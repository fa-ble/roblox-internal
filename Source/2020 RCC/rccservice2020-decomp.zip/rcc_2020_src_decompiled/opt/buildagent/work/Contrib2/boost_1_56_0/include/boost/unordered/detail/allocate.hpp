// Address: 0xed75a0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JSG_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSM_DpOSN_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,std::pair<std::string const,RBX::Reflection::Variant>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        std::pair<const std::string,RBX::Reflection::Variant> *x)
{
  __int64 v4; // rax
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rax

  std::string::basic_string(p, x);
  *((_QWORD *)p + 3) = *((_QWORD *)x + 3);
  *((_QWORD *)p + 4) = 0;
  v4 = *((_QWORD *)x + 4);
  if ( v4 )
  {
    (*(void (__fastcall **)(char *, char *))(v4 + 8))((char *)x + 40, (char *)p + 40);
    v5 = *((_QWORD *)x + 4);
  }
  else
  {
    v5 = 0;
  }
  *((_QWORD *)p + 4) = v5;
  v6 = *((_QWORD *)x + 4);
  if ( v6 )
  {
    (*(void (__fastcall **)(char *))(v6 + 16))((char *)x + 40);
    *((_QWORD *)x + 4) = 0;
  }
  *((_QWORD *)x + 3) = RBX::Reflection::Type::getSingleton<void>();
  v7 = *((_QWORD *)x + 4);
  if ( v7 )
  {
    (*(void (__fastcall **)(char *))(v7 + 16))((char *)x + 40);
    *((_QWORD *)x + 4) = 0;
  }
}


// Address: 0xf7b010 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKPN3RBX8InstanceENS6_INS_10shared_ptrIS8_EENS0_13unordered_mapImjNS_4hashImEENS3_8equal_toImEENS4_INS6_IKmjEEEEEEEEEEEEEEE7destroyISN_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISP_T_EE5valueEvE4typeERSP_PST_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Instance * const,std::pair<boost::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned long,unsigned int,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<unsigned long const,unsigned int>>>>>>>>::destroy<std::pair<RBX::Instance * const,std::pair<boost::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned long,unsigned int,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<unsigned long const,unsigned int>>>>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Instance *const,std::pair<boost::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned long,unsigned int,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<const unsigned long,unsigned int> > > > > > > *a1,
        std::pair<RBX::Instance *const,std::pair<boost::shared_ptr<RBX::Instance>,boost::unordered::unordered_map<unsigned long,unsigned int,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<const unsigned long,unsigned int> > > > > *p)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,unsigned int> >,unsigned long,unsigned int,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi
  boost::detail::sp_counted_base *pi; // rbx

  buckets = p->second.second.table_.buckets_;
  if ( buckets )
  {
    if ( p->second.second.table_.size_ )
    {
      bucket_count = p->second.second.table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --p->second.second.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = p->second.second.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&p->second.second.table_.max_load_ = 0;
  }
  pi = p->second.first.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf7b0a0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKPN3RBX8InstanceENS6_INS_10shared_ptrINS7_8AnimatorEEENS0_13unordered_mapINS7_9ContentIdENS7_7Network10Replicator30AnimationTrackReplicatedValuesENS_4hashISF_EENS3_8equal_toISF_EENS4_INS6_IKSF_SI_EEEEEEEEEEEEEEE7destroyISS_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISU_T_EE5valueEvE4typeERSU_PSY_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Instance * const,std::pair<boost::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>>>>>::destroy<std::pair<RBX::Instance * const,std::pair<boost::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,RBX::Network::Replicator::AnimationTrackReplicatedValues>>>>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Instance *const,std::pair<boost::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<const RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues> > > > > > > *a1,
        std::pair<RBX::Instance *const,std::pair<boost::shared_ptr<RBX::Animator>,boost::unordered::unordered_map<RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<const RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues> > > > > *p)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues> >,RBX::ContentId,RBX::Network::Replicator::AnimationTrackReplicatedValues,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx
  boost::detail::sp_counted_base *pi; // rbx

  buckets = p->second.second.table_.buckets_;
  if ( buckets )
  {
    if ( p->second.second.table_.size_ )
    {
      bucket_count = p->second.second.table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        if ( ((__int64)next[2].next_ & 1) != 0 )
          operator delete(next[4].next_);
        operator delete(next);
        --p->second.second.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = p->second.second.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&p->second.second.table_.max_load_ = 0;
  }
  pi = p->second.first.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xf7b150 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX4GuidENS7_7Network10Replicator12DeferredTreeEEEEEEEE7destroyISD_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISF_T_EE5valueEvE4typeERSF_PSJ_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>>>>::destroy<std::pair<RBX::Guid const,RBX::Network::Replicator::DeferredTree>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Guid,RBX::Network::Replicator::DeferredTree> > > *a1,
        std::pair<const RBX::Guid,RBX::Network::Replicator::DeferredTree> *p)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // r12
  void *v5; // rdi
  volatile signed __int32 *v6; // rbx

  v2 = *((_QWORD *)p + 3);
  if ( v2 )
  {
    v3 = *((_QWORD *)p + 4);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)p + 3);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 )
        {
          if ( !_InterlockedSub(v4 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
            if ( !_InterlockedSub(v4 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
          }
        }
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)p + 3);
    }
    *((_QWORD *)p + 4) = v2;
    operator delete(v5);
  }
  v6 = (volatile signed __int32 *)*((_QWORD *)p + 2);
  if ( v6 && !_InterlockedSub(v6 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0xf80f40 | Name: _ZN5boost9unordered6detail17array_constructorINS_19fast_pool_allocatorINS1_10ptr_bucketENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEED2Ev
void __fastcall boost::unordered::detail::array_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_bucket,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~array_constructor(
        boost::unordered::detail::array_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_bucket,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this)
{
  boost::unordered::detail::array_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_bucket,boost::default_user_allocator_new_delete,boost::mutex,32,0> >::pointer ptr; // rbx
  boost::singleton_pool<boost::fast_pool_allocator_tag,8,boost::default_user_allocator_new_delete,boost::mutex,32,0>::size_type length; // rsi

  ptr = this->ptr_;
  if ( ptr )
  {
    length = this->length_;
    if ( length == 1 )
    {
      if ( !byte_29FE162 )
      {
        byte_29FE162 = 1;
        boost::mutex::mutex(&stru_29FE068);
        *(_OWORD *)&stru_29FE090.first = 0;
        stru_29FE090.list.sz = 0;
        *(_OWORD *)&stru_29FE090.requested_size = xmmword_3EA460;
        *(_OWORD *)&stru_29FE090.start_size = 0x20u;
      }
      boost::mutex::lock(&stru_29FE068);
      ptr->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)stru_29FE090.first;
      stru_29FE090.first = ptr;
      boost::mutex::unlock(&stru_29FE068);
    }
    else
    {
      boost::singleton_pool<boost::fast_pool_allocator_tag,8u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::free(
        this->ptr_,
        length);
    }
  }
}


// Address: 0x10c52c0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX8InstanceEEEN3rbx7signals17scoped_connectionEEEEEEEE7destroyISF_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISH_T_EE5valueEvE4typeERSH_PSL_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::Instance> const,rbx::signals::scoped_connection>>>>::destroy<std::pair<boost::shared_ptr<RBX::Instance> const,rbx::signals::scoped_connection>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::Instance>,rbx::signals::scoped_connection> > > *a1,
        std::pair<const boost::shared_ptr<RBX::Instance>,rbx::signals::scoped_connection> *p)
{
  rbx::signals::slot_base *v2; // rdi
  boost::detail::sp_counted_base *pi; // rbx

  rbx::signals::connection::disconnect(&p->second.con);
  v2 = p->second.con.weak_slot.p_;
  if ( v2 && !_InterlockedSub(&v2->weak.v, 1u) )
    operator delete(v2);
  pi = p->first.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10c5340 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX12PartInstanceEEEN3rbx7signals17scoped_connectionEEEEEEEE7destroyISF_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISH_T_EE5valueEvE4typeERSH_PSL_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::PartInstance> const,rbx::signals::scoped_connection>>>>::destroy<std::pair<boost::shared_ptr<RBX::PartInstance> const,rbx::signals::scoped_connection>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::PartInstance>,rbx::signals::scoped_connection> > > *a1,
        std::pair<const boost::shared_ptr<RBX::PartInstance>,rbx::signals::scoped_connection> *p)
{
  rbx::signals::slot_base *v2; // rdi
  boost::detail::sp_counted_base *pi; // rbx

  rbx::signals::connection::disconnect(&p->second.con);
  v2 = p->second.con.weak_slot.p_;
  if ( v2 && !_InterlockedSub(&v2->weak.v, 1u) )
    operator delete(v2);
  pi = p->first.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1214450 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX10HttpTargetENS_10shared_ptrINS7_14AsyncHttpQueue7RequestEEEEEEEEEE7destroyISE_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISG_T_EE5valueEvE4typeERSG_PSK_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::HttpTarget const,boost::shared_ptr<RBX::AsyncHttpQueue::Request>>>>>::destroy<std::pair<RBX::HttpTarget const,boost::shared_ptr<RBX::AsyncHttpQueue::Request>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request> > > > *a1,
        std::pair<const RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request> > *p)
{
  volatile signed __int32 *v2; // r14

  v2 = (volatile signed __int32 *)*((_QWORD *)p + 10);
  if ( v2 && !_InterlockedSub(v2 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
    if ( !_InterlockedSub(v2 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
  }
  if ( (*((_BYTE *)p + 48) & 1) != 0 )
  {
    operator delete(*((void **)p + 8));
    if ( (*((_BYTE *)p + 24) & 1) == 0 )
    {
LABEL_7:
      if ( (*(_BYTE *)p & 1) == 0 )
        return;
LABEL_11:
      operator delete(*((void **)p + 2));
      return;
    }
  }
  else if ( (*((_BYTE *)p + 24) & 1) == 0 )
  {
    goto LABEL_7;
  }
  operator delete(*((void **)p + 5));
  if ( (*(_BYTE *)p & 1) != 0 )
    goto LABEL_11;
}


// Address: 0x1265d40 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX21BatchThumbnailFetcher21BatchThumbnailRequestEEEEEEEE7destroyISG_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISI_T_EE5valueEvE4typeERSI_PSM_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::BatchThumbnailFetcher::BatchThumbnailRequest>>>>::destroy<std::pair<std::string const,RBX::BatchThumbnailFetcher::BatchThumbnailRequest>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::BatchThumbnailFetcher::BatchThumbnailRequest> > > *a1,
        std::pair<const std::string,RBX::BatchThumbnailFetcher::BatchThumbnailRequest> *p)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  __int64 v4; // rax
  void (__fastcall *v5)(__int64, __int64, __int64); // rax
  void *v6; // rdi

  v2 = *((_QWORD *)p + 8);
  if ( v2 )
  {
    v3 = *((_QWORD *)p + 9);
    if ( v3 == v2 )
    {
      v6 = (void *)*((_QWORD *)p + 8);
    }
    else
    {
      do
      {
        v4 = *(_QWORD *)(v3 - 32);
        if ( v4 )
        {
          if ( (v4 & 1) == 0 )
          {
            v5 = *(void (__fastcall **)(__int64, __int64, __int64))(v4 & 0xFFFFFFFFFFFFFFFELL);
            if ( v5 )
              v5(v3 - 24, v3 - 24, 2);
          }
          *(_QWORD *)(v3 - 32) = 0;
        }
        v3 -= 32;
      }
      while ( v2 != v3 );
      v6 = (void *)*((_QWORD *)p + 8);
    }
    *((_QWORD *)p + 9) = v2;
    operator delete(v6);
  }
  if ( (*((_BYTE *)p + 24) & 1) != 0 )
    operator delete(*((void **)p + 5));
  if ( (*(_BYTE *)p & 1) != 0 )
    operator delete(*((void **)p + 2));
}


// Address: 0x14e5930 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX11ChatService18MessageAndSenderIdENS3_6vectorINS_8functionIFvRKNS7_16TextFilterResultEEEENS4_ISH_EEEEEEEEEEE7destroyISK_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISM_T_EE5valueEvE4typeERSM_PSQ_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::ChatService::MessageAndSenderId const,std::vector<boost::function<void ()(RBX::TextFilterResult const&)>>>>>>::destroy<std::pair<RBX::ChatService::MessageAndSenderId const,std::vector<boost::function<void ()(RBX::TextFilterResult const&)>>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::ChatService::MessageAndSenderId,std::vector<boost::function<void (const RBX::TextFilterResult &)>> > > > *a1,
        std::pair<const RBX::ChatService::MessageAndSenderId,std::vector<boost::function<void (const RBX::TextFilterResult &)>> > *p)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  __int64 v4; // rax
  void (__fastcall *v5)(__int64, __int64, __int64); // rax
  void *v6; // rdi

  v2 = *((_QWORD *)p + 4);
  if ( v2 )
  {
    v3 = *((_QWORD *)p + 5);
    if ( v3 == v2 )
    {
      v6 = (void *)*((_QWORD *)p + 4);
    }
    else
    {
      do
      {
        v4 = *(_QWORD *)(v3 - 32);
        if ( v4 )
        {
          if ( (v4 & 1) == 0 )
          {
            v5 = *(void (__fastcall **)(__int64, __int64, __int64))(v4 & 0xFFFFFFFFFFFFFFFELL);
            if ( v5 )
              v5(v3 - 24, v3 - 24, 2);
          }
          *(_QWORD *)(v3 - 32) = 0;
        }
        v3 -= 32;
      }
      while ( v2 != v3 );
      v6 = (void *)*((_QWORD *)p + 4);
    }
    *((_QWORD *)p + 5) = v2;
    operator delete(v6);
  }
  if ( (*(_BYTE *)p & 1) != 0 )
    operator delete(*((void **)p + 2));
}


// Address: 0x1530b80 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS3_6vectorINS_10shared_ptrIN3RBX17LocalizationTable5EntryEEENS4_ISI_EEEEEEEEEEE7destroyISL_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISN_T_EE5valueEvE4typeERSN_PSR_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::vector<boost::shared_ptr<RBX::LocalizationTable::Entry>>>>>>::destroy<std::pair<std::string const,std::vector<boost::shared_ptr<RBX::LocalizationTable::Entry>>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::vector<boost::shared_ptr<RBX::LocalizationTable::Entry>> > > > *a1,
        std::pair<const std::string,std::vector<boost::shared_ptr<RBX::LocalizationTable::Entry>> > *p)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // r12
  void *v5; // rdi

  v2 = *((_QWORD *)p + 3);
  if ( v2 )
  {
    v3 = *((_QWORD *)p + 4);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)p + 3);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 )
        {
          if ( !_InterlockedSub(v4 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
            if ( !_InterlockedSub(v4 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
          }
        }
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)p + 3);
    }
    *((_QWORD *)p + 4) = v2;
    operator delete(v5);
  }
  if ( (*(_BYTE *)p & 1) != 0 )
    operator delete(*((void **)p + 2));
}


// Address: 0x1535e90 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRSC_SL_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSN_DpOSO_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,std::string const&,std::string const&>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const std::string *x,
        const std::string *a4)
{
  std::string::basic_string(p, x);
  *((_QWORD *)p + 3) = RBX::Reflection::Type::getSingleton<std::string>();
  *((_QWORD *)p + 4) = 0;
  std::string::basic_string((char *)p + 40, a4);
  if ( !(_BYTE)byte_29F1F00 && __cxa_guard_acquire(&byte_29F1F00) )
  {
    *(__m128i *)&xmmword_29F1EE8 = _mm_unpacklo_epi64(
                                     (__m128i)(unsigned __int64)rbx::implementation::typed_holder<std::string>::construct_func,
                                     (__m128i)(unsigned __int64)rbx::implementation::typed_holder<std::string>::moveConstruct_func);
    qword_29F1EF8 = (__int64)rbx::implementation::typed_holder<std::string>::destruct_func;
    __cxa_guard_release(&byte_29F1F00);
  }
  *((_QWORD *)p + 4) = &xmmword_29F1EE8;
}


// Address: 0x1537bd0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEESB_EEEEEEE9constructISD_JRSC_RA1_KcEEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISF_T_DpT0_EE5valueEvE4typeERSF_PSN_DpOSO_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::string>>>>::construct<std::pair<std::string const,std::string>,std::string const&,char const(&)[1]>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::string > > > *a,
        std::pair<const std::string,std::string > *p,
        const std::string *x,
        const char (*a4)[1])
{
  size_t v5; // rax
  size_t v6; // r13
  char *v7; // r15
  size_t v8; // rbx
  struct _Unwind_Exception *v9; // rax
  struct _Unwind_Exception *v10; // rbx

  std::string::basic_string(p, x);
  *(_OWORD *)((char *)p + 24) = 0;
  *((_QWORD *)p + 5) = 0;
  v5 = strlen((const char *)a4);
  if ( v5 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error((char *)p + 24);
    v10 = v9;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v10);
  }
  v6 = v5;
  if ( v5 >= 0x17 )
  {
    v8 = (v5 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v7 = (char *)operator new(v8);
    *((_QWORD *)p + 5) = v7;
    *((_QWORD *)p + 3) = v8 | 1;
    *((_QWORD *)p + 4) = v6;
  }
  else
  {
    *((_BYTE *)p + 24) = 2 * v5;
    v7 = (char *)p + 25;
    if ( !v5 )
      goto LABEL_7;
  }
  memcpy(v7, a4, v6);
LABEL_7:
  v7[v6] = 0;
}


// Address: 0x15cbb10 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS6_INS_8functionIFvNS_10shared_ptrIN3RBX8InstanceEEEEEENSD_IFvSB_EEEEEEEEEEEE7destroyISN_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISP_T_EE5valueEvE4typeERSP_PST_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::pair<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>>>>>::destroy<std::pair<std::string const,std::pair<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::pair<boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)> > > > > *a1,
        std::pair<const std::string,std::pair<boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)> > > *p)
{
  __int64 v2; // rax
  void (__fastcall *v3)(char *, char *, __int64); // rax
  __int64 v4; // rax
  void (__fastcall *v5)(char *, char *, __int64); // rax

  v2 = *((_QWORD *)p + 7);
  if ( v2 )
  {
    if ( (v2 & 1) == 0 )
    {
      v3 = *(void (__fastcall **)(char *, char *, __int64))(v2 & 0xFFFFFFFFFFFFFFFELL);
      if ( v3 )
        v3((char *)p + 64, (char *)p + 64, 2);
    }
    *((_QWORD *)p + 7) = 0;
  }
  v4 = *((_QWORD *)p + 3);
  if ( v4 )
  {
    if ( (v4 & 1) == 0 )
    {
      v5 = *(void (__fastcall **)(char *, char *, __int64))(v4 & 0xFFFFFFFFFFFFFFFELL);
      if ( v5 )
        v5((char *)p + 32, (char *)p + 32, 2);
    }
    *((_QWORD *)p + 3) = 0;
  }
  if ( (*(_BYTE *)p & 1) != 0 )
    operator delete(*((void **)p + 2));
}


// Address: 0x1792300 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX11InputObjectEEENS3_6vectorINS8_17GuiLayerCollector11SunkGuiDataENS4_ISE_EEEEEEEEEEE7destroyISH_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISJ_T_EE5valueEvE4typeERSJ_PSN_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::InputObject> const,std::vector<RBX::GuiLayerCollector::SunkGuiData>>>>>::destroy<std::pair<boost::shared_ptr<RBX::InputObject> const,std::vector<RBX::GuiLayerCollector::SunkGuiData>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData> > > > *a1,
        std::pair<const boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData> > *p)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // rdi
  void *v5; // rdi
  volatile signed __int32 *v6; // rbx

  v2 = *((_QWORD *)p + 2);
  if ( v2 )
  {
    v3 = *((_QWORD *)p + 3);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)p + 2);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 16);
        if ( v4 && !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        v3 -= 24;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)p + 2);
    }
    *((_QWORD *)p + 3) = v2;
    operator delete(v5);
  }
  v6 = (volatile signed __int32 *)*((_QWORD *)p + 1);
  if ( v6 && !_InterlockedSub(v6 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


// Address: 0x17da4e0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS6_INS_8weak_ptrIN3RBX9GuiObjectEEENS_10shared_ptrIKNSE_10Reflection5TupleEEEEEEEEEEEE7destroyISN_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISP_T_EE5valueEvE4typeERSP_PST_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::pair<boost::weak_ptr<RBX::GuiObject>,boost::shared_ptr<RBX::Reflection::Tuple const>>>>>>::destroy<std::pair<std::string const,std::pair<boost::weak_ptr<RBX::GuiObject>,boost::shared_ptr<RBX::Reflection::Tuple const>>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::pair<boost::weak_ptr<RBX::GuiObject>,boost::shared_ptr<const RBX::Reflection::Tuple> > > > > *a1,
        std::pair<const std::string,std::pair<boost::weak_ptr<RBX::GuiObject>,boost::shared_ptr<const RBX::Reflection::Tuple> > > *p)
{
  volatile signed __int32 *v2; // rbx
  volatile signed __int32 *v3; // rdi

  v2 = (volatile signed __int32 *)*((_QWORD *)p + 6);
  if ( v2 )
  {
    if ( !_InterlockedSub(v2 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
      if ( !_InterlockedSub(v2 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
    }
  }
  v3 = (volatile signed __int32 *)*((_QWORD *)p + 4);
  if ( v3 && !_InterlockedSub(v3 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  if ( (*(_BYTE *)p & 1) != 0 )
    operator delete(*((void **)p + 2));
}


// Address: 0x18c0380 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA5_KcRKSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSR_DpOSS_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[5],RBX::Reflection::Variant const&>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[5],
        const RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rcx
  struct _Unwind_Exception *v12; // rax
  struct _Unwind_Exception *v13; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v13 = v12;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v13);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->construct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
}


// Address: 0x18c05c0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA12_KcRKSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSR_DpOSS_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[12],RBX::Reflection::Variant const&>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[12],
        const RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rcx
  struct _Unwind_Exception *v12; // rax
  struct _Unwind_Exception *v13; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v13 = v12;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v13);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->construct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
}


// Address: 0x18c0800 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA13_KcRKSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSR_DpOSS_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[13],RBX::Reflection::Variant const&>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[13],
        const RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rcx
  struct _Unwind_Exception *v12; // rax
  struct _Unwind_Exception *v13; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v13 = v12;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v13);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->construct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
}


// Address: 0x18c0a40 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA8_KcRKSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSR_DpOSS_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[8],RBX::Reflection::Variant const&>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[8],
        const RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rcx
  struct _Unwind_Exception *v12; // rax
  struct _Unwind_Exception *v13; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v13 = v12;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v13);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->construct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
}


// Address: 0x18c0c80 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA17_KcRKSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSR_DpOSS_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[17],RBX::Reflection::Variant const&>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[17],
        const RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rcx
  struct _Unwind_Exception *v12; // rax
  struct _Unwind_Exception *v13; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v13 = v12;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v13);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->construct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
}


// Address: 0x18c0ec0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA10_KcRbEEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSQ_DpOSR_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[10],bool &>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[10],
        bool *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  struct _Unwind_Exception *v10; // rax
  struct _Unwind_Exception *v11; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v11 = v10;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v11);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
  }
  else
  {
    *(_BYTE *)p = 2 * v6;
    v8 = (char *)p + 1;
    if ( !v6 )
      goto LABEL_7;
  }
  memcpy(v8, x, v7);
LABEL_7:
  v8[v7] = 0;
  *((_QWORD *)p + 3) = RBX::Reflection::Type::getSingleton<bool>();
  *((_QWORD *)p + 4) = 0;
  *((_BYTE *)p + 40) = *a4;
  if ( !(_BYTE)byte_29F1F20 && __cxa_guard_acquire(&byte_29F1F20) )
  {
    *(__m128i *)&xmmword_29F1F08 = _mm_unpacklo_epi64(
                                     (__m128i)(unsigned __int64)rbx::implementation::typed_holder<bool>::construct_func,
                                     (__m128i)(unsigned __int64)rbx::implementation::typed_holder<bool>::moveConstruct_func);
    qword_29F1F18 = (__int64)rbx::implementation::typed_holder<bool>::destruct_func;
    __cxa_guard_release(&byte_29F1F20);
  }
  *((_QWORD *)p + 4) = &xmmword_29F1F08;
}


// Address: 0x18c1150 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA7_KcRbEEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSQ_DpOSR_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[7],bool &>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[7],
        bool *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  struct _Unwind_Exception *v10; // rax
  struct _Unwind_Exception *v11; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v11 = v10;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v11);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
  }
  else
  {
    *(_BYTE *)p = 2 * v6;
    v8 = (char *)p + 1;
    if ( !v6 )
      goto LABEL_7;
  }
  memcpy(v8, x, v7);
LABEL_7:
  v8[v7] = 0;
  *((_QWORD *)p + 3) = RBX::Reflection::Type::getSingleton<bool>();
  *((_QWORD *)p + 4) = 0;
  *((_BYTE *)p + 40) = *a4;
  if ( !(_BYTE)byte_29F1F20 && __cxa_guard_acquire(&byte_29F1F20) )
  {
    *(__m128i *)&xmmword_29F1F08 = _mm_unpacklo_epi64(
                                     (__m128i)(unsigned __int64)rbx::implementation::typed_holder<bool>::construct_func,
                                     (__m128i)(unsigned __int64)rbx::implementation::typed_holder<bool>::moveConstruct_func);
    qword_29F1F18 = (__int64)rbx::implementation::typed_holder<bool>::destruct_func;
    __cxa_guard_release(&byte_29F1F20);
  }
  *((_QWORD *)p + 4) = &xmmword_29F1F08;
}


// Address: 0x18c13e0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA10_KcRKSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSR_DpOSS_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[10],RBX::Reflection::Variant const&>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[10],
        const RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rcx
  struct _Unwind_Exception *v12; // rax
  struct _Unwind_Exception *v13; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v13 = v12;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v13);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->construct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
}


// Address: 0x18c1620 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA12_KciEEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSP_DpOSQ_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[12],int>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[12],
        int *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  struct _Unwind_Exception *v10; // rax
  struct _Unwind_Exception *v11; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v11 = v10;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v11);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
  }
  else
  {
    *(_BYTE *)p = 2 * v6;
    v8 = (char *)p + 1;
    if ( !v6 )
      goto LABEL_7;
  }
  memcpy(v8, x, v7);
LABEL_7:
  v8[v7] = 0;
  *((_QWORD *)p + 3) = RBX::Reflection::Type::getSingleton<int>();
  *((_QWORD *)p + 4) = 0;
  *((_DWORD *)p + 10) = *a4;
  if ( !(_BYTE)byte_29F1EC8 && __cxa_guard_acquire(&byte_29F1EC8) )
  {
    *(__m128i *)&xmmword_29F1EB0 = _mm_unpacklo_epi64(
                                     (__m128i)(unsigned __int64)rbx::implementation::typed_holder<int>::construct_func,
                                     (__m128i)(unsigned __int64)rbx::implementation::typed_holder<int>::moveConstruct_func);
    qword_29F1EC0 = (__int64)rbx::implementation::typed_holder<int>::destruct_func;
    __cxa_guard_release(&byte_29F1EC8);
  }
  *((_QWORD *)p + 4) = &xmmword_29F1EB0;
}


// Address: 0x18c18b0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA23_KcNSD_14MembershipTypeEEEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSQ_DpOSR_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[23],RBX::MembershipType>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[23],
        RBX::MembershipType *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  struct _Unwind_Exception *v10; // rax
  struct _Unwind_Exception *v11; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v11 = v10;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v11);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
  }
  else
  {
    *(_BYTE *)p = 2 * v6;
    v8 = (char *)p + 1;
    if ( !v6 )
      goto LABEL_7;
  }
  memcpy(v8, x, v7);
LABEL_7:
  v8[v7] = 0;
  *((_QWORD *)p + 3) = RBX::Reflection::Type::getSingleton<RBX::MembershipType>();
  *((_QWORD *)p + 4) = 0;
  *((RBX::MembershipType *)p + 10) = *a4;
  if ( !(_BYTE)byte_29FABF8 && __cxa_guard_acquire(&byte_29FABF8) )
  {
    xmmword_29FABE0 = (__int128)_mm_unpacklo_epi64(
                                  (__m128i)(unsigned __int64)rbx::implementation::typed_holder<RBX::MembershipType>::construct_func,
                                  (__m128i)(unsigned __int64)rbx::implementation::typed_holder<RBX::MembershipType>::moveConstruct_func);
    qword_29FABF0 = (__int64)rbx::implementation::typed_holder<RBX::MembershipType>::destruct_func;
    __cxa_guard_release(&byte_29FABF8);
  }
  *((_QWORD *)p + 4) = &xmmword_29FABE0;
}


// Address: 0x1a26160 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA7_KcSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSP_DpOSQ_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[7],RBX::Reflection::Variant>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[7],
        RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rax
  const rbx::implementation::type_holder *v12; // rax
  const rbx::implementation::type_holder *v13; // rax
  struct _Unwind_Exception *v14; // rax
  struct _Unwind_Exception *v15; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v15 = v14;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v15);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->moveConstruct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
  v12 = a4->value.holder;
  if ( v12 )
  {
    v12->destruct(a4->value.data);
    a4->value.holder = 0;
  }
  a4->_type = RBX::Reflection::Type::getSingleton<void>();
  v13 = a4->value.holder;
  if ( v13 )
  {
    v13->destruct(a4->value.data);
    a4->value.holder = 0;
  }
}


// Address: 0x1a263f0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA9_KcSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSP_DpOSQ_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[9],RBX::Reflection::Variant>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[9],
        RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rax
  const rbx::implementation::type_holder *v12; // rax
  const rbx::implementation::type_holder *v13; // rax
  struct _Unwind_Exception *v14; // rax
  struct _Unwind_Exception *v15; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v15 = v14;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v15);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->moveConstruct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
  v12 = a4->value.holder;
  if ( v12 )
  {
    v12->destruct(a4->value.data);
    a4->value.holder = 0;
  }
  a4->_type = RBX::Reflection::Type::getSingleton<void>();
  v13 = a4->value.holder;
  if ( v13 )
  {
    v13->destruct(a4->value.data);
    a4->value.holder = 0;
  }
}


// Address: 0x1a26680 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA5_KcSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSP_DpOSQ_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[5],RBX::Reflection::Variant>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[5],
        RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rax
  const rbx::implementation::type_holder *v12; // rax
  const rbx::implementation::type_holder *v13; // rax
  struct _Unwind_Exception *v14; // rax
  struct _Unwind_Exception *v15; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v15 = v14;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v15);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->moveConstruct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
  v12 = a4->value.holder;
  if ( v12 )
  {
    v12->destruct(a4->value.data);
    a4->value.holder = 0;
  }
  a4->_type = RBX::Reflection::Type::getSingleton<void>();
  v13 = a4->value.holder;
  if ( v13 )
  {
    v13->destruct(a4->value.data);
    a4->value.holder = 0;
  }
}


// Address: 0x1a26910 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA10_KcSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSP_DpOSQ_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[10],RBX::Reflection::Variant>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[10],
        RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rax
  const rbx::implementation::type_holder *v12; // rax
  const rbx::implementation::type_holder *v13; // rax
  struct _Unwind_Exception *v14; // rax
  struct _Unwind_Exception *v15; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v15 = v14;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v15);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->moveConstruct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
  v12 = a4->value.holder;
  if ( v12 )
  {
    v12->destruct(a4->value.data);
    a4->value.holder = 0;
  }
  a4->_type = RBX::Reflection::Type::getSingleton<void>();
  v13 = a4->value.holder;
  if ( v13 )
  {
    v13->destruct(a4->value.data);
    a4->value.holder = 0;
  }
}


// Address: 0x1a26ba0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JRA8_KcSF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSP_DpOSQ_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,char const(&)[8],RBX::Reflection::Variant>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        const char (*x)[8],
        RBX::Reflection::Variant *a4)
{
  size_t v6; // rax
  size_t v7; // rbx
  char *v8; // r13
  size_t v9; // rbp
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v11; // rax
  const rbx::implementation::type_holder *v12; // rax
  const rbx::implementation::type_holder *v13; // rax
  struct _Unwind_Exception *v14; // rax
  struct _Unwind_Exception *v15; // rbx

  *(_OWORD *)p = 0;
  *((_QWORD *)p + 2) = 0;
  v6 = strlen((const char *)x);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(p);
    v15 = v14;
    if ( (*(_BYTE *)p & 1) != 0 )
      operator delete(*((void **)p + 2));
    _Unwind_Resume(v15);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)p + 2) = v8;
    *(_QWORD *)p = v9 | 1;
    *((_QWORD *)p + 1) = v7;
    goto LABEL_6;
  }
  *(_BYTE *)p = 2 * v6;
  v8 = (char *)p + 1;
  if ( v6 )
LABEL_6:
    memcpy(v8, x, v7);
  v8[v7] = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->moveConstruct(a4->value.data, (char *)p + 40);
    v11 = a4->value.holder;
  }
  else
  {
    v11 = 0;
  }
  *((_QWORD *)p + 4) = v11;
  v12 = a4->value.holder;
  if ( v12 )
  {
    v12->destruct(a4->value.data);
    a4->value.holder = 0;
  }
  a4->_type = RBX::Reflection::Type::getSingleton<void>();
  v13 = a4->value.holder;
  if ( v13 )
  {
    v13->destruct(a4->value.data);
    a4->value.holder = 0;
  }
}


// Address: 0x1b47210 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX11PackageLinkEEEN3rbx7signals17scoped_connectionEEEEEEEE7destroyISF_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISH_T_EE5valueEvE4typeERSH_PSL_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::PackageLink> const,rbx::signals::scoped_connection>>>>::destroy<std::pair<boost::shared_ptr<RBX::PackageLink> const,rbx::signals::scoped_connection>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::PackageLink>,rbx::signals::scoped_connection> > > *a1,
        std::pair<const boost::shared_ptr<RBX::PackageLink>,rbx::signals::scoped_connection> *p)
{
  rbx::signals::slot_base *v2; // rdi
  boost::detail::sp_counted_base *pi; // rbx

  rbx::signals::connection::disconnect(&p->second.con);
  v2 = p->second.con.weak_slot.p_;
  if ( v2 && !_InterlockedSub(&v2->weak.v, 1u) )
    operator delete(v2);
  pi = p->first.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1bbf970 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX20UntranslatedVariantsEEEEEEEE7destroyISF_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISH_T_EE5valueEvE4typeERSH_PSL_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::UntranslatedVariants>>>>::destroy<std::pair<std::string const,RBX::UntranslatedVariants>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::UntranslatedVariants> > > *a1,
        std::pair<const std::string,RBX::UntranslatedVariants> *p)
{
  _QWORD *v2; // r15
  __int64 v3; // r12
  void **v4; // rbx

  v2 = (_QWORD *)*((_QWORD *)p + 9);
  if ( v2 )
  {
    if ( *((_QWORD *)p + 6) )
    {
      v3 = *((_QWORD *)p + 5);
      v4 = (void **)v2[v3];
      do
      {
        v2[v3] = *v4;
        if ( ((_BYTE)v4[2] & 1) != 0 )
          operator delete(v4[4]);
        operator delete(v4);
        --*((_QWORD *)p + 6);
        v4 = (void **)v2[v3];
      }
      while ( v4 );
      v2 = (_QWORD *)*((_QWORD *)p + 9);
    }
    operator delete(v2);
    *((_OWORD *)p + 4) = 0;
  }
  if ( (*(_BYTE *)p & 1) != 0 )
    operator delete(*((void **)p + 2));
}


// Address: 0x1bbfac0 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX11TextScraper21TimedEntry_deprecatedEEEEEEEE7destroyISG_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISI_T_EE5valueEvE4typeERSI_PSM_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::TextScraper::TimedEntry_deprecated>>>>::destroy<std::pair<std::string const,RBX::TextScraper::TimedEntry_deprecated>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::TextScraper::TimedEntry_deprecated> > > *a1,
        std::pair<const std::string,RBX::TextScraper::TimedEntry_deprecated> *p)
{
  volatile signed __int32 *v2; // r14

  if ( (*((_BYTE *)p + 88) & 1) != 0 )
    operator delete(*((void **)p + 13));
  if ( (*((_BYTE *)p + 64) & 1) != 0 )
    operator delete(*((void **)p + 10));
  v2 = (volatile signed __int32 *)*((_QWORD *)p + 5);
  if ( v2 )
  {
    if ( !_InterlockedSub(v2 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
      if ( !_InterlockedSub(v2 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
    }
  }
  if ( (*(_BYTE *)p & 1) != 0 )
    operator delete(*((void **)p + 2));
}


// Address: 0x1d1d430 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX6PlayerEEENS0_13unordered_setINS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS_4hashISH_EENS3_8equal_toISH_EENS4_ISH_EEEEEEEEEEE7destroyISO_EENS_12disable_if_cIXsr5boost9unordered6detail11has_destroyISQ_T_EE5valueEvE4typeERSQ_PSU_
boost::disable_if_c<false,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::Player> const,boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>>>>>::destroy<std::pair<boost::shared_ptr<RBX::Player> const,boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>>>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::Player>,boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::string > > > > > *a1,
        std::pair<const boost::shared_ptr<RBX::Player>,boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::string > > > *p)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<std::string >,std::string,boost::hash<std::string>,std::equal_to<std::string > > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx
  boost::detail::sp_counted_base *pi; // rbx

  buckets = p->second.table_.buckets_;
  if ( buckets )
  {
    if ( p->second.table_.size_ )
    {
      bucket_count = p->second.table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        if ( ((__int64)next[2].next_ & 1) != 0 )
          operator delete(next[4].next_);
        operator delete(next);
        --p->second.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = p->second.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&p->second.table_.max_load_ = 0;
  }
  pi = p->first.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1e94d70 | Name: _ZN5boost9unordered6detail16allocator_traitsINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE9constructISG_JSB_SF_EEENS_11enable_if_cIXsr5boost9unordered6detail13has_constructISI_T_DpT0_EE5valueEvE4typeERSI_PSM_DpOSN_
boost::enable_if_c<true,void>::type __fastcall boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct<std::pair<std::string const,RBX::Reflection::Variant>,std::string,RBX::Reflection::Variant>(
        std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > *a,
        std::pair<const std::string,RBX::Reflection::Variant> *p,
        std::string *x,
        RBX::Reflection::Variant *a4)
{
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v6; // rax
  const rbx::implementation::type_holder *v7; // rax
  const rbx::implementation::type_holder *v8; // rax

  *((_QWORD *)p + 2) = *((_QWORD *)x + 2);
  *(_OWORD *)p = *(_OWORD *)x;
  *(_OWORD *)x = 0;
  *((_QWORD *)x + 2) = 0;
  *((_QWORD *)p + 3) = a4->_type;
  *((_QWORD *)p + 4) = 0;
  holder = a4->value.holder;
  if ( holder )
  {
    holder->moveConstruct(a4->value.data, (char *)p + 40);
    v6 = a4->value.holder;
  }
  else
  {
    v6 = 0;
  }
  *((_QWORD *)p + 4) = v6;
  v7 = a4->value.holder;
  if ( v7 )
  {
    v7->destruct(a4->value.data);
    a4->value.holder = 0;
  }
  a4->_type = RBX::Reflection::Type::getSingleton<void>();
  v8 = a4->value.holder;
  if ( v8 )
  {
    v8->destruct(a4->value.data);
    a4->value.holder = 0;
  }
}


