// Address: 0x25ed650 | Name: _ZN5boost4asio5error6detail12ssl_categoryD0Ev
// Alternative name is 'j__ZdlPv_1968'
// attributes: thunk
void __fastcall boost::asio::error::detail::ssl_category::~ssl_category(boost::asio::error::detail::ssl_category *this)
{
  operator delete(this);
}


// Address: 0x25ed660 | Name: _ZNK5boost4asio5error6detail12ssl_category4nameEv
const char *__fastcall boost::asio::error::detail::ssl_category::name(
        const boost::asio::error::detail::ssl_category *this)
{
  return "asio.ssl";
}


// Address: 0x25ed670 | Name: _ZNK5boost4asio5error6detail12ssl_category7messageEi
boost::asio::error::detail::ssl_category *__fastcall boost::asio::error::detail::ssl_category::message(
        boost::asio::error::detail::ssl_category *this,
        int a2,
        int a3)
{
  __int64 v3; // rax
  const char *v4; // r14
  size_t v5; // rax
  size_t v6; // r13
  char *v7; // r12
  size_t v8; // rbx

  v3 = ERR_reason_error_string(a3);
  v4 = "asio.ssl error";
  if ( v3 )
    v4 = (const char *)v3;
  *(_OWORD *)&this->_vptr$error_category = 0;
  *((_QWORD *)this + 2) = 0;
  v5 = strlen(v4);
  if ( v5 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(this);
    JUMPOUT(0x25ED71C);
  }
  v6 = v5;
  if ( v5 >= 0x17 )
  {
    v8 = (v5 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v7 = (char *)operator new(v8);
    *((_QWORD *)this + 2) = v7;
    this->_vptr$error_category = (int (**)(void))(v8 | 1);
    *((_QWORD *)this + 1) = v6;
  }
  else
  {
    LOBYTE(this->_vptr$error_category) = 2 * v5;
    v7 = (char *)&this->_vptr$error_category + 1;
    if ( !v5 )
      goto LABEL_9;
  }
  memcpy(v7, v4, v6);
LABEL_9:
  v7[v6] = 0;
  return this;
}


// Address: 0x25ed720 | Name: _ZN5boost4asio3ssl5error6detail15stream_categoryD0Ev
// Alternative name is 'j__ZdlPv_1969'
// attributes: thunk
void __fastcall boost::asio::ssl::error::detail::stream_category::~stream_category(
        boost::asio::ssl::error::detail::stream_category *this)
{
  operator delete(this);
}


// Address: 0x25ed730 | Name: _ZNK5boost4asio3ssl5error6detail15stream_category4nameEv
const char *__fastcall boost::asio::ssl::error::detail::stream_category::name(
        const boost::asio::ssl::error::detail::stream_category *this)
{
  return "asio.ssl.stream";
}


