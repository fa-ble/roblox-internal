// Address: 0x25f8b50 | Name: _ZN5boost4asio6detail15task_io_service9init_taskEv
void __fastcall boost::asio::detail::task_io_service::init_task(boost::asio::detail::task_io_service_0 *this)
{
  boost::asio::detail::mutex *p_mutex; // r14
  boost::asio::detail::service_registry *service_registry; // rdi
  boost::asio::detail::reactor *v4; // rax
  boost::asio::detail::task_io_service::task_operation *p_task_operation; // rcx
  boost::asio::detail::task_io_service_operation *back; // rsi
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_back; // rdx
  size_t state; // rcx
  boost::asio::io_service::service::key_0 key; // [rsp+8h] [rbp-20h] BYREF

  p_mutex = &this->mutex_;
  pthread_mutex_lock(&this->mutex_.mutex_);
  if ( this->shutdown_ || this->task_ )
  {
    pthread_mutex_unlock(&p_mutex->mutex_);
  }
  else
  {
    service_registry = this->owner_->service_registry_;
    key.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::detail::epoll_reactor>;
    key.id_ = 0;
    v4 = (boost::asio::detail::reactor *)boost::asio::detail::service_registry::do_use_service(
                                           service_registry,
                                           &key,
                                           boost::asio::detail::service_registry::create<boost::asio::detail::epoll_reactor>);
    this->task_ = v4;
    p_task_operation = &this->task_operation_;
    this->task_operation_.next_ = 0;
    back = this->op_queue_.back_;
    if ( back )
    {
      p_back = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&this->op_queue_.back_;
      back->next_ = p_task_operation;
    }
    else
    {
      p_back = &this->op_queue_;
      this->op_queue_.back_ = p_task_operation;
    }
    p_back->front_ = p_task_operation;
    state = this->wakeup_event_.state_;
    this->wakeup_event_.state_ = state | 1;
    if ( state < 2 )
    {
      if ( v4 )
      {
        if ( !this->task_interrupted_ )
        {
          this->task_interrupted_ = 1;
          LODWORD(key.type_info_) = -2147483639;
          *(const std::type_info **)((char *)&key.type_info_ + 4) = (const std::type_info *)&v4->interrupter_;
          epoll_ctl(v4->epoll_fd_, 3, v4->interrupter_.read_descriptor_, (struct epoll_event *)&key);
        }
      }
      pthread_mutex_unlock(&p_mutex->mutex_);
    }
    else
    {
      pthread_mutex_unlock(&p_mutex->mutex_);
      pthread_cond_signal(&this->wakeup_event_.cond_);
    }
  }
}


// Address: 0x25f9180 | Name: _ZN5boost4asio6detail15task_io_service25post_deferred_completionsERNS1_8op_queueINS1_25task_io_service_operationEEE
void __fastcall boost::asio::detail::task_io_service::post_deferred_completions(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *ops)
{
  unsigned __int64 v2; // rcx
  __int64 v3; // rcx
  boost::asio::detail::task_io_service_operation **v4; // rdx
  _QWORD *p_front; // rcx
  size_t state; // rax
  boost::asio::detail::reactor *task; // rax
  struct epoll_event v8; // [rsp+0h] [rbp-28h] BYREF

  if ( ops->front_ )
  {
    if ( !this->one_thread_ )
      goto LABEL_11;
    v2 = __readfsqword(0xFFFFFFD8);
    if ( !v2 )
      goto LABEL_11;
    while ( *(boost::asio::detail::task_io_service_0 **)v2 != this )
    {
      v2 = *(_QWORD *)(v2 + 16);
      if ( !v2 )
        goto LABEL_11;
    }
    v3 = *(_QWORD *)(v2 + 8);
    if ( v3 )
    {
      v4 = (boost::asio::detail::task_io_service_operation **)(v3 + 8);
      if ( *(_QWORD *)(v3 + 16) )
        v4 = *(boost::asio::detail::task_io_service_operation ***)(v3 + 16);
      *v4 = ops->front_;
      *(_QWORD *)(v3 + 16) = ops->back_;
      *ops = 0;
    }
    else
    {
LABEL_11:
      pthread_mutex_lock(&this->mutex_.mutex_);
      if ( ops->front_ )
      {
        p_front = &this->op_queue_.front_;
        if ( this->op_queue_.back_ )
          p_front = &this->op_queue_.back_->next_;
        *p_front = ops->front_;
        this->op_queue_.back_ = ops->back_;
        *ops = 0;
      }
      state = this->wakeup_event_.state_;
      this->wakeup_event_.state_ = state | 1;
      if ( state < 2 )
      {
        if ( !this->task_interrupted_ )
        {
          task = this->task_;
          if ( task )
          {
            this->task_interrupted_ = 1;
            v8.events = -2147483639;
            v8.data.u64 = (uint64_t)&task->interrupter_;
            epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, &v8);
          }
        }
        pthread_mutex_unlock(&this->mutex_.mutex_);
      }
      else
      {
        pthread_mutex_unlock(&this->mutex_.mutex_);
        pthread_cond_signal(&this->wakeup_event_.cond_);
      }
    }
  }
}


// Address: 0x25f9430 | Name: _ZN5boost4asio6detail15task_io_serviceC2ERNS0_10io_serviceEm
void __fastcall boost::asio::detail::task_io_service::task_io_service(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::io_service *io_service,
        size_t concurrency_hint)
{
  int v3; // ebp
  const boost::system::error_category *v4; // rax
  int v5; // ebp
  const boost::system::error_category *v6; // rax
  const boost::system::error_category *v7; // r14
  const boost::system::error_category *v8; // r14
  _QWORD v9[2]; // [rsp+0h] [rbp-58h] BYREF
  int v10; // [rsp+10h] [rbp-48h]
  const boost::system::error_category *v11; // [rsp+18h] [rbp-40h]
  __int128 v12; // [rsp+20h] [rbp-38h]
  void *ptr; // [rsp+30h] [rbp-28h]

  this->key_ = 0;
  this->owner_ = io_service;
  this->next_ = 0;
  this->_vptr$service = (int (**)(void))off_29C2B60;
  this->one_thread_ = concurrency_hint == 1;
  v3 = pthread_mutex_init(&this->mutex_.mutex_, 0);
  v4 = boost::system::system_category();
  if ( v3 )
  {
    v7 = v4;
    std::runtime_error::runtime_error((std::runtime_error *)v9, "mutex");
    v9[0] = off_2875F00;
    v10 = v3;
    v11 = v7;
    v12 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v9);
  }
  this->wakeup_event_.state_ = 0;
  v5 = pthread_cond_init(&this->wakeup_event_.cond_, 0);
  v6 = boost::system::system_category();
  if ( v5 )
  {
    v8 = v6;
    std::runtime_error::runtime_error((std::runtime_error *)v9, "event");
    v9[0] = off_2875F00;
    v10 = v5;
    v11 = v8;
    v12 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v9);
  }
  *(_OWORD *)((char *)&this->task_operation_.next_ + 4) = 0;
  *(_OWORD *)&this->task_ = 0;
  this->task_interrupted_ = 1;
  *(boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)((char *)&this->op_queue_ + 2) = 0;
  *(_OWORD *)&this->outstanding_work_.__a_ = 0;
}


// Address: 0x25f9710 | Name: _ZN5boost4asio6detail15task_io_service16shutdown_serviceEv
void __fastcall boost::asio::detail::task_io_service::shutdown_service(boost::asio::detail::task_io_service_0 *this)
{
  boost::asio::detail::task_io_service_0 *front; // rbx
  boost::asio::detail::task_io_service_operation *v2; // rax
  const std::type_info *type_info; // r13
  int v4; // [rsp+0h] [rbp-38h] BYREF
  const boost::system::error_category *v5; // [rsp+8h] [rbp-30h]

  pthread_mutex_lock(&this->mutex_.mutex_);
  this->shutdown_ = 1;
  pthread_mutex_unlock(&this->mutex_.mutex_);
  front = (boost::asio::detail::task_io_service_0 *)this->op_queue_.front_;
  if ( front )
  {
    do
    {
      v2 = (boost::asio::detail::task_io_service_operation *)front->_vptr$service;
      this->op_queue_.front_ = (boost::asio::detail::task_io_service_operation *)front->_vptr$service;
      if ( !v2 )
        this->op_queue_.back_ = 0;
      front->_vptr$service = 0;
      if ( front != (boost::asio::detail::task_io_service_0 *)&this->task_operation_ )
      {
        type_info = front->key_.type_info_;
        v4 = 0;
        v5 = boost::system::system_category();
        ((void (__fastcall *)(_QWORD, boost::asio::detail::task_io_service_0 *, int *, _QWORD))type_info)(
          0,
          front,
          &v4,
          0);
        v2 = this->op_queue_.front_;
      }
      front = (boost::asio::detail::task_io_service_0 *)v2;
    }
    while ( v2 );
  }
  this->task_ = 0;
}


// Address: 0x2608110 | Name: _ZN5boost4asio6detail15task_io_service25post_immediate_completionEPNS1_25task_io_service_operationEb
void __fastcall boost::asio::detail::task_io_service::post_immediate_completion(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::task_io_service::operation *op,
        bool is_continuation)
{
  unsigned __int64 v3; // rax
  _QWORD *v4; // rax
  boost::asio::detail::task_io_service::operation **v5; // rcx
  boost::asio::detail::task_io_service_operation *back; // rcx
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_back; // rax
  size_t state; // rax
  boost::asio::detail::reactor *task; // rax
  struct epoll_event v10; // [rsp+0h] [rbp-28h] BYREF

  if ( !this->one_thread_ && !is_continuation )
    goto LABEL_10;
  v3 = __readfsqword(0xFFFFFFD8);
  if ( !v3 )
    goto LABEL_10;
  while ( *(boost::asio::detail::task_io_service_0 **)v3 != this )
  {
    v3 = *(_QWORD *)(v3 + 16);
    if ( !v3 )
      goto LABEL_10;
  }
  v4 = *(_QWORD **)(v3 + 8);
  if ( v4 )
  {
    ++v4[3];
    op->next_ = 0;
    v5 = (boost::asio::detail::task_io_service::operation **)v4[2];
    if ( v5 )
    {
      *v5 = op;
      v4[2] = op;
    }
    else
    {
      v4[2] = op;
      v4[1] = op;
    }
  }
  else
  {
LABEL_10:
    _InterlockedAdd64(&this->outstanding_work_.__a_, 1u);
    pthread_mutex_lock(&this->mutex_.mutex_);
    op->next_ = 0;
    back = this->op_queue_.back_;
    if ( back )
    {
      p_back = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&this->op_queue_.back_;
      back->next_ = op;
    }
    else
    {
      p_back = &this->op_queue_;
      this->op_queue_.back_ = op;
    }
    p_back->front_ = op;
    state = this->wakeup_event_.state_;
    this->wakeup_event_.state_ = state | 1;
    if ( state < 2 )
    {
      if ( !this->task_interrupted_ )
      {
        task = this->task_;
        if ( task )
        {
          this->task_interrupted_ = 1;
          v10.events = -2147483639;
          v10.data.u64 = (uint64_t)&task->interrupter_;
          epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, &v10);
        }
      }
      pthread_mutex_unlock(&this->mutex_.mutex_);
    }
    else
    {
      pthread_mutex_unlock(&this->mutex_.mutex_);
      pthread_cond_signal(&this->wakeup_event_.cond_);
    }
  }
}


// Address: 0x261ecf0 | Name: _ZN5boost4asio6detail15task_io_service3runERNS_6system10error_codeE
size_t __fastcall boost::asio::detail::task_io_service::run(
        boost::asio::detail::task_io_service_0 *this,
        boost::system::error_code *ec)
{
  const boost::system::error_category *v2; // rax
  size_t v3; // rbp
  boost::asio::detail::task_io_service_operation *i; // rbx
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r15
  boost::asio::detail::reactor *task; // rax
  boost::asio::detail::posix_mutex::scoped_lock mutex; // [rsp+0h] [rbp-78h] BYREF
  boost::asio::detail::task_io_service::thread_info this_thread; // [rsp+10h] [rbp-68h] BYREF
  boost::asio::detail::task_io_service_0 *v10; // [rsp+30h] [rbp-48h] BYREF
  void *p_this_thread; // [rsp+38h] [rbp-40h]
  unsigned __int64 v12; // [rsp+40h] [rbp-38h]

  v2 = boost::system::system_category();
  ec->m_val = 0;
  ec->m_cat = v2;
  if ( this->outstanding_work_.__a_ )
  {
    memset(&this_thread, 0, sizeof(this_thread));
    v10 = this;
    p_this_thread = &this_thread;
    v12 = __readfsqword(0xFFFFFFD8);
    __writefsqword(0xFFFFFFD8, (unsigned __int64)&v10);
    mutex.mutex_ = &this->mutex_;
    pthread_mutex_lock(&this->mutex_.mutex_);
    v3 = 0;
LABEL_3:
    mutex.locked_ = 1;
    while ( boost::asio::detail::task_io_service::do_run_one(this, &mutex, &this_thread, ec) )
    {
      if ( v3 != -1 )
        ++v3;
      if ( !mutex.locked_ )
      {
        pthread_mutex_lock(&mutex.mutex_->mutex_);
        goto LABEL_3;
      }
    }
    if ( mutex.locked_ )
      pthread_mutex_unlock(&mutex.mutex_->mutex_);
    __writefsqword(0xFFFFFFD8, v12);
    for ( i = this_thread.private_op_queue.front_;
          this_thread.private_op_queue.front_;
          i = this_thread.private_op_queue.front_ )
    {
      this_thread.private_op_queue.front_ = i->next_;
      if ( !this_thread.private_op_queue.front_ )
        this_thread.private_op_queue.back_ = 0;
      i->next_ = 0;
      func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
      LODWORD(v10) = 0;
      p_this_thread = (void *)boost::system::system_category();
      func(0, i, &v10, 0);
    }
    if ( this_thread.reusable_memory_ )
      operator delete(this_thread.reusable_memory_);
  }
  else
  {
    pthread_mutex_lock(&this->mutex_.mutex_);
    this->stopped_ = 1;
    LOBYTE(this->wakeup_event_.state_) |= 1u;
    pthread_cond_broadcast(&this->wakeup_event_.cond_);
    if ( !this->task_interrupted_ )
    {
      task = this->task_;
      if ( task )
      {
        this->task_interrupted_ = 1;
        LODWORD(this_thread.reusable_memory_) = -2147483639;
        *(void **)((char *)&this_thread.reusable_memory_ + 4) = &task->interrupter_;
        epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, (struct epoll_event *)&this_thread);
      }
    }
    pthread_mutex_unlock(&this->mutex_.mutex_);
    return 0;
  }
  return v3;
}


// Address: 0x261ef70 | Name: _ZN5boost4asio6detail15task_io_service10do_run_oneERNS1_11scoped_lockINS1_11posix_mutexEEERNS1_27task_io_service_thread_infoERKNS_6system10error_codeE
size_t __fastcall boost::asio::detail::task_io_service::do_run_one(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::posix_mutex::scoped_lock *lock,
        boost::asio::detail::task_io_service::thread_info *this_thread,
        const boost::system::error_code *ec)
{
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_op_queue; // rax
  boost::asio::detail::event *p_wakeup_event; // rbp
  boost::asio::detail::task_io_service::task_operation *p_task_operation; // r13
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_private_op_queue; // rcx
  size_t state; // r12
  boost::asio::detail::task_io_service_operation *front; // r12
  boost::asio::detail::task_io_service_operation *next; // r14
  signed __int64 private_outstanding_work; // rax
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *v12; // rdx
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *v13; // rcx
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *v14; // rcx
  size_t v15; // rax
  size_t task_result; // r13
  boost::asio::detail::task_io_service::thread_info *v18; // r14
  const boost::system::error_code *v19; // rbp
  size_t v20; // rax
  boost::asio::detail::reactor *task; // rax
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *v22; // [rsp+8h] [rbp-70h]
  boost::asio::detail::task_io_service_operation **p_back; // [rsp+18h] [rbp-60h]
  boost::asio::detail::task_io_service::work_cleanup v26; // [rsp+30h] [rbp-48h] BYREF

  if ( this->stopped_ )
    return 0;
  p_op_queue = &this->op_queue_;
  p_wakeup_event = &this->wakeup_event_;
  p_task_operation = &this->task_operation_;
  p_private_op_queue = &this_thread->private_op_queue;
  v22 = &this_thread->private_op_queue;
  p_back = &this->op_queue_.back_;
  while ( 1 )
  {
    front = p_op_queue->front_;
    if ( p_op_queue->front_ )
      break;
    v15 = this->wakeup_event_.state_ & 0xFFFFFFFFFFFFFFFELL;
    this->wakeup_event_.state_ = v15;
    do
    {
      this->wakeup_event_.state_ = v15 + 2;
      pthread_cond_wait(&p_wakeup_event->cond_, &lock->mutex_->mutex_);
      v15 = this->wakeup_event_.state_ - 2;
      this->wakeup_event_.state_ = v15;
    }
    while ( (v15 & 1) == 0 );
LABEL_30:
    p_op_queue = &this->op_queue_;
    p_private_op_queue = v22;
    if ( this->stopped_ )
      return 0;
  }
  next = front->next_;
  p_op_queue->front_ = front->next_;
  if ( !next )
    *p_back = 0;
  front->next_ = 0;
  if ( front == p_task_operation )
  {
    this->task_interrupted_ = next != 0;
    if ( next && !this->one_thread_ )
    {
      state = this->wakeup_event_.state_;
      this->wakeup_event_.state_ = state | 1;
      if ( lock->locked_ )
      {
        pthread_mutex_unlock(&lock->mutex_->mutex_);
        p_private_op_queue = v22;
        lock->locked_ = 0;
      }
      if ( state >= 2 )
      {
        pthread_cond_signal(&p_wakeup_event->cond_);
        p_private_op_queue = v22;
      }
    }
    else if ( lock->locked_ )
    {
      pthread_mutex_unlock(&lock->mutex_->mutex_);
      p_private_op_queue = v22;
      lock->locked_ = 0;
    }
    boost::asio::detail::epoll_reactor::run(this->task_, next == 0, p_private_op_queue);
    private_outstanding_work = this_thread->private_outstanding_work;
    if ( private_outstanding_work > 0 )
      _InterlockedAdd64(&this->outstanding_work_.__a_, private_outstanding_work);
    this_thread->private_outstanding_work = 0;
    v12 = v22;
    if ( !lock->locked_ )
    {
      pthread_mutex_lock(&lock->mutex_->mutex_);
      v12 = v22;
      lock->locked_ = 1;
    }
    this->task_interrupted_ = 1;
    if ( v12->front_ )
    {
      v13 = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)*p_back;
      if ( !*p_back )
        v13 = &this->op_queue_;
      v13->front_ = v12->front_;
      *p_back = this_thread->private_op_queue.back_;
      *v12 = 0;
    }
    p_task_operation->next_ = 0;
    if ( *p_back )
    {
      (*p_back)->next_ = p_task_operation;
      v14 = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&this->op_queue_.back_;
    }
    else
    {
      *p_back = p_task_operation;
      v14 = &this->op_queue_;
    }
    v14->front_ = p_task_operation;
    goto LABEL_30;
  }
  task_result = front->task_result_;
  if ( next && !this->one_thread_ )
  {
    v20 = this->wakeup_event_.state_;
    this->wakeup_event_.state_ = v20 | 1;
    v18 = this_thread;
    if ( v20 < 2 )
    {
      v19 = ec;
      if ( !this->task_interrupted_ )
      {
        task = this->task_;
        if ( task )
        {
          this->task_interrupted_ = 1;
          LODWORD(v26.task_io_service_) = -2147483639;
          *(boost::asio::detail::task_io_service **)((char *)&v26.task_io_service_ + 4) = (boost::asio::detail::task_io_service *)&task->interrupter_;
          epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, (struct epoll_event *)&v26);
        }
      }
      if ( lock->locked_ )
      {
LABEL_35:
        pthread_mutex_unlock(&lock->mutex_->mutex_);
        lock->locked_ = 0;
      }
    }
    else
    {
      if ( lock->locked_ )
      {
        pthread_mutex_unlock(&lock->mutex_->mutex_);
        lock->locked_ = 0;
      }
      pthread_cond_signal(&p_wakeup_event->cond_);
      v19 = ec;
    }
  }
  else
  {
    v18 = this_thread;
    v19 = ec;
    if ( lock->locked_ )
      goto LABEL_35;
  }
  v26.task_io_service_ = this;
  v26.lock_ = lock;
  v26.this_thread_ = v18;
  front->func_(this, front, v19, task_result);
  boost::asio::detail::task_io_service::work_cleanup::~work_cleanup(&v26);
  return 1;
}


// Address: 0x261f5c0 | Name: _ZN5boost4asio6detail15task_io_service12work_cleanupD2Ev
void __fastcall boost::asio::detail::task_io_service::work_cleanup::~work_cleanup(
        boost::asio::detail::task_io_service::work_cleanup *this)
{
  __int64 private_outstanding_work; // rax
  boost::asio::detail::task_io_service *task_io_service; // r15
  boost::asio::detail::reactor *task; // rax
  boost::asio::detail::task_io_service::thread_info *this_thread; // rax
  boost::asio::detail::posix_mutex::scoped_lock *lock; // rbx
  boost::asio::detail::task_io_service_operation *front; // rcx
  boost::asio::detail::task_io_service *v7; // rdx
  _QWORD *p_front; // rsi
  struct epoll_event event; // [rsp+8h] [rbp-30h] BYREF

  private_outstanding_work = this->this_thread_->private_outstanding_work;
  if ( private_outstanding_work < 2 )
  {
    if ( private_outstanding_work != 1 )
    {
      task_io_service = this->task_io_service_;
      if ( !_InterlockedSub64(&this->task_io_service_->outstanding_work_.__a_, 1u) )
      {
        pthread_mutex_lock(&task_io_service->mutex_.mutex_);
        task_io_service->stopped_ = 1;
        LOBYTE(task_io_service->wakeup_event_.state_) |= 1u;
        pthread_cond_broadcast(&task_io_service->wakeup_event_.cond_);
        if ( !task_io_service->task_interrupted_ )
        {
          task = task_io_service->task_;
          if ( task )
          {
            task_io_service->task_interrupted_ = 1;
            event.events = -2147483639;
            event.data.u64 = (uint64_t)&task->interrupter_;
            epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, &event);
          }
        }
        pthread_mutex_unlock(&task_io_service->mutex_.mutex_);
      }
    }
  }
  else
  {
    _InterlockedAdd64(&this->task_io_service_->outstanding_work_.__a_, private_outstanding_work - 1);
  }
  this_thread = this->this_thread_;
  this_thread->private_outstanding_work = 0;
  if ( this_thread->private_op_queue.front_ )
  {
    lock = this->lock_;
    if ( !lock->locked_ )
    {
      pthread_mutex_lock(&lock->mutex_->mutex_);
      lock->locked_ = 1;
      this_thread = this->this_thread_;
    }
    front = this_thread->private_op_queue.front_;
    if ( front )
    {
      v7 = this->task_io_service_;
      p_front = &this->task_io_service_->op_queue_.front_;
      if ( this->task_io_service_->op_queue_.back_ )
        p_front = &this->task_io_service_->op_queue_.back_->next_;
      *p_front = front;
      v7->op_queue_.back_ = this_thread->private_op_queue.back_;
      this_thread->private_op_queue = 0;
    }
  }
}


// Address: 0x2620960 | Name: _ZN5boost4asio6detail15task_io_service24post_deferred_completionEPNS1_25task_io_service_operationE
void __fastcall boost::asio::detail::task_io_service::post_deferred_completion(
        boost::asio::detail::task_io_service_0 *this,
        boost::asio::detail::task_io_service::operation *op)
{
  unsigned __int64 v2; // rax
  __int64 v3; // rax
  boost::asio::detail::task_io_service::operation **v4; // rcx
  boost::asio::detail::task_io_service_operation *back; // rcx
  boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *p_back; // rax
  size_t state; // rax
  boost::asio::detail::reactor *task; // rax
  struct epoll_event v9; // [rsp+0h] [rbp-28h] BYREF

  if ( !this->one_thread_ )
    goto LABEL_9;
  v2 = __readfsqword(0xFFFFFFD8);
  if ( !v2 )
    goto LABEL_9;
  while ( *(boost::asio::detail::task_io_service_0 **)v2 != this )
  {
    v2 = *(_QWORD *)(v2 + 16);
    if ( !v2 )
      goto LABEL_9;
  }
  v3 = *(_QWORD *)(v2 + 8);
  if ( v3 )
  {
    op->next_ = 0;
    v4 = *(boost::asio::detail::task_io_service::operation ***)(v3 + 16);
    if ( v4 )
    {
      *v4 = op;
      *(_QWORD *)(v3 + 16) = op;
    }
    else
    {
      *(_QWORD *)(v3 + 16) = op;
      *(_QWORD *)(v3 + 8) = op;
    }
  }
  else
  {
LABEL_9:
    pthread_mutex_lock(&this->mutex_.mutex_);
    op->next_ = 0;
    back = this->op_queue_.back_;
    if ( back )
    {
      p_back = (boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *)&this->op_queue_.back_;
      back->next_ = op;
    }
    else
    {
      p_back = &this->op_queue_;
      this->op_queue_.back_ = op;
    }
    p_back->front_ = op;
    state = this->wakeup_event_.state_;
    this->wakeup_event_.state_ = state | 1;
    if ( state < 2 )
    {
      if ( !this->task_interrupted_ )
      {
        task = this->task_;
        if ( task )
        {
          this->task_interrupted_ = 1;
          v9.events = -2147483639;
          v9.data.u64 = (uint64_t)&task->interrupter_;
          epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, &v9);
        }
      }
      pthread_mutex_unlock(&this->mutex_.mutex_);
    }
    else
    {
      pthread_mutex_unlock(&this->mutex_.mutex_);
      pthread_cond_signal(&this->wakeup_event_.cond_);
    }
  }
}


