// Address: 0xfe94b0 | Name: _ZN5boost9gregorian16bad_day_of_monthD0Ev
void __fastcall boost::gregorian::bad_day_of_month::~bad_day_of_month(boost::gregorian::bad_day_of_month *this)
{
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


