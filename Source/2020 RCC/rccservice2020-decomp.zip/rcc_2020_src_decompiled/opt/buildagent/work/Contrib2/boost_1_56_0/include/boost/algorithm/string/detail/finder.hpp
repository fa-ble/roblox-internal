// Address: 0xfec6b0 | Name: _ZNK5boost9algorithm6detail13token_finderFINS1_10is_any_ofFIcEEEclINSt3__111__wrap_iterIPKcEEEENS_14iterator_rangeIT_EESD_SD_
std::__wrap_iter<const char *>::iterator_type __fastcall boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>::operator()<std::__wrap_iter<char const*>>(
        const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *this,
        std::__wrap_iter<const char *> Begin,
        std::__wrap_iter<const char *> End)
{
  size_t m_Size; // r12
  void *v7; // rdi
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  void **v9; // r10
  void **v10; // r9
  char v11; // dl
  void **v12; // rcx
  void **v13; // rdi
  signed __int64 v14; // rcx
  void **v15; // rsi
  __int64 v16; // rax
  size_t v17; // r10
  std::__wrap_iter<const char *>::iterator_type i; // r11
  char v19; // dl
  boost::algorithm::detail::is_any_ofF<char>::set_value_type *v20; // r9
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *v21; // rsi
  signed __int64 v22; // rdi
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *v23; // rcx
  __int64 v24; // rax
  void *ptr[2]; // [rsp+8h] [rbp-40h] BYREF
  unsigned __int64 v27; // [rsp+18h] [rbp-30h]
  unsigned __int64 v28; // [rsp+20h] [rbp-28h]

  v28 = __readfsqword(0x28u);
  m_Size = this->m_Pred.m_Size;
  v27 = m_Size;
  ptr[0] = 0;
  if ( m_Size > 0x10 )
  {
    v7 = operator new[](m_Size);
    ptr[0] = v7;
    m_dynSet = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)this->m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    v7 = ptr;
    m_dynSet = this;
  }
  memcpy(v7, m_dynSet, m_Size);
  if ( Begin.__i != End.__i )
  {
    v9 = (void **)ptr[0];
    v10 = (void **)((char *)ptr[0] + v27);
    if ( v27 <= 0x10 )
    {
      v10 = (void **)((char *)ptr + v27);
      v9 = ptr;
    }
    while ( 1 )
    {
      v11 = *Begin.__i;
      v12 = (void **)((char *)ptr + v27);
      v13 = ptr;
      if ( v27 )
      {
        v13 = v9;
        v14 = v27;
        do
        {
          v15 = v13;
          v16 = v14 + ~(v14 / 2);
          if ( *((char *)v13 + v14 / 2) >= v11 )
            v16 = v14 / 2;
          v13 = (void **)((char *)v13 + v14 / 2 + 1);
          if ( *((char *)v15 + v14 / 2) >= v11 )
            v13 = v15;
          v14 = v16;
        }
        while ( v16 );
        v12 = v10;
      }
      if ( v13 != v12 && *(char *)v13 <= v11 )
        break;
      if ( ++Begin.__i == End.__i )
      {
        Begin.__i = End.__i;
        break;
      }
    }
  }
  if ( v27 >= 0x11 && ptr[0] )
    operator delete[](ptr[0]);
  if ( Begin.__i != End.__i )
  {
    if ( this->m_eCompress )
      return Begin.__i;
    v17 = this->m_Pred.m_Size;
    i = Begin.__i;
    while ( 1 )
    {
      v19 = *i;
      if ( v17 >= 0x11 )
        break;
      v20 = (char *)this + v17;
      v21 = this;
      if ( v17 )
        goto LABEL_31;
LABEL_37:
      if ( v21 != (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)v20
        && v21->m_Pred.m_Storage.m_fixSet[0] <= v19
        && ++i != End.__i )
      {
        continue;
      }
      return Begin.__i;
    }
    v21 = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)this->m_Pred.m_Storage.m_dynSet;
    v20 = &this->m_Pred.m_Storage.m_dynSet[v17];
LABEL_31:
    v22 = this->m_Pred.m_Size;
    do
    {
      v23 = v21;
      v24 = v22 + ~(v22 / 2);
      if ( v21->m_Pred.m_Storage.m_fixSet[v22 / 2] >= v19 )
        v24 = v22 / 2;
      v21 = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)((char *)v21 + v22 / 2 + 1);
      if ( v23->m_Pred.m_Storage.m_fixSet[v22 / 2] >= v19 )
        v21 = v23;
      v22 = v24;
    }
    while ( v24 );
    goto LABEL_37;
  }
  return End.__i;
}


// Address: 0x1019850 | Name: _ZNK5boost9algorithm6detail13token_finderFINS1_10is_any_ofFIcEEEclINSt3__111__wrap_iterIPcEEEENS_14iterator_rangeIT_EESC_SC_
std::__wrap_iter<char *>::iterator_type __fastcall boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>::operator()<std::__wrap_iter<char *>>(
        const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *this,
        std::__wrap_iter<char *> Begin,
        std::__wrap_iter<char *> End)
{
  size_t m_Size; // r12
  void *v7; // rdi
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  void **v9; // r10
  void **v10; // r9
  char v11; // dl
  void **v12; // rcx
  void **v13; // rdi
  signed __int64 v14; // rcx
  void **v15; // rsi
  __int64 v16; // rax
  size_t v17; // r10
  std::__wrap_iter<char *>::iterator_type i; // r11
  char v19; // dl
  boost::algorithm::detail::is_any_ofF<char>::set_value_type *v20; // r9
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *v21; // rsi
  signed __int64 v22; // rdi
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *v23; // rcx
  __int64 v24; // rax
  void *ptr[2]; // [rsp+8h] [rbp-40h] BYREF
  unsigned __int64 v27; // [rsp+18h] [rbp-30h]
  unsigned __int64 v28; // [rsp+20h] [rbp-28h]

  v28 = __readfsqword(0x28u);
  m_Size = this->m_Pred.m_Size;
  v27 = m_Size;
  ptr[0] = 0;
  if ( m_Size > 0x10 )
  {
    v7 = operator new[](m_Size);
    ptr[0] = v7;
    m_dynSet = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)this->m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    v7 = ptr;
    m_dynSet = this;
  }
  memcpy(v7, m_dynSet, m_Size);
  if ( Begin.__i != End.__i )
  {
    v9 = (void **)ptr[0];
    v10 = (void **)((char *)ptr[0] + v27);
    if ( v27 <= 0x10 )
    {
      v10 = (void **)((char *)ptr + v27);
      v9 = ptr;
    }
    while ( 1 )
    {
      v11 = *Begin.__i;
      v12 = (void **)((char *)ptr + v27);
      v13 = ptr;
      if ( v27 )
      {
        v13 = v9;
        v14 = v27;
        do
        {
          v15 = v13;
          v16 = v14 + ~(v14 / 2);
          if ( *((char *)v13 + v14 / 2) >= v11 )
            v16 = v14 / 2;
          v13 = (void **)((char *)v13 + v14 / 2 + 1);
          if ( *((char *)v15 + v14 / 2) >= v11 )
            v13 = v15;
          v14 = v16;
        }
        while ( v16 );
        v12 = v10;
      }
      if ( v13 != v12 && *(char *)v13 <= v11 )
        break;
      if ( ++Begin.__i == End.__i )
      {
        Begin.__i = End.__i;
        break;
      }
    }
  }
  if ( v27 >= 0x11 && ptr[0] )
    operator delete[](ptr[0]);
  if ( Begin.__i != End.__i )
  {
    if ( this->m_eCompress )
      return Begin.__i;
    v17 = this->m_Pred.m_Size;
    i = Begin.__i;
    while ( 1 )
    {
      v19 = *i;
      if ( v17 >= 0x11 )
        break;
      v20 = (char *)this + v17;
      v21 = this;
      if ( v17 )
        goto LABEL_31;
LABEL_37:
      if ( v21 != (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)v20
        && v21->m_Pred.m_Storage.m_fixSet[0] <= v19
        && ++i != End.__i )
      {
        continue;
      }
      return Begin.__i;
    }
    v21 = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)this->m_Pred.m_Storage.m_dynSet;
    v20 = &this->m_Pred.m_Storage.m_dynSet[v17];
LABEL_31:
    v22 = this->m_Pred.m_Size;
    do
    {
      v23 = v21;
      v24 = v22 + ~(v22 / 2);
      if ( v21->m_Pred.m_Storage.m_fixSet[v22 / 2] >= v19 )
        v24 = v22 / 2;
      v21 = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)((char *)v21 + v22 / 2 + 1);
      if ( v23->m_Pred.m_Storage.m_fixSet[v22 / 2] >= v19 )
        v21 = v23;
      v22 = v24;
    }
    while ( v24 );
    goto LABEL_37;
  }
  return End.__i;
}


// Address: 0x1110850 | Name: _ZNK5boost9algorithm6detail13token_finderFINS1_10is_any_ofFIcEEEclIPKcEENS_14iterator_rangeIT_EESA_SA_
boost::iterator_range<const char *> __fastcall boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>::operator()<char const*>(
        const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *this,
        const char *Begin,
        const char *End)
{
  size_t m_Size; // r12
  void *v7; // rdi
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  void **v9; // r10
  void **v10; // r9
  char v11; // dl
  void **v12; // rcx
  void **v13; // rdi
  signed __int64 v14; // rcx
  void **v15; // rsi
  __int64 v16; // rax
  size_t v17; // r10
  const char *v18; // r11
  char v19; // dl
  boost::algorithm::detail::is_any_ofF<char>::set_value_type *v20; // r9
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *v21; // rsi
  signed __int64 v22; // rdi
  const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *v23; // rcx
  __int64 v24; // rax
  boost::iterator_range<const char *> result; // rax
  void *ptr[2]; // [rsp+8h] [rbp-40h] BYREF
  unsigned __int64 v27; // [rsp+18h] [rbp-30h]
  unsigned __int64 v28; // [rsp+20h] [rbp-28h]

  v28 = __readfsqword(0x28u);
  m_Size = this->m_Pred.m_Size;
  v27 = m_Size;
  ptr[0] = 0;
  if ( m_Size > 0x10 )
  {
    v7 = operator new[](m_Size);
    ptr[0] = v7;
    m_dynSet = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)this->m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    v7 = ptr;
    m_dynSet = this;
  }
  memcpy(v7, m_dynSet, m_Size);
  if ( Begin != End )
  {
    v9 = (void **)ptr[0];
    v10 = (void **)((char *)ptr[0] + v27);
    if ( v27 <= 0x10 )
    {
      v10 = (void **)((char *)ptr + v27);
      v9 = ptr;
    }
    while ( 1 )
    {
      v11 = *Begin;
      v12 = (void **)((char *)ptr + v27);
      v13 = ptr;
      if ( v27 )
      {
        v13 = v9;
        v14 = v27;
        do
        {
          v15 = v13;
          v16 = v14 + ~(v14 / 2);
          if ( *((char *)v13 + v14 / 2) >= v11 )
            v16 = v14 / 2;
          v13 = (void **)((char *)v13 + v14 / 2 + 1);
          if ( *((char *)v15 + v14 / 2) >= v11 )
            v13 = v15;
          v14 = v16;
        }
        while ( v16 );
        v12 = v10;
      }
      if ( v13 != v12 && *(char *)v13 <= v11 )
        break;
      if ( ++Begin == End )
      {
        Begin = End;
        break;
      }
    }
  }
  if ( v27 >= 0x11 && ptr[0] )
    operator delete[](ptr[0]);
  if ( Begin == End )
  {
    Begin = End;
    goto LABEL_42;
  }
  if ( this->m_eCompress == boost::algorithm::token_compress_mode_type::token_compress_on )
  {
    v17 = this->m_Pred.m_Size;
    v18 = Begin;
    while ( 1 )
    {
      v19 = *v18;
      if ( v17 >= 0x11 )
      {
        v21 = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)this->m_Pred.m_Storage.m_dynSet;
        v20 = &this->m_Pred.m_Storage.m_dynSet[v17];
      }
      else
      {
        v20 = (char *)this + v17;
        v21 = this;
        if ( !v17 )
          goto LABEL_37;
      }
      v22 = this->m_Pred.m_Size;
      do
      {
        v23 = v21;
        v24 = v22 + ~(v22 / 2);
        if ( v21->m_Pred.m_Storage.m_fixSet[v22 / 2] >= v19 )
          v24 = v22 / 2;
        v21 = (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)((char *)v21 + v22 / 2 + 1);
        if ( v23->m_Pred.m_Storage.m_fixSet[v22 / 2] >= v19 )
          v21 = v23;
        v22 = v24;
      }
      while ( v24 );
LABEL_37:
      if ( v21 == (const boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)v20
        || v21->m_Pred.m_Storage.m_fixSet[0] > v19 )
      {
        End = v18;
        goto LABEL_42;
      }
      if ( ++v18 == End )
        goto LABEL_42;
    }
  }
  End = Begin + 1;
LABEL_42:
  result.m_Begin = Begin;
  result.m_End = End;
  return result;
}


// Address: 0x275b1a0 | Name: _ZN5boost6detail8function21function_obj_invoker2INS_9algorithm6detail13token_finderFINS4_14is_from_rangeFIcEEEENS_14iterator_rangeINSt3__111__wrap_iterIPKcEEEESE_SE_E6invokeERNS1_15function_bufferESE_SE_
std::__wrap_iter<const char *>::iterator_type __fastcall boost::detail::function::function_obj_invoker2<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_from_rangeF<char>>,boost::iterator_range<std::__wrap_iter<char const*>>,std::__wrap_iter<char const*>,std::__wrap_iter<char const*>>::invoke(
        boost::detail::function::function_buffer *function_obj_ptr,
        std::__wrap_iter<const char *> a0,
        std::__wrap_iter<const char *> a1)
{
  int obj_ptr; // r9d
  char v5; // di
  std::__wrap_iter<const char *>::iterator_type i; // rcx

  obj_ptr = (int)function_obj_ptr->obj_ptr;
  if ( a0.__i != a1.__i )
  {
    while ( *a0.__i < (char)obj_ptr || *a0.__i > SBYTE1(obj_ptr) )
    {
      if ( a1.__i == ++a0.__i )
        return a1.__i;
    }
  }
  if ( a0.__i == a1.__i )
    return a1.__i;
  if ( HIDWORD(function_obj_ptr->bound_memfunc_ptr.memfunc_ptr) )
    return a0.__i;
  v5 = BYTE1(function_obj_ptr->obj_ptr);
  i = a0.__i;
  while ( 1 )
  {
    if ( *i < (char)obj_ptr )
      return a0.__i;
    if ( v5 < *i )
      break;
    if ( a1.__i == ++i )
      return a0.__i;
  }
  return a0.__i;
}


