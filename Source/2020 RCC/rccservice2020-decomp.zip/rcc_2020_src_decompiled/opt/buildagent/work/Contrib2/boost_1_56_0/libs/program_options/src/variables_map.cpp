// Address: 0xe69330 | Name: _ZN5boost15program_options5storeERKNS0_20basic_parsed_optionsIcEERNS0_13variables_mapEb
void __fastcall boost::program_options::store(
        const boost::program_options::parsed_options *options,
        boost::program_options::variables_map *xm,
        bool utf8)
{
  unsigned __int64 v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  __int64 *v6; // r15
  const boost::program_options::options_description *v7; // r13
  __int64 v8; // rsi
  bool v9; // zf
  unsigned int v10; // r12d
  unsigned __int64 v11; // rax
  __int64 v12; // rbp
  int v13; // edx
  void *v14; // rcx
  size_t v15; // r8
  const void *v16; // r9
  __int128 *v17; // rsi
  __int64 v18; // rsi
  std::pair<std::__tree_iterator<std::__value_type<std::string,boost::program_options::variable_value>,std::__tree_node<std::__value_type<std::string,boost::program_options::variable_value>,void *> *,long>,bool> v19; // rax
  std::__tree_iterator<std::__value_type<std::string,boost::program_options::variable_value>,std::__tree_node<std::__value_type<std::string,boost::program_options::variable_value>,void *> *,long>::__iter_pointer v20; // r13
  std::__tree_iterator<std::__value_type<std::string,boost::program_options::variable_value>,std::__tree_node<std::__value_type<std::string,boost::program_options::variable_value>,void *> *,long>::__iter_pointer v21; // r15
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer left; // rdi
  volatile signed __int32 *v23; // rbx
  volatile signed __int32 *v24; // rbx
  __int128 v25; // xmm0
  volatile signed __int32 *v26; // rbx
  volatile signed __int32 *v27; // rbx
  char v28; // bl
  volatile signed __int32 *v29; // rbp
  std::__tree<std::string>::__iter_pointer begin_node; // rbp
  std::__tree<std::string> *v31; // r12
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *v32; // rbx
  _QWORD *p_left; // rcx
  std::__tree<std::string> *v34; // rax
  __int64 v35; // rbp
  const std::vector<boost::shared_ptr<boost::program_options::option_description>> *v36; // r13
  __int64 v37; // rax
  unsigned int v38; // r12d
  unsigned __int64 v39; // rcx
  const boost::program_options::option_description *v40; // r14
  const std::string *v41; // rax
  char v42; // bl
  volatile signed __int32 *v43; // rbp
  std::__tree_node_base<void *> *v44; // rbp
  std::pair<std::__tree_iterator<std::__value_type<std::string,boost::program_options::variable_value>,std::__tree_node<std::__value_type<std::string,boost::program_options::variable_value>,void *> *,long>,bool> v45; // rax
  std::__tree_iterator<std::__value_type<std::string,boost::program_options::variable_value>,std::__tree_node<std::__value_type<std::string,boost::program_options::variable_value>,void *> *,long>::__iter_pointer v46; // r15
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v47; // rdi
  volatile signed __int32 *v48; // rbx
  std::pair<std::__tree_iterator<std::__value_type<std::string,boost::program_options::variable_value>,std::__tree_node<std::__value_type<std::string,boost::program_options::variable_value>,void *> *,long>,bool> v49; // rax
  __int128 v50; // xmm0
  volatile signed __int32 *v51; // rbx
  volatile signed __int32 *v52; // rbx
  char v53; // bl
  volatile signed __int32 *v54; // rbp
  unsigned __int64 v55; // rbx
  std::__tree_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>::__iter_pointer v56; // rax
  unsigned __int64 left_low; // rcx
  std::pair<std::__tree_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>,bool> v58; // rax
  void *v59; // rcx
  size_t v60; // r8
  const void *v61; // r9
  __int128 v62; // [rsp+0h] [rbp-F8h] BYREF
  void *v63; // [rsp+10h] [rbp-E8h]
  std::tuple<> v64; // [rsp+18h] [rbp-E0h] BYREF
  std::tuple<> __args[8]; // [rsp+20h] [rbp-D8h] BYREF
  std::tuple<> v66[8]; // [rsp+28h] [rbp-D0h] BYREF
  __int128 v67; // [rsp+30h] [rbp-C8h] BYREF
  void *ptr; // [rsp+40h] [rbp-B8h]
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *v69; // [rsp+48h] [rbp-B0h]
  __int64 *v70; // [rsp+50h] [rbp-A8h]
  std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > > *p_tree; // [rsp+58h] [rbp-A0h]
  boost::program_options::option_description *v72; // [rsp+60h] [rbp-98h]
  _BOOL4 v73; // [rsp+6Ch] [rbp-8Ch]
  __int128 v74; // [rsp+70h] [rbp-88h] BYREF
  void *v75; // [rsp+80h] [rbp-78h]
  std::__tree<std::string> v76; // [rsp+88h] [rbp-70h] BYREF
  __int128 v77; // [rsp+A0h] [rbp-58h] BYREF
  void *v78; // [rsp+B0h] [rbp-48h]
  std::__tree<std::string> *p_pair3; // [rsp+B8h] [rbp-40h]
  const boost::program_options::options_description *v80; // [rsp+C0h] [rbp-38h]

  v73 = utf8;
  v6 = (__int64 *)options;
  v7 = (const boost::program_options::options_description *)*((_QWORD *)options + 3);
  v69 = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)xm;
  p_tree = &xm->__tree_;
  *(_OWORD *)&v76.__pair1_.__value_.__left_ = 0;
  v76.__begin_node_ = &v76.__pair1_.__value_;
  v74 = 0;
  v75 = 0;
  v77 = 0;
  v78 = 0;
  v8 = *(_QWORD *)options;
  v9 = *((_QWORD *)options + 1) == *(_QWORD *)options;
  v70 = (__int64 *)options;
  if ( v9 )
    goto LABEL_52;
  p_pair3 = (std::__tree<std::string> *)&v69[1].__pair3_;
  v10 = 1;
  v11 = 0;
  v80 = v7;
  do
  {
    v12 = 88 * v11;
    std::string::operator=((soap *)&v74, 88 * v11 + v8, utf8, (void *)v3, v4, v5);
    v17 = *(__int128 **)(*v6 + v12 + 56);
    if ( *(__int128 **)(*v6 + v12 + 64) == v17 )
      v17 = &v74;
    std::string::operator=((soap *)&v77, (int)v17, v13, v14, v15, v16);
    if ( (v74 & 1) != 0 )
    {
      if ( !*((_QWORD *)&v74 + 1) )
        goto LABEL_42;
    }
    else if ( !((unsigned __int64)(unsigned __int8)v74 >> 1) )
    {
      goto LABEL_42;
    }
    if ( !*(_BYTE *)(*v6 + v12 + 80)
      && !std::__tree<std::string>::__count_unique<std::string>(p_pair3, (const std::string *)&v74) )
    {
      v18 = *(_QWORD *)(*v6 + v12 + 56);
      if ( *(_QWORD *)(*v6 + v12 + 64) == v18 )
      {
        v67 = 0;
        ptr = 0;
      }
      else
      {
        std::string::basic_string(&v67, v18);
      }
      v72 = boost::program_options::options_description::find(v7, (const std::string *)&v74, 0, 0, 0);
      *(_QWORD *)&v62 = &v74;
      v19 = std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
              p_tree,
              (const std::string *)&v74,
              &stru_499629,
              (std::tuple<const std::string &> *)&v62,
              __args);
      v20 = v19.first.__ptr_;
      v21 = v19.first.__ptr_ + 7;
      if ( LOBYTE(v19.first.__ptr_[8].__left_) )
      {
        left = v21->__left_;
        v21->__left_ = 0;
        if ( left )
          ((void (__fastcall *)(std::__tree_end_node<std::__tree_node_base<void *> *>::pointer, __int128 *, _QWORD))left->__left_->__right_)(
            left,
            &v74,
            *(_QWORD *)&v19.second);
        LOBYTE(v20[8].__left_) = 0;
        v23 = (volatile signed __int32 *)v20[10].__left_;
        *(_OWORD *)&v20[9].__left_ = 0;
        if ( v23 )
        {
          if ( !_InterlockedSub(v23 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *, __int128 *, _QWORD))(*(_QWORD *)v23 + 16LL))(
              v23,
              &v74,
              *(_QWORD *)&v19.second);
            if ( !_InterlockedSub(v23 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 24LL))(v23);
          }
        }
      }
      boost::program_options::option_description::semantic(&v62, v72);
      (*(void (__fastcall **)(_QWORD, std::__tree_iterator<std::__value_type<std::string,boost::program_options::variable_value>,std::__tree_node<std::__value_type<std::string,boost::program_options::variable_value>,void *> *,long>::__iter_pointer, __int64, _BOOL4))(*(_QWORD *)v62 + 40LL))(
        v62,
        v21,
        *v70 + v12 + 32,
        v73);
      v24 = (volatile signed __int32 *)*((_QWORD *)&v62 + 1);
      if ( *((_QWORD *)&v62 + 1) )
      {
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v62 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 16LL))(v24);
          if ( !_InterlockedSub(v24 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 24LL))(v24);
        }
      }
      boost::program_options::option_description::semantic(&v62, v72);
      v25 = v62;
      v62 = 0;
      v26 = (volatile signed __int32 *)v20[10].__left_;
      *(_OWORD *)&v20[9].__left_ = v25;
      if ( v26 )
      {
        if ( !_InterlockedSub(v26 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 16LL))(v26);
          if ( !_InterlockedSub(v26 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 24LL))(v26);
        }
      }
      v27 = (volatile signed __int32 *)*((_QWORD *)&v62 + 1);
      v7 = v80;
      if ( *((_QWORD *)&v62 + 1) )
      {
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v62 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 16LL))(v27);
          if ( !_InterlockedSub(v27 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 24LL))(v27);
        }
      }
      boost::program_options::option_description::semantic(&v62, v72);
      v28 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)v62 + 24LL))(v62);
      v29 = (volatile signed __int32 *)*((_QWORD *)&v62 + 1);
      if ( *((_QWORD *)&v62 + 1) )
      {
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v62 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v29 + 16LL))(v29);
          if ( !_InterlockedSub(v29 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v29 + 24LL))(v29);
        }
      }
      if ( !v28 )
        std::__tree<std::string>::__emplace_unique_key_args<std::string,std::string const&>(
          &v76,
          (const std::string *)&v74,
          (const std::string *)&v74);
      if ( (v67 & 1) != 0 )
        operator delete(ptr);
      v6 = v70;
    }
LABEL_42:
    v11 = v10;
    v8 = *v6;
    *(_DWORD *)&utf8 = -1171354717;
    v3 = 0x2E8BA2E8BA2E8BA3LL * ((v6[1] - *v6) >> 3);
    ++v10;
  }
  while ( v3 > v11 );
  begin_node = v76.__begin_node_;
  v31 = p_pair3;
  if ( (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)v76.__begin_node_ != &v76.__pair1_ )
  {
    v32 = v69 + 2;
    do
    {
      std::__tree<std::string>::__emplace_hint_unique_key_args<std::string,std::string const&>(
        v31,
        (std::__tree<std::string>::const_iterator)v32,
        (const std::string *)&begin_node[4],
        (const std::string *)&begin_node[4]);
      p_left = &begin_node[1].__left_->__left_;
      if ( p_left )
      {
        do
        {
          v34 = (std::__tree<std::string> *)p_left;
          p_left = (_QWORD *)*p_left;
        }
        while ( p_left );
      }
      else
      {
        v34 = (std::__tree<std::string> *)begin_node[2].__left_;
        if ( v34->__begin_node_ != begin_node )
        {
          v35 = (__int64)&begin_node[2];
          do
          {
            v34 = *(std::__tree<std::string> **)(*(_QWORD *)v35 + 16LL);
            v9 = v34->__begin_node_ == *(std::__tree<std::string>::__iter_pointer *)v35;
            v35 = *(_QWORD *)v35 + 16LL;
          }
          while ( !v9 );
        }
      }
      begin_node = (std::__tree<std::string>::__iter_pointer)v34;
    }
    while ( v34 != (std::__tree<std::string> *)&v76.__pair1_ );
  }
LABEL_52:
  v36 = boost::program_options::options_description::options(v7);
  v37 = *(_QWORD *)v36;
  if ( *((_QWORD *)v36 + 1) != *(_QWORD *)v36 )
  {
    v69 = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)((char *)v69 + 64);
    v38 = 1;
    v39 = 0;
    do
    {
      v40 = *(const boost::program_options::option_description **)(v37 + 16 * v39);
      v62 = 0;
      v63 = 0;
      v41 = boost::program_options::option_description::key(v40, (const std::string *)&v62);
      std::string::basic_string(&v67, v41);
      if ( (v62 & 1) != 0 )
        operator delete(v63);
      if ( (v67 & 1) != 0 )
      {
        if ( *((_QWORD *)&v67 + 1) )
          goto LABEL_60;
      }
      else if ( (unsigned __int64)(unsigned __int8)v67 >> 1 )
      {
LABEL_60:
        if ( !std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::__count_unique<std::string>(
                p_tree,
                (const std::string *)&v67) )
        {
          *(_QWORD *)&v66[0].gap0 = 0;
          boost::program_options::option_description::semantic(&v62, v40);
          v42 = (*(__int64 (__fastcall **)(_QWORD, std::tuple<> *))(*(_QWORD *)v62 + 48LL))(v62, v66);
          v43 = (volatile signed __int32 *)*((_QWORD *)&v62 + 1);
          if ( *((_QWORD *)&v62 + 1) )
          {
            if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v62 + 1) + 8LL), 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v43 + 16LL))(v43);
              if ( !_InterlockedSub(v43 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v43 + 24LL))(v43);
            }
          }
          if ( v42 )
          {
            if ( *(_QWORD *)&v66[0].gap0 )
              v44 = (std::__tree_node_base<void *> *)(*(__int64 (__fastcall **)(_QWORD))(**(_QWORD **)&v66[0].gap0 + 24LL))(*(_QWORD *)&v66[0].gap0);
            else
              v44 = 0;
            *(_QWORD *)&v62 = &v67;
            v45 = std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
                    p_tree,
                    (const std::string *)&v67,
                    &stru_499629,
                    (std::tuple<const std::string &> *)&v62,
                    __args);
            v46 = v45.first.__ptr_;
            v47 = v45.first.__ptr_[7].__left_;
            v45.first.__ptr_[7].__left_ = v44;
            if ( v47 )
              ((void (__fastcall *)(std::__tree_end_node<std::__tree_node_base<void *> *>::pointer, __int128 *, _QWORD))v47->__left_->__right_)(
                v47,
                &v67,
                *(_QWORD *)&v45.second);
            LOBYTE(v46[8].__left_) = 1;
            v48 = (volatile signed __int32 *)v46[10].__left_;
            *(_OWORD *)&v46[9].__left_ = 0;
            if ( v48 )
            {
              if ( !_InterlockedSub(v48 + 2, 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *, __int128 *, _QWORD))(*(_QWORD *)v48 + 16LL))(
                  v48,
                  &v67,
                  *(_QWORD *)&v45.second);
                if ( !_InterlockedSub(v48 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v48 + 24LL))(v48);
              }
            }
            boost::program_options::option_description::semantic(&v62, v40);
            v6 = v70;
            *(_QWORD *)&__args[0].gap0 = &v67;
            v49 = std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
                    p_tree,
                    (const std::string *)&v67,
                    &stru_499629,
                    (std::tuple<const std::string &> *)__args,
                    &v64);
            v50 = v62;
            v62 = 0;
            v51 = (volatile signed __int32 *)v49.first.__ptr_[10].__left_;
            *(_OWORD *)&v49.first.__ptr_[9].__left_ = v50;
            if ( v51 )
            {
              if ( !_InterlockedSub(v51 + 2, 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *, __int128 *, _QWORD))(*(_QWORD *)v51 + 16LL))(
                  v51,
                  &v67,
                  *(_QWORD *)&v49.second);
                if ( !_InterlockedSub(v51 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v51 + 24LL))(v51);
              }
            }
            v52 = (volatile signed __int32 *)*((_QWORD *)&v62 + 1);
            if ( *((_QWORD *)&v62 + 1) )
            {
              if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v62 + 1) + 8LL), 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *, __int128 *, _QWORD))(*(_QWORD *)v52 + 16LL))(
                  v52,
                  &v67,
                  *(_QWORD *)&v49.second);
                if ( !_InterlockedSub(v52 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v52 + 24LL))(v52);
              }
            }
          }
          if ( *(_QWORD *)&v66[0].gap0 )
            (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v66[0].gap0 + 8LL))(*(_QWORD *)&v66[0].gap0);
        }
        boost::program_options::option_description::semantic(&v62, v40);
        v53 = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)v62 + 32LL))(v62);
        v54 = (volatile signed __int32 *)*((_QWORD *)&v62 + 1);
        if ( *((_QWORD *)&v62 + 1) )
        {
          if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v62 + 1) + 8LL), 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v54 + 16LL))(v54);
            if ( !_InterlockedSub(v54 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v54 + 24LL))(v54);
          }
        }
        if ( !v53 )
          goto LABEL_100;
        boost::program_options::option_description::canonical_display_name(
          (boost::program_options::option_description *)&v62,
          (__int64)v40,
          *((_DWORD *)v6 + 8));
        if ( (v62 & 1) != 0 )
          v55 = *((_QWORD *)&v62 + 1);
        else
          v55 = (unsigned __int64)(unsigned __int8)v62 >> 1;
        *(_QWORD *)&__args[0].gap0 = &v67;
        v56 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
                v69,
                (const std::string *)&v67,
                &stru_499629,
                (std::tuple<const std::string &> *)__args,
                v66).first.__ptr_;
        left_low = LOBYTE(v56[7].__left_);
        if ( (left_low & 1) != 0 )
        {
          if ( (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v55 <= v56[8].__left_ )
            goto LABEL_98;
        }
        else if ( v55 <= left_low >> 1 )
        {
LABEL_98:
          if ( (v62 & 1) != 0 )
            operator delete(v63);
          goto LABEL_100;
        }
        *(_QWORD *)&__args[0].gap0 = &v67;
        v58 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
                v69,
                (const std::string *)&v67,
                &stru_499629,
                (std::tuple<const std::string &> *)__args,
                v66);
        std::string::operator=((soap *)&v58.first.__ptr_[7], (int)&v62, *(int *)&v58.second, v59, v60, v61);
        goto LABEL_98;
      }
LABEL_100:
      if ( (v67 & 1) != 0 )
        operator delete(ptr);
      v39 = v38;
      v37 = *(_QWORD *)v36;
      ++v38;
    }
    while ( (__int64)(*((_QWORD *)v36 + 1) - *(_QWORD *)v36) >> 4 > v39 );
  }
  if ( (v77 & 1) != 0 )
    operator delete(v78);
  if ( (v74 & 1) != 0 )
    operator delete(v75);
  std::__tree<std::string>::destroy(&v76, (std::__tree<std::string>::__node_pointer)v76.__pair1_.__value_.__left_);
}


// Address: 0xe69e30 | Name: _ZN5boost15program_options5storeERKNS0_20basic_parsed_optionsIwEERNS0_13variables_mapE
void __fastcall boost::program_options::store(
        const boost::program_options::wparsed_options *options,
        boost::program_options::variables_map *m)
{
  boost::program_options::store((char *)options + 32, m, 1);
}


// Address: 0xe69e40 | Name: _ZN5boost15program_options6notifyERNS0_13variables_mapE
// attributes: thunk
void __fastcall boost::program_options::notify(boost::program_options::variables_map *vm)
{
  boost::program_options::variables_map::notify(vm);
}


// Address: 0xe69e50 | Name: _ZN5boost15program_options13variables_map6notifyEv
void __fastcall boost::program_options::variables_map::notify(boost::program_options::variables_map *this)
{
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__iter_pointer begin_node; // rbx
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *p_pair1; // r12
  std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::iterator v3; // rax
  _QWORD *p_left; // rcx
  boost::program_options::variables_map *left; // rax
  __int64 v6; // rbx
  bool v7; // zf
  std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::__iter_pointer v8; // rbx
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v9; // rdi
  _QWORD *v10; // rcx
  _QWORD *v11; // rax
  __int64 v12; // rbx
  _QWORD v13[3]; // [rsp+8h] [rbp-A0h] BYREF

  begin_node = this->m_required.__tree_.__begin_node_;
  if ( begin_node == (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__iter_pointer)&this->m_required.__tree_.__pair1_ )
  {
    p_pair1 = &this->__tree_.__pair1_;
  }
  else
  {
    p_pair1 = &this->__tree_.__pair1_;
    do
    {
      v3.__ptr_ = std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::find<std::string>(
                    &this->__tree_,
                    (const std::string *)&begin_node[4]).__ptr_;
      if ( (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)v3.__ptr_ == p_pair1
        || !v3.__ptr_[7].__left_ )
      {
        boost::program_options::required_option::required_option(
          (boost::program_options::required_option *)v13,
          (const std::string *)&begin_node[7]);
        boost::throw_exception<boost::program_options::required_option>((const boost::program_options::required_option *)v13);
      }
      p_left = &begin_node[1].__left_->__left_;
      if ( p_left )
      {
        do
        {
          left = (boost::program_options::variables_map *)p_left;
          p_left = (_QWORD *)*p_left;
        }
        while ( p_left );
      }
      else
      {
        left = (boost::program_options::variables_map *)begin_node[2].__left_;
        if ( (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__iter_pointer)left->_vptr$abstract_variables_map != begin_node )
        {
          v6 = (__int64)&begin_node[2];
          do
          {
            left = *(boost::program_options::variables_map **)(*(_QWORD *)v6 + 16LL);
            v7 = left->_vptr$abstract_variables_map == *(int (***)(void))v6;
            v6 = *(_QWORD *)v6 + 16LL;
          }
          while ( !v7 );
        }
      }
      begin_node = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__iter_pointer)left;
    }
    while ( left != (boost::program_options::variables_map *)&this->m_required.__tree_.__pair1_ );
  }
  v8 = this->__tree_.__begin_node_;
  if ( v8 != (std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::__iter_pointer)p_pair1 )
  {
    do
    {
      v9 = v8[9].__left_;
      if ( v9 )
        (*(void (__fastcall **)(std::__tree_end_node<std::__tree_node_base<void *> *>::pointer, std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::__iter_pointer))&v9->__left_[1].__is_black_)(
          v9,
          v8 + 7);
      v10 = &v8[1].__left_->__left_;
      if ( v10 )
      {
        do
        {
          v11 = v10;
          v10 = (_QWORD *)*v10;
        }
        while ( v10 );
      }
      else
      {
        v11 = &v8[2].__left_->__left_;
        if ( (std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::__iter_pointer)*v11 != v8 )
        {
          v12 = (__int64)&v8[2];
          do
          {
            v11 = *(_QWORD **)(*(_QWORD *)v12 + 16LL);
            v7 = *v11 == *(_QWORD *)v12;
            v12 = *(_QWORD *)v12 + 16LL;
          }
          while ( !v7 );
        }
      }
      v8 = (std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::__iter_pointer)v11;
    }
    while ( v11 != (_QWORD *)p_pair1 );
  }
}


// Address: 0xe69ff0 | Name: _ZN5boost15program_options22abstract_variables_mapC2Ev
void __fastcall boost::program_options::abstract_variables_map::abstract_variables_map(
        boost::program_options::abstract_variables_map *this)
{
  this->_vptr$abstract_variables_map = (int (**)(void))&off_287E738;
  this->m_next = 0;
}


// Address: 0xe6a010 | Name: _ZN5boost15program_options22abstract_variables_mapC2EPKS1_
void __fastcall boost::program_options::abstract_variables_map::abstract_variables_map(
        boost::program_options::abstract_variables_map *this,
        const boost::program_options::abstract_variables_map *next)
{
  this->_vptr$abstract_variables_map = (int (**)(void))&off_287E738;
  this->m_next = next;
}


// Address: 0xe6a020 | Name: _ZNK5boost15program_options22abstract_variables_mapixERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
const boost::program_options::variable_value *__fastcall boost::program_options::abstract_variables_map::operator[](
        boost::program_options::abstract_variables_map *a1,
        const std::string *name)
{
  const boost::program_options::abstract_variables_map *v2; // rbx
  __int64 v3; // rax
  __int64 v4; // r15
  const boost::program_options::variable_value *result; // rax

  do
  {
    v2 = a1;
    v3 = (*((__int64 (__fastcall **)(boost::program_options::abstract_variables_map *, const std::string *))a1->_vptr$abstract_variables_map
          + 2))(
           a1,
           name);
    v4 = v3;
    if ( *(_QWORD *)v3 )
      break;
    a1 = (boost::program_options::abstract_variables_map *)a1->m_next;
  }
  while ( a1 );
  if ( !*(_BYTE *)(v3 + 8) )
    return (const boost::program_options::variable_value *)v4;
  if ( !v2->m_next )
    return (const boost::program_options::variable_value *)v4;
  result = boost::program_options::abstract_variables_map::operator[](v2, name);
  if ( !result->v.content || result->m_defaulted )
    return (const boost::program_options::variable_value *)v4;
  return result;
}


// Address: 0xe6a080 | Name: _ZN5boost15program_options22abstract_variables_map4nextEPS1_
void __fastcall boost::program_options::abstract_variables_map::next(
        boost::program_options::abstract_variables_map *this,
        boost::program_options::abstract_variables_map *next)
{
  this->m_next = next;
}


// Address: 0xe6a090 | Name: _ZN5boost15program_options13variables_mapC2Ev
void __fastcall boost::program_options::variables_map::variables_map(boost::program_options::variables_map *this)
{
  this->m_next = 0;
  *(_OWORD *)&this->__tree_.__pair1_.__value_.__left_ = 0;
  this->__tree_.__begin_node_ = &this->__tree_.__pair1_.__value_;
  this->_vptr$abstract_variables_map = (int (**)(void))off_287E760;
  *(_OWORD *)&this->m_final.__tree_.__pair1_.__value_.__left_ = 0;
  this->m_final.__tree_.__begin_node_ = &this->m_final.__tree_.__pair1_.__value_;
  *(_OWORD *)&this->m_required.__tree_.__pair1_.__value_.__left_ = 0;
  this->m_required.__tree_.__begin_node_ = &this->m_required.__tree_.__pair1_.__value_;
}


// Address: 0xe6a0d0 | Name: _ZN5boost15program_options13variables_mapC2EPKNS0_22abstract_variables_mapE
void __fastcall boost::program_options::variables_map::variables_map(
        boost::program_options::variables_map *this,
        const boost::program_options::abstract_variables_map *next)
{
  this->m_next = next;
  *(_OWORD *)&this->__tree_.__pair1_.__value_.__left_ = 0;
  this->__tree_.__begin_node_ = &this->__tree_.__pair1_.__value_;
  this->_vptr$abstract_variables_map = (int (**)(void))off_287E760;
  *(_OWORD *)&this->m_final.__tree_.__pair1_.__value_.__left_ = 0;
  this->m_final.__tree_.__begin_node_ = &this->m_final.__tree_.__pair1_.__value_;
  *(_OWORD *)&this->m_required.__tree_.__pair1_.__value_.__left_ = 0;
  this->m_required.__tree_.__begin_node_ = &this->m_required.__tree_.__pair1_.__value_;
}


// Address: 0xe6a110 | Name: _ZN5boost15program_options13variables_map5clearEv
void __fastcall boost::program_options::variables_map::clear(boost::program_options::variables_map *this)
{
  std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::destroy(
    &this->__tree_,
    (std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::__node_pointer)this->__tree_.__pair1_.__value_.__left_);
  this->__tree_.__begin_node_ = &this->__tree_.__pair1_.__value_;
  *(_OWORD *)&this->__tree_.__pair1_.__value_.__left_ = 0;
  std::__tree<std::string>::destroy(
    &this->m_final.__tree_,
    (std::__tree<std::string>::__node_pointer)this->m_final.__tree_.__pair1_.__value_.__left_);
  this->m_final.__tree_.__begin_node_ = &this->m_final.__tree_.__pair1_.__value_;
  *(_OWORD *)&this->m_final.__tree_.__pair1_.__value_.__left_ = 0;
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    &this->m_required.__tree_,
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer)this->m_required.__tree_.__pair1_.__value_.__left_);
  this->m_required.__tree_.__begin_node_ = &this->m_required.__tree_.__pair1_.__value_;
  *(_OWORD *)&this->m_required.__tree_.__pair1_.__value_.__left_ = 0;
}


// Address: 0xe6a180 | Name: _ZNK5boost15program_options13variables_map3getERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
const boost::program_options::variable_value *__fastcall boost::program_options::variables_map::get(
        const boost::program_options::variables_map *this,
        const std::string *name)
{
  std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value> > >::const_iterator v2; // rax
  bool v3; // zf
  const boost::program_options::variable_value *result; // rax

  if ( !(_BYTE)byte_29F2128 && __cxa_guard_acquire(&byte_29F2128) )
  {
    stru_29F2108.v.content = 0;
    stru_29F2108.m_defaulted = 0;
    stru_29F2108.m_value_semantic = 0;
    __cxa_atexit((void (*)(void *))boost::program_options::variable_value::~variable_value, &stru_29F2108, &dso_handle);
    __cxa_guard_release(&byte_29F2128);
  }
  v2.__ptr_ = std::__tree<std::__value_type<std::string,boost::program_options::variable_value>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::program_options::variable_value>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::program_options::variable_value>>>::find<std::string>(
                &this->__tree_,
                name).__ptr_;
  v3 = v2.__ptr_ == &this->__tree_.__pair1_.__value_;
  result = (const boost::program_options::variable_value *)&v2.__ptr_[7];
  if ( v3 )
    return &stru_29F2108;
  return result;
}


