// Address: 0xe602c0 | Name: _ZN5boost14char_separatorIcNSt3__111char_traitsIcEEEC2EPKcS6_NS_18empty_token_policyE
void __fastcall boost::char_separator<char,std::char_traits<char>>::char_separator(
        boost::char_separator<char,std::char_traits<char> > *this,
        const char *dropped_delims,
        const char *kept_delims,
        boost::empty_token_policy empty_tokens)
{
  _BYTE *v5; // r12
  size_t v6; // rax
  size_t v7; // rbp
  char *v8; // r14
  size_t v9; // r12
  struct _Unwind_Exception *v10; // rax
  struct _Unwind_Exception *v11; // rbp

  v5 = (char *)this + 24;
  *((_OWORD *)this + 2) = 0;
  *((_OWORD *)this + 1) = 0;
  *(_OWORD *)this = 0;
  v6 = strlen(dropped_delims);
  if ( v6 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v10 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(v5);
    v11 = v10;
    if ( (*(_BYTE *)this & 1) == 0 )
      _Unwind_Resume(v10);
    operator delete(*((void **)this + 2));
    _Unwind_Resume(v11);
  }
  v7 = v6;
  if ( v6 >= 0x17 )
  {
    v9 = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v8 = (char *)operator new(v9);
    *((_QWORD *)this + 5) = v8;
    *((_QWORD *)this + 3) = v9 | 1;
    *((_QWORD *)this + 4) = v7;
    goto LABEL_6;
  }
  *v5 = 2 * v6;
  v8 = (char *)this + 25;
  if ( v6 )
LABEL_6:
    memcpy(v8, dropped_delims, v7);
  v8[v7] = 0;
  *((_WORD *)this + 24) = 0;
  *((_DWORD *)this + 13) = empty_tokens;
  *((_BYTE *)this + 56) = 0;
  if ( kept_delims )
    std::string::assign(this, kept_delims);
}


// Address: 0xe606b0 | Name: _ZN5boost14char_separatorIcNSt3__111char_traitsIcEEEclINS1_11__wrap_iterIPKcEENS1_12basic_stringIcS3_NS1_9allocatorIcEEEEEEbRT_SE_RT0_
char __fastcall boost::char_separator<char,std::char_traits<char>>::operator()<std::__wrap_iter<char const*>,std::string>(
        boost::char_separator<char,std::char_traits<char> > *this,
        std::__wrap_iter<const char *> *next,
        std::__wrap_iter<const char *> end,
        std::string *tok)
{
  std::string *v4; // r13
  std::__wrap_iter<const char *>::iterator_type i; // r15
  std::__wrap_iter<const char *> *v6; // rbx
  std::__wrap_iter<const char *>::iterator_type v7; // r14
  char v8; // bl
  unsigned __int64 v9; // rax
  __int64 v10; // rax
  bool v11; // cl
  unsigned __int8 *v12; // r13
  __int64 v13; // rbp
  unsigned __int64 v14; // rax
  __int64 v15; // rax
  const unsigned __int16 **v17; // rax
  std::__wrap_iter<const char *>::iterator_type v18; // rbp
  unsigned __int64 v19; // r14
  unsigned __int8 v20; // al
  unsigned __int64 v21; // rsi
  __int64 v22; // rcx
  __int64 v23; // r15
  unsigned __int64 v24; // rax
  __int64 v25; // rax
  std::__wrap_iter<const char *>::iterator_type v26; // rbp
  unsigned __int64 v27; // rax
  std::__wrap_iter<const char *>::iterator_type v28; // r15
  __int64 v29; // rbp
  unsigned __int64 v30; // rax
  unsigned __int64 v31; // rax
  __int64 v32; // rax
  char v33; // bl
  unsigned __int64 v34; // rax
  unsigned __int64 v35; // rax
  const char *v36; // rbp
  unsigned __int64 v37; // r15
  unsigned __int8 v38; // al
  unsigned __int64 v39; // rsi
  __int64 v40; // rcx
  unsigned __int64 v41; // rcx
  const char *v42; // rax
  const char *v43; // rdx
  signed __int64 v44; // rbp
  __int64 v45; // rcx
  unsigned __int64 v46; // rcx
  __int64 v47; // rdx
  __int64 v48; // rsi
  unsigned __int64 v49; // rcx
  __int64 v50; // rdi
  __int128 v51; // xmm1
  __int128 v52; // xmm1
  __int128 v53; // xmm1
  __int128 v54; // xmm1
  __int64 v55; // rsi
  __int64 v56; // rdx
  __int128 v57; // xmm1
  std::__wrap_iter<const char *> *v58; // r15
  char v59; // bl
  unsigned __int64 v60; // rax
  unsigned __int64 v61; // rax
  bool v62; // zf
  _BYTE *v63; // rax
  unsigned __int64 v64; // rcx
  _BYTE *v65; // rcx
  __int64 v66; // rbp
  __int64 v67; // rdx
  unsigned __int64 v68; // r8
  __int64 v69; // rsi
  __int64 v70; // rdi
  __int64 v71; // rdx
  __int128 v72; // xmm1
  __int128 v73; // xmm1
  __int128 v74; // xmm1
  __int128 v75; // xmm1
  __int64 v76; // rdi
  __int64 v77; // rsi
  __int128 v78; // xmm1
  _BYTE *v80; // [rsp+18h] [rbp-40h]
  const char *v81; // [rsp+20h] [rbp-38h]
  const char *v82; // [rsp+20h] [rbp-38h]

  v4 = tok;
  i = end.__i;
  v6 = next;
  if ( *((_DWORD *)this + 13) )
  {
    v7 = next->__i;
    if ( next->__i == end.__i )
      goto LABEL_21;
    goto LABEL_3;
  }
  v7 = next->__i;
  if ( next->__i == end.__i )
    return 0;
  v12 = (unsigned __int8 *)this + 24;
  do
  {
    v13 = *v7;
    v14 = *v12;
    if ( (v14 & 1) != 0 )
    {
      if ( *((_QWORD *)this + 4) )
      {
LABEL_12:
        v15 = std::string::find((char *)this + 24, (unsigned int)v13, 0);
        v7 = next->__i;
        if ( v15 == -1 )
          goto LABEL_19;
        goto LABEL_17;
      }
    }
    else if ( v14 >> 1 )
    {
      goto LABEL_12;
    }
    if ( !*((_BYTE *)this + 49) || ((*__ctype_b_loc())[v13] & 0x2000) == 0 )
      goto LABEL_19;
LABEL_17:
    next->__i = ++v7;
  }
  while ( v7 != i );
  v7 = i;
LABEL_19:
  if ( *((_DWORD *)this + 13) )
  {
    v4 = tok;
    if ( v7 == i )
    {
LABEL_21:
      if ( *((_BYTE *)this + 56) )
        return 0;
      *((_BYTE *)this + 56) = 1;
      v18 = next->__i;
      v19 = next->__i - i;
      v20 = *(_BYTE *)v4;
      if ( (*(_BYTE *)v4 & 1) != 0 )
      {
        v22 = *(_QWORD *)v4;
        v21 = (*(_QWORD *)v4 & 0xFFFFFFFFFFFFFFFELL) - 1;
      }
      else
      {
        v21 = 22;
        LOBYTE(v22) = *(_BYTE *)v4;
      }
      if ( v19 > v21 )
      {
        if ( (v20 & 1) != 0 )
          v49 = *((_QWORD *)v4 + 1);
        else
          v49 = (unsigned __int64)v20 >> 1;
        std::string::__grow_by(v4, v21, v19 - v21, v49, 0, v49, 0);
        LOBYTE(v22) = *(_BYTE *)v4;
      }
      if ( (v22 & 1) != 0 )
        v63 = (_BYTE *)*((_QWORD *)v4 + 2);
      else
        v63 = (char *)v4 + 1;
      v64 = v18 - i;
      if ( v18 != i )
      {
        if ( v64 < 0x20 || v63 < v18 && &v63[v64] > i )
        {
          v65 = v63;
LABEL_142:
          v66 = v18 - i;
          v67 = 0;
          do
          {
            v65[v67] = i[v67];
            ++v67;
          }
          while ( v66 != v67 );
          goto LABEL_144;
        }
        v68 = v64 & 0xFFFFFFFFFFFFFFE0LL;
        v69 = ((unsigned __int8)(((v64 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
        if ( (v64 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
        {
          v71 = v69 - ((((v64 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
          v70 = 0;
          do
          {
            v72 = *(_OWORD *)&i[v70 + 16];
            *(_OWORD *)&v63[v70] = *(_OWORD *)&i[v70];
            *(_OWORD *)&v63[v70 + 16] = v72;
            v73 = *(_OWORD *)&i[v70 + 48];
            *(_OWORD *)&v63[v70 + 32] = *(_OWORD *)&i[v70 + 32];
            *(_OWORD *)&v63[v70 + 48] = v73;
            v74 = *(_OWORD *)&i[v70 + 80];
            *(_OWORD *)&v63[v70 + 64] = *(_OWORD *)&i[v70 + 64];
            *(_OWORD *)&v63[v70 + 80] = v74;
            v75 = *(_OWORD *)&i[v70 + 112];
            *(_OWORD *)&v63[v70 + 96] = *(_OWORD *)&i[v70 + 96];
            *(_OWORD *)&v63[v70 + 112] = v75;
            v70 += 128;
            v71 += 4;
          }
          while ( v71 );
          if ( (((unsigned __int8)(((v64 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) != 0 )
            goto LABEL_155;
        }
        else
        {
          v70 = 0;
          if ( (((unsigned __int8)(((v64 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
            goto LABEL_157;
LABEL_155:
          v76 = v70 + 16;
          v77 = -v69;
          do
          {
            v78 = *(_OWORD *)&i[v76];
            *(_OWORD *)&v63[v76 - 16] = *(_OWORD *)&i[v76 - 16];
            *(_OWORD *)&v63[v76] = v78;
            v76 += 32;
            ++v77;
          }
          while ( v77 );
        }
LABEL_157:
        if ( v64 != v68 )
        {
          v65 = &v63[v68];
          i += v68;
          goto LABEL_142;
        }
LABEL_144:
        v63 += v19;
      }
      *v63 = 0;
      if ( (*(_BYTE *)v4 & 1) != 0 )
        *((_QWORD *)v4 + 1) = v19;
      else
        *(_BYTE *)v4 = 2 * v19;
      return 1;
    }
LABEL_3:
    v8 = *v7;
    v9 = *(unsigned __int8 *)this;
    if ( (v9 & 1) != 0 )
    {
      if ( !*((_QWORD *)this + 1) )
        goto LABEL_24;
LABEL_5:
      v10 = std::string::find(this, (unsigned int)v8, 0);
      v80 = (char *)this + 56;
      v11 = *((_BYTE *)this + 56) == 0;
      if ( v10 != -1 )
        goto LABEL_6;
LABEL_26:
      if ( v11 )
      {
        v8 = *next->__i;
        goto LABEL_37;
      }
      goto LABEL_44;
    }
    if ( v9 >> 1 )
      goto LABEL_5;
LABEL_24:
    if ( *((_BYTE *)this + 48) )
    {
      v17 = __ctype_b_loc();
      v80 = (char *)this + 56;
      v11 = *((_BYTE *)this + 56) == 0;
      if ( ((*v17)[v8] & 4) == 0 )
        goto LABEL_26;
LABEL_6:
      v6 = next;
      if ( v11 )
      {
        *v80 = 1;
      }
      else
      {
        ++next->__i;
        *v80 = 0;
      }
      goto LABEL_73;
    }
    v80 = (char *)this + 56;
    if ( *((_BYTE *)this + 56) )
      goto LABEL_44;
LABEL_37:
    v27 = *((unsigned __int8 *)this + 24);
    if ( (v27 & 1) == 0 )
    {
      if ( v27 >> 1 )
        goto LABEL_39;
LABEL_42:
      if ( !*((_BYTE *)this + 49) || ((*__ctype_b_loc())[v8] & 0x2000) == 0 )
        goto LABEL_44;
LABEL_71:
      *v80 = 1;
LABEL_72:
      v6 = next;
      goto LABEL_73;
    }
    if ( !*((_QWORD *)this + 4) )
      goto LABEL_42;
LABEL_39:
    if ( std::string::find((char *)this + 24, (unsigned int)v8, 0) != -1 )
      goto LABEL_71;
LABEL_44:
    v82 = i;
    v28 = next->__i;
    v29 = *next->__i;
    v30 = *((unsigned __int8 *)this + 24);
    if ( (v30 & 1) != 0 )
      v31 = *((_QWORD *)this + 4);
    else
      v31 = v30 >> 1;
    if ( v31 )
    {
      v32 = std::string::find((char *)this + 24, (unsigned int)v29, 0);
      v28 = next->__i;
      if ( v32 == -1 )
        goto LABEL_55;
LABEL_52:
      next->__i = ++v28;
      v7 = v28;
      if ( v28 != v82 )
        goto LABEL_56;
LABEL_70:
      *v80 = 1;
      goto LABEL_72;
    }
    if ( *((_BYTE *)this + 49) && ((*__ctype_b_loc())[v29] & 0x2000) != 0 )
      goto LABEL_52;
LABEL_55:
    while ( 2 )
    {
      if ( v28 == v82 )
        goto LABEL_70;
LABEL_56:
      v33 = *v28;
      v34 = *((unsigned __int8 *)this + 24);
      if ( (v34 & 1) != 0 )
      {
        if ( !*((_QWORD *)this + 4) )
          goto LABEL_61;
LABEL_58:
        if ( std::string::find((char *)this + 24, (unsigned int)v33, 0) != -1 )
          goto LABEL_70;
        v28 = next->__i;
        v33 = *next->__i;
      }
      else
      {
        if ( v34 >> 1 )
          goto LABEL_58;
LABEL_61:
        if ( *((_BYTE *)this + 49) && ((*__ctype_b_loc())[v33] & 0x2000) != 0 )
          goto LABEL_70;
      }
      v35 = *(unsigned __int8 *)this;
      if ( (v35 & 1) != 0 )
      {
        if ( !*((_QWORD *)this + 1) )
          goto LABEL_68;
LABEL_65:
        if ( std::string::find(this, (unsigned int)v33, 0) != -1 )
          goto LABEL_70;
        v28 = next->__i;
      }
      else
      {
        if ( v35 >> 1 )
          goto LABEL_65;
LABEL_68:
        if ( *((_BYTE *)this + 48) && ((*__ctype_b_loc())[v33] & 4) != 0 )
          goto LABEL_70;
      }
      next->__i = ++v28;
      continue;
    }
  }
  if ( v7 == i )
    return 0;
  v81 = i;
  v23 = *v7;
  v24 = *(unsigned __int8 *)this;
  if ( (v24 & 1) == 0 )
  {
    if ( v24 >> 1 )
      goto LABEL_34;
LABEL_110:
    v26 = v7;
    if ( !*((_BYTE *)this + 48) )
      goto LABEL_112;
    v26 = v7;
    if ( ((*__ctype_b_loc())[v23] & 4) == 0 )
      goto LABEL_112;
LABEL_131:
    next->__i = v26 + 1;
    v4 = tok;
    goto LABEL_73;
  }
  if ( !*((_QWORD *)this + 1) )
    goto LABEL_110;
LABEL_34:
  v25 = std::string::find(this, (unsigned int)v23, 0);
  v26 = next->__i;
  if ( v25 != -1 )
    goto LABEL_131;
LABEL_112:
  if ( v26 == v81 )
  {
LABEL_130:
    v4 = tok;
    goto LABEL_73;
  }
  while ( 2 )
  {
    v58 = v6;
    v59 = *v26;
    v60 = *v12;
    if ( (v60 & 1) != 0 )
    {
      if ( !*((_QWORD *)this + 4) )
        goto LABEL_118;
LABEL_115:
      if ( std::string::find((char *)this + 24, (unsigned int)v59, 0) != -1 )
        goto LABEL_151;
      v26 = v58->__i;
      v59 = *v58->__i;
LABEL_120:
      v61 = *(unsigned __int8 *)this;
      if ( (v61 & 1) != 0 )
      {
        if ( *((_QWORD *)this + 1) )
          goto LABEL_122;
      }
      else if ( v61 >> 1 )
      {
LABEL_122:
        if ( std::string::find(this, (unsigned int)v59, 0) != -1 )
          goto LABEL_151;
        v6 = v58;
        v26 = v58->__i;
        goto LABEL_129;
      }
      if ( *((_BYTE *)this + 48) )
      {
        v62 = ((*__ctype_b_loc())[v59] & 4) == 0;
        v6 = v58;
        if ( !v62 )
          goto LABEL_130;
      }
      else
      {
        v6 = v58;
      }
LABEL_129:
      v6->__i = ++v26;
      if ( v26 == v81 )
        goto LABEL_130;
      continue;
    }
    break;
  }
  if ( v60 >> 1 )
    goto LABEL_115;
LABEL_118:
  if ( !*((_BYTE *)this + 49) || ((*__ctype_b_loc())[v59] & 0x2000) == 0 )
    goto LABEL_120;
LABEL_151:
  v4 = tok;
  v6 = v58;
LABEL_73:
  v36 = v6->__i;
  v37 = v6->__i - v7;
  v38 = *(_BYTE *)v4;
  if ( (*(_BYTE *)v4 & 1) != 0 )
  {
    v40 = *(_QWORD *)v4;
    v39 = (*(_QWORD *)v4 & 0xFFFFFFFFFFFFFFFELL) - 1;
  }
  else
  {
    v39 = 22;
    LOBYTE(v40) = *(_BYTE *)v4;
  }
  if ( v37 > v39 )
  {
    if ( (v38 & 1) != 0 )
      v41 = *((_QWORD *)v4 + 1);
    else
      v41 = (unsigned __int64)v38 >> 1;
    std::string::__grow_by(v4, v39, v37 - v39, v41, 0, v41, 0);
    LOBYTE(v40) = *(_BYTE *)v4;
  }
  if ( (v40 & 1) != 0 )
  {
    v42 = (const char *)*((_QWORD *)v4 + 2);
    if ( v7 != v36 )
    {
LABEL_83:
      if ( v37 < 0x20 || v42 < v36 && v7 < &v42[v37] )
      {
        v43 = v42;
LABEL_87:
        v44 = v36 - v7;
        v45 = 0;
        do
        {
          v43[v45] = v7[v45];
          ++v45;
        }
        while ( v44 != v45 );
        goto LABEL_89;
      }
      v46 = v37 & 0xFFFFFFFFFFFFFFE0LL;
      v47 = ((unsigned __int8)(((v37 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
      if ( (v37 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
      {
        v50 = v47 - ((((v37 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
        v48 = 0;
        do
        {
          v51 = *(_OWORD *)&v7[v48 + 16];
          *(_OWORD *)&v42[v48] = *(_OWORD *)&v7[v48];
          *(_OWORD *)&v42[v48 + 16] = v51;
          v52 = *(_OWORD *)&v7[v48 + 48];
          *(_OWORD *)&v42[v48 + 32] = *(_OWORD *)&v7[v48 + 32];
          *(_OWORD *)&v42[v48 + 48] = v52;
          v53 = *(_OWORD *)&v7[v48 + 80];
          *(_OWORD *)&v42[v48 + 64] = *(_OWORD *)&v7[v48 + 64];
          *(_OWORD *)&v42[v48 + 80] = v53;
          v54 = *(_OWORD *)&v7[v48 + 112];
          *(_OWORD *)&v42[v48 + 96] = *(_OWORD *)&v7[v48 + 96];
          *(_OWORD *)&v42[v48 + 112] = v54;
          v48 += 128;
          v50 += 4;
        }
        while ( v50 );
        if ( (((unsigned __int8)(((v37 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) != 0 )
          goto LABEL_105;
      }
      else
      {
        v48 = 0;
        if ( (((unsigned __int8)(((v37 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
          goto LABEL_107;
LABEL_105:
        v55 = v48 + 16;
        v56 = -v47;
        do
        {
          v57 = *(_OWORD *)&v7[v55];
          *(_OWORD *)&v42[v55 - 16] = *(_OWORD *)&v7[v55 - 16];
          *(_OWORD *)&v42[v55] = v57;
          v55 += 32;
          ++v56;
        }
        while ( v56 );
      }
LABEL_107:
      if ( v37 != v46 )
      {
        v43 = &v42[v46];
        v7 += v46;
        goto LABEL_87;
      }
LABEL_89:
      v42 += v37;
    }
  }
  else
  {
    v42 = (char *)v4 + 1;
    if ( v7 != v36 )
      goto LABEL_83;
  }
  *v42 = 0;
  if ( (*(_BYTE *)v4 & 1) != 0 )
    *((_QWORD *)v4 + 1) = v37;
  else
    *(_BYTE *)v4 = 2 * v37;
  return 1;
}


