// Address: 0xe51de0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE20construct_with_valueIJRKNS0_21piecewise_construct_tENS_6tuples5tupleISB_NSO_9null_typeESQ_SQ_SQ_SQ_SQ_SQ_SQ_SQ_EENSP_ISQ_SQ_SQ_SQ_SQ_SQ_SQ_SQ_SQ_SQ_EEEEEvDpOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct_with_value<boost::unordered::piecewise_construct_t const&,boost::tuples::tuple<std::string,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type>,boost::tuples::tuple<boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type>>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > > *this,
        const boost::unordered::piecewise_construct_t *args,
        boost::tuples::tuple<std::string,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type> *a3,
        boost::tuples::tuple<boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type> *a4)
{
  char *node; // rbx
  bool *p_value_constructed; // r12
  __int64 v7; // rax

  node = (char *)this->node_;
  if ( node )
  {
    p_value_constructed = &this->value_constructed_;
    if ( this->value_constructed_ )
    {
      v7 = *((_QWORD *)node + 6);
      if ( v7 )
        (*(void (__fastcall **)(char *, const boost::unordered::piecewise_construct_t *, boost::tuples::tuple<std::string,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type> *, boost::tuples::tuple<boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type,boost::tuples::null_type> *))(v7 + 16))(
          node + 56,
          args,
          a3,
          a4);
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    p_value_constructed = &this->value_constructed_;
    node = (char *)operator new(0x98u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > >::node_pointer)node;
    *((_OWORD *)node + 8) = 0;
    *((_OWORD *)node + 7) = 0;
    *((_OWORD *)node + 6) = 0;
    *((_OWORD *)node + 5) = 0;
    *((_OWORD *)node + 4) = 0;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    *((_QWORD *)node + 18) = 0;
    this->node_constructed_ = 1;
  }
  std::string::basic_string(node + 16, a3);
  *((_QWORD *)node + 5) = RBX::Reflection::Type::getSingleton<void>();
  *((_QWORD *)node + 6) = 0;
  *p_value_constructed = 1;
}


// Address: 0xe523b0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEE21construct_with_value2IRKSG_EEvOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::construct_with_value2<std::pair<std::string const,RBX::Reflection::Variant> const&>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > > *this,
        const std::pair<const std::string,RBX::Reflection::Variant> *a0)
{
  char *node; // rbx
  __int64 v3; // rax
  void (__fastcall **v4)(char *, __int64); // rax
  __int64 v5; // rcx

  node = (char *)this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = *((_QWORD *)node + 6);
      if ( v3 )
        (*(void (__fastcall **)(char *))(v3 + 16))(node + 56);
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    node = (char *)operator new(0x98u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > >::node_pointer)node;
    *((_OWORD *)node + 8) = 0;
    *((_OWORD *)node + 7) = 0;
    *((_OWORD *)node + 6) = 0;
    *((_OWORD *)node + 5) = 0;
    *((_OWORD *)node + 4) = 0;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    *((_QWORD *)node + 18) = 0;
    this->node_constructed_ = 1;
  }
  std::string::basic_string(node + 16, a0);
  *((_QWORD *)node + 5) = *((_QWORD *)a0 + 3);
  *((_QWORD *)node + 6) = 0;
  v4 = (void (__fastcall **)(char *, __int64))*((_QWORD *)a0 + 4);
  if ( v4 )
  {
    (*v4)((char *)a0 + 40, (__int64)(node + 56));
    v5 = *((_QWORD *)a0 + 4);
  }
  else
  {
    v5 = 0;
  }
  *((_QWORD *)node + 6) = v5;
  this->value_constructed_ = 1;
}


// Address: 0xec3540 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEESB_EEEEEEE21construct_with_value2IRKSD_EEvOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::string>>>>::construct_with_value2<std::pair<std::string const,std::string> const&>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::string > > > > *this,
        const std::pair<const std::string,std::string > *a0)
{
  char *node; // rbx

  node = (char *)this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      if ( (node[40] & 1) != 0 )
        operator delete(*((void **)node + 7));
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    node = (char *)operator new(0x40u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::string > > > >::node_pointer)node;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    this->node_constructed_ = 1;
  }
  std::string::basic_string(node + 16, a0);
  std::string::basic_string(node + 40, (char *)a0 + 24);
  this->value_constructed_ = 1;
}


// Address: 0xf80000 | Name: _ZN5boost9unordered6detail16node_constructorINS_19fast_pool_allocatorINS1_8ptr_nodeINSt3__14pairIKN3RBX13ConstPropertyENS7_7Network22PropertyChangeMetadataEEEEENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<RBX::ConstProperty const,RBX::Network::PropertyChangeMetadata>>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~node_constructor(
        boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::ConstProperty,RBX::Network::PropertyChangeMetadata> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this)
{
  boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::ConstProperty,RBX::Network::PropertyChangeMetadata> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> >::node_pointer node; // rbx

  node = this->node_;
  if ( node )
  {
    if ( !byte_29FE161 )
    {
      byte_29FE161 = 1;
      boost::mutex::mutex(&stru_29FDFF0);
      *(_OWORD *)&stru_29FE018.first = 0;
      stru_29FE018.list.sz = 0;
      *(_OWORD *)&stru_29FE018.requested_size = xmmword_3EA050;
      *(_OWORD *)&stru_29FE018.start_size = 0x20u;
    }
    boost::mutex::lock(&stru_29FDFF0);
    node->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)stru_29FE018.first;
    stru_29FE018.first = node;
    boost::mutex::unlock(&stru_29FDFF0);
  }
}


// Address: 0xf815f0 | Name: _ZN5boost9unordered6detail16node_constructorINS_19fast_pool_allocatorINS1_8ptr_nodeINSt3__14pairIKNS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEPKN3RBX8InstanceEEEEENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Instance const*>>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~node_constructor(
        boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this)
{
  boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> >::node_pointer node; // r14

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ && (node->value_base_.data_.data_.buf[0] & 1) != 0 )
    {
      operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
      node = this->node_;
    }
    if ( !byte_29FE161 )
    {
      byte_29FE161 = 1;
      boost::mutex::mutex(&stru_29FDFF0);
      *(_OWORD *)&stru_29FE018.first = 0;
      stru_29FE018.list.sz = 0;
      *(_OWORD *)&stru_29FE018.requested_size = xmmword_3EA050;
      *(_OWORD *)&stru_29FE018.start_size = 0x20u;
    }
    boost::mutex::lock(&stru_29FDFF0);
    node->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)stru_29FE018.first;
    stru_29FE018.first = node;
    boost::mutex::unlock(&stru_29FDFF0);
  }
}


// Address: 0xff9540 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX12Vector3int32ENS7_7Network17StreamingObserver13RegionClusterEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Vector3int32 const,RBX::Network::StreamingObserver::RegionCluster>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Vector3int32,RBX::Network::StreamingObserver::RegionCluster> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Vector3int32,RBX::Network::StreamingObserver::RegionCluster> > > >::node_pointer node; // r15
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v3; // r12
  void *v4; // rdi
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v5; // r15
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v6; // r13
  _QWORD *v7; // rbx
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type v8; // rbp
  _QWORD *v9; // rdi

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = &node->value_base_.data_.data_.align_ + 450;
      v4 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 450);
      if ( v4 )
      {
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 451) = v4;
        operator delete(v4);
      }
      v5 = &node->value_base_.data_.data_.align_ + 2;
      do
      {
        v6 = v3 - 7;
        v7 = (_QWORD *)v3[-2];
        if ( v7 )
        {
          if ( v3[-5] )
          {
            v8 = v3[-6];
            v9 = (_QWORD *)v7[*(_QWORD *)&v8];
            do
            {
              v7[*(_QWORD *)&v8] = *v9;
              operator delete(v9);
              --*(_QWORD *)&v3[-5];
              v9 = (_QWORD *)v7[*(_QWORD *)&v8];
            }
            while ( v9 );
            v7 = (_QWORD *)v3[-2];
          }
          operator delete(v7);
          *(_OWORD *)v3[-3].gap0 = 0;
        }
        v3 -= 7;
      }
      while ( v6 != v5 );
      node = this->node_;
    }
    operator delete(node);
  }
}


// Address: 0xff9620 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX12Vector3int32ENS7_7Network17StreamingObserver13RegionClusterEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Vector3int32 const,RBX::Network::StreamingObserver::RegionCluster>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Vector3int32,RBX::Network::StreamingObserver::RegionCluster> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Vector3int32,RBX::Network::StreamingObserver::RegionCluster> > > >::node_pointer node; // r15
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v3; // r12
  void *v4; // rdi
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v5; // r15
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v6; // r13
  _QWORD *v7; // rbx
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type v8; // rbp
  _QWORD *v9; // rdi
  boost::unordered::detail::ptr_node<std::pair<const RBX::Vector3int32,RBX::Network::StreamingObserver::RegionCluster> > *v10; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = &node->value_base_.data_.data_.align_ + 450;
      v4 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 450);
      if ( v4 )
      {
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 451) = v4;
        operator delete(v4);
      }
      v5 = &node->value_base_.data_.data_.align_ + 2;
      do
      {
        v6 = v3 - 7;
        v7 = (_QWORD *)v3[-2];
        if ( v7 )
        {
          if ( v3[-5] )
          {
            v8 = v3[-6];
            v9 = (_QWORD *)v7[*(_QWORD *)&v8];
            do
            {
              v7[*(_QWORD *)&v8] = *v9;
              operator delete(v9);
              --*(_QWORD *)&v3[-5];
              v9 = (_QWORD *)v7[*(_QWORD *)&v8];
            }
            while ( v9 );
            v7 = (_QWORD *)v3[-2];
          }
          operator delete(v7);
          *(_OWORD *)v3[-3].gap0 = 0;
        }
        v3 -= 7;
      }
      while ( v6 != v5 );
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v10 = (boost::unordered::detail::ptr_node<std::pair<const RBX::Vector3int32,RBX::Network::StreamingObserver::RegionCluster> > *)operator new(0xE40u);
    this->node_ = v10;
    memset(
      v10,
      0,
      sizeof(boost::unordered::detail::ptr_node<std::pair<const RBX::Vector3int32,RBX::Network::StreamingObserver::RegionCluster> >));
    this->node_constructed_ = 1;
  }
}


// Address: 0x1016280 | Name: _ZN5boost9unordered6detail11node_holderINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEESB_EEEEEEED2Ev
void __fastcall boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::string>>>>::~node_holder(
        boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::string > > > > *this)
{
  boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::string > > > >::node_pointer i; // rbx
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::string > > > >::node_pointer node; // rbx

  for ( i = this->nodes_; i; i = this->nodes_ )
  {
    this->nodes_ = (boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::string > > > >::node_pointer)i->next_;
    if ( (i->value_base_.data_.data_.buf[24] & 1) != 0 )
      operator delete(*((void **)&i->value_base_.data_.data_.align_ + 5));
    if ( (i->value_base_.data_.data_.buf[0] & 1) != 0 )
      operator delete(*((void **)&i->value_base_.data_.data_.align_ + 2));
    operator delete(i);
  }
  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      if ( (node->value_base_.data_.data_.buf[24] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 5));
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    }
    operator delete(this->node_);
  }
}


// Address: 0x10c8fc0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3rbx7signals17scoped_connectionEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,rbx::signals::scoped_connection>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,rbx::signals::scoped_connection> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,rbx::signals::scoped_connection> > > >::node_pointer node; // rbx
  volatile signed __int32 *v3; // rdi

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      rbx::signals::connection::disconnect((const rbx::signals::connection *)&node->value_base_.data_.data_.align_ + 3);
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v3 && !_InterlockedSub(v3 + 1, 1u) )
        operator delete((void *)v3);
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    }
    operator delete(this->node_);
  }
}


// Address: 0x10c9170 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3rbx7signals17scoped_connectionEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,rbx::signals::scoped_connection>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,rbx::signals::scoped_connection> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,rbx::signals::scoped_connection> > > >::node_pointer node; // r15
  volatile signed __int32 *v3; // rdi
  boost::unordered::detail::ptr_node<std::pair<const std::string,rbx::signals::scoped_connection> > *v4; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      rbx::signals::connection::disconnect((const rbx::signals::connection *)&node->value_base_.data_.data_.align_ + 3);
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v3 && !_InterlockedSub(v3 + 1, 1u) )
        operator delete((void *)v3);
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v4 = (boost::unordered::detail::ptr_node<std::pair<const std::string,rbx::signals::scoped_connection> > *)operator new(0x30u);
    this->node_ = v4;
    *((_OWORD *)&v4->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v4->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v4->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x10ffa90 | Name: _ZN5boost9unordered6detail11node_holderINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS3_3setIlNS3_4lessIlEENS4_IlEEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::set<long>>>>>::~node_holder(
        boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::set<long> > > > > *this)
{
  boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::set<long> > > > >::node_pointer i; // rbx
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::set<long> > > > >::node_pointer node; // rbx

  for ( i = this->nodes_; i; i = this->nodes_ )
  {
    this->nodes_ = (boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::set<long> > > > >::node_pointer)i->next_;
    std::__tree<long>::destroy(
      (std::__tree<long> *)&i->value_base_.data_.data_.align_ + 1,
      *((std::__tree<long>::__node_pointer *)&i->value_base_.data_.data_.align_ + 4));
    if ( (i->value_base_.data_.data_.buf[0] & 1) != 0 )
      operator delete(*((void **)&i->value_base_.data_.data_.align_ + 2));
    operator delete(i);
  }
  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      std::__tree<long>::destroy(
        (std::__tree<long> *)&node->value_base_.data_.data_.align_ + 1,
        *((std::__tree<long>::__node_pointer *)&node->value_base_.data_.data_.align_ + 4));
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    }
    operator delete(this->node_);
  }
}


// Address: 0x112a120 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKmN3RBX9Scripting14ScriptDebugger16PausedThreadDataEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned long const,RBX::Scripting::ScriptDebugger::PausedThreadData>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData> > > >::node_pointer node; // r15
  RBX::Scripting::ScriptDebugger::FunctionInfo *v3; // r12
  RBX::Scripting::ScriptDebugger::FunctionInfo *v4; // rbx
  void *v5; // rdi

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      if ( (node->value_base_.data_.data_.buf[96] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 14));
      v3 = (RBX::Scripting::ScriptDebugger::FunctionInfo *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 9);
      if ( v3 )
      {
        v4 = (RBX::Scripting::ScriptDebugger::FunctionInfo *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 10);
        if ( v4 == v3 )
        {
          v5 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 9);
        }
        else
        {
          do
          {
            v4 = (RBX::Scripting::ScriptDebugger::FunctionInfo *)((char *)v4 - 136);
            RBX::Scripting::ScriptDebugger::FunctionInfo::~FunctionInfo(v4);
          }
          while ( v3 != v4 );
          v5 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 9);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 10) = v3;
        operator delete(v5);
      }
      RBX::Lua::WeakThreadRef::~WeakThreadRef((RBX::Lua::WeakThreadRef *)(&node->value_base_.data_.data_.align_ + 2));
      node = this->node_;
    }
    operator delete(node);
  }
}


// Address: 0x112a1c0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKmN3RBX9Scripting14ScriptDebugger16PausedThreadDataEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<unsigned long const,RBX::Scripting::ScriptDebugger::PausedThreadData>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData> > > >::node_pointer node; // r15
  RBX::Scripting::ScriptDebugger::FunctionInfo *v3; // r12
  RBX::Scripting::ScriptDebugger::FunctionInfo *v4; // rbx
  void *v5; // rdi
  boost::unordered::detail::ptr_node<std::pair<const unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData> > *v6; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      if ( (node->value_base_.data_.data_.buf[96] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 14));
      v3 = (RBX::Scripting::ScriptDebugger::FunctionInfo *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 9);
      if ( v3 )
      {
        v4 = (RBX::Scripting::ScriptDebugger::FunctionInfo *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 10);
        if ( v4 == v3 )
        {
          v5 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 9);
        }
        else
        {
          do
          {
            v4 = (RBX::Scripting::ScriptDebugger::FunctionInfo *)((char *)v4 - 136);
            RBX::Scripting::ScriptDebugger::FunctionInfo::~FunctionInfo(v4);
          }
          while ( v3 != v4 );
          v5 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 9);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 10) = v3;
        operator delete(v5);
      }
      RBX::Lua::WeakThreadRef::~WeakThreadRef((RBX::Lua::WeakThreadRef *)(&node->value_base_.data_.data_.align_ + 2));
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v6 = (boost::unordered::detail::ptr_node<std::pair<const unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData> > *)operator new(0x88u);
    this->node_ = v6;
    *((_OWORD *)&v6->value_base_.data_.data_.align_ + 6) = 0;
    *((_OWORD *)&v6->value_base_.data_.data_.align_ + 5) = 0;
    *((_OWORD *)&v6->value_base_.data_.data_.align_ + 4) = 0;
    *((_OWORD *)&v6->value_base_.data_.data_.align_ + 3) = 0;
    *((_OWORD *)&v6->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v6->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v6->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v6->next_ = 0;
    *((_QWORD *)&v6->value_base_.data_.data_.align_ + 14) = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x12058d0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS3_5queueISB_NS3_5dequeISB_NS4_ISB_EEEEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::queue<std::string>>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::queue<std::string> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::queue<std::string> > > > >::node_pointer node; // r12
  void **v2; // r14
  void **v3; // rbx
  void **v4; // r13
  __int64 v5; // rcx
  __int64 v6; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (void **)(&node->value_base_.data_.data_.align_ + 3);
      std::__deque_base<std::string>::clear((std::__deque_base<std::string> *)(&node->value_base_.data_.data_.align_ + 3));
      v3 = (void **)*((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
      v4 = (void **)*((_QWORD *)&node->value_base_.data_.data_.align_ + 5);
      if ( v3 != v4 )
      {
        do
          operator delete(*v3++);
        while ( v4 != v3 );
        v5 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
        v6 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 5);
        if ( v6 != v5 )
          *((_QWORD *)&node->value_base_.data_.data_.align_ + 5) = v6 + (~(v6 - 8 - v5) & 0xFFFFFFFFFFFFFFF8LL);
      }
      if ( *v2 )
        operator delete(*v2);
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    }
    operator delete(this->node_);
  }
}


// Address: 0x1205ad0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS3_5queueISB_NS3_5dequeISB_NS4_ISB_EEEEEEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,std::queue<std::string>>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::queue<std::string> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::queue<std::string> > > > >::node_pointer node; // r12
  void **v2; // r14
  void **v3; // rbx
  void **v4; // r13
  __int64 v5; // rcx
  __int64 v6; // rax
  boost::unordered::detail::ptr_node<std::pair<const std::string,std::queue<std::string> > > *v7; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (void **)(&node->value_base_.data_.data_.align_ + 3);
      std::__deque_base<std::string>::clear((std::__deque_base<std::string> *)(&node->value_base_.data_.data_.align_ + 3));
      v3 = (void **)*((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
      v4 = (void **)*((_QWORD *)&node->value_base_.data_.data_.align_ + 5);
      if ( v3 != v4 )
      {
        do
          operator delete(*v3++);
        while ( v4 != v3 );
        v5 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
        v6 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 5);
        if ( v6 != v5 )
          *((_QWORD *)&node->value_base_.data_.data_.align_ + 5) = v6 + (~(v6 - 8 - v5) & 0xFFFFFFFFFFFFFFF8LL);
      }
      if ( *v2 )
        operator delete(*v2);
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v7 = (boost::unordered::detail::ptr_node<std::pair<const std::string,std::queue<std::string> > > *)operator new(0x58u);
    this->node_ = v7;
    *((_OWORD *)&v7->value_base_.data_.data_.align_ + 3) = 0;
    *((_OWORD *)&v7->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v7->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v7->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v7->next_ = 0;
    *((_QWORD *)&v7->value_base_.data_.data_.align_ + 8) = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x125b170 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS6_INS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEESB_EENS3_15__list_iteratorINS6_ISC_NS6_ImN3RBX13CachedContentEEEEEPvEEEEEEEEE20construct_with_valueIJSL_EEEvDpOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::CachedContent>>,void *>>>>>::construct_with_value<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::CachedContent>>,void *>>>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::CachedContent> >,void *> > > > > *this,
        std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::CachedContent> >,void *> > *args)
{
  char *node; // rbx

  node = (char *)this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      if ( (node[40] & 1) != 0 )
        operator delete(*((void **)node + 7));
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    node = (char *)operator new(0x48u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::CachedContent> >,void *> > > > >::node_pointer)node;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    *((_QWORD *)node + 8) = 0;
    this->node_constructed_ = 1;
  }
  std::string::basic_string(node + 16, args);
  std::string::basic_string(node + 40, (char *)args + 24);
  *((_QWORD *)node + 8) = *((_QWORD *)args + 6);
  this->value_constructed_ = 1;
}


// Address: 0x12f15c0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS6_INS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEESB_EENS3_15__list_iteratorINS6_ISC_NS6_ImN3RBX13LuaWebService23CachedLuaWebServiceInfoEEEEEPvEEEEEEEEE20construct_with_valueIJSM_EEEvDpOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo>>,void *>>>>>::construct_with_value<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo>>,void *>>>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo> >,void *> > > > > *this,
        std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo> >,void *> > *args)
{
  char *node; // rbx

  node = (char *)this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      if ( (node[40] & 1) != 0 )
        operator delete(*((void **)node + 7));
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    node = (char *)operator new(0x48u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo> >,void *> > > > >::node_pointer)node;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    *((_QWORD *)node + 8) = 0;
    this->node_constructed_ = 1;
  }
  std::string::basic_string(node + 16, args);
  std::string::basic_string(node + 40, (char *)args + 24);
  *((_QWORD *)node + 8) = *((_QWORD *)args + 6);
  this->value_constructed_ = 1;
}


// Address: 0x12f4960 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS6_INS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEESB_EENS3_15__list_iteratorINS6_ISC_NS6_ImN3RBX13LuaWebService26CachedRawLuaWebServiceInfoEEEEEPvEEEEEEEEE20construct_with_valueIJSM_EEEvDpOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo>>,void *>>>>>::construct_with_value<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo>>,void *>>>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo> >,void *> > > > > *this,
        std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo> >,void *> > *args)
{
  char *node; // rbx

  node = (char *)this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      if ( (node[40] & 1) != 0 )
        operator delete(*((void **)node + 7));
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    node = (char *)operator new(0x48u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo> >,void *> > > > >::node_pointer)node;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    *((_QWORD *)node + 8) = 0;
    this->node_constructed_ = 1;
  }
  std::string::basic_string(node + 16, args);
  std::string::basic_string(node + 40, (char *)args + 24);
  *((_QWORD *)node + 8) = *((_QWORD *)args + 6);
  this->value_constructed_ = 1;
}


// Address: 0x134aa00 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX10Soundscape7SoundIdENS3_6vectorINS_8weak_ptrINS8_20PlaybackChannelOwnerEEENS4_ISE_EEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Soundscape::SoundId const,std::vector<boost::weak_ptr<RBX::Soundscape::PlaybackChannelOwner>>>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Soundscape::SoundId,std::vector<boost::weak_ptr<RBX::Soundscape::PlaybackChannelOwner>> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Soundscape::SoundId,std::vector<boost::weak_ptr<RBX::Soundscape::PlaybackChannelOwner>> > > > >::node_pointer node; // r15
  __int64 v3; // r12
  __int64 v4; // rbx
  volatile signed __int32 *v5; // rdi
  void *v6; // rdi

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v3 )
      {
        v4 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
        if ( v4 == v3 )
        {
          v6 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
        }
        else
        {
          do
          {
            v5 = *(volatile signed __int32 **)(v4 - 8);
            if ( v5 && !_InterlockedSub(v5 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
            v4 -= 16;
          }
          while ( v3 != v4 );
          v6 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 4) = v3;
        operator delete(v6);
      }
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    }
    operator delete(this->node_);
  }
}


// Address: 0x134aaa0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX10Soundscape7SoundIdENS3_6vectorINS_8weak_ptrINS8_20PlaybackChannelOwnerEEENS4_ISE_EEEEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Soundscape::SoundId const,std::vector<boost::weak_ptr<RBX::Soundscape::PlaybackChannelOwner>>>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Soundscape::SoundId,std::vector<boost::weak_ptr<RBX::Soundscape::PlaybackChannelOwner>> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Soundscape::SoundId,std::vector<boost::weak_ptr<RBX::Soundscape::PlaybackChannelOwner>> > > > >::node_pointer node; // r15
  __int64 v3; // r12
  __int64 v4; // rbx
  volatile signed __int32 *v5; // rdi
  void *v6; // rdi
  boost::unordered::detail::ptr_node<std::pair<const RBX::Soundscape::SoundId,std::vector<boost::weak_ptr<RBX::Soundscape::PlaybackChannelOwner>> > > *v7; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v3 )
      {
        v4 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
        if ( v4 == v3 )
        {
          v6 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
        }
        else
        {
          do
          {
            v5 = *(volatile signed __int32 **)(v4 - 8);
            if ( v5 && !_InterlockedSub(v5 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
            v4 -= 16;
          }
          while ( v3 != v4 );
          v6 = (void *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 4) = v3;
        operator delete(v6);
      }
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v7 = (boost::unordered::detail::ptr_node<std::pair<const RBX::Soundscape::SoundId,std::vector<boost::weak_ptr<RBX::Soundscape::PlaybackChannelOwner>> > > *)operator new(0x40u);
    this->node_ = v7;
    *((_OWORD *)&v7->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v7->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v7->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v7->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x14068f0 | Name: _ZN3RBX11Constraints13WidgetManagerC2EPNS_9WorkspaceE
void __fastcall RBX::Constraints::WidgetManager::WidgetManager(
        RBX::Constraints::WidgetManager *this,
        RBX::Workspace *workspace)
{
  this->attachments.table_.current_ = 0;
  *(_OWORD *)&this->attachments.table_.bucket_count_ = 0x10u;
  this->attachments.table_.mlf_ = 1.0;
  *(_OWORD *)&this->attachments.table_.max_load_ = 0;
  this->constraints.table_.current_ = 0;
  *(_OWORD *)&this->constraints.table_.bucket_count_ = 0x10u;
  this->constraints.table_.mlf_ = 1.0;
  *(_OWORD *)&this->constraints.table_.max_load_ = 0;
  this->weldConstraints.table_.current_ = 0;
  *(_OWORD *)&this->weldConstraints.table_.bucket_count_ = 0x10u;
  this->weldConstraints.table_.mlf_ = 1.0;
  *(_OWORD *)&this->weldConstraints.table_.max_load_ = 0;
  this->noCollisionConstraints.table_.current_ = 0;
  *(_OWORD *)&this->noCollisionConstraints.table_.bucket_count_ = 0x10u;
  this->noCollisionConstraints.table_.mlf_ = 1.0;
  *(_OWORD *)&this->noCollisionConstraints.table_.max_load_ = 0;
  this->workspace = workspace;
  this->showConstraintDetails = 0;
  this->showWelds = 0;
  this->constraintsDrawOnTop = 0;
  this->constraintWidgetScale = 1.0;
  this->constraintWidgetScaleChanged.head.px = 0;
}


// Address: 0x14f2670 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX11ChatService20UnfilteredTextReportEEEEEEEE20construct_with_valueIJRSB_SF_EEEvDpOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::ChatService::UnfilteredTextReport>>>>::construct_with_value<std::string&,RBX::ChatService::UnfilteredTextReport>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::ChatService::UnfilteredTextReport> > > > *this,
        std::string *args,
        RBX::ChatService::UnfilteredTextReport *a3)
{
  char *node; // rbx
  bool *p_value_constructed; // r13

  node = (char *)this->node_;
  if ( node )
  {
    p_value_constructed = &this->value_constructed_;
    if ( this->value_constructed_ )
    {
      RBX::ChatService::UnfilteredTextReport::~UnfilteredTextReport((RBX::ChatService::UnfilteredTextReport *)(node + 40));
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    p_value_constructed = &this->value_constructed_;
    node = (char *)operator new(0xD0u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::ChatService::UnfilteredTextReport> > > >::node_pointer)node;
    *((_OWORD *)node + 12) = 0;
    *((_OWORD *)node + 11) = 0;
    *((_OWORD *)node + 10) = 0;
    *((_OWORD *)node + 9) = 0;
    *((_OWORD *)node + 8) = 0;
    *((_OWORD *)node + 7) = 0;
    *((_OWORD *)node + 6) = 0;
    *((_OWORD *)node + 5) = 0;
    *((_OWORD *)node + 4) = 0;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    this->node_constructed_ = 1;
  }
  std::string::basic_string(node + 16, args);
  *(_OWORD *)(node + 40) = *(_OWORD *)a3;
  *((_QWORD *)node + 9) = *((_QWORD *)a3 + 4);
  *(_OWORD *)(node + 56) = *((_OWORD *)a3 + 1);
  *((_OWORD *)a3 + 1) = 0;
  *((_QWORD *)a3 + 4) = 0;
  *((_QWORD *)node + 12) = *((_QWORD *)a3 + 7);
  *((_OWORD *)node + 5) = *(_OWORD *)((char *)a3 + 40);
  *(_OWORD *)((char *)a3 + 40) = 0;
  *((_QWORD *)a3 + 7) = 0;
  *((_WORD *)node + 52) = *((_WORD *)a3 + 32);
  *((_QWORD *)node + 16) = *((_QWORD *)a3 + 11);
  *((_OWORD *)node + 7) = *(_OWORD *)((char *)a3 + 72);
  *(_OWORD *)((char *)a3 + 72) = 0;
  *((_QWORD *)a3 + 11) = 0;
  *((_QWORD *)node + 19) = *((_QWORD *)a3 + 14);
  *(_OWORD *)(node + 136) = *((_OWORD *)a3 + 6);
  *((_OWORD *)a3 + 6) = 0;
  *((_QWORD *)a3 + 14) = 0;
  node[160] = 0;
  *(_OWORD *)(node + 168) = *((_OWORD *)a3 + 8);
  *((_DWORD *)node + 46) = *((_DWORD *)a3 + 36);
  *((_OWORD *)node + 12) = *(_OWORD *)((char *)a3 + 152);
  *((_QWORD *)a3 + 17) = 0;
  *(_OWORD *)((char *)a3 + 152) = 0;
  *p_value_constructed = 1;
}


// Address: 0x1545490 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX17CollectionService3TagEEEEEEEE20construct_with_valueIJNS6_ISB_SF_EEEEEvDpOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::CollectionService::Tag>>>>::construct_with_value<std::pair<std::string,RBX::CollectionService::Tag>>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::CollectionService::Tag> > > > *this,
        std::pair<std::string,RBX::CollectionService::Tag> *args)
{
  char *node; // rbx
  bool *p_value_constructed; // r12
  __int128 v4; // xmm1
  __int128 v5; // xmm1

  node = (char *)this->node_;
  if ( node )
  {
    p_value_constructed = &this->value_constructed_;
    if ( this->value_constructed_ )
    {
      RBX::CollectionService::Tag::~Tag((RBX::CollectionService::Tag *)(node + 40));
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    p_value_constructed = &this->value_constructed_;
    node = (char *)operator new(0x78u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::CollectionService::Tag> > > >::node_pointer)node;
    *((_OWORD *)node + 6) = 0;
    *((_OWORD *)node + 5) = 0;
    *((_OWORD *)node + 4) = 0;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    *((_QWORD *)node + 14) = 0;
    this->node_constructed_ = 1;
  }
  *((_QWORD *)node + 4) = *((_QWORD *)args + 2);
  *((_OWORD *)node + 1) = *(_OWORD *)args;
  *(_OWORD *)args = 0;
  *((_QWORD *)args + 2) = 0;
  *((_QWORD *)node + 6) = 0;
  v4 = *(_OWORD *)((char *)args + 24);
  *((_QWORD *)args + 4) = 0;
  *(_OWORD *)(node + 40) = v4;
  *((_QWORD *)args + 3) = 0;
  *((_QWORD *)node + 8) = 0;
  v5 = *(_OWORD *)((char *)args + 40);
  *((_QWORD *)args + 6) = 0;
  *(_OWORD *)(node + 56) = v5;
  *((_QWORD *)args + 5) = 0;
  node[72] = 0;
  *((_OWORD *)node + 5) = *((_OWORD *)args + 4);
  *((_DWORD *)node + 24) = *((_DWORD *)args + 20);
  *(_OWORD *)(node + 104) = *(_OWORD *)((char *)args + 88);
  *((_QWORD *)args + 9) = 0;
  *(_OWORD *)((char *)args + 88) = 0;
  *p_value_constructed = 1;
}


// Address: 0x1545c80 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX17CollectionService3TagEEEEEEEE20construct_with_valueIJRKNS3_21piecewise_construct_tENS3_5tupleIJRSC_EEENSO_IJOSF_EEEEEEvDpOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::CollectionService::Tag>>>>::construct_with_value<std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<RBX::CollectionService::Tag&&>>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::CollectionService::Tag> > > > *this,
        const std::piecewise_construct_t *args,
        std::tuple<const std::string &> *a3,
        std::tuple<RBX::CollectionService::Tag &&> *a4)
{
  char *node; // rbp
  bool *p_value_constructed; // r13
  RBX::CollectionService::Tag *value; // rbx
  boost::shared_ptr<rbx::signal<void (boost::shared_ptr<RBX::Instance>)> > addedSignal; // xmm0
  boost::shared_ptr<rbx::signal<void (boost::shared_ptr<RBX::Instance>)> > removedSignal; // xmm0

  node = (char *)this->node_;
  if ( node )
  {
    p_value_constructed = &this->value_constructed_;
    if ( this->value_constructed_ )
    {
      RBX::CollectionService::Tag::~Tag((RBX::CollectionService::Tag *)(node + 40));
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    p_value_constructed = &this->value_constructed_;
    node = (char *)operator new(0x78u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::CollectionService::Tag> > > >::node_pointer)node;
    *((_OWORD *)node + 6) = 0;
    *((_OWORD *)node + 5) = 0;
    *((_OWORD *)node + 4) = 0;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    *((_QWORD *)node + 14) = 0;
    this->node_constructed_ = 1;
  }
  value = a4->__base_.__value_;
  std::string::basic_string(node + 16, a3->__base_.__value_);
  *((_QWORD *)node + 6) = 0;
  addedSignal = value->addedSignal;
  value->addedSignal.pn.pi_ = 0;
  *(boost::shared_ptr<rbx::signal<void (boost::shared_ptr<RBX::Instance>)> > *)(node + 40) = addedSignal;
  value->addedSignal.px = 0;
  *((_QWORD *)node + 8) = 0;
  removedSignal = value->removedSignal;
  value->removedSignal.pn.pi_ = 0;
  *(boost::shared_ptr<rbx::signal<void (boost::shared_ptr<RBX::Instance>)> > *)(node + 56) = removedSignal;
  value->removedSignal.px = 0;
  node[72] = 0;
  *((_OWORD *)node + 5) = *(_OWORD *)&value->instances.table_.bucket_count_;
  *((_DWORD *)node + 24) = LODWORD(value->instances.table_.mlf_);
  *(_OWORD *)(node + 104) = *(_OWORD *)&value->instances.table_.max_load_;
  value->instances.table_.size_ = 0;
  *(_OWORD *)&value->instances.table_.max_load_ = 0;
  *p_value_constructed = 1;
}


// Address: 0x15a85e0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX9DataModel9FastValueEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::DataModel::FastValue>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::DataModel::FastValue> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::DataModel::FastValue> > > >::node_pointer node; // rbx
  __int64 v2; // rax
  __int64 v3; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 18);
      if ( v2 )
        (*(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *))(v2 + 16))(&node->value_base_.data_.data_.align_ + 19);
      v3 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
      if ( v3 )
        (*(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *))(v3 + 16))(&node->value_base_.data_.data_.align_ + 5);
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    }
    operator delete(this->node_);
  }
}


// Address: 0x15a8660 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX9DataModel9FastValueEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::DataModel::FastValue>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::DataModel::FastValue> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::DataModel::FastValue> > > >::node_pointer node; // rbx
  __int64 v2; // rax
  __int64 v3; // rax
  boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::DataModel::FastValue> > *v4; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 18);
      if ( v2 )
        (*(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *))(v2 + 16))(&node->value_base_.data_.data_.align_ + 19);
      v3 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
      if ( v3 )
        (*(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *))(v3 + 16))(&node->value_base_.data_.data_.align_ + 5);
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v4 = (boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::DataModel::FastValue> > *)operator new(0x110u);
    this->node_ = v4;
    memset(v4, 0, sizeof(boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::DataModel::FastValue> >));
    this->node_constructed_ = 1;
  }
}


// Address: 0x162cfb0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX18InstanceStringDataEEEEEEEE20construct_with_valueIJSF_EEEvDpOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::InstanceStringData>>>>::construct_with_value<std::pair<std::string const,RBX::InstanceStringData>>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::InstanceStringData> > > > *this,
        std::pair<const std::string,RBX::InstanceStringData> *args)
{
  char *node; // rbx
  bool *p_value_constructed; // r12
  volatile signed __int32 *v5; // rdi

  node = (char *)this->node_;
  if ( node )
  {
    p_value_constructed = &this->value_constructed_;
    if ( this->value_constructed_ )
    {
      v5 = (volatile signed __int32 *)*((_QWORD *)node + 6);
      if ( v5 && !_InterlockedSub(v5 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
      if ( (node[16] & 1) != 0 )
        operator delete(*((void **)node + 4));
      this->value_constructed_ = 0;
      node = (char *)this->node_;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    p_value_constructed = &this->value_constructed_;
    node = (char *)operator new(0x40u);
    this->node_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::InstanceStringData> > > >::node_pointer)node;
    *((_OWORD *)node + 3) = 0;
    *((_OWORD *)node + 2) = 0;
    *((_OWORD *)node + 1) = 0;
    *(_OWORD *)node = 0;
    this->node_constructed_ = 1;
  }
  std::string::basic_string(node + 16, args);
  *(_OWORD *)(node + 40) = *(_OWORD *)((char *)args + 24);
  *(_OWORD *)((char *)args + 24) = 0;
  *((_DWORD *)node + 14) = *((_DWORD *)args + 10);
  *p_value_constructed = 1;
}


// Address: 0x162d940 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKPvNS6_INS_8weak_ptrIN3RBX8InstanceEEENS_8functionIFvvEEEEEEEEEEEE21construct_with_value2IRKSH_EEvOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>>>>>::construct_with_value2<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>> const&>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > *this,
        const std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > *a0)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > >::node_pointer node; // r15
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax

  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>>>>>::construct(this);
  node = this->node_;
  *(_OWORD *)node->value_base_.data_.data_.buf = *(_OWORD *)&a0->first;
  pi = a0->second.first.pn.pi_;
  *((_QWORD *)&node->value_base_.data_.data_.align_ + 2) = pi;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  *((_QWORD *)&node->value_base_.data_.data_.align_ + 3) = 0;
  vtable = a0->second.second.vtable;
  if ( vtable )
  {
    *((_QWORD *)&node->value_base_.data_.data_.align_ + 3) = vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      *(boost::detail::function::function_buffer *)(&node->value_base_.data_.data_.align_ + 4) = a0->second.second.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &a0->second.second.functor,
        &node->value_base_.data_.data_.align_ + 4,
        0);
  }
  this->value_constructed_ = 1;
}


// Address: 0x162d9f0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKPvNS6_INS_8weak_ptrIN3RBX8InstanceEEENS_8functionIFvvEEEEEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > >::node_pointer node; // rbx
  __int64 v3; // rax
  void (__fastcall *v4)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64); // rax
  volatile signed __int32 *v5; // rdi
  boost::unordered::detail::ptr_node<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > *v6; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v3 )
      {
        if ( (v3 & 1) == 0 )
        {
          v4 = *(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64))(v3 & 0xFFFFFFFFFFFFFFFELL);
          if ( v4 )
            v4(&node->value_base_.data_.data_.align_ + 4, &node->value_base_.data_.data_.align_ + 4, 2);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 3) = 0;
      }
      v5 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 2);
      if ( v5 )
      {
        if ( !_InterlockedSub(v5 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
      }
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v6 = (boost::unordered::detail::ptr_node<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > *)operator new(0x48u);
    this->node_ = v6;
    *((_OWORD *)&v6->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v6->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v6->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v6->next_ = 0;
    *((_QWORD *)&v6->value_base_.data_.data_.align_ + 6) = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x162dab0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKPvNS6_INS_8weak_ptrIN3RBX8InstanceEEENS_8functionIFvvEEEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > >::node_pointer node; // rbx
  __int64 v3; // rax
  void (__fastcall *v4)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64); // rax
  volatile signed __int32 *v5; // rdi

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v3 )
      {
        if ( (v3 & 1) == 0 )
        {
          v4 = *(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64))(v3 & 0xFFFFFFFFFFFFFFFELL);
          if ( v4 )
            v4(&node->value_base_.data_.data_.align_ + 4, &node->value_base_.data_.data_.align_ + 4, 2);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 3) = 0;
      }
      v5 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 2);
      if ( v5 )
      {
        if ( !_InterlockedSub(v5 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
      }
    }
    operator delete(this->node_);
  }
}


// Address: 0x162e210 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKPvNS_8functionIFvvEEEEEEEEEE21construct_with_value2IRKSC_EEvOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void * const,boost::function<void ()(void)>>>>>::construct_with_value2<std::pair<void * const,boost::function<void ()(void)>> const&>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,boost::function<void ()> > > > > *this,
        const std::pair<void *const,boost::function<void ()> > *a0)
{
  boost::unordered::detail::ptr_node<std::pair<void *const,boost::function<void ()> > > *node; // rbx
  __int64 v3; // rax
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,boost::function<void ()> > > > >::node_pointer v4; // rcx
  void (__fastcall *v5)(char *, char *, __int64, boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,boost::function<void ()> > > > >::node_pointer); // rax
  boost::detail::function::vtable_base *vtable; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v3 )
      {
        v4 = this->node_;
        if ( (v3 & 1) == 0 )
        {
          v5 = *(void (__fastcall **)(char *, char *, __int64, boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<void *const,boost::function<void ()> > > > >::node_pointer))(v3 & 0xFFFFFFFFFFFFFFFELL);
          v4 = this->node_;
          if ( v5 )
          {
            v5(&node->value_base_.data_.data_.buf[16], &node->value_base_.data_.data_.buf[16], 2, v4);
            v4 = this->node_;
          }
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 1) = 0;
        node = v4;
      }
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    node = (boost::unordered::detail::ptr_node<std::pair<void *const,boost::function<void ()> > > *)operator new(0x38u);
    this->node_ = node;
    *((_OWORD *)&node->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)node->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&node->next_ = 0;
    *((_QWORD *)&node->value_base_.data_.data_.align_ + 4) = 0;
    this->node_constructed_ = 1;
  }
  *(_QWORD *)node->value_base_.data_.data_.buf = a0->first;
  *((_QWORD *)&node->value_base_.data_.data_.align_ + 1) = 0;
  vtable = a0->second.vtable;
  if ( vtable )
  {
    *((_QWORD *)&node->value_base_.data_.data_.align_ + 1) = vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      *(boost::detail::function::function_buffer *)(&node->value_base_.data_.data_.align_ + 2) = a0->second.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, char *, _QWORD))((unsigned __int64)vtable
                                                                                         & 0xFFFFFFFFFFFFFFFELL))(
        &a0->second.functor,
        &node->value_base_.data_.data_.buf[16],
        0);
  }
  this->value_constructed_ = 1;
}


// Address: 0x162e7d0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS0_13unordered_mapIPvNS6_INS_8weak_ptrIN3RBX8InstanceEEENS_8functionIFvvEEEEENS_4hashISE_EENS3_8equal_toISE_EENS4_INS6_IKSE_SM_EEEEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,boost::unordered::unordered_map<void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>,boost::hash<void *>,std::equal_to<void *>,std::allocator<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>>>>>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,boost::unordered::unordered_map<void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> >,boost::hash<void *>,std::equal_to<void *>,std::allocator<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,boost::unordered::unordered_map<void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> >,boost::hash<void *>,std::equal_to<void *>,std::allocator<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > > > >::node_pointer node; // r12
  char *v3; // rdi
  bucket *v4; // rbx

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = (char *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 8);
      if ( v3 )
      {
        if ( *((_QWORD *)&node->value_base_.data_.data_.align_ + 5) )
        {
          v4 = (bucket *)&v3[8 * *((_QWORD *)&node->value_base_.data_.data_.align_ + 4)];
          do
            boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>>>,void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>,boost::hash<void *>,std::equal_to<void *>>>::delete_node(
              (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > >,void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> >,boost::hash<void *>,std::equal_to<void *> > > *)(&node->value_base_.data_.data_.align_ + 3),
              v4);
          while ( v4->next_ );
          v3 = (char *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 8);
        }
        operator delete(v3);
        *(_OWORD *)(&node->value_base_.data_.data_.align_ + 7) = 0;
      }
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    }
    operator delete(this->node_);
  }
}


// Address: 0x162e870 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEENS0_13unordered_mapIPvNS6_INS_8weak_ptrIN3RBX8InstanceEEENS_8functionIFvvEEEEENS_4hashISE_EENS3_8equal_toISE_EENS4_INS6_IKSE_SM_EEEEEEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,boost::unordered::unordered_map<void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>,boost::hash<void *>,std::equal_to<void *>,std::allocator<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>>>>>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,boost::unordered::unordered_map<void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> >,boost::hash<void *>,std::equal_to<void *>,std::allocator<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,boost::unordered::unordered_map<void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> >,boost::hash<void *>,std::equal_to<void *>,std::allocator<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > > > >::node_pointer node; // r12
  char *v3; // rdi
  bucket *v4; // rbx
  boost::unordered::detail::ptr_node<std::pair<const std::string,boost::unordered::unordered_map<void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> >,boost::hash<void *>,std::equal_to<void *>,std::allocator<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > > *v5; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = (char *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 8);
      if ( v3 )
      {
        if ( *((_QWORD *)&node->value_base_.data_.data_.align_ + 5) )
        {
          v4 = (bucket *)&v3[8 * *((_QWORD *)&node->value_base_.data_.data_.align_ + 4)];
          do
            boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<void * const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>>>,void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()(void)>>,boost::hash<void *>,std::equal_to<void *>>>::delete_node(
              (boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > >,void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> >,boost::hash<void *>,std::equal_to<void *> > > *)(&node->value_base_.data_.data_.align_ + 3),
              v4);
          while ( v4->next_ );
          v3 = (char *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 8);
        }
        operator delete(v3);
        *(_OWORD *)(&node->value_base_.data_.data_.align_ + 7) = 0;
      }
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v5 = (boost::unordered::detail::ptr_node<std::pair<const std::string,boost::unordered::unordered_map<void *,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> >,boost::hash<void *>,std::equal_to<void *>,std::allocator<std::pair<void *const,std::pair<boost::weak_ptr<RBX::Instance>,boost::function<void ()> > > > > > > *)operator new(0x58u);
    this->node_ = v5;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 3) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v5->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v5->next_ = 0;
    *((_QWORD *)&v5->value_base_.data_.data_.align_ + 8) = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x164e930 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKlN3RBX13FriendService11FriendsListEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<long const,RBX::FriendService::FriendsList>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const long,RBX::FriendService::FriendsList> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const long,RBX::FriendService::FriendsList> > > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      std::__vector_base<std::pair<boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>>>::~__vector_base((std::__vector_base<std::pair<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)>,boost::function<void (std::string)> >> *)(&node->value_base_.data_.data_.align_ + 8));
      if ( (node->value_base_.data_.data_.buf[32] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 6));
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v2 && !_InterlockedSub(v2 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
        if ( !_InterlockedSub(v2 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
      }
    }
    operator delete(this->node_);
  }
}


// Address: 0x164e9b0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKlN3RBX13FriendService11FriendsListEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<long const,RBX::FriendService::FriendsList>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const long,RBX::FriendService::FriendsList> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const long,RBX::FriendService::FriendsList> > > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14
  boost::unordered::detail::ptr_node<std::pair<const long,RBX::FriendService::FriendsList> > *v3; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      std::__vector_base<std::pair<boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>>>::~__vector_base((std::__vector_base<std::pair<boost::function<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)>,boost::function<void (std::string)> >> *)(&node->value_base_.data_.data_.align_ + 8));
      if ( (node->value_base_.data_.data_.buf[32] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 6));
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v2 && !_InterlockedSub(v2 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
        if ( !_InterlockedSub(v2 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
      }
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v3 = (boost::unordered::detail::ptr_node<std::pair<const long,RBX::FriendService::FriendsList> > *)operator new(0x68u);
    this->node_ = v3;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 4) = 0;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 3) = 0;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v3->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v3->next_ = 0;
    *((_QWORD *)&v3->value_base_.data_.data_.align_ + 10) = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x172cc20 | Name: _ZN5boost9unordered6detail11node_holderINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX7KeyCodeENS_10shared_ptrINS7_11InputObjectEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::KeyCode const,boost::shared_ptr<RBX::InputObject>>>>>::~node_holder(
        boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::KeyCode,boost::shared_ptr<RBX::InputObject> > > > > *this)
{
  boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::KeyCode,boost::shared_ptr<RBX::InputObject> > > > >::node_pointer i; // rbx
  volatile signed __int32 *v2; // r15
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::KeyCode,boost::shared_ptr<RBX::InputObject> > > > >::node_pointer node; // rax
  volatile signed __int32 *v4; // rbx

  for ( i = this->nodes_; i; i = this->nodes_ )
  {
    this->nodes_ = (boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::KeyCode,boost::shared_ptr<RBX::InputObject> > > > >::node_pointer)i->next_;
    v2 = (volatile signed __int32 *)*((_QWORD *)&i->value_base_.data_.data_.align_ + 2);
    if ( v2 )
    {
      if ( !_InterlockedSub(v2 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
        if ( !_InterlockedSub(v2 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
      }
    }
    operator delete(i);
  }
  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v4 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 2);
      if ( v4 )
      {
        if ( !_InterlockedSub(v4 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
          if ( !_InterlockedSub(v4 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        }
      }
    }
    operator delete(this->node_);
  }
}


// Address: 0x18c3210 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX8InstanceEEENS_8functionIFvbSA_EEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::Instance> const,boost::function<void ()(bool,boost::shared_ptr<RBX::Instance>)>>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::Instance>,boost::function<void (bool,boost::shared_ptr<RBX::Instance>)> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::Instance>,boost::function<void (bool,boost::shared_ptr<RBX::Instance>)> > > > >::node_pointer node; // rbx
  __int64 v2; // rax
  void (__fastcall *v3)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64); // rax
  volatile signed __int32 *v4; // r14

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 2);
      if ( v2 )
      {
        if ( (v2 & 1) == 0 )
        {
          v3 = *(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64))(v2 & 0xFFFFFFFFFFFFFFFELL);
          if ( v3 )
            v3(&node->value_base_.data_.data_.align_ + 3, &node->value_base_.data_.data_.align_ + 3, 2);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 2) = 0;
      }
      v4 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v4 && !_InterlockedSub(v4 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
        if ( !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
      }
    }
    operator delete(this->node_);
  }
}


// Address: 0x18c32b0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX8InstanceEEENS_8functionIFvbSA_EEEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::Instance> const,boost::function<void ()(bool,boost::shared_ptr<RBX::Instance>)>>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::Instance>,boost::function<void (bool,boost::shared_ptr<RBX::Instance>)> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::Instance>,boost::function<void (bool,boost::shared_ptr<RBX::Instance>)> > > > >::node_pointer node; // rbx
  __int64 v2; // rax
  void (__fastcall *v3)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64); // rax
  volatile signed __int32 *v4; // r14
  boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::Instance>,boost::function<void (bool,boost::shared_ptr<RBX::Instance>)> > > *v5; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 2);
      if ( v2 )
      {
        if ( (v2 & 1) == 0 )
        {
          v3 = *(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64))(v2 & 0xFFFFFFFFFFFFFFFELL);
          if ( v3 )
            v3(&node->value_base_.data_.data_.align_ + 3, &node->value_base_.data_.data_.align_ + 3, 2);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 2) = 0;
      }
      v4 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v4 && !_InterlockedSub(v4 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
        if ( !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
      }
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v5 = (boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::Instance>,boost::function<void (bool,boost::shared_ptr<RBX::Instance>)> > > *)operator new(0x40u);
    this->node_ = v5;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v5->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v5->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x193ff00 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeIN3RBX9TouchPairEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<RBX::TouchPair>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<RBX::TouchPair> > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<RBX::TouchPair> > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14
  volatile signed __int32 *v3; // r14

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v2 )
      {
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
      }
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
        if ( !_InterlockedSub(v3 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      }
    }
    operator delete(this->node_);
  }
}


// Address: 0x193ffa0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeIN3RBX9TouchPairEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<RBX::TouchPair>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<RBX::TouchPair> > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<RBX::TouchPair> > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14
  volatile signed __int32 *v3; // r14
  boost::unordered::detail::ptr_node<RBX::TouchPair> *v4; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v2 )
      {
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
      }
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
        if ( !_InterlockedSub(v3 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      }
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v4 = (boost::unordered::detail::ptr_node<RBX::TouchPair> *)operator new(0x40u);
    this->node_ = v4;
    *((_OWORD *)&v4->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v4->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v4->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v4->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x1b48110 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX11PackageLinkEEENS7_INS8_18RCCPackageListenerEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::PackageLink> const,boost::shared_ptr<RBX::RCCPackageListener>>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::RCCPackageListener> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::RCCPackageListener> > > > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14
  volatile signed __int32 *v3; // r14

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v2 )
      {
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
      }
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
        if ( !_InterlockedSub(v3 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      }
    }
    operator delete(this->node_);
  }
}


// Address: 0x1b481b0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX11PackageLinkEEENS7_INS8_18RCCPackageListenerEEEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::PackageLink> const,boost::shared_ptr<RBX::RCCPackageListener>>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::RCCPackageListener> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::RCCPackageListener> > > > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14
  volatile signed __int32 *v3; // r14
  boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::RCCPackageListener> > > *v4; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v2 )
      {
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
      }
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
        if ( !_InterlockedSub(v3 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      }
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v4 = (boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::RCCPackageListener> > > *)operator new(0x30u);
    this->node_ = v4;
    *((_OWORD *)&v4->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v4->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v4->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x1bf0060 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKPKN3RBX10Reflection18PropertyDescriptorENS7_5Tween10UpdateInfoEEEEEEEE21construct_with_value2IRKSF_EEvOT_
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Reflection::PropertyDescriptor const* const,RBX::Tween::UpdateInfo>>>>::construct_with_value2<std::pair<RBX::Reflection::PropertyDescriptor const* const,RBX::Tween::UpdateInfo> const&>(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Reflection::PropertyDescriptor *const,RBX::Tween::UpdateInfo> > > > *this,
        const std::pair<const RBX::Reflection::PropertyDescriptor *const,RBX::Tween::UpdateInfo> *a0)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Reflection::PropertyDescriptor *const,RBX::Tween::UpdateInfo> > > >::node_pointer node; // r15
  const rbx::implementation::type_holder *holder; // rax
  const rbx::implementation::type_holder *v4; // rax
  boost::detail::function::vtable_base *vtable; // rax

  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Reflection::PropertyDescriptor const* const,RBX::Tween::UpdateInfo>>>>::construct(this);
  node = this->node_;
  *(_QWORD *)node->value_base_.data_.data_.buf = a0->first;
  node->value_base_.data_.data_.buf[8] = a0->second.canUpdate;
  *((_QWORD *)&node->value_base_.data_.data_.align_ + 2) = a0->second.startValue._type;
  *((_QWORD *)&node->value_base_.data_.data_.align_ + 3) = 0;
  holder = a0->second.startValue.value.holder;
  if ( holder )
  {
    holder->construct(a0->second.startValue.value.data, &node->value_base_.data_.data_.buf[32]);
    v4 = a0->second.startValue.value.holder;
  }
  else
  {
    v4 = 0;
  }
  *((_QWORD *)&node->value_base_.data_.data_.align_ + 3) = v4;
  *((_QWORD *)&node->value_base_.data_.data_.align_ + 16) = 0;
  vtable = a0->second.updateFunc.vtable;
  if ( vtable )
  {
    *((_QWORD *)&node->value_base_.data_.data_.align_ + 16) = vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      *(boost::detail::function::function_buffer *)(&node->value_base_.data_.data_.align_ + 17) = a0->second.updateFunc.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &a0->second.updateFunc.functor,
        &node->value_base_.data_.data_.align_ + 17,
        0);
  }
  this->value_constructed_ = 1;
}


// Address: 0x1bf0140 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKPKN3RBX10Reflection18PropertyDescriptorENS7_5Tween10UpdateInfoEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Reflection::PropertyDescriptor const* const,RBX::Tween::UpdateInfo>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Reflection::PropertyDescriptor *const,RBX::Tween::UpdateInfo> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Reflection::PropertyDescriptor *const,RBX::Tween::UpdateInfo> > > >::node_pointer node; // rbx
  __int64 v2; // rax
  void (__fastcall *v3)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64); // rax
  __int64 v4; // rax
  boost::unordered::detail::ptr_node<std::pair<const RBX::Reflection::PropertyDescriptor *const,RBX::Tween::UpdateInfo> > *v5; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 16);
      if ( v2 )
      {
        if ( (v2 & 1) == 0 )
        {
          v3 = *(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *, __int64))(v2 & 0xFFFFFFFFFFFFFFFELL);
          if ( v3 )
            v3(&node->value_base_.data_.data_.align_ + 17, &node->value_base_.data_.data_.align_ + 17, 2);
        }
        *((_QWORD *)&node->value_base_.data_.data_.align_ + 16) = 0;
      }
      v4 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v4 )
        (*(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *))(v4 + 16))(&node->value_base_.data_.data_.align_ + 4);
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v5 = (boost::unordered::detail::ptr_node<std::pair<const RBX::Reflection::PropertyDescriptor *const,RBX::Tween::UpdateInfo> > *)operator new(0xB0u);
    this->node_ = v5;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 9) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 8) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 7) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 6) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 5) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 4) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 3) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v5->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v5->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x1bfbd90 | Name: _ZN3RBX16UserInputService16WindowInputStateC2Ev
void __fastcall RBX::UserInputService::WindowInputState::WindowInputState(
        RBX::UserInputService::WindowInputState *this)
{
  this->newKeyState.table_.current_ = 0;
  *(_OWORD *)&this->newKeyState.table_.bucket_count_ = 0x10u;
  this->newKeyState.table_.mlf_ = 1.0;
  *(_OWORD *)&this->newKeyState.table_.max_load_ = 0;
  this->capsLocked = 0;
  *(_OWORD *)((char *)&this->currentTextBox.pn.pi_ + 4) = 0;
  this->currentTextBox = 0;
}


// Address: 0x1c9af10 | Name: _ZN5boost9unordered6detail11node_holderINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEN3RBX10Reflection7VariantEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Reflection::Variant>>>>::~node_holder(
        boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > > *this)
{
  boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > >::node_pointer i; // rbx
  __int64 v2; // rax
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > >::node_pointer node; // rbx
  __int64 v4; // rax

  for ( i = this->nodes_; i; i = this->nodes_ )
  {
    this->nodes_ = (boost::unordered::detail::node_holder<std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::Reflection::Variant> > > >::node_pointer)i->next_;
    v2 = *((_QWORD *)&i->value_base_.data_.data_.align_ + 4);
    if ( v2 )
      (*(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *))(v2 + 16))(&i->value_base_.data_.data_.align_ + 5);
    if ( (i->value_base_.data_.data_.buf[0] & 1) != 0 )
      operator delete(*((void **)&i->value_base_.data_.data_.align_ + 2));
    operator delete(i);
  }
  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v4 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
      if ( v4 )
        (*(void (__fastcall **)(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *))(v4 + 16))(&node->value_base_.data_.data_.align_ + 5);
      if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    }
    operator delete(this->node_);
  }
}


// Address: 0x1cd9d90 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX11InputObjectEEENS_8weak_ptrINS8_8InstanceEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::InputObject> const,boost::weak_ptr<RBX::Instance>>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::InputObject>,boost::weak_ptr<RBX::Instance> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::InputObject>,boost::weak_ptr<RBX::Instance> > > > >::node_pointer node; // rbx
  volatile signed __int32 *v3; // rdi
  volatile signed __int32 *v4; // r14

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v3 && !_InterlockedSub(v3 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      v4 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v4 && !_InterlockedSub(v4 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
        if ( !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
      }
    }
    operator delete(this->node_);
  }
}


// Address: 0x1cd9e10 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKNS_10shared_ptrIN3RBX11InputObjectEEENS_8weak_ptrINS8_8InstanceEEEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::InputObject> const,boost::weak_ptr<RBX::Instance>>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::InputObject>,boost::weak_ptr<RBX::Instance> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::InputObject>,boost::weak_ptr<RBX::Instance> > > > >::node_pointer node; // rbx
  volatile signed __int32 *v3; // rdi
  volatile signed __int32 *v4; // r14
  boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::InputObject>,boost::weak_ptr<RBX::Instance> > > *v5; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
      if ( v3 && !_InterlockedSub(v3 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      v4 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v4 && !_InterlockedSub(v4 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
        if ( !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
      }
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v5 = (boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::InputObject>,boost::weak_ptr<RBX::Instance> > > *)operator new(0x30u);
    this->node_ = v5;
    *((_OWORD *)&v5->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v5->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v5->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x1d42a60 | Name: _ZNK3RBX8Instance20getOverrideInstancesEPKNS_10Reflection18PropertyDescriptorE
RBX::Instance::OverrideInstanceMap *__fastcall RBX::Instance::getOverrideInstances(
        RBX::Instance::OverrideInstanceMap *__return_ptr retstr,
        const RBX::Instance *this,
        const RBX::Reflection::PropertyDescriptor *p)
{
  retstr->table_.current_ = 0;
  *(_OWORD *)&retstr->table_.bucket_count_ = 0x10u;
  retstr->table_.mlf_ = 1.0;
  *(_OWORD *)&retstr->table_.max_load_ = 0;
  return retstr;
}


// Address: 0x1f1eec0 | Name: _ZN5LuaVM22getBytecodeCoreModulesEv
LuaVM::ScriptsMap *__cdecl LuaVM::getBytecodeCoreModules(LuaVM::ScriptsMap *__return_ptr retstr)
{
  retstr->table_.current_ = 0;
  *(_OWORD *)&retstr->table_.bucket_count_ = 0x10u;
  retstr->table_.mlf_ = 1.0;
  *(_OWORD *)&retstr->table_.max_load_ = 0;
  return retstr;
}


// Address: 0x1f1eef0 | Name: _ZN5LuaVM24getBytecodePlayerScriptsEv
LuaVM::ScriptsMap *__cdecl LuaVM::getBytecodePlayerScripts(LuaVM::ScriptsMap *__return_ptr retstr)
{
  retstr->table_.current_ = 0;
  *(_OWORD *)&retstr->table_.bucket_count_ = 0x10u;
  retstr->table_.mlf_ = 1.0;
  *(_OWORD *)&retstr->table_.max_load_ = 0;
  return retstr;
}


// Address: 0x1fe3dd0 | Name: _ZN5boost9unordered6detail16node_constructorINS_19fast_pool_allocatorINS1_8ptr_nodeINSt3__14pairIKPN3RBX7GfxPartENS7_8Graphics12SceneUpdater12GfxPartEntryEEEEENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<RBX::GfxPart * const,RBX::Graphics::SceneUpdater::GfxPartEntry>>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~node_constructor(
        boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<RBX::GfxPart *const,RBX::Graphics::SceneUpdater::GfxPartEntry> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this)
{
  boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<RBX::GfxPart *const,RBX::Graphics::SceneUpdater::GfxPartEntry> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> >::node_pointer node; // rbx
  __int64 v2; // rax
  _QWORD *v3; // rcx

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = *((_QWORD *)&node->value_base_.data_.data_.align_ + 1);
      if ( v2 )
      {
        v3 = (_QWORD *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 2);
        *v3 = v2;
        *(_QWORD *)(v2 + 8) = v3;
        *(_OWORD *)(&node->value_base_.data_.data_.align_ + 1) = 0;
        node = this->node_;
      }
    }
    if ( !byte_29FE161 )
    {
      byte_29FE161 = 1;
      boost::mutex::mutex(&stru_29FDFF0);
      *(_OWORD *)&stru_29FE018.first = 0;
      stru_29FE018.list.sz = 0;
      *(_OWORD *)&stru_29FE018.requested_size = xmmword_3EA050;
      *(_OWORD *)&stru_29FE018.start_size = 0x20u;
    }
    boost::mutex::lock(&stru_29FDFF0);
    node->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)stru_29FE018.first;
    stru_29FE018.first = node;
    boost::mutex::unlock(&stru_29FDFF0);
  }
}


// Address: 0x1fe8340 | Name: _ZN5boost9unordered6detail16node_constructorINS_19fast_pool_allocatorINS1_8ptr_nodeINSt3__14pairIKN3RBX8Graphics16SpatialGridIndexENS8_11SpatialGridINS8_17InstancedCluster2EE4CellEEEEENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Graphics::SpatialGridIndex const,RBX::Graphics::SpatialGrid<RBX::Graphics::InstancedCluster2>::Cell>>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~node_constructor(
        boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::SpatialGridIndex,RBX::Graphics::SpatialGrid<RBX::Graphics::InstancedCluster2>::Cell> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this)
{
  boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::SpatialGridIndex,RBX::Graphics::SpatialGrid<RBX::Graphics::InstancedCluster2>::Cell> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> >::node_pointer node; // rbx

  node = this->node_;
  if ( node )
  {
    if ( !byte_29FE160 )
    {
      byte_29FE160 = 1;
      boost::mutex::mutex(&stru_29FDF78);
      *(_OWORD *)&stru_29FDFA0.first = 0;
      stru_29FDFA0.list.sz = 0;
      *(_OWORD *)&stru_29FDFA0.requested_size = xmmword_3EADD0;
      *(_OWORD *)&stru_29FDFA0.start_size = 0x20u;
    }
    boost::mutex::lock(&stru_29FDF78);
    node->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)stru_29FDFA0.first;
    stru_29FDFA0.first = node;
    boost::mutex::unlock(&stru_29FDF78);
  }
}


// Address: 0x1fe8c80 | Name: _ZN5boost9unordered6detail16node_constructorINS_19fast_pool_allocatorINS1_8ptr_nodeINSt3__14pairIKN3RBX8Graphics16SpatialGridIndexENS8_11SpatialGridINS8_12SuperClusterEE4CellEEEEENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Graphics::SpatialGridIndex const,RBX::Graphics::SpatialGrid<RBX::Graphics::SuperCluster>::Cell>>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~node_constructor(
        boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::SpatialGridIndex,RBX::Graphics::SpatialGrid<RBX::Graphics::SuperCluster>::Cell> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this)
{
  boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::SpatialGridIndex,RBX::Graphics::SpatialGrid<RBX::Graphics::SuperCluster>::Cell> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> >::node_pointer node; // rbx

  node = this->node_;
  if ( node )
  {
    if ( !byte_29FE160 )
    {
      byte_29FE160 = 1;
      boost::mutex::mutex(&stru_29FDF78);
      *(_OWORD *)&stru_29FDFA0.first = 0;
      stru_29FDFA0.list.sz = 0;
      *(_OWORD *)&stru_29FDFA0.requested_size = xmmword_3EADD0;
      *(_OWORD *)&stru_29FDFA0.start_size = 0x20u;
    }
    boost::mutex::lock(&stru_29FDF78);
    node->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)stru_29FDFA0.first;
    stru_29FDFA0.first = node;
    boost::mutex::unlock(&stru_29FDF78);
  }
}


// Address: 0x205a080 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX8Graphics17InstancedCluster23KeyEPNS8_16InstancedEntity2EEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Graphics::InstancedCluster2::Key const,RBX::Graphics::InstancedEntity2 *>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *> > > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14
  volatile signed __int32 *v3; // r14

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
      if ( v2 )
      {
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
      }
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 2);
      if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
        if ( !_InterlockedSub(v3 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      }
    }
    operator delete(this->node_);
  }
}


// Address: 0x205a120 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX8Graphics17InstancedCluster23KeyEPNS8_16InstancedEntity2EEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Graphics::InstancedCluster2::Key const,RBX::Graphics::InstancedEntity2 *>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *> > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *> > > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14
  volatile signed __int32 *v3; // r14
  boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *> > *v4; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
      if ( v2 )
      {
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
      }
      v3 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 2);
      if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
        if ( !_InterlockedSub(v3 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      }
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v4 = (boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *> > *)operator new(0x40u);
    this->node_ = v4;
    *((_OWORD *)&v4->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v4->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v4->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v4->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x2069550 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX8Graphics8MeshDescENS_10shared_ptrINS8_12MeshResourceEEEEEEEEEED2Ev
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Graphics::MeshDesc const,boost::shared_ptr<RBX::Graphics::MeshResource>>>>>::~node_constructor(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::MeshDesc,boost::shared_ptr<RBX::Graphics::MeshResource> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::MeshDesc,boost::shared_ptr<RBX::Graphics::MeshResource> > > > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 11);
      if ( v2 )
      {
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
      }
      if ( (node->value_base_.data_.data_.buf[40] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 7));
      if ( (node->value_base_.data_.data_.buf[8] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 3));
    }
    operator delete(this->node_);
  }
}


// Address: 0x20695d0 | Name: _ZN5boost9unordered6detail16node_constructorINSt3__19allocatorINS1_8ptr_nodeINS3_4pairIKN3RBX8Graphics8MeshDescENS_10shared_ptrINS8_12MeshResourceEEEEEEEEEE9constructEv
void __fastcall boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::Graphics::MeshDesc const,boost::shared_ptr<RBX::Graphics::MeshResource>>>>>::construct(
        boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::MeshDesc,boost::shared_ptr<RBX::Graphics::MeshResource> > > > > *this)
{
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::MeshDesc,boost::shared_ptr<RBX::Graphics::MeshResource> > > > >::node_pointer node; // rbx
  volatile signed __int32 *v2; // r14
  boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::MeshDesc,boost::shared_ptr<RBX::Graphics::MeshResource> > > *v3; // rax

  node = this->node_;
  if ( node )
  {
    if ( this->value_constructed_ )
    {
      v2 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 11);
      if ( v2 )
      {
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
      }
      if ( (node->value_base_.data_.data_.buf[40] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 7));
      if ( (node->value_base_.data_.data_.buf[8] & 1) != 0 )
        operator delete(*((void **)&node->value_base_.data_.data_.align_ + 3));
      this->value_constructed_ = 0;
    }
  }
  else
  {
    *(_WORD *)&this->node_constructed_ = 0;
    v3 = (boost::unordered::detail::ptr_node<std::pair<const RBX::Graphics::MeshDesc,boost::shared_ptr<RBX::Graphics::MeshResource> > > *)operator new(0x70u);
    this->node_ = v3;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 5) = 0;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 4) = 0;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 3) = 0;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 2) = 0;
    *((_OWORD *)&v3->value_base_.data_.data_.align_ + 1) = 0;
    *(_OWORD *)v3->value_base_.data_.data_.buf = 0;
    *(_OWORD *)&v3->next_ = 0;
    this->node_constructed_ = 1;
  }
}


// Address: 0x20864c0 | Name: _ZN3RBX8Graphics17MaterialGenerator21TexturedMaterialCacheC2Ev
void __fastcall RBX::Graphics::MaterialGenerator::TexturedMaterialCache::TexturedMaterialCache(
        RBX::Graphics::MaterialGenerator::TexturedMaterialCache *this)
{
  *(_BYTE *)this = 0;
  *(_OWORD *)((char *)this + 8) = 0x10u;
  *((_DWORD *)this + 6) = 1065353216;
  *((_OWORD *)this + 4) = 0;
  *((_OWORD *)this + 3) = 0;
  *((_OWORD *)this + 2) = 0;
}


