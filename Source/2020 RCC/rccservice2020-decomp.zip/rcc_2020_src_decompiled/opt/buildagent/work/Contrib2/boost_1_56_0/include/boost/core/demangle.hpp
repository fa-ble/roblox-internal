// Address: 0xdc14e0 | Name: _ZN5boost4core8demangleEPKc
boost::core *__fastcall boost::core::demangle(boost::core *this, const char *a2)
{
  char *v2; // rax
  char *v3; // r14
  size_t v4; // rax
  size_t v5; // r15
  char *v6; // rbx
  size_t v7; // rax
  size_t v8; // r13
  char *v9; // rbx
  size_t v10; // r13
  char *v11; // rbx
  size_t v12; // rbp
  struct _Unwind_Exception *v14; // rbx
  int status; // [rsp+Ch] [rbp-3Ch] BYREF
  size_t outlen[7]; // [rsp+10h] [rbp-38h] BYREF

  status = 0;
  outlen[0] = 0;
  v2 = __cxa_demangle(a2, 0, outlen, &status);
  v3 = v2;
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  if ( !v2 )
  {
    v7 = strlen(a2);
    if ( v7 >= 0xFFFFFFFFFFFFFFF0LL )
      goto LABEL_18;
    v8 = v7;
    if ( v7 >= 0x17 )
    {
      v12 = (v7 + 16) & 0xFFFFFFFFFFFFFFF0LL;
      v9 = (char *)operator new(v12);
      *((_QWORD *)this + 2) = v9;
      *(_QWORD *)this = v12 | 1;
      *((_QWORD *)this + 1) = v8;
    }
    else
    {
      *(_BYTE *)this = 2 * v7;
      v9 = (char *)this + 1;
      if ( !v7 )
        goto LABEL_15;
    }
    memcpy(v9, a2, v8);
LABEL_15:
    v11 = &v9[v8];
    goto LABEL_16;
  }
  v4 = strlen(v2);
  if ( v4 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(this);
LABEL_18:
    v14 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(this);
    free(v3);
    _Unwind_Resume(v14);
  }
  v5 = v4;
  if ( v4 >= 0x17 )
  {
    v10 = (v4 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v6 = (char *)operator new(v10);
    *((_QWORD *)this + 2) = v6;
    *(_QWORD *)this = v10 | 1;
    *((_QWORD *)this + 1) = v5;
  }
  else
  {
    *(_BYTE *)this = 2 * v4;
    v6 = (char *)this + 1;
    if ( !v4 )
      goto LABEL_12;
  }
  memcpy(v6, v3, v5);
LABEL_12:
  v11 = &v6[v5];
LABEL_16:
  *v11 = 0;
  free(v3);
  return this;
}


