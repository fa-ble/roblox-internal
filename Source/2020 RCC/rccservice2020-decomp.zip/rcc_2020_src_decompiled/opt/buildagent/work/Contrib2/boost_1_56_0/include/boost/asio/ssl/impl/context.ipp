// Address: 0x25f4020 | Name: _ZN5boost4asio3ssl7contextC2ENS1_12context_base6methodE
void __fastcall boost::asio::ssl::context::context(
        boost::asio::ssl::context *this,
        boost::asio::ssl::context_base::method m)
{
  boost::asio::ssl::detail::openssl_init<true> *p_init; // rdi
  std::shared_ptr<boost::asio::ssl::detail::openssl_init_base::do_init> v4; // rax
  __int64 v5; // rax
  SSL_CTX *v6; // rax
  __int64 v7; // rax
  __int64 v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rax
  __int64 v15; // rax
  __int64 v16; // rax
  __int64 v17; // rax
  int error; // ebx
  const boost::system::error_category *v19; // rbx
  const boost::system::error_category *v20; // rbx
  _QWORD v21[2]; // [rsp+0h] [rbp-58h] BYREF
  int v22; // [rsp+10h] [rbp-48h]
  void (__fastcall ***v23)(boost::system::error_category *__hidden); // [rsp+18h] [rbp-40h]
  __int128 v24; // [rsp+20h] [rbp-38h]
  void *ptr; // [rsp+30h] [rbp-28h]

  this->handle_ = 0;
  p_init = &this->init_;
  v4 = boost::asio::ssl::detail::openssl_init_base::instance();
  switch ( m )
  {
    case boost::asio::ssl::context_base::method::sslv2:
    case boost::asio::ssl::context_base::method::sslv2_client:
    case boost::asio::ssl::context_base::method::sslv2_server:
      v19 = boost::system::system_category();
      std::runtime_error::runtime_error((std::runtime_error *)v21, "context");
      v21[0] = off_2875F00;
      v22 = 22;
      v23 = (void (__fastcall ***)(boost::system::error_category *__hidden))v19;
      v24 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v21);
    case boost::asio::ssl::context_base::method::sslv3:
    case boost::asio::ssl::context_base::method::sslv3_client:
    case boost::asio::ssl::context_base::method::sslv3_server:
      v20 = boost::system::system_category();
      std::runtime_error::runtime_error((std::runtime_error *)v21, "context");
      v21[0] = off_2875F00;
      v22 = 22;
      v23 = (void (__fastcall ***)(boost::system::error_category *__hidden))v20;
      v24 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v21);
    case boost::asio::ssl::context_base::method::tlsv1:
      v5 = TLSv1_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v5);
      break;
    case boost::asio::ssl::context_base::method::tlsv1_client:
      v14 = TLSv1_client_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v14);
      break;
    case boost::asio::ssl::context_base::method::tlsv1_server:
      v12 = TLSv1_server_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v12);
      break;
    case boost::asio::ssl::context_base::method::sslv23:
      v8 = TLS_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v8);
      break;
    case boost::asio::ssl::context_base::method::sslv23_client:
      v9 = TLS_client_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v9);
      break;
    case boost::asio::ssl::context_base::method::sslv23_server:
      v16 = TLS_server_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v16);
      break;
    case boost::asio::ssl::context_base::method::tlsv11:
      v10 = TLSv1_1_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v10);
      break;
    case boost::asio::ssl::context_base::method::tlsv11_client:
      v11 = TLSv1_1_client_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v11);
      break;
    case boost::asio::ssl::context_base::method::tlsv11_server:
      v17 = TLSv1_1_server_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v17);
      break;
    case boost::asio::ssl::context_base::method::tlsv12:
      v13 = TLSv1_2_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v13);
      break;
    case boost::asio::ssl::context_base::method::tlsv12_client:
      v7 = TLSv1_2_client_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v7);
      break;
    case boost::asio::ssl::context_base::method::tlsv12_server:
      v15 = TLSv1_2_server_method(p_init, m, v4.__cntrl_);
      v6 = (SSL_CTX *)SSL_CTX_new(v15);
      break;
    default:
      v6 = (SSL_CTX *)SSL_CTX_new(0);
      break;
  }
  this->handle_ = v6;
  if ( !v6 )
  {
    error = ERR_get_error();
    if ( (_BYTE)byte_2B114E8 || !__cxa_guard_acquire(&byte_2B114E8) )
    {
      if ( error )
        goto LABEL_20;
    }
    else
    {
      __cxa_guard_release(&byte_2B114E8);
      if ( error )
      {
LABEL_20:
        std::runtime_error::runtime_error((std::runtime_error *)v21, "context");
        v21[0] = off_2875F00;
        v22 = error;
        v23 = off_2870A10;
        v24 = 0;
        ptr = 0;
        boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v21);
      }
    }
  }
  boost::system::system_category();
  SSL_CTX_set_options(this->handle_, 0x20000);
  boost::system::system_category();
}


// Address: 0x25f42c0 | Name: _ZN5boost4asio3ssl7context24set_default_verify_pathsEv
void __fastcall boost::asio::ssl::context::set_default_verify_paths(boost::asio::ssl::context *this)
{
  int error; // ebx
  _QWORD v2[2]; // [rsp+8h] [rbp-50h] BYREF
  int v3; // [rsp+18h] [rbp-40h]
  void (__fastcall ***v4)(boost::system::error_category *__hidden); // [rsp+20h] [rbp-38h]
  __int128 v5; // [rsp+28h] [rbp-30h]
  void *ptr; // [rsp+38h] [rbp-20h]

  boost::system::system_category();
  if ( (unsigned int)SSL_CTX_set_default_verify_paths(this->handle_) == 1 )
  {
    boost::system::system_category();
    return;
  }
  error = ERR_get_error();
  if ( (_BYTE)byte_2B114E8 || !__cxa_guard_acquire(&byte_2B114E8) )
  {
    if ( error )
      goto LABEL_8;
  }
  else
  {
    __cxa_guard_release(&byte_2B114E8);
    if ( error )
    {
LABEL_8:
      std::runtime_error::runtime_error((std::runtime_error *)v2, "set_default_verify_paths");
      v2[0] = off_2875F00;
      v3 = error;
      v4 = off_2870A10;
      v5 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v2);
    }
  }
}


// Address: 0x25f4ed0 | Name: _ZN5boost4asio3ssl7contextD2Ev
void __fastcall boost::asio::ssl::context::~context(boost::asio::ssl::context *this)
{
  boost::asio::ssl::context::native_handle_type handle; // rdi
  __int64 default_passwd_cb_userdata; // rax
  __int64 v4; // rax
  volatile signed __int64 *cntrl; // rbx

  handle = this->handle_;
  if ( handle )
  {
    default_passwd_cb_userdata = SSL_CTX_get_default_passwd_cb_userdata(handle);
    if ( default_passwd_cb_userdata )
    {
      (*(void (__fastcall **)(__int64))(*(_QWORD *)default_passwd_cb_userdata + 8LL))(default_passwd_cb_userdata);
      SSL_CTX_set_default_passwd_cb_userdata(this->handle_, 0);
    }
    if ( SSL_CTX_get_ex_data(this->handle_, 0) )
    {
      v4 = SSL_CTX_get_ex_data(this->handle_, 0);
      if ( v4 )
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(v4);
      SSL_CTX_set_ex_data(this->handle_, 0, 0);
    }
    SSL_CTX_free(this->handle_);
  }
  cntrl = (volatile signed __int64 *)this->init_.ref_.__cntrl_;
  if ( cntrl )
  {
    if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
  }
}


// Address: 0x25f5030 | Name: _ZN5boost4asio3ssl7context24verify_callback_functionEiP17x509_store_ctx_st
int __fastcall boost::asio::ssl::context::verify_callback_function(int preverified, X509_STORE_CTX *ctx)
{
  X509_STORE_CTX *v2; // rax
  int v3; // ebp
  unsigned int v4; // eax
  __int64 v5; // rax
  __int64 SSL_CTX; // rax
  __int64 v7; // r15
  __int64 v8; // rax
  X509_STORE_CTX *v10; // [rsp+0h] [rbp-28h] BYREF

  v10 = v2;
  v3 = 0;
  if ( ctx )
  {
    v4 = SSL_get_ex_data_X509_STORE_CTX_idx(preverified);
    v5 = X509_STORE_CTX_get_ex_data(ctx, v4);
    if ( v5 )
    {
      SSL_CTX = SSL_get_SSL_CTX(v5);
      if ( SSL_CTX )
      {
        v7 = SSL_CTX;
        v3 = 0;
        if ( SSL_CTX_get_ex_data(SSL_CTX, 0) )
        {
          v8 = SSL_CTX_get_ex_data(v7, 0);
          v10 = ctx;
          return (*(unsigned __int8 (__fastcall **)(__int64, bool, X509_STORE_CTX **))(*(_QWORD *)v8 + 16LL))(
                   v8,
                   preverified != 0,
                   &v10);
        }
      }
    }
  }
  return v3;
}


