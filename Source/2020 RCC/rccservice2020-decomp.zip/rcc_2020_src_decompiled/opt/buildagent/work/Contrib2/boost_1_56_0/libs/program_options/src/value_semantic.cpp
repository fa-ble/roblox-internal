// Address: 0xe63720 | Name: _ZNK5boost15program_options29value_semantic_codecvt_helperIcE5parseERNS_3anyERKNSt3__16vectorINS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENSA_ISC_EEEEb
void __fastcall boost::program_options::value_semantic_codecvt_helper<char>::parse(
        const boost::program_options::value_semantic_codecvt_helper<char> *this,
        boost::any_0 *value_store,
        const std::vector<std::string> *new_tokens,
        bool utf8)
{
  __int64 v5; // rax
  unsigned int v6; // r14d
  unsigned __int64 v7; // rcx
  _OWORD *v8; // rax
  void **v9; // rbx
  void **v10; // rax
  void **v11; // rbp
  void *v12; // rdi
  void *v13[2]; // [rsp+0h] [rbp-88h] BYREF
  std::locale v14; // [rsp+10h] [rbp-78h]
  int v15[4]; // [rsp+20h] [rbp-68h] BYREF
  void *ptr; // [rsp+30h] [rbp-58h]
  boost::any_0 *v17; // [rsp+38h] [rbp-50h]
  int v18; // [rsp+40h] [rbp-48h] BYREF
  void *v19; // [rsp+50h] [rbp-38h]

  if ( utf8 )
  {
    v17 = value_store;
    *(_OWORD *)v13 = 0;
    v14.__locale_ = 0;
    v5 = *(_QWORD *)new_tokens;
    if ( *((_QWORD *)new_tokens + 1) != *(_QWORD *)new_tokens )
    {
      v6 = 1;
      v7 = 0;
      do
      {
        boost::from_utf8((const std::string *)(v5 + 24 * v7));
        boost::to_local_8_bit((int)v15, (int)&v18, (int)v13[0], (int)v13[1], v14);
        v8 = v13[1];
        if ( v13[1] >= v14.__locale_ )
        {
          std::vector<std::string>::__push_back_slow_path<std::string>(
            (std::vector<std::string> *)v13,
            (std::string *)v15);
          if ( (v15[0] & 1) != 0 )
            operator delete(ptr);
          if ( (v18 & 1) == 0 )
            goto LABEL_11;
        }
        else
        {
          *((_QWORD *)v13[1] + 2) = ptr;
          *v8 = *(_OWORD *)v15;
          *(_OWORD *)v15 = 0;
          ptr = 0;
          v13[1] = (char *)v13[1] + 24;
          if ( (v18 & 1) == 0 )
            goto LABEL_11;
        }
        operator delete(v19);
LABEL_11:
        v7 = v6;
        v5 = *(_QWORD *)new_tokens;
        ++v6;
      }
      while ( 0xAAAAAAAAAAAAAAABLL * ((__int64)(*((_QWORD *)new_tokens + 1) - *(_QWORD *)new_tokens) >> 3) > v7 );
    }
    (*((void (__fastcall **)(const boost::program_options::value_semantic_codecvt_helper<char> *, boost::any_0 *, void **))this->_vptr$value_semantic
     + 10))(
      this,
      v17,
      v13);
    v9 = (void **)v13[0];
    if ( v13[0] )
    {
      v10 = (void **)v13[1];
      if ( v13[1] == v13[0] )
      {
        v12 = v13[0];
      }
      else
      {
        do
        {
          v11 = v10 - 3;
          if ( (*(_BYTE *)(v10 - 3) & 1) != 0 )
            operator delete(*(v10 - 1));
          v10 = v11;
        }
        while ( v9 != v11 );
        v12 = v13[0];
      }
      v13[1] = v9;
      operator delete(v12);
    }
  }
  else
  {
    (*((void (__fastcall **)(const boost::program_options::value_semantic_codecvt_helper<char> *, boost::any_0 *, const std::vector<std::string> *))this->_vptr$value_semantic
     + 10))(
      this,
      value_store,
      new_tokens);
  }
}


// Address: 0xe63950 | Name: _ZNK5boost15program_options29value_semantic_codecvt_helperIwE5parseERNS_3anyERKNSt3__16vectorINS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENSA_ISC_EEEEb
void __fastcall boost::program_options::value_semantic_codecvt_helper<wchar_t>::parse(
        const boost::program_options::value_semantic_codecvt_helper<wchar_t> *this,
        boost::any_0 *value_store,
        const std::vector<std::string> *new_tokens,
        bool utf8)
{
  __int64 v5; // rsi
  __int64 v6; // rax
  unsigned int v7; // ebp
  unsigned __int64 v8; // rax
  _OWORD *v9; // rax
  unsigned int v10; // ebp
  unsigned __int64 v11; // rcx
  _OWORD *v12; // rax
  void **v13; // rbx
  void **v14; // rax
  void **v15; // rbp
  void *v16; // rdi
  void *v17[2]; // [rsp+0h] [rbp-78h] BYREF
  void *v18; // [rsp+10h] [rbp-68h]
  __int128 v19; // [rsp+20h] [rbp-58h] BYREF
  void *ptr; // [rsp+30h] [rbp-48h]
  boost::any_0 *v21; // [rsp+40h] [rbp-38h]

  v21 = value_store;
  *(_OWORD *)v17 = 0;
  v18 = 0;
  v5 = *(_QWORD *)new_tokens;
  v6 = *((_QWORD *)new_tokens + 1);
  if ( utf8 )
  {
    if ( v6 != v5 )
    {
      v7 = 1;
      v8 = 0;
      do
      {
        boost::from_utf8((const std::string *)(v5 + 24 * v8));
        v9 = v17[1];
        if ( v17[1] >= v18 )
        {
          std::vector<std::wstring>::__push_back_slow_path<std::wstring>(
            (std::vector<std::wstring> *)v17,
            (std::wstring *)&v19);
          if ( (v19 & 1) != 0 )
            operator delete(ptr);
        }
        else
        {
          *((_QWORD *)v17[1] + 2) = ptr;
          *v9 = v19;
          v19 = 0;
          ptr = 0;
          v17[1] = (char *)v17[1] + 24;
        }
        v8 = v7;
        v5 = *(_QWORD *)new_tokens;
        ++v7;
      }
      while ( 0xAAAAAAAAAAAAAAABLL * ((__int64)(*((_QWORD *)new_tokens + 1) - *(_QWORD *)new_tokens) >> 3) > v8 );
    }
  }
  else if ( v6 != v5 )
  {
    v10 = 1;
    v11 = 0;
    do
    {
      boost::from_local_8_bit((const std::string *)(v5 + 24 * v11));
      v12 = v17[1];
      if ( v17[1] >= v18 )
      {
        std::vector<std::wstring>::__push_back_slow_path<std::wstring>(
          (std::vector<std::wstring> *)v17,
          (std::wstring *)&v19);
        if ( (v19 & 1) != 0 )
          operator delete(ptr);
      }
      else
      {
        *((_QWORD *)v17[1] + 2) = ptr;
        *v12 = v19;
        v19 = 0;
        ptr = 0;
        v17[1] = (char *)v17[1] + 24;
      }
      v11 = v10;
      v5 = *(_QWORD *)new_tokens;
      ++v10;
    }
    while ( 0xAAAAAAAAAAAAAAABLL * ((__int64)(*((_QWORD *)new_tokens + 1) - *(_QWORD *)new_tokens) >> 3) > v11 );
  }
  (*((void (__fastcall **)(const boost::program_options::value_semantic_codecvt_helper<wchar_t> *, boost::any_0 *, void **))this->_vptr$value_semantic
   + 10))(
    this,
    v21,
    v17);
  v13 = (void **)v17[0];
  if ( v17[0] )
  {
    v14 = (void **)v17[1];
    if ( v17[1] == v17[0] )
    {
      v16 = v17[0];
    }
    else
    {
      do
      {
        v15 = v14 - 3;
        if ( (*(_BYTE *)(v14 - 3) & 1) != 0 )
          operator delete(*(v14 - 1));
        v14 = v15;
      }
      while ( v13 != v15 );
      v16 = v17[0];
    }
    v17[1] = v13;
    operator delete(v16);
  }
}


// Address: 0xe63bd0 | Name: _ZNK5boost15program_options13untyped_value4nameEv
boost::program_options::untyped_value *__fastcall boost::program_options::untyped_value::name(
        boost::program_options::untyped_value *this)
{
  std::string::basic_string(this, &xmmword_29F20D0);
  return this;
}


// Address: 0xe63bf0 | Name: _ZNK5boost15program_options13untyped_value10min_tokensEv
unsigned int __fastcall boost::program_options::untyped_value::min_tokens(
        const boost::program_options::untyped_value *this)
{
  return !this->m_zero_tokens;
}


// Address: 0xe63c00 | Name: _ZNK5boost15program_options13untyped_value10max_tokensEv
unsigned int __fastcall boost::program_options::untyped_value::max_tokens(
        const boost::program_options::untyped_value *this)
{
  return !this->m_zero_tokens;
}


// Address: 0xe63c10 | Name: _ZNK5boost15program_options13untyped_value6xparseERNS_3anyERKNSt3__16vectorINS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS9_ISB_EEEE
void __fastcall boost::program_options::untyped_value::xparse(
        const boost::program_options::untyped_value *this,
        boost::any_0 *value_store,
        const std::vector<std::string> *new_tokens)
{
  __int64 v4; // rsi
  boost::any::placeholder *v5; // rbx
  boost::any::placeholder *content; // rdi
  __int128 v7; // [rsp+0h] [rbp-88h] BYREF
  void *ptr; // [rsp+10h] [rbp-78h]

  if ( value_store->content )
  {
    boost::program_options::multiple_occurrences::multiple_occurrences((boost::program_options::multiple_occurrences *)&v7);
    boost::throw_exception<boost::program_options::multiple_occurrences>((const boost::program_options::multiple_occurrences *)&v7);
  }
  v4 = *(_QWORD *)new_tokens;
  if ( 0xAAAAAAAAAAAAAAABLL * ((__int64)(*((_QWORD *)new_tokens + 1) - *(_QWORD *)new_tokens) >> 3) >= 2 )
  {
    boost::program_options::multiple_values::multiple_values((boost::program_options::multiple_values *)&v7);
    boost::throw_exception<boost::program_options::multiple_values>((const boost::program_options::multiple_values *)&v7);
  }
  if ( v4 == *((_QWORD *)new_tokens + 1) )
  {
    v7 = 0;
    ptr = 0;
  }
  else
  {
    std::string::basic_string(&v7, v4);
  }
  v5 = (boost::any::placeholder *)operator new(0x20u);
  v5->_vptr$placeholder = (int (**)(void))&off_287BA98;
  std::string::basic_string(&v5[1], &v7);
  content = value_store->content;
  value_store->content = v5;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  if ( (v7 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0xe63d70 | Name: _ZN5boost15program_options11bool_switchEv
boost::program_options::typed_value<bool,char> *__cdecl boost::program_options::bool_switch()
{
  return boost::program_options::bool_switch(0);
}


// Address: 0xe63d80 | Name: _ZN5boost15program_options11bool_switchEPb
boost::program_options::typed_value<bool,char> *__fastcall boost::program_options::bool_switch(bool *v)
{
  char *v1; // rbx
  _BYTE *v2; // rax

  v1 = (char *)operator new(0x98u);
  *(__m128i *)v1 = _mm_unpacklo_epi64((__m128i)(unsigned __int64)&off_287E408, (__m128i)(unsigned __int64)off_287E478);
  *((_QWORD *)v1 + 2) = v;
  *((_WORD *)v1 + 57) = 0;
  v1[116] = 0;
  *((_QWORD *)v1 + 15) = 0;
  *(_OWORD *)(v1 + 97) = 0;
  *(_OWORD *)(v1 + 88) = 0;
  *(_OWORD *)(v1 + 72) = 0;
  *(_OWORD *)(v1 + 56) = 0;
  *(_OWORD *)(v1 + 40) = 0;
  *(_OWORD *)(v1 + 24) = 0;
  v2 = operator new(0x10u);
  *(_QWORD *)v2 = &off_287E4D8;
  v2[8] = 0;
  *((_QWORD *)v1 + 6) = v2;
  *((_WORD *)v1 + 28) = 0;
  std::string::reserve(v1 + 56, 0);
  *((_WORD *)v1 + 28) = 12290;
  v1[58] = 0;
  *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)(v1 + 59) = 0;
  *((_QWORD *)v1 + 9) = 0;
  v1[115] = 1;
  return (boost::program_options::typed_value<bool,char> *)v1;
}


// Address: 0xe63e90 | Name: _ZN5boost15program_options8validateERNS_3anyERKNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEEPbi
void __fastcall boost::program_options::validate(boost::any_0 *v, const std::vector<std::string> *xs, bool *a3, int a4)
{
  const std::string *single; // rax
  unsigned __int8 v6; // cl
  unsigned __int64 v7; // rax
  bool v8; // dl
  unsigned __int64 v9; // rsi
  unsigned __int64 v10; // rdi
  unsigned __int64 v11; // rbx
  char *v12; // r12
  __int32_t v13; // ebp
  unsigned __int64 v14; // rdi
  bool v15; // zf
  unsigned __int64 v16; // rdx
  char v17; // cl
  unsigned __int64 v18; // rdx
  unsigned __int64 v19; // rdx
  unsigned __int64 v20; // rdx
  unsigned __int64 v21; // rdx
  unsigned __int64 v22; // rdx
  unsigned __int64 v23; // rdx
  boost::any::placeholder *v24; // rax
  boost::any::placeholder *content; // rdi
  unsigned __int8 v26; // [rsp+8h] [rbp-C0h] BYREF
  char v27; // [rsp+9h] [rbp-BFh] BYREF
  unsigned __int64 v28; // [rsp+10h] [rbp-B8h]
  void *ptr; // [rsp+18h] [rbp-B0h]
  _QWORD v30[3]; // [rsp+20h] [rbp-A8h] BYREF

  boost::program_options::validators::check_first_occurrence(v);
  single = boost::program_options::validators::get_single_string<char>(xs, 1);
  std::string::basic_string(&v26, single);
  v6 = v26;
  v7 = (unsigned __int64)v26 >> 1;
  v8 = (v26 & 1) == 0;
  v9 = v28;
  v10 = v28;
  if ( (v26 & 1) == 0 )
    v10 = (unsigned __int64)v26 >> 1;
  if ( v10 )
  {
    v11 = 0;
    do
    {
      v12 = &v27;
      if ( !v8 )
        v12 = (char *)ptr;
      v13 = v12[v11];
      if ( (unsigned int)(v13 + 128) <= 0x17F )
        v13 = (*__ctype_tolower_loc())[v13];
      v12[v11++] = v13;
      v6 = v26;
      v7 = (unsigned __int64)v26 >> 1;
      v8 = (v26 & 1) == 0;
      v9 = v28;
      v14 = v28;
      if ( (v26 & 1) == 0 )
        v14 = (unsigned __int64)v26 >> 1;
    }
    while ( v11 < v14 );
  }
  v15 = !v8;
  v16 = v9;
  if ( !v15 )
    v16 = v7;
  if ( !v16 )
    goto LABEL_53;
  if ( v16 == 2 )
  {
    if ( !(unsigned int)std::string::compare(&v26, 0, -1, "on", 2) )
      goto LABEL_53;
    v6 = v26;
    v9 = v28;
    v7 = (unsigned __int64)v26 >> 1;
  }
  v17 = v6 & 1;
  v18 = v9;
  if ( !v17 )
    v18 = v7;
  if ( v18 == 3 )
  {
    if ( !(unsigned int)std::string::compare(&v26, 0, -1, "yes", 3) )
      goto LABEL_53;
    v9 = v28;
    v17 = v26 & 1;
    v7 = (unsigned __int64)v26 >> 1;
  }
  v19 = v9;
  if ( !v17 )
    v19 = v7;
  if ( v19 == 1 )
  {
    if ( !(unsigned int)std::string::compare(&v26, 0, -1, "1", 1) )
      goto LABEL_53;
    v9 = v28;
    v17 = v26 & 1;
    v7 = (unsigned __int64)v26 >> 1;
  }
  v20 = v9;
  if ( !v17 )
    v20 = v7;
  if ( v20 != 4 )
  {
LABEL_33:
    v21 = v9;
    if ( !v17 )
      v21 = v7;
    if ( v21 == 3 )
    {
      if ( !(unsigned int)std::string::compare(&v26, 0, -1, "off", 3) )
        goto LABEL_52;
      v9 = v28;
      v17 = v26 & 1;
      v7 = (unsigned __int64)v26 >> 1;
    }
    v22 = v9;
    if ( !v17 )
      v22 = v7;
    if ( v22 == 2 )
    {
      if ( !(unsigned int)std::string::compare(&v26, 0, -1, "no", 2) )
        goto LABEL_52;
      v9 = v28;
      v17 = v26 & 1;
      v7 = (unsigned __int64)v26 >> 1;
    }
    v23 = v9;
    if ( !v17 )
      v23 = v7;
    if ( v23 != 1 )
      goto LABEL_48;
    if ( (unsigned int)std::string::compare(&v26, 0, -1, "0", 1) )
    {
      v9 = v28;
      v17 = v26 & 1;
      v7 = (unsigned __int64)v26 >> 1;
LABEL_48:
      if ( v17 )
        v7 = v9;
      if ( v7 != 5 || (unsigned int)std::string::compare(&v26, 0, -1, "false", 5) )
      {
        boost::program_options::invalid_bool_value::invalid_bool_value(
          (boost::program_options::invalid_bool_value *)v30,
          (const std::string *)&v26);
        boost::throw_exception<boost::program_options::invalid_bool_value>((const boost::program_options::invalid_bool_value *)v30);
      }
    }
LABEL_52:
    v24 = (boost::any::placeholder *)operator new(0x10u);
    v24->_vptr$placeholder = (int (**)(void))&off_287E4D8;
    LOBYTE(v24[1]._vptr$placeholder) = 0;
    goto LABEL_54;
  }
  if ( (unsigned int)std::string::compare(&v26, 0, -1, "true", 4) )
  {
    v9 = v28;
    v17 = v26 & 1;
    v7 = (unsigned __int64)v26 >> 1;
    goto LABEL_33;
  }
LABEL_53:
  v24 = (boost::any::placeholder *)operator new(0x10u);
  v24->_vptr$placeholder = (int (**)(void))&off_287E4D8;
  LOBYTE(v24[1]._vptr$placeholder) = 1;
LABEL_54:
  content = v->content;
  v->content = v24;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  if ( (v26 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0xe642d0 | Name: _ZN5boost15program_options10validators22check_first_occurrenceERKNS_3anyE
void __fastcall boost::program_options::validators::check_first_occurrence(const boost::any_0 *value)
{
  _QWORD v1[3]; // [rsp+8h] [rbp-80h] BYREF

  if ( value->content )
  {
    boost::program_options::multiple_occurrences::multiple_occurrences((boost::program_options::multiple_occurrences *)v1);
    boost::throw_exception<boost::program_options::multiple_occurrences>((const boost::program_options::multiple_occurrences *)v1);
  }
}


// Address: 0xe64360 | Name: _ZN5boost15program_options8validateERNS_3anyERKNSt3__16vectorINS3_12basic_stringIwNS3_11char_traitsIwEENS3_9allocatorIwEEEENS8_ISA_EEEEPbi
void __fastcall boost::program_options::validate(
        boost::any_0 *v,
        const std::vector<std::wstring> *xs,
        bool *a3,
        int a4)
{
  const std::wstring *single; // rax
  char v6; // cl
  unsigned __int64 v7; // rax
  bool v8; // dl
  unsigned __int64 v9; // rsi
  unsigned __int64 v10; // rdi
  unsigned __int64 v11; // rbx
  char *v12; // r12
  __int32_t v13; // eax
  unsigned __int64 v14; // rdi
  bool v15; // zf
  unsigned __int64 v16; // rdx
  char v17; // cl
  unsigned __int64 v18; // rdx
  unsigned __int64 v19; // rdx
  unsigned __int64 v20; // rdx
  unsigned __int64 v21; // rdx
  unsigned __int64 v22; // rdx
  unsigned __int64 v23; // rdx
  boost::any::placeholder *v24; // rax
  boost::any::placeholder *content; // rdi
  _BYTE v26[4]; // [rsp+0h] [rbp-D8h] BYREF
  char v27; // [rsp+4h] [rbp-D4h] BYREF
  unsigned __int64 v28; // [rsp+8h] [rbp-D0h]
  void *ptr; // [rsp+10h] [rbp-C8h]
  _BYTE v30[16]; // [rsp+18h] [rbp-C0h] BYREF
  _QWORD v31[3]; // [rsp+30h] [rbp-A8h] BYREF

  boost::program_options::validators::check_first_occurrence(v);
  single = boost::program_options::validators::get_single_string<wchar_t>(xs, 1);
  std::wstring::basic_string(v26, single);
  v6 = v26[0];
  v7 = (unsigned __int64)v26[0] >> 1;
  v8 = (v26[0] & 1) == 0;
  v9 = v28;
  v10 = v28;
  if ( (v26[0] & 1) == 0 )
    v10 = (unsigned __int64)v26[0] >> 1;
  if ( v10 )
  {
    v11 = 0;
    do
    {
      v12 = &v27;
      if ( !v8 )
        v12 = (char *)ptr;
      v13 = *(_DWORD *)&v12[4 * v11];
      if ( (unsigned int)(v13 + 128) <= 0x17F )
        v13 = (*__ctype_tolower_loc())[v13];
      *(_DWORD *)&v12[4 * v11++] = v13;
      v6 = v26[0];
      v7 = (unsigned __int64)v26[0] >> 1;
      v8 = (v26[0] & 1) == 0;
      v9 = v28;
      v14 = v28;
      if ( (v26[0] & 1) == 0 )
        v14 = (unsigned __int64)v26[0] >> 1;
    }
    while ( v11 < v14 );
  }
  v15 = !v8;
  v16 = v9;
  if ( !v15 )
    v16 = v7;
  if ( !v16 )
    goto LABEL_53;
  if ( v16 == 2 )
  {
    if ( !(unsigned int)std::wstring::compare(v26, 0, -1, &unk_4991B4, 2) )
      goto LABEL_53;
    v6 = v26[0];
    v9 = v28;
    v7 = (unsigned __int64)v26[0] >> 1;
  }
  v17 = v6 & 1;
  v18 = v9;
  if ( !v17 )
    v18 = v7;
  if ( v18 == 3 )
  {
    if ( !(unsigned int)std::wstring::compare(v26, 0, -1, &unk_499130, 3) )
      goto LABEL_53;
    v9 = v28;
    v17 = v26[0] & 1;
    v7 = (unsigned __int64)v26[0] >> 1;
  }
  v19 = v9;
  if ( !v17 )
    v19 = v7;
  if ( v19 == 1 )
  {
    if ( !(unsigned int)std::wstring::compare(v26, 0, -1, &unk_4991A4, 1) )
      goto LABEL_53;
    v9 = v28;
    v17 = v26[0] & 1;
    v7 = (unsigned __int64)v26[0] >> 1;
  }
  v20 = v9;
  if ( !v17 )
    v20 = v7;
  if ( v20 != 4 )
  {
LABEL_33:
    v21 = v9;
    if ( !v17 )
      v21 = v7;
    if ( v21 == 3 )
    {
      if ( !(unsigned int)std::wstring::compare(v26, 0, -1, &unk_499140, 3) )
        goto LABEL_52;
      v9 = v28;
      v17 = v26[0] & 1;
      v7 = (unsigned __int64)v26[0] >> 1;
    }
    v22 = v9;
    if ( !v17 )
      v22 = v7;
    if ( v22 == 2 )
    {
      if ( !(unsigned int)std::wstring::compare(v26, 0, -1, &unk_499174, 2) )
        goto LABEL_52;
      v9 = v28;
      v17 = v26[0] & 1;
      v7 = (unsigned __int64)v26[0] >> 1;
    }
    v23 = v9;
    if ( !v17 )
      v23 = v7;
    if ( v23 != 1 )
      goto LABEL_48;
    if ( (unsigned int)std::wstring::compare(v26, 0, -1, &unk_4991C0, 1) )
    {
      v9 = v28;
      v17 = v26[0] & 1;
      v7 = (unsigned __int64)v26[0] >> 1;
LABEL_48:
      if ( v17 )
        v7 = v9;
      if ( v7 != 5 || (unsigned int)std::wstring::compare(v26, 0, -1, &unk_49918C, 5) )
      {
        boost::program_options::`anonymous namespace'::convert_value(v30, v26);
        boost::program_options::invalid_bool_value::invalid_bool_value(
          (boost::program_options::invalid_bool_value *)v31,
          (const std::string *)v30);
        boost::throw_exception<boost::program_options::invalid_bool_value>((const boost::program_options::invalid_bool_value *)v31);
      }
    }
LABEL_52:
    v24 = (boost::any::placeholder *)operator new(0x10u);
    v24->_vptr$placeholder = (int (**)(void))&off_287E4D8;
    LOBYTE(v24[1]._vptr$placeholder) = 0;
    goto LABEL_54;
  }
  if ( (unsigned int)std::wstring::compare(v26, 0, -1, &unk_499110, 4) )
  {
    v9 = v28;
    v17 = v26[0] & 1;
    v7 = (unsigned __int64)v26[0] >> 1;
    goto LABEL_33;
  }
LABEL_53:
  v24 = (boost::any::placeholder *)operator new(0x10u);
  v24->_vptr$placeholder = (int (**)(void))&off_287E4D8;
  LOBYTE(v24[1]._vptr$placeholder) = 1;
LABEL_54:
  content = v->content;
  v->content = v24;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  if ( (v26[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0xe647b0 | Name: _ZN5boost15program_options12_GLOBAL__N_113convert_valueERKNSt3__112basic_stringIwNS2_11char_traitsIwEENS2_9allocatorIwEEEE
__int64 __fastcall boost::program_options::`anonymous namespace'::convert_value(__int64 a1, int a2)
{
  int v2; // eax
  int v4; // [rsp+0h] [rbp-10h]
  std::locale v5; // [rsp+8h] [rbp-8h]

  boost::to_local_8_bit(a1, a2, v2, v4, v5);
  return a1;
}


// Address: 0xe64840 | Name: _ZN5boost15program_options8validateERNS_3anyERKNSt3__16vectorINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS8_ISA_EEEEPSA_i
void __fastcall boost::program_options::validate(
        boost::any_0 *v,
        const std::vector<std::string> *xs,
        std::string *a3,
        int a4)
{
  const std::string *single; // r15
  boost::any::placeholder *v6; // rbx
  boost::any::placeholder *content; // rdi

  boost::program_options::validators::check_first_occurrence(v);
  single = boost::program_options::validators::get_single_string<char>(xs, 0);
  v6 = (boost::any::placeholder *)operator new(0x20u);
  v6->_vptr$placeholder = (int (**)(void))&off_287BA98;
  std::string::basic_string(&v6[1], single);
  content = v->content;
  v->content = v6;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
}


// Address: 0xe648b0 | Name: _ZN5boost15program_options8validateERNS_3anyERKNSt3__16vectorINS3_12basic_stringIwNS3_11char_traitsIwEENS3_9allocatorIwEEEENS8_ISA_EEEEPNS5_IcNS6_IcEENS8_IcEEEEi
void __fastcall boost::program_options::validate(
        boost::any_0 *v,
        const std::vector<std::wstring> *xs,
        std::string *a3,
        int a4)
{
  const std::wstring *single; // r15
  boost::any::placeholder *v6; // rbx
  boost::any::placeholder *content; // rdi

  boost::program_options::validators::check_first_occurrence(v);
  single = boost::program_options::validators::get_single_string<wchar_t>(xs, 0);
  v6 = (boost::any::placeholder *)operator new(0x20u);
  v6->_vptr$placeholder = (int (**)(void))&off_287E6B8;
  std::wstring::basic_string(&v6[1], single);
  content = v->content;
  v->content = v6;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
}


// Address: 0xe64920 | Name: _ZN5boost15program_options20invalid_option_valueC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::invalid_option_value::invalid_option_value(
        boost::program_options::invalid_option_value *this,
        const std::string *bad_value)
{
  std::pair<std::__tree_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>,bool> v2; // rax
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  std::tuple<> __args; // [rsp+8h] [rbp-60h] BYREF
  __int128 v7; // [rsp+10h] [rbp-58h] BYREF
  void *v8; // [rsp+20h] [rbp-48h]
  std::tuple<const std::string &> v9[2]; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  v7 = 0;
  v8 = 0;
  *(_OWORD *)&v9[0].__base_.__value_ = 0;
  ptr = 0;
  boost::program_options::validation_error::validation_error(
    this,
    boost::program_options::validation_error::kind_t::invalid_option_value,
    (const std::string *)&v7,
    (const std::string *)v9,
    0);
  if ( ((__int64)v9[0].__base_.__value_ & 1) != 0 )
    operator delete(ptr);
  if ( (v7 & 1) != 0 )
    operator delete(v8);
  *(_QWORD *)this = off_287C168;
  v7 = 0;
  v8 = 0;
  strcpy((char *)&v7, "\nvalue");
  v9[0].__base_.__value_ = (const std::string *)&v7;
  v2 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
         (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
       + 1,
         (const std::string *)&v7,
         &stru_49910C,
         v9,
         &__args);
  std::string::operator=((soap *)&v2.first.__ptr_[7], (int)bad_value, *(int *)&v2.second, v3, v4, v5);
  if ( (v7 & 1) != 0 )
    operator delete(v8);
}


// Address: 0xe64ab0 | Name: _ZN5boost15program_options20invalid_option_valueC2ERKNSt3__112basic_stringIwNS2_11char_traitsIwEENS2_9allocatorIwEEEE
void __fastcall boost::program_options::invalid_option_value::invalid_option_value(
        boost::program_options::invalid_option_value *this,
        const std::wstring *bad_value)
{
  std::pair<std::__tree_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>,bool> v2; // rax
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  std::tuple<> __args; // [rsp+8h] [rbp-60h] BYREF
  __int128 v7; // [rsp+10h] [rbp-58h] BYREF
  void *v8; // [rsp+20h] [rbp-48h]
  __int128 v9; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]
  std::tuple<const std::string &> v11; // [rsp+48h] [rbp-20h] BYREF

  v7 = 0;
  v8 = 0;
  v9 = 0;
  ptr = 0;
  boost::program_options::validation_error::validation_error(
    this,
    boost::program_options::validation_error::kind_t::invalid_option_value,
    (const std::string *)&v7,
    (const std::string *)&v9,
    0);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
  if ( (v7 & 1) != 0 )
    operator delete(v8);
  *(_QWORD *)this = off_287C168;
  v7 = 0;
  v8 = 0;
  strcpy((char *)&v7, "\nvalue");
  boost::program_options::`anonymous namespace'::convert_value((__int64)&v9, (int)bad_value);
  v11.__base_.__value_ = (const std::string *)&v7;
  v2 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
         (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
       + 1,
         (const std::string *)&v7,
         &stru_49910C,
         &v11,
         &__args);
  std::string::operator=((soap *)&v2.first.__ptr_[7], (int)&v9, *(int *)&v2.second, v3, v4, v5);
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
  if ( (v7 & 1) != 0 )
    operator delete(v8);
}


// Address: 0xe64c70 | Name: _ZN5boost15program_options18invalid_bool_valueC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::invalid_bool_value::invalid_bool_value(
        boost::program_options::invalid_bool_value *this,
        const std::string *bad_value)
{
  std::pair<std::__tree_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>,bool> v2; // rax
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  std::tuple<> __args; // [rsp+8h] [rbp-60h] BYREF
  __int128 v7; // [rsp+10h] [rbp-58h] BYREF
  void *v8; // [rsp+20h] [rbp-48h]
  std::tuple<const std::string &> v9[2]; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  v7 = 0;
  v8 = 0;
  *(_OWORD *)&v9[0].__base_.__value_ = 0;
  ptr = 0;
  boost::program_options::validation_error::validation_error(
    this,
    boost::program_options::validation_error::kind_t::invalid_bool_value,
    (const std::string *)&v7,
    (const std::string *)v9,
    0);
  if ( ((__int64)v9[0].__base_.__value_ & 1) != 0 )
    operator delete(ptr);
  if ( (v7 & 1) != 0 )
    operator delete(v8);
  *(_QWORD *)this = off_287DD88;
  v7 = 0;
  v8 = 0;
  strcpy((char *)&v7, "\nvalue");
  v9[0].__base_.__value_ = (const std::string *)&v7;
  v2 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
         (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
       + 1,
         (const std::string *)&v7,
         &stru_49910C,
         v9,
         &__args);
  std::string::operator=((soap *)&v2.first.__ptr_[7], (int)bad_value, *(int *)&v2.second, v3, v4, v5);
  if ( (v7 & 1) != 0 )
    operator delete(v8);
}


// Address: 0xe64e00 | Name: _ZN5boost15program_options22error_with_option_nameC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEESA_SA_i
void __fastcall boost::program_options::error_with_option_name::error_with_option_name(
        boost::program_options::error_with_option_name *this,
        const std::string *template_,
        const std::string *option_name,
        const std::string *original_token,
        int option_style)
{
  int v6; // r15d
  int v7; // r14d
  int v8; // r13d
  int v9; // edx
  void *v10; // rcx
  size_t v11; // r8
  const void *v12; // r9
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_base_pointer *v13; // r15
  char *v14; // rbp
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer v15; // rax
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer left; // rax
  std::__tree_node_base<void *> *v17; // rsi
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *v18; // r14
  int v19; // edx
  void *v20; // rcx
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_base_pointer *v21; // rbx
  size_t v22; // r8
  const void *v23; // r9
  char *v24; // rbp
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer v25; // rax
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v26; // rax
  std::__tree_node_base<void *> *v27; // rsi
  _OWORD v28[2]; // [rsp+0h] [rbp-98h] BYREF
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer __parent[4]; // [rsp+20h] [rbp-78h] BYREF
  _OWORD v30[2]; // [rsp+40h] [rbp-58h] BYREF
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *v31; // [rsp+60h] [rbp-38h]

  v6 = (int)original_token;
  v7 = (int)option_name;
  std::logic_error::logic_error(this, template_);
  *(_QWORD *)this = off_287DDC0;
  *((_DWORD *)this + 4) = option_style;
  v31 = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)((char *)this + 24);
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 3) = (char *)this + 32;
  *(_OWORD *)((char *)this + 56) = 0;
  *((_QWORD *)this + 6) = (char *)this + 56;
  std::string::basic_string((char *)this + 72, template_);
  *((_OWORD *)this + 6) = 0;
  *((_QWORD *)this + 14) = 0;
  BYTE1(v28[1]) = 0;
  WORD1(v28[1]) = 0;
  DWORD1(v28[1]) = 0;
  strcpy((char *)v28, " canonical_optio");
  __parent[2] = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer)operator new(0x20u);
  *(_OWORD *)__parent = xmmword_3E5420;
  strcpy((char *)__parent[2], "option '%canonical_option%'");
  *(_OWORD *)((char *)v30 + 8) = 0;
  LOBYTE(v30[0]) = 12;
  strcpy((char *)v30 + 1, "option");
  boost::program_options::error_with_option_name::set_substitute_default(
    this,
    (const std::string *)v28,
    (const std::string *)__parent,
    (const std::string *)v30);
  if ( (v30[0] & 1) != 0 )
  {
    operator delete(*(void **)&v30[1]);
    if ( ((__int64)__parent[0] & 1) == 0 )
    {
LABEL_3:
      if ( (v28[0] & 1) == 0 )
        goto LABEL_5;
      goto LABEL_4;
    }
  }
  else if ( ((__int64)__parent[0] & 1) == 0 )
  {
    goto LABEL_3;
  }
  operator delete(__parent[2]);
  if ( (v28[0] & 1) != 0 )
LABEL_4:
    operator delete(*(void **)&v28[1]);
LABEL_5:
  memset(v28, 0, 24);
  strcpy((char *)v28, "\nvalue");
  BYTE1(__parent[2]) = 101;
  WORD1(__parent[2]) = 10021;
  HIDWORD(__parent[2]) = 41;
  strcpy((char *)__parent, "(argument ('%val");
  BYTE9(v30[0]) = 0;
  WORD5(v30[0]) = 0;
  HIDWORD(v30[0]) = 0;
  *(_QWORD *)&v30[1] = 0;
  LOBYTE(v30[0]) = 16;
  strcpy((char *)v30 + 1, "argumen");
  boost::program_options::error_with_option_name::set_substitute_default(
    this,
    (const std::string *)v28,
    (const std::string *)__parent,
    (const std::string *)v30);
  if ( (v30[0] & 1) != 0 )
  {
    operator delete(*(void **)&v30[1]);
    if ( ((__int64)__parent[0] & 1) == 0 )
    {
LABEL_7:
      if ( (v28[0] & 1) == 0 )
        goto LABEL_9;
      goto LABEL_8;
    }
  }
  else if ( ((__int64)__parent[0] & 1) == 0 )
  {
    goto LABEL_7;
  }
  operator delete(__parent[2]);
  if ( (v28[0] & 1) != 0 )
LABEL_8:
    operator delete(*(void **)&v28[1]);
LABEL_9:
  *(_OWORD *)((char *)v28 + 8) = 0;
  LOBYTE(v28[0]) = 12;
  strcpy((char *)v28 + 1, "prefix");
  __parent[1] = 0;
  __parent[2] = 0;
  LOBYTE(__parent[0]) = 16;
  *(std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer *)((char *)__parent + 1) = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer)0x2578696665727025LL;
  memset(v30, 0, 24);
  boost::program_options::error_with_option_name::set_substitute_default(
    this,
    (const std::string *)v28,
    (const std::string *)__parent,
    (const std::string *)v30);
  if ( (v30[0] & 1) != 0 )
    operator delete(*(void **)&v30[1]);
  if ( ((__int64)__parent[0] & 1) != 0 )
    operator delete(__parent[2]);
  v8 = v6;
  if ( (v28[0] & 1) != 0 )
    operator delete(*(void **)&v28[1]);
  *(_OWORD *)((char *)v28 + 8) = 0;
  LOBYTE(v28[0]) = 12;
  strcpy((char *)v28 + 1, "option");
  v13 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__find_equal<std::string>(
          v31,
          __parent,
          (const std::string *)v28);
  v14 = (char *)*v13;
  if ( !*v13 )
  {
    v14 = (char *)operator new(0x50u);
    *((_QWORD *)v14 + 6) = *(_QWORD *)&v28[1];
    *((_OWORD *)v14 + 2) = v28[0];
    memset(v28, 0, 24);
    *(_OWORD *)(v14 + 56) = 0;
    *((_QWORD *)v14 + 9) = 0;
    v15 = __parent[0];
    *(_OWORD *)v14 = 0;
    *((_QWORD *)v14 + 2) = v15;
    *v13 = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_base_pointer)v14;
    left = v31->__begin_node_->__left_;
    if ( left )
    {
      v31->__begin_node_ = left;
      v17 = *v13;
    }
    else
    {
      v17 = (std::__tree_node_base<void *> *)v14;
    }
    std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(
      *((std::__tree_node_base<void *> **)this + 4),
      v17);
    ++*((_QWORD *)this + 5);
  }
  std::string::operator=((soap *)(v14 + 56), v7, v9, v10, v11, v12);
  if ( (v28[0] & 1) != 0 )
    operator delete(*(void **)&v28[1]);
  *(_QWORD *)&v28[1] = 0;
  LOBYTE(v28[0]) = 28;
  strcpy((char *)v28 + 1, "original_token");
  v18 = v31;
  v21 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__find_equal<std::string>(
          v31,
          __parent,
          (const std::string *)v28);
  v24 = (char *)*v21;
  if ( !*v21 )
  {
    v24 = (char *)operator new(0x50u);
    *((_QWORD *)v24 + 6) = *(_QWORD *)&v28[1];
    *((_OWORD *)v24 + 2) = v28[0];
    memset(v28, 0, 24);
    *(_OWORD *)(v24 + 56) = 0;
    *((_QWORD *)v24 + 9) = 0;
    v25 = __parent[0];
    *(_OWORD *)v24 = 0;
    *((_QWORD *)v24 + 2) = v25;
    *v21 = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_base_pointer)v24;
    v26 = v18->__begin_node_->__left_;
    if ( v26 )
    {
      v18->__begin_node_ = v26;
      v27 = *v21;
    }
    else
    {
      v27 = (std::__tree_node_base<void *> *)v24;
    }
    std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(
      *((std::__tree_node_base<void *> **)this + 4),
      v27);
    ++*((_QWORD *)this + 5);
  }
  std::string::operator=((soap *)(v24 + 56), v8, v19, v20, v22, v23);
  if ( (v28[0] & 1) != 0 )
    operator delete(*(void **)&v28[1]);
}


// Address: 0xe65370 | Name: _ZNK5boost15program_options22error_with_option_name4whatEv
const char *__fastcall boost::program_options::error_with_option_name::what(
        const boost::program_options::error_with_option_name *this)
{
  (*(void (__fastcall **)(const boost::program_options::error_with_option_name *, char *))(*(_QWORD *)this + 32LL))(
    this,
    (char *)this + 72);
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    return (const char *)*((_QWORD *)this + 14);
  else
    return (char *)this + 97;
}


// Address: 0xe65397 | Name: sub_E65397
void __fastcall __noreturn sub_E65397()
{
  void *v0; // rax

  __cxa_call_unexpected(v0);
}


// Address: 0xe653a0 | Name: _ZNK5boost15program_options22error_with_option_name13replace_tokenERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEESA_
void __fastcall boost::program_options::error_with_option_name::replace_token(
        const boost::program_options::error_with_option_name *this,
        const std::string *from,
        const std::string *to)
{
  char *v5; // r15
  unsigned __int64 v6; // rcx
  char *v7; // r12
  char *v8; // rsi
  unsigned __int64 v9; // rcx
  __int64 i; // rax
  unsigned __int64 v11; // rdx
  unsigned __int64 v12; // rdx
  unsigned __int64 v13; // r8
  char *v14; // rcx
  unsigned __int64 v15; // r8
  unsigned __int64 v16; // rcx
  char *v17; // rsi
  unsigned __int64 v18; // rcx

  v5 = (char *)this + 96;
  v6 = *(unsigned __int8 *)from;
  v7 = (char *)from + 1;
  if ( (v6 & 1) != 0 )
  {
    v8 = (char *)*((_QWORD *)from + 2);
    v9 = *((_QWORD *)from + 1);
  }
  else
  {
    v9 = v6 >> 1;
    v8 = (char *)from + 1;
  }
  for ( i = std::string::find((char *)this + 96, v8, 0, v9); i != -1; i = std::string::find(v5, v17, 0, v18) )
  {
    v11 = *(unsigned __int8 *)from;
    if ( (v11 & 1) != 0 )
      v12 = *((_QWORD *)from + 1);
    else
      v12 = v11 >> 1;
    v13 = *(unsigned __int8 *)to;
    if ( (v13 & 1) != 0 )
    {
      v14 = (char *)*((_QWORD *)to + 2);
      v15 = *((_QWORD *)to + 1);
    }
    else
    {
      v15 = v13 >> 1;
      v14 = (char *)to + 1;
    }
    std::string::replace(v5, i, v12, v14, v15);
    v16 = *(unsigned __int8 *)from;
    if ( (v16 & 1) != 0 )
    {
      v17 = (char *)*((_QWORD *)from + 2);
      v18 = *((_QWORD *)from + 1);
    }
    else
    {
      v18 = v16 >> 1;
      v17 = v7;
    }
  }
}


// Address: 0xe65470 | Name: _ZNK5boost15program_options22error_with_option_name27get_canonical_option_prefixEv
boost::program_options::error_with_option_name *__fastcall boost::program_options::error_with_option_name::get_canonical_option_prefix(
        boost::program_options::error_with_option_name *this,
        __int64 a2)
{
  std::logic_error *exception; // rbx

  switch ( *(_DWORD *)(a2 + 16) )
  {
    case 0:
      *(_OWORD *)this = 0;
      *((_QWORD *)this + 2) = 0;
      return this;
    case 1:
      *(_OWORD *)this = 0;
      *((_QWORD *)this + 2) = 0;
      *(_BYTE *)this = 4;
      strcpy((char *)this + 1, "--");
      return this;
    case 2:
    case 3:
    case 5:
    case 6:
    case 7:
      goto LABEL_9;
    case 4:
      goto LABEL_4;
    case 8:
      *(_OWORD *)this = 0;
      *((_QWORD *)this + 2) = 0;
      *(_WORD *)this = 12034;
      goto LABEL_6;
    default:
      if ( *(_DWORD *)(a2 + 16) != 4096 )
      {
LABEL_9:
        exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
        std::logic_error::logic_error(
          exception,
          "error_with_option_name::m_option_style can only be one of [0, allow_dash_for_short, allow_slash_for_short, all"
          "ow_long_disguise or allow_long]");
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'std::logic_error,
          (void (*)(void *))&std::logic_error::~logic_error);
      }
LABEL_4:
      *(_OWORD *)this = 0;
      *((_QWORD *)this + 2) = 0;
      *(_WORD *)this = 11522;
LABEL_6:
      *((_BYTE *)this + 2) = 0;
      return this;
  }
}


// Address: 0xe65540 | Name: _ZNK5boost15program_options22error_with_option_name25get_canonical_option_nameEv
boost::program_options::error_with_option_name *__fastcall boost::program_options::error_with_option_name::get_canonical_option_name(
        boost::program_options::error_with_option_name *this,
        __int64 a2)
{
  const std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *v3; // r12
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::const_iterator v4; // rax
  unsigned __int64 left_low; // rbx
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer left; // rbx
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::const_iterator v7; // rax
  unsigned __int64 v8; // rsi
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v9; // r8
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v10; // rsi
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::const_iterator v11; // rax
  std::__tree_const_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>::__iter_pointer v12; // rax
  __int64 v13; // rdx
  __int64 v14; // rbx
  unsigned __int8 v15; // cl
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::const_iterator v16; // rax
  unsigned __int64 v17; // rsi
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v18; // r8
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v19; // rsi
  std::__tree_const_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>::__iter_pointer v20; // rax
  __int64 v21; // rdx
  __int64 v22; // rbx
  unsigned __int8 v23; // cl
  int v24; // ecx
  _BYTE *v25; // rax
  char *v26; // rsi
  unsigned __int64 v27; // rdx
  __int64 v28; // rax
  char *v30; // rax
  std::logic_error *exception; // r14
  _BYTE v32[24]; // [rsp+0h] [rbp-78h] BYREF
  unsigned __int8 v33; // [rsp+18h] [rbp-60h] BYREF
  _BYTE v34[23]; // [rsp+19h] [rbp-5Fh] BYREF
  __int128 v35; // [rsp+30h] [rbp-48h] BYREF
  void *v36; // [rsp+40h] [rbp-38h]

  *(_OWORD *)&v34[7] = 0;
  v33 = 12;
  strcpy(v34, "option");
  v3 = (const std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)(a2 + 24);
  v4.__ptr_ = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::find<std::string>(
                (const std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)(a2 + 24),
                (const std::string *)&v33).__ptr_;
  left_low = LOBYTE(v4.__ptr_[7].__left_);
  if ( (left_low & 1) != 0 )
  {
    left = v4.__ptr_[8].__left_;
    if ( (v33 & 1) == 0 )
      goto LABEL_6;
    goto LABEL_5;
  }
  left = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)(left_low >> 1);
  if ( (v33 & 1) != 0 )
LABEL_5:
    operator delete(*(void **)&v34[15]);
LABEL_6:
  if ( !left )
  {
    *(_QWORD *)&v34[15] = 0;
    v33 = 28;
    strcpy(v34, "original_token");
    v11.__ptr_ = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::find<std::string>(
                   v3,
                   (const std::string *)&v33).__ptr_;
    std::string::basic_string(this, &v11.__ptr_[7]);
    goto LABEL_49;
  }
  v36 = 0;
  LOBYTE(v35) = 28;
  *(_QWORD *)((char *)&v35 + 7) = 0x6E656B6F745F6C61LL;
  *(_QWORD *)((char *)&v35 + 1) = 0x6C616E696769726FLL;
  HIBYTE(v35) = 0;
  v7.__ptr_ = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::find<std::string>(
                v3,
                (const std::string *)&v35).__ptr_;
  v8 = LOBYTE(v7.__ptr_[7].__left_);
  if ( (v8 & 1) != 0 )
  {
    v9 = v7.__ptr_[9].__left_;
    v10 = v7.__ptr_[8].__left_;
  }
  else
  {
    v9 = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)((char *)&v7.__ptr_[7].__left_ + 1);
    v10 = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)(v8 >> 1);
  }
  v12 = v7.__ptr_ + 7;
  v13 = -1;
  if ( v10 )
  {
    v14 = 0;
    while ( 1 )
    {
      v15 = *((_BYTE *)&v9->__left_ + v14);
      if ( v15 > 0x3Fu || ((1LL << v15) & 0xA00000000000LL) == 0 )
        break;
      if ( v10 == (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)++v14 )
        goto LABEL_18;
    }
    v13 = v14;
  }
LABEL_18:
  std::string::basic_string(&v33, v12, v13, -1, v12);
  if ( (v35 & 1) != 0 )
    operator delete(v36);
  *(_OWORD *)&v32[8] = 0;
  v32[0] = 12;
  strcpy(&v32[1], "option");
  v16.__ptr_ = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::find<std::string>(
                 v3,
                 (const std::string *)v32).__ptr_;
  v17 = LOBYTE(v16.__ptr_[7].__left_);
  if ( (v17 & 1) != 0 )
  {
    v18 = v16.__ptr_[9].__left_;
    v19 = v16.__ptr_[8].__left_;
  }
  else
  {
    v18 = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)((char *)&v16.__ptr_[7].__left_ + 1);
    v19 = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)(v17 >> 1);
  }
  v20 = v16.__ptr_ + 7;
  v21 = -1;
  if ( v19 )
  {
    v22 = 0;
    while ( 1 )
    {
      v23 = *((_BYTE *)&v18->__left_ + v22);
      if ( v23 > 0x3Fu || ((1LL << v23) & 0xA00000000000LL) == 0 )
        break;
      if ( v19 == (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)++v22 )
        goto LABEL_30;
    }
    v21 = v22;
  }
LABEL_30:
  std::string::basic_string(&v35, v20, v21, -1, v20);
  if ( (v32[0] & 1) != 0 )
    operator delete(*(void **)&v32[16]);
  v24 = *(_DWORD *)(a2 + 16);
  if ( !v24 )
    goto LABEL_53;
  if ( v24 != 4096 && v24 != 1 )
  {
    if ( (v33 & 1) != 0 )
    {
      if ( *(_QWORD *)&v34[7] )
        goto LABEL_40;
    }
    else if ( (unsigned __int64)v33 >> 1 )
    {
LABEL_40:
      if ( v24 > 7 )
      {
        if ( v24 == 8 )
        {
          memset(v32, 0, sizeof(v32));
          *(_WORD *)v32 = 12034;
          goto LABEL_58;
        }
      }
      else if ( v24 == 4 )
      {
        memset(v32, 0, sizeof(v32));
        *(_WORD *)v32 = 11522;
LABEL_58:
        v32[2] = 0;
        if ( (v33 & 1) != 0 )
          v30 = *(char **)&v34[15];
        else
          v30 = v34;
        std::string::push_back(v32, (unsigned int)*v30);
        *((_QWORD *)this + 2) = *(_QWORD *)&v32[16];
        *(_OWORD *)this = *(_OWORD *)v32;
        if ( (v35 & 1) == 0 )
          goto LABEL_49;
        goto LABEL_48;
      }
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(
        exception,
        "error_with_option_name::m_option_style can only be one of [0, allow_dash_for_short, allow_slash_for_short, allow"
        "_long_disguise or allow_long]");
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::logic_error,
        (void (*)(void *))&std::logic_error::~logic_error);
    }
LABEL_53:
    *((_QWORD *)this + 2) = v36;
    *(_OWORD *)this = v35;
    v35 = 0;
    v36 = 0;
    goto LABEL_49;
  }
  memset(v32, 0, sizeof(v32));
  if ( v24 > 7 )
  {
    *(_WORD *)v32 = 11522;
    v25 = &v32[2];
  }
  else
  {
    v32[0] = 4;
    *(_WORD *)&v32[1] = 11565;
    v25 = &v32[3];
  }
  *v25 = 0;
  if ( (v35 & 1) != 0 )
  {
    v26 = (char *)v36;
    v27 = *((_QWORD *)&v35 + 1);
  }
  else
  {
    v27 = (unsigned __int64)(unsigned __int8)v35 >> 1;
    v26 = (char *)&v35 + 1;
  }
  v28 = std::string::append(v32, v26, v27);
  *((_QWORD *)this + 2) = *(_QWORD *)(v28 + 16);
  *(_OWORD *)this = *(_OWORD *)v28;
  *(_OWORD *)v28 = 0;
  *(_QWORD *)(v28 + 16) = 0;
  if ( (v32[0] & 1) != 0 )
    operator delete(*(void **)&v32[16]);
  if ( (v35 & 1) != 0 )
LABEL_48:
    operator delete(v36);
LABEL_49:
  if ( (v33 & 1) != 0 )
    operator delete(*(void **)&v34[15]);
  return this;
}


// Address: 0xe65ac0 | Name: _ZNK5boost15program_options22error_with_option_name23substitute_placeholdersERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::error_with_option_name::substitute_placeholders(
        const boost::program_options::error_with_option_name *this,
        const std::string *error_template)
{
  int v2; // edx
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  const boost::program_options::error_with_option_name *v7; // rbx
  const boost::program_options::error_with_option_name *v8; // rcx
  const boost::program_options::error_with_option_name *v9; // rax
  __int64 v10; // rbx
  bool v11; // zf
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_base_pointer *v12; // rbp
  char *v13; // rbx
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer v14; // rax
  std::__tree_node_base<void *> *v15; // rsi
  _WORD *v16; // rbp
  char v17; // r12
  __int16 v18; // r14
  __int16 v19; // r13
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_base_pointer *v20; // rbp
  char *v21; // rbx
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer v22; // rax
  std::__tree_node_base<void *> *v23; // rsi
  _WORD *v24; // rdi
  const boost::program_options::error_with_option_name *v25; // r13
  std::__tree_iterator<std::__value_type<std::string,std::string >,std::__tree_node<std::__value_type<std::string,std::string >,void *> *,long>::__iter_pointer ptr; // rax
  unsigned __int64 left_low; // rcx
  const boost::program_options::error_with_option_name *v28; // rcx
  const boost::program_options::error_with_option_name *v29; // rax
  __int64 v30; // r13
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__iter_pointer begin_node; // rbp
  _QWORD *p_left; // rcx
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *left; // rax
  __int64 v34; // rbp
  std::logic_error *exception; // rbp
  _OWORD v36[2]; // [rsp+0h] [rbp-98h] BYREF
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > v37; // [rsp+20h] [rbp-78h] BYREF
  std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__parent_pointer __parent; // [rsp+38h] [rbp-60h] BYREF
  std::tuple<> __args[32]; // [rsp+40h] [rbp-58h] BYREF
  unsigned __int64 v40; // [rsp+60h] [rbp-38h]

  v40 = __readfsqword(0x28u);
  std::string::operator=((soap *)((char *)this + 96), (int)error_template, v2, v3, v4, v5);
  *(_OWORD *)&v37.__pair1_.__value_.__left_ = 0;
  v37.__begin_node_ = &v37.__pair1_.__value_;
  v7 = (const boost::program_options::error_with_option_name *)*((_QWORD *)this + 3);
  if ( v7 != (const boost::program_options::error_with_option_name *)((char *)this + 32) )
  {
    do
    {
      std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_hint_unique_key_args<std::string,std::pair<std::string const,std::string> const&>(
        &v37,
        (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::const_iterator)&v37.__pair1_,
        (const boost::program_options::error_with_option_name *)((char *)v7 + 32),
        (const boost::program_options::error_with_option_name *)((char *)v7 + 32));
      v8 = (const boost::program_options::error_with_option_name *)*((_QWORD *)v7 + 1);
      if ( v8 )
      {
        do
        {
          v9 = v8;
          v8 = *(const boost::program_options::error_with_option_name **)v8;
        }
        while ( v8 );
      }
      else
      {
        v9 = (const boost::program_options::error_with_option_name *)*((_QWORD *)v7 + 2);
        if ( *(const boost::program_options::error_with_option_name **)v9 != v7 )
        {
          v10 = (__int64)v7 + 16;
          do
          {
            v9 = *(const boost::program_options::error_with_option_name **)(*(_QWORD *)v10 + 16LL);
            v11 = *(_QWORD *)v9 == *(_QWORD *)v10;
            v10 = *(_QWORD *)v10 + 16LL;
          }
          while ( !v11 );
        }
      }
      v7 = v9;
    }
    while ( v9 != (const boost::program_options::error_with_option_name *)((char *)this + 32) );
  }
  boost::program_options::error_with_option_name::get_canonical_option_name(
    (boost::program_options::error_with_option_name *)v36,
    (__int64)this);
  __args[17].gap0 = 0;
  *(_WORD *)&__args[18].gap0 = 0;
  *(_DWORD *)&__args[20].gap0 = 0;
  strcpy(&__args[0].gap0, " canonical_optio");
  v12 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__find_equal<std::string>(
          &v37,
          &__parent,
          (const std::string *)__args);
  v13 = (char *)*v12;
  if ( !*v12 )
  {
    v13 = (char *)operator new(0x50u);
    *((_QWORD *)v13 + 6) = *(_QWORD *)&__args[16].gap0;
    *((_OWORD *)v13 + 2) = *(_OWORD *)&__args[0].gap0;
    memset(__args, 0, 24);
    *(_OWORD *)(v13 + 56) = 0;
    *((_QWORD *)v13 + 9) = 0;
    v14 = __parent;
    *(_OWORD *)v13 = 0;
    *((_QWORD *)v13 + 2) = v14;
    *v12 = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_base_pointer)v13;
    if ( v37.__begin_node_->__left_ )
    {
      v37.__begin_node_ = v37.__begin_node_->__left_;
      v15 = *v12;
    }
    else
    {
      v15 = (std::__tree_node_base<void *> *)v13;
    }
    std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(v37.__pair1_.__value_.__left_, v15);
    ++v37.__pair3_.__value_;
  }
  v16 = v13 + 56;
  if ( (v13[56] & 1) != 0 )
  {
    **((_BYTE **)v13 + 9) = 0;
    *((_QWORD *)v13 + 8) = 0;
  }
  else
  {
    *v16 = 0;
  }
  std::string::reserve(v13 + 56, 0);
  *((_QWORD *)v13 + 9) = *(_QWORD *)&v36[1];
  *(_OWORD *)v16 = v36[0];
  memset(v36, 0, 24);
  if ( (__args[0].gap0 & 1) != 0 )
  {
    operator delete(*(void **)&__args[16].gap0);
    if ( (v36[0] & 1) != 0 )
      operator delete(*(void **)&v36[1]);
  }
  switch ( *((_DWORD *)this + 4) )
  {
    case 0:
      *(_DWORD *)&__args[8].gap0 = 0;
      *(_QWORD *)&__args[0].gap0 = 0;
      v17 = 0;
      v18 = 0;
      v19 = 0;
      goto LABEL_27;
    case 1:
      *(_DWORD *)&__args[8].gap0 = 0;
      *(_QWORD *)&__args[0].gap0 = 0;
      v19 = 11520;
      v18 = 45;
      v17 = 4;
      goto LABEL_27;
    case 2:
    case 3:
    case 5:
    case 6:
    case 7:
      goto LABEL_64;
    case 4:
      goto LABEL_23;
    case 8:
      *(_DWORD *)&__args[8].gap0 = 0;
      *(_QWORD *)&__args[0].gap0 = 0;
      v18 = 47;
      goto LABEL_25;
    default:
      if ( *((_DWORD *)this + 4) != 4096 )
      {
LABEL_64:
        exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
        std::logic_error::logic_error(
          exception,
          "error_with_option_name::m_option_style can only be one of [0, allow_dash_for_short, allow_slash_for_short, all"
          "ow_long_disguise or allow_long]");
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'std::logic_error,
          (void (*)(void *))&std::logic_error::~logic_error);
      }
LABEL_23:
      *(_DWORD *)&__args[8].gap0 = 0;
      *(_QWORD *)&__args[0].gap0 = 0;
      v18 = 45;
LABEL_25:
      v17 = 2;
      v19 = 0;
LABEL_27:
      *(_OWORD *)((char *)v36 + 8) = 0;
      LOBYTE(v36[0]) = 12;
      strcpy((char *)v36 + 1, "prefix");
      v20 = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__find_equal<std::string>(
              &v37,
              &__parent,
              (const std::string *)v36);
      v21 = (char *)*v20;
      if ( !*v20 )
      {
        v21 = (char *)operator new(0x50u);
        *((_QWORD *)v21 + 6) = *(_QWORD *)&v36[1];
        *((_OWORD *)v21 + 2) = v36[0];
        memset(v36, 0, 24);
        *(_OWORD *)(v21 + 56) = 0;
        *((_QWORD *)v21 + 9) = 0;
        v22 = __parent;
        *(_OWORD *)v21 = 0;
        *((_QWORD *)v21 + 2) = v22;
        *v20 = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_base_pointer)v21;
        if ( v37.__begin_node_->__left_ )
        {
          v37.__begin_node_ = v37.__begin_node_->__left_;
          v23 = *v20;
        }
        else
        {
          v23 = (std::__tree_node_base<void *> *)v21;
        }
        std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(v37.__pair1_.__value_.__left_, v23);
        ++v37.__pair3_.__value_;
      }
      v24 = v21 + 56;
      if ( (v21[56] & 1) != 0 )
      {
        **((_BYTE **)v21 + 9) = 0;
        *((_QWORD *)v21 + 8) = 0;
      }
      else
      {
        *v24 = 0;
      }
      std::string::reserve(v24, 0);
      v21[56] = v17;
      *(_WORD *)(v21 + 57) = v18 | v19;
      v21[59] = 0;
      *((_DWORD *)v21 + 17) = *(_DWORD *)&__args[8].gap0;
      *(_QWORD *)(v21 + 60) = *(_QWORD *)&__args[0].gap0;
      *((_QWORD *)v21 + 9) = 0;
      *(_DWORD *)&__args[8].gap0 = 0;
      *(_QWORD *)&__args[0].gap0 = 0;
      if ( (v36[0] & 1) != 0 )
        operator delete(*(void **)&v36[1]);
      v25 = (const boost::program_options::error_with_option_name *)*((_QWORD *)this + 6);
      if ( v25 == (const boost::program_options::error_with_option_name *)((char *)this + 56) )
        goto LABEL_51;
      break;
  }
  do
  {
    if ( std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__count_unique<std::string>(
           &v37,
           (const boost::program_options::error_with_option_name *)((char *)v25 + 32)) )
    {
      *(_QWORD *)&v36[0] = (char *)v25 + 32;
      ptr = std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
              &v37,
              (const boost::program_options::error_with_option_name *)((char *)v25 + 32),
              &stru_49910C,
              (std::tuple<const std::string &> *)v36,
              __args).first.__ptr_;
      left_low = LOBYTE(ptr[7].__left_);
      if ( (left_low & 1) != 0 )
      {
        if ( ptr[8].__left_ )
          goto LABEL_44;
      }
      else if ( left_low >> 1 )
      {
        goto LABEL_44;
      }
    }
    boost::program_options::error_with_option_name::replace_token(
      this,
      (const boost::program_options::error_with_option_name *)((char *)v25 + 56),
      (const boost::program_options::error_with_option_name *)((char *)v25 + 80));
LABEL_44:
    v28 = (const boost::program_options::error_with_option_name *)*((_QWORD *)v25 + 1);
    if ( v28 )
    {
      do
      {
        v29 = v28;
        v28 = *(const boost::program_options::error_with_option_name **)v28;
      }
      while ( v28 );
    }
    else
    {
      v29 = (const boost::program_options::error_with_option_name *)*((_QWORD *)v25 + 2);
      if ( *(const boost::program_options::error_with_option_name **)v29 != v25 )
      {
        v30 = (__int64)v25 + 16;
        do
        {
          v29 = *(const boost::program_options::error_with_option_name **)(*(_QWORD *)v30 + 16LL);
          v11 = *(_QWORD *)v29 == *(_QWORD *)v30;
          v30 = *(_QWORD *)v30 + 16LL;
        }
        while ( !v11 );
      }
    }
    v25 = v29;
  }
  while ( v29 != (const boost::program_options::error_with_option_name *)((char *)this + 56) );
LABEL_51:
  begin_node = v37.__begin_node_;
  if ( (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)v37.__begin_node_ != &v37.__pair1_ )
  {
    do
    {
      std::operator+<char>(__args, 37, &begin_node[4]);
      std::string::push_back(__args, 37);
      *(_QWORD *)&v36[1] = *(_QWORD *)&__args[16].gap0;
      v36[0] = *(_OWORD *)&__args[0].gap0;
      memset(__args, 0, 24);
      boost::program_options::error_with_option_name::replace_token(
        this,
        (const std::string *)v36,
        (const std::string *)&begin_node[7]);
      if ( (v36[0] & 1) != 0 )
        operator delete(*(void **)&v36[1]);
      if ( (__args[0].gap0 & 1) != 0 )
        operator delete(*(void **)&__args[16].gap0);
      p_left = &begin_node[1].__left_->__left_;
      if ( p_left )
      {
        do
        {
          left = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)p_left;
          p_left = (_QWORD *)*p_left;
        }
        while ( p_left );
      }
      else
      {
        left = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)begin_node[2].__left_;
        if ( left->__begin_node_ != begin_node )
        {
          v34 = (__int64)&begin_node[2];
          do
          {
            left = *(std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > **)(*(_QWORD *)v34 + 16LL);
            v11 = left->__begin_node_ == *(std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__iter_pointer *)v34;
            v34 = *(_QWORD *)v34 + 16LL;
          }
          while ( !v11 );
        }
      }
      begin_node = (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__iter_pointer)left;
    }
    while ( left != (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)&v37.__pair1_ );
  }
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    &v37,
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer)v37.__pair1_.__value_.__left_);
}


// Address: 0xe66130 | Name: _ZNK5boost15program_options16ambiguous_option23substitute_placeholdersERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall boost::program_options::ambiguous_option::substitute_placeholders(
        const boost::program_options::ambiguous_option *this,
        const std::string *original_error_template)
{
  int v2; // eax
  const std::string *v3; // rbx
  const std::string *v4; // rbp
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *p_pair1; // rsi
  char *v6; // rax
  unsigned int v7; // r14d
  unsigned __int64 v8; // rcx
  __int64 v9; // rax
  char *v10; // rsi
  unsigned __int64 v11; // rdx
  __int64 v12; // rax
  char *v13; // rsi
  unsigned __int64 v14; // rdx
  void **v15; // rbx
  void **v16; // rax
  void **v17; // rbp
  void *v18; // rdi
  __int128 v19; // [rsp+0h] [rbp-A8h] BYREF
  void *ptr; // [rsp+10h] [rbp-98h]
  void *v21; // [rsp+18h] [rbp-90h] BYREF
  void **v22; // [rsp+20h] [rbp-88h]
  _BYTE v23[16]; // [rsp+30h] [rbp-78h] BYREF
  void *v24; // [rsp+40h] [rbp-68h]
  std::__tree<std::string> v25; // [rsp+48h] [rbp-60h] BYREF
  _BYTE v26[16]; // [rsp+60h] [rbp-48h] BYREF
  void *v27; // [rsp+70h] [rbp-38h]

  v2 = *((_DWORD *)this + 4);
  if ( v2 == 8 || v2 == 4 )
  {
    boost::program_options::error_with_option_name::substitute_placeholders(this, original_error_template);
  }
  else
  {
    std::string::basic_string(v26, original_error_template);
    v3 = (const std::string *)*((_QWORD *)this + 15);
    v4 = (const std::string *)*((_QWORD *)this + 16);
    *(_OWORD *)&v25.__pair1_.__value_.__left_ = 0;
    v25.__begin_node_ = &v25.__pair1_.__value_;
    p_pair1 = &v25.__pair1_;
    if ( v3 != v4 )
    {
      do
      {
        std::__tree<std::string>::__emplace_hint_unique_key_args<std::string,std::string const&>(
          &v25,
          (std::__tree<std::string>::const_iterator)&v25.__pair1_,
          v3,
          v3);
        v3 = (const std::string *)((char *)v3 + 24);
      }
      while ( v4 != v3 );
      p_pair1 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)v25.__begin_node_;
    }
    std::vector<std::string>::vector<std::__tree_const_iterator<std::string,std::__tree_node<std::string,void *> *,long>>(
      (std::vector<std::string> *)&v21,
      (std::__tree_const_iterator<std::string,std::__tree_node<std::string,void *> *,long>)p_pair1,
      (std::enable_if<true,std::__tree_const_iterator<std::string,std::__tree_node<std::string,void *> *,long> >::type)&v25.__pair1_);
    std::string::append(v26, " and matches ");
    v6 = (char *)v21;
    if ( 0xAAAAAAAAAAAAAAABLL * (((char *)v22 - (_BYTE *)v21) >> 3) >= 2 )
    {
      if ( (char *)v22 - (_BYTE *)v21 != 24 )
      {
        v7 = 1;
        v8 = 0;
        do
        {
          std::operator+<char>(v23, "'%prefix%", &v6[24 * v8]);
          v9 = std::string::append(v23, "', ");
          ptr = *(void **)(v9 + 16);
          v19 = *(_OWORD *)v9;
          *(_OWORD *)v9 = 0;
          *(_QWORD *)(v9 + 16) = 0;
          if ( (v19 & 1) != 0 )
          {
            v10 = (char *)ptr;
            v11 = *((_QWORD *)&v19 + 1);
          }
          else
          {
            v11 = (unsigned __int64)(unsigned __int8)v19 >> 1;
            v10 = (char *)&v19 + 1;
          }
          std::string::append(v26, v10, v11);
          if ( (v19 & 1) != 0 )
            operator delete(ptr);
          if ( (v23[0] & 1) != 0 )
            operator delete(v24);
          v8 = v7;
          v6 = (char *)v21;
          ++v7;
        }
        while ( 0xAAAAAAAAAAAAAAABLL * (((char *)v22 - (_BYTE *)v21) >> 3) - 1 > v8 );
      }
      std::string::append(v26, "and ");
    }
    if ( 0xAAAAAAAAAAAAAAABLL * ((__int64)(*((_QWORD *)this + 16) - *((_QWORD *)this + 15)) >> 3) >= 2
      && (char *)v22 - (_BYTE *)v21 == 24 )
    {
      std::string::append(v26, "different versions of ");
    }
    std::operator+<char>(v23, "'%prefix%", v22 - 3);
    v12 = std::string::append(v23, "'");
    ptr = *(void **)(v12 + 16);
    v19 = *(_OWORD *)v12;
    *(_OWORD *)v12 = 0;
    *(_QWORD *)(v12 + 16) = 0;
    if ( (v19 & 1) != 0 )
    {
      v13 = (char *)ptr;
      v14 = *((_QWORD *)&v19 + 1);
    }
    else
    {
      v14 = (unsigned __int64)(unsigned __int8)v19 >> 1;
      v13 = (char *)&v19 + 1;
    }
    std::string::append(v26, v13, v14);
    if ( (v19 & 1) != 0 )
      operator delete(ptr);
    if ( (v23[0] & 1) != 0 )
      operator delete(v24);
    boost::program_options::error_with_option_name::substitute_placeholders(this, (const std::string *)v26);
    v15 = (void **)v21;
    if ( v21 )
    {
      v16 = v22;
      if ( v22 == v21 )
      {
        v18 = v21;
      }
      else
      {
        do
        {
          v17 = v16 - 3;
          if ( (*(_BYTE *)(v16 - 3) & 1) != 0 )
            operator delete(*(v16 - 1));
          v16 = v17;
        }
        while ( v15 != v17 );
        v18 = v21;
      }
      v22 = v15;
      operator delete(v18);
    }
    std::__tree<std::string>::destroy(&v25, (std::__tree<std::string>::__node_pointer)v25.__pair1_.__value_.__left_);
    if ( (v26[0] & 1) != 0 )
      operator delete(v27);
  }
}


// Address: 0xe66510 | Name: _ZN5boost15program_options16validation_error12get_templateENS1_6kind_tE
boost::program_options::validation_error *__fastcall boost::program_options::validation_error::get_template(
        boost::program_options::validation_error *this,
        boost::program_options::validation_error::kind_t a2,
        int a3)
{
  unsigned int v3; // edx
  const char *v4; // r14
  size_t v5; // rax
  size_t v6; // r13
  char *v7; // r12
  size_t v8; // rbx

  v3 = a3 - 30;
  if ( v3 > 4 )
    v4 = "unknown error";
  else
    v4 = (const char *)*((_QWORD *)&off_287DFE0 + (int)v3);
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v5 = strlen(v4);
  if ( v5 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(this);
    JUMPOUT(0xE665C5);
  }
  v6 = v5;
  if ( v5 >= 0x17 )
  {
    v8 = (v5 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v7 = (char *)operator new(v8);
    *((_QWORD *)this + 2) = v7;
    *(_QWORD *)this = v8 | 1;
    *((_QWORD *)this + 1) = v6;
  }
  else
  {
    *(_BYTE *)this = 2 * v5;
    v7 = (char *)this + 1;
    if ( !v5 )
      goto LABEL_10;
  }
  memcpy(v7, v4, v6);
LABEL_10:
  v7[v6] = 0;
  return this;
}


