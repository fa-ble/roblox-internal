// Address: 0x2606e40 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINSB_6config15asio_tls_client16transport_configEEEFvNS9_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISM_EENS0_22deadline_timer_serviceISM_SO_EEEEEENS9_8functionIFvRKNS9_10error_codeEEEERKNS_6system10error_codeEEJNSJ_ISI_EERSS_RSY_RKNS9_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEES10_EES1D_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  char *v9; // r13
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code>(
      &handler->handler_.handler_,
      &handler->handler_.arg1_);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (char *)operator new(0x101u);
    v9[256] = 0;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)(v9 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x26078a0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config15asio_tls_client16transport_configEEEFvNS5_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISI_EENS0_22deadline_timer_serviceISI_SK_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNSF_ISE_EERSO_RSU_RKNS5_12placeholders4__phILi1EEEEEESW_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // rbx
  char v10; // al
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(char ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( (unsigned __int8)*v9 <= 0x8Fu )
  {
    operator delete(v9);
LABEL_12:
    v9 = (char *)operator new(0x91u);
    v10 = -112;
  }
  v9[144] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v9 + 3) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  *((_OWORD *)v9 + 4) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 14) = v9 + 80;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 80,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 14) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 14) = 0;
  }
  *((_OWORD *)v9 + 8) = handler->arg1_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v17);
}


// Address: 0x260ff20 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_15wrapped_handlerINS0_10io_service6strandENSt3__18functionIFvvEEENS1_26is_continuation_if_runningEEESB_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,std::function<void ()(void)>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *handler)
{
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rax
  char **v6; // rax
  char *v7; // rbx
  char v8; // al
  boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *f; // rax
  boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *v10; // rax
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v12; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v15; // rbp
  _QWORD v16[2]; // [rsp+0h] [rbp-58h] BYREF
  unsigned __int64 v17; // [rsp+10h] [rbp-48h]
  boost::system::error_code v18; // [rsp+18h] [rbp-40h] BYREF

  v4 = __readfsqword(0xFFFFFFE0);
  if ( v4 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v4 != *impl )
    {
      v4 = *(_QWORD *)(v4 + 16);
      if ( !v4 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v4 + 8) )
    {
      _mm_lfence();
      boost::asio::io_service::strand::dispatch<std::function<void ()(void)>>(
        &handler->handler_.dispatcher_,
        &handler->handler_.handler_);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v5 = __readfsqword(0xFFFFFFD8);
  if ( v5 )
  {
    v6 = *(char ***)(v5 + 8);
    if ( v6 )
    {
      v7 = *v6;
      if ( *v6 )
      {
        *v6 = 0;
        v8 = *v7;
        if ( (unsigned __int8)*v7 > 0x8Fu )
          goto LABEL_13;
        operator delete(v7);
      }
    }
  }
  v7 = (char *)operator new(0x91u);
  v8 = -112;
LABEL_13:
  v7[144] = v8;
  *(_QWORD *)v7 = 0;
  *((_QWORD *)v7 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,std::function<void ()(void)>>>::do_complete;
  *((_DWORD *)v7 + 4) = 0;
  f = (boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *)handler->context_.__f_;
  if ( f )
  {
    if ( handler == f )
    {
      *((_QWORD *)v7 + 8) = v7 + 32;
      (*((void (__fastcall **)(std::function<void ()>::__base *, char *))handler->context_.__f_->_vptr$__base + 3))(
        handler->context_.__f_,
        v7 + 32);
    }
    else
    {
      *((_QWORD *)v7 + 8) = f;
      handler->context_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v7 + 8) = 0;
  }
  *((_OWORD *)v7 + 5) = handler->handler_.dispatcher_;
  v10 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *)handler->handler_.handler_.__f_;
  if ( v10 )
  {
    if ( &handler->handler_.handler_ == (std::function<void ()> *)v10 )
    {
      *((_QWORD *)v7 + 16) = v7 + 96;
      (*((void (__fastcall **)(std::function<void ()>::__base *, char *))handler->handler_.handler_.__f_->_vptr$__base
       + 3))(
        handler->handler_.handler_.__f_,
        v7 + 96);
    }
    else
    {
      *((_QWORD *)v7 + 16) = v10;
      handler->handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v7 + 16) = 0;
  }
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v7) )
  {
    v16[0] = *impl;
    v17 = __readfsqword(0xFFFFFFE0);
    v16[1] = v16;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v16);
    io_service = this->io_service_;
    v12 = *impl;
    v18.m_val = 0;
    v18.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,std::function<void ()(void)>>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v7,
      &v18,
      0);
    pthread_mutex_lock(&v12->mutex_.mutex_);
    front = v12->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v12->ready_queue_.front_;
      if ( v12->ready_queue_.back_ )
        p_front = &v12->ready_queue_.back_->next_;
      *p_front = front;
      v12->ready_queue_.back_ = v12->waiting_queue_.back_;
      v12->waiting_queue_ = 0;
    }
    v15 = v12->ready_queue_.front_;
    v12->locked_ = v15 != 0;
    pthread_mutex_unlock(&v12->mutex_.mutex_);
    if ( v15 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v12, 0);
    __writefsqword(0xFFFFFFE0, v17);
  }
}


// Address: 0x2610580 | Name: _ZN5boost4asio6detail14strand_service8dispatchINSt3__18functionIFvvEEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<std::function<void ()(void)>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        std::function<void ()> *handler)
{
  unsigned __int64 v4; // rax
  std::function<void ()>::__base *v5; // rdi
  unsigned __int64 v6; // rax
  char **v7; // rax
  char *v8; // rbx
  char v9; // al
  std::function<void ()> *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v12; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v15; // rbx
  _QWORD *exception; // rax
  _QWORD v17[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v18; // [rsp+18h] [rbp-40h]
  boost::system::error_code v19; // [rsp+20h] [rbp-38h] BYREF

  v4 = __readfsqword(0xFFFFFFE0);
  if ( !v4 )
    goto LABEL_8;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v4 != *impl )
  {
    v4 = *(_QWORD *)(v4 + 16);
    if ( !v4 )
      goto LABEL_8;
  }
  if ( !*(_QWORD *)(v4 + 8) )
  {
LABEL_8:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(char ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          v9 = *v8;
          if ( (unsigned __int8)*v8 > 0x4Fu )
            goto LABEL_14;
          operator delete(v8);
        }
      }
    }
    v8 = (char *)operator new(0x51u);
    v9 = 80;
LABEL_14:
    v8[80] = v9;
    *(_QWORD *)v8 = 0;
    *((_QWORD *)v8 + 1) = boost::asio::detail::completion_handler<std::function<void ()(void)>>::do_complete;
    *((_DWORD *)v8 + 4) = 0;
    f = (std::function<void ()> *)handler->__f_;
    if ( f )
    {
      if ( handler == f )
      {
        *((_QWORD *)v8 + 8) = v8 + 32;
        (*((void (__fastcall **)(std::function<void ()>::__base *, char *))handler->__f_->_vptr$__base + 3))(
          handler->__f_,
          v8 + 32);
      }
      else
      {
        *((_QWORD *)v8 + 8) = f;
        handler->__f_ = 0;
      }
    }
    else
    {
      *((_QWORD *)v8 + 8) = 0;
    }
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v8) )
    {
      v17[0] = *impl;
      v18 = __readfsqword(0xFFFFFFE0);
      v17[1] = v17;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v17);
      io_service = this->io_service_;
      v12 = *impl;
      v19.m_val = 0;
      v19.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<std::function<void ()(void)>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v8,
        &v19,
        0);
      pthread_mutex_lock(&v12->mutex_.mutex_);
      front = v12->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v12->ready_queue_.front_;
        if ( v12->ready_queue_.back_ )
          p_front = &v12->ready_queue_.back_->next_;
        *p_front = front;
        v12->ready_queue_.back_ = v12->waiting_queue_.back_;
        v12->waiting_queue_ = 0;
      }
      v15 = v12->ready_queue_.front_;
      v12->locked_ = v15 != 0;
      pthread_mutex_unlock(&v12->mutex_.mutex_);
      if ( v15 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v12, 0);
      __writefsqword(0xFFFFFFE0, v18);
    }
    return;
  }
  _mm_lfence();
  v5 = handler->__f_;
  if ( !v5 )
  {
    exception = __cxa_allocate_exception(8u);
    *exception = off_28852C8;
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::bad_function_call,
      (void (*)(void *))&std::exception::~exception);
  }
  (*((void (__fastcall **)(std::function<void ()>::__base *))v5->_vptr$__base + 6))(v5);
  _mm_sfence();
}


// Address: 0x2619b60 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config15asio_tls_client16transport_configEEEFvRKNS_6system10error_codeEmEJNS5_10shared_ptrISE_EERKNS5_12placeholders4__phILi1EEERKNSO_ILi2EEEEEESG_mEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *handler)
{
  unsigned __int64 v4; // rax
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd f; // rax
  websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> *v6; // rdi
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v12; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v15; // rbx
  _QWORD v16[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v17; // [rsp+18h] [rbp-40h]
  boost::system::error_code v18; // [rsp+20h] [rbp-38h] BYREF

  v4 = __readfsqword(0xFFFFFFE0);
  if ( !v4 )
    goto LABEL_9;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v4 != *impl )
  {
    v4 = *(_QWORD *)(v4 + 16);
    if ( !v4 )
      goto LABEL_9;
  }
  if ( !*(_QWORD *)(v4 + 8) )
  {
LABEL_9:
    v7 = __readfsqword(0xFFFFFFD8);
    if ( v7 )
    {
      v8 = *(_BYTE ***)(v7 + 8);
      if ( v8 )
      {
        v9 = *v8;
        if ( *v8 )
        {
          *v8 = 0;
          v10 = *v9;
          if ( *v9 > 0x4Fu )
            goto LABEL_15;
          operator delete(v9);
        }
      }
    }
    v9 = operator new(0x51u);
    v10 = 80;
LABEL_15:
    v9[80] = v10;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    *(_OWORD *)(v9 + 24) = *(_OWORD *)&handler->handler_.__f_;
    *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Td *)(v9 + 40) = handler->handler_.__bound_args_;
    handler->handler_.__bound_args_ = 0;
    *((_QWORD *)v9 + 9) = handler->arg2_;
    *(boost::system::error_code *)(v9 + 56) = handler->arg1_;
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v16[0] = *impl;
      v17 = __readfsqword(0xFFFFFFE0);
      v16[1] = v16;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v16);
      io_service = this->io_service_;
      v12 = *impl;
      v18.m_val = 0;
      v18.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v18,
        0);
      pthread_mutex_lock(&v12->mutex_.mutex_);
      front = v12->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v12->ready_queue_.front_;
        if ( v12->ready_queue_.back_ )
          p_front = &v12->ready_queue_.back_->next_;
        *p_front = front;
        v12->ready_queue_.back_ = v12->waiting_queue_.back_;
        v12->waiting_queue_ = 0;
      }
      v15 = v12->ready_queue_.front_;
      v12->locked_ = v15 != 0;
      pthread_mutex_unlock(&v12->mutex_.mutex_);
      if ( v15 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v12, 0);
      __writefsqword(0xFFFFFFE0, v17);
    }
    return;
  }
  _mm_lfence();
  f = handler->handler_.__f_;
  v6 = (std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *)((char *)handler->handler_.__bound_args_.__base_.__value_.__ptr_ + *((_QWORD *)&handler->handler_.__f_ + 1));
  if ( ((__int64)handler->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd *)((char *)f + *(_QWORD *)v6 - 1);
  f(v6, &handler->arg1_, handler->arg2_);
  _mm_sfence();
}


// Address: 0x26216d0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSB_6config15asio_tls_client16transport_configEEEFvNS9_10shared_ptrINSD_10connectionISH_EEEENSJ_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISP_EENS0_22deadline_timer_serviceISP_SR_EEEEEENS9_8functionIFvRKNS9_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS16_3tcpEEEEJPSI_RSM_RSV_RS11_RKNS9_12placeholders4__phILi1EEERKNS1H_ILi2EEEEEENS1_26is_continuation_if_runningEEES13_S19_EES1O_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  char *v9; // r13
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
      &handler->handler_.handler_,
      &handler->handler_.arg1_,
      &handler->handler_.arg2_);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (char *)operator new(0x141u);
    v9[320] = 0;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)(v9 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x2622190 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS7_6config15asio_tls_client16transport_configEEEFvNS5_10shared_ptrINS9_10connectionISD_EEEENSF_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS12_3tcpEEEEJPSE_RSI_RSR_RSX_RKNS5_12placeholders4__phILi1EEERKNS1D_ILi2EEEEEESZ_S15_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xBFu )
  {
    operator delete(v9);
LABEL_12:
    v9 = operator new(0xC1u);
    v10 = -64;
  }
  v9[192] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_QWORD *)v9 + 6) = handler->handler_.__bound_args_.__base_.__value_;
  *(std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)(v9 + 56) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)(v9 + 72) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 16) = v9 + 96;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 96,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 16) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 16) = 0;
  }
  *((_OWORD *)v9 + 9) = handler->arg1_;
  *((_OWORD *)v9 + 10) = handler->arg2_.values_;
  handler->arg2_.values_ = 0;
  *((_QWORD *)v9 + 22) = handler->arg2_.index_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(&v17);
}


// Address: 0x2625c20 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EENS7_23basic_resolver_iteratorIS8_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSJ_6config15asio_tls_client16transport_configEEEFvNSH_10shared_ptrINSL_10connectionISP_EEEENSR_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISX_EENS0_22deadline_timer_serviceISX_SZ_EEEEEENSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJPSQ_RSU_RS13_RS19_RKNSH_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES1B_EES1P_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  char *v9; // rbx
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      &handler->handler_.handler_,
      handler->handler_.arg1_,
      0);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (char *)operator new(0x161u);
    v9[352] = 0;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)(v9 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x2626680 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS7_6config15asio_tls_client16transport_configEEEFvNS5_10shared_ptrINS9_10connectionISD_EEEENSF_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJPSE_RSI_RSR_RSX_RKNS5_12placeholders4__phILi1EEEEEESZ_NS0_2ip23basic_resolver_iteratorINS1E_3tcpEEEEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xBFu )
  {
    operator delete(v9);
LABEL_12:
    v9 = operator new(0xC1u);
    v10 = -64;
  }
  v9[192] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_QWORD *)v9 + 6) = handler->handler_.__bound_args_.__base_.__value_;
  *(std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)(v9 + 56) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)(v9 + 72) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 16) = v9 + 96;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 96,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 16) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 16) = 0;
  }
  *((_OWORD *)v9 + 9) = handler->arg1_;
  *((_OWORD *)v9 + 10) = handler->arg2_.values_;
  handler->arg2_.values_ = 0;
  *((_QWORD *)v9 + 22) = handler->arg2_.index_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(&v17);
}


// Address: 0x262ad60 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENSt3__16vectorINS0_12const_bufferENSD_9allocatorISF_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENSD_6__bindIMN11websocketpp9transport4asio10connectionINSO_6config15asio_tls_client16transport_configEEEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEEJNSD_10shared_ptrISV_EERS11_RKNSD_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES13_mEES1G_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  boost::asio::detail::operation *v9; // rbx
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)handler + 80),
      (const boost::system::error_code *)handler + 17,
      *((_QWORD *)handler + 36),
      0);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (boost::asio::detail::operation *)operator new(0x151u);
    LOBYTE(v9[14].next_) = 0;
    v9->next_ = 0;
    v9->func_ = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    v9->task_result_ = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&v9[1].func_,
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x262b840 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config15asio_tls_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISE_EERSK_RKNS5_12placeholders4__phILi1EEEEEESM_mEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // rbx
  char v10; // al
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(char ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( (unsigned __int8)*v9 <= 0x8Fu )
  {
    operator delete(v9);
LABEL_12:
    v9 = (char *)operator new(0x91u);
    v10 = -112;
  }
  v9[144] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v9 + 3) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 12) = v9 + 64;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 64,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 12) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 12) = 0;
  }
  *((_QWORD *)v9 + 16) = handler->arg2_;
  *((_OWORD *)v9 + 7) = handler->arg1_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v17);
}


// Address: 0x262e180 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSD_6__bindIMN11websocketpp9transport4asio10connectionINSK_6config15asio_tls_client16transport_configEEEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEmEJNSD_10shared_ptrISR_EERSX_RKNSD_12placeholders4__phILi1EEERKNS18_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESZ_mEES1F_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  boost::asio::detail::operation *v9; // r13
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)((char *)handler + 80),
      (const boost::system::error_code *)handler + 15,
      *((_QWORD *)handler + 32),
      0);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (boost::asio::detail::operation *)operator new(0x131u);
    LOBYTE(v9[12].task_result_) = 0;
    v9->next_ = 0;
    v9->func_ = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete;
    v9->task_result_ = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&v9[1].func_,
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete(
        io_service,
        v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x262e7b0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config15asio_tls_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEmEJNS5_10shared_ptrISE_EERSK_RKNS5_12placeholders4__phILi1EEERKNSV_ILi2EEEEEESM_mEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // rbx
  char v10; // al
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(char ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( (unsigned __int8)*v9 <= 0x8Fu )
  {
    operator delete(v9);
LABEL_12:
    v9 = (char *)operator new(0x91u);
    v10 = -112;
  }
  v9[144] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v9 + 3) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 12) = v9 + 64;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 64,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 12) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 12) = 0;
  }
  *((_QWORD *)v9 + 16) = handler->arg2_;
  *((_OWORD *)v9 + 7) = handler->arg1_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v17);
}


// Address: 0x2633120 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder2INS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISB_EEEENS7_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSJ_8functionIFvRKNSJ_10error_codeEEEERKNS_6system10error_codeEEJNSJ_10shared_ptrISP_EERSV_RKNSJ_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEESX_mEES1A_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  char *v9; // rbx
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      &handler->handler_.handler_,
      handler->handler_.arg1_,
      handler->handler_.arg2_,
      0);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (char *)operator new(0x131u);
    v9[304] = 0;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)(v9 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x26343c0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder1INS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISB_EEEENS7_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSJ_8functionIFvRKNSJ_10error_codeEEEERKNS_6system10error_codeEEJNSJ_10shared_ptrISP_EERSV_RKNSJ_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEESX_EES1A_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  char *v9; // rbx
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      &handler->handler_.handler_,
      handler->handler_.arg1_,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (char *)operator new(0x121u);
    v9[288] = 0;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)(v9 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x26355a0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS0_17mutable_buffers_1ENS1_14transfer_all_tENS0_3ssl6detail5io_opISC_NSG_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSM_8functionIFvRKNSM_10error_codeEEEERKNS_6system10error_codeEEJNSM_10shared_ptrISS_EERSY_RKNSM_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEES10_mEES1D_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 arg2; // rax
  size_t v7; // rcx
  size_t size; // rax
  unsigned __int64 v9; // rax
  void **v10; // rax
  void *v11; // rdi
  char *v12; // rbx
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v14; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v17; // rbx
  char *v18; // rdi
  bool v19; // cf
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *stream; // rsi
  unsigned __int64 v21; // rax
  size_t v22; // rcx
  boost::asio::mutable_buffers_1 buffers; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v24; // [rsp+18h] [rbp-40h]
  boost::system::error_code v25; // [rsp+20h] [rbp-38h] BYREF
  boost::system::error_code v26; // 0:esi.4,8:rdx.8

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_10;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_10;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    arg2 = handler->handler_.arg2_;
    handler->handler_.handler_.start_ = 0;
    v7 = arg2 + handler->handler_.handler_.total_transferred_;
    handler->handler_.handler_.total_transferred_ = v7;
    v26.m_val = handler->handler_.arg1_.m_val;
    if ( !arg2 || v26.m_val || (size = handler->handler_.handler_.buffer_.size_, v7 == size) )
    {
      v26.m_cat = handler->handler_.arg1_.m_cat;
      boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
        &handler->handler_.handler_.handler_,
        v26,
        v7,
        0);
    }
    else
    {
      v18 = 0;
      v19 = size < v7;
      if ( size < v7 )
        size = v7;
      stream = handler->handler_.handler_.stream_;
      if ( !v19 )
        v18 = (char *)handler->handler_.handler_.buffer_.data_ + v7;
      v21 = size - v7;
      v22 = 0x10000;
      if ( v21 < 0x10000 )
        v22 = v21;
      buffers.data_ = v18;
      buffers.size_ = v22;
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>>(
        stream->service_,
        &stream->implementation,
        &buffers,
        0,
        &handler->handler_.handler_);
    }
    _mm_sfence();
  }
  else
  {
LABEL_10:
    v9 = __readfsqword(0xFFFFFFD8);
    if ( v9 )
    {
      v10 = *(void ***)(v9 + 8);
      if ( v10 )
      {
        v11 = *v10;
        if ( *v10 )
        {
          *v10 = 0;
          operator delete(v11);
        }
      }
    }
    v12 = (char *)operator new(0x161u);
    v12[352] = 0;
    *(_QWORD *)v12 = 0;
    *((_QWORD *)v12 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    *((_DWORD *)v12 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)(v12 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v12) )
    {
      buffers.data_ = *impl;
      v24 = __readfsqword(0xFFFFFFE0);
      buffers.size_ = (size_t)&buffers;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)&buffers);
      io_service = this->io_service_;
      v14 = *impl;
      v25.m_val = 0;
      v25.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v12,
        &v25,
        0);
      pthread_mutex_lock(&v14->mutex_.mutex_);
      front = v14->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v14->ready_queue_.front_;
        if ( v14->ready_queue_.back_ )
          p_front = &v14->ready_queue_.back_->next_;
        *p_front = front;
        v14->ready_queue_.back_ = v14->waiting_queue_.back_;
        v14->waiting_queue_ = 0;
      }
      v17 = v14->ready_queue_.front_;
      v14->locked_ = v17 != 0;
      pthread_mutex_unlock(&v14->mutex_.mutex_);
      if ( v17 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v14, 0);
      __writefsqword(0xFFFFFFE0, v24);
    }
  }
}


// Address: 0x2636200 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISB_EERSH_RKNS5_12placeholders4__phILi1EEEEEESJ_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // rbx
  char v10; // al
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(char ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 >= 0 )
  {
    operator delete(v9);
LABEL_12:
    v9 = (char *)operator new(0x81u);
    v10 = 0x80;
  }
  v9[128] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v9 + 3) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 12) = v9 + 64;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 64,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 12) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 12) = 0;
  }
  *((_OWORD *)v9 + 7) = handler->arg1_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v17);
}


// Address: 0x26571b0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINSB_6config11asio_client16transport_configEEEFvNS9_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISM_EENS0_22deadline_timer_serviceISM_SO_EEEEEENS9_8functionIFvRKNS9_10error_codeEEEERKNS_6system10error_codeEEJNSJ_ISI_EERSS_RSY_RKNS9_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEES10_EES1D_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  char *v9; // r13
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code>(
      &handler->handler_.handler_,
      &handler->handler_.arg1_);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (char *)operator new(0x101u);
    v9[256] = 0;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)(v9 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x2657b00 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config11asio_client16transport_configEEEFvNS5_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISI_EENS0_22deadline_timer_serviceISI_SK_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNSF_ISE_EERSO_RSU_RKNS5_12placeholders4__phILi1EEEEEESW_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // rbx
  char v10; // al
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(char ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( (unsigned __int8)*v9 <= 0x8Fu )
  {
    operator delete(v9);
LABEL_12:
    v9 = (char *)operator new(0x91u);
    v10 = -112;
  }
  v9[144] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v9 + 3) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  *((_OWORD *)v9 + 4) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 14) = v9 + 80;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 80,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 14) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 14) = 0;
  }
  *((_OWORD *)v9 + 8) = handler->arg1_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v17);
}


// Address: 0x265f920 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config11asio_client16transport_configEEEFvRKNS_6system10error_codeEmEJNS5_10shared_ptrISE_EERKNS5_12placeholders4__phILi1EEERKNSO_ILi2EEEEEESG_mEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *handler)
{
  unsigned __int64 v4; // rax
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd f; // rax
  websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> *v6; // rdi
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v12; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v15; // rbx
  _QWORD v16[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v17; // [rsp+18h] [rbp-40h]
  boost::system::error_code v18; // [rsp+20h] [rbp-38h] BYREF

  v4 = __readfsqword(0xFFFFFFE0);
  if ( !v4 )
    goto LABEL_9;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v4 != *impl )
  {
    v4 = *(_QWORD *)(v4 + 16);
    if ( !v4 )
      goto LABEL_9;
  }
  if ( !*(_QWORD *)(v4 + 8) )
  {
LABEL_9:
    v7 = __readfsqword(0xFFFFFFD8);
    if ( v7 )
    {
      v8 = *(_BYTE ***)(v7 + 8);
      if ( v8 )
      {
        v9 = *v8;
        if ( *v8 )
        {
          *v8 = 0;
          v10 = *v9;
          if ( *v9 > 0x4Fu )
            goto LABEL_15;
          operator delete(v9);
        }
      }
    }
    v9 = operator new(0x51u);
    v10 = 80;
LABEL_15:
    v9[80] = v10;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    *(_OWORD *)(v9 + 24) = *(_OWORD *)&handler->handler_.__f_;
    *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Td *)(v9 + 40) = handler->handler_.__bound_args_;
    handler->handler_.__bound_args_ = 0;
    *((_QWORD *)v9 + 9) = handler->arg2_;
    *(boost::system::error_code *)(v9 + 56) = handler->arg1_;
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v16[0] = *impl;
      v17 = __readfsqword(0xFFFFFFE0);
      v16[1] = v16;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v16);
      io_service = this->io_service_;
      v12 = *impl;
      v18.m_val = 0;
      v18.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v18,
        0);
      pthread_mutex_lock(&v12->mutex_.mutex_);
      front = v12->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v12->ready_queue_.front_;
        if ( v12->ready_queue_.back_ )
          p_front = &v12->ready_queue_.back_->next_;
        *p_front = front;
        v12->ready_queue_.back_ = v12->waiting_queue_.back_;
        v12->waiting_queue_ = 0;
      }
      v15 = v12->ready_queue_.front_;
      v12->locked_ = v15 != 0;
      pthread_mutex_unlock(&v12->mutex_.mutex_);
      if ( v15 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v12, 0);
      __writefsqword(0xFFFFFFE0, v17);
    }
    return;
  }
  _mm_lfence();
  f = handler->handler_.__f_;
  v6 = (std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *)((char *)handler->handler_.__bound_args_.__base_.__value_.__ptr_ + *((_QWORD *)&handler->handler_.__f_ + 1));
  if ( ((__int64)handler->handler_.__f_ & 1) != 0 )
    f = *(std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd *)((char *)f + *(_QWORD *)v6 - 1);
  f(v6, &handler->arg1_, handler->arg2_);
  _mm_sfence();
}


// Address: 0x2663b80 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSB_6config11asio_client16transport_configEEEFvNS9_10shared_ptrINSD_10connectionISH_EEEENSJ_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISP_EENS0_22deadline_timer_serviceISP_SR_EEEEEENS9_8functionIFvRKNS9_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS16_3tcpEEEEJPSI_RSM_RSV_RS11_RKNS9_12placeholders4__phILi1EEERKNS1H_ILi2EEEEEENS1_26is_continuation_if_runningEEES13_S19_EES1O_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  char *v9; // r13
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
      &handler->handler_.handler_,
      &handler->handler_.arg1_,
      &handler->handler_.arg2_);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (char *)operator new(0x141u);
    v9[320] = 0;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)(v9 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x2664640 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS7_6config11asio_client16transport_configEEEFvNS5_10shared_ptrINS9_10connectionISD_EEEENSF_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS12_3tcpEEEEJPSE_RSI_RSR_RSX_RKNS5_12placeholders4__phILi1EEERKNS1D_ILi2EEEEEESZ_S15_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xBFu )
  {
    operator delete(v9);
LABEL_12:
    v9 = operator new(0xC1u);
    v10 = -64;
  }
  v9[192] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_QWORD *)v9 + 6) = handler->handler_.__bound_args_.__base_.__value_;
  *(std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)(v9 + 56) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)(v9 + 72) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 16) = v9 + 96;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 96,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 16) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 16) = 0;
  }
  *((_OWORD *)v9 + 9) = handler->arg1_;
  *((_OWORD *)v9 + 10) = handler->arg2_.values_;
  handler->arg2_.values_ = 0;
  *((_QWORD *)v9 + 22) = handler->arg2_.index_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(&v17);
}


// Address: 0x26676a0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EENS7_23basic_resolver_iteratorIS8_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSJ_6config11asio_client16transport_configEEEFvNSH_10shared_ptrINSL_10connectionISP_EEEENSR_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISX_EENS0_22deadline_timer_serviceISX_SZ_EEEEEENSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJPSQ_RSU_RS13_RS19_RKNSH_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES1B_EES1P_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  char *v9; // rbx
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      &handler->handler_.handler_,
      handler->handler_.arg1_,
      0);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (char *)operator new(0x161u);
    v9[352] = 0;
    *(_QWORD *)v9 = 0;
    *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    *((_DWORD *)v9 + 4) = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)(v9 + 32),
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        (boost::asio::detail::operation *)v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x2668020 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS7_6config11asio_client16transport_configEEEFvNS5_10shared_ptrINS9_10connectionISD_EEEENSF_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJPSE_RSI_RSR_RSX_RKNS5_12placeholders4__phILi1EEEEEESZ_NS0_2ip23basic_resolver_iteratorINS1E_3tcpEEEEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  _BYTE **v8; // rax
  _BYTE *v9; // rbx
  char v10; // al
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(_BYTE ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( *v9 <= 0xBFu )
  {
    operator delete(v9);
LABEL_12:
    v9 = operator new(0xC1u);
    v10 = -64;
  }
  v9[192] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_QWORD *)v9 + 6) = handler->handler_.__bound_args_.__base_.__value_;
  *(std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)(v9 + 56) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)(v9 + 72) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 16) = v9 + 96;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 96,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 16) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 16) = 0;
  }
  *((_OWORD *)v9 + 9) = handler->arg1_;
  *((_OWORD *)v9 + 10) = handler->arg2_.values_;
  handler->arg2_.values_ = 0;
  *((_QWORD *)v9 + 22) = handler->arg2_.index_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(&v17);
}


// Address: 0x266c180 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENSt3__16vectorINS0_12const_bufferENSD_9allocatorISF_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENSD_6__bindIMN11websocketpp9transport4asio10connectionINSO_6config11asio_client16transport_configEEEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEEJNSD_10shared_ptrISV_EERS11_RKNSD_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES13_mEES1G_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  boost::asio::detail::operation *v9; // rbx
  boost::asio::detail::io_service_impl *io_service; // r15
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)handler + 80),
      (const boost::system::error_code *)handler + 17,
      *((_QWORD *)handler + 36),
      0);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (boost::asio::detail::operation *)operator new(0x151u);
    LOBYTE(v9[14].next_) = 0;
    v9->next_ = 0;
    v9->func_ = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
    v9->task_result_ = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&v9[1].func_,
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        io_service,
        v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x266cb70 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config11asio_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISE_EERSK_RKNS5_12placeholders4__phILi1EEEEEESM_mEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // rbx
  char v10; // al
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(char ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( (unsigned __int8)*v9 <= 0x8Fu )
  {
    operator delete(v9);
LABEL_12:
    v9 = (char *)operator new(0x91u);
    v10 = -112;
  }
  v9[144] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v9 + 3) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 12) = v9 + 64;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 64,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 12) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 12) = 0;
  }
  *((_QWORD *)v9 + 16) = handler->arg2_;
  *((_OWORD *)v9 + 7) = handler->arg1_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v17);
}


// Address: 0x266f4b0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSD_6__bindIMN11websocketpp9transport4asio10connectionINSK_6config11asio_client16transport_configEEEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEmEJNSD_10shared_ptrISR_EERSX_RKNSD_12placeholders4__phILi1EEERKNS18_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESZ_mEES1F_EEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *handler)
{
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax
  void **v7; // rax
  void *v8; // rdi
  boost::asio::detail::operation *v9; // r13
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v11; // r12
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v14; // rbx
  _QWORD v15[2]; // [rsp+8h] [rbp-50h] BYREF
  unsigned __int64 v16; // [rsp+18h] [rbp-40h]
  boost::system::error_code v17; // [rsp+20h] [rbp-38h] BYREF

  v5 = __readfsqword(0xFFFFFFE0);
  if ( !v5 )
    goto LABEL_7;
  while ( *(boost::asio::detail::strand_service::implementation_type *)v5 != *impl )
  {
    v5 = *(_QWORD *)(v5 + 16);
    if ( !v5 )
      goto LABEL_7;
  }
  if ( *(_QWORD *)(v5 + 8) )
  {
    _mm_lfence();
    boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)((char *)handler + 80),
      (const boost::system::error_code *)handler + 15,
      *((_QWORD *)handler + 32),
      0);
    _mm_sfence();
  }
  else
  {
LABEL_7:
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(void ***)(v6 + 8);
      if ( v7 )
      {
        v8 = *v7;
        if ( *v7 )
        {
          *v7 = 0;
          operator delete(v8);
        }
      }
    }
    v9 = (boost::asio::detail::operation *)operator new(0x131u);
    LOBYTE(v9[12].task_result_) = 0;
    v9->next_ = 0;
    v9->func_ = boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete;
    v9->task_result_ = 0;
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&v9[1].func_,
      handler);
    if ( boost::asio::detail::strand_service::do_dispatch(this, impl, v9) )
    {
      v15[0] = *impl;
      v16 = __readfsqword(0xFFFFFFE0);
      v15[1] = v15;
      __writefsqword(0xFFFFFFE0, (unsigned __int64)v15);
      io_service = this->io_service_;
      v11 = *impl;
      v17.m_val = 0;
      v17.m_cat = boost::system::system_category();
      boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete(
        io_service,
        v9,
        &v17,
        0);
      pthread_mutex_lock(&v11->mutex_.mutex_);
      front = v11->waiting_queue_.front_;
      if ( front )
      {
        p_front = &v11->ready_queue_.front_;
        if ( v11->ready_queue_.back_ )
          p_front = &v11->ready_queue_.back_->next_;
        *p_front = front;
        v11->ready_queue_.back_ = v11->waiting_queue_.back_;
        v11->waiting_queue_ = 0;
      }
      v14 = v11->ready_queue_.front_;
      v11->locked_ = v14 != 0;
      pthread_mutex_unlock(&v11->mutex_.mutex_);
      if ( v14 )
        boost::asio::detail::task_io_service::post_immediate_completion(io_service, v11, 0);
      __writefsqword(0xFFFFFFE0, v16);
    }
  }
}


// Address: 0x266fae0 | Name: _ZN5boost4asio6detail14strand_service8dispatchINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config11asio_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEmEJNS5_10shared_ptrISE_EERSK_RKNS5_12placeholders4__phILi1EEERKNSV_ILi2EEEEEESM_mEEEEvRPNS2_11strand_implERT_
void __fastcall boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
        boost::asio::detail::strand_service *this,
        boost::asio::detail::strand_service::implementation_type *impl,
        boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *handler)
{
  __int64 v3; // r8
  __int64 v4; // r9
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // rbx
  char v10; // al
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *f; // rax
  boost::asio::detail::io_service_impl *io_service; // r14
  boost::asio::detail::strand_service::implementation_type v13; // r13
  boost::asio::detail::task_io_service_operation *front; // rax
  _QWORD *p_front; // rdx
  boost::asio::detail::task_io_service_operation *v16; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::ptr v17; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v18[2]; // [rsp+18h] [rbp-50h] BYREF
  unsigned __int64 v19; // [rsp+28h] [rbp-40h]
  boost::system::error_code v20; // [rsp+30h] [rbp-38h] BYREF

  v6 = __readfsqword(0xFFFFFFE0);
  if ( v6 )
  {
    while ( *(boost::asio::detail::strand_service::implementation_type *)v6 != *impl )
    {
      v6 = *(_QWORD *)(v6 + 16);
      if ( !v6 )
        goto LABEL_7;
    }
    if ( *(_QWORD *)(v6 + 8) )
    {
      _mm_lfence();
      boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>::operator()(handler);
      _mm_sfence();
      return;
    }
  }
LABEL_7:
  v17.h = handler;
  v7 = __readfsqword(0xFFFFFFD8);
  if ( !v7 )
    goto LABEL_12;
  v8 = *(char ***)(v7 + 8);
  if ( !v8 )
    goto LABEL_12;
  v9 = *v8;
  if ( !*v8 )
    goto LABEL_12;
  *v8 = 0;
  v10 = *v9;
  if ( (unsigned __int8)*v9 <= 0x8Fu )
  {
    operator delete(v9);
LABEL_12:
    v9 = (char *)operator new(0x91u);
    v10 = -112;
  }
  v9[144] = v10;
  v17.v = v9;
  v17.p = 0;
  *(_QWORD *)v9 = 0;
  *((_QWORD *)v9 + 1) = boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete;
  *((_DWORD *)v9 + 4) = 0;
  *((_OWORD *)v9 + 2) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v9 + 3) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v9 + 12) = v9 + 64;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *, void *, boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v9 + 64,
        handler,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v3,
        v4,
        v17.h,
        v17.v,
        v17.p);
    }
    else
    {
      *((_QWORD *)v9 + 12) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v9 + 12) = 0;
  }
  *((_QWORD *)v9 + 16) = handler->arg2_;
  *((_OWORD *)v9 + 7) = handler->arg1_;
  *(_OWORD *)&v17.v = 0;
  if ( boost::asio::detail::strand_service::do_dispatch(this, impl, (boost::asio::detail::operation *)v9) )
  {
    v18[0] = *impl;
    v19 = __readfsqword(0xFFFFFFE0);
    v18[1] = v18;
    __writefsqword(0xFFFFFFE0, (unsigned __int64)v18);
    io_service = this->io_service_;
    v13 = *impl;
    v20.m_val = 0;
    v20.m_cat = boost::system::system_category();
    boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete(
      io_service,
      (boost::asio::detail::operation *)v9,
      &v20,
      0);
    pthread_mutex_lock(&v13->mutex_.mutex_);
    front = v13->waiting_queue_.front_;
    if ( front )
    {
      p_front = &v13->ready_queue_.front_;
      if ( v13->ready_queue_.back_ )
        p_front = &v13->ready_queue_.back_->next_;
      *p_front = front;
      v13->ready_queue_.back_ = v13->waiting_queue_.back_;
      v13->waiting_queue_ = 0;
    }
    v16 = v13->ready_queue_.front_;
    v13->locked_ = v16 != 0;
    pthread_mutex_unlock(&v13->mutex_.mutex_);
    if ( v16 )
      boost::asio::detail::task_io_service::post_immediate_completion(io_service, v13, 0);
    __writefsqword(0xFFFFFFE0, v19);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v17);
}


