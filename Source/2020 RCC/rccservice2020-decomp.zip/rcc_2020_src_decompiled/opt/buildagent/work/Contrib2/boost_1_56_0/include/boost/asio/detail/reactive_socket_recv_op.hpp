// Address: 0x260a2d0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESJ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v4; // rbx
  boost::asio::detail::operation *next; // rdi
  boost::asio::detail::operation *v7; // rdi
  unsigned __int64 v8; // rax
  boost::asio::detail::operation **v9; // rax
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > v10; // [rsp+0h] [rbp-B8h] BYREF
  __int128 ec; // [rsp+70h] [rbp-48h]
  size_t bytes_transferred; // [rsp+80h] [rbp-38h]
  unsigned __int64 v13; // [rsp+98h] [rbp-20h]
  boost::system::error_code v14; // 0:kr00_16.16

  v4 = base;
  v13 = __readfsqword(0x28u);
  *(_OWORD *)&v10.next_layer_ = *(_OWORD *)&base[4].next_;
  v10.start_ = *(&base[4].task_result_ + 1);
  v10.want_ = (boost::asio::ssl::detail::engine::want)base[5].next_;
  v10.ec_ = *(boost::system::error_code *)&base[5].func_;
  v10.bytes_transferred_ = (size_t)base[6].next_;
  next = base[8].next_;
  if ( next )
  {
    if ( &base[6].task_result_ == (unsigned int *)next )
    {
      v10.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&v10.handler_;
      base = (boost::asio::detail::operation *)&v10.handler_;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::function<void (const boost::system::error_code &)> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &v10.handler_,
        a3,
        a4);
    }
    else
    {
      v10.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)base[8].next_;
      base[8].next_ = 0;
    }
  }
  else
  {
    v10.handler_.__f_ = 0;
  }
  ec = *(_OWORD *)&v4[1].next_;
  bytes_transferred = *(_QWORD *)&v4[1].task_result_;
  v7 = v4[8].next_;
  if ( &v4[6].task_result_ == (unsigned int *)v7 )
  {
    v7->next_[1].func_((boost::asio::detail::task_io_service *)v7, base, a3, a4);
  }
  else if ( v7 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&v7->next_[1].task_result_)(
      v7,
      base,
      a3,
      a4);
  }
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 || (v9 = *(boost::asio::detail::operation ***)(v8 + 8)) == 0 || *v9 )
  {
    operator delete(v4);
    if ( !owner )
      goto LABEL_15;
    goto LABEL_14;
  }
  LOBYTE(v4->next_) = v4[8].task_result_;
  *v9 = v4;
  if ( owner )
  {
LABEL_14:
    base = (boost::asio::detail::operation *)(unsigned int)ec;
    v14.m_val = ec;
    v14.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>::operator()(
      &v10,
      v14,
      bytes_transferred,
      0);
    _mm_sfence();
  }
LABEL_15:
  if ( &v10.handler_ == (std::function<void (const boost::system::error_code &)> *)v10.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v10.handler_.__f_->_vptr$__base
     + 4))(v10.handler_.__f_);
  }
  else if ( v10.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *, boost::asio::detail::operation *))v10.handler_.__f_->_vptr$__base
     + 5))(
      v10.handler_.__f_,
      base);
  }
}


// Address: 0x260a480 | Name: _ZN5boost4asio6detail28reactive_socket_recv_op_baseINS0_17mutable_buffers_1EE10do_performEPNS1_10reactor_opE
bool __fastcall boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform(
        boost::asio::detail::reactor_op *base)
{
  boost::asio::detail::socket_ops::buf bufs; // [rsp+10h] [rbp-18h] BYREF
  unsigned __int64 v3; // [rsp+20h] [rbp-8h]

  bufs = (boost::asio::detail::socket_ops::buf)_mm_loadu_si128((const __m128i *)&base[1].func_);
  v3 = _mm_shuffle_epi32((__m128i)bufs, 78).m128i_u64[0];
  return boost::asio::detail::socket_ops::non_blocking_recv(
           (boost::asio::detail::socket_type)base[1].next_,
           &bufs,
           1u,
           base[1].ec_.m_val,
           (unsigned __int8)(BYTE4(base[1].next_) & 0x10) >> 4,
           &base->ec_,
           &base->bytes_transferred_);
}


// Address: 0x2612fe0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_8write_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorISF_NSG_9allocatorISF_EEEEEEEENS1_8write_opINS4_6streamISC_EESK_NS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSG_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  void (*next)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t); // rdi
  boost::asio::detail::task_io_service_operation *v7; // rdi
  _BYTE v8[16]; // [rsp+0h] [rbp-148h] BYREF
  void *v9; // [rsp+10h] [rbp-138h]
  void *v10; // [rsp+18h] [rbp-130h]
  void *ptr; // [rsp+78h] [rbp-D0h]
  void *v12; // [rsp+80h] [rbp-C8h]
  __int64 v13; // [rsp+D0h] [rbp-78h]
  char v14; // [rsp+E0h] [rbp-68h] BYREF
  char *v15; // [rsp+100h] [rbp-48h]
  __int128 ec; // [rsp+110h] [rbp-38h]
  size_t bytes_transferred; // [rsp+120h] [rbp-28h]
  unsigned __int64 v18; // [rsp+130h] [rbp-18h]
  boost::system::error_code v19; // 0:esi.4,8:rdx.8

  v18 = __readfsqword(0x28u);
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v8,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)&base[4]);
  ec = *(_OWORD *)&base[1].next_;
  bytes_transferred = *(_QWORD *)&base[1].task_result_;
  if ( base )
  {
    v5 = *(boost::asio::detail::operation **)&base[14].task_result_;
    if ( &base[13].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v5->next_[1].func_)(v5);
    }
    else if ( v5 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v5->next_[1].task_result_)(v5);
    }
    next = (void (*)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t))base[9].next_;
    if ( next )
    {
      base[9].func_ = next;
      operator delete(next);
    }
    v7 = *(boost::asio::detail::task_io_service_operation **)&base[4].task_result_;
    if ( v7 )
    {
      base[5].next_ = v7;
      operator delete(v7);
    }
  }
  if ( (boost::asio::detail::operation *)v13 == base )
  {
    *(_BYTE *)(v13 + 1024) = 0;
    if ( !owner )
      goto LABEL_15;
    goto LABEL_14;
  }
  operator delete(base);
  if ( owner )
  {
LABEL_14:
    v19.m_val = ec;
    v19.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v8,
      v19,
      bytes_transferred,
      0);
    _mm_sfence();
  }
LABEL_15:
  if ( &v14 == v15 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v15 + 32LL))(v15);
  }
  else if ( v15 )
  {
    (*(void (**)(void))(*(_QWORD *)v15 + 40LL))();
  }
  if ( ptr )
  {
    v12 = ptr;
    operator delete(ptr);
  }
  if ( v9 )
  {
    v10 = v9;
    operator delete(v9);
  }
}


// Address: 0x2616af0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_7read_opIS3_EENS1_7read_opINS4_6streamISC_EES3_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESS_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::operation *v6; // rbx
  boost::asio::detail::operation *v8; // rdi
  boost::asio::detail::operation *v9; // rdi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > v10; // [rsp+0h] [rbp-F8h] BYREF
  __int128 ec; // [rsp+B0h] [rbp-48h]
  size_t bytes_transferred; // [rsp+C0h] [rbp-38h]
  unsigned __int64 v13; // [rsp+D8h] [rbp-20h]
  boost::system::error_code v14; // 0:esi.4,8:rdx.8

  v6 = base;
  v13 = __readfsqword(0x28u);
  *(_OWORD *)&v10.next_layer_ = *(_OWORD *)&base[4].next_;
  v10.op_ = *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&base[4].task_result_;
  *(_QWORD *)&v10.start_ = base[5].func_;
  v10.ec_ = *(boost::system::error_code *)&base[5].task_result_;
  *(_OWORD *)&v10.bytes_transferred_ = *(_OWORD *)&base[6].func_;
  *(boost::asio::detail::operation *)&v10.handler_.stream_ = base[7];
  v10.handler_.start_ = (int)base[8].next_;
  *(_OWORD *)&v10.handler_.total_transferred_ = *(_OWORD *)&base[8].func_;
  v8 = *(boost::asio::detail::operation **)&base[10].task_result_;
  if ( v8 )
  {
    if ( &base[9].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v8 )
    {
      v10.handler_.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v10.handler_.handler_.handler_;
      base = (boost::asio::detail::operation *)&v10.handler_.handler_.handler_;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::function<void (const boost::system::error_code &,unsigned long)> *, const boost::system::error_code *, size_t, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *, void *, size_t, int, size_t))v8->next_[1].next_)(
        v8,
        &v10.handler_.handler_.handler_,
        a3,
        a4,
        v4,
        v5,
        v10.next_layer_,
        v10.core_,
        v10.op_.buffers_.data_,
        v10.op_.buffers_.size_,
        *(_QWORD *)&v10.start_,
        *(_QWORD *)&v10.ec_.m_val,
        v10.ec_.m_cat,
        v10.bytes_transferred_,
        v10.handler_.completion_condition_.minimum_,
        v10.handler_.stream_,
        v10.handler_.buffer_.data_,
        v10.handler_.buffer_.size_,
        v10.handler_.start_,
        v10.handler_.total_transferred_);
    }
    else
    {
      v10.handler_.handler_.handler_.__f_ = *(std::function<void (const boost::system::error_code &,unsigned long)>::__base **)&base[10].task_result_;
      *(_QWORD *)&base[10].task_result_ = 0;
    }
  }
  else
  {
    v10.handler_.handler_.handler_.__f_ = 0;
  }
  ec = *(_OWORD *)&v6[1].next_;
  bytes_transferred = *(_QWORD *)&v6[1].task_result_;
  v9 = *(boost::asio::detail::operation **)&v6[10].task_result_;
  if ( &v6[9].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v9 )
  {
    v9->next_[1].func_((boost::asio::detail::task_io_service *)v9, base, a3, a4);
  }
  else if ( v9 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&v9->next_[1].task_result_)(
      v9,
      base,
      a3,
      a4);
  }
  if ( (boost::asio::detail::operation *)v10.handler_.handler_.allocator_ == v6 )
  {
    v10.handler_.handler_.allocator_->in_use_ = 0;
    if ( !owner )
      goto LABEL_15;
    goto LABEL_14;
  }
  operator delete(v6);
  if ( owner )
  {
LABEL_14:
    v14.m_val = ec;
    v14.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
      &v10,
      v14,
      bytes_transferred,
      0);
    _mm_sfence();
  }
LABEL_15:
  if ( &v10.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v10.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v10.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(v10.handler_.handler_.handler_.__f_);
  }
  else if ( v10.handler_.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v10.handler_.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x262db80 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > >::ptr v7; // [rsp+8h] [rbp-330h] BYREF
  __int128 v8; // [rsp+20h] [rbp-318h] BYREF
  __int128 v9; // [rsp+30h] [rbp-308h]
  void *ptr; // [rsp+40h] [rbp-2F8h]
  unsigned int task_result; // [rsp+48h] [rbp-2F0h]
  boost::asio::detail::task_io_service_operation *next; // [rsp+50h] [rbp-2E8h]
  boost::asio::detail::strand_service::implementation_type impl[2]; // [rsp+60h] [rbp-2D8h] BYREF
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> context; // [rsp+70h] [rbp-2C8h] BYREF
  boost::asio::detail::operation v15; // [rsp+C0h] [rbp-278h]
  _BYTE v16[272]; // [rsp+E0h] [rbp-258h] BYREF
  _BYTE v17[296]; // [rsp+1F0h] [rbp-148h] BYREF
  unsigned __int64 v18; // [rsp+318h] [rbp-20h]

  v18 = __readfsqword(0x28u);
  v7.h = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)&base[4];
  v7.v = base;
  v7.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *)base;
  v8 = *(_OWORD *)&base[4].next_;
  ptr = base[5].func_;
  v9 = *(_OWORD *)&base[4].task_result_;
  *(_OWORD *)&base[4].task_result_ = 0;
  base[5].func_ = 0;
  task_result = base[5].task_result_;
  next = base[6].next_;
  *(_OWORD *)impl = *(_OWORD *)&base[6].task_result_;
  *(_OWORD *)&context.__f_ = *(_OWORD *)&base[7].func_;
  context.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)&base[8].next_;
  *(_OWORD *)&base[8].next_ = 0;
  v5 = base[10].next_;
  if ( v5 )
  {
    if ( &base[8].task_result_ == (unsigned int *)v5 )
    {
      context.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&context.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))v5->next_[1].next_)(
        v5,
        &context.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      context.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[10].next_;
      base[10].next_ = 0;
    }
  }
  else
  {
    context.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v15 = base[1];
  v7.h = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)&v8;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v7);
  if ( owner )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v16,
      (boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)&v8,
      &context);
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v17,
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v16);
    boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>(
      (boost::asio::detail::strand_service *)impl[0],
      &impl[1],
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v17);
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v17);
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v16);
    _mm_sfence();
  }
  if ( &context.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)context.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))context.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(context.__bound_args_.__base_.__value_.__f_);
  }
  else if ( context.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))context.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = context.__bound_args_.__base_.__value_.__cntrl_;
  if ( context.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)context.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
    if ( (v9 & 1) == 0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  if ( (v9 & 1) != 0 )
LABEL_15:
    operator delete(ptr);
LABEL_16:
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v7);
}


// Address: 0x262de70 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(
        boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > >::ptr *this)
{
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *p; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *v3; // rdi
  volatile signed __int64 *v4; // r15
  void *v; // rdi

  p = this->p;
  if ( !p )
    goto LABEL_11;
  v3 = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *)*((_QWORD *)p + 30);
  if ( (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *)((char *)p + 208) == v3 )
  {
    (*(void (__fastcall **)(boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *))(*(_QWORD *)v3 + 32LL))(v3);
  }
  else if ( v3 )
  {
    (*(void (__fastcall **)(boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *))(*(_QWORD *)v3 + 40LL))(v3);
  }
  v4 = (volatile signed __int64 *)*((_QWORD *)p + 25);
  if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
    if ( (*((_BYTE *)p + 112) & 1) == 0 )
      goto LABEL_10;
    goto LABEL_9;
  }
  if ( (*((_BYTE *)p + 112) & 1) != 0 )
LABEL_9:
    operator delete(*((void **)p + 16));
LABEL_10:
  this->p = 0;
LABEL_11:
  v = this->v;
  if ( v )
  {
    operator delete(v);
    this->v = 0;
  }
}


// Address: 0x2632a80 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJNSH_10shared_ptrISN_EERST_RKNSH_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESX_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::operation *v6; // rbx
  boost::asio::detail::operation *next; // rdi
  boost::asio::detail::operation *v9; // rdi
  volatile signed __int64 *func; // r12
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> v12; // [rsp+0h] [rbp-E8h] BYREF
  unsigned __int64 v13; // [rsp+C0h] [rbp-28h]

  v6 = base;
  v13 = __readfsqword(0x28u);
  *(boost::asio::detail::operation *)&v12.handler_.next_layer_ = base[4];
  v12.handler_.want_ = (boost::asio::ssl::detail::engine::want)base[5].next_;
  v12.handler_.ec_ = *(boost::system::error_code *)&base[5].func_;
  v12.handler_.bytes_transferred_ = (size_t)base[6].next_;
  v12.handler_.handler_.dispatcher_ = *(boost::asio::io_service::strand *)&base[6].task_result_;
  *(_OWORD *)&v12.handler_.handler_.handler_.__f_ = *(_OWORD *)&base[7].func_;
  v12.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)&base[8].next_;
  *(_OWORD *)&base[8].next_ = 0;
  next = base[10].next_;
  if ( next )
  {
    if ( &base[8].task_result_ == (unsigned int *)next )
    {
      v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v12.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      base = (boost::asio::detail::operation *)&v12.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, _QWORD, const boost::system::error_category *, size_t))next->next_[1].next_)(
        next,
        &v12.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4,
        v4,
        v5,
        v12.handler_.next_layer_,
        v12.handler_.core_,
        *(_QWORD *)&v12.handler_.op_.type_,
        v12.handler_.want_,
        *(_QWORD *)&v12.handler_.ec_.m_val,
        v12.handler_.ec_.m_cat,
        v12.handler_.bytes_transferred_);
    }
    else
    {
      v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[10].next_;
      base[10].next_ = 0;
    }
  }
  else
  {
    v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v12.arg1_ = *(boost::system::error_code *)&v6[1].next_;
  v12.arg2_ = *(_QWORD *)&v6[1].task_result_;
  v9 = v6[10].next_;
  if ( &v6[8].task_result_ == (unsigned int *)v9 )
  {
    v9->next_[1].func_((boost::asio::detail::task_io_service *)v9, base, a3, a4);
  }
  else if ( v9 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&v9->next_[1].task_result_)(
      v9,
      base,
      a3,
      a4);
  }
  func = (volatile signed __int64 *)v6[8].func_;
  if ( func && !_InterlockedExchangeAdd64(func + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*func + 16))(
      func,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)func);
  }
  operator delete(v6);
  if ( owner )
  {
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      &v12,
      &v12.handler_.handler_);
    _mm_sfence();
  }
  if ( &v12.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v12.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26375c0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSE_8functionIFvRKNSE_10error_codeEEEERKNS_6system10error_codeEEJNSE_10shared_ptrISK_EERSQ_RKNSE_12placeholders4__phILi1EEEEEEEEEC2EihRKS3_iRS16_
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::reactive_socket_recv_op(
        boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *this,
        boost::asio::detail::socket_type socket,
        boost::asio::detail::socket_ops::state_type state,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  std::function<void (const std::error_code &)>::__base *f; // rax

  this->next_ = 0;
  this->func_ = boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete;
  this->task_result_ = 0;
  this->ec_.m_val = 0;
  this->ec_.m_cat = boost::system::system_category();
  this->bytes_transferred_ = 0;
  this->perform_func_ = boost::asio::detail::reactive_socket_recv_op_base<boost::asio::mutable_buffers_1>::do_perform;
  this->socket_ = socket;
  this->state_ = state;
  this->buffers_ = *buffers;
  this->flags_ = flags;
  this->handler_.next_layer_ = handler->next_layer_;
  this->handler_.core_ = handler->core_;
  this->handler_.op_.type_ = handler->op_.type_;
  this->handler_.start_ = handler->start_;
  this->handler_.want_ = handler->want_;
  this->handler_.ec_ = handler->ec_;
  this->handler_.bytes_transferred_ = handler->bytes_transferred_;
  *(_OWORD *)&this->handler_.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  this->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(handler->handler_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
}


// Address: 0x26376f0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSE_8functionIFvRKNSE_10error_codeEEEERKNS_6system10error_codeEEJNSE_10shared_ptrISK_EERSQ_RKNSE_12placeholders4__phILi1EEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESU_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *func; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::ptr v7; // [rsp+8h] [rbp-F0h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v8; // [rsp+20h] [rbp-D8h] BYREF
  __int128 ec; // [rsp+B0h] [rbp-48h]
  size_t bytes_transferred; // [rsp+C0h] [rbp-38h]
  unsigned __int64 v11; // [rsp+D8h] [rbp-20h]
  boost::system::error_code v12; // 0:esi.4,8:rdx.8

  v11 = __readfsqword(0x28u);
  v7.h = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[4];
  v7.v = base;
  v7.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)base;
  *(boost::asio::detail::operation *)&v8.next_layer_ = base[4];
  v8.want_ = (boost::asio::ssl::detail::engine::want)base[5].next_;
  v8.ec_ = *(boost::system::error_code *)&base[5].func_;
  v8.bytes_transferred_ = (size_t)base[6].next_;
  *(_OWORD *)&v8.handler_.__f_ = *(_OWORD *)&base[6].task_result_;
  v8.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)&base[7].func_;
  *(_OWORD *)&base[7].func_ = 0;
  func = (boost::asio::detail::operation *)base[9].func_;
  if ( func )
  {
    if ( &base[8] == func )
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))func->next_[1].next_)(
        func,
        &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[9].func_;
      base[9].func_ = 0;
    }
  }
  else
  {
    v8.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  ec = *(_OWORD *)&base[1].next_;
  bytes_transferred = *(_QWORD *)&base[1].task_result_;
  v7.h = &v8;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::ptr::reset(&v7);
  if ( owner )
  {
    v12.m_val = ec;
    v12.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::operator()(
      &v8,
      v12,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  if ( &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::ptr::reset(&v7);
}


// Address: 0x2637930 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSE_8functionIFvRKNSE_10error_codeEEEERKNS_6system10error_codeEEJNSE_10shared_ptrISK_EERSQ_RKNSE_12placeholders4__phILi1EEEEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::ptr::reset(
        boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::ptr *this)
{
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *p; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[240];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x265e0e0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_7read_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEES3_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESL_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::operation *v6; // rbx
  boost::asio::detail::operation *next; // rdi
  boost::asio::detail::operation *v9; // rdi
  boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > v10; // [rsp+0h] [rbp-B8h] BYREF
  boost::system::error_code ec; // [rsp+70h] [rbp-48h] BYREF
  size_t bytes_transferred; // [rsp+80h] [rbp-38h]
  unsigned __int64 v13; // [rsp+98h] [rbp-20h]

  v6 = base;
  v13 = __readfsqword(0x28u);
  *(_OWORD *)&v10.completion_condition_.minimum_ = *(_OWORD *)&base[4].next_;
  v10.buffer_ = *(boost::asio::mutable_buffer *)&base[4].task_result_;
  v10.start_ = (int)base[5].func_;
  *(_OWORD *)&v10.total_transferred_ = *(_OWORD *)&base[5].task_result_;
  next = base[8].next_;
  if ( next )
  {
    if ( &base[6].task_result_ == (unsigned int *)next )
    {
      v10.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v10.handler_.handler_;
      base = (boost::asio::detail::operation *)&v10.handler_.handler_;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::function<void (const boost::system::error_code &,unsigned long)> *, const boost::system::error_code *, size_t, __int64, __int64, size_t, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, void *, size_t, int, size_t))next->next_[1].next_)(
        next,
        &v10.handler_.handler_,
        a3,
        a4,
        v4,
        v5,
        v10.completion_condition_.minimum_,
        v10.stream_,
        v10.buffer_.data_,
        v10.buffer_.size_,
        v10.start_,
        v10.total_transferred_);
    }
    else
    {
      v10.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)base[8].next_;
      base[8].next_ = 0;
    }
  }
  else
  {
    v10.handler_.handler_.__f_ = 0;
  }
  ec = *(boost::system::error_code *)&v6[1].next_;
  bytes_transferred = *(_QWORD *)&v6[1].task_result_;
  v9 = v6[8].next_;
  if ( &v6[6].task_result_ == (unsigned int *)v9 )
  {
    v9->next_[1].func_((boost::asio::detail::task_io_service *)v9, base, a3, a4);
  }
  else if ( v9 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&v9->next_[1].task_result_)(
      v9,
      base,
      a3,
      a4);
  }
  if ( (boost::asio::detail::operation *)v10.handler_.allocator_ == v6 )
  {
    v10.handler_.allocator_->in_use_ = 0;
    if ( !owner )
      goto LABEL_15;
    goto LABEL_14;
  }
  operator delete(v6);
  if ( owner )
  {
LABEL_14:
    boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>::operator()(
      &v10,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
LABEL_15:
  if ( &v10.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v10.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v10.handler_.handler_.__f_->_vptr$__base
     + 4))(v10.handler_.handler_.__f_);
  }
  else if ( v10.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v10.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x266eeb0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > >::ptr v7; // [rsp+8h] [rbp-330h] BYREF
  __int128 v8; // [rsp+20h] [rbp-318h] BYREF
  __int128 v9; // [rsp+30h] [rbp-308h]
  void *ptr; // [rsp+40h] [rbp-2F8h]
  unsigned int task_result; // [rsp+48h] [rbp-2F0h]
  boost::asio::detail::task_io_service_operation *next; // [rsp+50h] [rbp-2E8h]
  boost::asio::detail::strand_service::implementation_type impl[2]; // [rsp+60h] [rbp-2D8h] BYREF
  std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> context; // [rsp+70h] [rbp-2C8h] BYREF
  boost::asio::detail::operation v15; // [rsp+C0h] [rbp-278h]
  _BYTE v16[272]; // [rsp+E0h] [rbp-258h] BYREF
  _BYTE v17[296]; // [rsp+1F0h] [rbp-148h] BYREF
  unsigned __int64 v18; // [rsp+318h] [rbp-20h]

  v18 = __readfsqword(0x28u);
  v7.h = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)&base[4];
  v7.v = base;
  v7.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *)base;
  v8 = *(_OWORD *)&base[4].next_;
  ptr = base[5].func_;
  v9 = *(_OWORD *)&base[4].task_result_;
  *(_OWORD *)&base[4].task_result_ = 0;
  base[5].func_ = 0;
  task_result = base[5].task_result_;
  next = base[6].next_;
  *(_OWORD *)impl = *(_OWORD *)&base[6].task_result_;
  *(_OWORD *)&context.__f_ = *(_OWORD *)&base[7].func_;
  context.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)&base[8].next_;
  *(_OWORD *)&base[8].next_ = 0;
  v5 = base[10].next_;
  if ( v5 )
  {
    if ( &base[8].task_result_ == (unsigned int *)v5 )
    {
      context.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&context.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))v5->next_[1].next_)(
        v5,
        &context.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      context.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[10].next_;
      base[10].next_ = 0;
    }
  }
  else
  {
    context.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v15 = base[1];
  v7.h = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)&v8;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v7);
  if ( owner )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v16,
      (boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)&v8,
      &context);
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v17,
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v16);
    boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>(
      (boost::asio::detail::strand_service *)impl[0],
      &impl[1],
      (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v17);
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v17);
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v16);
    _mm_sfence();
  }
  if ( &context.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)context.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))context.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(context.__bound_args_.__base_.__value_.__f_);
  }
  else if ( context.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))context.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = context.__bound_args_.__base_.__value_.__cntrl_;
  if ( context.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)context.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
    if ( (v9 & 1) == 0 )
      goto LABEL_16;
    goto LABEL_15;
  }
  if ( (v9 & 1) != 0 )
LABEL_15:
    operator delete(ptr);
LABEL_16:
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v7);
}


// Address: 0x266f1a0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(
        boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > >::ptr *this)
{
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *p; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *v3; // rdi
  volatile signed __int64 *v4; // r15
  void *v; // rdi

  p = this->p;
  if ( !p )
    goto LABEL_11;
  v3 = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *)*((_QWORD *)p + 30);
  if ( (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *)((char *)p + 208) == v3 )
  {
    (*(void (__fastcall **)(boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *))(*(_QWORD *)v3 + 32LL))(v3);
  }
  else if ( v3 )
  {
    (*(void (__fastcall **)(boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > > *))(*(_QWORD *)v3 + 40LL))(v3);
  }
  v4 = (volatile signed __int64 *)*((_QWORD *)p + 25);
  if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
    if ( (*((_BYTE *)p + 112) & 1) == 0 )
      goto LABEL_10;
    goto LABEL_9;
  }
  if ( (*((_BYTE *)p + 112) & 1) != 0 )
LABEL_9:
    operator delete(*((void **)p + 16));
LABEL_10:
  this->p = 0;
LABEL_11:
  v = this->v;
  if ( v )
  {
    operator delete(v);
    this->v = 0;
  }
}


// Address: 0x26a2de0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_8write_opINS0_15const_buffers_1EEENS1_8write_opINS4_6streamIRSC_EESE_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES12_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> v12; // [rsp+0h] [rbp-C8h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > v13; // [rsp+10h] [rbp-B8h] BYREF
  __m128i ec; // [rsp+A0h] [rbp-28h]
  size_t v15; // [rsp+B0h] [rbp-18h]
  boost::system::error_code v16; // 0:kr00_16.16

  *(_OWORD *)&v13.next_layer_ = *(_OWORD *)&base[3].task_result_;
  v13.op_ = *(boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)&base[4].func_;
  *(boost::asio::detail::operation *)&v13.start_ = base[5];
  *(_OWORD *)&v13.bytes_transferred_ = *(_OWORD *)&base[6].next_;
  v13.handler_.buffer_ = *(boost::asio::const_buffer *)&base[6].task_result_;
  v13.handler_.start_ = (int)base[7].func_;
  *(_OWORD *)&v13.handler_.total_transferred_ = *(_OWORD *)&base[7].task_result_;
  v13.handler_.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> *)&base[8].func_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[9]);
  v13.handler_.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[9].next_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v15 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v12 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v12);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[9].task_result_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v16.m_val = ec.m128i_i32[0];
    v16.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::operator()(
      &v13,
      v16,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v13.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v13.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, const void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, const void *, size_t, int, size_t, boost::asio::basic_streambuf<std::allocator<char> > *, boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.a1_.t_.__ptr_,
      v12.a1_.t_.__cntrl_,
      v13.next_layer_,
      v13.core_,
      v13.op_.buffers_.data_,
      v13.op_.buffers_.size_,
      *(_QWORD *)&v13.start_,
      *(_QWORD *)&v13.ec_.m_val,
      v13.ec_.m_cat,
      v13.bytes_transferred_,
      v13.handler_.stream_,
      v13.handler_.buffer_.data_,
      v13.handler_.buffer_.size_,
      v13.handler_.start_,
      v13.handler_.total_transferred_,
      v13.handler_.handler_.streambuf_,
      v13.handler_.handler_.handler_.f_.f_,
      *((_QWORD *)&v13.handler_.handler_.handler_.f_.f_ + 1),
      v13.handler_.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26a5b00 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_7read_opIS3_EENS1_26read_until_delim_string_opINS4_6streamIRSC_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__shared_weak_count *v4; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::ptr v5; // [rsp+8h] [rbp-E0h] BYREF
  _OWORD v6[2]; // [rsp+20h] [rbp-C8h] BYREF
  boost::asio::detail::operation v7; // [rsp+40h] [rbp-A8h]
  boost::asio::detail::operation v8; // [rsp+58h] [rbp-90h]
  __int128 v9; // [rsp+70h] [rbp-78h]
  void *ptr; // [rsp+80h] [rbp-68h]
  int next; // [rsp+88h] [rbp-60h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+90h] [rbp-58h]
  __int128 v13; // [rsp+98h] [rbp-50h]
  std::__shared_weak_count *v14[2]; // [rsp+A8h] [rbp-40h]
  __int128 ec; // [rsp+B8h] [rbp-30h]
  size_t bytes_transferred; // [rsp+C8h] [rbp-20h]
  boost::system::error_code v17; // 0:esi.4,8:rdx.8

  v5.v = base;
  v5.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *)base;
  v6[0] = *(_OWORD *)&base[3].task_result_;
  v6[1] = *(_OWORD *)&base[4].func_;
  v7 = base[5];
  v8 = base[6];
  ptr = *(void **)&base[7].task_result_;
  v9 = *(_OWORD *)&base[7].next_;
  *(_OWORD *)&base[7].next_ = 0;
  *(_QWORD *)&base[7].task_result_ = 0;
  next = (int)base[8].next_;
  func = base[8].func_;
  v13 = *(_OWORD *)&base[8].task_result_;
  *(_OWORD *)v14 = *(_OWORD *)&base[9].func_;
  *(_OWORD *)&base[9].func_ = 0;
  ec = *(_OWORD *)&base[1].next_;
  bytes_transferred = *(_QWORD *)&base[1].task_result_;
  v5.h = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)v6;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v5);
  if ( owner )
  {
    v17.m_val = ec;
    v17.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)v6,
      v17,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  v4 = v14[1];
  if ( v14[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
    if ( (v9 & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
  if ( (v9 & 1) != 0 )
LABEL_6:
    operator delete(ptr);
LABEL_7:
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v5);
}


// Address: 0x26a5d00 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_7read_opIS3_EENS1_26read_until_delim_string_opINS4_6streamIRSC_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(
        boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::ptr *this)
{
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *p; // rbx
  volatile signed __int64 *v3; // r15
  _BYTE *v; // rdi
  unsigned __int64 v5; // rax
  _QWORD *v6; // rax

  p = this->p;
  if ( p )
  {
    v3 = (volatile signed __int64 *)*((_QWORD *)p + 29);
    if ( v3 && !_InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(v3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
      if ( (*((_BYTE *)p + 168) & 1) == 0 )
        goto LABEL_6;
    }
    else if ( (*((_BYTE *)p + 168) & 1) == 0 )
    {
LABEL_6:
      this->p = 0;
      goto LABEL_7;
    }
    operator delete(*((void **)p + 23));
    goto LABEL_6;
  }
LABEL_7:
  v = this->v;
  if ( v )
  {
    v5 = __readfsqword(0xFFFFFFD8);
    if ( v5 && (v6 = *(_QWORD **)(v5 + 8)) != 0 && !*v6 )
    {
      *v = v[240];
      *v6 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26a7150 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSE_5list2INSE_5valueINSB_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESR_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__shared_weak_count *v4; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > >::ptr v5; // [rsp+8h] [rbp-A0h] BYREF
  __int128 v6; // [rsp+20h] [rbp-88h] BYREF
  __int128 v7; // [rsp+30h] [rbp-78h]
  void *ptr; // [rsp+40h] [rbp-68h]
  int func; // [rsp+48h] [rbp-60h]
  __int64 v10; // [rsp+50h] [rbp-58h]
  __int128 v11; // [rsp+58h] [rbp-50h]
  std::__shared_weak_count *v12[2]; // [rsp+68h] [rbp-40h]
  boost::system::error_code ec; // [rsp+78h] [rbp-30h] BYREF
  size_t bytes_transferred; // [rsp+88h] [rbp-20h]

  v5.v = base;
  v5.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)base;
  v6 = *(_OWORD *)&base[3].task_result_;
  ptr = base[5].next_;
  v7 = *(_OWORD *)&base[4].func_;
  *(_OWORD *)&base[4].func_ = 0;
  base[5].next_ = 0;
  func = (int)base[5].func_;
  v10 = *(_QWORD *)&base[5].task_result_;
  v11 = *(_OWORD *)&base[6].next_;
  *(_OWORD *)v12 = *(_OWORD *)&base[6].task_result_;
  *(_OWORD *)&base[6].task_result_ = 0;
  ec = *(boost::system::error_code *)&base[1].next_;
  bytes_transferred = *(_QWORD *)&base[1].task_result_;
  v5.h = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *)&v6;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::ptr::reset(&v5);
  if ( owner )
  {
    boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>::operator()(
      (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *)&v6,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  v4 = v12[1];
  if ( v12[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v12[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
    if ( (v7 & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
  if ( (v7 & 1) != 0 )
LABEL_6:
    operator delete(ptr);
LABEL_7:
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::ptr::reset(&v5);
}


// Address: 0x26a72e0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSE_5list2INSE_5valueINSB_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::ptr::reset(
        boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > >::ptr *this)
{
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *p; // rbx
  volatile signed __int64 *v3; // r15
  _BYTE *v; // rdi
  unsigned __int64 v5; // rax
  _QWORD *v6; // rax

  p = this->p;
  if ( p )
  {
    v3 = (volatile signed __int64 *)*((_QWORD *)p + 21);
    if ( v3 && !_InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(v3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
      if ( (*((_BYTE *)p + 104) & 1) == 0 )
        goto LABEL_6;
    }
    else if ( (*((_BYTE *)p + 104) & 1) == 0 )
    {
LABEL_6:
      this->p = 0;
      goto LABEL_7;
    }
    operator delete(*((void **)p + 15));
    goto LABEL_6;
  }
LABEL_7:
  v = this->v;
  if ( v )
  {
    v5 = __readfsqword(0xFFFFFFD8);
    if ( v5 && (v6 = *(_QWORD **)(v5 + 8)) != 0 && !*v6 )
    {
      *v = v[176];
      *v6 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26a9010 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSE_5list2INSE_5valueINSt3__110shared_ptrISM_EEEEPFNS_3argILi1EEEvEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESQ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v12; // [rsp+0h] [rbp-98h] BYREF
  __m128i ec; // [rsp+58h] [rbp-40h]
  size_t v14; // [rsp+68h] [rbp-30h]
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v15; // [rsp+70h] [rbp-28h] BYREF
  boost::system::error_code v16; // 0:kr00_16.16

  *(_OWORD *)&v12.next_layer_ = *(_OWORD *)&base[3].task_result_;
  *(_QWORD *)&v12.op_.type_ = base[4].func_;
  v12.want_ = base[4].task_result_;
  *(boost::asio::detail::operation *)&v12.ec_.m_val = base[5];
  v12.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[6].next_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[6].task_result_);
  v12.handler_.l_ = si128;
  *(_OWORD *)&base[6].task_result_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v14 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v15 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v15);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[7].func_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v16.m_val = ec.m128i_i32[0];
    v16.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
      &v12,
      v16,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v12.handler_.l_.a1_.t_.__cntrl_;
    if ( !v12.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, _QWORD, const boost::system::error_category *, size_t, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.next_layer_,
      v12.core_,
      *(_QWORD *)&v12.op_.type_,
      v12.want_,
      *(_QWORD *)&v12.ec_.m_val,
      v12.ec_.m_cat,
      v12.bytes_transferred_,
      v12.handler_.f_.f_,
      *((_QWORD *)&v12.handler_.f_.f_ + 1),
      v12.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26aa830 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_8write_opINS0_15const_buffers_1EEENS1_8write_opINS4_6streamIRSC_EESE_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v12; // [rsp+0h] [rbp-C8h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > v13; // [rsp+10h] [rbp-B8h] BYREF
  __m128i ec; // [rsp+A0h] [rbp-28h]
  size_t v15; // [rsp+B0h] [rbp-18h]
  boost::system::error_code v16; // 0:kr00_16.16

  *(_OWORD *)&v13.next_layer_ = *(_OWORD *)&base[3].task_result_;
  v13.op_ = *(boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)&base[4].func_;
  *(boost::asio::detail::operation *)&v13.start_ = base[5];
  *(_OWORD *)&v13.bytes_transferred_ = *(_OWORD *)&base[6].next_;
  v13.handler_.buffer_ = *(boost::asio::const_buffer *)&base[6].task_result_;
  v13.handler_.start_ = (int)base[7].func_;
  *(_OWORD *)&v13.handler_.total_transferred_ = *(_OWORD *)&base[7].task_result_;
  v13.handler_.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[8].func_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[9]);
  v13.handler_.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[9].next_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v15 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v12 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v12);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[9].task_result_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v16.m_val = ec.m128i_i32[0];
    v16.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::operator()(
      &v13,
      v16,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v13.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v13.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, const void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, const void *, size_t, int, size_t, boost::asio::basic_streambuf<std::allocator<char> > *, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.a1_.t_.__ptr_,
      v12.a1_.t_.__cntrl_,
      v13.next_layer_,
      v13.core_,
      v13.op_.buffers_.data_,
      v13.op_.buffers_.size_,
      *(_QWORD *)&v13.start_,
      *(_QWORD *)&v13.ec_.m_val,
      v13.ec_.m_cat,
      v13.bytes_transferred_,
      v13.handler_.stream_,
      v13.handler_.buffer_.data_,
      v13.handler_.buffer_.size_,
      v13.handler_.start_,
      v13.handler_.total_transferred_,
      v13.handler_.handler_.streambuf_,
      v13.handler_.handler_.handler_.f_.f_,
      *((_QWORD *)&v13.handler_.handler_.handler_.f_.f_ + 1),
      v13.handler_.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26adf80 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_7read_opIS3_EENS1_26read_until_delim_string_opINS4_6streamIRSC_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESY_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__shared_weak_count *v4; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::ptr v5; // [rsp+8h] [rbp-E0h] BYREF
  _OWORD v6[2]; // [rsp+20h] [rbp-C8h] BYREF
  boost::asio::detail::operation v7; // [rsp+40h] [rbp-A8h]
  boost::asio::detail::operation v8; // [rsp+58h] [rbp-90h]
  __int128 v9; // [rsp+70h] [rbp-78h]
  void *ptr; // [rsp+80h] [rbp-68h]
  int next; // [rsp+88h] [rbp-60h]
  boost::asio::detail::task_io_service_operation::func_type func; // [rsp+90h] [rbp-58h]
  __int128 v13; // [rsp+98h] [rbp-50h]
  std::__shared_weak_count *v14[2]; // [rsp+A8h] [rbp-40h]
  __int128 ec; // [rsp+B8h] [rbp-30h]
  size_t bytes_transferred; // [rsp+C8h] [rbp-20h]
  boost::system::error_code v17; // 0:esi.4,8:rdx.8

  v5.v = base;
  v5.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *)base;
  v6[0] = *(_OWORD *)&base[3].task_result_;
  v6[1] = *(_OWORD *)&base[4].func_;
  v7 = base[5];
  v8 = base[6];
  ptr = *(void **)&base[7].task_result_;
  v9 = *(_OWORD *)&base[7].next_;
  *(_OWORD *)&base[7].next_ = 0;
  *(_QWORD *)&base[7].task_result_ = 0;
  next = (int)base[8].next_;
  func = base[8].func_;
  v13 = *(_OWORD *)&base[8].task_result_;
  *(_OWORD *)v14 = *(_OWORD *)&base[9].func_;
  *(_OWORD *)&base[9].func_ = 0;
  ec = *(_OWORD *)&base[1].next_;
  bytes_transferred = *(_QWORD *)&base[1].task_result_;
  v5.h = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)v6;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v5);
  if ( owner )
  {
    v17.m_val = ec;
    v17.m_cat = (const boost::system::error_category *)*((_QWORD *)&ec + 1);
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
      (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)v6,
      v17,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  v4 = v14[1];
  if ( v14[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v14[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
    if ( (v9 & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
  if ( (v9 & 1) != 0 )
LABEL_6:
    operator delete(ptr);
LABEL_7:
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v5);
}


// Address: 0x26ae180 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_7read_opIS3_EENS1_26read_until_delim_string_opINS4_6streamIRSC_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(
        boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::ptr *this)
{
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *p; // rbx
  volatile signed __int64 *v3; // r15
  _BYTE *v; // rdi
  unsigned __int64 v5; // rax
  _QWORD *v6; // rax

  p = this->p;
  if ( p )
  {
    v3 = (volatile signed __int64 *)*((_QWORD *)p + 29);
    if ( v3 && !_InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(v3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
      if ( (*((_BYTE *)p + 168) & 1) == 0 )
        goto LABEL_6;
    }
    else if ( (*((_BYTE *)p + 168) & 1) == 0 )
    {
LABEL_6:
      this->p = 0;
      goto LABEL_7;
    }
    operator delete(*((void **)p + 23));
    goto LABEL_6;
  }
LABEL_7:
  v = this->v;
  if ( v )
  {
    v5 = __readfsqword(0xFFFFFFD8);
    if ( v5 && (v6 = *(_QWORD **)(v5 + 8)) != 0 && !*v6 )
    {
      *v = v[240];
      *v6 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26af5d0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSE_5list2INSE_5valueINSB_10shared_ptrISM_EEEEPFNS_3argILi1EEEvEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESQ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__shared_weak_count *v4; // rbx
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::ptr v5; // [rsp+8h] [rbp-A0h] BYREF
  __int128 v6; // [rsp+20h] [rbp-88h] BYREF
  __int128 v7; // [rsp+30h] [rbp-78h]
  void *ptr; // [rsp+40h] [rbp-68h]
  int func; // [rsp+48h] [rbp-60h]
  __int64 v10; // [rsp+50h] [rbp-58h]
  __int128 v11; // [rsp+58h] [rbp-50h]
  std::__shared_weak_count *v12[2]; // [rsp+68h] [rbp-40h]
  boost::system::error_code ec; // [rsp+78h] [rbp-30h] BYREF
  size_t bytes_transferred; // [rsp+88h] [rbp-20h]

  v5.v = base;
  v5.p = (boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)base;
  v6 = *(_OWORD *)&base[3].task_result_;
  ptr = base[5].next_;
  v7 = *(_OWORD *)&base[4].func_;
  *(_OWORD *)&base[4].func_ = 0;
  base[5].next_ = 0;
  func = (int)base[5].func_;
  v10 = *(_QWORD *)&base[5].task_result_;
  v11 = *(_OWORD *)&base[6].next_;
  *(_OWORD *)v12 = *(_OWORD *)&base[6].task_result_;
  *(_OWORD *)&base[6].task_result_ = 0;
  ec = *(boost::system::error_code *)&base[1].next_;
  bytes_transferred = *(_QWORD *)&base[1].task_result_;
  v5.h = (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *)&v6;
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::ptr::reset(&v5);
  if ( owner )
  {
    boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
      (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *)&v6,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  v4 = v12[1];
  if ( v12[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v12[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
    if ( (v7 & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
  if ( (v7 & 1) != 0 )
LABEL_6:
    operator delete(ptr);
LABEL_7:
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::ptr::reset(&v5);
}


// Address: 0x26af760 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSE_5list2INSE_5valueINSB_10shared_ptrISM_EEEEPFNS_3argILi1EEEvEEEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::ptr::reset(
        boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::ptr *this)
{
  boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *p; // rbx
  volatile signed __int64 *v3; // r15
  _BYTE *v; // rdi
  unsigned __int64 v5; // rax
  _QWORD *v6; // rax

  p = this->p;
  if ( p )
  {
    v3 = (volatile signed __int64 *)*((_QWORD *)p + 21);
    if ( v3 && !_InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(v3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
      if ( (*((_BYTE *)p + 104) & 1) == 0 )
        goto LABEL_6;
    }
    else if ( (*((_BYTE *)p + 104) & 1) == 0 )
    {
LABEL_6:
      this->p = 0;
      goto LABEL_7;
    }
    operator delete(*((void **)p + 15));
    goto LABEL_6;
  }
LABEL_7:
  v = this->v;
  if ( v )
  {
    v5 = __readfsqword(0xFFFFFFD8);
    if ( v5 && (v6 = *(_QWORD **)(v5 + 8)) != 0 && !*v6 )
    {
      *v = v[176];
      *v6 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26b28b0 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_7read_opIS3_EENS1_17read_streambuf_opINS4_6streamIRSC_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v12; // [rsp+0h] [rbp-C8h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v13; // [rsp+10h] [rbp-B8h] BYREF
  __m128i ec; // [rsp+98h] [rbp-30h]
  size_t v15; // [rsp+A8h] [rbp-20h]
  boost::system::error_code v16; // 0:kr00_16.16

  *(_OWORD *)&v13.next_layer_ = *(_OWORD *)&base[3].task_result_;
  v13.op_ = *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&base[4].func_;
  *(boost::asio::detail::operation *)&v13.start_ = base[5];
  *(_OWORD *)&v13.bytes_transferred_ = *(_OWORD *)&base[6].next_;
  *(_OWORD *)&v13.handler_.stream_ = *(_OWORD *)&base[6].task_result_;
  v13.handler_.start_ = (int)base[7].func_;
  v13.handler_.total_transferred_ = *(_QWORD *)&base[7].task_result_;
  v13.handler_.handler_.f_ = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)&base[8].next_;
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[8].task_result_);
  v13.handler_.handler_.l_ = si128;
  *(_OWORD *)&base[8].task_result_ = 0;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v15 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v12 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v12);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[9].func_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v16.m_val = ec.m128i_i32[0];
    v16.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
      &v13,
      v16,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v13.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v13.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, boost::asio::basic_streambuf<std::allocator<char> > *, int, size_t, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.a1_.t_.__ptr_,
      v12.a1_.t_.__cntrl_,
      v13.next_layer_,
      v13.core_,
      v13.op_.buffers_.data_,
      v13.op_.buffers_.size_,
      *(_QWORD *)&v13.start_,
      *(_QWORD *)&v13.ec_.m_val,
      v13.ec_.m_cat,
      v13.bytes_transferred_,
      v13.handler_.completion_condition_.size_,
      v13.handler_.stream_,
      v13.handler_.streambuf_,
      v13.handler_.start_,
      v13.handler_.total_transferred_,
      v13.handler_.handler_.f_.f_,
      *((_QWORD *)&v13.handler_.handler_.f_.f_ + 1),
      v13.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26b3840 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_17read_streambuf_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSB_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESR_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  boost::system::error_code v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v12; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v13; // [rsp+10h] [rbp-78h] BYREF
  boost::system::error_code ec; // [rsp+58h] [rbp-30h] BYREF
  size_t v15; // [rsp+68h] [rbp-20h]

  *(_OWORD *)&v13.completion_condition_.size_ = *(_OWORD *)&base[3].task_result_;
  v13.streambuf_ = (boost::asio::basic_streambuf<std::allocator<char> > *)base[4].func_;
  v13.start_ = base[4].task_result_;
  *(boost::asio::detail::operation *)&v13.total_transferred_ = base[5];
  si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[6]);
  v13.handler_.l_ = si128;
  *(_OWORD *)&base[6].next_ = 0;
  v7 = (boost::system::error_code)_mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v15 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v12 = si128;
    operator delete(base);
    si128 = (boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v12);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[6].task_result_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)&ec;
    boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
      &v13,
      &ec,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v13.handler_.l_.a1_.t_.__cntrl_;
    if ( !v13.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  *(_QWORD *)&v7.m_val = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = *(volatile signed __int64 **)&v7.m_val;
  if ( !*(_QWORD *)&v7.m_val )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, size_t, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::basic_streambuf<std::allocator<char> > *, int, size_t, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)&v7.m_val,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.a1_.t_.__ptr_,
      v12.a1_.t_.__cntrl_,
      v13.completion_condition_.size_,
      v13.stream_,
      v13.streambuf_,
      v13.start_,
      v13.total_transferred_,
      v13.handler_.f_.f_,
      *((_QWORD *)&v13.handler_.f_.f_ + 1),
      v13.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26b6330 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_7read_opIS3_EENS1_17read_streambuf_opINS4_6streamIRSC_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSN_5list3INSN_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvENS12_IiEEEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESZ_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  __m128i v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v12; // [rsp+0h] [rbp-C8h] BYREF
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > v13; // [rsp+10h] [rbp-B8h] BYREF
  __m128i ec; // [rsp+A0h] [rbp-28h]
  size_t v15; // [rsp+B0h] [rbp-18h]
  boost::system::error_code v16; // 0:kr00_16.16

  *(_OWORD *)&v13.next_layer_ = *(_OWORD *)&base[3].task_result_;
  v13.op_ = *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&base[4].func_;
  *(boost::asio::detail::operation *)&v13.start_ = base[5];
  *(_OWORD *)&v13.bytes_transferred_ = *(_OWORD *)&base[6].next_;
  *(_OWORD *)&v13.handler_.stream_ = *(_OWORD *)&base[6].task_result_;
  v13.handler_.start_ = (int)base[7].func_;
  v13.handler_.total_transferred_ = *(_QWORD *)&base[7].task_result_;
  v13.handler_.handler_.f_ = *(boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int> *)&base[8].next_;
  si128 = (boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[8].task_result_);
  v13.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = si128;
  *(_OWORD *)&base[8].task_result_ = 0;
  v13.handler_.handler_.l_.a3_.t_ = (int)base[9].func_;
  v7 = _mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v15 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v12 = si128;
    operator delete(base);
    si128 = (boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v12);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[9].task_result_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)ec.m128i_u32[0];
    v16.m_val = ec.m128i_i32[0];
    v16.m_cat = (const boost::system::error_category *)ec.m128i_i64[1];
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>::operator()(
      &v13,
      v16,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v13.handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( !v13.handler_.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  v7.m128i_i64[0] = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = (volatile signed __int64 *)v7.m128i_i64[0];
  if ( !v7.m128i_i64[0] )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, boost::asio::basic_streambuf<std::allocator<char> > *, int, size_t, boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)v7.m128i_i64,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.a1_.t_.__ptr_,
      v12.a1_.t_.__cntrl_,
      v13.next_layer_,
      v13.core_,
      v13.op_.buffers_.data_,
      v13.op_.buffers_.size_,
      *(_QWORD *)&v13.start_,
      *(_QWORD *)&v13.ec_.m_val,
      v13.ec_.m_cat,
      v13.bytes_transferred_,
      v13.handler_.completion_condition_.size_,
      v13.handler_.stream_,
      v13.handler_.streambuf_,
      v13.handler_.start_,
      v13.handler_.total_transferred_,
      v13.handler_.handler_.f_.f_,
      *((_QWORD *)&v13.handler_.handler_.f_.f_ + 1),
      v13.handler_.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


// Address: 0x26b7330 | Name: _ZN5boost4asio6detail23reactive_socket_recv_opINS0_17mutable_buffers_1ENS1_17read_streambuf_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSF_5list3INSF_5valueINSB_10shared_ptrISN_EEEEPFNS_3argILi1EEEvENSU_IiEEEEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESR_m
void __fastcall boost::asio::detail::reactive_socket_recv_op<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r8
  __int64 v5; // r9
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> si128; // xmm1
  boost::system::error_code v7; // xmm0
  size_t v8; // rbx
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  volatile signed __int64 *cntrl; // rbx
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v12; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > v13; // [rsp+10h] [rbp-78h] BYREF
  boost::system::error_code ec; // [rsp+60h] [rbp-28h] BYREF
  size_t v15; // [rsp+70h] [rbp-18h]

  *(_OWORD *)&v13.completion_condition_.size_ = *(_OWORD *)&base[3].task_result_;
  v13.streambuf_ = (boost::asio::basic_streambuf<std::allocator<char> > *)base[4].func_;
  v13.start_ = base[4].task_result_;
  *(boost::asio::detail::operation *)&v13.total_transferred_ = base[5];
  si128 = (boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_loadu_si128((const __m128i *)&base[6]);
  v13.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = si128;
  *(_OWORD *)&base[6].next_ = 0;
  v13.handler_.l_.a3_.t_ = base[6].task_result_;
  v7 = (boost::system::error_code)_mm_loadu_si128((const __m128i *)&base[1]);
  ec = v7;
  v8 = *(_QWORD *)&base[1].task_result_;
  v15 = v8;
  if ( !base )
  {
LABEL_6:
    if ( owner )
      goto LABEL_7;
    goto LABEL_10;
  }
  v9 = __readfsqword(0xFFFFFFD8);
  if ( !v9 || (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) == 0 || *v10 )
  {
    v12 = si128;
    operator delete(base);
    si128 = (boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>)_mm_load_si128((const __m128i *)&v12);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[7].next_;
  LOBYTE(base->next_) = a4;
  *v10 = base;
  if ( owner )
  {
LABEL_7:
    base = (boost::asio::detail::operation *)&ec;
    boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>::operator()(
      &v13,
      &ec,
      v8,
      0);
    _mm_sfence();
    cntrl = (volatile signed __int64 *)v13.handler_.l_.a1_.t_.__cntrl_;
    if ( !v13.handler_.l_.a1_.t_.__cntrl_ )
      return;
    goto LABEL_11;
  }
LABEL_10:
  *(_QWORD *)&v7.m_val = _mm_shuffle_epi32((__m128i)si128, 78).m128i_u64[0];
  cntrl = *(volatile signed __int64 **)&v7.m_val;
  if ( !*(_QWORD *)&v7.m_val )
    return;
LABEL_11:
  if ( !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t, __int64, __int64, double, double, std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, size_t, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::basic_streambuf<std::allocator<char> > *, int, size_t, boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*cntrl + 16))(
      cntrl,
      base,
      a3,
      a4,
      v4,
      v5,
      *(double *)&v7.m_val,
      *(double *)&si128.a1_.t_.__ptr_,
      v12.a1_.t_.__ptr_,
      v12.a1_.t_.__cntrl_,
      v13.completion_condition_.size_,
      v13.stream_,
      v13.streambuf_,
      v13.start_,
      v13.total_transferred_,
      v13.handler_.f_.f_,
      *((_QWORD *)&v13.handler_.f_.f_ + 1),
      v13.handler_.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
}


