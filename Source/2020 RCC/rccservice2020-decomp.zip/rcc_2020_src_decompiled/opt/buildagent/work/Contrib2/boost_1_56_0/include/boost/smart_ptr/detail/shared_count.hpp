// Address: 0xdaf680 | Name: _ZN5boost6detail12shared_countC2IP18ThumbnailGeneratorN3RBX9CreatableINS5_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<ThumbnailGenerator *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        ThumbnailGenerator *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2875F88;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xdb40f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20CSGDictionaryServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CSGDictionaryService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CSGDictionaryService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2876548;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xdb45e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX33NonReplicatedCSGDictionaryServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::NonReplicatedCSGDictionaryService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::NonReplicatedCSGDictionaryService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28765A8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xdb4760 | Name: _ZN5boost6detail12shared_countC2IN11CWebService7JobItemEEEPT_
void __fastcall boost::detail::shared_count::shared_count<CWebService::JobItem>(
        boost::detail::shared_count *this,
        CWebService::JobItem *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2876608;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xdcfd80 | Name: _ZN5boost6detail12shared_countC2IN3RBX10Reflection5TupleEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Reflection::Tuple>(
        boost::detail::shared_count *this,
        RBX::Reflection::Tuple *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2879098;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xdd1940 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13ScriptContextENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ScriptContext *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2879278;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xdd22b0 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKNS2_9unordered13unordered_mapINSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEN3RBX10Reflection7VariantENS2_4hashISC_EENS6_8equal_toISC_EENSA_INS6_4pairIKSC_SF_EEEEEEEEE18moveConstruct_funcEPcSS_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0xdd3ea0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX21TaskSchedulerSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TaskSchedulerSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::TaskSchedulerSettings *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2879568;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xdd40d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12GameSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GameSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28795C8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xde5c30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12TimerServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TimerService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::TimerService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2879B10;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xde5db0 | Name: _ZN5boost6detail12shared_countC2INSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<std::string>(
        boost::detail::shared_count *this,
        std::string *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2879B68;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xe4c910 | Name: _ZN5boost6detail12shared_countC2INS0_11thread_dataIPFvvEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<boost::detail::thread_data<void (*)(void)>>(
        boost::detail::shared_count *this,
        boost::detail::thread_data<void (*)()> *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_287C7C8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xe4d300 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKNSt3__16vectorIN3RBX10Reflection7VariantENS4_9allocatorIS8_EEEEEEE18moveConstruct_funcEPcSF_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0xe4e4a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15ContentProviderENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ContentProvider *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287CAD8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xe4e990 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19MeshContentProviderENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MeshContentProvider *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::MeshContentProvider *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287CB38;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xe4ee80 | Name: _ZN5boost6detail12shared_countC2IPN3RBX25SolidModelContentProviderENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SolidModelContentProvider *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SolidModelContentProvider *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287CB98;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xe50d30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12ModuleScriptENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ModuleScript *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287CBF8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xe51220 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11HttpServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::HttpService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287CC58;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xe51710 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9SelectionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Selection *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287CCB8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xe524c0 | Name: _ZN5boost6detail12shared_countC2INS_9unordered13unordered_mapINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashISB_EENS5_8equal_toISB_EENS9_INS5_4pairIKSB_SE_EEEEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>(
        boost::detail::shared_count *this,
        boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_287CD18;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xe52900 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8LightingENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Lighting *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Lighting *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287CD78;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xe52b30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX21ColorCorrectionEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ColorCorrectionEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ColorCorrectionEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287CDD8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xe62060 | Name: _ZN5boost6detail12shared_countC2INS_15program_options19options_descriptionEEEPT_
void __fastcall boost::detail::shared_count::shared_count<boost::program_options::options_description>(
        boost::detail::shared_count *this,
        boost::program_options::options_description *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_287DB08;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xeb5f20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network6ClientENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::Client *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287F448;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xeb6160 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network6ServerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::Server *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287F4D8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xeb63a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX6PlayerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Player *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287F568;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xeb66a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network29CheatHandlingServerReplicatorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::CheatHandlingServerReplicator *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287F5C8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xeb8fd0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15NetworkSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::NetworkSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_287FA30;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xec1440 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIN3RBX8InstanceEEEE18moveConstruct_funcEPcS8_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<RBX::Instance>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0xec3280 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7PlayersENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Players *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28803C8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xec3610 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network16ClientReplicatorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::ClientReplicator *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2880428;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xec3960 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10RunServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RunService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::RunService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2880488;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xed5f10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats14TypedStatsItemIjEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::TypedStatsItem<unsigned int> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2881238;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xed6090 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network16ClientReplicator15ClientStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::ClientReplicator::ClientStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2881298;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xed6710 | Name: _ZN5boost6detail12shared_countC2IN3RBX7Network15PhysicsSenderS2EEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::PhysicsSenderS2>(
        boost::detail::shared_count *this,
        RBX::Network::PhysicsSenderS2 *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2881870;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xed6880 | Name: _ZN5boost6detail12shared_countC2IN3RBX7Network17PhysicsReceiverS2EEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::PhysicsReceiverS2>(
        boost::detail::shared_count *this,
        RBX::Network::PhysicsReceiverS2 *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28818C8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xed6f80 | Name: _ZN5boost6detail12shared_countC2INSt3__16vectorIN3RBX10Reflection7VariantENS3_9allocatorIS7_EEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<std::vector<RBX::Reflection::Variant>>(
        boost::detail::shared_count *this,
        std::vector<RBX::Reflection::Variant> *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2881988;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xefb1b0 | Name: _ZN5boost6detail12shared_countC2INS_10filesystem6detail11dir_itr_impEEEPT_
void __fastcall boost::detail::shared_count::shared_count<boost::filesystem::detail::dir_itr_imp>(
        boost::detail::shared_count *this,
        boost::filesystem::detail::dir_itr_imp *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2881CE8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xefb620 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14CookiesServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CookiesService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2881D48;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xefb850 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10GuiServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GuiService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2881DA8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xefbc20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5VisitENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Visit *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2881E08;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xf02670 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16UserInputServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UserInputService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2881EA8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xf02d30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20ChangeHistoryServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ChangeHistoryService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ChangeHistoryService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2881F08;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xf03100 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13InsertServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::InsertService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::InsertService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2881F68;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xf03a40 | Name: _ZN5boost6detail12shared_countC2IN3RBX15GamePerfMonitorEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::GamePerfMonitor>(
        boost::detail::shared_count *this,
        RBX::GamePerfMonitor *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2882028;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xf05f70 | Name: _ZN5boost6detail12shared_countC2IPN3RBX6FolderENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Folder *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Folder *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28820C8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xf06340 | Name: _ZN5boost6detail12shared_countC2IPN3RBX21CoreScriptSyncServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CoreScriptSyncService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CoreScriptSyncService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2882128;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xf06b40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12CorePackagesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CorePackages *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CorePackages *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2882188;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xf11d30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats12StatsServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::StatsService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2882348;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xf225d0 | Name: _ZN5boost6detail12shared_countC2IN3RBX7Network20PhysicsAssemblyCacheEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::PhysicsAssemblyCache>(
        boost::detail::shared_count *this,
        RBX::Network::PhysicsAssemblyCache *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2882848;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xf2a4f0 | Name: _ZN5boost6detail12shared_countC2IN3RBX7Network19StrictNetworkFilter9WhiteListEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::StrictNetworkFilter::WhiteList>(
        boost::detail::shared_count *this,
        RBX::Network::StrictNetworkFilter::WhiteList *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28828D0;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xf3bf00 | Name: _ZN5boost6detail12shared_countC2IN3RBX7Network17ConcurrentRakPeerEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::ConcurrentRakPeer>(
        boost::detail::shared_count *this,
        RBX::Network::ConcurrentRakPeer *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2883FF8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xf3ca90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network13PeerStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::PeerStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2884218;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xf87450 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network6MarkerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::Marker *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Network::Marker *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2885568;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xf8a720 | Name: _ZN5boost6detail12shared_countC2INSt3__13mapINS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEN3RBX10Reflection7VariantENS3_4lessISA_EENS8_INS3_4pairIKSA_SD_EEEEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<std::map<std::string,RBX::Reflection::Variant>>(
        boost::detail::shared_count *this,
        std::map<std::string,RBX::Reflection::Variant> *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2885678;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xf8aff0 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKN3RBX10Reflection5TupleEEEE18moveConstruct_funcEPcSA_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<RBX::Reflection::Tuple const>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0xf8b290 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKNSt3__13mapINS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEN3RBX10Reflection7VariantENS4_4lessISB_EENS9_INS4_4pairIKSB_SE_EEEEEEEEE18moveConstruct_funcEPcSP_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0xfb69e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats14TypedStatsItemImEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::TypedStatsItem<unsigned long> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2887CB8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfb6e90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats14TypedStatsItemIbEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::TypedStatsItem<bool> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2887E98;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfb7340 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats14TypedStatsItemIfEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::TypedStatsItem<float> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2888078;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfb74c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network12RakStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::RakStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28880D8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfb7970 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats14TypedStatsItemIdEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::TypedStatsItem<double> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28882B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfb7e20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats14TypedStatsItemIiEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::TypedStatsItem<int> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2888498;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfd2a90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network16ServerReplicatorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::ServerReplicator *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2888B88;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfd5d00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network18ClusterPacketCacheENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::ClusterPacketCache *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Network::ClusterPacketCache *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2889048;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xfd6430 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Security19AslrPmcSharedHasherEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Security::AslrPmcSharedHasher>(
        boost::detail::shared_count *this,
        RBX::Security::AslrPmcSharedHasher *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2889168;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0xfd6bf0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20StarterPlayerServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StarterPlayerService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28891C8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfeb2c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network16ServerReplicator15ServerStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::ServerReplicator::ServerStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288A298;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfedf40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15ReplicatedFirstENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ReplicatedFirst *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ReplicatedFirst *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288A968;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xfee290 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape12SoundServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::SoundService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288A9C8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfee5e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15TeleportServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TeleportService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AA28;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfeead0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18StarterPackServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StarterPackService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::StarterPackService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AA88;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xfeefc0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17StarterGuiServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StarterGuiService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AAE8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfef310 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13JointsServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::JointsService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AB48;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xfef800 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5TeamsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Teams *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Teams *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288ABA8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xfefcf0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11ChatServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ChatService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ChatService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AC08;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff0040 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19LocalizationServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LocalizationService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AC68;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xff0530 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13FriendServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FriendService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::FriendService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288ACC8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff0a20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18MarketplaceServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MarketplaceService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::MarketplaceService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AD28;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff0f10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12BadgeServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BadgeService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AD88;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xff1400 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17ReplicatedStorageENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ReplicatedStorage *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ReplicatedStorage *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288ADE8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff18f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX23RobloxReplicatedStorageENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RobloxReplicatedStorage *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::RobloxReplicatedStorage *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AE48;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff1de0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11TestServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TestService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AEA8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xff22d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13PointsServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PointsService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AF08;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xff27c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9AdServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::AdService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::AdService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AF68;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff2cb0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13SocialServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SocialService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SocialService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288AFC8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff31a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19ServerScriptServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ServerScriptService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ServerScriptService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288B028;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff3690 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13ServerStorageENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ServerStorage *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ServerStorage *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288B088;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff3b80 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16AnalyticsServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::AnalyticsService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288B0E8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0xff4070 | Name: _ZN5boost6detail12shared_countC2IPN3RBX21VersionControlServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::VersionControlService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::VersionControlService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288B148;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff4560 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10StudioDataENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StudioData *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::StudioData *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288B1A8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0xff4e70 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10LogServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LogService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::LogService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288B248;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1019c80 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Security13AslrPmcServerEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Security::AslrPmcServer>(
        boost::detail::shared_count *this,
        RBX::Security::AslrPmcServer *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_288BF70;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1029500 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Network19GuidRegistryServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Network::GuidRegistryService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Network::GuidRegistryService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288C928;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1036a40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14PackageServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PackageService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PackageService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288D118;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x103e2f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8AnimatorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Animator *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288D498;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1040ad0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14AnimationTrackENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::AnimationTrack *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::AnimationTrack *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288D818;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x10418a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9AnimationENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Animation *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288D8D8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1046280 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIN3RBX10Reflection13DescribedBaseEEEE18moveConstruct_funcEPcS9_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<RBX::Reflection::DescribedBase>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0x104a7d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX24KeyframeSequenceProviderENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::KeyframeSequenceProvider *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::KeyframeSequenceProvider *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288EB58;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x104b760 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19AnimationControllerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::AnimationController *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::AnimationController *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288EDD8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x104cf40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8KeyframeENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Keyframe *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Keyframe *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288F278;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1051c90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16KeyframeSequenceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::KeyframeSequence *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::KeyframeSequence *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_288F928;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x10691d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14InventoryPagesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::InventoryPages *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28906D0;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x106c750 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4PoseENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Pose *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Pose *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2890D88;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x106dcd0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14KeyframeMarkerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::KeyframeMarker *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2891458;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x10b94d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7Motor6DENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Motor6D *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Motor6D *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2893260;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x10ba9c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12NumericValueIdEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::NumericValue<double> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::NumericValue<double> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28932B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x10bac00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8HumanoidENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Humanoid *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2893348;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x10c5470 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5ValueIbEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Value<bool> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Value<bool> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2894958;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x10c6280 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17FilteredSelectionINS3_12PartInstanceEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FilteredSelection<RBX::PartInstance> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2894B68;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x10c6700 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14StatusInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StatusInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2894BC8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x10c6930 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17GameBasicSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GameBasicSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2894C28;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x10c9900 | Name: _ZN5boost6detail12shared_countC2IN3RBX6GfxGuiEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::GfxGui>(
        boost::detail::shared_count *this,
        RBX::GfxGui *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2894D68;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x10c9d80 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19HumanoidDescriptionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::HumanoidDescription *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::HumanoidDescription *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2894DC8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x10cc060 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5ValueIN3G3D7Vector3EEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Value<G3D::Vector3> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Value<G3D::Vector3> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2894F08;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x10cc8f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11StringValueENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StringValue *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2894F68;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x10fcf00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17CollectionServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CollectionService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CollectionService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2898AB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x10ff3d0 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrINSt3__16vectorIN3RBX10Reflection7VariantENS4_9allocatorIS8_EEEEEEE18moveConstruct_funcEPcSE_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::vector<RBX::Reflection::Variant>>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0x10ffb50 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrINS2_9unordered13unordered_mapINSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEN3RBX10Reflection7VariantENS2_4hashISC_EENS6_8equal_toISC_EENSA_INS6_4pairIKSC_SF_EEEEEEEEE18moveConstruct_funcEPcSR_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0x1125b70 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9Scripting14ScriptDebuggerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Scripting::ScriptDebugger *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2899FA8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1128270 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9Scripting13DebuggerWatchENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Scripting::DebuggerWatch *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_289A848;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x112abd0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9Scripting18DebuggerBreakpointENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Scripting::DebuggerBreakpoint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_289A948;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1134920 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9Scripting15DebuggerManagerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Scripting::DebuggerManager *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Scripting::DebuggerManager *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_289AF88;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x11b12e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11LocalScriptENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LocalScript *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_289F868;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x11b1520 | Name: _ZN5boost6detail12shared_countC2IPN3RBX6ScriptENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Script *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_289F8F8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x11b2060 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20RuntimeScriptServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RuntimeScriptService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::RuntimeScriptService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A0298;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x11d2410 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11LuaSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LuaSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::LuaSettings *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A09E8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x11d78e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13ModelInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ModelInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A0EC8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x11d8c20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10CoreScriptENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CoreScript *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A10B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x11d91a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13DebugSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DebugSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::DebugSettings *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A1118;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x11dca30 | Name: _ZN5boost6detail12shared_countC2IN16RobloxExtraSpace6SharedEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RobloxExtraSpace::Shared>(
        boost::detail::shared_count *this,
        RobloxExtraSpace::Shared *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28A11B8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x11e4120 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12LuaStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LuaStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A1AA8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x122a280 | Name: _ZN5boost6detail12shared_countC2IN3RBX24CacheableContentProvider10CachedItemEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::CacheableContentProvider::CachedItem>(
        boost::detail::shared_count *this,
        RBX::CacheableContentProvider::CachedItem *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28A3318;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x127f5c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9Analytics28GoogleAnalyticsConfigurationENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Analytics::GoogleAnalyticsConfiguration *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A4A08;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1280760 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9Analytics8SettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Analytics::Settings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A4DE8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1298510 | Name: _ZN3RBX12HttpResponseC2ERNS_11HttpRequestE
void __fastcall RBX::HttpResponse::HttpResponse(RBX::HttpResponse *this, RBX::HttpRequest *req)
{
  *(_OWORD *)((char *)this + 8) = 0;
  *(_QWORD *)this = off_28A5D60;
  *((_DWORD *)this + 6) = -1;
  *((_OWORD *)this + 7) = 0;
  *((_OWORD *)this + 6) = 0;
  *((_OWORD *)this + 5) = 0;
  *((_OWORD *)this + 4) = 0;
  *((_OWORD *)this + 3) = 0;
  *((_OWORD *)this + 2) = 0;
  *((_DWORD *)this + 32) = 11;
  *(_OWORD *)((char *)this + 145) = 0;
  *(_OWORD *)((char *)this + 136) = 0;
  *((_QWORD *)this + 21) = req;
}


// Address: 0x12a4280 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7RbxCurlEZNS4_13createRbxCurlEvEUlS5_E_EET_T0_
_QWORD *__fastcall boost::detail::shared_count::shared_count<RBX::RbxCurl *,RBX::RbxCurl::createRbxCurl(void)::{lambda(RBX::RbxCurl *)#1}>(
        _QWORD *a1,
        __int64 a2)
{
  _QWORD *result; // rax

  *a1 = 0;
  result = operator new(0x20u);
  result[1] = 0x100000001LL;
  *result = &off_28A6328;
  result[2] = a2;
  *a1 = result;
  return result;
}


// Address: 0x13136d0 | Name: _ZN3RBX11SimpleTimerC2Ev
void __fastcall RBX::SimpleTimer::SimpleTimer(RBX::SimpleTimer *this)
{
  *this = 0;
}


// Address: 0x131ac10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape12SoundChannelENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::SoundChannel *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28A89C8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x131d910 | Name: _ZN5boost6detail12shared_countC2IN3RBX10Soundscape19FMODPlaybackChannelEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::FMODPlaybackChannel>(
        boost::detail::shared_count *this,
        RBX::Soundscape::FMODPlaybackChannel *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28A9648;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1322490 | Name: _ZN3RBX10Soundscape24FMODPlaybackChannelGroupC2EPN4FMOD12ChannelGroupE
void __fastcall RBX::Soundscape::FMODPlaybackChannelGroup::FMODPlaybackChannelGroup(
        RBX::Soundscape::FMODPlaybackChannelGroup *this,
        FMOD::ChannelGroup *_channelGroup)
{
  *(_OWORD *)this = 0;
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_QWORD *)this + 2) = _channelGroup;
}


// Address: 0x132d920 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape15EchoSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::EchoSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::EchoSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AAC48;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x132dbd0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape17FlangeSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::FlangeSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::FlangeSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AACD8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x132de70 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape21DistortionSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::DistortionSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::DistortionSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AAD68;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x132e110 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape21PitchShiftSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::PitchShiftSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::PitchShiftSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AADF8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x132e3c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape17ChorusSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::ChorusSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::ChorusSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AAE88;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x132e670 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape18TremoloSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::TremoloSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::TremoloSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AAF18;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x132e920 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape17ReverbSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::ReverbSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::ReverbSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AAFA8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x132ebd0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape20EqualizerSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::EqualizerSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::EqualizerSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AB038;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x132eea0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape21CompressorSoundEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::CompressorSoundEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::CompressorSoundEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AB0C8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1331330 | Name: _ZN3RBX10Soundscape15FMODPlaybackDSPC2EPN4FMOD3DSPE
void __fastcall RBX::Soundscape::FMODPlaybackDSP::FMODPlaybackDSP(
        RBX::Soundscape::FMODPlaybackDSP *this,
        FMOD::DSP *_dsp)
{
  this->boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackDSP> = 0;
  *(_OWORD *)&this->sideChain = 0;
  this->dsp = _dsp;
}


// Address: 0x13321c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape10SoundGroupENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::SoundGroup *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Soundscape::SoundGroup *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28ACF48;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x13446c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10Soundscape21SoundServiceStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::SoundServiceStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AE008;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1344d90 | Name: _ZN5boost6detail12shared_countC2IN3RBX10Soundscape26NonBlockingFmodSoundLoaderEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Soundscape::NonBlockingFmodSoundLoader>(
        boost::detail::shared_count *this,
        RBX::Soundscape::NonBlockingFmodSoundLoader *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28AE068;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x135cde0 | Name: _ZN3RBX9WebSocketC2Ev
void __fastcall RBX::WebSocket::WebSocket(RBX::WebSocket *this)
{
  this->boost::enable_shared_from_this<RBX::WebSocket> = 0;
  this->_vptr$WebSocket = (int (**)(void))off_28AECB0;
  this->seq = _InterlockedExchangeAdd(&dword_2A1BAD4, 1u);
  this->state = RBX::WebSocketState::WebSocketState_Idle;
}


// Address: 0x13ce4f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10AttachmentENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Attachment *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Attachment *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28AF7A8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x13d69f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints14WeldConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::WeldConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::WeldConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B0C98;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x13e8380 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12AccoutrementENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Accoutrement *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Accoutrement *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B2458;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x13e85c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX3HatENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Hat *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Hat *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B24E8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x13e8800 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9AccessoryENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Accessory *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Accessory *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B2578;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x13f1af0 | Name: _ZN3RBX12MouseCommand13onPeekKeyDownERKN5boost10shared_ptrINS_11InputObjectEEE
_OWORD *__fastcall RBX::MouseCommand::onPeekKeyDown(
        _OWORD *a1,
        RBX::MouseCommand *this,
        const boost::shared_ptr<RBX::InputObject> *inputObject)
{
  *a1 = 0;
  return a1;
}


// Address: 0x13f1e40 | Name: _ZN3RBX12MouseCommand19onMouseWheelForwardERKN5boost10shared_ptrINS_11InputObjectEEE
_OWORD *__fastcall RBX::MouseCommand::onMouseWheelForward(
        _OWORD *a1,
        RBX::MouseCommand *this,
        const boost::shared_ptr<RBX::InputObject> *inputObject)
{
  *a1 = 0;
  return a1;
}


// Address: 0x13f1e50 | Name: _ZN3RBX12MouseCommand20onMouseWheelBackwardERKN5boost10shared_ptrINS_11InputObjectEEE
_OWORD *__fastcall RBX::MouseCommand::onMouseWheelBackward(
        _OWORD *a1,
        RBX::MouseCommand *this,
        const boost::shared_ptr<RBX::InputObject> *inputObject)
{
  *a1 = 0;
  return a1;
}


// Address: 0x13f1f60 | Name: _ZN3RBX12MouseCommand11onPeekKeyUpERKN5boost10shared_ptrINS_11InputObjectEEE
_OWORD *__fastcall RBX::MouseCommand::onPeekKeyUp(
        _OWORD *a1,
        RBX::MouseCommand *this,
        const boost::shared_ptr<RBX::InputObject> *inputObject)
{
  *a1 = 0;
  return a1;
}


// Address: 0x13f2110 | Name: _ZNK3RBX12MouseCommand8isStickyEv
_OWORD *__fastcall RBX::MouseCommand::isSticky(_OWORD *a1, const RBX::MouseCommand *this)
{
  *a1 = 0;
  return a1;
}


// Address: 0x13f3680 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17FilteredSelectionINS3_10PVInstanceEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FilteredSelection<RBX::PVInstance> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B3C68;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x13f4600 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17FilteredSelectionINS3_8InstanceEEENS3_9CreatableIS5_E7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FilteredSelection<RBX::Instance> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B3EC8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x13f6990 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13AdvLuaDraggerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::AdvLuaDragger *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B4138;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1400880 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12PartInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PartInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PartInstance *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B4508;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x140dcd0 | Name: _ZNK3RBX11Constraints21NoCollisionConstraint8getPart0Ev
RBX::PartInstance *__fastcall RBX::Constraints::NoCollisionConstraint::getPart0(
        const RBX::Constraints::NoCollisionConstraint *this)
{
  boost::detail::sp_counted_base *pi; // rax

  pi = this->part0.pn.pi_;
  if ( pi && pi->use_count_ )
    return this->part0.px;
  else
    return 0;
}


// Address: 0x140df60 | Name: _ZNK3RBX11Constraints21NoCollisionConstraint8getPart1Ev
RBX::PartInstance *__fastcall RBX::Constraints::NoCollisionConstraint::getPart1(
        const RBX::Constraints::NoCollisionConstraint *this)
{
  boost::detail::sp_counted_base *pi; // rax

  pi = this->part1.pn.pi_;
  if ( pi && pi->use_count_ )
    return this->part1.px;
  else
    return 0;
}


// Address: 0x140f540 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints21NoCollisionConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::NoCollisionConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::NoCollisionConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B4838;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1413840 | Name: _ZNK3RBX21AttachmentDraggerTool8isStickyEv
_OWORD *__fastcall RBX::AttachmentDraggerTool::isSticky(_OWORD *a1, const RBX::AttachmentDraggerTool *this)
{
  *a1 = 0;
  return a1;
}


// Address: 0x1416d00 | Name: _ZN3RBX21AnalyticsProviderBaseC2EN5boost10shared_ptrINS_16AnalyticsServiceEEE
void __fastcall RBX::AnalyticsProviderBase::AnalyticsProviderBase(
        RBX::AnalyticsProviderBase *this,
        boost::shared_ptr<RBX::AnalyticsService> as)
{
  boost::detail::sp_counted_base *v2; // rax

  this->boost::enable_shared_from_this<RBX::AnalyticsProviderBase> = 0;
  this->_vptr$AnalyticsProviderBase = (int (**)(void))&off_28B5760;
  this->status = RBX::AnalyticsProviderBase::Status::StatusInitializing;
  this->readyCallback.__f_ = 0;
  this->analyticsService.px = *(boost::weak_ptr<RBX::AnalyticsService>::element_type **)as.px;
  v2 = (boost::detail::sp_counted_base *)*((_QWORD *)as.px + 1);
  this->analyticsService.pn.pi_ = v2;
  if ( v2 )
    _InterlockedAdd(&v2->weak_count_, 1u);
}


// Address: 0x1436d30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10ArcHandlesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ArcHandles *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ArcHandles *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B6318;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x145a2f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13LuaWebServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LuaWebService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::LuaWebService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B8118;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x145e710 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13StandardPagesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StandardPages *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B8218;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1482460 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8BackpackENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Backpack *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Backpack *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B84E8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1499420 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13BindableEventENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BindableEvent *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BindableEvent *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B9238;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1499800 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16BindableFunctionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BindableFunction *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BindableFunction *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B9408;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x14ab010 | Name: _ZN5boost6detail12shared_countC2IPN3RBX6CameraENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Camera *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28B9F38;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x14ad000 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrIKNSt3__16vectorINS3_IN3RBX8InstanceEEENS4_9allocatorIS8_EEEEEEE18moveConstruct_funcEPcSF_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0x14ad800 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17ControllerServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ControllerService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ControllerService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BA858;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x14adb50 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12MouseServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MouseService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BA8B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x14b95f0 | Name: _ZN5boost6detail12shared_countC2IP22ChangeHistoryStatsItemN3RBX9CreatableINS5_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<ChangeHistoryStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BB048;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x14c2f10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10BodyColorsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BodyColors *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BodyColors *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BC1F8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x14c3150 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12ShirtGraphicENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ShirtGraphic *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BC288;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x14c33b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5ShirtENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Shirt *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BC318;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x14c3610 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5PantsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Pants *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BC3A8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x14c3850 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4SkinENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Skin *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Skin *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BC438;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1511ad0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17LocalizationTableENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LocalizationTable *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BF948;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1511e20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14CoreGuiServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CoreGuiService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BF9A8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x15134e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX49PlayerLocaleLocalizationServiceTranslatorInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PlayerLocaleLocalizationServiceTranslatorInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28BFA08;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x153a7a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13ClickDetectorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ClickDetector *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C0AB8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x15444c0 | Name: _ZN5boost6detail12shared_countC2IN3RBX17copy_on_write_ptrINSt3__16vectorINS_10shared_ptrINS3_8InstanceEEENS5_9allocatorIS9_EEEEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::copy_on_write_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>(
        boost::detail::shared_count *this,
        RBX::copy_on_write_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28C14B8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1552760 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19CustomEventReceiverENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CustomEventReceiver *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CustomEventReceiver *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C20D8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15543f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11CustomEventENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CustomEvent *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CustomEvent *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C2688;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15576b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX21CustomParticleEmitterENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CustomParticleEmitter *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C2FA8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x157af40 | Name: _ZN3RBX9DataModel16WindowInputStateC2Ev
void __fastcall RBX::DataModel::WindowInputState::WindowInputState(RBX::DataModel::WindowInputState *this)
{
  this->mouseOverInteractable = 0;
  this->mouseOverGui = 0;
  this->guiTargetInstance = 0;
}


// Address: 0x1593fb0 | Name: _ZN5boost6detail12shared_countC2IN3RBX9DataModel10LegacyLock14Implementation6EventsEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::DataModel::LegacyLock::Implementation::Events>(
        boost::detail::shared_count *this,
        RBX::DataModel::LegacyLock::Implementation::Events *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28C5458;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x159d430 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9DataModelENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DataModel *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6248;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x159e710 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9WorkspaceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Workspace *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6498;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x159eeb0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19NotificationServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::NotificationService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6558;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x159f0e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17HttpRbxApiServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::HttpRbxApiService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C65B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x159f4b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12TweenServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TweenService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6618;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x159f6e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11TextServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TextService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6678;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x159fda0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14PhysicsServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PhysicsService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6838;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x15a0170 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15GeometryServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GeometryService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::GeometryService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6898;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a0540 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15GamePassServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GamePassService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::GamePassService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C68F8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a0910 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13DebrisServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DebrisService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::DebrisService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6958;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a0b40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9VRServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::VRService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C69B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x15a0f10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20ContextActionServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ContextActionService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6A18;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x15a1390 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13ScriptServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ScriptService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ScriptService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6D38;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a1760 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12AssetServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::AssetService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::AssetService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6D98;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a1b30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17TouchInputServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TouchInputService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::TouchInputService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6DF8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a1f00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14BrowserServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BrowserService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BrowserService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6E58;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a22d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17AppStorageServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::AppStorageService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::AppStorageService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C6EB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a4e80 | Name: _ZN3rbx14implementation12typed_holderIN5boost10shared_ptrINSt3__16vectorINS3_IN3RBX8InstanceEEENS4_9allocatorIS8_EEEEEEE18moveConstruct_funcEPcSE_
void __fastcall rbx::implementation::typed_holder<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>::moveConstruct_func(
        char *src,
        char *dest)
{
  __int128 v2; // xmm0

  *((_QWORD *)dest + 1) = 0;
  v2 = *(_OWORD *)src;
  *((_QWORD *)src + 1) = 0;
  *(_OWORD *)dest = v2;
  *(_QWORD *)src = 0;
}


// Address: 0x15a5800 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14GamepadServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GamepadService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::GamepadService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C7098;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15a98b0 | Name: _ZN5boost6detail12shared_countC2IN3RBX9DataModel16WindowInputStateEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::DataModel::WindowInputState>(
        boost::detail::shared_count *this,
        RBX::DataModel::WindowInputState *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28C71F8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x15cbba0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11InputObjectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::InputObject *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28C88E8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x15dd440 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16DataStoreServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DataStoreService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::DataStoreService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CA0C8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x15dde10 | Name: _ZN5boost6detail12shared_countC2IN3RBX18RequestDataInQueueEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::RequestDataInQueue>(
        boost::detail::shared_count *this,
        RBX::RequestDataInQueue *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28CA438;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x15ddf80 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9DataStoreENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DataStore *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CA498;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x15de490 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16OrderedDataStoreENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::OrderedDataStore *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CA4F8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1613620 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14DataStorePagesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DataStorePages *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CB3F8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x161be80 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5DecalENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Decal *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CD0A8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x161c0c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12DecalTextureENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DecalTexture *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CD138;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1623860 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8FileMeshENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FileMesh *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CE2F8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1627fe0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9FloorWireENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FloorWire *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CED78;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x162cbd0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16FlyweightServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FlyweightService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::FlyweightService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CF518;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x162f8d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5ValueINS3_12BinaryStringEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Value<RBX::BinaryString> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CF6B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1630720 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10ForceFieldENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ForceField *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ForceField *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28CF908;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1651e30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15PhysicsSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PhysicsSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PhysicsSettings *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D0A88;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1652050 | Name: _ZN5boost6detail12shared_countC2IN3RBX11CommonVerbsEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::CommonVerbs>(
        boost::detail::shared_count *this,
        RBX::CommonVerbs *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28D0AE8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x165ae30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17FilteredSelectionINS3_10AttachmentEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FilteredSelection<RBX::Attachment> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D2018;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x165b970 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17FilteredSelectionINS3_11Constraints10ConstraintEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FilteredSelection<RBX::Constraints::Constraint> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D2218;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x165c4b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17FilteredSelectionINS3_11Constraints14WeldConstraintEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FilteredSelection<RBX::Constraints::WeldConstraint> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D2418;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x16654d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4WeldENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Weld *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Weld *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D2508;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x16f1380 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints13RodConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::RodConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::RodConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D3AF8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x16f4180 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints14RopeConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::RopeConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::RopeConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D4188;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x16f8640 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints16SpringConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::SpringConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::SpringConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D4818;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x16fe350 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4HoleENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Hole *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Hole *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D5BE8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x16fe590 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12MotorFeatureENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MotorFeature *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::MotorFeature *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D5C78;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x16fed50 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13VelocityMotorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::VelocityMotor *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::VelocityMotor *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D64E8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1706de0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9ExplosionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Explosion *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Explosion *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D7E28;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1716690 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10LuaDraggerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LuaDragger *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28D9298;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1736b50 | Name: _ZN5boost6detail12shared_countC2IPN3RBX22GlobalAdvancedSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GlobalAdvancedSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28DCFB8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1736d70 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19GlobalBasicSettingsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GlobalBasicSettings *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28DD018;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x174b550 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12GroupServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GroupService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::GroupService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28DD7A8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1786b80 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5FrameENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Frame *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28DF158;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1791520 | Name: _ZN3RBX17GuiLayerCollector16findLayoutParentEv
_OWORD *__fastcall RBX::GuiLayerCollector::findLayoutParent(_OWORD *a1, RBX::GuiLayerCollector *this)
{
  *a1 = 0;
  return a1;
}


// Address: 0x17bd520 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20ExtrudedPartInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ExtrudedPartInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ExtrudedPartInstance *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28E4868;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x17da560 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10ImageLabelENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ImageLabel *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28E6D98;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x17e6aa0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10DialogRootENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DialogRoot *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28E75A8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x17ea000 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12DialogChoiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DialogChoice *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28E8018;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x17f4050 | Name: _ZN5boost6detail12shared_countC2I10MemStorageEEPT_
void __fastcall boost::detail::shared_count::shared_count<MemStorage>(boost::detail::shared_count *this, MemStorage *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_28E9458;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x17fd600 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8BodyGyroENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BodyGyro *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BodyGyro *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EB288;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x17fd8e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9BodyForceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BodyForce *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BodyForce *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EB318;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x17fdbc0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10BodyThrustENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BodyThrust *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BodyThrust *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EB3A8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x17fdef0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12BodyPositionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BodyPosition *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BodyPosition *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EB438;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x17fe1f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12BodyVelocityENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BodyVelocity *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BodyVelocity *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EB4C8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x17fe4f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19BodyAngularVelocityENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BodyAngularVelocity *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BodyAngularVelocity *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EB558;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x17fe730 | Name: _ZN5boost6detail12shared_countC2IPN3RBX6RocketENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Rocket *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Rocket *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EB5E8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1806b90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18BoxHandleAdornmentENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BoxHandleAdornment *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BoxHandleAdornment *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EEA08;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1806e30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19ConeHandleAdornmentENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ConeHandleAdornment *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ConeHandleAdornment *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EEA98;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x18070d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX23CylinderHandleAdornmentENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CylinderHandleAdornment *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CylinderHandleAdornment *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EEB28;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1807370 | Name: _ZN5boost6detail12shared_countC2IPN3RBX21SphereHandleAdornmentENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SphereHandleAdornment *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SphereHandleAdornment *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EEBB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1807610 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19LineHandleAdornmentENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::LineHandleAdornment *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::LineHandleAdornment *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EEC48;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1807850 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20ImageHandleAdornmentENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ImageHandleAdornment *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28EECD8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x180bb30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7HandlesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Handles *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Handles *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28F0BF8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1812460 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11StarterGearENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StarterGear *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::StarterGear *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28F20B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x18126a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9HopperBinENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::HopperBin *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28F2148;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1843b90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14GuiImageButtonENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GuiImageButton *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28F4468;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1849410 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13ViewportFrameENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ViewportFrame *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ViewportFrame *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28F6408;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x185cb00 | Name: _ZNK3RBX13JointInstance17getPart0DangerousEv
RBX::PartInstance *__fastcall RBX::JointInstance::getPart0Dangerous(const RBX::JointInstance *this)
{
  boost::detail::sp_counted_base *pi; // rax

  pi = this->part[0].pn.pi_;
  if ( pi && pi->use_count_ )
    return this->part[0].px;
  else
    return 0;
}


// Address: 0x185cb50 | Name: _ZNK3RBX13JointInstance17getPart1DangerousEv
RBX::PartInstance *__fastcall RBX::JointInstance::getPart1Dangerous(const RBX::JointInstance *this)
{
  boost::detail::sp_counted_base *pi; // rax

  pi = this->part[1].pn.pi_;
  if ( pi && pi->use_count_ )
    return this->part[1].px;
  else
    return 0;
}


// Address: 0x185db00 | Name: _ZN3RBX13JointInstance8getPart0Ev
RBX::PartInstance *__fastcall RBX::JointInstance::getPart0(RBX::JointInstance *this)
{
  boost::detail::sp_counted_base *pi; // rax

  pi = this->part[0].pn.pi_;
  if ( pi && pi->use_count_ )
    return this->part[0].px;
  else
    return 0;
}


// Address: 0x185db20 | Name: _ZN3RBX13JointInstance8getPart1Ev
RBX::PartInstance *__fastcall RBX::JointInstance::getPart1(RBX::JointInstance *this)
{
  boost::detail::sp_counted_base *pi; // rax

  pi = this->part[1].pn.pi_;
  if ( pi && pi->use_count_ )
    return this->part[1].px;
  else
    return 0;
}


// Address: 0x1860160 | Name: _ZN3RBX5Motor13getParentNameEv
const std::string *__fastcall RBX::Motor::getParentName(RBX::Motor *this)
{
  boost::detail::sp_counted_base *pi; // rcx
  const std::string *result; // rax
  boost::weak_ptr<RBX::PartInstance>::element_type *px; // rcx

  pi = this->part[0].pn.pi_;
  result = (const std::string *)&xmmword_2A038A8;
  if ( pi && pi->use_count_ )
  {
    px = this->part[0].px;
    if ( px )
      return px->name.h.h;
  }
  return result;
}


// Address: 0x1860190 | Name: _ZThn240_N3RBX5Motor13getParentNameEv
void __fastcall `non-virtual thunk to'RBX::Motor::getParentName(RBX::Motor *this)
{
  ;
}


// Address: 0x18601c0 | Name: _ZN3RBX5Motor11getPartNameEv
const std::string *__fastcall RBX::Motor::getPartName(RBX::Motor *this)
{
  boost::detail::sp_counted_base *pi; // rcx
  const std::string *result; // rax
  boost::weak_ptr<RBX::PartInstance>::element_type *px; // rcx

  pi = this->part[1].pn.pi_;
  result = (const std::string *)&xmmword_2A038A8;
  if ( pi && pi->use_count_ )
  {
    px = this->part[1].px;
    if ( px )
      return px->name.h.h;
  }
  return result;
}


// Address: 0x18601f0 | Name: _ZThn240_N3RBX5Motor11getPartNameEv
void __fastcall `non-virtual thunk to'RBX::Motor::getPartName(RBX::Motor *this)
{
  ;
}


// Address: 0x1863810 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4GlueENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Glue *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Glue *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28FA098;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1863a50 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5MotorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Motor *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Motor *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28FA128;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1863cb0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX6RotateENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Rotate *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Rotate *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28FA1E8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1863ef0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7RotatePENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RotateP *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::RotateP *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28FA278;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1864130 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7RotateVENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RotateV *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::RotateV *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28FA308;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1864370 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4SnapENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Snap *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Snap *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28FA398;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x18645d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10ManualWeldENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ManualWeld *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ManualWeld *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28FA458;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1864810 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10ManualGlueENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ManualGlue *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ManualGlue *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_28FA4E8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x18e7ea0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19MegaClusterInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MegaClusterInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2901D98;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x18edad0 | Name: _ZN5boost6detail12shared_countC2IN3RBX6Voxel24GridEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Voxel2::Grid>(
        boost::detail::shared_count *this,
        RBX::Voxel2::Grid *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2903358;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x18eedd0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13TerrainRegionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TerrainRegion *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::TerrainRegion *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29033B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x18f6250 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8MeshPartENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MeshPart *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2904C98;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x18f8460 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4HintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Hint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29067C8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x18f8710 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7MessageENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Message *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2906858;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x192a660 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16TouchTransmitterENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TouchTransmitter *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_290C008;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1934d00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13PartOperationENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PartOperation *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29117B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1934f40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14UnionOperationENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UnionOperation *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2911848;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1935180 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15NegateOperationENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::NegateOperation *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29118D8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1938710 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats25PerformanceStatsChildItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::PerformanceStatsChildItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2916338;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1938890 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats24UntrackedMemoryStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::UntrackedMemoryStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2916398;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1938a10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats30MemoryTrackerCategoryStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::MemoryTrackerCategoryStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29163F8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1938b90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats19CoreMemoryStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::CoreMemoryStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2916458;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1938d10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats20PlaceMemoryStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::PlaceMemoryStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29164B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1938e90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats21DeveloperTagStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::DeveloperTagStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2916518;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1947ca0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17BasicPartInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BasicPartInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BasicPartInstance *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2923BB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x197cbd0 | Name: _ZN5boost6detail12shared_countC2IN3RBX19PersistentDataStoreEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::PersistentDataStore>(
        boost::detail::shared_count *this,
        RBX::PersistentDataStore *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2927B38;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x197e330 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14SpawnerServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SpawnerService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SpawnerService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2927BF8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x197e650 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9PlayerGuiENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PlayerGui *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2927C58;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x197e7d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13PlayerScriptsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PlayerScripts *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PlayerScripts *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2927CB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x197ed00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11PlayerMouseENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PlayerMouse *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2927D18;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x19a45e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11EmotesPagesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::EmotesPages *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2928208;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x19b76d0 | Name: _ZN5boost6detail12shared_countC2IN3RBX19IAdornableCollectorEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::IAdornableCollector>(
        boost::detail::shared_count *this,
        RBX::IAdornableCollector *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2929438;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x19bcbb0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9ScreenGuiENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ScreenGui *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2929F00;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x19bcd30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9TextLabelENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TextLabel *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2929F58;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x19c1b80 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12BillboardGuiENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BillboardGui *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_292A428;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a08b90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11FriendPagesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FriendPages *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_292D338;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a21330 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20StarterPlayerScriptsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StarterPlayerScripts *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::StarterPlayerScripts *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_292E168;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1a214b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX23StarterCharacterScriptsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StarterCharacterScripts *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::StarterCharacterScripts *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_292E1C8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1a21800 | Name: _ZN5boost6detail12shared_countC2IN3RBX17LuaScriptFileDescEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::LuaScriptFileDesc>(
        boost::detail::shared_count *this,
        RBX::LuaScriptFileDesc *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_292E228;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1a2e3d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13PluginManagerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PluginManager *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PluginManager *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_292F8D8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1a2ec10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX6PluginENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Plugin *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_292FB18;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a2f750 | Name: _ZN5boost6detail12shared_countC2IPN3RBX23StandalonePluginScriptsENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StandalonePluginScripts *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::StandalonePluginScripts *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_292FD28;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1a41650 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11PluginMouseENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PluginMouse *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29312F8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a41b40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17MemStorageServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MemStorageService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::MemStorageService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2931358;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1a41cc0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX33MultipleDocumentInterfaceInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MultipleDocumentInterfaceInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::MultipleDocumentInterfaceInstance *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29313B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1a41e40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13PluginToolbarENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PluginToolbar *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2931418;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a41fc0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19DockWidgetPluginGuiENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DockWidgetPluginGui *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2931478;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a42140 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16QWidgetPluginGuiENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::QWidgetPluginGui *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29314D8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a422c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12PluginActionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PluginAction *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2931538;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a42440 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10PluginMenuENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PluginMenu *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2931598;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a54920 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16DataModelSessionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::DataModelSession *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2933F88;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a567b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19PluginToolbarButtonENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PluginToolbarButton *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29344B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a75d10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14RemoteFunctionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RemoteFunction *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2936048;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a76030 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11RemoteEventENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RemoteEvent *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::RemoteEvent *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29360D8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1a84050 | Name: _ZN5boost6detail12shared_countC2IN3RBX6CEventEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::CEvent>(
        boost::detail::shared_count *this,
        RBX::CEvent *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2937208;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1a93690 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4TeamENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Team *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Team *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2938C20;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1a97940 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7GuiMainENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GuiMain *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29392F8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1a987b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5MouseENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Mouse *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2939CC8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1aa1b30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14ScrollingFrameENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ScrollingFrame *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_293A7B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1aa8d70 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4SeatENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Seat *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Seat *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_293E298;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ab1440 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20SkateboardControllerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SkateboardController *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SkateboardController *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_293F868;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ab7700 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18SkateboardPlatformENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SkateboardPlatform *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SkateboardPlatform *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29427F8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1abc450 | Name: _ZN5boost6detail12shared_countC2IPN3RBX3SkyENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Sky *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2945368;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1abf460 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5TrailENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Trail *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2945D38;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1ac2c20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4BeamENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Beam *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2946B08;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1ace0e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18PartOperationAssetENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PartOperationAsset *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29480C8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1ad0bb0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13SpawnLocationENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SpawnLocation *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SpawnLocation *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294A248;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ad2670 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12SpecialShapeENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SpecialShape *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294C4F8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1adb2e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats20PerformanceStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::PerformanceStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294CCF8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1adc710 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats4ItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::Item *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294D238;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1adca90 | Name: _ZN5boost6detail12shared_countC2IP26TotalCountTimeIntervalItemN3RBX9CreatableINS5_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<TotalCountTimeIntervalItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294D560;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1adce00 | Name: _ZN5boost6detail12shared_countC2IP21RunningAverageItemIntN3RBX9CreatableINS5_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RunningAverageItemInt *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294D8A0;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1add170 | Name: _ZN5boost6detail12shared_countC2IP24RunningAverageItemDoubleN3RBX9CreatableINS5_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RunningAverageItemDouble *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294DBE0;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1add550 | Name: _ZN5boost6detail12shared_countC2IP43RunningAverageTimeIntervalItemTimeBenchmarkN3RBX9CreatableINS5_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RunningAverageTimeIntervalItemTimeBenchmark *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294DF20;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1add840 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats12TypedMemItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::TypedMemItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294E0D8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1addac0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5Stats16TypedPercentItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Stats::TypedPercentItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_294E298;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1aef9b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13StudioServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::StudioService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::StudioService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2950508;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1afb6c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX21PlayerEmulatorServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PlayerEmulatorService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2951168;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1b08b90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10SurfaceGuiENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SurfaceGui *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29534A8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1b0a840 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16SurfaceSelectionENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SurfaceSelection *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SurfaceSelection *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2953F88;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1b0b4b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11PackageLinkENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PackageLink *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29543B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1b14f10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16PackageLinkDummyENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PackageLinkDummy *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2954D78;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1b15570 | Name: _ZN5boost6detail12shared_countC2INS_7promiseINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<boost::promise<std::string>>(
        boost::detail::shared_count *this,
        boost::promise<std::string > *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2954F28;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1b483b0 | Name: _ZN5boost6detail12shared_countC2IN3RBX18RCCPackageListenerEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::RCCPackageListener>(
        boost::detail::shared_count *this,
        RBX::RCCPackageListener *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29556F8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1b8ee30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14FunctionalTestENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FunctionalTest *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2957DD8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1b9ab40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13RenderingTestENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RenderingTest *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2958B38;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1ba7c30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7TextBoxENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::TextBox *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_295A138;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1baf310 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13GuiTextButtonENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::GuiTextButton *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_295BCB8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1bc5190 | Name: _ZN3RBX13NumberHandlerC2ERKNS_12Localization10FormatInfoE
void __fastcall RBX::NumberHandler::NumberHandler(
        RBX::NumberHandler *this,
        const RBX::Localization::FormatInfo *formatInfo)
{
  *(_OWORD *)((char *)this + 8) = 0;
  *(_QWORD *)this = &off_295E390;
  *((_QWORD *)this + 3) = formatInfo;
  *((_OWORD *)this + 3) = 0;
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 8) = 0;
  *((_BYTE *)this + 49) = 0;
  *(_OWORD *)((char *)this + 72) = 0;
  *((_QWORD *)this + 11) = 0;
  *((_BYTE *)this + 73) = 0;
  *((_DWORD *)this + 24) = 0;
}


// Address: 0x1bc71d0 | Name: _ZN3RBX15UsernameHandlerC2ERKN5boost9unordered13unordered_setINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS1_4hashISA_EENS4_8equal_toISA_EENS8_ISA_EEEE
void __fastcall RBX::UsernameHandler::UsernameHandler(
        RBX::UsernameHandler *this,
        const boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::string > > *knownUsernames)
{
  this->nextHandler = 0;
  this->_vptr$ParameterizeHandler = (int (**)(void))&off_295E550;
  this->knownUsernames = knownUsernames;
}


// Address: 0x1bd6910 | Name: _ZN5boost6detail12shared_countC2IN3RBX10TypesetterEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Typesetter>(
        boost::detail::shared_count *this,
        RBX::Typesetter *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_295EF68;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1bd7ae0 | Name: _ZN5boost6detail12shared_countC2IN3RBX19HinteractableResultEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::HinteractableResult>(
        boost::detail::shared_count *this,
        RBX::HinteractableResult *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_295F3A8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1bd9d30 | Name: _ZN3RBX4Tool23special_equipped_signalC2Ev
void __fastcall RBX::Tool::special_equipped_signal::special_equipped_signal(RBX::Tool::special_equipped_signal *this)
{
  this->lastArg = 0;
  this->currentlyEquipped = 0;
  this->head.px = 0;
}


// Address: 0x1bdf150 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4ToolENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Tool *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_295FCE8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1bf8230 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17VehicleControllerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::VehicleController *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::VehicleController *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2964628;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1bf96f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18HumanoidControllerENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::HumanoidController *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::HumanoidController *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2964C68;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c11f00 | Name: _ZN5boost6detail12shared_countC2IN3RBX16UserInputService16WindowInputStateEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::UserInputService::WindowInputState>(
        boost::detail::shared_count *this,
        RBX::UserInputService::WindowInputState *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_2966878;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1c12210 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15KeyboardServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::KeyboardService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29668D8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1c20170 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12NumericValueIlEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::NumericValue<long> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::NumericValue<long> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2969A78;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c202f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5ValueIN3G3D15CoordinateFrameEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Value<G3D::CoordinateFrame> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Value<G3D::CoordinateFrame> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2969AD8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c20470 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5ValueIN3G3D6Color3EEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Value<G3D::Color3> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Value<G3D::Color3> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2969B38;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c205f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5ValueINS3_10BrickColorEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Value<RBX::BrickColor> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Value<RBX::BrickColor> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2969B98;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c20770 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11ObjectValueENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ObjectValue *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ObjectValue *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2969BF8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c208f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5ValueINS3_6RbxRayEEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Value<RBX::RbxRay> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Value<RBX::RbxRay> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2969C58;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c20a70 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16ConstrainedValueIlEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ConstrainedValue<long> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ConstrainedValue<long> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2969CB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c20bf0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16ConstrainedValueIdEENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ConstrainedValue<double> *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ConstrainedValue<double> *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2969D18;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c26f00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11VehicleSeatENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::VehicleSeat *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::VehicleSeat *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_296CAB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c314d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10VideoFrameENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::VideoFrame *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_296E628;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1c53120 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18WorkspaceStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::WorkspaceStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2971F88;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1c55d70 | Name: _ZN5boost6detail12shared_countC2IPbNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX5MouseERKNS_10shared_ptrINS8_11InputObjectEEEEENS4_5list2INS4_5valueIPNS8_11PluginMouseEEENSH_ISC_EEEEEEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<bool *,boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Mouse,boost::shared_ptr<RBX::InputObject> const&>,boost::_bi::list2<boost::_bi::value<RBX::PluginMouse *>,boost::_bi::value<boost::shared_ptr<RBX::InputObject>>>>>(
        boost::detail::shared_count *this,
        bool *p,
        __int64 a3)
{
  char *v4; // rax
  __int64 v5; // rcx

  this->pi_ = 0;
  v4 = (char *)operator new(0x40u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2973778;
  *((_QWORD *)v4 + 2) = p;
  *(_OWORD *)(v4 + 24) = *(_OWORD *)a3;
  *(_OWORD *)(v4 + 40) = *(_OWORD *)(a3 + 16);
  v5 = *(_QWORD *)(a3 + 32);
  *((_QWORD *)v4 + 7) = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 8), 1u);
  this->pi_ = (boost::detail::sp_counted_base *)v4;
}


// Address: 0x1c5afd0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10WorldModelENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::WorldModel *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2974DF8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1c603b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10PointLightENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PointLight *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PointLight *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2977118;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c60680 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9SpotLightENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SpotLight *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SpotLight *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29771A8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c60950 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12SurfaceLightENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SurfaceLight *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SurfaceLight *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2977238;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c641c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints11VectorForceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::VectorForce *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::VectorForce *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2978548;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c64400 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints9LineForceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::LineForce *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::LineForce *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29785D8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c66760 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints14TorqueActuatorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::TorqueActuator *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::TorqueActuator *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29792D8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c6b350 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints15HingeConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::HingeConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::HingeConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2979A48;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c6d760 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints16MoveToConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::MoveToConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::MoveToConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297A268;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c6f690 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints19PrismaticConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::PrismaticConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::PrismaticConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297A9B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c76370 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints20BallSocketConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::BallSocketConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::BallSocketConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297B728;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c7c090 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints21CylindricalConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::CylindricalConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::CylindricalConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297BF58;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c80620 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints21OrientationConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::OrientationConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::OrientationConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297CAE8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c828b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11Constraints23AngularVelocityActuatorENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Constraints::AngularVelocityActuator *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Constraints::AngularVelocityActuator *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297D408;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c85520 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11VirtualUserENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::VirtualUser *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297DC18;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1c86630 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12CylinderMeshENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CylinderMesh *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CylinderMesh *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297E188;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c883e0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12SelectionBoxENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SelectionBox *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SelectionBox *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297EB88;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c8b000 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13ABTestServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ABTestService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ABTestService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297F378;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c90e60 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13CharacterMeshENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CharacterMesh *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CharacterMesh *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297FAB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c91a80 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13ConfigurationENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Configuration *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Configuration *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_297FF08;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c9a5f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13PolicyServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PolicyService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PolicyService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29803B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1c9feb0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18SelectionPartLassoENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SelectionPartLasso *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SelectionPartLasso *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2980E78;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ca00f0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19SelectionPointLassoENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SelectionPointLasso *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SelectionPointLasso *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2980F08;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ca1230 | Name: _ZN5boost6detail12shared_countC2IPN3RBX15SelectionSphereENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SelectionSphere *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SelectionSphere *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29818F8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ca3aa0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9FlagStandENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FlagStand *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::FlagStand *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2983EC8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ca4680 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16FlagStandServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::FlagStandService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::FlagStandService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2985B18;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ca5660 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4FlagENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Flag *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2985F48;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1cb86d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16MessagingServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::MessagingService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::MessagingService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2986A98;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cbe170 | Name: _ZN5boost6detail12shared_countC2IPN3RBX17ParabolaAdornmentENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::ParabolaAdornment *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::ParabolaAdornment *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29870E8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cc35c0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX18PathfindingServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PathfindingService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PathfindingService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2987A68;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cc4d10 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4PathENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Path *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Path *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2987E98;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cc63a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19CornerWedgeInstanceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::CornerWedgeInstance *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::CornerWedgeInstance *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2989318;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cca940 | Name: _ZN5boost6detail12shared_countC2IPN3RBX19RbxAnalyticsServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::RbxAnalyticsService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::RbxAnalyticsService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298A3B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cd25d0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4FireENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Fire *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Fire *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298ADE8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cd3550 | Name: _ZN5boost6detail12shared_countC2IPN3RBX4PART5WedgeENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::PART::Wedge *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::PART::Wedge *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298C938;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cd40b0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5SmokeENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Smoke *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Smoke *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298DE78;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cd5280 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8SparklesENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Sparkles *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Sparkles *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298E4A8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cd5b20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9BlockMeshENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BlockMesh *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BlockMesh *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298EAB8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cdbf50 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13HapticServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::HapticService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::HapticService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298F2B8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ce5d30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20UGCValidationServiceENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UGCValidationService *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::UGCValidationService *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298F7F8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ce8f00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX23UIAspectRatioConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UIAspectRatioConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::UIAspectRatioConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_298FF28;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1cebf20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12UIGridLayoutENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UIGridLayout *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2991028;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1ced010 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12UIListLayoutENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UIListLayout *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2991828;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1cf3020 | Name: _ZN5boost6detail12shared_countC2IPN3RBX12UIPageLayoutENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UIPageLayout *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2992198;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1cf6a00 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13UITableLayoutENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UITableLayout *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2992BC8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1cf8920 | Name: _ZN5boost6detail12shared_countC2IPN3RBX14UIInlineLayoutENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UIInlineLayout *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2993358;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1cfa010 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10UIGradientENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UIGradient *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2993858;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1d04b90 | Name: _ZN5boost6detail12shared_countC2IPN3RBX16UISizeConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UISizeConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::UISizeConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2994DD8;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1d05630 | Name: _ZN5boost6detail12shared_countC2IPN3RBX20UITextSizeConstraintENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UITextSizeConstraint *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::UITextSizeConstraint *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2995278;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1d08a40 | Name: _ZN5boost6detail12shared_countC2IPN3RBX5TweenENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Tween *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::Tween *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2995C58;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1d0d1a0 | Name: _ZN5boost6detail12shared_countC2IPN3RBX7UIScaleENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UIScale *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::UIScale *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2996688;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1d0e040 | Name: _ZN5boost6detail12shared_countC2IPN3RBX9UIPaddingENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::UIPadding *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::UIPadding *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_2996B18;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1e8ce90 | Name: _ZN5boost6detail12shared_countC2I10XmlElementEEPT_
void __fastcall boost::detail::shared_count::shared_count<XmlElement>(boost::detail::shared_count *this, XmlElement *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A1558;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1eaccb0 | Name: _ZN5boost6detail12shared_countC2IN3RBX8FontDataEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::FontData>(
        boost::detail::shared_count *this,
        RBX::FontData *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A1618;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1eada30 | Name: _ZN5boost6detail12shared_countC2IPN3RBX13SunRaysEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::SunRaysEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::SunRaysEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29A1828;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1eae210 | Name: _ZN5boost6detail12shared_countC2IPN3RBX10BlurEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BlurEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BlurEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29A1C98;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1eaec20 | Name: _ZN5boost6detail12shared_countC2IPN3RBX11BloomEffectENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::BloomEffect *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        RBX::BloomEffect *p,
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29A2108;
  v3[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v3;
}


// Address: 0x1ec0ff0 | Name: _ZN5boost6detail12shared_countC2IN3RBX19NavigationDebugDrawEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::NavigationDebugDraw>(
        boost::detail::shared_count *this,
        RBX::NavigationDebugDraw *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A30D8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1ec4f30 | Name: _ZN5boost6detail12shared_countC2IN3RBX18HeightfieldBuilderEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::HeightfieldBuilder>(
        boost::detail::shared_count *this,
        RBX::HeightfieldBuilder *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A3350;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1f10a60 | Name: _ZN3RBX10LayoutNodeC2Ev
void __fastcall RBX::LayoutNode::LayoutNode(RBX::LayoutNode *this)
{
  *(_OWORD *)((char *)this + 8) = 0;
  *(_QWORD *)this = &off_29A38E0;
  *(_OWORD *)((char *)this + 40) = 0;
  *(_OWORD *)((char *)this + 24) = 0;
  *((_DWORD *)this + 14) = 1065353216;
  *(_OWORD *)((char *)this + 60) = 0;
  *(_QWORD *)((char *)this + 76) = 0;
  *(_OWORD *)((char *)this + 152) = 0;
  *(_OWORD *)((char *)this + 136) = 0;
  *(_OWORD *)((char *)this + 120) = 0;
  *(_OWORD *)((char *)this + 104) = 0;
  *(_OWORD *)((char *)this + 88) = 0;
  *((_QWORD *)this + 21) = 1065353216;
  *((_WORD *)this + 88) = 7;
}


// Address: 0x1f62010 | Name: _ZN5boost6detail12shared_countC2I24CSGAssetFetchContinuatorEEPT_
void __fastcall boost::detail::shared_count::shared_count<CSGAssetFetchContinuator>(
        boost::detail::shared_count *this,
        CSGAssetFetchContinuator *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A4868;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1f7da40 | Name: _ZN5boost6detail12shared_countC2IN3RBX12FileMeshDataEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::FileMeshData>(
        boost::detail::shared_count *this,
        RBX::FileMeshData *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A4BE8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1f8c120 | Name: _ZN5boost6detail12shared_countC2IPN3RBX8Graphics25FrameRateManagerStatsItemENS3_9CreatableINS3_8InstanceEE7DeleterEEET_T0_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::FrameRateManagerStatsItem *,RBX::Creatable<RBX::Instance>::Deleter>(
        boost::detail::shared_count *this,
        int (**p)(void),
        RBX::Creatable<RBX::Instance>::Deleter d)
{
  boost::detail::sp_counted_base *v3; // rax

  this->pi_ = 0;
  v3 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v3->use_count_ = 0x100000001LL;
  v3->_vptr$sp_counted_base = (int (**)(void))&off_29A50B8;
  v3[1]._vptr$sp_counted_base = p;
  this->pi_ = v3;
}


// Address: 0x1f96860 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Graphics13GlyphRendererEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::GlyphRenderer>(
        boost::detail::shared_count *this,
        RBX::Graphics::GlyphRenderer *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A53A8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1f99340 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Graphics10TextureRef4DataEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::TextureRef::Data>(
        boost::detail::shared_count *this,
        RBX::Graphics::TextureRef::Data *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A5408;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1fa3080 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Graphics9TechniqueEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::Technique>(
        boost::detail::shared_count *this,
        RBX::Graphics::Technique *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A5848;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x1fbb000 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Graphics12SceneManager12GuiClusterRTEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::SceneManager::GuiClusterRT>(
        boost::detail::shared_count *this,
        RBX::Graphics::SceneManager::GuiClusterRT *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A59E8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x201e080 | Name: _ZN5boost6detail12shared_countC2IN3rbx10safe_queueIN3RBX8Graphics14TextureManager11LoadedImageEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage>>(
        boost::detail::shared_count *this,
        rbx::safe_queue<RBX::Graphics::TextureManager::LoadedImage> *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A6828;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x2029210 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Graphics5ImageEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::Image>(
        boost::detail::shared_count *this,
        RBX::Graphics::Image *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A68E8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x2068620 | Name: _ZN5boost6detail12shared_countC2IN3rbx10safe_queueIN3RBX8Graphics11MeshManager7MeshJobEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<rbx::safe_queue<RBX::Graphics::MeshManager::MeshJob>>(
        boost::detail::shared_count *this,
        rbx::safe_queue<RBX::Graphics::MeshManager::MeshJob> *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A7BB8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x20a19f0 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Graphics13GeometryBatchEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::GeometryBatch>(
        boost::detail::shared_count *this,
        RBX::Graphics::GeometryBatch_0 *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A7D98;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x20a3bf0 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Graphics20TextureCompositorJobEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::TextureCompositorJob>(
        boost::detail::shared_count *this,
        RBX::Graphics::TextureCompositorJob *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A7DF8;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x20a3cc0 | Name: _ZN5boost6detail12shared_countC2IN3RBX8Graphics17TextureCompositor3JobEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::Graphics::TextureCompositor::Job>(
        boost::detail::shared_count *this,
        RBX::Graphics::TextureCompositor::Job *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A7E58;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x27befa0 | Name: _ZN5boost6detail12shared_countC2IN3RBX9TaskQueueEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::TaskQueue>(
        boost::detail::shared_count *this,
        RBX::TaskQueue *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29CB038;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x27c0140 | Name: _ZN5boost6detail12shared_countC2INS_15circular_bufferIdNSt3__19allocatorIdEEEEEEPT_
void __fastcall boost::detail::shared_count::shared_count<boost::circular_buffer<double,std::allocator<double>>>(
        boost::detail::shared_count *this,
        boost::circular_buffer<double,std::allocator<double> > *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29CB148;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x27c94f0 | Name: _ZN5boost6detail12shared_countC2IN3RBX4dataEEEPT_
void __fastcall boost::detail::shared_count::shared_count<RBX::data>(boost::detail::shared_count *this, RBX::data *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29CB208;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x283e360 | Name: _ZN5boost6detail12shared_countC2INS_10filesystem16filesystem_error5m_impEEEPT_
void __fastcall boost::detail::shared_count::shared_count<boost::filesystem::filesystem_error::m_imp>(
        boost::detail::shared_count *this,
        boost::filesystem::filesystem_error::m_imp *p)
{
  boost::detail::sp_counted_base *v2; // rax

  this->pi_ = 0;
  v2 = (boost::detail::sp_counted_base *)operator new(0x18u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29CFC30;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->pi_ = v2;
}


// Address: 0x2842de0 | Name: _ZN5boost6threadC2Ev
void __fastcall boost::thread::thread(boost::thread *this)
{
  *this = 0;
}


