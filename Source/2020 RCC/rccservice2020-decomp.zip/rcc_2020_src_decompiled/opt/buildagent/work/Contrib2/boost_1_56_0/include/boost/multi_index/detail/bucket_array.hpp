// Address: 0x1114f00 | Name: _ZN5boost11multi_index6detail12bucket_arrayINSt3__19allocatorINS_10flyweights6detail16refcounted_valueINS6_20default_value_policyIN3RBX15ProtectedStringEE8rep_typeESA_EEEEEC2ERKSE_PNS1_22hashed_index_node_implINS4_IcEEEEm
void __fastcall boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>::bucket_array(
        boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > > *this,
        const std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > *al_0,
        boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >::pointer end_,
        size_t size_)
{
  char *v6; // rax
  __int64 v7; // rdx
  char *v8; // rsi
  __int64 v9; // rdi
  char *v10; // rsi
  __int64 v11; // r12
  unsigned __int64 v12; // rdi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v13; // rdi
  std::logic_error *exception; // rbx

  v6 = "5";
  v7 = 60;
  do
  {
    v8 = v6;
    v9 = v7 + ~(v7 / 2);
    if ( *(_QWORD *)&v6[8 * (v7 / 2)] >= size_ )
      v9 = v7 / 2;
    v6 += 8 * (v7 / 2) + 8;
    if ( *(_QWORD *)&v8[8 * (v7 / 2)] >= size_ )
      v6 = v8;
    v7 = v9;
  }
  while ( v9 );
  v10 = v6 - 8;
  if ( v6 != "N5boost6detail18sp_counted_impl_pdIPNSt3__118basic_stringstreamIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN"
             "S0_13sp_ms_deleterIS8_EEEE" )
    v10 = v6;
  v11 = *(_QWORD *)v10;
  this->size_index_ = (v10 - "5") >> 3;
  v12 = v11 + 1;
  this->spc.n_ = v11 + 1;
  if ( v11 == -1 )
  {
    v13 = 0;
  }
  else
  {
    if ( v12 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    v13 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *)operator new(8 * v12);
  }
  this->spc.data_ = v13;
  memset(v13, 0, 8 * v11);
  end_->prior_ = end_;
  this->spc.data_[v11].prior_ = end_;
  end_->next_ = &this->spc.data_[v11];
}


// Address: 0x11157d0 | Name: _ZN5boost11multi_index6detail17bucket_array_baseILb1EE8positionEmm
size_t __fastcall boost::multi_index::detail::bucket_array_base<true>::position(size_t hash, size_t size_index_)
{
  size_t v2; // rcx
  size_t result; // rax
  size_t v4; // rax
  __int64 v5; // rdx
  size_t v6; // rdx
  __int64 v7; // rax
  size_t v8; // rax
  bool v9; // cf

  v2 = hash;
  switch ( size_index_ )
  {
    case 1uLL:
      return hash % 0x61;
    case 2uLL:
      return hash % 0xC1;
    case 3uLL:
      return hash % 0x185;
    case 4uLL:
      return hash % 0x301;
    case 5uLL:
      return hash % 0x607;
    case 6uLL:
      return hash % 0xC07;
    case 7uLL:
      return hash % 0x1807;
    case 8uLL:
      return hash % 0x3001;
    case 9uLL:
      return hash % 0x6011;
    case 0xAuLL:
      return hash % 0xC005;
    case 0xBuLL:
      return hash % 0x1800D;
    case 0xCuLL:
      return hash % 0x30005;
    case 0xDuLL:
      return hash % 0x60019;
    case 0xEuLL:
      return hash % 0xC0001;
    case 0xFuLL:
      return hash % 0x180005;
    case 0x10uLL:
      return hash % 0x30000B;
    case 0x11uLL:
      return hash % 0x60000D;
    case 0x12uLL:
      return hash % 0xC00005;
    case 0x13uLL:
      return hash % 0x1800013;
    case 0x14uLL:
      return hash % 0x3000005;
    case 0x15uLL:
      return hash % 0x6000017;
    case 0x16uLL:
      return hash % 0xC000013;
    case 0x17uLL:
      return hash % 0x18000005;
    case 0x18uLL:
      return hash % 0x30000059;
    case 0x19uLL:
      return hash % 0x60000005;
    case 0x1AuLL:
      v4 = hash / 0xC0000001;
      v5 = 3221225473LL;
      return hash - v4 * v5;
    case 0x1BuLL:
      v6 = hash / 0x17FFFFFFBLL;
      v7 = 0x17FFFFFFBLL;
      return hash - v6 * v7;
    case 0x1CuLL:
      v4 = hash / 0x300000005LL;
      v5 = 0x300000005LL;
      return hash - v4 * v5;
    case 0x1DuLL:
      v6 = hash / 0x5FFFFFFE7LL;
      v7 = 0x5FFFFFFE7LL;
      return hash - v6 * v7;
    case 0x1EuLL:
      v6 = hash / 0xBFFFFFFFFLL;
      v7 = 0xBFFFFFFFFLL;
      return hash - v6 * v7;
    case 0x1FuLL:
      v6 = hash / 0x1800000007LL;
      v7 = 0x1800000007LL;
      return hash - v6 * v7;
    case 0x20uLL:
      v4 = hash / 0x3000000001LL;
      v5 = 0x3000000001LL;
      return hash - v4 * v5;
    case 0x21uLL:
      v4 = hash / 0x6000000019LL;
      v5 = 0x6000000019LL;
      return hash - v4 * v5;
    case 0x22uLL:
      v6 = hash / 0xBFFFFFFFFFLL;
      v7 = 0xBFFFFFFFFFLL;
      return hash - v6 * v7;
    case 0x23uLL:
      v6 = hash / 0x17FFFFFFFF3LL;
      v7 = 0x17FFFFFFFF3LL;
      return hash - v6 * v7;
    case 0x24uLL:
      v6 = hash / 0x2FFFFFFFFEDLL;
      v7 = 0x2FFFFFFFFEDLL;
      return hash - v6 * v7;
    case 0x25uLL:
      v6 = hash / 0x60000000001LL;
      v7 = 0x60000000001LL;
      return hash - v6 * v7;
    case 0x26uLL:
      v6 = hash / 0xBFFFFFFFFF3LL;
      v7 = 0xBFFFFFFFFF3LL;
      return hash - v6 * v7;
    case 0x27uLL:
      v6 = hash / 0x17FFFFFFFFFFLL;
      v7 = 0x17FFFFFFFFFFLL;
      return hash - v6 * v7;
    case 0x28uLL:
      v6 = hash / 0x300000000037LL;
      v7 = 0x300000000037LL;
      return hash - v6 * v7;
    case 0x29uLL:
      v6 = hash / 0x5FFFFFFFFFF9LL;
      v7 = 0x5FFFFFFFFFF9LL;
      return hash - v6 * v7;
    case 0x2AuLL:
      v6 = hash / 0xBFFFFFFFFFE9LL;
      v7 = 0xBFFFFFFFFFE9LL;
      return hash - v6 * v7;
    case 0x2BuLL:
      v6 = hash / 0x1800000000011LL;
      v7 = 0x1800000000011LL;
      return hash - v6 * v7;
    case 0x2CuLL:
      v6 = hash / 0x2FFFFFFFFFFFBLL;
      v7 = 0x2FFFFFFFFFFFBLL;
      return hash - v6 * v7;
    case 0x2DuLL:
      v6 = hash / 0x6000000000011LL;
      v7 = 0x6000000000011LL;
      return hash - v6 * v7;
    case 0x2EuLL:
      v6 = hash / 0xBFFFFFFFFFFF5LL;
      v7 = 0xBFFFFFFFFFFF5LL;
      return hash - v6 * v7;
    case 0x2FuLL:
      v6 = hash / 0x17FFFFFFFFFFF3LL;
      v7 = 0x17FFFFFFFFFFF3LL;
      return hash - v6 * v7;
    case 0x30uLL:
      v6 = hash / 0x2FFFFFFFFFFFFBLL;
      v7 = 0x2FFFFFFFFFFFFBLL;
      return hash - v6 * v7;
    case 0x31uLL:
      v6 = hash / 0x5FFFFFFFFFFFDBLL;
      v7 = 0x5FFFFFFFFFFFDBLL;
      return hash - v6 * v7;
    case 0x32uLL:
      v6 = hash / 0xC0000000000005LL;
      v7 = 0xC0000000000005LL;
      return hash - v6 * v7;
    case 0x33uLL:
      v6 = hash / 0x17FFFFFFFFFFFFFLL;
      v7 = 0x17FFFFFFFFFFFFFLL;
      return hash - v6 * v7;
    case 0x34uLL:
      v6 = hash / 0x300000000000023LL;
      v7 = 0x300000000000023LL;
      return hash - v6 * v7;
    case 0x35uLL:
      v6 = hash / 0x600000000000005LL;
      v7 = 0x600000000000005LL;
      return hash - v6 * v7;
    case 0x36uLL:
      v4 = hash / 0xBFFFFFFFFFFFFE7LL;
      v5 = 0xBFFFFFFFFFFFFE7LL;
      return hash - v4 * v5;
    case 0x37uLL:
      v6 = hash / 0x1800000000000011LL;
      v7 = 0x1800000000000011LL;
      return hash - v6 * v7;
    case 0x38uLL:
      v6 = hash / 0x3000000000000005LL;
      v7 = 0x3000000000000005LL;
      return hash - v6 * v7;
    case 0x39uLL:
      v6 = (unsigned __int64)((0x155555555555554BLL * (unsigned __int128)hash) >> 64) >> 59;
      v7 = 0x600000000000002FLL;
      return hash - v6 * v7;
    case 0x3AuLL:
      v8 = hash + 0x3FFFFFFFFFFFFFEFLL;
      v9 = hash < 0xC000000000000011LL;
      goto LABEL_64;
    case 0x3BuLL:
      v8 = hash + 59;
      v9 = hash < 0xFFFFFFFFFFFFFFC5LL;
LABEL_64:
      if ( !v9 )
        v2 = v8;
      result = v2;
      break;
    default:
      result = hash % 0x35;
      break;
  }
  return result;
}


// Address: 0x13122c0 | Name: _ZN5boost11multi_index6detail12bucket_arrayINSt3__19allocatorINS_10flyweights6detail16refcounted_valueINS6_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeESB_EEEEEC2ERKSF_PNS1_22hashed_index_node_implINS4_IcEEEEm
void __fastcall boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>::bucket_array(
        boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > > *this,
        const std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > *al_0,
        boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >::pointer end_,
        size_t size_)
{
  char *v6; // rax
  __int64 v7; // rdx
  char *v8; // rsi
  __int64 v9; // rdi
  char *v10; // rsi
  __int64 v11; // r12
  unsigned __int64 v12; // rdi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v13; // rdi
  std::logic_error *exception; // rbx

  v6 = "5";
  v7 = 60;
  do
  {
    v8 = v6;
    v9 = v7 + ~(v7 / 2);
    if ( *(_QWORD *)&v6[8 * (v7 / 2)] >= size_ )
      v9 = v7 / 2;
    v6 += 8 * (v7 / 2) + 8;
    if ( *(_QWORD *)&v8[8 * (v7 / 2)] >= size_ )
      v6 = v8;
    v7 = v9;
  }
  while ( v9 );
  v10 = v6 - 8;
  if ( v6 != "N5boost6detail18sp_counted_impl_pdIPNSt3__118basic_stringstreamIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN"
             "S0_13sp_ms_deleterIS8_EEEE" )
    v10 = v6;
  v11 = *(_QWORD *)v10;
  this->size_index_ = (v10 - "5") >> 3;
  v12 = v11 + 1;
  this->spc.n_ = v11 + 1;
  if ( v11 == -1 )
  {
    v13 = 0;
  }
  else
  {
    if ( v12 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    v13 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *)operator new(8 * v12);
  }
  this->spc.data_ = v13;
  memset(v13, 0, 8 * v11);
  end_->prior_ = end_;
  this->spc.data_[v11].prior_ = end_;
  end_->next_ = &this->spc.data_[v11];
}


// Address: 0x1544d60 | Name: _ZN5boost11multi_index6detail12bucket_arrayINSt3__19allocatorINS_10flyweights6detail16refcounted_valueINS6_20default_value_policyINS3_12basic_stringIcNS3_11char_traitsIcEENS4_IcEEEEE8rep_typeESD_EEEEEC2ERKSH_PNS1_22hashed_index_node_implISC_EEm
void __fastcall boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>::bucket_array(
        boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > > *this,
        const std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > *al_0,
        boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >::pointer end_,
        size_t size_)
{
  char *v6; // rax
  __int64 v7; // rdx
  char *v8; // rsi
  __int64 v9; // rdi
  char *v10; // rsi
  __int64 v11; // r12
  unsigned __int64 v12; // rdi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v13; // rdi
  std::logic_error *exception; // rbx

  v6 = "5";
  v7 = 60;
  do
  {
    v8 = v6;
    v9 = v7 + ~(v7 / 2);
    if ( *(_QWORD *)&v6[8 * (v7 / 2)] >= size_ )
      v9 = v7 / 2;
    v6 += 8 * (v7 / 2) + 8;
    if ( *(_QWORD *)&v8[8 * (v7 / 2)] >= size_ )
      v6 = v8;
    v7 = v9;
  }
  while ( v9 );
  v10 = v6 - 8;
  if ( v6 != "N5boost6detail18sp_counted_impl_pdIPNSt3__118basic_stringstreamIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN"
             "S0_13sp_ms_deleterIS8_EEEE" )
    v10 = v6;
  v11 = *(_QWORD *)v10;
  this->size_index_ = (v10 - "5") >> 3;
  v12 = v11 + 1;
  this->spc.n_ = v11 + 1;
  if ( v11 == -1 )
  {
    v13 = 0;
  }
  else
  {
    if ( v12 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    v13 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *)operator new(8 * v12);
  }
  this->spc.data_ = v13;
  memset(v13, 0, 8 * v11);
  end_->prior_ = end_;
  this->spc.data_[v11].prior_ = end_;
  end_->next_ = &this->spc.data_[v11];
}


// Address: 0x1e2e100 | Name: _ZN5boost11multi_index6detail12bucket_arrayINSt3__19allocatorINS_10flyweights6detail16refcounted_valueINS6_20default_value_policyIN3RBX18PhysicalPropertiesEE8rep_typeESA_EEEEEC2ERKSE_PNS1_22hashed_index_node_implINS4_IcEEEEm
void __fastcall boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties>>>::bucket_array(
        boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > > *this,
        const std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > *al_0,
        boost::multi_index::detail::bucket_array<std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> > >::pointer end_,
        size_t size_)
{
  char *v6; // rax
  __int64 v7; // rdx
  char *v8; // rsi
  __int64 v9; // rdi
  char *v10; // rsi
  __int64 v11; // r12
  unsigned __int64 v12; // rdi
  boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *v13; // rdi
  std::logic_error *exception; // rbx

  v6 = "5";
  v7 = 60;
  do
  {
    v8 = v6;
    v9 = v7 + ~(v7 / 2);
    if ( *(_QWORD *)&v6[8 * (v7 / 2)] >= size_ )
      v9 = v7 / 2;
    v6 += 8 * (v7 / 2) + 8;
    if ( *(_QWORD *)&v8[8 * (v7 / 2)] >= size_ )
      v6 = v8;
    v7 = v9;
  }
  while ( v9 );
  v10 = v6 - 8;
  if ( v6 != "N5boost6detail18sp_counted_impl_pdIPNSt3__118basic_stringstreamIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN"
             "S0_13sp_ms_deleterIS8_EEEE" )
    v10 = v6;
  v11 = *(_QWORD *)v10;
  this->size_index_ = (v10 - "5") >> 3;
  v12 = v11 + 1;
  this->spc.n_ = v11 + 1;
  if ( v11 == -1 )
  {
    v13 = 0;
  }
  else
  {
    if ( v12 >> 61 )
    {
      exception = (std::logic_error *)__cxa_allocate_exception(0x10u);
      std::logic_error::logic_error(exception, "allocator<T>::allocate(size_t n) 'n' exceeds maximum supported size");
      *(_QWORD *)exception = (char *)&`vtable for'std::length_error + 16;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'std::length_error,
        (void (*)(void *))&std::length_error::~length_error);
    }
    v13 = (boost::multi_index::detail::hashed_index_base_node_impl<std::allocator<char> > *)operator new(8 * v12);
  }
  this->spc.data_ = v13;
  memset(v13, 0, 8 * v11);
  end_->prior_ = end_;
  this->spc.data_[v11].prior_ = end_;
  end_->next_ = &this->spc.data_[v11];
}


