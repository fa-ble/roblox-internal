// Address: 0xdcbea0 | Name: _ZN5boost6detail20interruption_checkerC2EP15pthread_mutex_tP14pthread_cond_t
void __fastcall boost::detail::interruption_checker::interruption_checker(
        boost::detail::interruption_checker *this,
        pthread_mutex_t *cond_mutex,
        pthread_cond_t *cond)
{
  boost::detail::thread_data_base *current_thread_data; // rax
  boost::detail::thread_data_base *v5; // r15
  char v6; // al
  boost::mutex *v7; // r15
  boost::detail::thread_data_base *thread_info; // rax
  void *exception; // rax

  current_thread_data = boost::detail::get_current_thread_data();
  this->thread_info = current_thread_data;
  this->m = cond_mutex;
  if ( !current_thread_data )
  {
    this->set = 0;
    goto LABEL_6;
  }
  v5 = current_thread_data;
  v6 = *((_BYTE *)current_thread_data + 408);
  this->set = v6;
  if ( !v6 )
  {
LABEL_6:
    pthread_mutex_lock(cond_mutex);
    return;
  }
  v7 = (boost::mutex *)((char *)v5 + 48);
  boost::mutex::lock(v7);
  thread_info = this->thread_info;
  if ( *((_BYTE *)this->thread_info + 409) )
  {
    *((_BYTE *)thread_info + 409) = 0;
    exception = __cxa_allocate_exception(1u);
    __cxa_throw(exception, (struct type_info *)&`typeinfo for'boost::thread_interrupted, 0);
  }
  *((_QWORD *)thread_info + 43) = cond_mutex;
  *((_QWORD *)thread_info + 44) = cond;
  pthread_mutex_lock(this->m);
  boost::mutex::unlock(v7);
}


// Address: 0xdcf720 | Name: _ZN5boost6detail16thread_data_baseC2Ev
void __fastcall boost::detail::thread_data_base::thread_data_base(boost::detail::thread_data_base *this)
{
  *(_OWORD *)((char *)this + 8) = 0;
  *(_QWORD *)this = &off_29CFE40;
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  boost::mutex::mutex((boost::mutex *)((char *)this + 48));
  boost::condition_variable::condition_variable((boost::condition_variable *)this + 1);
  boost::mutex::mutex((boost::mutex *)((char *)this + 176));
  boost::condition_variable::condition_variable((boost::condition_variable *)((char *)this + 216));
  *((_WORD *)this + 152) = 0;
  *((_BYTE *)this + 306) = 0;
  *((_QWORD *)this + 39) = 0;
  *(_OWORD *)((char *)this + 328) = 0;
  *((_QWORD *)this + 40) = (char *)this + 328;
  *(_OWORD *)((char *)this + 392) = 0;
  *(_OWORD *)((char *)this + 376) = 0;
  *(_OWORD *)((char *)this + 360) = 0;
  *(_OWORD *)((char *)this + 344) = 0;
  *((_WORD *)this + 204) = 1;
}


// Address: 0xdcf940 | Name: _ZN5boost6detail16thread_data_base25notify_all_at_thread_exitEPNS_18condition_variableEPNS_5mutexE
void __fastcall boost::detail::thread_data_base::notify_all_at_thread_exit(
        boost::detail::thread_data_base *this,
        boost::condition_variable *cv,
        boost::mutex *m)
{
  std::pair<boost::condition_variable *,boost::mutex *> *v3; // rax
  std::pair<boost::condition_variable *,boost::mutex *> __x; // [rsp+8h] [rbp-10h] BYREF

  __x.first = cv;
  __x.second = m;
  v3 = (std::pair<boost::condition_variable *,boost::mutex *> *)*((_QWORD *)this + 46);
  if ( (unsigned __int64)v3 >= *((_QWORD *)this + 47) )
  {
    std::vector<std::pair<boost::condition_variable *,boost::mutex *>>::__push_back_slow_path<std::pair<boost::condition_variable *,boost::mutex *>>(
      (boost::detail::thread_data_base *)((char *)this + 360),
      &__x);
  }
  else
  {
    *v3 = __x;
    *((_QWORD *)this + 46) += 16LL;
  }
}


// Address: 0xfe77f0 | Name: _ZN5boost11this_thread5sleepINS_10posix_time7secondsEEEvRKT_
void __fastcall boost::this_thread::sleep<boost::posix_time::seconds>(const boost::posix_time::seconds *rel_time)
{
  boost::posix_time::ptime v1; // rax
  boost::date_time::int_adapter<long>::int_type value; // rdx
  unsigned __int64 v3; // rcx
  boost::date_time::int_adapter<long>::int_type v4; // rcx
  unsigned __int64 v5; // rdi
  unsigned __int64 v6; // rbx
  bool v7; // zf
  timespec ts; // [rsp+8h] [rbp-20h] BYREF

  v1.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
  value = rel_time->ticks_.value_;
  v3 = rel_time->ticks_.value_ - 0x7FFFFFFFFFFFFFFELL;
  if ( (unsigned __int64)(v1.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) >= 3 && v3 > 2 )
    goto LABEL_3;
  if ( v1.time_.time_count_.value_ != 0x8000000000000000LL )
  {
    if ( v1.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFELL )
    {
      v4 = 0x7FFFFFFFFFFFFFFELL;
      goto LABEL_15;
    }
    if ( v1.time_.time_count_.value_ != 0x7FFFFFFFFFFFFFFFLL && v3 > 2 )
      goto LABEL_3;
  }
  v4 = 0x7FFFFFFFFFFFFFFELL;
  if ( value == 0x7FFFFFFFFFFFFFFELL )
    goto LABEL_15;
  v5 = v1.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFFLL;
  if ( v1.time_.time_count_.value_ == 0x8000000000000000LL )
  {
    v6 = 0x7FFFFFFFFFFFFFFFLL;
    v4 = 0x8000000000000000LL;
LABEL_20:
    if ( value == v6 )
    {
      v4 = 0x7FFFFFFFFFFFFFFELL;
      goto LABEL_4;
    }
    if ( v5 >= 2 )
      goto LABEL_23;
    goto LABEL_4;
  }
  if ( v1.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
  {
    v6 = 0x8000000000000000LL;
    v4 = 0x7FFFFFFFFFFFFFFFLL;
    goto LABEL_20;
  }
  v4 = v1.time_.time_count_.value_;
  if ( v5 >= 2 )
  {
LABEL_23:
    if ( value == 0x8000000000000000LL )
    {
      v4 = 0x8000000000000000LL;
      goto LABEL_15;
    }
    if ( value == 0x7FFFFFFFFFFFFFFFLL )
    {
      v4 = 0x7FFFFFFFFFFFFFFFLL;
      goto LABEL_15;
    }
LABEL_3:
    v4 = v1.time_.time_count_.value_ + value;
  }
LABEL_4:
  if ( (unsigned __int64)(v4 - 0x7FFFFFFFFFFFFFFELL) > 2 )
  {
    v4 -= 210866803200000000LL;
    goto LABEL_18;
  }
LABEL_15:
  if ( (unsigned __int64)(v4 - 0x7FFFFFFFFFFFFFFELL) >= 3 )
  {
    v7 = v4 == 0x82ED263D83A88000LL;
    v4 = 0x8000000000000000LL;
    if ( !v7 )
      v4 = 0x7FFFFFFFFFFFFFFELL;
  }
LABEL_18:
  ts.tv_sec = (int)v4 / 1000000;
  ts.tv_nsec = 1000 * (v4 % 1000000);
  boost::this_thread::hiden::sleep_until(&ts);
}


// Address: 0x1228840 | Name: _ZN5boost11this_thread5sleepINS_9date_time18subsecond_durationINS_10posix_time13time_durationELl1000EEEEEvRKT_
void __fastcall boost::this_thread::sleep<boost::date_time::subsecond_duration<boost::posix_time::time_duration,1000l>>(
        const boost::date_time::subsecond_duration<boost::posix_time::time_duration,1000> *rel_time)
{
  boost::posix_time::ptime v1; // rax
  boost::date_time::int_adapter<long>::int_type value; // rdx
  unsigned __int64 v3; // rcx
  boost::date_time::int_adapter<long>::int_type v4; // rcx
  unsigned __int64 v5; // rdi
  unsigned __int64 v6; // rbx
  bool v7; // zf
  timespec ts; // [rsp+8h] [rbp-20h] BYREF

  v1.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
  value = rel_time->ticks_.value_;
  v3 = rel_time->ticks_.value_ - 0x7FFFFFFFFFFFFFFELL;
  if ( (unsigned __int64)(v1.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) >= 3 && v3 > 2 )
    goto LABEL_3;
  if ( v1.time_.time_count_.value_ != 0x8000000000000000LL )
  {
    if ( v1.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFELL )
    {
      v4 = 0x7FFFFFFFFFFFFFFELL;
      goto LABEL_15;
    }
    if ( v1.time_.time_count_.value_ != 0x7FFFFFFFFFFFFFFFLL && v3 > 2 )
      goto LABEL_3;
  }
  v4 = 0x7FFFFFFFFFFFFFFELL;
  if ( value == 0x7FFFFFFFFFFFFFFELL )
    goto LABEL_15;
  v5 = v1.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFFLL;
  if ( v1.time_.time_count_.value_ == 0x8000000000000000LL )
  {
    v6 = 0x7FFFFFFFFFFFFFFFLL;
    v4 = 0x8000000000000000LL;
LABEL_20:
    if ( value == v6 )
    {
      v4 = 0x7FFFFFFFFFFFFFFELL;
      goto LABEL_4;
    }
    if ( v5 >= 2 )
      goto LABEL_23;
    goto LABEL_4;
  }
  if ( v1.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
  {
    v6 = 0x8000000000000000LL;
    v4 = 0x7FFFFFFFFFFFFFFFLL;
    goto LABEL_20;
  }
  v4 = v1.time_.time_count_.value_;
  if ( v5 >= 2 )
  {
LABEL_23:
    if ( value == 0x8000000000000000LL )
    {
      v4 = 0x8000000000000000LL;
      goto LABEL_15;
    }
    if ( value == 0x7FFFFFFFFFFFFFFFLL )
    {
      v4 = 0x7FFFFFFFFFFFFFFFLL;
      goto LABEL_15;
    }
LABEL_3:
    v4 = v1.time_.time_count_.value_ + value;
  }
LABEL_4:
  if ( (unsigned __int64)(v4 - 0x7FFFFFFFFFFFFFFELL) > 2 )
  {
    v4 -= 210866803200000000LL;
    goto LABEL_18;
  }
LABEL_15:
  if ( (unsigned __int64)(v4 - 0x7FFFFFFFFFFFFFFELL) >= 3 )
  {
    v7 = v4 == 0x82ED263D83A88000LL;
    v4 = 0x8000000000000000LL;
    if ( !v7 )
      v4 = 0x7FFFFFFFFFFFFFFELL;
  }
LABEL_18:
  ts.tv_sec = (int)v4 / 1000000;
  ts.tv_nsec = 1000 * (v4 % 1000000);
  boost::this_thread::hiden::sleep_until(&ts);
}


