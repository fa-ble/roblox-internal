// Address: 0x2609380 | Name: _ZN5boost4asio3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE14async_shutdownIRNSt3__18functionIFvRKNS_6system10error_codeEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSE_EE4typeEE4typeEOSM_
boost::asio::async_result<std::function<void (const boost::system::error_code &)> >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_shutdown<std::function<void ()(boost::system::error_code const&)> &>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *this,
        std::function<void (const boost::system::error_code &)> *handler)
{
  std::function<void (const boost::system::error_code &)> *f; // rdi
  boost::asio::ssl::detail::shutdown_op op; // [rsp+8h] [rbp-60h] BYREF
  std::function<void (const boost::system::error_code &)> v5; // [rsp+10h] [rbp-58h] BYREF
  unsigned __int64 v6; // [rsp+50h] [rbp-18h]

  v6 = __readfsqword(0x28u);
  f = (std::function<void (const boost::system::error_code &)> *)handler->__f_;
  if ( f )
  {
    if ( handler == f )
    {
      v5.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&v5;
      (*(void (__fastcall **)(std::function<void (const boost::system::error_code &)> *))(*(_QWORD *)f->__buf_.__lx
                                                                                        + 24LL))(f);
    }
    else
    {
      v5.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)(*(__int64 (__fastcall **)(std::function<void (const boost::system::error_code &)> *))(*(_QWORD *)f->__buf_.__lx + 16LL))(f);
    }
  }
  else
  {
    v5.__f_ = 0;
  }
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>(
    (boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *)this,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *)((char *)this + 32),
    &op,
    &v5);
  if ( &v5 == (std::function<void (const boost::system::error_code &)> *)v5.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v5.__f_->_vptr$__base + 4))(v5.__f_);
  }
  else if ( v5.__f_ )
  {
    (*((void (**)(void))v5.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x2611e00 | Name: _ZN5boost4asio3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE16async_write_someINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISD_NSE_9allocatorISD_EEEEEENSB_8write_opIS9_SI_NSB_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSE_8functionIFvRKNS_6system10error_codeEmEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSS_mEE4typeEE4typeERKT_OS11_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *this,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *buffers,
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *v5; // rdi
  void *ptr[8]; // [rsp+0h] [rbp-118h] BYREF
  __int64 v7; // [rsp+40h] [rbp-D8h] BYREF
  void *v8[8]; // [rsp+48h] [rbp-D0h] BYREF
  int v9; // [rsp+88h] [rbp-90h]
  __int64 v10; // [rsp+90h] [rbp-88h]
  __int64 v11; // [rsp+A0h] [rbp-78h]
  _BYTE v12[32]; // [rsp+B0h] [rbp-68h] BYREF
  _BYTE *v13; // [rsp+D0h] [rbp-48h]
  unsigned __int64 v14; // [rsp+F0h] [rbp-28h]

  v14 = __readfsqword(0x28u);
  v7 = *(_QWORD *)handler;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)v8,
    (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)handler + 8));
  v9 = *((_DWORD *)handler + 18);
  v10 = *((_QWORD *)handler + 10);
  v11 = *((_QWORD *)handler + 12);
  v5 = (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)*((_QWORD *)handler + 18);
  if ( v5 )
  {
    if ( (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)handler + 112) == v5 )
    {
      v13 = v12;
      (*(void (__fastcall **)(boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *, _BYTE *))(*(_QWORD *)v5 + 24LL))(
        v5,
        v12);
    }
    else
    {
      v13 = (_BYTE *)*((_QWORD *)handler + 18);
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    v13 = 0;
  }
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    buffers);
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
    (boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *)this,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *)((char *)this + 32),
    (const boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > > *)ptr,
    (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)&v7);
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  if ( v12 == v13 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v13 + 32LL))(v13);
  }
  else if ( v13 )
  {
    (*(void (**)(void))(*(_QWORD *)v13 + 40LL))();
  }
  if ( v8[0] )
  {
    v8[1] = v8[0];
    operator delete(v8[0]);
  }
}


// Address: 0x2615a60 | Name: _ZN5boost4asio3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE15async_read_someINS0_17mutable_buffers_1ENS0_6detail7read_opIS9_SB_NSC_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSM_mEE4typeEE4typeERKT_OSV_
boost::asio::async_result<boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *f; // rdi
  boost::asio::mutable_buffers_1 v5; // [rsp+0h] [rbp-B8h] BYREF
  boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > v6; // [rsp+10h] [rbp-A8h] BYREF
  unsigned __int64 v7; // [rsp+98h] [rbp-20h]

  v7 = __readfsqword(0x28u);
  *(_OWORD *)&v6.completion_condition_.minimum_ = *(_OWORD *)&handler->completion_condition_.minimum_;
  v6.buffer_ = handler->buffer_;
  v6.start_ = handler->start_;
  *(_OWORD *)&v6.total_transferred_ = *(_OWORD *)&handler->total_transferred_;
  f = (boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)handler->handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v6.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v6.handler_.handler_;
      (*(void (__fastcall **)(boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *, std::function<void (const boost::system::error_code &,unsigned long)> *))(f->completion_condition_.minimum_ + 24))(
        f,
        &v6.handler_.handler_);
    }
    else
    {
      v6.handler_.handler_.__f_ = handler->handler_.handler_.__f_;
      handler->handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    v6.handler_.handler_.__f_ = 0;
  }
  v5 = *buffers;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
    (boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *)this,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *)((char *)this + 32),
    (const boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&v5,
    &v6);
  if ( &v6.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v6.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v6.handler_.handler_.__f_->_vptr$__base
     + 4))(v6.handler_.handler_.__f_);
  }
  else if ( v6.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v6.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x261a250 | Name: _ZN5boost4asio3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEEC2INS0_10io_serviceEEERT_RNS1_7contextE
void __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::stream<boost::asio::io_service>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *this,
        boost::asio::io_service *arg,
        boost::asio::ssl::context *ctx)
{
  boost::asio::detail::service_registry *service_registry; // rdi
  boost::asio::io_service::service *v6; // rax
  boost::asio::io_service::service::key_0 v7; // [rsp+0h] [rbp-28h] BYREF

  *((_DWORD *)this + 4) = 2;
  service_registry = arg->service_registry_;
  v7.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::stream_socket_service<boost::asio::ip::tcp>>;
  v7.id_ = 0;
  v6 = boost::asio::detail::service_registry::do_use_service(
         service_registry,
         &v7,
         boost::asio::detail::service_registry::create<boost::asio::stream_socket_service<boost::asio::ip::tcp>>);
  *((_QWORD *)this + 3) = v6;
  *(_DWORD *)this = -1;
  *((_BYTE *)this + 4) = 0;
  boost::asio::ssl::detail::stream_core::stream_core(
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *)((char *)this + 32),
    ctx->handle_,
    v6->owner_);
  *((_QWORD *)this + 34) = *((_QWORD *)this + 4);
}


// Address: 0x261a8a0 | Name: _ZN5boost4asio3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEED2Ev
void __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::~stream(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *this)
{
  void *v2; // rdi
  void *v3; // rdi
  __int64 v4; // rax
  boost::system::error_code v5; // [rsp+0h] [rbp-18h] BYREF

  v2 = (void *)*((_QWORD *)this + 27);
  if ( v2 )
  {
    *((_QWORD *)this + 28) = v2;
    operator delete(v2);
  }
  v3 = (void *)*((_QWORD *)this + 22);
  if ( v3 )
  {
    *((_QWORD *)this + 23) = v3;
    operator delete(v3);
  }
  boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>,false>::~basic_io_object((boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false> *)((char *)this + 112));
  boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>,false>::~basic_io_object((boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false> *)((char *)this + 48));
  if ( SSL_get_ex_data(*((_QWORD *)this + 4), 0) )
  {
    v4 = SSL_get_ex_data(*((_QWORD *)this + 4), 0);
    if ( v4 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(v4);
    SSL_set_ex_data(*((_QWORD *)this + 4), 0, 0);
  }
  BIO_free(*((_QWORD *)this + 5));
  SSL_free(*((_QWORD *)this + 4));
  if ( *(_DWORD *)this != -1 )
  {
    boost::asio::detail::epoll_reactor::deregister_descriptor(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)this + 3) + 40LL),
      *(_DWORD *)this,
      (boost::asio::detail::epoll_reactor::per_descriptor_data *)this + 1,
      (*((_BYTE *)this + 4) & 0x40) == 0);
    v5.m_val = 0;
    v5.m_cat = boost::system::system_category();
    boost::asio::detail::socket_ops::close(
      *(_DWORD *)this,
      (boost::asio::detail::socket_ops::state_type *)this + 4,
      1,
      &v5);
  }
}


// Address: 0x26318b0 | Name: _ZN5boost4asio3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE15async_handshakeINS0_6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJNSF_10shared_ptrISL_EERSR_RKNSF_12placeholders4__phILi1EEEEEENSB_26is_continuation_if_runningEEEEENS0_12async_resultINS0_12handler_typeIT_FvST_EE4typeEE4typeENS1_11stream_base14handshake_typeEOS1B_
boost::asio::async_result<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_handshake<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *this,
        boost::asio::ssl::stream_base::handshake_type type,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::handshake_op op; // [rsp+8h] [rbp-A0h] BYREF
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> v7; // [rsp+10h] [rbp-98h] BYREF
  unsigned __int64 v8; // [rsp+80h] [rbp-28h]

  v8 = __readfsqword(0x28u);
  v7.dispatcher_ = handler->dispatcher_;
  *(_OWORD *)&v7.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v7.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v7.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v7.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))f->dispatcher_.service_->owner_)(
        f,
        &v7.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      v7.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v7.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  op.type_ = type;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
    (boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *)this,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *)((char *)this + 32),
    &op,
    &v7);
  if ( &v7.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v7.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v7.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v7.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v7.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v7.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v7.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v7.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v7.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x2631af0 | Name: _ZN5boost4asio3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE15async_handshakeINSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrISH_EERSN_RKNSB_12placeholders4__phILi1EEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSP_EE4typeEE4typeENS1_11stream_base14handshake_typeEOS15_
boost::asio::async_result<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_handshake<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *this,
        boost::asio::ssl::stream_base::handshake_type type,
        std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *handler)
{
  std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::handshake_op op; // [rsp+8h] [rbp-90h] BYREF
  std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> v7; // [rsp+10h] [rbp-88h] BYREF
  unsigned __int64 v8; // [rsp+70h] [rbp-28h]

  v8 = __readfsqword(0x28u);
  *(_OWORD *)&v7.__f_ = *(_OWORD *)&handler->__f_;
  v7.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *)handler->__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v7.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v7.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))f->__f_
       + 3))(
        f,
        &v7.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      v7.__bound_args_.__base_.__value_.__f_ = handler->__bound_args_.__base_.__value_.__f_;
      handler->__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v7.__bound_args_.__base_.__value_.__f_ = 0;
  }
  op.type_ = type;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>(
    (boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *)this,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *)((char *)this + 32),
    &op,
    &v7);
  if ( &v7.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v7.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v7.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v7.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v7.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v7.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v7.__bound_args_.__base_.__value_.__cntrl_;
  if ( v7.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v7.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x2696470 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEED2Ev
void __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::~stream(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *this)
{
  void *v2; // rdi
  void *v3; // rdi
  __int64 v4; // rax

  v2 = (void *)*((_QWORD *)this + 24);
  if ( v2 )
  {
    *((_QWORD *)this + 25) = v2;
    operator delete(v2);
  }
  v3 = (void *)*((_QWORD *)this + 19);
  if ( v3 )
  {
    *((_QWORD *)this + 20) = v3;
    operator delete(v3);
  }
  boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>,false>::~basic_io_object((boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false> *)((char *)this + 88));
  boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>,false>::~basic_io_object((boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false> *)((char *)this + 24));
  if ( SSL_get_ex_data(*((_QWORD *)this + 1), 0) )
  {
    v4 = SSL_get_ex_data(*((_QWORD *)this + 1), 0);
    if ( v4 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 8LL))(v4);
    SSL_set_ex_data(*((_QWORD *)this + 1), 0, 0);
  }
  BIO_free(*((_QWORD *)this + 2));
  SSL_free(*((_QWORD *)this + 1));
}


// Address: 0x26a2330 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE16async_write_someINS0_15const_buffers_1ENS0_6detail8write_opISA_SC_NSD_14transfer_all_tENSD_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSK_5list2INSK_5valueINSH_10shared_ptrIST_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSV_mEE4typeEE4typeERKT_OS1E_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_write_some<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *this,
        const boost::asio::const_buffers_1 *buffers,
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v3; // rax
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::const_buffers_1 v5; // [rsp+0h] [rbp-78h] BYREF
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > v6; // [rsp+10h] [rbp-68h] BYREF

  v6 = *handler;
  handler->handler_.handler_.l_ = 0;
  v3 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  v5 = *buffers;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
    v3,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *)((char *)this + 8),
    (const boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)&v5,
    &v6);
  cntrl = v6.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a4ed0 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE15async_read_someINS0_17mutable_buffers_1ENS0_6detail26read_until_delim_string_opISA_NSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSI_5list2INSI_5valueINSF_10shared_ptrISR_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvST_mEE4typeEE4typeERKT_OS1B_
boost::asio::async_result<boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *handler)
{
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v3; // rax
  std::__shared_weak_count *v4; // rbx
  __int128 v5; // [rsp+0h] [rbp-88h] BYREF
  __int128 v6; // [rsp+10h] [rbp-78h]
  void *ptr; // [rsp+20h] [rbp-68h]
  int v8; // [rsp+28h] [rbp-60h]
  __int64 v9; // [rsp+30h] [rbp-58h]
  __int128 v10; // [rsp+38h] [rbp-50h]
  std::__shared_weak_count *v11[2]; // [rsp+48h] [rbp-40h]
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> op; // [rsp+60h] [rbp-28h] BYREF

  v5 = *(_OWORD *)handler;
  ptr = (void *)*((_QWORD *)handler + 4);
  v6 = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  v8 = *((_DWORD *)handler + 10);
  v9 = *((_QWORD *)handler + 6);
  v10 = *(_OWORD *)((char *)handler + 56);
  *(_OWORD *)v11 = *(_OWORD *)((char *)handler + 72);
  *(_OWORD *)((char *)handler + 72) = 0;
  v3 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  op = (boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>)*buffers;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>(
    v3,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *)((char *)this + 8),
    &op,
    (boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *)&v5);
  v4 = v11[1];
  if ( v11[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v11[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
    if ( (v6 & 1) == 0 )
      return;
  }
  else if ( (v6 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a83d0 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE19set_verify_callbackIZN3web4http6client7details12asio_context13write_requestEvEUlbRNS1_14verify_contextEE_EEvT_
const boost::system::error_category *__fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::set_verify_callback<web::http::client::details::asio_context::write_request(void)::{lambda(bool,boost::asio::ssl::verify_context &)#1}>(
        __int64 a1,
        __int64 *a2)
{
  __int64 v2; // r12
  volatile signed __int64 *v3; // r15
  _QWORD *v4; // rbx
  __int64 v5; // rax
  __int64 v6; // rbx
  unsigned int verify_mode; // eax
  const boost::system::error_category *result; // rax

  boost::system::system_category();
  v2 = *a2;
  v3 = (volatile signed __int64 *)a2[1];
  if ( v3 )
    _InterlockedAdd64(v3 + 2, 1u);
  v4 = operator new(0x18u);
  if ( v3 )
  {
    _InterlockedAdd64(v3 + 2, 1u);
    *v4 = &off_29C7478;
    v4[1] = v2;
    v4[2] = v3;
    _InterlockedAdd64(v3 + 2, 1u);
  }
  else
  {
    *v4 = &off_29C7478;
    v4[1] = v2;
    v4[2] = 0;
  }
  if ( SSL_get_ex_data(*(_QWORD *)(a1 + 8), 0) )
  {
    v5 = SSL_get_ex_data(*(_QWORD *)(a1 + 8), 0);
    if ( v5 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(v5);
  }
  SSL_set_ex_data(*(_QWORD *)(a1 + 8), 0, v4);
  v6 = *(_QWORD *)(a1 + 8);
  verify_mode = SSL_get_verify_mode(v6);
  SSL_set_verify(v6, verify_mode, boost::asio::ssl::detail::engine::verify_callback_function);
  result = boost::system::system_category();
  if ( v3 )
  {
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
    return (const boost::system::error_category *)std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
  }
  return result;
}


// Address: 0x26a8500 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE15async_handshakeIRKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSC_5list2INSC_5valueINSt3__110shared_ptrISK_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSM_EE4typeEE4typeENS1_11stream_base14handshake_typeEOS16_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_handshake<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *this,
        boost::asio::ssl::stream_base::handshake_type type,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // r14
  volatile signed __int64 *cntrl; // rbx
  std::__shared_weak_count *v5; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v6; // [rsp+8h] [rbp-80h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+60h] [rbp-28h]
  boost::system::error_code v8; // 0:esi.4,8:rdx.8

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v6.next_layer_ = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  v6.core_ = (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *)((char *)this + 8);
  v6.op_.type_ = type;
  *(_QWORD *)&v6.start_ = 0;
  v6.ec_.m_val = 0;
  v6.ec_.m_cat = boost::system::system_category();
  v6.bytes_transferred_ = 0;
  v6.handler_.f_ = f;
  v6.handler_.l_.a1_.t_.__ptr_ = ptr;
  v6.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  v8.m_val = 0;
  v8.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
    &v6,
    v8,
    0,
    1);
  v5 = v6.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v6.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
      std::__shared_weak_count::__release_weak(v5);
    }
  }
}


// Address: 0x26a9d80 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE16async_write_someINS0_15const_buffers_1ENS0_6detail8write_opISA_SC_NSD_14transfer_all_tENSD_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSK_5list2INSK_5valueINSH_10shared_ptrISS_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSU_mEE4typeEE4typeERKT_OS1D_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_write_some<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *this,
        const boost::asio::const_buffers_1 *buffers,
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v3; // rax
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::const_buffers_1 v5; // [rsp+0h] [rbp-78h] BYREF
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v6; // [rsp+10h] [rbp-68h] BYREF

  v6 = *handler;
  handler->handler_.handler_.l_ = 0;
  v3 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  v5 = *buffers;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    v3,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *)((char *)this + 8),
    (const boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)&v5,
    &v6);
  cntrl = v6.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26ad350 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE15async_read_someINS0_17mutable_buffers_1ENS0_6detail26read_until_delim_string_opISA_NSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSI_5list2INSI_5valueINSF_10shared_ptrISQ_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSS_mEE4typeEE4typeERKT_OS1A_
boost::asio::async_result<boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v3; // rax
  std::__shared_weak_count *v4; // rbx
  __int128 v5; // [rsp+0h] [rbp-88h] BYREF
  __int128 v6; // [rsp+10h] [rbp-78h]
  void *ptr; // [rsp+20h] [rbp-68h]
  int v8; // [rsp+28h] [rbp-60h]
  __int64 v9; // [rsp+30h] [rbp-58h]
  __int128 v10; // [rsp+38h] [rbp-50h]
  std::__shared_weak_count *v11[2]; // [rsp+48h] [rbp-40h]
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> op; // [rsp+60h] [rbp-28h] BYREF

  v5 = *(_OWORD *)handler;
  ptr = (void *)*((_QWORD *)handler + 4);
  v6 = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  v8 = *((_DWORD *)handler + 10);
  v9 = *((_QWORD *)handler + 6);
  v10 = *(_OWORD *)((char *)handler + 56);
  *(_OWORD *)v11 = *(_OWORD *)((char *)handler + 72);
  *(_OWORD *)((char *)handler + 72) = 0;
  v3 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  op = (boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>)*buffers;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    v3,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *)((char *)this + 8),
    &op,
    (boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *)&v5);
  v4 = v11[1];
  if ( v11[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v11[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
    if ( (v6 & 1) == 0 )
      return;
  }
  else if ( (v6 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26b1e40 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE15async_read_someINS0_17mutable_buffers_1ENS0_6detail17read_streambuf_opISA_NSt3__19allocatorIcEENSD_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSJ_5list2INSJ_5valueINSF_10shared_ptrISR_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvST_mEE4typeEE4typeERKT_OS1B_
boost::asio::async_result<boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v3; // rax
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::mutable_buffers_1 v5; // [rsp+0h] [rbp-78h] BYREF
  boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v6; // [rsp+10h] [rbp-68h] BYREF

  v6 = *handler;
  handler->handler_.l_ = 0;
  v3 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  v5 = *buffers;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    v3,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *)((char *)this + 8),
    (const boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&v5,
    &v6);
  cntrl = v6.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v6.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b5880 | Name: _ZN5boost4asio3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEEE15async_read_someINS0_17mutable_buffers_1ENS0_6detail17read_streambuf_opISA_NSt3__19allocatorIcEENSD_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSJ_5list3INSJ_5valueINSF_10shared_ptrISR_EEEEPFNS_3argILi1EEEvENSY_IiEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvST_mEE4typeEE4typeERKT_OS1C_
boost::asio::async_result<boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > >::type __fastcall boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *this,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > *handler)
{
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v3; // rax
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::mutable_buffers_1 v5; // [rsp+0h] [rbp-78h] BYREF
  boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > v6; // [rsp+10h] [rbp-68h] BYREF

  *(_OWORD *)&v6.completion_condition_.size_ = *(_OWORD *)&handler->completion_condition_.size_;
  v6.streambuf_ = handler->streambuf_;
  v6.start_ = handler->start_;
  v6.total_transferred_ = handler->total_transferred_;
  v6.handler_.f_ = handler->handler_.f_;
  v6.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  v6.handler_.l_.a3_.t_ = handler->handler_.l_.a3_.t_;
  v3 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  v5 = *buffers;
  boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
    v3,
    (boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *)((char *)this + 8),
    (const boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)&v5,
    &v6);
  cntrl = v6.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v6.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


