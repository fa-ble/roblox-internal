// Address: 0x1281920 | Name: _ZN5boost6random23mersenne_twister_engineIjLm32ELm624ELm397ELm31ELj2567483615ELm11ELj4294967295ELm7ELj2636928640ELm15ELj4022730752ELm18ELj1812433253EE4seedINS_5uuids6detail18generator_iteratorINS5_8seed_rngEEEEEvRT_S9_
// local variable allocation has failed, the output may be wrong!
void __fastcall boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>::seed<boost::uuids::detail::generator_iterator<boost::uuids::detail::seed_rng>>(
        boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> *this,
        boost::uuids::detail::generator_iterator<boost::uuids::detail::seed_rng> *first,
        boost::uuids::detail::generator_iterator<boost::uuids::detail::seed_rng> last)
{
  boost::uuids::detail::seed_rng *m_g; // r12
  unsigned __int64 i; // rbx
  boost::uuids::detail::seed_rng *v5; // rbp
  boost::uuids::detail::seed_rng::result_type v6; // r14d
  int rd_index; // eax
  signed int v8; // eax
  int v9; // edx
  unsigned int v10; // edx
  unsigned __int64 v11; // rax
  boost::uuids::detail::seed_rng::result_type m_value; // [rsp+4h] [rbp-44h]
  _QWORD v14[8]; // [rsp+8h] [rbp-40h] BYREF

  m_value = last.m_value;
  m_g = last.m_g;
  for ( i = 0; i < 0x270; ++i )
  {
    v5 = first->m_g;
    if ( first->m_g == m_g )
    {
      v6 = first->m_value;
      if ( v6 == m_value )
      {
        std::logic_error::logic_error((std::logic_error *)v14, "Not enough elements in call to seed.");
        v14[0] = (char *)&`vtable for'std::invalid_argument + 16;
        boost::throw_exception<std::invalid_argument>((const std::invalid_argument *)v14);
      }
    }
    else
    {
      v6 = first->m_value;
    }
    rd_index = v5->rd_index_;
    if ( rd_index >= 5 )
    {
      boost::uuids::detail::seed_rng::sha1_random_digest_(first->m_g);
      v5->rd_index_ = 0;
      rd_index = 0;
    }
    v5->rd_index_ = rd_index + 1;
    first->m_value = v5->rd_[rd_index];
    this->x[i] = v6;
  }
  this->i = 624;
  v8 = this->x[396] ^ this->x[623];
  v9 = (2 * v8) ^ 0x321161BF;
  if ( v8 >= 0 )
    v9 = 2 * v8;
  v10 = this->x[0] & 0x80000000 | v9 & 0x7FFFFFFF;
  this->x[0] = v10;
  if ( !v10 )
  {
    v11 = 1;
    while ( v11 <= 0x26F )
    {
      if ( this->x[v11++] != 0 )
        return;
    }
    this->x[0] = 0x80000000;
  }
}


// Address: 0x1283500 | Name: _ZN5boost6random23mersenne_twister_engineIjLm32ELm624ELm397ELm31ELj2567483615ELm11ELj4294967295ELm7ELj2636928640ELm15ELj4022730752ELm18ELj1812433253EE5twistEv
void __fastcall boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>::twist(
        boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> *this)
{
  unsigned int v1; // ecx
  __int64 i; // rax
  unsigned int v3; // esi
  __m128 v4; // xmm0
  __m128i v5; // xmm2
  __m128i v6; // xmm3
  __m128i v7; // xmm0
  __m128i si128; // xmm4
  unsigned int v9; // ecx
  __int64 j; // rax
  unsigned int v11; // esi

  v1 = this->x[0];
  for ( i = 0; i != 222; ++i )
  {
    v3 = (v1 & 0x80000000 | this->x[i + 1] & 0x7FFFFFFE) >> 1;
    v1 = this->x[i + 1];
    this->x[i] = v3 ^ this->x[i + 397] ^ (-1727483681 * (v1 & 1));
  }
  v4 = *(__m128 *)&this->x[223];
  v5 = (__m128i)_mm_or_ps(
                  _mm_and_ps((__m128)xmmword_3E58B0, v4),
                  _mm_and_ps(
                    _mm_shuffle_ps(_mm_shuffle_ps((__m128)this->x[222], v4, 0), v4, 152),
                    *(__m128 *)&stru_3E4970.x));
  v6 = _mm_shuffle_epi32((__m128i)v4, 231);
  v7 = _mm_and_si128((__m128i)v4, (__m128i)xmmword_3EA800);
  si128 = _mm_load_si128((const __m128i *)&xmmword_3E92C0);
  *(__m128i *)&this->x[222] = _mm_xor_si128(
                                _mm_xor_si128(
                                  _mm_unpacklo_epi32(
                                    _mm_shuffle_epi32(_mm_mul_epu32(v7, si128), 232),
                                    _mm_shuffle_epi32(_mm_mul_epu32(_mm_shuffle_epi32(v7, 245), si128), 232)),
                                  _mm_loadu_si128((const __m128i *)&this->x[619])),
                                _mm_srli_epi32(v5, 1u));
  v9 = this->x[227];
  this->x[226] = ((_mm_cvtsi128_si32(v6) & 0x80000000 | v9 & 0x7FFFFFFE) >> 1) ^ this->x[623] ^ (-1727483681 * (v9 & 1));
  for ( j = 0; j != 396; ++j )
  {
    v11 = (v9 & 0x80000000 | this->x[j + 228] & 0x7FFFFFFE) >> 1;
    v9 = this->x[j + 228];
    this->x[j + 227] = v11 ^ this->x[j] ^ (-1727483681 * (v9 & 1));
  }
  this->x[623] = ((this->x[623] & 0x80000000 | this->x[0] & 0x7FFFFFFE) >> 1)
               ^ this->x[396]
               ^ (-1727483681 * (this->x[0] & 1));
  this->i = 0;
}


