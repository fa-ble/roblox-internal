// Address: 0x25f5620 | Name: _ZN5boost4asio6detail10socket_ops9inet_ptonEiPKcPvPmRNS_6system10error_codeE
int __fastcall boost::asio::detail::socket_ops::inet_pton(
        int af_0,
        const char *src,
        void *dest,
        unsigned __int64 *scope_id,
        boost::system::error_code *ec)
{
  int *v8; // r15
  int v9; // eax
  int v10; // ebx
  int v11; // r15d
  const boost::system::error_category *v12; // rax
  char *v13; // rax
  char *v14; // r14
  bool v15; // cl
  const boost::system::error_category *v16; // rax
  bool v17; // al
  unsigned int v18; // eax
  _BYTE *v20; // [rsp+0h] [rbp-38h]

  v8 = __errno_location();
  *v8 = 0;
  v20 = dest;
  v9 = inet_pton(af_0, src, dest);
  v10 = *v8;
  v11 = v9;
  v12 = boost::system::system_category();
  ec->m_val = v10;
  ec->m_cat = v12;
  if ( v11 <= 0 )
  {
    if ( !v10 )
    {
      v16 = boost::system::system_category();
      ec->m_val = 22;
      ec->m_cat = v16;
    }
    return v11;
  }
  if ( af_0 != 10 )
    return v11;
  if ( !scope_id )
    return v11;
  *scope_id = 0;
  v13 = strchr(src, 37);
  if ( !v13 )
    return v11;
  v14 = v13;
  if ( *v20 == 0xFF )
  {
    v17 = (v20[1] & 0xF) == 2;
    goto LABEL_13;
  }
  v15 = *v20 == 0xFE && (v20[1] & 0xC0) == 0x80;
  v17 = 0;
  if ( !v15 )
  {
LABEL_13:
    if ( !v17 )
    {
LABEL_15:
      *scope_id = (int)strtol(v14 + 1, 0, 10);
      return v11;
    }
  }
  v18 = if_nametoindex(v14 + 1);
  *scope_id = v18;
  if ( !v18 )
    goto LABEL_15;
  return v11;
}


// Address: 0x25f9040 | Name: _ZN5boost4asio6detail10socket_ops5closeEiRhbRNS_6system10error_codeE
int __fastcall boost::asio::detail::socket_ops::close(
        boost::asio::detail::socket_type s,
        boost::asio::detail::socket_ops::state_type *state,
        bool destruction,
        boost::system::error_code *ec)
{
  int v5; // ebp
  int *v6; // r12
  int v7; // ebp
  int v8; // ebx
  const boost::system::error_category *v9; // rax
  const boost::system::error_category **p_m_cat; // r13
  int v11; // ebx
  const boost::system::error_category *v12; // rax
  const boost::system::error_category *v13; // rax
  int v15; // [rsp+4h] [rbp-44h] BYREF
  boost::asio::detail::socket_ops::state_type *v16; // [rsp+8h] [rbp-40h]
  _QWORD optval[7]; // [rsp+10h] [rbp-38h] BYREF

  if ( s == -1 )
  {
    p_m_cat = &ec->m_cat;
LABEL_14:
    v13 = boost::system::system_category();
    ec->m_val = 0;
    *p_m_cat = v13;
    return 0;
  }
  if ( destruction && (*state & 8) != 0 )
  {
    optval[0] = 0;
    boost::system::system_category();
    *state |= 8u;
    *__errno_location() = 0;
    v5 = setsockopt(s, 1, 13, optval, 8u);
    boost::system::system_category();
    if ( !v5 )
      boost::system::system_category();
  }
  v16 = state;
  v6 = __errno_location();
  *v6 = 0;
  v7 = close(s);
  v8 = *v6;
  v9 = boost::system::system_category();
  ec->m_val = v8;
  p_m_cat = &ec->m_cat;
  ec->m_cat = v9;
  if ( !v7 )
    goto LABEL_14;
  if ( ec->m_cat == boost::system::system_category() && ec->m_val == 11
    || ec->m_cat == boost::system::system_category() && ec->m_val == 11 )
  {
    v15 = 0;
    ioctl(s, 0x5421u, &v15);
    *v16 &= 0xFCu;
    *v6 = 0;
    v7 = close(s);
    v11 = *v6;
    v12 = boost::system::system_category();
    ec->m_val = v11;
    ec->m_cat = v12;
    if ( !v7 )
      goto LABEL_14;
  }
  return v7;
}


// Address: 0x26047e0 | Name: _ZN5boost4asio6detail10socket_ops9inet_ntopEiPKvPcmmRNS_6system10error_codeE
const char *__fastcall boost::asio::detail::socket_ops::inet_ntop(
        int af_0,
        const void *src,
        char *dest,
        size_t length,
        unsigned __int64 scope_id,
        boost::system::error_code *ec)
{
  socklen_t v7; // r12d
  int *v9; // r15
  const char *v10; // r12
  int v11; // ebx
  const boost::system::error_category *v12; // rax
  bool v13; // cl
  const boost::system::error_category *v14; // rax
  bool v15; // al
  char *v17; // [rsp+0h] [rbp-68h]
  char ifname[16]; // [rsp+10h] [rbp-58h] BYREF
  char v20; // [rsp+20h] [rbp-48h]
  unsigned __int64 v21; // [rsp+30h] [rbp-38h]

  v7 = length;
  v21 = __readfsqword(0x28u);
  v9 = __errno_location();
  *v9 = 0;
  v17 = dest;
  v10 = inet_ntop(af_0, src, dest, v7);
  v11 = *v9;
  v12 = boost::system::system_category();
  ec->m_val = v11;
  ec->m_cat = v12;
  if ( v10 )
  {
    if ( af_0 == 10 && scope_id )
    {
      *(_OWORD *)ifname = xmmword_5D7E90;
      v20 = 0;
      if ( *(_BYTE *)src == 0xFF )
      {
        v15 = (*((_BYTE *)src + 1) & 0xF) == 2;
      }
      else
      {
        v13 = *(_BYTE *)src == 0xFE && (*((_BYTE *)src + 1) & 0xC0) == 0x80;
        v15 = 0;
        if ( v13 )
        {
LABEL_14:
          if ( if_indextoname(scope_id, &ifname[1]) )
          {
LABEL_16:
            __strcat_chk(v17, ifname, -1);
            return v10;
          }
LABEL_15:
          sprintf(&ifname[1], "%lu", scope_id);
          goto LABEL_16;
        }
      }
      if ( !v15 )
        goto LABEL_15;
      goto LABEL_14;
    }
  }
  else if ( !v11 )
  {
    v14 = boost::system::system_category();
    ec->m_val = 22;
    ec->m_cat = v14;
  }
  return v10;
}


// Address: 0x260a4d0 | Name: _ZN5boost4asio6detail10socket_ops17non_blocking_recvEiP5iovecmibRNS_6system10error_codeERm
char __fastcall boost::asio::detail::socket_ops::non_blocking_recv(
        boost::asio::detail::socket_type s,
        boost::asio::detail::socket_ops::buf *bufs,
        size_t count,
        int flags,
        bool is_stream,
        boost::system::error_code *ec,
        size_t *bytes_transferred)
{
  int v8; // r14d
  int *v9; // r15
  size_t v10; // r12
  ssize_t v11; // r14
  int v12; // r13d
  const boost::system::error_category *v13; // rax
  const boost::system::error_category *v14; // rax
  const boost::system::error_category *v16; // rax
  struct msghdr message; // [rsp+10h] [rbp-68h] BYREF

  v8 = count;
  v9 = __errno_location();
  v10 = v8;
  do
  {
    *v9 = 0;
    memset(&message.msg_control, 0, 24);
    *(_OWORD *)&message.msg_name = 0;
    message.msg_iov = bufs;
    message.msg_iovlen = v10;
    v11 = recvmsg(s, &message, flags);
    v12 = *v9;
    v13 = boost::system::system_category();
    ec->m_val = v12;
    ec->m_cat = v13;
    if ( v11 >= 0 )
    {
      v14 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v14;
      if ( !v11 && is_stream )
      {
        if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
          __cxa_guard_release(&byte_2B114E0);
        ec->m_val = 2;
        ec->m_cat = (const boost::system::error_category *)off_2870A08;
        return 1;
      }
    }
  }
  while ( ec->m_cat == boost::system::system_category() && ec->m_val == 4 );
  if ( ec->m_cat == boost::system::system_category() && ec->m_val == 11
    || ec->m_cat == boost::system::system_category() && ec->m_val == 11 )
  {
    return 0;
  }
  if ( v11 < 0 )
  {
    v11 = 0;
  }
  else
  {
    v16 = boost::system::system_category();
    ec->m_val = 0;
    ec->m_cat = v16;
  }
  *bytes_transferred = v11;
  return 1;
}


// Address: 0x260b2b0 | Name: _ZN5boost4asio6detail10socket_ops17non_blocking_sendEiPK5iovecmiRNS_6system10error_codeERm
bool __fastcall boost::asio::detail::socket_ops::non_blocking_send(
        boost::asio::detail::socket_type s,
        const boost::asio::detail::socket_ops::buf *bufs,
        size_t count,
        int flags,
        boost::system::error_code *ec,
        size_t *bytes_transferred)
{
  int v8; // r15d
  int *v9; // r14
  size_t v10; // r12
  int v11; // ebp
  ssize_t v12; // r15
  int v13; // r13d
  const boost::system::error_category *v14; // rax
  const boost::system::error_category *v15; // rax
  const boost::system::error_category *v17; // rax
  struct msghdr message; // [rsp+20h] [rbp-68h] BYREF

  v8 = count;
  v9 = __errno_location();
  v10 = v8;
  v11 = flags | 0x4000;
  do
  {
    *v9 = 0;
    memset(&message.msg_control, 0, 24);
    *(_OWORD *)&message.msg_name = 0;
    message.msg_iov = (iovec *)bufs;
    message.msg_iovlen = v10;
    v12 = sendmsg(s, &message, v11);
    v13 = *v9;
    v14 = boost::system::system_category();
    ec->m_val = v13;
    ec->m_cat = v14;
    if ( v12 >= 0 )
    {
      v15 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v15;
    }
  }
  while ( ec->m_cat == boost::system::system_category() && ec->m_val == 4 );
  if ( ec->m_cat == boost::system::system_category() && ec->m_val == 11
    || ec->m_cat == boost::system::system_category() && ec->m_val == 11 )
  {
    return 0;
  }
  if ( v12 < 0 )
  {
    v12 = 0;
  }
  else
  {
    v17 = boost::system::system_category();
    ec->m_val = 0;
    ec->m_cat = v17;
  }
  *bytes_transferred = v12;
  return 1;
}


// Address: 0x2620df0 | Name: _ZN5boost4asio6detail10socket_ops24translate_addrinfo_errorEi
boost::system::error_code __fastcall boost::asio::detail::socket_ops::translate_addrinfo_error(int error)
{
  char v1; // al
  int v2; // ebp
  char v3; // al
  void (__fastcall ***v4)(boost::system::error_category *__hidden); // rbx
  boost::system::error_code result; // 0:eax.4,8:rdx.8

  switch ( error )
  {
    case -10:
      v2 = 12;
      goto LABEL_18;
    case -9:
    case -5:
    case -2:
      v1 = byte_2B114D0;
      v2 = 1;
      goto LABEL_13;
    case -8:
      v3 = byte_2B114D8;
      v2 = -8;
      goto LABEL_7;
    case -7:
      v3 = byte_2B114D8;
      v2 = -7;
LABEL_7:
      v4 = off_2870A00;
      if ( !v3 && __cxa_guard_acquire(&byte_2B114D8) )
        __cxa_guard_release(&byte_2B114D8);
      goto LABEL_19;
    case -6:
      v2 = 97;
      goto LABEL_18;
    case -4:
      v1 = byte_2B114D0;
      v2 = 3;
      goto LABEL_13;
    case -3:
      v1 = byte_2B114D0;
      v2 = 2;
LABEL_13:
      v4 = off_28709F8;
      if ( !v1 && __cxa_guard_acquire(&byte_2B114D0) )
        __cxa_guard_release(&byte_2B114D0);
      goto LABEL_19;
    case -1:
      v2 = 22;
      goto LABEL_18;
    case 0:
      v2 = 0;
      goto LABEL_18;
    default:
      v2 = *__errno_location();
LABEL_18:
      v4 = (void (__fastcall ***)(boost::system::error_category *__hidden))boost::system::system_category();
LABEL_19:
      result.m_val = v2;
      result.m_cat = (const boost::system::error_category *)v4;
      return result;
  }
}


// Address: 0x2626340 | Name: _ZN5boost4asio6detail10socket_ops20non_blocking_connectEiRNS_6system10error_codeE
bool __fastcall boost::asio::detail::socket_ops::non_blocking_connect(
        boost::asio::detail::socket_type s,
        boost::system::error_code *ec)
{
  bool v2; // bl
  int *v3; // rbx
  int v4; // ebp
  const boost::system::error_category *v5; // rax
  const boost::system::error_category *v6; // rax
  int v7; // ebx
  const boost::system::error_category *v8; // rax
  int v10; // [rsp+0h] [rbp-28h] BYREF
  socklen_t optlen; // [rsp+4h] [rbp-24h] BYREF
  struct pollfd fds; // [rsp+8h] [rbp-20h] BYREF

  fds.fd = s;
  *(_DWORD *)&fds.events = 4;
  v2 = 0;
  if ( poll(&fds, 1u, 0) )
  {
    v10 = 0;
    if ( s == -1 )
    {
      v8 = boost::system::system_category();
      ec->m_val = 9;
    }
    else
    {
      v3 = __errno_location();
      *v3 = 0;
      optlen = 4;
      v4 = getsockopt(s, 1, 4, &v10, &optlen);
      LODWORD(v3) = *v3;
      v5 = boost::system::system_category();
      ec->m_val = (int)v3;
      ec->m_cat = v5;
      if ( v4 )
        return 1;
      v6 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v6;
      v7 = v10;
      v8 = boost::system::system_category();
      if ( v7 )
        ec->m_val = v7;
      else
        ec->m_val = 0;
    }
    ec->m_cat = v8;
    return 1;
  }
  return v2;
}


