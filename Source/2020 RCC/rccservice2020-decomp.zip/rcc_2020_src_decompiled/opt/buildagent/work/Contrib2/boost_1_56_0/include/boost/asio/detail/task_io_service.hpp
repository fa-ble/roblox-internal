// Address: 0x25f95b0 | Name: _ZN5boost4asio6detail15task_io_serviceD2Ev
void __fastcall boost::asio::detail::task_io_service::~task_io_service(boost::asio::detail::task_io_service_0 *this)
{
  boost::asio::detail::task_io_service_operation *i; // rbx
  boost::asio::detail::task_io_service_operation *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v4; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v5; // [rsp+10h] [rbp-28h]

  this->_vptr$service = (int (**)(void))off_29C2B60;
  for ( i = this->op_queue_.front_; i; i = this->op_queue_.front_ )
  {
    next = i->next_;
    this->op_queue_.front_ = i->next_;
    if ( !next )
      this->op_queue_.back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v4 = 0;
    v5 = boost::system::system_category();
    func(0, i, &v4, 0);
  }
  pthread_cond_destroy(&this->wakeup_event_.cond_);
  pthread_mutex_destroy(&this->mutex_.mutex_);
}


// Address: 0x25f9660 | Name: _ZN5boost4asio6detail15task_io_serviceD0Ev
void __fastcall boost::asio::detail::task_io_service::~task_io_service(boost::asio::detail::task_io_service_0 *this)
{
  boost::asio::detail::task_io_service_operation *i; // rbx
  boost::asio::detail::task_io_service_operation *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v4; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v5; // [rsp+10h] [rbp-28h]

  this->_vptr$service = (int (**)(void))off_29C2B60;
  for ( i = this->op_queue_.front_; i; i = this->op_queue_.front_ )
  {
    next = i->next_;
    this->op_queue_.front_ = i->next_;
    if ( !next )
      this->op_queue_.back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v4 = 0;
    v5 = boost::system::system_category();
    func(0, i, &v4, 0);
  }
  pthread_cond_destroy(&this->wakeup_event_.cond_);
  pthread_mutex_destroy(&this->mutex_.mutex_);
  operator delete(this);
}


