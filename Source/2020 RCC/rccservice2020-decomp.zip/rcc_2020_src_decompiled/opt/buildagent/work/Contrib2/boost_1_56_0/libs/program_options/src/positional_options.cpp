// Address: 0xe62c20 | Name: _ZN5boost15program_options30positional_options_description3addEPKci
boost::program_options::positional_options_description *__fastcall boost::program_options::positional_options_description::add(
        boost::program_options::positional_options_description *this,
        const char *name,
        int max_count)
{
  boost::program_options::positional_options_description *v3; // r14
  std::vector<std::string>::size_type v4; // rbp
  __int64 v5; // r13
  __int64 v6; // r12
  size_t v7; // rax
  size_t v8; // rbx
  unsigned __int64 v9; // r14
  char *v10; // r13
  bool v11; // cf
  __int64 v12; // rbx
  __int64 v13; // rbp
  struct _Unwind_Exception *v15; // rbx
  __int128 dest; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+10h] [rbp-58h]
  std::vector<std::string> *v18; // [rsp+18h] [rbp-50h]
  __int64 v19; // [rsp+20h] [rbp-48h]
  __int64 v20; // [rsp+28h] [rbp-40h]
  unsigned __int64 v21; // [rsp+30h] [rbp-38h]

  v3 = this;
  if ( max_count == -1 )
  {
    std::string::assign((char *)this + 24, name);
    return v3;
  }
  LODWORD(v4) = max_count;
  v5 = *(_QWORD *)this;
  v6 = *((_QWORD *)this + 1);
  dest = 0;
  ptr = 0;
  v7 = strlen(name);
  if ( v7 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v15 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(&dest);
    if ( (dest & 1) != 0 )
      operator delete(ptr);
    _Unwind_Resume(v15);
  }
  v8 = v7;
  v18 = this;
  v20 = v5;
  v9 = 0xAAAAAAAAAAAAAAABLL * ((v6 - v5) >> 3);
  v4 = (int)v4;
  v21 = v9 + (int)v4;
  if ( v7 >= 0x17 )
  {
    v19 = (int)v4;
    v10 = (char *)operator new((v7 + 16) & 0xFFFFFFFFFFFFFFF0LL);
    ptr = v10;
    *(_QWORD *)&dest = (v8 + 16) & 0xFFFFFFFFFFFFFFF0LL | 1;
    v4 = (int)v4;
    *((_QWORD *)&dest + 1) = v8;
  }
  else
  {
    LOBYTE(dest) = 2 * v7;
    v10 = (char *)&dest + 1;
    if ( !v7 )
      goto LABEL_9;
  }
  memcpy(v10, name, v8);
LABEL_9:
  v10[v8] = 0;
  v11 = v21 < v9;
  if ( v21 <= v9 )
  {
    v3 = v18;
    if ( v11 )
    {
      v12 = v20 + 24 * v21;
      if ( v12 != v6 )
      {
        do
        {
          v13 = v6 - 24;
          if ( (*(_BYTE *)(v6 - 24) & 1) != 0 )
            operator delete(*(void **)(v6 - 8));
          v6 -= 24;
        }
        while ( v12 != v13 );
      }
      *((_QWORD *)v3 + 1) = v12;
    }
  }
  else
  {
    v3 = v18;
    std::vector<std::string>::__append(v18, v4, (std::vector<std::string>::const_reference)&dest);
  }
  if ( (dest & 1) != 0 )
    operator delete(ptr);
  return v3;
}


// Address: 0xe62de0 | Name: _ZNK5boost15program_options30positional_options_description17name_for_positionEj
const std::string *__fastcall boost::program_options::positional_options_description::name_for_position(
        const boost::program_options::positional_options_description *this,
        unsigned int position)
{
  const std::string *result; // rax

  result = (const std::string *)(*(_QWORD *)this + 24LL * position);
  if ( 0xAAAAAAAAAAAAAAABLL * ((__int64)(*((_QWORD *)this + 1) - *(_QWORD *)this) >> 3) <= position )
    return (const boost::program_options::positional_options_description *)((char *)this + 24);
  return result;
}


