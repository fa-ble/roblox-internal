// Address: 0x25f80e0 | Name: _ZN5boost4asio6detail26eventfd_select_interrupterD2Ev
void __fastcall boost::asio::detail::eventfd_select_interrupter::~eventfd_select_interrupter(
        boost::asio::detail::eventfd_select_interrupter *this)
{
  int write_descriptor; // edi

  write_descriptor = this->write_descriptor_;
  if ( write_descriptor == -1 )
  {
LABEL_4:
    write_descriptor = this->read_descriptor_;
    if ( this->read_descriptor_ == -1 )
      return;
    goto LABEL_5;
  }
  if ( write_descriptor != this->read_descriptor_ )
  {
    close(write_descriptor);
    goto LABEL_4;
  }
LABEL_5:
  close(write_descriptor);
}


// Address: 0x25f8800 | Name: _ZN5boost4asio6detail26eventfd_select_interrupter16open_descriptorsEv
void __fastcall boost::asio::detail::eventfd_select_interrupter::open_descriptors(
        boost::asio::detail::eventfd_select_interrupter *this)
{
  int v2; // eax
  int *v3; // r14
  int v4; // eax
  int v5; // ebp
  const boost::system::error_category *v6; // rax
  const boost::system::error_category *v7; // rbx
  int v8; // edi
  int v9; // edi
  int pipedes[2]; // [rsp+8h] [rbp-60h] BYREF
  _QWORD v11[2]; // [rsp+10h] [rbp-58h] BYREF
  int v12; // [rsp+20h] [rbp-48h]
  const boost::system::error_category *v13; // [rsp+28h] [rbp-40h]
  __int128 v14; // [rsp+30h] [rbp-38h]
  __int64 v15; // [rsp+40h] [rbp-28h]

  v2 = eventfd(0, 526336);
  this->read_descriptor_ = v2;
  this->write_descriptor_ = v2;
  if ( v2 == -1 )
  {
    v3 = __errno_location();
    if ( *v3 != 22
      || (v4 = eventfd(0, 0), this->read_descriptor_ = v4, this->write_descriptor_ = v4, v4 == -1)
      || (fcntl(v4, 4, 2048), fcntl(this->read_descriptor_, 2, 1), this->read_descriptor_ == -1) )
    {
      if ( pipe(pipedes) )
      {
        v5 = *v3;
        v6 = boost::system::system_category();
        if ( v5 )
        {
          v7 = v6;
          std::runtime_error::runtime_error((std::runtime_error *)v11, "eventfd_select_interrupter");
          v11[0] = off_2875F00;
          v12 = v5;
          v13 = v7;
          v14 = 0;
          v15 = 0;
          boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v11);
        }
      }
      else
      {
        v8 = pipedes[0];
        this->read_descriptor_ = pipedes[0];
        fcntl(v8, 4, 2048);
        fcntl(this->read_descriptor_, 2, 1);
        v9 = pipedes[1];
        this->write_descriptor_ = pipedes[1];
        fcntl(v9, 4, 2048);
        fcntl(this->write_descriptor_, 2, 1);
      }
    }
  }
}


