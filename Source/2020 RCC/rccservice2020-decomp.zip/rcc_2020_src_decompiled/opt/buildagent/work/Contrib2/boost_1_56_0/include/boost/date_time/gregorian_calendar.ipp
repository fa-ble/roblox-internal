// Address: 0x15dea00 | Name: _ZN5boost9date_time23gregorian_calendar_baseINS0_19year_month_day_baseINS_9gregorian9greg_yearENS3_10greg_monthENS3_8greg_dayEEEjE15from_day_numberEj
boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::ymd_type __fastcall boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::from_day_number(
        boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::date_int_type dayNumber)
{
  boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::date_int_type v1; // r8d
  boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::date_int_type v2; // ebx
  unsigned int v3; // ecx
  boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::date_int_type v4; // ebx
  unsigned int v5; // esi
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,31,boost::gregorian::bad_day_of_month> > v7; // [rsp+8h] [rbp-30h] BYREF
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,12,boost::gregorian::bad_month> > v8; // [rsp+10h] [rbp-28h] BYREF
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1400,10000,boost::gregorian::bad_year> > v9; // [rsp+18h] [rbp-20h] BYREF
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1400,10000,boost::gregorian::bad_year> > v10; // [rsp+20h] [rbp-18h] BYREF

  v1 = (4 * dayNumber + 128179) / 0x23AB1;
  v2 = dayNumber + 32044 - ((146097 * v1) >> 2);
  v3 = (4 * v2 + 3) / 0x5B5;
  v4 = v2 - ((1461 * v3) >> 2);
  v5 = 5 * v4 + 2;
  v10.value_ = 1400;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1400,(unsigned short)10000,boost::gregorian::bad_year>>::assign(
    &v10,
    v5 / 0x5FA + v3 + 100 * v1 - 4800);
  v9.value_ = 1400;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1400,(unsigned short)10000,boost::gregorian::bad_year>>::assign(
    &v9,
    v10.value_);
  v8.value_ = 1;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)12,boost::gregorian::bad_month>>::assign(
    &v8,
    v5 / 0x99 - 12 * (v5 / 0x5FA) + 3);
  v7.value_ = 1;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)31,boost::gregorian::bad_day_of_month>>::assign(
    &v7,
    v4 - (153 * (v5 / 0x99) + 2) / 5 + 1);
  return (boost::date_time::gregorian_calendar_base<boost::date_time::year_month_day_base<boost::gregorian::greg_year,boost::gregorian::greg_month,boost::gregorian::greg_day>,unsigned int>::ymd_type)(((unsigned __int64)v7.value_ << 32) | v9.value_ | ((unsigned __int64)v8.value_ << 16));
}


