// Address: 0x25f51d0 | Name: _ZNK5boost4asio3ssl20rfc2818_verificationclEbRNS1_14verify_contextE
bool __fastcall boost::asio::ssl::rfc2818_verification::operator()(
        const boost::asio::ssl::rfc2818_verification *this,
        bool preverified,
        boost::asio::ssl::verify_context *ctx)
{
  int error_depth; // ecx
  bool result; // al
  const char *v7; // r12
  int v8; // eax
  unsigned int v9; // ecx
  bool v10; // al
  int *v11; // rbp
  int v12; // r12d
  int v13; // ebp
  const boost::system::error_category *v14; // rax
  const boost::system::error_category *v15; // rax
  __int64 current_cert; // r12
  int v17; // ebx
  __int64 ext_d2i; // r13
  __int64 v19; // rax
  int v20; // ecx
  int *v21; // rax
  const char *v22; // rdi
  const char *v23; // rdx
  int *v24; // rcx
  const __m128i *v25; // rax
  int v26; // ecx
  __int64 subject_name; // r12
  int index_by_NID; // eax
  int i; // ebp
  __int64 entry; // rax
  int *data; // rbx
  const char *v32; // rdi
  bool matched; // cl
  __int32 v34; // [rsp+0h] [rbp-88h]
  int v35; // [rsp+4h] [rbp-84h]
  char *host; // [rsp+8h] [rbp-80h]
  boost::system::error_code ec; // [rsp+10h] [rbp-78h] BYREF
  __m128i dest; // [rsp+20h] [rbp-68h] BYREF
  unsigned __int64 scope_id; // [rsp+30h] [rbp-58h] BYREF
  __m128i v40[4]; // [rsp+40h] [rbp-48h] BYREF

  if ( !preverified )
    return 0;
  error_depth = X509_STORE_CTX_get_error_depth(ctx->handle_);
  result = 1;
  if ( error_depth > 0 )
    return result;
  ec.m_val = 0;
  ec.m_cat = boost::system::system_category();
  v7 = (char *)this + 1;
  host = (char *)this + 1;
  if ( (*(_BYTE *)this & 1) != 0 )
    v7 = (const char *)*((_QWORD *)this + 2);
  dest = 0;
  scope_id = 0;
  v8 = boost::asio::detail::socket_ops::inet_pton(10, v7, &dest, &scope_id, &ec);
  v9 = 0;
  v10 = v8 <= 0;
  if ( !ec.m_val )
  {
    LOBYTE(v9) = v10;
    v40[0] = _mm_andnot_si128(
               _mm_shuffle_epi32(
                 _mm_srai_epi32(_mm_slli_epi64(_mm_shuffle_epi32(_mm_cvtsi32_si128(v9), 68), 0x3Fu), 0x1Fu),
                 245),
               dest);
    v35 = 1;
    v13 = 0;
LABEL_14:
    v34 = 0;
    goto LABEL_15;
  }
  dest.m128i_i32[0] = 0;
  v11 = __errno_location();
  *v11 = 0;
  v12 = inet_pton(2, v7, &dest);
  v13 = *v11;
  v14 = boost::system::system_category();
  ec.m_val = v13;
  ec.m_cat = v14;
  if ( v12 <= 0 )
  {
    if ( v13 )
    {
      v40[0] = 0;
      v35 = 0;
    }
    else
    {
      v15 = boost::system::system_category();
      ec.m_val = 22;
      ec.m_cat = v15;
      v40[0] = 0;
      v35 = 0;
      v13 = 22;
    }
    goto LABEL_14;
  }
  v35 = 0;
  v34 = 0;
  if ( !v13 )
    v34 = dest.m128i_i32[0];
  v40[0] = 0;
LABEL_15:
  current_cert = X509_STORE_CTX_get_current_cert(ctx->handle_);
  v17 = 0;
  ext_d2i = X509_get_ext_d2i(current_cert, 85, 0, 0);
  if ( (int)OPENSSL_sk_num(ext_d2i) > 0 )
  {
    do
    {
      v19 = OPENSSL_sk_value(ext_d2i, (unsigned int)v17);
      v20 = *(_DWORD *)v19;
      if ( v13 && v20 == 2 )
      {
        v21 = *(int **)(v19 + 8);
        if ( v21[1] == 22 )
        {
          v22 = (const char *)*((_QWORD *)v21 + 1);
          if ( v22 )
          {
            if ( *v21 )
            {
              v23 = host;
              if ( (*(_BYTE *)this & 1) != 0 )
                v23 = (const char *)*((_QWORD *)this + 2);
              if ( boost::asio::ssl::rfc2818_verification::match_pattern(v22, *v21, v23) )
              {
LABEL_46:
                GENERAL_NAMES_free(ext_d2i);
                return 1;
              }
            }
          }
        }
      }
      else if ( v13 == 0 && v20 == 7 )
      {
        v24 = *(int **)(v19 + 8);
        if ( v24[1] == 4 )
        {
          v25 = (const __m128i *)*((_QWORD *)v24 + 1);
          if ( v25 )
          {
            v26 = *v24;
            if ( v35 )
            {
              if ( v26 == 16 )
              {
                dest = _mm_load_si128(v40);
                if ( _mm_movemask_epi8(_mm_cmpeq_epi8(_mm_loadu_si128(v25), dest)) == 0xFFFF )
                  goto LABEL_46;
              }
            }
            else if ( v26 == 4 )
            {
              dest.m128i_i32[0] = v34;
              if ( v34 == v25->m128i_i32[0] )
                goto LABEL_46;
            }
          }
        }
      }
      ++v17;
    }
    while ( v17 < (int)OPENSSL_sk_num(ext_d2i) );
  }
  GENERAL_NAMES_free(ext_d2i);
  subject_name = X509_get_subject_name(current_cert);
  index_by_NID = X509_NAME_get_index_by_NID(subject_name, 13, 0xFFFFFFFFLL);
  if ( index_by_NID < 0 )
    return 0;
  for ( i = index_by_NID; i >= 0; i = X509_NAME_get_index_by_NID(subject_name, 13, (unsigned int)i) )
  {
    entry = X509_NAME_get_entry(subject_name, (unsigned int)i);
    data = (int *)X509_NAME_ENTRY_get_data(entry);
  }
  if ( !data )
    return 0;
  v32 = (const char *)*((_QWORD *)data + 1);
  if ( !v32 || !*data )
    return 0;
  if ( (*(_BYTE *)this & 1) != 0 )
    host = (char *)*((_QWORD *)this + 2);
  matched = boost::asio::ssl::rfc2818_verification::match_pattern(v32, *data, host);
  result = 1;
  if ( !matched )
    return 0;
  return result;
}


// Address: 0x25f5510 | Name: _ZN5boost4asio3ssl20rfc2818_verification13match_patternEPKcmS4_
bool __fastcall boost::asio::ssl::rfc2818_verification::match_pattern(
        const char *pattern,
        size_t pattern_length,
        const char *host)
{
  char v3; // bp
  bool result; // al
  const char *v5; // rbx
  const char *v6; // r15
  const char *v7; // r14
  __int32_t v8; // r12d
  __int32_t v9; // eax

  v3 = *host;
  result = pattern_length == 0 && *host == 0;
  if ( pattern_length && v3 )
  {
    v5 = host;
    v6 = pattern;
    v7 = &pattern[pattern_length];
    while ( 1 )
    {
      v8 = *v6;
      if ( v8 == 42 )
      {
        ++v6;
        while ( v3 != 46 )
        {
          if ( boost::asio::ssl::rfc2818_verification::match_pattern(v6, v7 - v6, v5) )
            return 1;
          v3 = *++v5;
          if ( !v3 )
            break;
        }
      }
      else
      {
        if ( (unsigned int)(v8 + 128) <= 0x17F )
          v8 = (*__ctype_tolower_loc())[v8];
        v9 = v3;
        if ( (unsigned int)(v3 + 128) <= 0x17F )
          v9 = (*__ctype_tolower_loc())[v3];
        if ( v8 != v9 )
          return 0;
        ++v6;
        v3 = *++v5;
      }
      if ( v6 == v7 || !v3 )
        return v3 == 0 && v6 == v7;
    }
  }
  return result;
}


