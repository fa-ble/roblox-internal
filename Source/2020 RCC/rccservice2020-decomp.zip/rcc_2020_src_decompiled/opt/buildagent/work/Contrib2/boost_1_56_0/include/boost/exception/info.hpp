// Address: 0xdc12d0 | Name: _ZN5boost16exception_detail8set_infoINS_17unknown_exceptionENS_27tag_original_exception_typeEPKSt9type_infoEERKT_S9_RKNS_10error_infoIT0_T1_EE
const boost::unknown_exception *__fastcall boost::exception_detail::set_info<boost::unknown_exception,boost::tag_original_exception_type,std::type_info const*>(
        const boost::unknown_exception *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 1);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 1) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc14b0 | Name: _ZNK5boost10error_infoINS_27tag_original_exception_typeEPKSt9type_infoE17name_value_stringEv
boost::core *__fastcall boost::error_info<boost::tag_original_exception_type,std::type_info const*>::name_value_string(
        boost::core *a1,
        __int64 a2)
{
  boost::core::demangle(a1, *(const char **)(*(_QWORD *)(a2 + 8) + 8LL));
  return a1;
}


// Address: 0xdc14d0 | Name: j__ZdlPv_8
// attributes: thunk
void __fastcall operator delete(boost::error_info<boost::tag_original_exception_type,const std::type_info *> *this)
{
  _ZdlPv(this);
}


// Address: 0xdc1870 | Name: _ZNK5boost16exception_detail25error_info_container_impl22diagnostic_informationEPKc
const char *__fastcall boost::exception_detail::error_info_container_impl::diagnostic_information(
        const boost::exception_detail::error_info_container_impl *this,
        const char *header)
{
  size_t v2; // rax
  const boost::exception_detail::error_info_container_impl *v3; // r15
  const char *v4; // rsi
  size_t v5; // rdx
  const boost::exception_detail::error_info_container_impl *v6; // rcx
  const boost::exception_detail::error_info_container_impl *v7; // rax
  __int64 v8; // r15
  bool v9; // zf
  __int128 v10; // xmm0
  char *v11; // rbx
  char __str[16]; // [rsp+0h] [rbp-178h] BYREF
  void *ptr; // [rsp+10h] [rbp-168h]
  __int128 v16; // [rsp+20h] [rbp-158h] BYREF
  void *v17; // [rsp+30h] [rbp-148h]
  __int64 (__fastcall **v18)(); // [rsp+40h] [rbp-138h] BYREF
  _QWORD v19[8]; // [rsp+48h] [rbp-130h] BYREF
  __int128 v20; // [rsp+88h] [rbp-F0h]
  void *v21[2]; // [rsp+98h] [rbp-E0h]
  int v22; // [rsp+A8h] [rbp-D0h]
  _QWORD v23[18]; // [rsp+B0h] [rbp-C8h] BYREF
  int v24; // [rsp+140h] [rbp-38h]

  if ( header )
  {
    v23[0] = &off_2876B60;
    std::ios_base::init((std::ios_base *)v23, v19);
    v23[17] = 0;
    v24 = -1;
    v18 = &off_2876AC8;
    v23[0] = off_2876AF0;
    std::streambuf::basic_streambuf(v19);
    v19[0] = &off_28753A8;
    *(_OWORD *)v21 = 0;
    v20 = 0;
    v22 = 16;
    v2 = strlen(header);
    std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v18, header, v2);
    v3 = (const boost::exception_detail::error_info_container_impl *)*((_QWORD *)this + 1);
    if ( v3 != (const boost::exception_detail::error_info_container_impl *)((char *)this + 16) )
    {
      do
      {
        (***((void (__fastcall ****)(char *))v3 + 5))(__str);
        if ( (__str[0] & 1) != 0 )
        {
          v4 = (const char *)ptr;
          v5 = *(_QWORD *)&__str[8];
        }
        else
        {
          v5 = (unsigned __int64)(unsigned __int8)__str[0] >> 1;
          v4 = &__str[1];
        }
        std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v18, v4, v5);
        if ( (__str[0] & 1) != 0 )
          operator delete(ptr);
        v6 = (const boost::exception_detail::error_info_container_impl *)*((_QWORD *)v3 + 1);
        if ( v6 )
        {
          do
          {
            v7 = v6;
            v6 = *(const boost::exception_detail::error_info_container_impl **)v6;
          }
          while ( v6 );
        }
        else
        {
          v7 = (const boost::exception_detail::error_info_container_impl *)*((_QWORD *)v3 + 2);
          if ( *(const boost::exception_detail::error_info_container_impl **)v7 != v3 )
          {
            v8 = (__int64)v3 + 16;
            do
            {
              v7 = *(const boost::exception_detail::error_info_container_impl **)(*(_QWORD *)v8 + 16LL);
              v9 = *(_QWORD *)v7 == *(_QWORD *)v8;
              v8 = *(_QWORD *)v8 + 16LL;
            }
            while ( !v9 );
          }
        }
        v3 = v7;
      }
      while ( v7 != (const boost::exception_detail::error_info_container_impl *)((char *)this + 16) );
    }
    std::stringbuf::str((__int64)&v16, (__int64)v19);
    ptr = v17;
    v10 = v16;
    *(_OWORD *)__str = v16;
    v17 = (void *)*((_QWORD *)this + 6);
    v16 = *((_OWORD *)this + 2);
    *((_QWORD *)this + 6) = ptr;
    *((_OWORD *)this + 2) = v10;
    if ( (v16 & 1) != 0 )
      operator delete(v17);
    v11 = (char *)this + 32;
    v18 = &off_2876AC8;
    v23[0] = off_2876AF0;
    v19[0] = &off_28753A8;
    if ( (v20 & 1) != 0 )
      operator delete(v21[0]);
    std::streambuf::~streambuf(v19);
    std::ostream::~ostream(&v18, data);
    std::ios::~ios(v23);
    if ( (*v11 & 1) == 0 )
      return v11 + 1;
    return (const char *)*((_QWORD *)this + 6);
  }
  v11 = (char *)this + 32;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    return (const char *)*((_QWORD *)this + 6);
  return v11 + 1;
}


// Address: 0xdc1bf0 | Name: _ZN5boost16exception_detail25error_info_container_impl3setERKNS_10shared_ptrINS0_15error_info_baseEEERKNS0_10type_info_E
void __fastcall boost::exception_detail::error_info_container_impl::set(
        boost::exception_detail::error_info_container_impl *this,
        const boost::shared_ptr<boost::exception_detail::error_info_base> *x,
        const boost::exception_detail::type_info_ *typeid_)
{
  void **v5; // rbx
  void **v6; // rbp
  unsigned __int64 v7; // rax
  unsigned __int64 v8; // rcx
  void **v9; // rcx
  char *v10; // r13
  __int64 v11; // rax
  std::__tree_node_base<void *> *v12; // rsi
  boost::shared_ptr<boost::exception_detail::error_info_base>::element_type *px; // rcx
  boost::detail::sp_counted_base *pi; // rax
  volatile signed __int32 *v15; // r14

  v5 = (void **)*((_QWORD *)this + 2);
  if ( v5 )
  {
    v6 = (void **)((char *)this + 16);
    v7 = *((_QWORD *)typeid_->type_ + 1);
    while ( 1 )
    {
      v8 = *((_QWORD *)v5[4] + 1);
      if ( v7 >= v8 )
      {
        if ( v8 >= v7 )
          goto LABEL_12;
        v6 = v5 + 1;
        v9 = (void **)v5[1];
        if ( !v9 )
          goto LABEL_12;
      }
      else
      {
        v9 = (void **)*v5;
        v6 = v5;
        if ( !*v5 )
          goto LABEL_11;
      }
      v5 = v9;
    }
  }
  v5 = (void **)((char *)this + 16);
LABEL_11:
  v6 = v5;
LABEL_12:
  v10 = (char *)*v6;
  if ( !*v6 )
  {
    v10 = (char *)operator new(0x38u);
    *((boost::exception_detail::type_info_ *)v10 + 4) = (boost::exception_detail::type_info_)typeid_->type_;
    *(_OWORD *)(v10 + 40) = 0;
    *(_OWORD *)v10 = 0;
    *((_QWORD *)v10 + 2) = v5;
    *v6 = v10;
    v11 = **((_QWORD **)this + 1);
    if ( v11 )
    {
      *((_QWORD *)this + 1) = v11;
      v12 = (std::__tree_node_base<void *> *)*v6;
    }
    else
    {
      v12 = (std::__tree_node_base<void *> *)v10;
    }
    std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(
      *((std::__tree_node_base<void *> **)this + 2),
      v12);
    ++*((_QWORD *)this + 3);
  }
  px = x->px;
  pi = x->pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  *((_QWORD *)v10 + 5) = px;
  v15 = (volatile signed __int32 *)*((_QWORD *)v10 + 6);
  *((_QWORD *)v10 + 6) = pi;
  if ( v15 )
  {
    if ( !_InterlockedSub(v15 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
  {
    **((_BYTE **)this + 6) = 0;
    *((_QWORD *)this + 5) = 0;
  }
  else
  {
    *((_WORD *)this + 16) = 0;
  }
}


// Address: 0xdc1d40 | Name: _ZNK5boost16exception_detail25error_info_container_impl7add_refEv
void __fastcall boost::exception_detail::error_info_container_impl::add_ref(
        const boost::exception_detail::error_info_container_impl *this)
{
  ++*((_DWORD *)this + 14);
}


// Address: 0xdc1d50 | Name: _ZNK5boost16exception_detail25error_info_container_impl7releaseEv
bool __fastcall boost::exception_detail::error_info_container_impl::release(
        const boost::exception_detail::error_info_container_impl *this)
{
  if ( (*((_DWORD *)this + 14))-- != 1 )
    return 0;
  *(_QWORD *)this = &off_2876BF8;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::__tree<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base>>,std::__map_value_compare<boost::exception_detail::type_info_,std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base>>,std::less<boost::exception_detail::type_info_>,true>,std::allocator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base>>>>::destroy(
    (std::__tree<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__map_value_compare<boost::exception_detail::type_info_,std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::less<boost::exception_detail::type_info_>,true>,std::allocator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> > > > *)((char *)this + 8),
    *((std::__tree<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__map_value_compare<boost::exception_detail::type_info_,std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::less<boost::exception_detail::type_info_>,true>,std::allocator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> > > >::__node_pointer *)this
    + 2));
  operator delete(this);
  return 1;
}


// Address: 0xdc1d90 | Name: _ZNK5boost16exception_detail25error_info_container_impl5cloneEv
boost::exception_detail::refcount_ptr<boost::exception_detail::error_info_container>_0 __fastcall boost::exception_detail::error_info_container_impl::clone(
        std::__tree_const_iterator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__tree_node<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,void *> *,long> **a1,
        std::__tree_const_iterator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__tree_node<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,void *> *,long> *this)
{
  std::__tree_const_iterator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__tree_node<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,void *> *,long> *v2; // rbx

  *a1 = 0;
  v2 = (std::__tree_const_iterator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__tree_node<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,void *> *,long> *)operator new(0x40u);
  v2->__ptr_ = (std::__tree_const_iterator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__tree_node<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,void *> *,long>::__iter_pointer)&off_2876BF8;
  *(_OWORD *)&v2[2].__ptr_ = 0;
  v2[1].__ptr_ = (std::__tree_const_iterator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__tree_node<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,void *> *,long>::__iter_pointer)&v2[2];
  *(_OWORD *)&v2[4].__ptr_ = 0;
  v2[6].__ptr_ = 0;
  *a1 = v2;
  LODWORD(v2[7].__ptr_) = 1;
  if ( this != v2 )
    std::__tree<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base>>,std::__map_value_compare<boost::exception_detail::type_info_,std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base>>,std::less<boost::exception_detail::type_info_>,true>,std::allocator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base>>>>::__assign_multi<std::__tree_const_iterator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base>>,std::__tree_node<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base>>,void *> *,long>>(
      (std::__tree<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__map_value_compare<boost::exception_detail::type_info_,std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::less<boost::exception_detail::type_info_>,true>,std::allocator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> > > > *)&v2[1],
      *(this + 1),
      (std::__tree_const_iterator<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,std::__tree_node<std::__value_type<boost::exception_detail::type_info_,boost::shared_ptr<boost::exception_detail::error_info_base> >,void *> *,long>)(this + 2));
  return (boost::exception_detail::refcount_ptr<boost::exception_detail::error_info_container>_0)a1;
}


// Address: 0xdc29f0 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 2);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 2) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc3370 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt10bad_typeidEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 2);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 2) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc3cf0 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt8bad_castEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 2);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 2) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc4670 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt9bad_allocEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 2);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 2) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc5020 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt13runtime_errorEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc5a60 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SD_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 5);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 5) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc6430 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt15underflow_errorEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc6e00 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt14overflow_errorEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc77d0 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt11range_errorEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc8180 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt11logic_errorEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc8b50 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc9520 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt12length_errorEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdc9ef0 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


// Address: 0xdca8c0 | Name: _ZN5boost16exception_detail8set_infoINS0_39current_exception_std_exception_wrapperISt12domain_errorEENS_27tag_original_exception_typeEPKSt9type_infoEERKT_SB_RKNS_10error_infoIT0_T1_EE
const boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *__fastcall boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>,boost::tag_original_exception_type,std::type_info const*>(
        const boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *x,
        const boost::error_info<boost::tag_original_exception_type,const std::type_info *> *v)
{
  _QWORD *v3; // rbx
  void *v4; // r15
  _OWORD *v5; // rdi
  volatile signed __int32 *v6; // rbx
  _QWORD *v8; // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  _UNKNOWN **v10; // [rsp+18h] [rbp-20h] BYREF

  v3 = operator new(0x10u);
  *v3 = &off_2876A98;
  v3[1] = v->value_;
  v4 = operator new(0x18u);
  *((_QWORD *)v4 + 1) = 0x100000001LL;
  *(_QWORD *)v4 = &off_2876B98;
  *((_QWORD *)v4 + 2) = v3;
  v5 = (_OWORD *)*((_QWORD *)x + 3);
  if ( !v5 )
  {
    v5 = operator new(0x40u);
    *(_QWORD *)v5 = &off_2876BF8;
    v5[1] = 0;
    *((_QWORD *)v5 + 1) = v5 + 1;
    v5[2] = 0;
    *((_QWORD *)v5 + 6) = 0;
    *((_QWORD *)x + 3) = v5;
    *((_DWORD *)v5 + 14) = 1;
  }
  v8 = v3;
  v9 = (volatile signed __int32 *)v4;
  _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  v10 = &`typeinfo for'boost::error_info<boost::tag_original_exception_type,std::type_info const*>;
  (*(void (__fastcall **)(_OWORD *, _QWORD **, _UNKNOWN ***))(*(_QWORD *)v5 + 16LL))(v5, &v8, &v10);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  if ( !_InterlockedSub((volatile signed __int32 *)v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub((volatile signed __int32 *)v4 + 3, 1u) )
      (*(void (__fastcall **)(void *))(*(_QWORD *)v4 + 24LL))(v4);
  }
  return x;
}


