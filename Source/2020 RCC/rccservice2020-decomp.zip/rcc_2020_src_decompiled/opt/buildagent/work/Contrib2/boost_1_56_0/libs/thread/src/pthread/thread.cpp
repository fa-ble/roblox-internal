// Address: 0x2842980 | Name: _ZN5boost6detail16thread_data_baseD2Ev
void __fastcall boost::detail::thread_data_base::~thread_data_base(boost::detail::thread_data_base *this)
{
  void **v2; // r14
  __int64 v3; // rbx
  __int64 i; // r13
  pthread_mutex_t *v5; // r15
  boost::detail::shared_state_base **v6; // rbx
  boost::detail::shared_state_base **v7; // r15
  boost::detail::shared_state_base **v8; // r13
  volatile signed __int32 *v9; // r15
  boost::detail::shared_state_base **v10; // rdi
  void *v11; // rdi
  volatile signed __int32 *v12; // rbx
  volatile signed __int32 *v13; // rdi

  *(_QWORD *)this = &off_29CFE40;
  v2 = (void **)((char *)this + 360);
  v3 = *((_QWORD *)this + 45);
  for ( i = *((_QWORD *)this + 46); i != v3; v3 += 16 )
  {
    boost::mutex::unlock(*(boost::mutex **)(v3 + 8));
    v5 = *(pthread_mutex_t **)v3;
    pthread_mutex_lock(*(pthread_mutex_t **)v3);
    pthread_cond_broadcast((pthread_cond_t *)&v5[1]);
    pthread_mutex_unlock(v5);
  }
  v6 = (boost::detail::shared_state_base **)*((_QWORD *)this + 48);
  v7 = (boost::detail::shared_state_base **)*((_QWORD *)this + 49);
  if ( v6 != v7 )
  {
    do
    {
      boost::detail::shared_state_base::make_ready(*v6);
      v6 += 2;
    }
    while ( v7 != v6 );
    v6 = (boost::detail::shared_state_base **)*((_QWORD *)this + 48);
  }
  if ( v6 )
  {
    v8 = (boost::detail::shared_state_base **)*((_QWORD *)this + 49);
    if ( v8 == v6 )
    {
      v10 = v6;
    }
    else
    {
      do
      {
        v9 = (volatile signed __int32 *)*(v8 - 1);
        if ( v9 )
        {
          if ( !_InterlockedSub(v9 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
            if ( !_InterlockedSub(v9 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
          }
        }
        v8 -= 2;
      }
      while ( v6 != v8 );
      v10 = (boost::detail::shared_state_base **)*((_QWORD *)this + 48);
    }
    *((_QWORD *)this + 49) = v6;
    operator delete(v10);
  }
  v11 = *v2;
  if ( *v2 )
  {
    *((_QWORD *)this + 46) = v11;
    operator delete(v11);
  }
  std::__tree<std::__value_type<void const*,boost::detail::tss_data_node>,std::__map_value_compare<void const*,std::__value_type<void const*,boost::detail::tss_data_node>,std::less<void const*>,true>,std::allocator<std::__value_type<void const*,boost::detail::tss_data_node>>>::destroy(
    (std::__tree<std::__value_type<const void *,boost::detail::tss_data_node>,std::__map_value_compare<const void *,std::__value_type<const void *,boost::detail::tss_data_node>,std::less<const void *>,true>,std::allocator<std::__value_type<const void *,boost::detail::tss_data_node> > > *)((char *)this + 320),
    *((std::__tree<std::__value_type<const void *,boost::detail::tss_data_node>,std::__map_value_compare<const void *,std::__value_type<const void *,boost::detail::tss_data_node>,std::less<const void *>,true>,std::allocator<std::__value_type<const void *,boost::detail::tss_data_node> > >::__node_pointer *)this
    + 41));
  while ( pthread_mutex_destroy((pthread_mutex_t *)((char *)this + 216)) == 4 )
    ;
  while ( pthread_cond_destroy((pthread_cond_t *)((char *)this + 256)) == 4 )
    ;
  while ( pthread_mutex_destroy((pthread_mutex_t *)((char *)this + 176)) == 4 )
    ;
  while ( pthread_mutex_destroy((pthread_mutex_t *)((char *)this + 88)) == 4 )
    ;
  while ( pthread_cond_destroy((pthread_cond_t *)((char *)this + 128)) == 4 )
    ;
  while ( pthread_mutex_destroy((pthread_mutex_t *)((char *)this + 48)) == 4 )
    ;
  v12 = (volatile signed __int32 *)*((_QWORD *)this + 4);
  if ( v12 )
  {
    if ( !_InterlockedSub(v12 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  v13 = (volatile signed __int32 *)*((_QWORD *)this + 2);
  if ( v13 )
  {
    if ( !_InterlockedSub(v13 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
  }
}


// Address: 0x2842c50 | Name: _ZN5boost6detail16thread_data_baseD0Ev
void __fastcall __noreturn boost::detail::thread_data_base::~thread_data_base(boost::detail::thread_data_base *this)
{
  BUG();
}


// Address: 0x2842c60 | Name: _ZN5boost6detail23get_current_thread_dataEv
boost::detail::thread_data_base *__cdecl boost::detail::get_current_thread_data()
{
  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  return (boost::detail::thread_data_base *)pthread_getspecific(dword_2CE56E4);
}


// Address: 0x2842ca0 | Name: _ZN5boost6detail23set_current_thread_dataEPNS0_16thread_data_baseE
void __fastcall boost::detail::set_current_thread_data(boost::detail::thread_data_base *new_data)
{
  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  pthread_setspecific(dword_2CE56E4, new_data);
}


// Address: 0x2842cf0 | Name: _ZN5boost6detail25make_external_thread_dataEv
boost::detail::thread_data_base *__cdecl boost::detail::make_external_thread_data()
{
  char *v0; // rbx

  v0 = (char *)operator new(0x1A0u);
  boost::detail::thread_data_base::thread_data_base((boost::detail::thread_data_base *)v0);
  *(_QWORD *)v0 = off_29CFEA8;
  v0[408] = 0;
  boost::shared_ptr<boost::detail::thread_data_base>::reset<boost::detail::thread_data_base>(
    (boost::shared_ptr<boost::detail::thread_data_base> *)(v0 + 24),
    (boost::detail::thread_data_base *)v0);
  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  pthread_setspecific(dword_2CE56E4, v0);
  return (boost::detail::thread_data_base *)v0;
}


// Address: 0x2842d90 | Name: _ZN5boost6detail31get_or_make_current_thread_dataEv
boost::detail::thread_data_base *__cdecl boost::detail::get_or_make_current_thread_data()
{
  boost::detail::thread_data_base *result; // rax

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  result = (boost::detail::thread_data_base *)pthread_getspecific(dword_2CE56E4);
  if ( !result )
    return boost::detail::make_external_thread_data();
  return result;
}


// Address: 0x2842df0 | Name: _ZN5boost6thread21start_thread_noexceptEv
bool __fastcall boost::thread::start_thread_noexcept(boost::thread *this)
{
  boost::shared_ptr<boost::detail::thread_data_base>::element_type *px; // rax
  boost::detail::sp_counted_base *pi; // rcx
  volatile signed __int32 *v3; // rbx
  volatile signed __int32 *v4; // rbx

  px = this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  *((_QWORD *)px + 3) = px;
  v3 = (volatile signed __int32 *)*((_QWORD *)px + 4);
  *((_QWORD *)px + 4) = pi;
  if ( v3 )
  {
    if ( !_InterlockedSub(v3 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
      if ( !_InterlockedSub(v3 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
    }
  }
  if ( !pthread_create(
          (pthread_t *)this->thread_info.px + 5,
          0,
          boost::`anonymous namespace'::thread_proxy,
          this->thread_info.px) )
    return 1;
  v4 = (volatile signed __int32 *)*((_QWORD *)this->thread_info.px + 4);
  *(_OWORD *)((char *)this->thread_info.px + 24) = 0;
  if ( v4 )
  {
    if ( !_InterlockedSub(v4 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
      if ( !_InterlockedSub(v4 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
    }
  }
  return 0;
}


// Address: 0x2842eb0 | Name: _ZN5boost12_GLOBAL__N_112thread_proxyEPv
void *__fastcall boost::`anonymous namespace'::thread_proxy(void *param)
{
  __int64 v1; // r12
  volatile signed __int32 *v2; // r14
  volatile signed __int32 *v3; // rbx

  v1 = *((_QWORD *)param + 3);
  v2 = (volatile signed __int32 *)*((_QWORD *)param + 4);
  if ( v2 )
    _InterlockedAdd(v2 + 2, 1u);
  v3 = *(volatile signed __int32 **)(v1 + 32);
  *(_OWORD *)(v1 + 24) = 0;
  if ( v3 )
  {
    if ( !_InterlockedSub(v3 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
      if ( !_InterlockedSub(v3 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
    }
  }
  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  pthread_setspecific(dword_2CE56E4, (const void *)v1);
  (*(void (__fastcall **)(__int64))(*(_QWORD *)v1 + 16LL))(v1);
  boost::detail::`anonymous namespace'::tls_destructor((void *)v1);
  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  pthread_setspecific(dword_2CE56E4, 0);
  boost::mutex::lock((boost::mutex *)(v1 + 48));
  *(_BYTE *)(v1 + 304) = 1;
  pthread_mutex_lock((pthread_mutex_t *)(v1 + 88));
  pthread_cond_broadcast((pthread_cond_t *)(v1 + 128));
  pthread_mutex_unlock((pthread_mutex_t *)(v1 + 88));
  boost::mutex::unlock((boost::mutex *)(v1 + 48));
  if ( v2 )
  {
    if ( !_InterlockedSub(v2 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
      if ( !_InterlockedSub(v2 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
    }
  }
  return 0;
}


// Address: 0x2843070 | Name: _ZN5boost6thread21start_thread_noexceptERKNS_17thread_attributesE
bool __fastcall boost::thread::start_thread_noexcept(boost::thread *this, const boost::thread::attributes *attr)
{
  boost::shared_ptr<boost::detail::thread_data_base>::element_type *px; // rax
  boost::detail::sp_counted_base *pi; // rcx
  volatile signed __int32 *v4; // rbp
  volatile signed __int32 *v5; // rbx
  volatile signed __int32 *v6; // rbx
  bool v7; // bp
  char *v9; // rax
  boost::detail::sp_counted_base *v10; // r14
  int detachstate[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  px = this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  *((_QWORD *)px + 3) = px;
  v4 = (volatile signed __int32 *)*((_QWORD *)px + 4);
  *((_QWORD *)px + 4) = pi;
  if ( v4 )
  {
    if ( !_InterlockedSub(v4 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
      if ( !_InterlockedSub(v4 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
    }
  }
  if ( pthread_create(
         (pthread_t *)this->thread_info.px + 5,
         &attr->val_,
         boost::`anonymous namespace'::thread_proxy,
         this->thread_info.px) )
  {
    v5 = (volatile signed __int32 *)*((_QWORD *)this->thread_info.px + 4);
    *(_OWORD *)((char *)this->thread_info.px + 24) = 0;
    if ( v5 )
    {
      if ( !_InterlockedSub(v5 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 16LL))(v5);
        if ( !_InterlockedSub(v5 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
      }
    }
    return 0;
  }
  if ( pthread_attr_getdetachstate(&attr->val_, detachstate) )
  {
    v6 = (volatile signed __int32 *)*((_QWORD *)this->thread_info.px + 4);
    *(_OWORD *)((char *)this->thread_info.px + 24) = 0;
    if ( v6 )
    {
      if ( !_InterlockedSub(v6 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
    return 0;
  }
  v7 = 1;
  if ( detachstate[0] == 1 )
  {
    v9 = (char *)this->thread_info.px;
    v10 = this->thread_info.pn.pi_;
    *this = 0;
    if ( v9 && !v9[305] )
      *(_WORD *)(v9 + 305) = 257;
    if ( v10 )
    {
      if ( !_InterlockedSub(&v10->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
        if ( !_InterlockedSub(&v10->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
      }
    }
  }
  return v7;
}


// Address: 0x2843200 | Name: _ZN5boost6thread13join_noexceptEv
bool __fastcall boost::thread::join_noexcept(boost::thread *this)
{
  char *px; // rbp
  boost::detail::sp_counted_base *pi; // r14
  char v3; // r15
  bool v4; // bl
  boost::mutex *v5; // r15
  boost::detail::sp_counted_base *v7; // r15
  boost::unique_lock<boost::mutex> v8; // [rsp+0h] [rbp-48h] BYREF
  boost::mutex *v9; // [rsp+10h] [rbp-38h]

  px = (char *)this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  if ( !px )
  {
    v4 = 0;
    if ( !pi )
      return v4;
    goto LABEL_19;
  }
  v8.m = (boost::mutex *)(px + 48);
  v8.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v8);
  while ( !px[304] )
    boost::condition_variable::wait((boost::condition_variable *)px + 1, &v8);
  v9 = (boost::mutex *)(px + 48);
  v3 = px[305];
  if ( v3 )
  {
    while ( !px[306] )
      boost::condition_variable::wait((boost::condition_variable *)px + 1, &v8);
  }
  else
  {
    px[305] = 1;
  }
  if ( v8.is_locked )
    boost::mutex::unlock(v8.m);
  if ( !v3 )
  {
    v8.m = 0;
    pthread_join(*((_QWORD *)px + 5), (void **)&v8.m);
    v5 = v9;
    boost::mutex::lock(v9);
    px[306] = 1;
    pthread_mutex_lock((pthread_mutex_t *)(px + 88));
    pthread_cond_broadcast((pthread_cond_t *)(px + 128));
    pthread_mutex_unlock((pthread_mutex_t *)(px + 88));
    boost::mutex::unlock(v5);
  }
  v4 = 1;
  if ( this->thread_info.px == px )
  {
    v7 = this->thread_info.pn.pi_;
    *this = 0;
    if ( v7 )
    {
      if ( !_InterlockedSub(&v7->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
  }
  if ( pi )
  {
LABEL_19:
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return v4;
}


// Address: 0x2843410 | Name: _ZN5boost6thread26do_try_join_until_noexceptERK8timespecRb
bool __fastcall boost::thread::do_try_join_until_noexcept(boost::thread *this, const timespec *timeout, bool *res)
{
  const timespec *v3; // rbx
  char *px; // r12
  boost::detail::sp_counted_base *pi; // r15
  bool v6; // bl
  char v7; // r13
  bool v8; // bl
  char v9; // r13
  boost::mutex *v10; // rbx
  boost::detail::sp_counted_base *v12; // rbx
  boost::unique_lock<boost::mutex> m; // [rsp+8h] [rbp-50h] BYREF
  bool *v14; // [rsp+18h] [rbp-40h]
  boost::mutex *v15; // [rsp+20h] [rbp-38h]

  v3 = timeout;
  px = (char *)this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  if ( !px )
  {
    v8 = 0;
    if ( !pi )
      return v8;
    goto LABEL_10;
  }
  v14 = res;
  v15 = (boost::mutex *)(px + 48);
  m.m = (boost::mutex *)(px + 48);
  m.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&m);
  while ( !px[304] )
  {
    timeout = (const timespec *)&m;
    if ( !boost::condition_variable::do_wait_until((boost::condition_variable *)px + 1, &m, v3) )
    {
      *v14 = 0;
      v6 = 0;
      v7 = 0;
      if ( !m.is_locked )
        goto LABEL_19;
      goto LABEL_18;
    }
  }
  v9 = px[305];
  if ( v9 )
  {
    while ( !px[306] )
    {
      timeout = (const timespec *)&m;
      boost::condition_variable::wait((boost::condition_variable *)px + 1, &m);
    }
  }
  else
  {
    px[305] = 1;
  }
  v6 = v9 == 0;
  v7 = 1;
  if ( m.is_locked )
LABEL_18:
    boost::mutex::unlock(m.m);
LABEL_19:
  if ( v7 )
  {
    if ( v6 )
    {
      m.m = 0;
      timeout = (const timespec *)&m;
      pthread_join(*((_QWORD *)px + 5), (void **)&m.m);
      v10 = v15;
      boost::mutex::lock(v15);
      px[306] = 1;
      pthread_mutex_lock((pthread_mutex_t *)(px + 88));
      pthread_cond_broadcast((pthread_cond_t *)(px + 128));
      pthread_mutex_unlock((pthread_mutex_t *)(px + 88));
      boost::mutex::unlock(v10);
    }
    if ( this->thread_info.px == px )
    {
      v12 = this->thread_info.pn.pi_;
      *this = 0;
      if ( v12 )
      {
        if ( !_InterlockedSub(&v12->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
          if ( !_InterlockedSub(&v12->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
        }
      }
    }
    *v14 = 1;
  }
  v8 = 1;
  if ( pi )
  {
LABEL_10:
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, const timespec *, bool *))pi->_vptr$sp_counted_base + 2))(
        pi,
        timeout,
        res);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return v8;
}


// Address: 0x2843680 | Name: _ZNK5boost6thread8joinableEv
bool __fastcall boost::thread::joinable(const boost::thread *this)
{
  boost::shared_ptr<boost::detail::thread_data_base>::element_type *px; // rax
  boost::detail::sp_counted_base *pi; // rbx
  bool v3; // bp

  px = this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  if ( !pi )
    return px != 0;
  _InterlockedAdd(&pi->use_count_, 1u);
  v3 = px != 0;
  if ( !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
  return v3;
}


// Address: 0x28436e0 | Name: _ZN5boost6thread6detachEv
void __fastcall boost::thread::detach(boost::thread *this)
{
  char *px; // rbx
  boost::detail::sp_counted_base *pi; // r15

  px = (char *)this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  *this = 0;
  if ( px )
  {
    boost::mutex::lock((boost::mutex *)(px + 48));
    if ( !px[305] )
    {
      pthread_detach(*((_QWORD *)px + 5));
      *(_WORD *)(px + 305) = 257;
    }
    boost::mutex::unlock((boost::mutex *)(px + 48));
  }
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x28437c0 | Name: _ZN5boost11this_thread21no_interruption_point5hiden11sleep_untilERK8timespec
void __fastcall boost::this_thread::no_interruption_point::hiden::sleep_until(const timespec *ts)
{
  __time_t tv_sec; // r12
  __syscall_slong_t tv_nsec; // r13
  __time_t v3; // rax
  __syscall_slong_t v4; // rcx
  unsigned int v5; // ebp
  __int64 v6; // rcx
  struct timespec tp; // [rsp+8h] [rbp-50h] BYREF
  struct timespec requested_time; // [rsp+18h] [rbp-40h] BYREF

  clock_gettime(0, &tp);
  tv_sec = tp.tv_sec;
  tv_nsec = tp.tv_nsec;
  v3 = ts->tv_sec;
  v4 = ts->tv_nsec;
  if ( v4 + 1000000000 * ts->tv_sec > tp.tv_nsec + 1000000000 * tp.tv_sec )
  {
    v5 = 1;
    do
    {
      v6 = 1000000000 * (v3 - tv_sec) + v4 - tv_nsec;
      requested_time.tv_sec = v6 / 1000000000;
      requested_time.tv_nsec = v6 % 1000000000;
      nanosleep(&requested_time, 0);
      clock_gettime(0, &tp);
      v3 = ts->tv_sec;
      v4 = ts->tv_nsec;
      if ( tp.tv_nsec + 1000000000 * tp.tv_sec >= v4 + 1000000000 * ts->tv_sec )
        break;
    }
    while ( v5++ < 5 );
  }
}


// Address: 0x28438c0 | Name: _ZN5boost11this_thread5hiden9sleep_forERK8timespec
void __fastcall boost::this_thread::hiden::sleep_for(const timespec *ts)
{
  char *v1; // rax
  char *v2; // r14
  boost::condition_variable *v3; // r14
  __time_t v4; // rcx
  boost::unique_lock<boost::mutex> v5; // [rsp+0h] [rbp-48h] BYREF
  struct timespec tp; // [rsp+10h] [rbp-38h] BYREF

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v1 = (char *)pthread_getspecific(dword_2CE56E4);
  if ( v1 )
  {
    v2 = v1;
    v5.m = (boost::mutex *)(v1 + 176);
    v5.is_locked = 0;
    boost::unique_lock<boost::mutex>::lock(&v5);
    v3 = (boost::condition_variable *)(v2 + 216);
    do
    {
      clock_gettime(0, &tp);
      v4 = 1000000000 * (ts->tv_sec + tp.tv_sec) + ts->tv_nsec + tp.tv_nsec;
      tp.tv_sec = v4 / 1000000000;
      tp.tv_nsec = v4 % 1000000000;
    }
    while ( boost::condition_variable::do_wait_until(v3, &v5, &tp) );
    if ( v5.is_locked )
      boost::mutex::unlock(v5.m);
  }
  else if ( ts->tv_nsec + 1000000000 * ts->tv_sec >= 0 )
  {
    nanosleep(ts, 0);
  }
}


// Address: 0x2843a20 | Name: _ZN5boost11this_thread5hiden11sleep_untilERK8timespec
void __fastcall boost::this_thread::hiden::sleep_until(const timespec *ts)
{
  char *v1; // rax
  char *v2; // rbx
  boost::condition_variable *v3; // rbx
  boost::unique_lock<boost::mutex> v4[2]; // [rsp+0h] [rbp-28h] BYREF

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v1 = (char *)pthread_getspecific(dword_2CE56E4);
  if ( v1 )
  {
    v2 = v1;
    v4[0].m = (boost::mutex *)(v1 + 176);
    v4[0].is_locked = 0;
    boost::unique_lock<boost::mutex>::lock(v4);
    v3 = (boost::condition_variable *)(v2 + 216);
    while ( boost::condition_variable::do_wait_until(v3, v4, ts) )
      ;
    if ( v4[0].is_locked )
      boost::mutex::unlock(v4[0].m);
  }
  else
  {
    boost::this_thread::no_interruption_point::hiden::sleep_until(ts);
  }
}


// Address: 0x2843b00 | Name: _ZN5boost11this_thread5yieldEv
// Alternative name is 'j_.sched_yield_0'
// attributes: thunk
void __cdecl boost::this_thread::yield()
{
  sched_yield();
}


// Address: 0x2843b10 | Name: _ZN5boost6thread20hardware_concurrencyEv
unsigned int __cdecl boost::thread::hardware_concurrency()
{
  unsigned int result; // eax

  result = sysconf(84);
  if ( (result & 0x80000000) != 0 )
    return 0;
  return result;
}


// Address: 0x2843b30 | Name: _ZN5boost6thread20physical_concurrencyEv
unsigned int __cdecl boost::thread::physical_concurrency()
{
  __int64 v0; // rax
  char v1; // r15
  std::istream *v2; // rax
  unsigned __int64 v3; // rax
  _OWORD *v4; // rax
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rdx
  int v7; // ebp
  __int64 v8; // rsi
  __int64 v9; // rax
  const char *v10; // rcx
  unsigned __int64 v11; // rax
  __int64 v12; // rcx
  const char *v13; // rcx
  unsigned __int64 v14; // rax
  const char *v15; // rax
  char v16; // bl
  bool v17; // al
  __int64 locale_low; // rbp
  char *left; // rbx
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *v20; // r15
  char *v21; // rax
  unsigned int v22; // eax
  char *v23; // rax
  unsigned int v24; // eax
  const char *v25; // rax
  char v26; // bl
  bool v27; // al
  void **v28; // rbx
  void **v29; // rax
  void **v30; // rbp
  void *v31; // rdi
  int v32; // eax
  unsigned int value; // r15d
  std::locale::__imp *v35; // rdx
  std::locale::__imp *v36; // rdx
  unsigned int locale; // [rsp+4h] [rbp-294h]
  std::locale v38; // [rsp+8h] [rbp-290h] BYREF
  boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char> IsSpace; // [rsp+10h] [rbp-288h] BYREF
  void *v40[2]; // [rsp+30h] [rbp-268h] BYREF
  _OWORD *v41; // [rsp+40h] [rbp-258h]
  std::__tree<std::pair<unsigned int,unsigned int>> v42; // [rsp+50h] [rbp-248h] BYREF
  unsigned __int8 v43; // [rsp+68h] [rbp-230h] BYREF
  _BYTE v44[7]; // [rsp+69h] [rbp-22Fh] BYREF
  unsigned __int64 v45; // [rsp+70h] [rbp-228h]
  void *ptr; // [rsp+78h] [rbp-220h]
  _BYTE v47[8]; // [rsp+80h] [rbp-218h] BYREF
  unsigned __int64 v48; // [rsp+88h] [rbp-210h]
  void *s1; // [rsp+90h] [rbp-208h]
  int v50; // [rsp+9Ch] [rbp-1FCh]
  __int128 v51; // [rsp+A0h] [rbp-1F8h] BYREF
  void *v52; // [rsp+B0h] [rbp-1E8h]
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *p_pair1; // [rsp+B8h] [rbp-1E0h]
  char s2; // [rsp+C0h] [rbp-1D8h]
  __int64 s2_1; // [rsp+C1h] [rbp-1D7h] BYREF
  _BYTE s2_9[7]; // [rsp+C9h] [rbp-1CFh]
  __int64 v57; // [rsp+D0h] [rbp-1C8h]
  __int128 v58; // [rsp+E0h] [rbp-1B8h] BYREF
  __int64 v59; // [rsp+F0h] [rbp-1A8h]
  boost::algorithm::token_compress_mode_type eCompress[2]; // [rsp+F8h] [rbp-1A0h] BYREF
  unsigned __int64 v61; // [rsp+108h] [rbp-190h]
  __int128 v62; // [rsp+110h] [rbp-188h] BYREF
  _BYTE v63[120]; // [rsp+120h] [rbp-178h] BYREF
  FILE *v64; // [rsp+198h] [rbp-100h]
  int v65; // [rsp+1B8h] [rbp-E0h]
  _QWORD v66[18]; // [rsp+1C8h] [rbp-D0h] BYREF
  int v67; // [rsp+258h] [rbp-40h]
  unsigned __int64 v68; // [rsp+260h] [rbp-38h]
  boost::algorithm::detail::is_classifiedF v69; // 0:kr00_16.16
  boost::algorithm::detail::is_classifiedF v70; // 0:kr10_16.16

  v68 = __readfsqword(0x28u);
  v66[0] = &off_28791A0;
  v62 = (unsigned __int64)&off_2879178;
  std::ios_base::init((std::ios_base *)v66, v63);
  v66[17] = 0;
  v67 = -1;
  *(_QWORD *)&v62 = &off_2879100;
  v66[0] = off_2879128;
  std::filebuf::basic_filebuf((std::filebuf *)v63);
  if ( v64 || (v64 = fopen("/proc/cpuinfo", "r")) == 0 )
    std::ios_base::clear(
      (std::ios_base *)&v63[*(_QWORD *)(v62 - 24) - 16],
      *(_DWORD *)&v63[*(_QWORD *)(v62 - 24) + 16] | 4);
  else
    v65 = 8;
  *(_DWORD *)&s2_9[3] = 0;
  v57 = 0;
  s2 = 22;
  s2_1 = 0x6C61636973796870LL;
  *(_DWORD *)s2_9 = (_DWORD)&unk_646920;
  *((_QWORD *)&v58 + 1) = 0;
  v59 = 0;
  LOBYTE(v58) = 14;
  strcpy((char *)&v58 + 1, "core id");
  *(_OWORD *)&v42.__pair1_.__value_.__left_ = 0;
  v42.__begin_node_ = &v42.__pair1_.__value_;
  v51 = 0;
  v52 = 0;
  locale = 0;
  p_pair1 = &v42.__pair1_;
  while ( 1 )
  {
    std::ios_base::getloc((std::ios_base *)&IsSpace);
    v0 = std::locale::use_facet((std::locale *)&IsSpace, &std::ctype<char>::id);
    v1 = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v0 + 56LL))(v0, 10);
    std::locale::~locale((std::locale *)&IsSpace);
    v2 = std::getline<char,std::char_traits<char>,std::allocator<char>>((std::istream *)&v62, (std::string *)&v51, v1);
    if ( (*((_BYTE *)v2 + *(_QWORD *)(*(_QWORD *)v2 - 24LL) + 32) & 5) != 0 )
      break;
    if ( (v51 & 1) != 0 )
      v3 = *((_QWORD *)&v51 + 1);
    else
      v3 = (unsigned __int64)(unsigned __int8)v51 >> 1;
    if ( !v3 )
      continue;
    *(_OWORD *)v40 = 0;
    v41 = 0;
    v4 = operator new(0x30u);
    v40[0] = v4;
    v41 = v4 + 3;
    v4[2] = 0;
    v4[1] = 0;
    *v4 = 0;
    v40[1] = v4 + 3;
    *(_QWORD *)eCompress = 58;
    v61 = 1;
    std::__sort<std::__less<char,char> &,char *>(eCompress, (char *)eCompress + 1, &IsSpace);
    boost::algorithm::split<std::vector<std::string>,std::string,boost::algorithm::detail::is_any_ofF<char>>(
      (std::vector<std::string> *)v40,
      (std::string *)&v51,
      eCompress,
      1);
    if ( v61 >= 0x11 && *(_QWORD *)eCompress )
      operator delete[](*(void **)eCompress);
    if ( (void *)((char *)v40[1] - (char *)v40[0]) != &inputbuff.encodingTable[0].bitLength )
    {
      v9 = sysconf(84);
      if ( (int)v9 < 0 )
        v9 = 0;
      p_pair1 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)v9;
      v7 = 1;
      goto LABEL_81;
    }
    std::string::basic_string(v47, v40[0]);
    std::string::basic_string(&v43, (char *)v40[0] + 24);
    std::locale::locale(&v38);
    *(_WORD *)&IsSpace.m_multiplier_overflowed = 0x2000;
    std::locale::locale((std::locale *)&IsSpace.m_value, &v38);
    v69.m_Type = (unsigned __int16)&IsSpace;
    v69.m_Locale.__locale_ = v35;
    boost::algorithm::trim_if<std::string,boost::algorithm::detail::is_classifiedF>((std::string *)v47, v69);
    std::locale::~locale((std::locale *)&IsSpace.m_value);
    std::locale::~locale(&v38);
    std::locale::locale(&v38);
    *(_WORD *)&IsSpace.m_multiplier_overflowed = 0x2000;
    std::locale::locale((std::locale *)&IsSpace.m_value, &v38);
    v70.m_Type = (unsigned __int16)&IsSpace;
    v70.m_Locale.__locale_ = v36;
    boost::algorithm::trim_if<std::string,boost::algorithm::detail::is_classifiedF>((std::string *)&v43, v70);
    std::locale::~locale((std::locale *)&IsSpace.m_value);
    std::locale::~locale(&v38);
    v5 = (unsigned __int64)v47[0] >> 1;
    v6 = v5;
    if ( (v47[0] & 1) != 0 )
      v6 = v48;
    if ( v6 != 7 )
    {
      if ( v6 != 11 )
        goto LABEL_37;
      v7 = 0;
      if ( (v47[0] & 1) == 0 )
      {
        v8 = 0;
        while ( v47[v8 + 1] == s2_9[v8 - 8] )
        {
          if ( v5 == ++v8 )
            goto LABEL_28;
        }
LABEL_37:
        v7 = 0;
        if ( (v43 & 1) != 0 )
          goto LABEL_78;
        goto LABEL_79;
      }
      if ( !memcmp(s1, &s2_1, 0xBu) )
      {
LABEL_28:
        if ( (v43 & 1) != 0 )
        {
          v10 = (const char *)ptr;
          v11 = v45;
          if ( !v45 )
            goto LABEL_101;
        }
        else
        {
          v11 = (unsigned __int64)v43 >> 1;
          v10 = v44;
          if ( !v11 )
            goto LABEL_101;
        }
        v25 = &v10[v11];
        v26 = *v10;
        if ( *v10 == 45 || v26 == 43 )
          ++v10;
        IsSpace.m_multiplier_overflowed = 0;
        IsSpace.m_multiplier = 1;
        IsSpace.m_value = (unsigned int *)&v38;
        IsSpace.m_begin = v10;
        IsSpace.m_end = v25;
        v27 = boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char>::convert(&IsSpace);
        if ( v26 == 45 )
        {
          locale = -LODWORD(v38.__locale_);
          LODWORD(v38.__locale_) = -LODWORD(v38.__locale_);
          if ( !v27 )
          {
LABEL_101:
            std::bad_cast::bad_cast((std::bad_cast *)&IsSpace);
            *(_QWORD *)&IsSpace.m_multiplier_overflowed = off_287BC88;
            *(__m128i *)&IsSpace.m_value = _mm_unpacklo_epi64(
                                             (__m128i)(unsigned __int64)&`typeinfo for'std::string,
                                             _mm_loadl_epi64((const __m128i *)&`typeinfo for'unsigned int));
            boost::throw_exception<boost::bad_lexical_cast>((const boost::bad_lexical_cast *)&IsSpace);
          }
        }
        else
        {
          if ( !v27 )
            goto LABEL_101;
          locale = (unsigned int)v38.__locale_;
        }
        v7 = 2;
      }
LABEL_77:
      if ( (v43 & 1) != 0 )
        goto LABEL_78;
      goto LABEL_79;
    }
    if ( (v47[0] & 1) == 0 )
    {
      v12 = 0;
      v7 = 0;
      while ( v47[v12 + 1] == *((_BYTE *)&v58 + v12 + 1) )
      {
        if ( v5 == ++v12 )
          goto LABEL_40;
      }
      goto LABEL_77;
    }
    v7 = 0;
    if ( memcmp(s1, (char *)&v58 + 1, 7u) )
      goto LABEL_77;
LABEL_40:
    if ( (v43 & 1) != 0 )
    {
      v13 = (const char *)ptr;
      v14 = v45;
      if ( !v45 )
        goto LABEL_102;
    }
    else
    {
      v14 = (unsigned __int64)v43 >> 1;
      v13 = v44;
      if ( !v14 )
        goto LABEL_102;
    }
    v15 = &v13[v14];
    v16 = *v13;
    if ( *v13 == 45 || v16 == 43 )
      ++v13;
    IsSpace.m_multiplier_overflowed = 0;
    IsSpace.m_multiplier = 1;
    IsSpace.m_value = (unsigned int *)&v38;
    IsSpace.m_begin = v13;
    IsSpace.m_end = v15;
    v17 = boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char>::convert(&IsSpace);
    if ( v16 == 45 )
    {
      locale_low = (unsigned int)-LODWORD(v38.__locale_);
      LODWORD(v38.__locale_) = -LODWORD(v38.__locale_);
      if ( !v17 )
        goto LABEL_102;
    }
    else
    {
      if ( !v17 )
      {
LABEL_102:
        std::bad_cast::bad_cast((std::bad_cast *)&IsSpace);
        *(_QWORD *)&IsSpace.m_multiplier_overflowed = off_287BC88;
        *(__m128i *)&IsSpace.m_value = _mm_unpacklo_epi64(
                                         (__m128i)(unsigned __int64)&`typeinfo for'std::string,
                                         _mm_loadl_epi64((const __m128i *)&`typeinfo for'unsigned int));
        boost::throw_exception<boost::bad_lexical_cast>((const boost::bad_lexical_cast *)&IsSpace);
      }
      locale_low = LODWORD(v38.__locale_);
    }
    left = (char *)v42.__pair1_.__value_.__left_;
    v20 = &v42.__pair1_;
    if ( !v42.__pair1_.__value_.__left_ )
    {
      left = (char *)&v42.__pair1_;
LABEL_54:
      v21 = (char *)operator new(0x28u);
      *(_QWORD *)(v21 + 28) = (locale_low << 32) | locale;
      *(_OWORD *)v21 = 0;
      *((_QWORD *)v21 + 2) = left;
      v20->__value_.__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v21;
      if ( v42.__begin_node_->__left_ )
      {
        v42.__begin_node_ = v42.__begin_node_->__left_;
        v21 = (char *)v20->__value_.__left_;
      }
      v7 = 2;
      std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(
        v42.__pair1_.__value_.__left_,
        (std::__tree_node_base<void *> *)v21);
      ++v42.__pair3_.__value_;
      if ( (v43 & 1) != 0 )
        goto LABEL_78;
      goto LABEL_79;
    }
    while ( 1 )
    {
      v22 = *((_DWORD *)left + 7);
      if ( locale < v22 )
        break;
      if ( v22 >= locale )
      {
        v24 = *((_DWORD *)left + 8);
        if ( (unsigned int)locale_low < v24 )
          break;
        if ( v24 >= (unsigned int)locale_low )
          goto LABEL_92;
      }
      v20 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)(left + 8);
      v23 = (char *)*((_QWORD *)left + 1);
      if ( !v23 )
        goto LABEL_92;
LABEL_58:
      left = v23;
    }
    v23 = *(char **)left;
    v20 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)left;
    if ( *(_QWORD *)left )
      goto LABEL_58;
    v20 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)left;
LABEL_92:
    if ( !v20->__value_.__left_ )
      goto LABEL_54;
    v7 = 2;
    if ( (v43 & 1) == 0 )
      goto LABEL_79;
LABEL_78:
    operator delete(ptr);
LABEL_79:
    if ( (v47[0] & 1) != 0 )
      operator delete(s1);
LABEL_81:
    v28 = (void **)v40[0];
    if ( v40[0] )
    {
      v29 = (void **)v40[1];
      if ( v40[1] == v40[0] )
      {
        v31 = v40[0];
      }
      else
      {
        v50 = v7;
        do
        {
          v30 = v29 - 3;
          if ( (*(_BYTE *)(v29 - 3) & 1) != 0 )
            operator delete(*(v29 - 1));
          v29 = v30;
        }
        while ( v28 != v30 );
        v31 = v40[0];
        v7 = v50;
      }
      v40[1] = v28;
      operator delete(v31);
    }
    if ( (v7 | 2) != 2 )
    {
      value = (unsigned int)p_pair1;
      goto LABEL_98;
    }
  }
  value = v42.__pair3_.__value_;
  if ( !v42.__pair3_.__value_ )
  {
    v32 = sysconf(84);
    value = 0;
    if ( v32 > 0 )
      value = v32;
  }
LABEL_98:
  if ( (v51 & 1) != 0 )
    operator delete(v52);
  std::__tree<std::pair<unsigned int,unsigned int>>::destroy(
    &v42,
    (std::__tree<std::pair<unsigned int,unsigned int>>::__node_pointer)v42.__pair1_.__value_.__left_);
  *(_QWORD *)&v62 = &off_2879100;
  v66[0] = off_2879128;
  std::filebuf::~filebuf((std::filebuf *)v63);
  std::istream::~istream(&v62, off_2879148);
  std::ios::~ios();
  return value;
}


// Address: 0x2844630 | Name: _ZN5boost6thread9interruptEv
void __fastcall boost::thread::interrupt(boost::thread *this)
{
  char *px; // rbx
  boost::detail::sp_counted_base *pi; // r12
  pthread_mutex_t *v3; // r15

  px = (char *)this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  if ( px )
  {
    boost::mutex::lock((boost::mutex *)(px + 48));
    px[409] = 1;
    if ( *((_QWORD *)px + 44) )
    {
      v3 = (pthread_mutex_t *)*((_QWORD *)px + 43);
      pthread_mutex_lock(v3);
      pthread_cond_broadcast(*((pthread_cond_t **)px + 44));
      pthread_mutex_unlock(v3);
    }
    boost::mutex::unlock((boost::mutex *)(px + 48));
  }
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2844720 | Name: _ZNK5boost6thread22interruption_requestedEv
bool __fastcall boost::thread::interruption_requested(const boost::thread *this)
{
  char *px; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::mutex *v3; // rbx
  bool v4; // bp
  _BYTE *v6; // [rsp+8h] [rbp-20h]
  volatile signed __int32 *v7; // [rsp+10h] [rbp-18h]

  px = (char *)this->thread_info.px;
  v6 = this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  v7 = (volatile signed __int32 *)pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  if ( px )
  {
    v3 = (boost::mutex *)(px + 48);
    boost::mutex::lock(v3);
    v4 = v6[409] != 0;
    boost::mutex::unlock(v3);
  }
  else
  {
    v4 = 0;
  }
  if ( v7 )
  {
    if ( !_InterlockedSub(v7 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  return v4;
}


// Address: 0x28447d0 | Name: _ZN5boost6thread13native_handleEv
boost::thread::native_handle_type __fastcall boost::thread::native_handle(boost::thread *this)
{
  char *px; // rbx
  boost::detail::sp_counted_base *pi; // r15
  boost::thread::native_handle_type v3; // r14

  px = (char *)this->thread_info.px;
  pi = this->thread_info.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  if ( px )
  {
    boost::mutex::lock((boost::mutex *)(px + 48));
    v3 = *((_QWORD *)px + 5);
    boost::mutex::unlock((boost::mutex *)(px + 48));
    if ( !pi )
      return v3;
  }
  else
  {
    v3 = 0;
    if ( !pi )
      return v3;
  }
  if ( !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
  return v3;
}


// Address: 0x28448a0 | Name: _ZN5boost11this_thread18interruption_pointEv
void __cdecl boost::this_thread::interruption_point()
{
  char *v0; // rax
  char *v1; // rbx
  void *exception; // rax

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v0 = (char *)pthread_getspecific(dword_2CE56E4);
  if ( v0 )
  {
    v1 = v0;
    if ( v0[408] )
    {
      boost::mutex::lock((boost::mutex *)(v0 + 48));
      if ( v1[409] )
      {
        v1[409] = 0;
        exception = __cxa_allocate_exception(1u);
        __cxa_throw(exception, (struct type_info *)&`typeinfo for'boost::thread_interrupted, 0);
      }
      boost::mutex::unlock((boost::mutex *)(v1 + 48));
    }
  }
}


// Address: 0x2844960 | Name: _ZN5boost11this_thread20interruption_enabledEv
bool __cdecl boost::this_thread::interruption_enabled()
{
  _BYTE *v0; // rax

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v0 = pthread_getspecific(dword_2CE56E4);
  return v0 && v0[408] != 0;
}


// Address: 0x28449b0 | Name: _ZN5boost11this_thread22interruption_requestedEv
bool __cdecl boost::this_thread::interruption_requested()
{
  char *v0; // rax
  char *v1; // rbx
  boost::mutex *v2; // r14
  bool v3; // bl

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v0 = (char *)pthread_getspecific(dword_2CE56E4);
  if ( !v0 )
    return 0;
  v1 = v0;
  v2 = (boost::mutex *)(v0 + 48);
  boost::mutex::lock((boost::mutex *)(v0 + 48));
  v3 = v1[409] != 0;
  boost::mutex::unlock(v2);
  return v3;
}


// Address: 0x2844a40 | Name: _ZN5boost11this_thread20disable_interruptionC2Ev
void __fastcall boost::this_thread::disable_interruption::disable_interruption(
        boost::this_thread::disable_interruption *this)
{
  _BYTE *v1; // rax
  char v2; // al

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v1 = pthread_getspecific(dword_2CE56E4);
  if ( v1 )
  {
    v2 = v1[408];
    this->interruption_was_enabled = v2;
    if ( v2 )
    {
      if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
      {
        pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
        boost::thread_detail::commit_once_region(&stru_2CE56E0);
      }
      *((_BYTE *)pthread_getspecific(dword_2CE56E4) + 408) = 0;
    }
  }
  else
  {
    this->interruption_was_enabled = 0;
  }
}


// Address: 0x2844ae0 | Name: _ZN5boost11this_thread20disable_interruptionD2Ev
void __fastcall boost::this_thread::disable_interruption::~disable_interruption(
        boost::this_thread::disable_interruption *this)
{
  bool interruption_was_enabled; // bl

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  if ( pthread_getspecific(dword_2CE56E4) )
  {
    interruption_was_enabled = this->interruption_was_enabled;
    if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
    {
      pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
      boost::thread_detail::commit_once_region(&stru_2CE56E0);
    }
    *((_BYTE *)pthread_getspecific(dword_2CE56E4) + 408) = interruption_was_enabled;
  }
}


// Address: 0x2844b70 | Name: _ZN5boost11this_thread20restore_interruptionC2ERNS0_20disable_interruptionE
void __fastcall boost::this_thread::restore_interruption::restore_interruption(
        boost::this_thread::restore_interruption *this,
        boost::this_thread::disable_interruption *d)
{
  if ( d->interruption_was_enabled )
  {
    if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
    {
      pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
      boost::thread_detail::commit_once_region(&stru_2CE56E0);
    }
    *((_BYTE *)pthread_getspecific(dword_2CE56E4) + 408) = 1;
  }
}


// Address: 0x2844bc0 | Name: _ZN5boost11this_thread20restore_interruptionD2Ev
void __fastcall boost::this_thread::restore_interruption::~restore_interruption(
        boost::this_thread::restore_interruption *this)
{
  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  if ( pthread_getspecific(dword_2CE56E4) )
  {
    if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
    {
      pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
      boost::thread_detail::commit_once_region(&stru_2CE56E0);
    }
    *((_BYTE *)pthread_getspecific(dword_2CE56E4) + 408) = 0;
  }
}


// Address: 0x2844c50 | Name: _ZN5boost6detail24add_thread_exit_functionEPNS0_25thread_exit_function_baseE
void __fastcall boost::detail::add_thread_exit_function(boost::detail::thread_exit_function_base *func)
{
  _QWORD *external_thread_data; // rbx
  _QWORD *v2; // rax
  __int64 v3; // rcx

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  external_thread_data = pthread_getspecific(dword_2CE56E4);
  if ( !external_thread_data )
    external_thread_data = boost::detail::make_external_thread_data();
  v2 = operator new(0x10u);
  v3 = external_thread_data[39];
  *v2 = func;
  v2[1] = v3;
  external_thread_data[39] = v2;
}


// Address: 0x2844cd0 | Name: _ZN5boost6detail13find_tss_dataEPKv
boost::detail::tss_data_node *__fastcall boost::detail::find_tss_data(const void *key)
{
  _QWORD *v1; // rax
  char *v2; // rdx
  char *v3; // rcx
  char *v4; // rax

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v1 = pthread_getspecific(dword_2CE56E4);
  if ( !v1 )
    return 0;
  v2 = (char *)v1[41];
  if ( !v2 )
    return 0;
  v3 = (char *)(v1 + 41);
  v4 = (char *)(v1 + 41);
  do
  {
    if ( *((_QWORD *)v2 + 4) >= (unsigned __int64)key )
      v4 = v2;
    v2 = *(char **)&v2[8 * (*((_QWORD *)v2 + 4) < (unsigned __int64)key)];
  }
  while ( v2 );
  if ( v4 == v3 )
    return 0;
  if ( *((_QWORD *)v4 + 4) <= (unsigned __int64)key )
    return (boost::detail::tss_data_node *)(v4 + 40);
  return 0;
}


// Address: 0x2844d70 | Name: _ZN5boost6detail12get_tss_dataEPKv
void *__fastcall boost::detail::get_tss_data(const void *key)
{
  _QWORD *v1; // rax
  char *v2; // rdx
  char *v3; // rax
  char *v4; // rcx

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v1 = pthread_getspecific(dword_2CE56E4);
  if ( !v1 )
    return 0;
  v2 = (char *)v1[41];
  if ( !v2 )
    return 0;
  v3 = (char *)(v1 + 41);
  v4 = v3;
  do
  {
    if ( *((_QWORD *)v2 + 4) >= (unsigned __int64)key )
      v4 = v2;
    v2 = *(char **)&v2[8 * (*((_QWORD *)v2 + 4) < (unsigned __int64)key)];
  }
  while ( v2 );
  if ( v4 == v3 )
    return 0;
  if ( *((_QWORD *)v4 + 4) <= (unsigned __int64)key )
    return (void *)*((_QWORD *)v4 + 7);
  return 0;
}


// Address: 0x2844e10 | Name: _ZN5boost6detail16add_new_tss_nodeEPKvNS_10shared_ptrINS0_20tss_cleanup_functionEEEPv
void __fastcall boost::detail::add_new_tss_node(
        unsigned __int64 key,
        boost::shared_ptr<boost::detail::tss_cleanup_function>_0 func,
        void *tss_data)
{
  std::__tree_end_node<std::__tree_node_base<void *> *> *external_thread_data; // r12
  int (**v4)(void); // r13
  volatile signed __int32 *v5; // r15
  std::__tree_end_node<std::__tree_node_base<void *> *> *left; // rbp
  std::__tree_node_base<void *> **p_left; // r14
  bool v8; // cf
  std::__tree_node_base<void *> *v9; // rax
  std::__tree_node_base<void *> *v10; // rax
  std::__tree_node_base<void *> *v11; // rcx
  boost::detail::sp_counted_base *pi; // [rsp+0h] [rbp-38h]

  pi = func.pn.pi_;
  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  external_thread_data = (std::__tree_end_node<std::__tree_node_base<void *> *> *)pthread_getspecific(dword_2CE56E4);
  if ( !external_thread_data )
    external_thread_data = (std::__tree_end_node<std::__tree_node_base<void *> *> *)boost::detail::make_external_thread_data();
  v4 = func.px->_vptr$tss_cleanup_function;
  v5 = (volatile signed __int32 *)func.px[1]._vptr$tss_cleanup_function;
  if ( v5 )
  {
    _InterlockedAdd(v5 + 2, 1u);
    _InterlockedAdd(v5 + 2, 1u);
  }
  left = external_thread_data[41].__left_;
  if ( left )
  {
    p_left = &external_thread_data[41].__left_;
    v8 = left[4].__left_ < (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)key;
    if ( left[4].__left_ <= (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)key )
      goto LABEL_13;
    while ( 1 )
    {
      v9 = left->__left_;
      p_left = &left->__left_;
      if ( !left->__left_ )
        break;
      while ( 1 )
      {
        left = v9;
        v8 = v9[1].__left_ < (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)key;
        if ( v9[1].__left_ > (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)key )
          break;
LABEL_13:
        if ( v8 )
        {
          p_left = &left[1].__left_;
          v9 = left[1].__left_;
          if ( v9 )
            continue;
        }
        if ( !*p_left )
          goto LABEL_22;
        goto LABEL_16;
      }
    }
  }
  else
  {
    left = external_thread_data + 41;
  }
  p_left = &left->__left_;
  if ( left->__left_ )
  {
LABEL_16:
    if ( !v5 )
      return;
    if ( !_InterlockedSub(v5 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 16LL))(v5);
      if ( !_InterlockedSub(v5 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
    }
    goto LABEL_25;
  }
LABEL_22:
  v10 = (std::__tree_node_base<void *> *)operator new(0x40u);
  v10[1].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)key;
  v10[1].__right_ = (std::__tree_node_base<void *>::pointer)v4;
  v10[1].__parent_ = (std::__tree_node_base<void *>::__parent_pointer)v5;
  *(_QWORD *)&v10[1].__is_black_ = pi;
  *(_OWORD *)&v10->__left_ = 0;
  v10->__parent_ = left;
  *p_left = v10;
  v11 = external_thread_data[40].__left_->__left_;
  if ( v11 )
  {
    external_thread_data[40].__left_ = v11;
    v10 = *p_left;
  }
  std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(external_thread_data[41].__left_, v10);
  ++external_thread_data[42].__left_;
  if ( v5 )
  {
LABEL_25:
    if ( !_InterlockedSub(v5 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 16LL))(v5);
      if ( !_InterlockedSub(v5 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
    }
  }
}


// Address: 0x2845040 | Name: _ZN5boost6detail14erase_tss_nodeEPKv
void __fastcall boost::detail::erase_tss_node(const void *key)
{
  char *v2; // rax
  std::__tree_end_node<std::__tree_node_base<void *> *> *left; // rcx
  std::__tree<std::__value_type<const void *,boost::detail::tss_data_node>,std::__map_value_compare<const void *,std::__value_type<const void *,boost::detail::tss_data_node>,std::less<const void *>,true>,std::allocator<std::__value_type<const void *,boost::detail::tss_data_node> > > *v4; // rdi
  std::__tree_end_node<std::__tree_node_base<void *> *> *v5; // rax
  std::__tree<std::__value_type<const void *,boost::detail::tss_data_node>,std::__map_value_compare<const void *,std::__value_type<const void *,boost::detail::tss_data_node>,std::less<const void *>,true>,std::allocator<std::__value_type<const void *,boost::detail::tss_data_node> > >::const_iterator v6; // rsi

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v2 = (char *)pthread_getspecific(dword_2CE56E4);
  if ( v2 )
  {
    left = (std::__tree_end_node<std::__tree_node_base<void *> *> *)*((_QWORD *)v2 + 41);
    if ( left )
    {
      v4 = (std::__tree<std::__value_type<const void *,boost::detail::tss_data_node>,std::__map_value_compare<const void *,std::__value_type<const void *,boost::detail::tss_data_node>,std::less<const void *>,true>,std::allocator<std::__value_type<const void *,boost::detail::tss_data_node> > > *)(v2 + 320);
      v5 = (std::__tree_end_node<std::__tree_node_base<void *> *> *)(v2 + 328);
      v6.__ptr_ = v5;
      do
      {
        if ( left[4].__left_ >= key )
          v6.__ptr_ = left;
        left = left[left[4].__left_ < key].__left_;
      }
      while ( left );
      if ( v6.__ptr_ != v5 && v6.__ptr_[4].__left_ <= key )
        std::__tree<std::__value_type<void const*,boost::detail::tss_data_node>,std::__map_value_compare<void const*,std::__value_type<void const*,boost::detail::tss_data_node>,std::less<void const*>,true>,std::allocator<std::__value_type<void const*,boost::detail::tss_data_node>>>::erase(
          v4,
          v6);
    }
  }
}


// Address: 0x28450d0 | Name: _ZN5boost6detail12set_tss_dataEPKvNS_10shared_ptrINS0_20tss_cleanup_functionEEEPvb
void __fastcall boost::detail::set_tss_data(
        const void *key,
        boost::shared_ptr<boost::detail::tss_cleanup_function>_0 func,
        void *tss_data,
        bool cleanup_existing)
{
  char v4; // r12
  boost::detail::sp_counted_base *pi; // r14
  _QWORD *v7; // rax
  _QWORD *v8; // rcx
  _QWORD *v9; // rax
  _QWORD *v10; // rbp
  volatile signed __int32 *v11; // rbp
  __int64 v12; // rdi
  int (**v13)(void); // rax
  int (**v14)(void); // rcx
  volatile signed __int32 *v15; // rbx
  _QWORD v16[7]; // [rsp+0h] [rbp-38h] BYREF

  v4 = (char)tss_data;
  pi = func.pn.pi_;
  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v7 = pthread_getspecific(dword_2CE56E4);
  if ( !v7 )
    goto LABEL_35;
  v8 = (_QWORD *)v7[41];
  if ( !v8 )
    goto LABEL_35;
  v9 = v7 + 41;
  v10 = v9;
  do
  {
    if ( v8[4] >= (unsigned __int64)key )
      v10 = v8;
    v8 = (_QWORD *)v8[v8[4] < (unsigned __int64)key];
  }
  while ( v8 );
  if ( v10 != v9 && v10[4] <= (unsigned __int64)key )
  {
    if ( v4 )
    {
      v12 = v10[5];
      if ( v12 )
      {
        if ( v10[7] )
          (*(void (__fastcall **)(__int64))(*(_QWORD *)v12 + 16LL))(v12);
      }
    }
    v13 = func.px->_vptr$tss_cleanup_function;
    if ( pi || v13 )
    {
      v14 = func.px[1]._vptr$tss_cleanup_function;
      if ( v14 )
        _InterlockedAdd((volatile signed __int32 *)v14 + 2, 1u);
      v10[5] = v13;
      v15 = (volatile signed __int32 *)v10[6];
      v10[6] = v14;
      if ( v15 )
      {
        if ( !_InterlockedSub(v15 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
          if ( !_InterlockedSub(v15 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
        }
      }
      v10[7] = pi;
    }
    else
    {
      boost::detail::erase_tss_node(key);
    }
  }
  else
  {
LABEL_35:
    if ( pi || func.px->_vptr$tss_cleanup_function )
    {
      v16[0] = func.px->_vptr$tss_cleanup_function;
      v11 = (volatile signed __int32 *)func.px[1]._vptr$tss_cleanup_function;
      v16[1] = v11;
      if ( v11 )
        _InterlockedAdd(v11 + 2, 1u);
      boost::detail::add_new_tss_node(
        (unsigned __int64)key,
        (boost::shared_ptr<boost::detail::tss_cleanup_function>_0)__PAIR128__((unsigned __int64)pi, v16),
        v8);
      if ( v11 && !_InterlockedSub(v11 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
        if ( !_InterlockedSub(v11 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
      }
    }
  }
}


// Address: 0x28452b0 | Name: _ZN5boost25notify_all_at_thread_exitERNS_18condition_variableENS_11unique_lockINS_5mutexEEE
void __fastcall boost::notify_all_at_thread_exit(boost::condition_variable *cond, boost::unique_lock<boost::mutex> lk)
{
  void *v2; // rax
  __int64 align; // rdx

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v2 = pthread_getspecific(dword_2CE56E4);
  if ( v2 )
  {
    align = lk.m->m.__align;
    lk.m->m.__align = 0;
    lk.m->m.__size[8] = 0;
    (*(void (__fastcall **)(void *, boost::condition_variable *, __int64))(*(_QWORD *)v2 + 24LL))(v2, cond, align);
  }
}


// Address: 0x2845330 | Name: _ZN5boost6detail25make_ready_at_thread_exitENS_10shared_ptrINS0_17shared_state_baseEEE
void __fastcall boost::detail::make_ready_at_thread_exit(boost::shared_ptr<boost::detail::shared_state_base> as)
{
  _QWORD *v1; // rax
  int (**v2)(void); // rdx
  boost::detail::sp_counted_base *px; // rcx
  int (***v4)(void); // rcx
  boost::detail::sp_counted_base *pi; // rdx
  boost::detail::sp_counted_base *v6; // rbx
  boost::shared_ptr<boost::detail::shared_state_base> __x; // [rsp+8h] [rbp-20h] BYREF

  if ( boost::thread_detail::enter_once_region(&stru_2CE56E0) )
  {
    as.pn.pi_ = (boost::detail::sp_counted_base *)boost::detail::`anonymous namespace'::tls_destructor;
    pthread_key_create(&dword_2CE56E4, boost::detail::`anonymous namespace'::tls_destructor);
    boost::thread_detail::commit_once_region(&stru_2CE56E0);
  }
  v1 = pthread_getspecific(dword_2CE56E4);
  if ( v1 )
  {
    v2 = as.px->_vptr$shared_state_base;
    __x.px = (boost::shared_ptr<boost::detail::shared_state_base>::element_type *)as.px->_vptr$shared_state_base;
    px = (boost::detail::sp_counted_base *)as.px->weak_this_.px;
    __x.pn.pi_ = px;
    if ( px )
      _InterlockedAdd(&px->use_count_, 1u);
    v4 = (int (***)(void))v1[49];
    if ( v4 == (int (***)(void))v1[50] )
    {
      as.pn.pi_ = (boost::detail::sp_counted_base *)&__x;
      std::vector<boost::shared_ptr<boost::detail::shared_state_base>>::__push_back_slow_path<boost::shared_ptr<boost::detail::shared_state_base> const&>(
        (std::vector<boost::shared_ptr<boost::detail::shared_state_base>> *)(v1 + 48),
        &__x);
    }
    else
    {
      *v4 = v2;
      pi = __x.pn.pi_;
      v4[1] = (int (**)(void))__x.pn.pi_;
      if ( pi )
      {
        _InterlockedAdd(&pi->use_count_, 1u);
        v4 = (int (***)(void))v1[49];
      }
      v1[49] = v4 + 2;
    }
    v6 = __x.pn.pi_;
    if ( __x.pn.pi_ && !_InterlockedSub(&__x.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        as.pn.pi_);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
  }
}


// Address: 0x2845460 | Name: _ZN5boost6detail12_GLOBAL__N_114tls_destructorEPv
void __fastcall boost::detail::`anonymous namespace'::tls_destructor(void *data)
{
  __int64 v1; // rdx
  std::__tree<std::__value_type<const void *,boost::detail::tss_data_node>,std::__map_value_compare<const void *,std::__value_type<const void *,boost::detail::tss_data_node>,std::less<const void *>,true>,std::allocator<std::__value_type<const void *,boost::detail::tss_data_node> > > *v3; // r14
  char *v4; // r12
  _QWORD *v5; // rbx
  _QWORD *p_left; // rax
  std::__tree_end_node<std::__tree_node_base<void *> *> *begin_node; // rbx
  std::__tree<std::__value_type<const void *,boost::detail::tss_data_node>,std::__map_value_compare<const void *,std::__value_type<const void *,boost::detail::tss_data_node>,std::less<const void *>,true>,std::allocator<std::__value_type<const void *,boost::detail::tss_data_node> > >::const_iterator v8; // r13
  std::__tree_end_node<std::__tree_node_base<void *> *> *p_parent; // rcx
  std::__tree_node_base<void *> *left; // rcx
  bool v11; // zf
  __int64 v12; // rdi
  __int64 v13; // rsi
  volatile signed __int32 *v14; // rbx

  if ( data )
  {
    v3 = (std::__tree<std::__value_type<const void *,boost::detail::tss_data_node>,std::__map_value_compare<const void *,std::__value_type<const void *,boost::detail::tss_data_node>,std::less<const void *>,true>,std::allocator<std::__value_type<const void *,boost::detail::tss_data_node> > > *)((char *)data + 320);
    v4 = (char *)data + 328;
    while ( 1 )
    {
      v5 = (_QWORD *)*((_QWORD *)data + 39);
      if ( !*((_QWORD *)data + 42) )
        break;
      while ( v5 )
      {
LABEL_4:
        *((_QWORD *)data + 39) = v5[1];
        if ( *v5 )
        {
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v5 + 16LL))(*v5);
          if ( *v5 )
            (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v5 + 8LL))(*v5);
        }
        operator delete(v5);
        v5 = (_QWORD *)*((_QWORD *)data + 39);
      }
      p_left = &v3->__begin_node_->__left_;
      if ( (char *)v3->__begin_node_ != v4 )
      {
        begin_node = v3->__begin_node_;
        do
        {
          v8.__ptr_ = begin_node;
          p_parent = (std::__tree_end_node<std::__tree_node_base<void *> *> *)p_left[1];
          if ( p_parent )
          {
            do
            {
              begin_node = p_parent;
              p_parent = p_parent->__left_;
            }
            while ( p_parent );
          }
          else
          {
            begin_node = (std::__tree_end_node<std::__tree_node_base<void *> *> *)p_left[2];
            if ( begin_node->__left_ != (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)p_left )
            {
              p_parent = (std::__tree_end_node<std::__tree_node_base<void *> *> *)(p_left + 2);
              do
              {
                left = p_parent->__left_;
                begin_node = left->__parent_;
                v11 = begin_node->__left_ == left;
                p_parent = (std::__tree_end_node<std::__tree_node_base<void *> *> *)&left->__parent_;
              }
              while ( !v11 );
            }
          }
          v12 = p_left[5];
          if ( v12 )
          {
            v13 = p_left[7];
            if ( v13 )
              (*(void (__fastcall **)(__int64, __int64, __int64, std::__tree_end_node<std::__tree_node_base<void *> *> *))(*(_QWORD *)v12 + 16LL))(
                v12,
                v13,
                v1,
                p_parent);
          }
          std::__tree<std::__value_type<void const*,boost::detail::tss_data_node>,std::__map_value_compare<void const*,std::__value_type<void const*,boost::detail::tss_data_node>,std::less<void const*>,true>,std::allocator<std::__value_type<void const*,boost::detail::tss_data_node>>>::erase(
            v3,
            v8);
          p_left = &begin_node->__left_;
        }
        while ( begin_node != (std::__tree_end_node<std::__tree_node_base<void *> *> *)v4 );
      }
    }
    if ( v5 )
      goto LABEL_4;
    v14 = (volatile signed __int32 *)*((_QWORD *)data + 4);
    *(_OWORD *)((char *)data + 24) = 0;
    if ( v14 && !_InterlockedSub(v14 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
      if ( !_InterlockedSub(v14 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
    }
  }
}


// Address: 0x2845c10 | Name: _ZN5boost6detail26externally_launched_threadD2Ev
void __fastcall boost::detail::externally_launched_thread::~externally_launched_thread(
        boost::detail::externally_launched_thread *this)
{
  __int64 v1; // r15
  __int64 i; // rbx
  volatile signed __int32 *v3; // r12

  *(_QWORD *)this = off_29CFEA8;
  v1 = *((_QWORD *)this + 48);
  *((_QWORD *)this + 46) = *((_QWORD *)this + 45);
  for ( i = *((_QWORD *)this + 49); v1 != i; i -= 16 )
  {
    v3 = *(volatile signed __int32 **)(i - 8);
    if ( v3 )
    {
      if ( !_InterlockedSub(v3 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
        if ( !_InterlockedSub(v3 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      }
    }
  }
  *((_QWORD *)this + 49) = v1;
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x2845cb0 | Name: _ZN5boost6detail26externally_launched_threadD0Ev
void __fastcall boost::detail::externally_launched_thread::~externally_launched_thread(
        boost::detail::externally_launched_thread *this)
{
  __int64 v1; // r15
  __int64 i; // rbx
  volatile signed __int32 *v3; // r12

  *(_QWORD *)this = off_29CFEA8;
  v1 = *((_QWORD *)this + 48);
  *((_QWORD *)this + 46) = *((_QWORD *)this + 45);
  for ( i = *((_QWORD *)this + 49); v1 != i; i -= 16 )
  {
    v3 = *(volatile signed __int32 **)(i - 8);
    if ( v3 )
    {
      if ( !_InterlockedSub(v3 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
        if ( !_InterlockedSub(v3 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
      }
    }
  }
  *((_QWORD *)this + 49) = v1;
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x2845d60 | Name: _ZN5boost6detail26externally_launched_thread3runEv
void __fastcall boost::detail::externally_launched_thread::run(boost::detail::externally_launched_thread *this)
{
  ;
}


// Address: 0x2845d70 | Name: _ZN5boost6detail26externally_launched_thread25notify_all_at_thread_exitEPNS_18condition_variableEPNS_5mutexE
void __fastcall boost::detail::externally_launched_thread::notify_all_at_thread_exit(
        boost::detail::externally_launched_thread *this,
        boost::condition_variable *a2,
        boost::mutex *a3)
{
  ;
}


// Address: 0x2845f30 | Name: _GLOBAL__sub_I_thread.cpp
void __cdecl GLOBAL__sub_I_thread_cpp()
{
  qword_2CE56C8 = (__int64)boost::system::generic_category();
  qword_2CE56D0 = (__int64)boost::system::generic_category();
  qword_2CE56D8 = (__int64)boost::system::system_category();
}


