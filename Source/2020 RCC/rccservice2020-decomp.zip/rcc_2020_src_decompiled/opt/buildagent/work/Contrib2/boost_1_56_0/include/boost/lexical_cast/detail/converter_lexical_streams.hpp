// Address: 0x159c090 | Name: _ZN5boost6detail27lexical_istream_limited_srcIcNSt3__111char_traitsIcEELb1ELm2EEC2Ev
void __fastcall boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2ul>::lexical_istream_limited_src(
        boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2> *this)
{
  *(_QWORD *)this = &off_2876B38;
  *((_QWORD *)this + 14) = &off_2876B60;
  std::ios_base::init(
    (boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2> *)((char *)this + 112),
    (char *)this + 8);
  *((_QWORD *)this + 31) = 0;
  *((_DWORD *)this + 64) = -1;
  *(_QWORD *)this = &off_2876AC8;
  *((_QWORD *)this + 14) = off_2876AF0;
  std::streambuf::basic_streambuf((char *)this + 8);
  *((_QWORD *)this + 1) = &off_28753A8;
  *(_OWORD *)((char *)this + 88) = 0;
  *(_OWORD *)((char *)this + 72) = 0;
  *((_DWORD *)this + 26) = 16;
  *((_QWORD *)this + 34) = (char *)this + 264;
  *((_QWORD *)this + 35) = (char *)this + 266;
}


// Address: 0x159c160 | Name: _ZN5boost6detail27lexical_istream_limited_srcIcNSt3__111char_traitsIcEELb1ELm2EE20shl_input_streamableIKN3RBX9HeapValueIlLi0EEEEEbRT_
bool __fastcall boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2ul>::shl_input_streamable<RBX::HeapValue<long,0> const>(
        boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2> *this,
        const RBX::HeapValue<long,0> *input)
{
  __int64 v2; // rax
  _QWORD *v3; // rax
  bool result; // al

  v2 = *(_QWORD *)(*(_QWORD *)this - 24LL);
  *(_DWORD *)((char *)this + v2 + 36) = 1;
  std::ios_base::clear(
    (boost::detail::lexical_istream_limited_src<char,std::char_traits<char>,true,2> *)((char *)this + v2),
    *(_DWORD *)((char *)this + v2 + 32));
  v3 = (_QWORD *)std::ostream::operator<<(
                   this,
                   ((unsigned __int64)(input->storage.px->storage.asRaw[1] - (unsigned int)input->storage.px) << 32)
                 | (input->storage.px->storage.asRaw[0] - (unsigned int)input->storage.px));
  result = (*(_DWORD *)((_BYTE *)v3 + *(_QWORD *)(*v3 - 24LL) + 32) & 5) == 0;
  *((_OWORD *)this + 17) = *((_OWORD *)this + 3);
  return result;
}


