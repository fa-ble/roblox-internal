// Address: 0xdcb6e0 | Name: _ZN5boost18condition_variableC2Ev
void __fastcall boost::condition_variable::condition_variable(boost::condition_variable *this)
{
  int v1; // eax
  int v2; // eax
  int v3; // ebp
  const boost::system::error_category *v4; // rbx
  int v5; // ebp
  const boost::system::error_category *v6; // rbx
  _QWORD v7[2]; // [rsp+8h] [rbp-50h] BYREF
  int v8; // [rsp+18h] [rbp-40h]
  const boost::system::error_category *v9; // [rsp+20h] [rbp-38h]
  __int128 v10; // [rsp+28h] [rbp-30h]
  void *ptr; // [rsp+38h] [rbp-20h]

  v1 = pthread_mutex_init(&this->internal_mutex, 0);
  if ( v1 )
  {
    v3 = v1;
    v4 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)v7,
      "boost::condition_variable::condition_variable() constructor failed in pthread_mutex_init");
    v8 = v3;
    v9 = v4;
    v10 = 0;
    ptr = 0;
    v7[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v7);
  }
  v2 = pthread_cond_init(&this->cond, 0);
  if ( v2 )
  {
    v5 = v2;
    pthread_mutex_destroy(&this->internal_mutex);
    v6 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)v7,
      "boost::condition_variable::condition_variable() constructor failed in pthread_cond_init");
    v8 = v5;
    v9 = v6;
    v10 = 0;
    ptr = 0;
    v7[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v7);
  }
}


// Address: 0x12044a0 | Name: _ZN5boost18condition_variableD2Ev
void __fastcall boost::condition_variable::~condition_variable(boost::condition_variable *this)
{
  while ( pthread_mutex_destroy(&this->internal_mutex) == 4 )
    ;
  while ( pthread_cond_destroy(&this->cond) == 4 )
    ;
}


