// Address: 0xf1c700 | Name: _ZN5boost12shared_mutexC2Ev
void __fastcall boost::shared_mutex::shared_mutex(boost::shared_mutex *this)
{
  this->state.exclusive_waiting_blocked = 0;
  *(_WORD *)&this->state.exclusive = 0;
  this->state.shared_count = 0;
  boost::mutex::mutex(&this->state_change);
  boost::condition_variable::condition_variable(&this->shared_cond);
  boost::condition_variable::condition_variable(&this->exclusive_cond);
  boost::condition_variable::condition_variable(&this->upgrade_cond);
}


// Address: 0xf1c890 | Name: _ZN5boost12shared_mutexD2Ev
void __fastcall boost::shared_mutex::~shared_mutex(boost::shared_mutex *this)
{
  while ( pthread_mutex_destroy(&this->upgrade_cond.internal_mutex) == 4 )
    ;
  while ( pthread_cond_destroy(&this->upgrade_cond.cond) == 4 )
    ;
  while ( pthread_mutex_destroy(&this->exclusive_cond.internal_mutex) == 4 )
    ;
  while ( pthread_cond_destroy(&this->exclusive_cond.cond) == 4 )
    ;
  while ( pthread_mutex_destroy(&this->shared_cond.internal_mutex) == 4 )
    ;
  while ( pthread_cond_destroy(&this->shared_cond.cond) == 4 )
    ;
  while ( pthread_mutex_destroy(&this->state_change.m) == 4 )
    ;
}


// Address: 0xf1e000 | Name: _ZN5boost12shared_mutex11lock_sharedEv
void __fastcall boost::shared_mutex::lock_shared(boost::shared_mutex *this)
{
  boost::this_thread::disable_interruption v1; // [rsp+8h] [rbp-30h] BYREF
  boost::unique_lock<boost::mutex> m; // [rsp+10h] [rbp-28h] BYREF

  boost::this_thread::disable_interruption::disable_interruption(&v1);
  m.m = &this->state_change;
  m.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&m);
  while ( this->state.exclusive || this->state.exclusive_waiting_blocked )
    boost::condition_variable::wait(&this->shared_cond, &m);
  ++this->state.shared_count;
  if ( m.is_locked )
    boost::mutex::unlock(m.m);
  boost::this_thread::disable_interruption::~disable_interruption(&v1);
}


// Address: 0xf1e0c0 | Name: _ZN5boost12shared_mutex13unlock_sharedEv
void __fastcall boost::shared_mutex::unlock_shared(boost::shared_mutex *this)
{
  boost::unique_lock<boost::mutex> v2; // [rsp+8h] [rbp-20h] BYREF

  v2.m = &this->state_change;
  v2.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v2);
  if ( this->state.shared_count-- != 1 )
  {
    if ( !v2.is_locked )
      return;
LABEL_8:
    boost::mutex::unlock(v2.m);
    return;
  }
  if ( this->state.upgrade )
  {
    *(_WORD *)&this->state.exclusive = 1;
    boost::unique_lock<boost::mutex>::unlock(&v2);
    pthread_mutex_lock(&this->upgrade_cond.internal_mutex);
    pthread_cond_signal(&this->upgrade_cond.cond);
    pthread_mutex_unlock(&this->upgrade_cond.internal_mutex);
  }
  else
  {
    this->state.exclusive_waiting_blocked = 0;
    boost::unique_lock<boost::mutex>::unlock(&v2);
  }
  pthread_mutex_lock(&this->exclusive_cond.internal_mutex);
  pthread_cond_signal(&this->exclusive_cond.cond);
  pthread_mutex_unlock(&this->exclusive_cond.internal_mutex);
  pthread_mutex_lock(&this->shared_cond.internal_mutex);
  pthread_cond_broadcast(&this->shared_cond.cond);
  pthread_mutex_unlock(&this->shared_cond.internal_mutex);
  if ( v2.is_locked )
    goto LABEL_8;
}


// Address: 0xf20380 | Name: _ZN5boost12shared_mutex12lock_upgradeEv
void __fastcall boost::shared_mutex::lock_upgrade(boost::shared_mutex *this)
{
  boost::this_thread::disable_interruption v1; // [rsp+8h] [rbp-30h] BYREF
  boost::unique_lock<boost::mutex> m; // [rsp+10h] [rbp-28h] BYREF

  boost::this_thread::disable_interruption::disable_interruption(&v1);
  m.m = &this->state_change;
  m.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&m);
  while ( this->state.exclusive || this->state.exclusive_waiting_blocked || this->state.upgrade )
    boost::condition_variable::wait(&this->shared_cond, &m);
  ++this->state.shared_count;
  this->state.upgrade = 1;
  if ( m.is_locked )
    boost::mutex::unlock(m.m);
  boost::this_thread::disable_interruption::~disable_interruption(&v1);
}


// Address: 0xf20460 | Name: _ZN5boost12shared_mutex14unlock_upgradeEv
void __fastcall boost::shared_mutex::unlock_upgrade(boost::shared_mutex *this)
{
  boost::unique_lock<boost::mutex> v2; // [rsp+8h] [rbp-20h] BYREF

  v2.m = &this->state_change;
  v2.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v2);
  this->state.upgrade = 0;
  if ( this->state.shared_count-- == 1 )
  {
    this->state.exclusive_waiting_blocked = 0;
    pthread_mutex_lock(&this->exclusive_cond.internal_mutex);
    pthread_cond_signal(&this->exclusive_cond.cond);
    pthread_mutex_unlock(&this->exclusive_cond.internal_mutex);
  }
  pthread_mutex_lock(&this->shared_cond.internal_mutex);
  pthread_cond_broadcast(&this->shared_cond.cond);
  pthread_mutex_unlock(&this->shared_cond.internal_mutex);
  if ( v2.is_locked )
    boost::mutex::unlock(v2.m);
}


// Address: 0xf20500 | Name: _ZN5boost12shared_mutex23unlock_upgrade_and_lockEv
void __fastcall boost::shared_mutex::unlock_upgrade_and_lock(boost::shared_mutex *this)
{
  boost::this_thread::disable_interruption v2; // [rsp+8h] [rbp-30h] BYREF
  boost::unique_lock<boost::mutex> m; // [rsp+10h] [rbp-28h] BYREF

  boost::this_thread::disable_interruption::disable_interruption(&v2);
  m.m = &this->state_change;
  m.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&m);
  if ( this->state.shared_count-- != 1 )
  {
    do
      boost::condition_variable::wait(&this->upgrade_cond, &m);
    while ( this->state.shared_count );
  }
  *(_WORD *)&this->state.exclusive = 1;
  if ( m.is_locked )
    boost::mutex::unlock(m.m);
  boost::this_thread::disable_interruption::~disable_interruption(&v2);
}


// Address: 0xf205c0 | Name: _ZN5boost12shared_mutex23unlock_and_lock_upgradeEv
void __fastcall boost::shared_mutex::unlock_and_lock_upgrade(boost::shared_mutex *this)
{
  boost::unique_lock<boost::mutex> v1; // [rsp+8h] [rbp-20h] BYREF

  v1.m = &this->state_change;
  v1.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v1);
  *(_WORD *)&this->state.exclusive = 256;
  ++this->state.shared_count;
  this->state.exclusive_waiting_blocked = 0;
  pthread_mutex_lock(&this->exclusive_cond.internal_mutex);
  pthread_cond_signal(&this->exclusive_cond.cond);
  pthread_mutex_unlock(&this->exclusive_cond.internal_mutex);
  pthread_mutex_lock(&this->shared_cond.internal_mutex);
  pthread_cond_broadcast(&this->shared_cond.cond);
  pthread_mutex_unlock(&this->shared_cond.internal_mutex);
  if ( v1.is_locked )
    boost::mutex::unlock(v1.m);
}


// Address: 0xf22e80 | Name: _ZN5boost12shared_mutex4lockEv
void __fastcall boost::shared_mutex::lock(boost::shared_mutex *this)
{
  boost::this_thread::disable_interruption v1; // [rsp+8h] [rbp-30h] BYREF
  boost::unique_lock<boost::mutex> m; // [rsp+10h] [rbp-28h] BYREF

  boost::this_thread::disable_interruption::disable_interruption(&v1);
  m.m = &this->state_change;
  m.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&m);
  while ( this->state.shared_count || this->state.exclusive )
  {
    this->state.exclusive_waiting_blocked = 1;
    boost::condition_variable::wait(&this->exclusive_cond, &m);
  }
  this->state.exclusive = 1;
  if ( m.is_locked )
    boost::mutex::unlock(m.m);
  boost::this_thread::disable_interruption::~disable_interruption(&v1);
}


