// Address: 0xe3fab0 | Name: _ZN5boost15program_options19options_descriptionD2Ev
void __fastcall boost::program_options::options_description::~options_description(
        boost::program_options::options_description *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // r12
  void *v5; // rdi
  void *v6; // rdi
  __int64 v7; // r15
  __int64 v8; // rbx
  volatile signed __int32 *v9; // r12
  void *v10; // rdi

  v2 = *((_QWORD *)this + 10);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 11);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 10);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 )
        {
          if ( !_InterlockedSub(v4 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
            if ( !_InterlockedSub(v4 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
          }
        }
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)this + 10);
    }
    *((_QWORD *)this + 11) = v2;
    operator delete(v5);
  }
  v6 = (void *)*((_QWORD *)this + 7);
  if ( v6 )
    operator delete(v6);
  v7 = *((_QWORD *)this + 4);
  if ( v7 )
  {
    v8 = *((_QWORD *)this + 5);
    if ( v8 == v7 )
    {
      v10 = (void *)*((_QWORD *)this + 4);
    }
    else
    {
      do
      {
        v9 = *(volatile signed __int32 **)(v8 - 8);
        if ( v9 )
        {
          if ( !_InterlockedSub(v9 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
            if ( !_InterlockedSub(v9 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
          }
        }
        v8 -= 16;
      }
      while ( v7 != v8 );
      v10 = (void *)*((_QWORD *)this + 4);
    }
    *((_QWORD *)this + 5) = v7;
    operator delete(v10);
  }
  if ( (*(_BYTE *)this & 1) != 0 )
    operator delete(*((void **)this + 2));
}


// Address: 0xe5fa30 | Name: _ZN5boost15program_options19options_descriptionC2ERKS1_
void __fastcall boost::program_options::options_description::options_description(
        boost::program_options::options_description *this,
        const boost::program_options::options_description *a2)
{
  __int64 v3; // rbp
  unsigned __int64 v4; // rbp
  _QWORD *v5; // rax
  _QWORD *v6; // r15
  const void *v7; // rbp
  __int64 v8; // r13
  unsigned __int64 v9; // r14
  __int64 v10; // r13
  struct _Unwind_Exception *v11; // r15
  char *v12; // r13
  char *v13; // rbp
  volatile signed __int32 *v14; // rbx
  void *v15; // rdi
  void **v16; // [rsp+10h] [rbp-38h]

  std::string::basic_string(this, a2);
  *((_QWORD *)this + 3) = *((_QWORD *)a2 + 3);
  v16 = (void **)((char *)this + 32);
  std::vector<boost::shared_ptr<boost::program_options::option_description>>::vector(
    (boost::program_options::options_description *)((char *)this + 32),
    (const boost::program_options::options_description *)((char *)a2 + 32));
  *(_OWORD *)((char *)this + 56) = 0;
  *((_QWORD *)this + 9) = 0;
  v3 = *((_QWORD *)a2 + 8);
  if ( !v3 )
    goto LABEL_6;
  if ( v3 < 0 )
  {
    v11 = (struct _Unwind_Exception *)std::__vector_base_common<true>::__throw_length_error((char *)this + 56);
    v12 = (char *)*v16;
    if ( *v16 )
    {
      v13 = (char *)*((_QWORD *)this + 5);
      if ( v13 == v12 )
      {
        v15 = *v16;
      }
      else
      {
        do
        {
          v14 = (volatile signed __int32 *)*((_QWORD *)v13 - 1);
          if ( v14 )
          {
            if ( !_InterlockedSub(v14 + 2, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
              if ( !_InterlockedSub(v14 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
            }
          }
          v13 -= 16;
        }
        while ( v12 != v13 );
        v15 = *v16;
      }
      *((_QWORD *)this + 5) = v12;
      operator delete(v15);
      if ( (*(_BYTE *)this & 1) == 0 )
LABEL_20:
        _Unwind_Resume(v11);
    }
    else if ( (*(_BYTE *)this & 1) == 0 )
    {
      goto LABEL_20;
    }
    operator delete(*((void **)this + 2));
    goto LABEL_20;
  }
  v4 = (unsigned __int64)(v3 - 1) >> 6;
  v5 = operator new(8 * v4 + 8);
  v6 = v5;
  *((_QWORD *)this + 7) = v5;
  *((_QWORD *)this + 8) = 0;
  *((_QWORD *)this + 9) = v4 + 1;
  v7 = (const void *)*((_QWORD *)a2 + 7);
  v8 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v8;
  if ( v8 > 0 )
  {
    v9 = (unsigned __int64)v8 >> 6;
    memmove(v5, v7, 8 * ((unsigned __int64)v8 >> 6));
    v10 = v8 & 0x3F;
    if ( v10 )
      v6[v9] = (0xFFFFFFFFFFFFFFFFLL >> (64 - (unsigned __int8)v10)) & *((_QWORD *)v7 + v9)
             | v6[v9] & ~(0xFFFFFFFFFFFFFFFFLL >> (64 - (unsigned __int8)v10));
  }
LABEL_6:
  std::vector<boost::shared_ptr<boost::program_options::options_description>>::vector(
    (boost::program_options::options_description *)((char *)this + 80),
    (const boost::program_options::options_description *)((char *)a2 + 80));
}


