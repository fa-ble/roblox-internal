// Address: 0x2607300 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINSA_6config15asio_tls_client16transport_configEEEFvNS8_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeEEJNSI_ISH_EERSR_RSX_RKNS8_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEESZ_EES1C_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v4; // [rsp+0h] [rbp-108h] BYREF
  unsigned __int64 v5; // [rsp+E8h] [rbp-20h]

  v5 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &v4,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code>(
      &v4.handler_.handler_,
      &v4.handler_.arg1_);
    _mm_sfence();
  }
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler(&v4);
}


// Address: 0x2607bb0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config15asio_tls_client16transport_configEEEFvNS4_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISH_EENS0_22deadline_timer_serviceISH_SJ_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNSE_ISD_EERSN_RST_RKNS4_12placeholders4__phILi1EEEEEESV_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESX_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v7; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr v8; // [rsp+8h] [rbp-B0h] BYREF
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> v9; // [rsp+20h] [rbp-98h] BYREF
  unsigned __int64 v10; // [rsp+98h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  v8.h = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)&base[1].func_;
  v8.v = base;
  v8.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *)base;
  *(_OWORD *)&v9.handler_.__f_ = *(_OWORD *)&base[1].func_;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)&base[2].next_;
  *(_OWORD *)&base[2].next_ = 0;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[2].task_result_;
  *(_OWORD *)&base[2].task_result_ = 0;
  v5 = *(boost::asio::detail::operation **)&base[4].task_result_;
  if ( v5 )
  {
    if ( &base[3].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))v5->next_[1].next_)(
        v5,
        &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = *(std::function<void (const std::error_code &)>::__base **)&base[4].task_result_;
      *(_QWORD *)&base[4].task_result_ = 0;
    }
  }
  else
  {
    v9.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v9.arg1_ = *(boost::system::error_code *)&base[5].func_;
  v8.h = &v9;
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v8);
  if ( owner )
  {
    boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(&v9);
    _mm_sfence();
  }
  if ( &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v7 = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v8);
}


// Address: 0x2607f40 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config15asio_tls_client16transport_configEEEFvNS4_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISH_EENS0_22deadline_timer_serviceISH_SJ_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNSE_ISD_EERSN_RST_RKNS4_12placeholders4__phILi1EEEEEESV_EEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *p; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *f; // rdi
  volatile signed __int64 *cntrl; // r15
  volatile signed __int64 *v5; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v7; // rax
  _QWORD *v8; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    v5 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v7 = __readfsqword(0xFFFFFFD8);
    if ( v7 && (v8 = *(_QWORD **)(v7 + 8)) != 0 && !*v8 )
    {
      *v = v[144];
      *v8 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x260faf0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_15wrapped_handlerINS0_10io_service6strandENSt3__18functionIFvvEEENS1_26is_continuation_if_runningEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationERKNS_6system10error_codeEm
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v4; // rbx
  boost::asio::detail::operation *func; // rdi
  boost::asio::detail::operation *v7; // rdi
  unsigned __int64 v8; // rax
  boost::asio::detail::operation **v9; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> v10; // [rsp+0h] [rbp-68h] BYREF
  unsigned __int64 v11; // [rsp+48h] [rbp-20h]

  v4 = base;
  v11 = __readfsqword(0x28u);
  v10.dispatcher_ = *(boost::asio::io_service::strand *)&base[1].func_;
  func = (boost::asio::detail::operation *)base[3].func_;
  if ( func )
  {
    if ( &base[2] != func )
    {
      v10.handler_.__f_ = (std::function<void ()>::__base *)base[3].func_;
      base[3].func_ = 0;
      goto LABEL_10;
    }
    v10.handler_.__f_ = (std::function<void ()>::__base *)&v10.handler_;
    base = (boost::asio::detail::operation *)&v10.handler_;
    ((void (__fastcall *)(boost::asio::detail::operation *, std::function<void ()> *, const boost::system::error_code *))func->next_[1].next_)(
      func,
      &v10.handler_,
      a3);
  }
  else
  {
    v10.handler_.__f_ = 0;
  }
  v7 = (boost::asio::detail::operation *)v4[3].func_;
  if ( &v4[2] == v7 )
  {
    v7->next_[1].func_((boost::asio::detail::task_io_service *)v7, base, a3, a4);
  }
  else if ( v7 )
  {
    (*(void (__fastcall **)(boost::asio::detail::operation *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&v7->next_[1].task_result_)(
      v7,
      base,
      a3,
      a4);
  }
LABEL_10:
  v8 = __readfsqword(0xFFFFFFD8);
  if ( !v8 || (v9 = *(boost::asio::detail::operation ***)(v8 + 8)) == 0 || *v9 )
  {
    operator delete(v4);
    if ( !owner )
      goto LABEL_15;
    goto LABEL_14;
  }
  LOBYTE(v4->next_) = v4[4].next_;
  *v9 = v4;
  if ( owner )
  {
LABEL_14:
    base = (boost::asio::detail::operation *)&v10;
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>(
      &v10,
      &v10);
    _mm_sfence();
  }
LABEL_15:
  if ( &v10.handler_ == (std::function<void ()> *)v10.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void ()>::__base *))v10.handler_.__f_->_vptr$__base + 4))(v10.handler_.__f_);
  }
  else if ( v10.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void ()>::__base *, boost::asio::detail::operation *))v10.handler_.__f_->_vptr$__base
     + 5))(
      v10.handler_.__f_,
      base);
  }
}


// Address: 0x2610290 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_15wrapped_handlerINS0_10io_service6strandENSt3__18functionIFvvEEENS1_26is_continuation_if_runningEEESA_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationERKNS_6system10error_codeEm
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,std::function<void ()(void)>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v4; // r12
  char *p_func; // rbx
  char *v7; // rdi
  char *v8; // rdi
  char *v9; // rdi
  unsigned __int64 v10; // rax
  boost::asio::detail::operation **v11; // rax
  boost::asio::detail::operation *func; // rdi
  _BYTE v13[32]; // [rsp+0h] [rbp-98h] BYREF
  _BYTE *v14; // [rsp+20h] [rbp-78h]
  boost::asio::io_service::strand v15; // [rsp+30h] [rbp-68h] BYREF
  std::function<void ()> handler; // [rsp+40h] [rbp-58h] BYREF
  unsigned __int64 v17; // [rsp+70h] [rbp-28h]

  v4 = base;
  v17 = __readfsqword(0x28u);
  p_func = (char *)&base[1].func_;
  v7 = *(char **)&base[2].task_result_;
  if ( v7 )
  {
    if ( p_func == v7 )
    {
      base = (boost::asio::detail::operation *)v13;
      v14 = v13;
      (*(void (__fastcall **)(char *, _BYTE *, const boost::system::error_code *, size_t))(*(_QWORD *)v7 + 24LL))(
        v7,
        v13,
        a3,
        a4);
    }
    else
    {
      v14 = *(_BYTE **)&base[2].task_result_;
      *(_QWORD *)&base[2].task_result_ = 0;
    }
  }
  else
  {
    v14 = 0;
  }
  v15 = (boost::asio::io_service::strand)*((_OWORD *)p_func + 3);
  v8 = (char *)*((_QWORD *)p_func + 12);
  if ( v8 )
  {
    if ( p_func + 64 == v8 )
    {
      handler.__f_ = (std::function<void ()>::__base *)&handler;
      base = (boost::asio::detail::operation *)&handler;
      (*(void (__fastcall **)(char *, std::function<void ()> *, const boost::system::error_code *, size_t))(*(_QWORD *)v8 + 24LL))(
        v8,
        &handler,
        a3,
        a4);
      func = (boost::asio::detail::operation *)v4[5].func_;
      if ( &v4[4] == func )
      {
        ((void (__fastcall *)(boost::asio::detail::operation *))func->next_[1].func_)(func);
      }
      else if ( func )
      {
        (*(void (__fastcall **)(boost::asio::detail::operation *))&func->next_[1].task_result_)(func);
      }
    }
    else
    {
      handler.__f_ = (std::function<void ()>::__base *)*((_QWORD *)p_func + 12);
      *((_QWORD *)p_func + 12) = 0;
    }
  }
  else
  {
    handler.__f_ = 0;
  }
  v9 = *(char **)&v4[2].task_result_;
  if ( p_func == v9 )
  {
    (*(void (__fastcall **)(char *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v9 + 32LL))(
      v9,
      base,
      a3,
      a4);
  }
  else if ( v9 )
  {
    (*(void (__fastcall **)(char *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v9 + 40LL))(
      v9,
      base,
      a3,
      a4);
  }
  v10 = __readfsqword(0xFFFFFFD8);
  if ( !v10 || (v11 = *(boost::asio::detail::operation ***)(v10 + 8)) == 0 || *v11 )
  {
    operator delete(v4);
    if ( !owner )
      goto LABEL_19;
    goto LABEL_18;
  }
  LOBYTE(v4->next_) = v4[6].next_;
  *v11 = v4;
  if ( owner )
  {
LABEL_18:
    boost::asio::io_service::strand::dispatch<std::function<void ()(void)>>(&v15, &handler);
    _mm_sfence();
  }
LABEL_19:
  if ( &handler == (std::function<void ()> *)handler.__f_ )
  {
    (*((void (__fastcall **)(std::function<void ()>::__base *))handler.__f_->_vptr$__base + 4))(handler.__f_);
  }
  else if ( handler.__f_ )
  {
    (*((void (**)(void))handler.__f_->_vptr$__base + 5))();
  }
  if ( v13 == v14 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v14 + 32LL))(v14);
  }
  else if ( v14 )
  {
    (*(void (**)(void))(*(_QWORD *)v14 + 40LL))();
  }
}


// Address: 0x26108a0 | Name: _ZN5boost4asio6detail18completion_handlerINSt3__18functionIFvvEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationERKNS_6system10error_codeEm
void __fastcall boost::asio::detail::completion_handler<std::function<void ()(void)>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v4; // rbx
  char *p_func; // r15
  char *v7; // rdi
  char *v8; // rdi
  unsigned __int64 v9; // rax
  boost::asio::detail::operation **v10; // rax
  _QWORD *exception; // rax
  _BYTE v12[32]; // [rsp+0h] [rbp-58h] BYREF
  _BYTE *v13; // [rsp+20h] [rbp-38h]
  unsigned __int64 v14; // [rsp+38h] [rbp-20h]

  v4 = base;
  v14 = __readfsqword(0x28u);
  p_func = (char *)&base[1].func_;
  v7 = *(char **)&base[2].task_result_;
  if ( v7 )
  {
    if ( p_func != v7 )
    {
      v13 = *(_BYTE **)&base[2].task_result_;
      *(_QWORD *)&base[2].task_result_ = 0;
      goto LABEL_10;
    }
    base = (boost::asio::detail::operation *)v12;
    v13 = v12;
    (*(void (__fastcall **)(char *, _BYTE *, const boost::system::error_code *, size_t))(*(_QWORD *)v7 + 24LL))(
      v7,
      v12,
      a3,
      a4);
  }
  else
  {
    v13 = 0;
  }
  v8 = *(char **)&v4[2].task_result_;
  if ( p_func == v8 )
  {
    (*(void (__fastcall **)(char *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v8 + 32LL))(
      v8,
      base,
      a3,
      a4);
  }
  else if ( v8 )
  {
    (*(void (__fastcall **)(char *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v8 + 40LL))(
      v8,
      base,
      a3,
      a4);
  }
LABEL_10:
  v9 = __readfsqword(0xFFFFFFD8);
  if ( v9 && (v10 = *(boost::asio::detail::operation ***)(v9 + 8)) != 0 && !*v10 )
  {
    LOBYTE(v4->next_) = v4[3].func_;
    *v10 = v4;
    if ( !owner )
      goto LABEL_16;
  }
  else
  {
    operator delete(v4);
    if ( !owner )
      goto LABEL_16;
  }
  if ( !v13 )
  {
    exception = __cxa_allocate_exception(8u);
    *exception = off_28852C8;
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::bad_function_call,
      (void (*)(void *))&std::exception::~exception);
  }
  (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v13 + 48LL))(v13);
  _mm_sfence();
LABEL_16:
  if ( v12 == v13 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v13 + 32LL))(v13);
  }
  else if ( v13 )
  {
    (*(void (**)(void))(*(_QWORD *)v13 + 40LL))();
  }
}


// Address: 0x2619e60 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config15asio_tls_client16transport_configEEEFvRKNS_6system10error_codeEmEJNS4_10shared_ptrISD_EERKNS4_12placeholders4__phILi1EEERKNSN_ILi2EEEEEESF_mEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESH_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r14
  volatile signed __int64 *next; // rbx
  unsigned __int64 v6; // rax
  boost::asio::detail::operation **v7; // rax
  void (__fastcall *v8)(size_t *, __int128 *, boost::asio::detail::task_io_service_operation *, size_t); // rax
  size_t *v9; // r14
  __int128 v10; // [rsp+0h] [rbp-58h]
  __int128 v11; // [rsp+20h] [rbp-38h] BYREF
  boost::asio::detail::task_io_service_operation *v12; // [rsp+30h] [rbp-28h]

  v10 = *(_OWORD *)&base[1].next_;
  v4 = *(_QWORD *)&base[1].task_result_;
  next = (volatile signed __int64 *)base[2].next_;
  *(_OWORD *)&base[1].task_result_ = 0;
  v12 = base[3].next_;
  v11 = *(_OWORD *)&base[2].func_;
  if ( base )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(boost::asio::detail::operation ***)(v6 + 8);
      if ( v7 )
      {
        if ( !*v7 )
        {
          LOBYTE(a4) = base[3].func_;
          LOBYTE(base->next_) = a4;
          *v7 = base;
          if ( !owner )
            goto LABEL_10;
          goto LABEL_7;
        }
      }
    }
    operator delete(base);
  }
  if ( !owner )
    goto LABEL_10;
LABEL_7:
  base = (boost::asio::detail::operation *)&v11;
  v8 = (void (__fastcall *)(size_t *, __int128 *, boost::asio::detail::task_io_service_operation *, size_t))v10;
  v9 = (size_t *)(*((_QWORD *)&v10 + 1) + v4);
  if ( (v10 & 1) != 0 )
  {
    a4 = *v9;
    v8 = *(void (__fastcall **)(size_t *, __int128 *, boost::asio::detail::task_io_service_operation *, size_t))(*v9 + v10 - 1);
  }
  v8(v9, &v11, v12, a4);
  _mm_sfence();
LABEL_10:
  if ( next )
  {
    if ( !_InterlockedExchangeAdd64(next + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*next + 16))(
        next,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)next);
    }
  }
}


// Address: 0x2621ad0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSA_6config15asio_tls_client16transport_configEEEFvNS8_10shared_ptrINSC_10connectionISG_EEEENSI_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISO_EENS0_22deadline_timer_serviceISO_SQ_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS15_3tcpEEEEJPSH_RSL_RSU_RS10_RKNS8_12placeholders4__phILi1EEERKNS1G_ILi2EEEEEENS1_26is_continuation_if_runningEEES12_S18_EES1N_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES14_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > v4; // [rsp+0h] [rbp-148h] BYREF
  unsigned __int64 v5; // [rsp+128h] [rbp-20h]

  v5 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
    &v4,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&base[1].func_);
  if ( base )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&base[1].func_);
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
      &v4.handler_.handler_,
      &v4.handler_.arg1_,
      &v4.handler_.arg2_);
    _mm_sfence();
  }
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(&v4);
}


// Address: 0x26224c0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS6_6config15asio_tls_client16transport_configEEEFvNS4_10shared_ptrINS8_10connectionISC_EEEENSE_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS11_3tcpEEEEJPSD_RSH_RSQ_RSW_RKNS4_12placeholders4__phILi1EEERKNS1C_ILi2EEEEEESY_S14_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES10_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *p; // rbx
  boost::asio::detail::task_io_service_operation::func_type *p_func; // r12
  boost::asio::detail::operation *func; // rdi
  volatile signed __int64 *cntrl; // r12
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *f; // rdi
  volatile signed __int64 *v10; // r12
  volatile signed __int64 *v11; // rbx
  void *v; // rdi
  unsigned __int64 v13; // rax
  _QWORD *v14; // rax
  std::__shared_weak_count *v15; // rbx
  std::__shared_weak_count *v16; // rbx
  std::__shared_weak_count *v17; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr v18; // [rsp+8h] [rbp-E0h] BYREF
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > v19; // [rsp+20h] [rbp-C8h] BYREF
  unsigned __int64 v20; // [rsp+C0h] [rbp-28h]

  p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)base;
  v20 = __readfsqword(0x28u);
  p_func = &base[1].func_;
  v18.h = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&base[1].func_;
  v18.v = base;
  v18.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)base;
  *(_OWORD *)&v19.handler_.__f_ = *(_OWORD *)&base[1].func_;
  *(boost::asio::detail::operation *)&v19.handler_.__bound_args_.__base_.__value_ = base[2];
  *(_OWORD *)&base[2].func_ = 0;
  v19.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[3].next_;
  *(_OWORD *)&base[3].next_ = 0;
  func = (boost::asio::detail::operation *)base[5].func_;
  if ( func )
  {
    if ( &base[4] == func )
    {
      v19.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      base = (boost::asio::detail::operation *)&v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))func->next_[1].next_)(
        func,
        &v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
      p = v18.p;
    }
    else
    {
      v19.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[5].func_;
      base[5].func_ = 0;
    }
  }
  else
  {
    v19.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v19.arg1_ = (boost::system::error_code)*((_OWORD *)p_func + 7);
  v19.arg2_.values_ = (std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >)*((_OWORD *)p_func + 8);
  *((_OWORD *)p_func + 8) = 0;
  v19.arg2_.index_ = (size_t)p_func[18];
  v18.h = &v19;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.arg2_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*cntrl + 16))(
        cntrl,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      f->next_[1].func_((boost::asio::detail::task_io_service *)f, base, a3, a4);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&f->next_[1].task_result_)(
        f,
        base,
        a3,
        a4);
    }
    v10 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v10 && !_InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*v10 + 16))(
        v10,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v10);
    }
    v11 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v11 && !_InterlockedExchangeAdd64(v11 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*v11 + 16))(
        v11,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v11);
    }
    v18.p = 0;
  }
  v = v18.v;
  if ( v18.v )
  {
    v13 = __readfsqword(0xFFFFFFD8);
    if ( v13 && (v14 = *(_QWORD **)(v13 + 8)) != 0 && !*v14 )
    {
      LOBYTE(a4) = *((_BYTE *)v18.v + 192);
      *(_BYTE *)v18.v = a4;
      *v14 = v;
    }
    else
    {
      operator delete(v18.v);
    }
    v18.v = 0;
  }
  if ( owner )
  {
    boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(&v19);
    _mm_sfence();
  }
  v15 = v19.arg2_.values_.__cntrl_;
  if ( v19.arg2_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v19.arg2_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v15 + 16LL))(
      v15,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v15);
  }
  if ( &v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v19.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))v19.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(
      v19.handler_.__bound_args_.__base_.__value_.__f_,
      base,
      a3,
      a4);
  }
  else if ( v19.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))v19.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(
      v19.handler_.__bound_args_.__base_.__value_.__f_,
      base,
      a3,
      a4);
  }
  v16 = v19.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v19.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v19.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v16 + 16LL))(
      v16,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v16);
  }
  v17 = v19.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v19.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v19.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v17 + 16LL))(
      v17,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v17);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(&v18);
}


// Address: 0x2622880 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS6_6config15asio_tls_client16transport_configEEEFvNS4_10shared_ptrINS8_10connectionISC_EEEENSE_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS11_3tcpEEEEJPSD_RSH_RSQ_RSW_RKNS4_12placeholders4__phILi1EEERKNS1C_ILi2EEEEEESY_S14_EEE3ptrD2Ev
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(
        boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *p; // rbx
  volatile signed __int64 *cntrl; // r15
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *f; // rdi
  volatile signed __int64 *v5; // r15
  volatile signed __int64 *v6; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v8; // rax
  _QWORD *v9; // rax

  p = this->p;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.arg2_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))&f->next_[1].task_result_)(f);
    }
    v5 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
    }
    v6 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v6 && !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v8 = __readfsqword(0xFFFFFFD8);
    if ( v8 && (v9 = *(_QWORD **)(v8 + 8)) != 0 && !*v9 )
    {
      *v = v[192];
      *v9 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x2626050 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EENS6_23basic_resolver_iteratorIS7_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSI_6config15asio_tls_client16transport_configEEEFvNSG_10shared_ptrINSK_10connectionISO_EEEENSQ_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISW_EENS0_22deadline_timer_serviceISW_SY_EEEEEENSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJPSP_RST_RS12_RS18_RKNSG_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES1A_EES1O_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES1C_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *func; // rdi
  volatile signed __int64 *v6; // rbx
  volatile signed __int64 *v7; // rbx
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v9; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v10; // [rsp+0h] [rbp-168h] BYREF
  unsigned __int64 v11; // [rsp+148h] [rbp-20h]

  v11 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &v10,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op((boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[6]);
    func = (boost::asio::detail::operation *)base[5].func_;
    if ( &base[4] == func )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))func->next_[1].func_)(func);
    }
    else if ( func )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&func->next_[1].task_result_)(func);
    }
    v6 = (volatile signed __int64 *)base[3].func_;
    if ( v6 && !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    v7 = *(volatile signed __int64 **)&base[2].task_result_;
    if ( v7 && !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(v7);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      &v10.handler_.handler_,
      v10.handler_.arg1_,
      0);
    _mm_sfence();
  }
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&v10.handler_.handler_);
  if ( &v10.context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v10.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v10.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v10.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v10.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v10.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v10.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v10.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v9 = v10.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
      std::__shared_weak_count::__release_weak(v9);
    }
  }
}


// Address: 0x2626540 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EENS5_23basic_resolver_iteratorIS6_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSH_6config15asio_tls_client16transport_configEEEFvNSF_10shared_ptrINSJ_10connectionISN_EEEENSP_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISV_EENS0_22deadline_timer_serviceISV_SX_EEEEEENSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJPSO_RSS_RS11_RS17_RKNSF_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES19_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES1B_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  unsigned __int64 v4; // rax
  boost::asio::detail::operation **v5; // rax
  boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> v6; // [rsp+0h] [rbp-F8h] BYREF
  unsigned __int64 v7; // [rsp+D8h] [rbp-20h]

  v7 = __readfsqword(0x28u);
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    &v6.handler_,
    (boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[1].func_);
  v6.arg1_ = *(boost::system::error_code *)&base[9].func_;
  if ( base )
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op((boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[1].func_);
  v4 = __readfsqword(0xFFFFFFD8);
  if ( v4 )
  {
    v5 = *(boost::asio::detail::operation ***)(v4 + 8);
    if ( v5 )
    {
      if ( !*v5 )
      {
        LOBYTE(base->next_) = base[10].next_;
        *v5 = base;
        if ( !owner )
          goto LABEL_8;
        goto LABEL_7;
      }
    }
  }
  operator delete(base);
  if ( owner )
  {
LABEL_7:
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      &v6,
      &v6.handler_.handler_);
    _mm_sfence();
  }
LABEL_8:
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&v6.handler_);
}


// Address: 0x26269b0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS6_6config15asio_tls_client16transport_configEEEFvNS4_10shared_ptrINS8_10connectionISC_EEEENSE_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJPSD_RSH_RSQ_RSW_RKNS4_12placeholders4__phILi1EEEEEESY_NS0_2ip23basic_resolver_iteratorINS1D_3tcpEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES10_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *p; // rbx
  boost::asio::detail::task_io_service_operation::func_type *p_func; // r12
  boost::asio::detail::operation *func; // rdi
  volatile signed __int64 *cntrl; // r12
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *f; // rdi
  volatile signed __int64 *v10; // r12
  volatile signed __int64 *v11; // rbx
  void *v; // rdi
  unsigned __int64 v13; // rax
  _QWORD *v14; // rax
  std::__shared_weak_count *v15; // rbx
  std::__shared_weak_count *v16; // rbx
  std::__shared_weak_count *v17; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr v18; // [rsp+8h] [rbp-E0h] BYREF
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > v19; // [rsp+20h] [rbp-C8h] BYREF
  unsigned __int64 v20; // [rsp+C0h] [rbp-28h]

  p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)base;
  v20 = __readfsqword(0x28u);
  p_func = &base[1].func_;
  v18.h = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&base[1].func_;
  v18.v = base;
  v18.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)base;
  *(_OWORD *)&v19.handler_.__f_ = *(_OWORD *)&base[1].func_;
  *(boost::asio::detail::operation *)&v19.handler_.__bound_args_.__base_.__value_ = base[2];
  *(_OWORD *)&base[2].func_ = 0;
  v19.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[3].next_;
  *(_OWORD *)&base[3].next_ = 0;
  func = (boost::asio::detail::operation *)base[5].func_;
  if ( func )
  {
    if ( &base[4] == func )
    {
      v19.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      base = (boost::asio::detail::operation *)&v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))func->next_[1].next_)(
        func,
        &v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
      p = v18.p;
    }
    else
    {
      v19.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[5].func_;
      base[5].func_ = 0;
    }
  }
  else
  {
    v19.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v19.arg1_ = (boost::system::error_code)*((_OWORD *)p_func + 7);
  v19.arg2_.values_ = (std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >)*((_OWORD *)p_func + 8);
  *((_OWORD *)p_func + 8) = 0;
  v19.arg2_.index_ = (size_t)p_func[18];
  v18.h = &v19;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.arg2_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*cntrl + 16))(
        cntrl,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      f->next_[1].func_((boost::asio::detail::task_io_service *)f, base, a3, a4);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&f->next_[1].task_result_)(
        f,
        base,
        a3,
        a4);
    }
    v10 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v10 && !_InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*v10 + 16))(
        v10,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v10);
    }
    v11 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v11 && !_InterlockedExchangeAdd64(v11 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*v11 + 16))(
        v11,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v11);
    }
    v18.p = 0;
  }
  v = v18.v;
  if ( v18.v )
  {
    v13 = __readfsqword(0xFFFFFFD8);
    if ( v13 && (v14 = *(_QWORD **)(v13 + 8)) != 0 && !*v14 )
    {
      LOBYTE(a4) = *((_BYTE *)v18.v + 192);
      *(_BYTE *)v18.v = a4;
      *v14 = v;
    }
    else
    {
      operator delete(v18.v);
    }
    v18.v = 0;
  }
  if ( owner )
  {
    boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(&v19);
    _mm_sfence();
  }
  v15 = v19.arg2_.values_.__cntrl_;
  if ( v19.arg2_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v19.arg2_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v15 + 16LL))(
      v15,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v15);
  }
  if ( &v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v19.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))v19.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(
      v19.handler_.__bound_args_.__base_.__value_.__f_,
      base,
      a3,
      a4);
  }
  else if ( v19.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))v19.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(
      v19.handler_.__bound_args_.__base_.__value_.__f_,
      base,
      a3,
      a4);
  }
  v16 = v19.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v19.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v19.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v16 + 16LL))(
      v16,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v16);
  }
  v17 = v19.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v19.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v19.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v17 + 16LL))(
      v17,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v17);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(&v18);
}


// Address: 0x2626d70 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS6_6config15asio_tls_client16transport_configEEEFvNS4_10shared_ptrINS8_10connectionISC_EEEENSE_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJPSD_RSH_RSQ_RSW_RKNS4_12placeholders4__phILi1EEEEEESY_NS0_2ip23basic_resolver_iteratorINS1D_3tcpEEEEEE3ptrD2Ev
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(
        boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *p; // rbx
  volatile signed __int64 *cntrl; // r15
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *f; // rdi
  volatile signed __int64 *v5; // r15
  volatile signed __int64 *v6; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v8; // rax
  _QWORD *v9; // rax

  p = this->p;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.arg2_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))&f->next_[1].task_result_)(f);
    }
    v5 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
    }
    v6 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v6 && !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v8 = __readfsqword(0xFFFFFFD8);
    if ( v8 && (v9 = *(_QWORD **)(v8 + 8)) != 0 && !*v9 )
    {
      *v = v[192];
      *v9 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x262b240 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__16vectorINS0_12const_bufferENSC_9allocatorISE_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENSC_6__bindIMN11websocketpp9transport4asio10connectionINSN_6config15asio_tls_client16transport_configEEEFvNSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEEJNSC_10shared_ptrISU_EERS10_RKNSC_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES12_mEES1F_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES14_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  volatile signed __int64 *func; // rbx
  void (*v7)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t); // rdi
  boost::asio::detail::operation *v8; // rdi
  volatile signed __int64 *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  __int64 v12; // [rsp+0h] [rbp-158h] BYREF
  std::__shared_weak_count *v13; // [rsp+18h] [rbp-140h]
  char v14; // [rsp+20h] [rbp-138h] BYREF
  char *v15; // [rsp+40h] [rbp-118h]
  _BYTE v16[8]; // [rsp+50h] [rbp-108h] BYREF
  void *ptr; // [rsp+58h] [rbp-100h]
  void *v18; // [rsp+60h] [rbp-F8h]
  std::__shared_weak_count *v19; // [rsp+D8h] [rbp-80h]
  char v20; // [rsp+E0h] [rbp-78h] BYREF
  char *v21; // [rsp+100h] [rbp-58h]
  boost::system::error_code ec; // [rsp+110h] [rbp-48h] BYREF
  size_t bytes_transferred; // [rsp+120h] [rbp-38h]
  unsigned __int64 v24; // [rsp+138h] [rbp-20h]

  v24 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&v12,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    next = base[12].next_;
    if ( &base[10].task_result_ == (unsigned int *)next )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))next->next_[1].func_)(next);
    }
    else if ( next )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&next->next_[1].task_result_)(next);
    }
    func = (volatile signed __int64 *)base[10].func_;
    if ( func && !_InterlockedExchangeAdd64(func + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*func + 16))(func);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)func);
    }
    v7 = (void (*)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t))base[5].next_;
    if ( v7 )
    {
      base[5].func_ = v7;
      operator delete(v7);
    }
    v8 = base[4].next_;
    if ( &base[2].task_result_ == (unsigned int *)v8 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v8->next_[1].func_)(v8);
    }
    else if ( v8 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v8->next_[1].task_result_)(v8);
    }
    v9 = (volatile signed __int64 *)base[2].func_;
    if ( v9 && !_InterlockedExchangeAdd64(v9 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v9 + 16))(v9);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v9);
    }
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)v16,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  if ( &v20 == v21 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v21 + 32LL))(v21);
  }
  else if ( v21 )
  {
    (*(void (**)(void))(*(_QWORD *)v21 + 40LL))();
  }
  v10 = v19;
  if ( v19 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v19 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  if ( ptr )
  {
    v18 = ptr;
    operator delete(ptr);
  }
  if ( &v14 == v15 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v15 + 32LL))(v15);
  }
  else if ( v15 )
  {
    (*(void (**)(void))(*(_QWORD *)v15 + 40LL))();
  }
  v11 = v13;
  if ( v13 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v13 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
      std::__shared_weak_count::__release_weak(v11);
    }
  }
}


// Address: 0x262bb40 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config15asio_tls_client16transport_configEEEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNS4_10shared_ptrISD_EERSJ_RKNS4_12placeholders4__phILi1EEEEEESL_mEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESN_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> >::ptr v7; // [rsp+8h] [rbp-B0h] BYREF
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> v8; // [rsp+20h] [rbp-98h] BYREF
  unsigned __int64 v9; // [rsp+98h] [rbp-20h]

  v9 = __readfsqword(0x28u);
  v7.h = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *)&base[1].func_;
  v7.v = base;
  v7.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *)base;
  *(_OWORD *)&v8.handler_.__f_ = *(_OWORD *)&base[1].func_;
  v8.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)&base[2].next_;
  *(_OWORD *)&base[2].next_ = 0;
  next = base[4].next_;
  if ( next )
  {
    if ( &base[2].task_result_ == (unsigned int *)next )
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[4].next_;
      base[4].next_ = 0;
    }
  }
  else
  {
    v8.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v8.arg2_ = (unsigned __int64)base[5].func_;
  v8.arg1_ = *(boost::system::error_code *)&base[4].task_result_;
  v7.h = &v8;
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v7);
  if ( owner )
  {
    boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>::operator()(&v8);
    _mm_sfence();
  }
  if ( &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v7);
}


// Address: 0x262bdf0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config15asio_tls_client16transport_configEEEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNS4_10shared_ptrISD_EERSJ_RKNS4_12placeholders4__phILi1EEEEEESL_mEEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *p; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[144];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x262e570 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSC_6__bindIMN11websocketpp9transport4asio10connectionINSJ_6config15asio_tls_client16transport_configEEEFvNSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEmEJNSC_10shared_ptrISQ_EERSW_RKNSC_12placeholders4__phILi1EEERKNS17_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESY_mEES1E_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES10_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  _BYTE v4[80]; // [rsp+0h] [rbp-138h] BYREF
  _BYTE v5[160]; // [rsp+50h] [rbp-E8h] BYREF
  boost::system::error_code ec; // [rsp+F0h] [rbp-48h] BYREF
  size_t bytes_transferred; // [rsp+100h] [rbp-38h]
  unsigned __int64 v8; // [rsp+118h] [rbp-20h]

  v8 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v4,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&base[1].func_);
  if ( base )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&base[1].func_);
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)v5,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v4);
}


// Address: 0x262eab0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config15asio_tls_client16transport_configEEEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEmEJNS4_10shared_ptrISD_EERSJ_RKNS4_12placeholders4__phILi1EEERKNSU_ILi2EEEEEESL_mEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESN_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::ptr v7; // [rsp+8h] [rbp-B0h] BYREF
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> v8; // [rsp+20h] [rbp-98h] BYREF
  unsigned __int64 v9; // [rsp+98h] [rbp-20h]

  v9 = __readfsqword(0x28u);
  v7.h = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *)&base[1].func_;
  v7.v = base;
  v7.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *)base;
  *(_OWORD *)&v8.handler_.__f_ = *(_OWORD *)&base[1].func_;
  v8.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)&base[2].next_;
  *(_OWORD *)&base[2].next_ = 0;
  next = base[4].next_;
  if ( next )
  {
    if ( &base[2].task_result_ == (unsigned int *)next )
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[4].next_;
      base[4].next_ = 0;
    }
  }
  else
  {
    v8.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v8.arg2_ = (unsigned __int64)base[5].func_;
  v8.arg1_ = *(boost::system::error_code *)&base[4].task_result_;
  v7.h = &v8;
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v7);
  if ( owner )
  {
    boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>::operator()(&v8);
    _mm_sfence();
  }
  if ( &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v7);
}


// Address: 0x262ed60 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config15asio_tls_client16transport_configEEEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEmEJNS4_10shared_ptrISD_EERSJ_RKNS4_12placeholders4__phILi1EEERKNSU_ILi2EEEEEESL_mEEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *p; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[144];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26335b0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder2INS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSI_8functionIFvRKNSI_10error_codeEEEERKNS_6system10error_codeEEJNSI_10shared_ptrISO_EERSU_RKNSI_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEESW_mEES19_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESY_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  volatile signed __int64 *next; // rbx
  boost::asio::detail::operation *v7; // rdi
  volatile signed __int64 *func; // rbx
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v10; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v11; // [rsp+0h] [rbp-138h] BYREF
  unsigned __int64 v12; // [rsp+118h] [rbp-20h]

  v12 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &v11,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    v5 = *(boost::asio::detail::operation **)&base[10].task_result_;
    if ( &base[9].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v5->next_[1].func_)(v5);
    }
    else if ( v5 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v5->next_[1].task_result_)(v5);
    }
    next = (volatile signed __int64 *)base[9].next_;
    if ( next && !_InterlockedExchangeAdd64(next + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*next + 16))(next);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)next);
    }
    v7 = base[4].next_;
    if ( &base[2].task_result_ == (unsigned int *)v7 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v7->next_[1].func_)(v7);
    }
    else if ( v7 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v7->next_[1].task_result_)(v7);
    }
    func = (volatile signed __int64 *)base[2].func_;
    if ( func && !_InterlockedExchangeAdd64(func + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*func + 16))(func);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)func);
    }
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      &v11.handler_.handler_,
      v11.handler_.arg1_,
      v11.handler_.arg2_,
      0);
    _mm_sfence();
  }
  if ( &v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  if ( &v11.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v11.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v11.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v11.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v11.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v11.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v10 = v11.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v11.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v11.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
      std::__shared_weak_count::__release_weak(v10);
    }
  }
}


// Address: 0x2634830 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder1INS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISA_EEEENS6_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSI_8functionIFvRKNSI_10error_codeEEEERKNS_6system10error_codeEEJNSI_10shared_ptrISO_EERSU_RKNSI_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEESW_EES19_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESY_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  volatile signed __int64 *next; // rbx
  boost::asio::detail::operation *v7; // rdi
  volatile signed __int64 *func; // rbx
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v10; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v11; // [rsp+0h] [rbp-128h] BYREF
  unsigned __int64 v12; // [rsp+108h] [rbp-20h]

  v12 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &v11,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    v5 = *(boost::asio::detail::operation **)&base[10].task_result_;
    if ( &base[9].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v5->next_[1].func_)(v5);
    }
    else if ( v5 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v5->next_[1].task_result_)(v5);
    }
    next = (volatile signed __int64 *)base[9].next_;
    if ( next && !_InterlockedExchangeAdd64(next + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*next + 16))(next);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)next);
    }
    v7 = base[4].next_;
    if ( &base[2].task_result_ == (unsigned int *)v7 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v7->next_[1].func_)(v7);
    }
    else if ( v7 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v7->next_[1].task_result_)(v7);
    }
    func = (volatile signed __int64 *)base[2].func_;
    if ( func && !_InterlockedExchangeAdd64(func + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*func + 16))(func);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)func);
    }
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      &v11.handler_.handler_,
      v11.handler_.arg1_,
      0xFFFFFFFFFFFFFFFFLL,
      0);
    _mm_sfence();
  }
  if ( &v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v11.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  if ( &v11.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v11.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v11.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v11.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v11.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v11.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v10 = v11.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v11.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v11.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
      std::__shared_weak_count::__release_weak(v10);
    }
  }
}


// Address: 0x2635a40 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENS0_17mutable_buffers_1ENS1_14transfer_all_tENS0_3ssl6detail5io_opISB_NSF_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSL_8functionIFvRKNSL_10error_codeEEEERKNS_6system10error_codeEEJNSL_10shared_ptrISR_EERSX_RKNSL_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEESZ_mEES1C_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  volatile signed __int64 *next; // rbx
  boost::asio::detail::operation *v7; // rdi
  volatile signed __int64 *func; // rbx
  size_t v9; // rcx
  size_t size; // rax
  char *v11; // rdi
  unsigned __int64 v12; // rax
  size_t v13; // rcx
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v15; // rbx
  boost::asio::mutable_buffers_1 v16; // [rsp+0h] [rbp-178h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > ec; // [rsp+10h] [rbp-168h] BYREF
  unsigned __int64 v18; // [rsp+158h] [rbp-20h]
  boost::system::error_code v19; // 0:esi.4,8:rdx.8

  v18 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &ec,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    v5 = *(boost::asio::detail::operation **)&base[12].task_result_;
    if ( &base[11].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v5->next_[1].func_)(v5);
    }
    else if ( v5 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v5->next_[1].task_result_)(v5);
    }
    next = (volatile signed __int64 *)base[11].next_;
    if ( next && !_InterlockedExchangeAdd64(next + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*next + 16))(next);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)next);
    }
    v7 = base[4].next_;
    if ( &base[2].task_result_ == (unsigned int *)v7 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v7->next_[1].func_)(v7);
    }
    else if ( v7 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v7->next_[1].task_result_)(v7);
    }
    func = (volatile signed __int64 *)base[2].func_;
    if ( func && !_InterlockedExchangeAdd64(func + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*func + 16))(func);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)func);
    }
    operator delete(base);
  }
  if ( owner )
  {
    ec.handler_.handler_.start_ = 0;
    v9 = ec.handler_.arg2_ + ec.handler_.handler_.total_transferred_;
    ec.handler_.handler_.total_transferred_ += ec.handler_.arg2_;
    v19.m_val = ec.handler_.arg1_.m_val;
    if ( !ec.handler_.arg2_
      || ec.handler_.arg1_.m_val
      || (size = ec.handler_.handler_.buffer_.size_, v9 == ec.handler_.handler_.buffer_.size_) )
    {
      v19.m_cat = ec.handler_.arg1_.m_cat;
      boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
        &ec.handler_.handler_.handler_,
        v19,
        v9,
        0);
    }
    else
    {
      v11 = 0;
      if ( ec.handler_.handler_.buffer_.size_ >= v9 )
        v11 = (char *)ec.handler_.handler_.buffer_.data_ + v9;
      else
        size = v9;
      v12 = size - v9;
      v13 = 0x10000;
      if ( v12 < 0x10000 )
        v13 = v12;
      v16.data_ = v11;
      v16.size_ = v13;
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>>(
        ec.handler_.handler_.stream_->service_,
        &ec.handler_.handler_.stream_->implementation,
        &v16,
        0,
        &ec.handler_.handler_);
    }
    _mm_sfence();
  }
  if ( &ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))();
  }
  cntrl = ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)ec.handler_.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  if ( &ec.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)ec.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))ec.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(ec.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( ec.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))ec.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v15 = ec.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( ec.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)ec.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v15 + 16LL))(v15);
      std::__shared_weak_count::__release_weak(v15);
    }
  }
}


// Address: 0x26364f0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNS4_10shared_ptrISA_EERSG_RKNS4_12placeholders4__phILi1EEEEEESI_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESK_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr v7; // [rsp+8h] [rbp-A0h] BYREF
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> v8; // [rsp+20h] [rbp-88h] BYREF
  unsigned __int64 v9; // [rsp+88h] [rbp-20h]

  v9 = __readfsqword(0x28u);
  v7.h = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)&base[1].func_;
  v7.v = base;
  v7.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *)base;
  *(_OWORD *)&v8.handler_.__f_ = *(_OWORD *)&base[1].func_;
  v8.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)&base[2].next_;
  *(_OWORD *)&base[2].next_ = 0;
  next = base[4].next_;
  if ( next )
  {
    if ( &base[2].task_result_ == (unsigned int *)next )
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[4].next_;
      base[4].next_ = 0;
    }
  }
  else
  {
    v8.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v8.arg1_ = *(boost::system::error_code *)&base[4].task_result_;
  v7.h = &v8;
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v7);
  if ( owner )
  {
    boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(&v8);
    _mm_sfence();
  }
  if ( &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v7);
}


// Address: 0x26367a0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNS4_10shared_ptrISA_EERSG_RKNS4_12placeholders4__phILi1EEEEEESI_EEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *p; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[128];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x2657560 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINSA_6config11asio_client16transport_configEEEFvNS8_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeEEJNSI_ISH_EERSR_RSX_RKNS8_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEESZ_EES1C_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES11_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v4; // [rsp+0h] [rbp-108h] BYREF
  unsigned __int64 v5; // [rsp+E8h] [rbp-20h]

  v5 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &v4,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code>(
      &v4.handler_.handler_,
      &v4.handler_.arg1_);
    _mm_sfence();
  }
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler(&v4);
}


// Address: 0x2657e10 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config11asio_client16transport_configEEEFvNS4_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISH_EENS0_22deadline_timer_serviceISH_SJ_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNSE_ISD_EERSN_RST_RKNS4_12placeholders4__phILi1EEEEEESV_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESX_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *v5; // rdi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v7; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr v8; // [rsp+8h] [rbp-B0h] BYREF
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> v9; // [rsp+20h] [rbp-98h] BYREF
  unsigned __int64 v10; // [rsp+98h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  v8.h = (boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> *)&base[1].func_;
  v8.v = base;
  v8.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *)base;
  *(_OWORD *)&v9.handler_.__f_ = *(_OWORD *)&base[1].func_;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)&base[2].next_;
  *(_OWORD *)&base[2].next_ = 0;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[2].task_result_;
  *(_OWORD *)&base[2].task_result_ = 0;
  v5 = *(boost::asio::detail::operation **)&base[4].task_result_;
  if ( v5 )
  {
    if ( &base[3].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v5 )
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))v5->next_[1].next_)(
        v5,
        &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = *(std::function<void (const std::error_code &)>::__base **)&base[4].task_result_;
      *(_QWORD *)&base[4].task_result_ = 0;
    }
  }
  else
  {
    v9.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v9.arg1_ = *(boost::system::error_code *)&base[5].func_;
  v8.h = &v9;
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v8);
  if ( owner )
  {
    boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>::operator()(&v9);
    _mm_sfence();
  }
  if ( &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v7 = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(&v8);
}


// Address: 0x26581a0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config11asio_client16transport_configEEEFvNS4_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISH_EENS0_22deadline_timer_serviceISH_SJ_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNSE_ISD_EERSN_RST_RKNS4_12placeholders4__phILi1EEEEEESV_EEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *p; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *f; // rdi
  volatile signed __int64 *cntrl; // r15
  volatile signed __int64 *v5; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v7; // rax
  _QWORD *v8; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    v5 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v7 = __readfsqword(0xFFFFFFD8);
    if ( v7 && (v8 = *(_QWORD **)(v7 + 8)) != 0 && !*v8 )
    {
      *v = v[144];
      *v8 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x265fc20 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config11asio_client16transport_configEEEFvRKNS_6system10error_codeEmEJNS4_10shared_ptrISD_EERKNS4_12placeholders4__phILi1EEERKNSN_ILi2EEEEEESF_mEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESH_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  __int64 v4; // r14
  volatile signed __int64 *next; // rbx
  unsigned __int64 v6; // rax
  boost::asio::detail::operation **v7; // rax
  void (__fastcall *v8)(size_t *, __int128 *, boost::asio::detail::task_io_service_operation *, size_t); // rax
  size_t *v9; // r14
  __int128 v10; // [rsp+0h] [rbp-58h]
  __int128 v11; // [rsp+20h] [rbp-38h] BYREF
  boost::asio::detail::task_io_service_operation *v12; // [rsp+30h] [rbp-28h]

  v10 = *(_OWORD *)&base[1].next_;
  v4 = *(_QWORD *)&base[1].task_result_;
  next = (volatile signed __int64 *)base[2].next_;
  *(_OWORD *)&base[1].task_result_ = 0;
  v12 = base[3].next_;
  v11 = *(_OWORD *)&base[2].func_;
  if ( base )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 )
    {
      v7 = *(boost::asio::detail::operation ***)(v6 + 8);
      if ( v7 )
      {
        if ( !*v7 )
        {
          LOBYTE(a4) = base[3].func_;
          LOBYTE(base->next_) = a4;
          *v7 = base;
          if ( !owner )
            goto LABEL_10;
          goto LABEL_7;
        }
      }
    }
    operator delete(base);
  }
  if ( !owner )
    goto LABEL_10;
LABEL_7:
  base = (boost::asio::detail::operation *)&v11;
  v8 = (void (__fastcall *)(size_t *, __int128 *, boost::asio::detail::task_io_service_operation *, size_t))v10;
  v9 = (size_t *)(*((_QWORD *)&v10 + 1) + v4);
  if ( (v10 & 1) != 0 )
  {
    a4 = *v9;
    v8 = *(void (__fastcall **)(size_t *, __int128 *, boost::asio::detail::task_io_service_operation *, size_t))(*v9 + v10 - 1);
  }
  v8(v9, &v11, v12, a4);
  _mm_sfence();
LABEL_10:
  if ( next )
  {
    if ( !_InterlockedExchangeAdd64(next + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*next + 16))(
        next,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)next);
    }
  }
}


// Address: 0x2663f80 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSA_6config11asio_client16transport_configEEEFvNS8_10shared_ptrINSC_10connectionISG_EEEENSI_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISO_EENS0_22deadline_timer_serviceISO_SQ_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS15_3tcpEEEEJPSH_RSL_RSU_RS10_RKNS8_12placeholders4__phILi1EEERKNS1G_ILi2EEEEEENS1_26is_continuation_if_runningEEES12_S18_EES1N_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES14_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > v4; // [rsp+0h] [rbp-148h] BYREF
  unsigned __int64 v5; // [rsp+128h] [rbp-20h]

  v5 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
    &v4,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&base[1].func_);
  if ( base )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&base[1].func_);
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
      &v4.handler_.handler_,
      &v4.handler_.arg1_,
      &v4.handler_.arg2_);
    _mm_sfence();
  }
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(&v4);
}


// Address: 0x2664970 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS6_6config11asio_client16transport_configEEEFvNS4_10shared_ptrINS8_10connectionISC_EEEENSE_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS11_3tcpEEEEJPSD_RSH_RSQ_RSW_RKNS4_12placeholders4__phILi1EEERKNS1C_ILi2EEEEEESY_S14_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES10_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *p; // rbx
  boost::asio::detail::task_io_service_operation::func_type *p_func; // r12
  boost::asio::detail::operation *func; // rdi
  volatile signed __int64 *cntrl; // r12
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *f; // rdi
  volatile signed __int64 *v10; // r12
  volatile signed __int64 *v11; // rbx
  void *v; // rdi
  unsigned __int64 v13; // rax
  _QWORD *v14; // rax
  std::__shared_weak_count *v15; // rbx
  std::__shared_weak_count *v16; // rbx
  std::__shared_weak_count *v17; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr v18; // [rsp+8h] [rbp-E0h] BYREF
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > v19; // [rsp+20h] [rbp-C8h] BYREF
  unsigned __int64 v20; // [rsp+C0h] [rbp-28h]

  p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)base;
  v20 = __readfsqword(0x28u);
  p_func = &base[1].func_;
  v18.h = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&base[1].func_;
  v18.v = base;
  v18.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)base;
  *(_OWORD *)&v19.handler_.__f_ = *(_OWORD *)&base[1].func_;
  *(boost::asio::detail::operation *)&v19.handler_.__bound_args_.__base_.__value_ = base[2];
  *(_OWORD *)&base[2].func_ = 0;
  v19.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[3].next_;
  *(_OWORD *)&base[3].next_ = 0;
  func = (boost::asio::detail::operation *)base[5].func_;
  if ( func )
  {
    if ( &base[4] == func )
    {
      v19.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      base = (boost::asio::detail::operation *)&v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))func->next_[1].next_)(
        func,
        &v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
      p = v18.p;
    }
    else
    {
      v19.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[5].func_;
      base[5].func_ = 0;
    }
  }
  else
  {
    v19.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v19.arg1_ = (boost::system::error_code)*((_OWORD *)p_func + 7);
  v19.arg2_.values_ = (std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >)*((_OWORD *)p_func + 8);
  *((_OWORD *)p_func + 8) = 0;
  v19.arg2_.index_ = (size_t)p_func[18];
  v18.h = &v19;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.arg2_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*cntrl + 16))(
        cntrl,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      f->next_[1].func_((boost::asio::detail::task_io_service *)f, base, a3, a4);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&f->next_[1].task_result_)(
        f,
        base,
        a3,
        a4);
    }
    v10 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v10 && !_InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*v10 + 16))(
        v10,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v10);
    }
    v11 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v11 && !_InterlockedExchangeAdd64(v11 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*v11 + 16))(
        v11,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v11);
    }
    v18.p = 0;
  }
  v = v18.v;
  if ( v18.v )
  {
    v13 = __readfsqword(0xFFFFFFD8);
    if ( v13 && (v14 = *(_QWORD **)(v13 + 8)) != 0 && !*v14 )
    {
      LOBYTE(a4) = *((_BYTE *)v18.v + 192);
      *(_BYTE *)v18.v = a4;
      *v14 = v;
    }
    else
    {
      operator delete(v18.v);
    }
    v18.v = 0;
  }
  if ( owner )
  {
    boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(&v19);
    _mm_sfence();
  }
  v15 = v19.arg2_.values_.__cntrl_;
  if ( v19.arg2_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v19.arg2_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v15 + 16LL))(
      v15,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v15);
  }
  if ( &v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v19.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))v19.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(
      v19.handler_.__bound_args_.__base_.__value_.__f_,
      base,
      a3,
      a4);
  }
  else if ( v19.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))v19.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(
      v19.handler_.__bound_args_.__base_.__value_.__f_,
      base,
      a3,
      a4);
  }
  v16 = v19.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v19.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v19.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v16 + 16LL))(
      v16,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v16);
  }
  v17 = v19.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v19.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v19.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v17 + 16LL))(
      v17,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v17);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(&v18);
}


// Address: 0x2664d30 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS6_6config11asio_client16transport_configEEEFvNS4_10shared_ptrINS8_10connectionISC_EEEENSE_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS11_3tcpEEEEJPSD_RSH_RSQ_RSW_RKNS4_12placeholders4__phILi1EEERKNS1C_ILi2EEEEEESY_S14_EEE3ptrD2Ev
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(
        boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *p; // rbx
  volatile signed __int64 *cntrl; // r15
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *f; // rdi
  volatile signed __int64 *v5; // r15
  volatile signed __int64 *v6; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v8; // rax
  _QWORD *v9; // rax

  p = this->p;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.arg2_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))&f->next_[1].task_result_)(f);
    }
    v5 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
    }
    v6 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v6 && !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v8 = __readfsqword(0xFFFFFFD8);
    if ( v8 && (v9 = *(_QWORD **)(v8 + 8)) != 0 && !*v9 )
    {
      *v = v[192];
      *v9 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x2667ad0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EENS6_23basic_resolver_iteratorIS7_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSI_6config11asio_client16transport_configEEEFvNSG_10shared_ptrINSK_10connectionISO_EEEENSQ_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISW_EENS0_22deadline_timer_serviceISW_SY_EEEEEENSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJPSP_RST_RS12_RS18_RKNSG_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES1A_EES1O_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES1C_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *func; // rdi
  volatile signed __int64 *v6; // rbx
  volatile signed __int64 *v7; // rbx
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v9; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v10; // [rsp+0h] [rbp-168h] BYREF
  unsigned __int64 v11; // [rsp+148h] [rbp-20h]

  v11 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &v10,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op((boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[6]);
    func = (boost::asio::detail::operation *)base[5].func_;
    if ( &base[4] == func )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))func->next_[1].func_)(func);
    }
    else if ( func )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&func->next_[1].task_result_)(func);
    }
    v6 = (volatile signed __int64 *)base[3].func_;
    if ( v6 && !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    v7 = *(volatile signed __int64 **)&base[2].task_result_;
    if ( v7 && !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(v7);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      &v10.handler_.handler_,
      v10.handler_.arg1_,
      0);
    _mm_sfence();
  }
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&v10.handler_.handler_);
  if ( &v10.context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v10.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v10.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v10.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v10.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v10.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v10.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v10.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v9 = v10.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
      std::__shared_weak_count::__release_weak(v9);
    }
  }
}


// Address: 0x2667ee0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EENS5_23basic_resolver_iteratorIS6_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSH_6config11asio_client16transport_configEEEFvNSF_10shared_ptrINSJ_10connectionISN_EEEENSP_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISV_EENS0_22deadline_timer_serviceISV_SX_EEEEEENSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJPSO_RSS_RS11_RS17_RKNSF_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES19_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES1B_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  unsigned __int64 v4; // rax
  boost::asio::detail::operation **v5; // rax
  boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> v6; // [rsp+0h] [rbp-F8h] BYREF
  unsigned __int64 v7; // [rsp+D8h] [rbp-20h]

  v7 = __readfsqword(0x28u);
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    &v6.handler_,
    (boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[1].func_);
  v6.arg1_ = *(boost::system::error_code *)&base[9].func_;
  if ( base )
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op((boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[1].func_);
  v4 = __readfsqword(0xFFFFFFD8);
  if ( v4 )
  {
    v5 = *(boost::asio::detail::operation ***)(v4 + 8);
    if ( v5 )
    {
      if ( !*v5 )
      {
        LOBYTE(base->next_) = base[10].next_;
        *v5 = base;
        if ( !owner )
          goto LABEL_8;
        goto LABEL_7;
      }
    }
  }
  operator delete(base);
  if ( owner )
  {
LABEL_7:
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      &v6,
      &v6.handler_.handler_);
    _mm_sfence();
  }
LABEL_8:
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&v6.handler_);
}


// Address: 0x2668350 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS6_6config11asio_client16transport_configEEEFvNS4_10shared_ptrINS8_10connectionISC_EEEENSE_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJPSD_RSH_RSQ_RSW_RKNS4_12placeholders4__phILi1EEEEEESY_NS0_2ip23basic_resolver_iteratorINS1D_3tcpEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES10_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *p; // rbx
  boost::asio::detail::task_io_service_operation::func_type *p_func; // r12
  boost::asio::detail::operation *func; // rdi
  volatile signed __int64 *cntrl; // r12
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *f; // rdi
  volatile signed __int64 *v10; // r12
  volatile signed __int64 *v11; // rbx
  void *v; // rdi
  unsigned __int64 v13; // rax
  _QWORD *v14; // rax
  std::__shared_weak_count *v15; // rbx
  std::__shared_weak_count *v16; // rbx
  std::__shared_weak_count *v17; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr v18; // [rsp+8h] [rbp-E0h] BYREF
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > v19; // [rsp+20h] [rbp-C8h] BYREF
  unsigned __int64 v20; // [rsp+C0h] [rbp-28h]

  p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)base;
  v20 = __readfsqword(0x28u);
  p_func = &base[1].func_;
  v18.h = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&base[1].func_;
  v18.v = base;
  v18.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)base;
  *(_OWORD *)&v19.handler_.__f_ = *(_OWORD *)&base[1].func_;
  *(boost::asio::detail::operation *)&v19.handler_.__bound_args_.__base_.__value_ = base[2];
  *(_OWORD *)&base[2].func_ = 0;
  v19.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[3].next_;
  *(_OWORD *)&base[3].next_ = 0;
  func = (boost::asio::detail::operation *)base[5].func_;
  if ( func )
  {
    if ( &base[4] == func )
    {
      v19.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      base = (boost::asio::detail::operation *)&v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))func->next_[1].next_)(
        func,
        &v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
      p = v18.p;
    }
    else
    {
      v19.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[5].func_;
      base[5].func_ = 0;
    }
  }
  else
  {
    v19.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v19.arg1_ = (boost::system::error_code)*((_OWORD *)p_func + 7);
  v19.arg2_.values_ = (std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> >)*((_OWORD *)p_func + 8);
  *((_OWORD *)p_func + 8) = 0;
  v19.arg2_.index_ = (size_t)p_func[18];
  v18.h = &v19;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.arg2_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*cntrl + 16))(
        cntrl,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      f->next_[1].func_((boost::asio::detail::task_io_service *)f, base, a3, a4);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))&f->next_[1].task_result_)(
        f,
        base,
        a3,
        a4);
    }
    v10 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v10 && !_InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*v10 + 16))(
        v10,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v10);
    }
    v11 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v11 && !_InterlockedExchangeAdd64(v11 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*v11 + 16))(
        v11,
        base,
        a3,
        a4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v11);
    }
    v18.p = 0;
  }
  v = v18.v;
  if ( v18.v )
  {
    v13 = __readfsqword(0xFFFFFFD8);
    if ( v13 && (v14 = *(_QWORD **)(v13 + 8)) != 0 && !*v14 )
    {
      LOBYTE(a4) = *((_BYTE *)v18.v + 192);
      *(_BYTE *)v18.v = a4;
      *v14 = v;
    }
    else
    {
      operator delete(v18.v);
    }
    v18.v = 0;
  }
  if ( owner )
  {
    boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>::operator()(&v19);
    _mm_sfence();
  }
  v15 = v19.arg2_.values_.__cntrl_;
  if ( v19.arg2_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v19.arg2_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v15 + 16LL))(
      v15,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v15);
  }
  if ( &v19.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v19.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))v19.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(
      v19.handler_.__bound_args_.__base_.__value_.__f_,
      base,
      a3,
      a4);
  }
  else if ( v19.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))v19.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(
      v19.handler_.__bound_args_.__base_.__value_.__f_,
      base,
      a3,
      a4);
  }
  v16 = v19.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v19.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v19.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v16 + 16LL))(
      v16,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v16);
  }
  v17 = v19.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v19.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v19.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::detail::operation *, const boost::system::error_code *, size_t))(*(_QWORD *)v17 + 16LL))(
      v17,
      base,
      a3,
      a4);
    std::__shared_weak_count::__release_weak(v17);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(&v18);
}


// Address: 0x2668710 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio8endpointINS6_6config11asio_client16transport_configEEEFvNS4_10shared_ptrINS8_10connectionISC_EEEENSE_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJPSD_RSH_RSQ_RSW_RKNS4_12placeholders4__phILi1EEEEEESY_NS0_2ip23basic_resolver_iteratorINS1D_3tcpEEEEEE3ptrD2Ev
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::ptr::~ptr(
        boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *p; // rbx
  volatile signed __int64 *cntrl; // r15
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *f; // rdi
  volatile signed __int64 *v5; // r15
  volatile signed __int64 *v6; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v8; // rax
  _QWORD *v9; // rax

  p = this->p;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.arg2_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *))&f->next_[1].task_result_)(f);
    }
    v5 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
    }
    v6 = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( v6 && !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v8 = __readfsqword(0xFFFFFFD8);
    if ( v8 && (v9 = *(_QWORD **)(v8 + 8)) != 0 && !*v9 )
    {
      *v = v[192];
      *v9 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x266c660 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__16vectorINS0_12const_bufferENSC_9allocatorISE_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENSC_6__bindIMN11websocketpp9transport4asio10connectionINSN_6config11asio_client16transport_configEEEFvNSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEEJNSC_10shared_ptrISU_EERS10_RKNSC_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES12_mEES1F_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES14_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  volatile signed __int64 *func; // rbx
  void (*v7)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t); // rdi
  boost::asio::detail::operation *v8; // rdi
  volatile signed __int64 *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  __int64 v12; // [rsp+0h] [rbp-158h] BYREF
  std::__shared_weak_count *v13; // [rsp+18h] [rbp-140h]
  char v14; // [rsp+20h] [rbp-138h] BYREF
  char *v15; // [rsp+40h] [rbp-118h]
  _BYTE v16[8]; // [rsp+50h] [rbp-108h] BYREF
  void *ptr; // [rsp+58h] [rbp-100h]
  void *v18; // [rsp+60h] [rbp-F8h]
  std::__shared_weak_count *v19; // [rsp+D8h] [rbp-80h]
  char v20; // [rsp+E0h] [rbp-78h] BYREF
  char *v21; // [rsp+100h] [rbp-58h]
  boost::system::error_code ec; // [rsp+110h] [rbp-48h] BYREF
  size_t bytes_transferred; // [rsp+120h] [rbp-38h]
  unsigned __int64 v24; // [rsp+138h] [rbp-20h]

  v24 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&v12,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&base[1].func_);
  if ( base )
  {
    next = base[12].next_;
    if ( &base[10].task_result_ == (unsigned int *)next )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))next->next_[1].func_)(next);
    }
    else if ( next )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&next->next_[1].task_result_)(next);
    }
    func = (volatile signed __int64 *)base[10].func_;
    if ( func && !_InterlockedExchangeAdd64(func + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*func + 16))(func);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)func);
    }
    v7 = (void (*)(boost::asio::detail::task_io_service *, boost::asio::detail::task_io_service_operation *, const boost::system::error_code *, size_t))base[5].next_;
    if ( v7 )
    {
      base[5].func_ = v7;
      operator delete(v7);
    }
    v8 = base[4].next_;
    if ( &base[2].task_result_ == (unsigned int *)v8 )
    {
      ((void (__fastcall *)(boost::asio::detail::operation *))v8->next_[1].func_)(v8);
    }
    else if ( v8 )
    {
      (*(void (__fastcall **)(boost::asio::detail::operation *))&v8->next_[1].task_result_)(v8);
    }
    v9 = (volatile signed __int64 *)base[2].func_;
    if ( v9 && !_InterlockedExchangeAdd64(v9 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v9 + 16))(v9);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v9);
    }
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)v16,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  if ( &v20 == v21 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v21 + 32LL))(v21);
  }
  else if ( v21 )
  {
    (*(void (**)(void))(*(_QWORD *)v21 + 40LL))();
  }
  v10 = v19;
  if ( v19 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v19 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  if ( ptr )
  {
    v18 = ptr;
    operator delete(ptr);
  }
  if ( &v14 == v15 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v15 + 32LL))(v15);
  }
  else if ( v15 )
  {
    (*(void (**)(void))(*(_QWORD *)v15 + 40LL))();
  }
  v11 = v13;
  if ( v13 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v13 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
      std::__shared_weak_count::__release_weak(v11);
    }
  }
}


// Address: 0x266ce70 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config11asio_client16transport_configEEEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNS4_10shared_ptrISD_EERSJ_RKNS4_12placeholders4__phILi1EEEEEESL_mEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESN_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> >::ptr v7; // [rsp+8h] [rbp-B0h] BYREF
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> v8; // [rsp+20h] [rbp-98h] BYREF
  unsigned __int64 v9; // [rsp+98h] [rbp-20h]

  v9 = __readfsqword(0x28u);
  v7.h = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> *)&base[1].func_;
  v7.v = base;
  v7.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *)base;
  *(_OWORD *)&v8.handler_.__f_ = *(_OWORD *)&base[1].func_;
  v8.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)&base[2].next_;
  *(_OWORD *)&base[2].next_ = 0;
  next = base[4].next_;
  if ( next )
  {
    if ( &base[2].task_result_ == (unsigned int *)next )
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[4].next_;
      base[4].next_ = 0;
    }
  }
  else
  {
    v8.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v8.arg2_ = (unsigned __int64)base[5].func_;
  v8.arg1_ = *(boost::system::error_code *)&base[4].task_result_;
  v7.h = &v8;
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v7);
  if ( owner )
  {
    boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>::operator()(&v8);
    _mm_sfence();
  }
  if ( &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v7);
}


// Address: 0x266d120 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config11asio_client16transport_configEEEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEEJNS4_10shared_ptrISD_EERSJ_RKNS4_12placeholders4__phILi1EEEEEESL_mEEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *p; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[144];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x266f8a0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS8_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSC_6__bindIMN11websocketpp9transport4asio10connectionINSJ_6config11asio_client16transport_configEEEFvNSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEmEJNSC_10shared_ptrISQ_EERSW_RKNSC_12placeholders4__phILi1EEERKNS17_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESY_mEES1E_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES10_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  _BYTE v4[80]; // [rsp+0h] [rbp-138h] BYREF
  _BYTE v5[160]; // [rsp+50h] [rbp-E8h] BYREF
  boost::system::error_code ec; // [rsp+F0h] [rbp-48h] BYREF
  size_t bytes_transferred; // [rsp+100h] [rbp-38h]
  unsigned __int64 v8; // [rsp+118h] [rbp-20h]

  v8 = __readfsqword(0x28u);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v4,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&base[1].func_);
  if ( base )
  {
    boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)&base[1].func_);
    operator delete(base);
  }
  if ( owner )
  {
    boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
      (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)v5,
      &ec,
      bytes_transferred,
      0);
    _mm_sfence();
  }
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler((boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)v4);
}


// Address: 0x266fde0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config11asio_client16transport_configEEEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEmEJNS4_10shared_ptrISD_EERSJ_RKNS4_12placeholders4__phILi1EEERKNSU_ILi2EEEEEESL_mEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESN_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::operation *next; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::ptr v7; // [rsp+8h] [rbp-B0h] BYREF
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> v8; // [rsp+20h] [rbp-98h] BYREF
  unsigned __int64 v9; // [rsp+98h] [rbp-20h]

  v9 = __readfsqword(0x28u);
  v7.h = (boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> *)&base[1].func_;
  v7.v = base;
  v7.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *)base;
  *(_OWORD *)&v8.handler_.__f_ = *(_OWORD *)&base[1].func_;
  v8.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)&base[2].next_;
  *(_OWORD *)&base[2].next_ = 0;
  next = base[4].next_;
  if ( next )
  {
    if ( &base[2].task_result_ == (unsigned int *)next )
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))next->next_[1].next_)(
        next,
        &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        a3,
        a4);
    }
    else
    {
      v8.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)base[4].next_;
      base[4].next_ = 0;
    }
  }
  else
  {
    v8.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v8.arg2_ = (unsigned __int64)base[5].func_;
  v8.arg1_ = *(boost::system::error_code *)&base[4].task_result_;
  v7.h = &v8;
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v7);
  if ( owner )
  {
    boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>::operator()(&v8);
    _mm_sfence();
  }
  if ( &v8.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::ptr::reset(&v7);
}


// Address: 0x2670090 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder2INSt3__16__bindIMN11websocketpp9transport4asio10connectionINS6_6config11asio_client16transport_configEEEFvNS4_8functionIFvRKNS4_10error_codeEEEERKNS_6system10error_codeEmEJNS4_10shared_ptrISD_EERSJ_RKNS4_12placeholders4__phILi1EEERKNSU_ILi2EEEEEESL_mEEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *p; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    f = (boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *)p->handler_.handler_.__bound_args_.__base_.__value_.__f_;
    if ( &p->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      ((void (__fastcall *)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *))f->next_[1].func_)(f);
    }
    else if ( f )
    {
      (*(void (__fastcall **)(boost::asio::detail::completion_handler<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> > *))&f->next_[1].task_result_)(f);
    }
    cntrl = (volatile signed __int64 *)p->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[144];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26a1420 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSI_3tcpEEEEENS4_5list3INS4_5valueINSt3__110shared_ptrISD_EEEEPFNS_3argILi1EEEvENSO_ISL_EEEEEESF_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESH_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  int v4; // r8d
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v6; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> >::ptr v7; // [rsp+0h] [rbp-78h] BYREF
  _BYTE f[24]; // [rsp+18h] [rbp-60h] BYREF
  __int128 v9; // [rsp+30h] [rbp-48h] BYREF
  __int128 v10; // [rsp+40h] [rbp-38h]
  boost::asio::detail::operation v11; // [rsp+50h] [rbp-28h] BYREF

  v7.v = base;
  v7.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> > *)base;
  *(_OWORD *)&f[8] = *(_OWORD *)&base[1].next_;
  v9 = *(_OWORD *)&base[1].task_result_;
  *(_OWORD *)&base[1].task_result_ = 0;
  v10 = *(_OWORD *)&base[2].func_;
  *(_OWORD *)&base[2].func_ = 0;
  v11 = base[3];
  v7.h = (boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> *)&f[8];
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::ptr::reset(&v7);
  if ( owner )
  {
    *(_QWORD *)f = &v11.func_;
    boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::operator()<boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list1<boost::system::error_code const&>>(
      (boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)&v9,
      (boost::_bi::type<void>)&f[8],
      (boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)f,
      0,
      v4);
    _mm_sfence();
  }
  v5 = (std::__shared_weak_count *)*((_QWORD *)&v10 + 1);
  if ( *((_QWORD *)&v10 + 1)
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v10 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
  }
  v6 = (std::__shared_weak_count *)*((_QWORD *)&v9 + 1);
  if ( *((_QWORD *)&v9 + 1)
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v9 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::ptr::reset(&v7);
}


// Address: 0x26a15a0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSI_3tcpEEEEENS4_5list3INS4_5valueINSt3__110shared_ptrISD_EEEEPFNS_3argILi1EEEvENSO_ISL_EEEEEESF_EEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> > *p; // rbx
  volatile signed __int64 *cntrl; // r15
  volatile signed __int64 *v4; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.handler_.l_.a3_.t_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    v4 = (volatile signed __int64 *)p->handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[96];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26bc330 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSH_3tcpEEEEENS4_5list3INS4_5valueINSt3__110shared_ptrISC_EEEEPFNS_3argILi1EEEvENSN_ISK_EEEEEESE_EEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESG_m
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  int v4; // r8d
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v6; // rbx
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> >::ptr v7; // [rsp+0h] [rbp-78h] BYREF
  _BYTE f[24]; // [rsp+18h] [rbp-60h] BYREF
  __int128 v9; // [rsp+30h] [rbp-48h] BYREF
  __int128 v10; // [rsp+40h] [rbp-38h]
  boost::asio::detail::operation v11; // [rsp+50h] [rbp-28h] BYREF

  v7.v = base;
  v7.p = (boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> > *)base;
  *(_OWORD *)&f[8] = *(_OWORD *)&base[1].next_;
  v9 = *(_OWORD *)&base[1].task_result_;
  *(_OWORD *)&base[1].task_result_ = 0;
  v10 = *(_OWORD *)&base[2].func_;
  *(_OWORD *)&base[2].func_ = 0;
  v11 = base[3];
  v7.h = (boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> *)&f[8];
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::ptr::reset(&v7);
  if ( owner )
  {
    *(_QWORD *)f = &v11.func_;
    boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::operator()<boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list1<boost::system::error_code const&>>(
      (boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > *)&v9,
      (boost::_bi::type<void>)&f[8],
      (boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)f,
      0,
      v4);
    _mm_sfence();
  }
  v5 = (std::__shared_weak_count *)*((_QWORD *)&v10 + 1);
  if ( *((_QWORD *)&v10 + 1)
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v10 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
  }
  v6 = (std::__shared_weak_count *)*((_QWORD *)&v9 + 1);
  if ( *((_QWORD *)&v9 + 1)
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)(*((_QWORD *)&v9 + 1) + 8LL), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::ptr::reset(&v7);
}


// Address: 0x26bc4b0 | Name: _ZN5boost4asio6detail18completion_handlerINS1_7binder1INS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSH_3tcpEEEEENS4_5list3INS4_5valueINSt3__110shared_ptrISC_EEEEPFNS_3argILi1EEEvENSN_ISK_EEEEEESE_EEE3ptr5resetEv
void __fastcall boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>::ptr::reset(
        boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> >::ptr *this)
{
  boost::asio::detail::completion_handler<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> > *p; // rbx
  volatile signed __int64 *cntrl; // r15
  volatile signed __int64 *v4; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.handler_.l_.a3_.t_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    v4 = (volatile signed __int64 *)p->handler_.handler_.l_.a1_.t_.__cntrl_;
    if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[96];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26cece0 | Name: _ZN5boost4asio6detail18completion_handlerINS_3_bi6bind_tIvPFvPvENS3_5list1INS3_5valueIS5_EEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationERKNS_6system10error_codeEm
void __fastcall boost::asio::detail::completion_handler<boost::_bi::bind_t<void,void (*)(void *),boost::_bi::list1<boost::_bi::value<void *>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::task_io_service_operation *next; // r15
  boost::asio::detail::task_io_service_operation::func_type func; // r14
  unsigned __int64 v6; // rax
  boost::asio::detail::operation **v7; // rax

  next = base[1].next_;
  func = base[1].func_;
  if ( !base )
  {
LABEL_6:
    if ( !owner )
      return;
    goto LABEL_7;
  }
  v6 = __readfsqword(0xFFFFFFD8);
  if ( !v6 || (v7 = *(boost::asio::detail::operation ***)(v6 + 8)) == 0 || *v7 )
  {
    operator delete(base);
    goto LABEL_6;
  }
  LOBYTE(a4) = base[1].task_result_;
  LOBYTE(base->next_) = a4;
  *v7 = base;
  if ( !owner )
    return;
LABEL_7:
  ((void (__fastcall *)(_QWORD, boost::asio::detail::operation *, const boost::system::error_code *, size_t))next)(
    func,
    base,
    a3,
    a4);
  _mm_sfence();
}


