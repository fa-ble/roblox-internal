// Address: 0xf125e0 | Name: _ZN3RBX7Network9ItemQueueC2Ev
void __fastcall RBX::Network::ItemQueue::ItemQueue(RBX::Network::ItemQueue *this)
{
  this->itemList.data_.root_plus_size_.size_ = 0;
  this->itemList.data_.root_plus_size_.m_header.next_ = &this->itemList.data_.root_plus_size_.m_header;
  this->itemList.data_.root_plus_size_.m_header.prev_ = &this->itemList.data_.root_plus_size_.m_header;
}


// Address: 0x1e402c0 | Name: _ZN3RBX11SendPhysicsC2Ev
void __fastcall RBX::SendPhysics::SendPhysics(RBX::SendPhysics *this)
{
  *(_QWORD *)this = 0;
  *((_QWORD *)this + 1) = (char *)this + 8;
  *((_QWORD *)this + 2) = (char *)this + 8;
  *(_OWORD *)((char *)this + 68) = 0;
  *(_OWORD *)((char *)this + 56) = 0;
  *((_DWORD *)this + 22) = 0;
  *(_OWORD *)((char *)this + 36) = 0;
  *(_OWORD *)((char *)this + 24) = 0;
  *((_OWORD *)this + 6) = 0;
}


