// Address: 0x1281a50 | Name: _ZN5boost5uuids6detail8seed_rng19sha1_random_digest_Ev
void __fastcall boost::uuids::detail::seed_rng::sha1_random_digest_(boost::uuids::detail::seed_rng *this)
{
  __int64 v1; // rbp
  size_t block_byte_index; // rax
  unsigned __int8 v3; // cl
  size_t v4; // rax
  size_t *p_bit_count_high; // rcx
  __int64 i; // rbp
  unsigned __int8 v7; // al
  size_t v8; // rcx
  size_t v9; // rax
  size_t *p_bit_count_low; // rcx
  void *v11; // rax
  __int64 j; // rbp
  size_t v13; // rcx
  size_t v14; // rax
  size_t *v15; // rcx
  void *v16; // rax
  __int64 k; // rbp
  size_t v18; // rcx
  size_t v19; // rax
  size_t *v20; // rcx
  __int64 m; // rbp
  unsigned __int8 v22; // al
  size_t v23; // rcx
  size_t v24; // rax
  size_t *v25; // rcx
  FILE *random; // rcx
  __int64 n; // rbp
  unsigned __int8 v28; // al
  size_t v29; // rcx
  size_t v30; // rax
  size_t *v31; // rcx
  _BYTE *v32; // r14
  size_t v33; // rax
  size_t *v34; // rcx
  unsigned __int8 v35; // al
  size_t v36; // rcx
  size_t v37; // rax
  size_t *v38; // rcx
  unsigned __int8 v39; // al
  size_t v40; // rcx
  size_t v41; // rax
  size_t *v42; // rcx
  unsigned __int8 v43; // al
  size_t v44; // rcx
  size_t v45; // rax
  size_t *v46; // rcx
  __int64 ii; // rbp
  unsigned __int8 v48; // al
  size_t v49; // rcx
  size_t v50; // rax
  size_t *v51; // rcx
  __int64 jj; // rbp
  unsigned __int8 v53; // al
  size_t v54; // rcx
  size_t v55; // rax
  size_t *v56; // rcx
  __int128 *v57; // rax
  boost::uuids::detail::seed_rng *v58; // rdx
  void *v59; // [rsp+0h] [rbp-108h] BYREF
  int v60; // [rsp+8h] [rbp-100h]
  boost::uuids::detail::seed_rng *v61; // [rsp+10h] [rbp-F8h]
  __int128 *v62; // [rsp+18h] [rbp-F0h]
  __int128 v63; // [rsp+20h] [rbp-E8h]
  int v64; // [rsp+30h] [rbp-D8h]
  unsigned int ptr[8]; // [rsp+40h] [rbp-C8h] BYREF
  boost::uuids::detail::sha1 v66; // [rsp+60h] [rbp-A8h] BYREF
  unsigned __int64 v67; // [rsp+D0h] [rbp-38h]

  v61 = this;
  v67 = __readfsqword(0x28u);
  *(_OWORD *)v66.h_ = xmmword_3E8580;
  v66.h_[4] = -1009589776;
  memset(&v66.block_byte_index_, 0, 24);
  v62 = &xmmword_2A13200;
  v64 = dword_2A13210;
  v63 = xmmword_2A13200;
  v1 = 0;
  block_byte_index = 0;
  while ( 1 )
  {
    v3 = *((_BYTE *)&v63 + v1);
    v66.block_byte_index_ = block_byte_index + 1;
    v66.block_[block_byte_index] = v3;
    if ( v66.block_byte_index_ == 64 )
    {
      v66.block_byte_index_ = 0;
      boost::uuids::detail::sha1::process_block(&v66);
    }
    if ( v66.bit_count_low >= 0xFFFFFFF8 )
    {
      v66.bit_count_low = 0;
      if ( v66.bit_count_high > 0xFFFFFFFE )
      {
        std::runtime_error::runtime_error((std::runtime_error *)ptr, "sha1 too many bytes");
        boost::exception_detail::throw_exception_<std::runtime_error>(
          (const std::runtime_error *)ptr,
          "void boost::uuids::detail::sha1::process_byte(unsigned char)",
          "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
          104);
      }
      v4 = v66.bit_count_high + 1;
      p_bit_count_high = &v66.bit_count_high;
    }
    else
    {
      v4 = v66.bit_count_low + 8;
      p_bit_count_high = &v66.bit_count_low;
    }
    *p_bit_count_high = v4;
    if ( v1 == 19 )
      break;
    block_byte_index = v66.block_byte_index_;
    ++v1;
  }
  for ( i = 0; i != 8; ++i )
  {
    v7 = *((_BYTE *)&v62 + i);
    v8 = v66.block_byte_index_++;
    v66.block_[v8] = v7;
    if ( v66.block_byte_index_ == 64 )
    {
      v66.block_byte_index_ = 0;
      boost::uuids::detail::sha1::process_block(&v66);
    }
    if ( v66.bit_count_low >= 0xFFFFFFF8 )
    {
      v66.bit_count_low = 0;
      if ( v66.bit_count_high > 0xFFFFFFFE )
      {
        std::runtime_error::runtime_error((std::runtime_error *)ptr, "sha1 too many bytes");
        boost::exception_detail::throw_exception_<std::runtime_error>(
          (const std::runtime_error *)ptr,
          "void boost::uuids::detail::sha1::process_byte(unsigned char)",
          "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
          104);
      }
      v9 = v66.bit_count_high + 1;
      p_bit_count_low = &v66.bit_count_high;
    }
    else
    {
      v9 = v66.bit_count_low + 8;
      p_bit_count_low = &v66.bit_count_low;
    }
    *p_bit_count_low = v9;
  }
  v11 = (void *)time(0);
  v59 = v11;
  for ( j = 1; ; ++j )
  {
    v13 = v66.block_byte_index_++;
    v66.block_[v13] = (unsigned __int8)v11;
    if ( v66.block_byte_index_ == 64 )
    {
      v66.block_byte_index_ = 0;
      boost::uuids::detail::sha1::process_block(&v66);
    }
    if ( v66.bit_count_low >= 0xFFFFFFF8 )
    {
      v66.bit_count_low = 0;
      if ( v66.bit_count_high > 0xFFFFFFFE )
      {
        std::runtime_error::runtime_error((std::runtime_error *)ptr, "sha1 too many bytes");
        boost::exception_detail::throw_exception_<std::runtime_error>(
          (const std::runtime_error *)ptr,
          "void boost::uuids::detail::sha1::process_byte(unsigned char)",
          "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
          104);
      }
      v14 = v66.bit_count_high + 1;
      v15 = &v66.bit_count_high;
    }
    else
    {
      v14 = v66.bit_count_low + 8;
      v15 = &v66.bit_count_low;
    }
    *v15 = v14;
    if ( j == 8 )
      break;
    LOBYTE(v11) = *((_BYTE *)&v59 + j);
  }
  v16 = (void *)clock();
  v59 = v16;
  for ( k = 1; ; ++k )
  {
    v18 = v66.block_byte_index_++;
    v66.block_[v18] = (unsigned __int8)v16;
    if ( v66.block_byte_index_ == 64 )
    {
      v66.block_byte_index_ = 0;
      boost::uuids::detail::sha1::process_block(&v66);
    }
    if ( v66.bit_count_low >= 0xFFFFFFF8 )
    {
      v66.bit_count_low = 0;
      if ( v66.bit_count_high > 0xFFFFFFFE )
      {
        std::runtime_error::runtime_error((std::runtime_error *)ptr, "sha1 too many bytes");
        boost::exception_detail::throw_exception_<std::runtime_error>(
          (const std::runtime_error *)ptr,
          "void boost::uuids::detail::sha1::process_byte(unsigned char)",
          "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
          104);
      }
      v19 = v66.bit_count_high + 1;
      v20 = &v66.bit_count_high;
    }
    else
    {
      v19 = v66.bit_count_low + 8;
      v20 = &v66.bit_count_low;
    }
    *v20 = v19;
    if ( k == 8 )
      break;
    LOBYTE(v16) = *((_BYTE *)&v59 + k);
  }
  LODWORD(v59) = rand();
  HIDWORD(v59) = rand();
  v60 = rand();
  for ( m = 0; m != 12; ++m )
  {
    v22 = *((_BYTE *)&v59 + m);
    v23 = v66.block_byte_index_++;
    v66.block_[v23] = v22;
    if ( v66.block_byte_index_ == 64 )
    {
      v66.block_byte_index_ = 0;
      boost::uuids::detail::sha1::process_block(&v66);
    }
    if ( v66.bit_count_low >= 0xFFFFFFF8 )
    {
      v66.bit_count_low = 0;
      if ( v66.bit_count_high > 0xFFFFFFFE )
      {
        std::runtime_error::runtime_error((std::runtime_error *)ptr, "sha1 too many bytes");
        boost::exception_detail::throw_exception_<std::runtime_error>(
          (const std::runtime_error *)ptr,
          "void boost::uuids::detail::sha1::process_byte(unsigned char)",
          "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
          104);
      }
      v24 = v66.bit_count_high + 1;
      v25 = &v66.bit_count_high;
    }
    else
    {
      v24 = v66.bit_count_low + 8;
      v25 = &v66.bit_count_low;
    }
    *v25 = v24;
  }
  random = v61->random_;
  if ( random )
    fread(ptr, 1u, 0x14u, random);
  for ( n = 0; n != 20; ++n )
  {
    v28 = *((_BYTE *)ptr + n);
    v29 = v66.block_byte_index_++;
    v66.block_[v29] = v28;
    if ( v66.block_byte_index_ == 64 )
    {
      v66.block_byte_index_ = 0;
      boost::uuids::detail::sha1::process_block(&v66);
    }
    if ( v66.bit_count_low >= 0xFFFFFFF8 )
    {
      v66.bit_count_low = 0;
      if ( v66.bit_count_high > 0xFFFFFFFE )
      {
        std::runtime_error::runtime_error((std::runtime_error *)&v59, "sha1 too many bytes");
        boost::exception_detail::throw_exception_<std::runtime_error>(
          (const std::runtime_error *)&v59,
          "void boost::uuids::detail::sha1::process_byte(unsigned char)",
          "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
          104);
      }
      v30 = v66.bit_count_high + 1;
      v31 = &v66.bit_count_high;
    }
    else
    {
      v30 = v66.bit_count_low + 8;
      v31 = &v66.bit_count_low;
    }
    *v31 = v30;
  }
  v32 = operator new(4u);
  v59 = v32;
  if ( ++v66.block_byte_index_ == 64 )
  {
    v66.block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(&v66);
  }
  if ( v66.bit_count_low >= 0xFFFFFFF8 )
  {
    v66.bit_count_low = 0;
    if ( v66.bit_count_high > 0xFFFFFFFE )
      goto LABEL_105;
    v33 = v66.bit_count_high + 1;
    v34 = &v66.bit_count_high;
  }
  else
  {
    v33 = v66.bit_count_low + 8;
    v34 = &v66.bit_count_low;
  }
  *v34 = v33;
  v35 = v32[1];
  v36 = v66.block_byte_index_++;
  v66.block_[v36] = v35;
  if ( v66.block_byte_index_ == 64 )
  {
    v66.block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(&v66);
  }
  if ( v66.bit_count_low >= 0xFFFFFFF8 )
  {
    v66.bit_count_low = 0;
    if ( v66.bit_count_high > 0xFFFFFFFE )
      goto LABEL_105;
    v37 = v66.bit_count_high + 1;
    v38 = &v66.bit_count_high;
  }
  else
  {
    v37 = v66.bit_count_low + 8;
    v38 = &v66.bit_count_low;
  }
  *v38 = v37;
  v39 = v32[2];
  v40 = v66.block_byte_index_++;
  v66.block_[v40] = v39;
  if ( v66.block_byte_index_ == 64 )
  {
    v66.block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(&v66);
  }
  if ( v66.bit_count_low >= 0xFFFFFFF8 )
  {
    v66.bit_count_low = 0;
    if ( v66.bit_count_high > 0xFFFFFFFE )
      goto LABEL_105;
    v41 = v66.bit_count_high + 1;
    v42 = &v66.bit_count_high;
  }
  else
  {
    v41 = v66.bit_count_low + 8;
    v42 = &v66.bit_count_low;
  }
  *v42 = v41;
  v43 = v32[3];
  v44 = v66.block_byte_index_++;
  v66.block_[v44] = v43;
  if ( v66.block_byte_index_ == 64 )
  {
    v66.block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(&v66);
  }
  if ( v66.bit_count_low >= 0xFFFFFFF8 )
  {
    v66.bit_count_low = 0;
    if ( v66.bit_count_high <= 0xFFFFFFFE )
    {
      v45 = v66.bit_count_high + 1;
      v46 = &v66.bit_count_high;
      goto LABEL_78;
    }
LABEL_105:
    std::runtime_error::runtime_error((std::runtime_error *)ptr, "sha1 too many bytes");
    boost::exception_detail::throw_exception_<std::runtime_error>(
      (const std::runtime_error *)ptr,
      "void boost::uuids::detail::sha1::process_byte(unsigned char)",
      "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
      104);
  }
  v45 = v66.bit_count_low + 8;
  v46 = &v66.bit_count_low;
LABEL_78:
  *v46 = v45;
  for ( ii = 0; ii != 8; ++ii )
  {
    v48 = *((_BYTE *)&v59 + ii);
    v49 = v66.block_byte_index_++;
    v66.block_[v49] = v48;
    if ( v66.block_byte_index_ == 64 )
    {
      v66.block_byte_index_ = 0;
      boost::uuids::detail::sha1::process_block(&v66);
    }
    if ( v66.bit_count_low >= 0xFFFFFFF8 )
    {
      v66.bit_count_low = 0;
      if ( v66.bit_count_high > 0xFFFFFFFE )
      {
        std::runtime_error::runtime_error((std::runtime_error *)ptr, "sha1 too many bytes");
        boost::exception_detail::throw_exception_<std::runtime_error>(
          (const std::runtime_error *)ptr,
          "void boost::uuids::detail::sha1::process_byte(unsigned char)",
          "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
          104);
      }
      v50 = v66.bit_count_high + 1;
      v51 = &v66.bit_count_high;
    }
    else
    {
      v50 = v66.bit_count_low + 8;
      v51 = &v66.bit_count_low;
    }
    *v51 = v50;
  }
  if ( v59 )
    operator delete(v59);
  for ( jj = 0; jj != 20; ++jj )
  {
    v53 = *((_BYTE *)v61->rd_ + jj);
    v54 = v66.block_byte_index_++;
    v66.block_[v54] = v53;
    if ( v66.block_byte_index_ == 64 )
    {
      v66.block_byte_index_ = 0;
      boost::uuids::detail::sha1::process_block(&v66);
    }
    if ( v66.bit_count_low >= 0xFFFFFFF8 )
    {
      v66.bit_count_low = 0;
      if ( v66.bit_count_high > 0xFFFFFFFE )
      {
        std::runtime_error::runtime_error((std::runtime_error *)ptr, "sha1 too many bytes");
        boost::exception_detail::throw_exception_<std::runtime_error>(
          (const std::runtime_error *)ptr,
          "void boost::uuids::detail::sha1::process_byte(unsigned char)",
          "/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/uuid/sha1.hpp",
          104);
      }
      v55 = v66.bit_count_high + 1;
      v56 = &v66.bit_count_high;
    }
    else
    {
      v55 = v66.bit_count_low + 8;
      v56 = &v66.bit_count_low;
    }
    *v56 = v55;
  }
  boost::uuids::detail::sha1::get_digest(&v66, (boost::uuids::detail::sha1::digest_type)ptr);
  v57 = v62;
  *(_DWORD *)v62 ^= ptr[0];
  v58 = v61;
  v61->rd_[0] ^= ptr[0];
  *((_DWORD *)v57 + 1) ^= ptr[1];
  v58->rd_[1] ^= ptr[1];
  *((_DWORD *)v57 + 2) ^= ptr[2];
  v58->rd_[2] ^= ptr[2];
  *((_DWORD *)v57 + 3) ^= ptr[3];
  v58->rd_[3] ^= ptr[3];
  *((_DWORD *)v57 + 4) ^= ptr[4];
  v58->rd_[4] ^= ptr[4];
}


