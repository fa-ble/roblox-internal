// Address: 0xf1c980 | Name: _ZN5boost9unordered13unordered_mapIPN3RBX8InstanceENS2_7Network14MegaReplicator28NonReplicationDataCacheEntryENS_4hashIS4_EENSt3__18equal_toIS4_EENSA_9allocatorINSA_4pairIKS4_S7_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Instance *,RBX::Network::MegaReplicator::NonReplicationDataCacheEntry,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance * const,RBX::Network::MegaReplicator::NonReplicationDataCacheEntry>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::Instance *,RBX::Network::MegaReplicator::NonReplicationDataCacheEntry,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance *const,RBX::Network::MegaReplicator::NonReplicationDataCacheEntry> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,RBX::Network::MegaReplicator::NonReplicationDataCacheEntry> >,RBX::Instance *,RBX::Network::MegaReplicator::NonReplicationDataCacheEntry,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r13
  boost::unordered::detail::ptr_bucket *next; // rbx
  volatile signed __int32 *v5; // r12
  volatile signed __int32 *v6; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        v5 = (volatile signed __int32 *)next[5].next_;
        if ( v5 )
        {
          if ( !_InterlockedSub(v5 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 16LL))(v5);
            if ( !_InterlockedSub(v5 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
          }
        }
        v6 = (volatile signed __int32 *)next[3].next_;
        if ( v6 )
        {
          if ( !_InterlockedSub(v6 + 1, 1u) )
            operator delete((void *)v6);
        }
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xf1ca50 | Name: _ZN5boost9unordered13unordered_mapIPKN3RBX8InstanceENS2_7Network19MegaReplicationDataENS_4hashIS5_EENSt3__18equal_toIS5_EENSA_9allocatorINSA_4pairIKS5_S7_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Instance const*,RBX::Network::MegaReplicationData,boost::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,std::allocator<std::pair<RBX::Instance const* const,RBX::Network::MegaReplicationData>>>::~unordered_map(
        boost::unordered::unordered_map<const RBX::Instance *,RBX::Network::MegaReplicationData,boost::hash<const RBX::Instance *>,std::equal_to<const RBX::Instance *>,std::allocator<std::pair<const RBX::Instance *const,RBX::Network::MegaReplicationData> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::Instance *const,RBX::Network::MegaReplicationData> >,const RBX::Instance *,RBX::Network::MegaReplicationData,boost::hash<const RBX::Instance *>,std::equal_to<const RBX::Instance *> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::unordered::detail::ptr_bucket *next; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        RBX::Network::MegaReplicationData::~MegaReplicationData((RBX::Network::MegaReplicationData *)&next[3]);
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xf94730 | Name: _ZN3RBX7Network16ClientReplicator5GCJob13getNumRegionsEv
int __fastcall RBX::Network::ClientReplicator::GCJob::getNumRegions(RBX::Network::ClientReplicator::GCJob *this)
{
  return *((_DWORD *)this + 130);
}


// Address: 0xf9a7f0 | Name: _ZN5boost9unordered13unordered_mapIN3RBX12StreamRegion2IdEbNS_4hashIS4_EENSt3__18equal_toIS4_EENS7_9allocatorINS7_4pairIKS4_bEEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::StreamRegion::Id,bool,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id>,std::allocator<std::pair<RBX::StreamRegion::Id const,bool>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::StreamRegion::Id,bool,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id>,std::allocator<std::pair<const RBX::StreamRegion::Id,bool> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::StreamRegion::Id,bool> >,RBX::StreamRegion::Id,bool,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xfa4d70 | Name: _ZN5boost9unordered13unordered_mapIPKN3RBX10Reflection15ClassDescriptorENS2_7Network10Replicator14JoinDataItemV217instanceTypeCountENS_4hashIS6_EENSt3__18equal_toIS6_EENSD_9allocatorINSD_4pairIKS6_SA_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Reflection::ClassDescriptor const*,RBX::Network::Replicator::JoinDataItemV2::instanceTypeCount,boost::hash<RBX::Reflection::ClassDescriptor const*>,std::equal_to<RBX::Reflection::ClassDescriptor const*>,std::allocator<std::pair<RBX::Reflection::ClassDescriptor const* const,RBX::Network::Replicator::JoinDataItemV2::instanceTypeCount>>>::~unordered_map(
        boost::unordered::unordered_map<const RBX::Reflection::ClassDescriptor *,RBX::Network::Replicator::JoinDataItemV2::instanceTypeCount,boost::hash<const RBX::Reflection::ClassDescriptor *>,std::equal_to<const RBX::Reflection::ClassDescriptor *>,std::allocator<std::pair<const RBX::Reflection::ClassDescriptor *const,RBX::Network::Replicator::JoinDataItemV2::instanceTypeCount> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::Reflection::ClassDescriptor *const,RBX::Network::Replicator::JoinDataItemV2::instanceTypeCount> >,const RBX::Reflection::ClassDescriptor *,RBX::Network::Replicator::JoinDataItemV2::instanceTypeCount,boost::hash<const RBX::Reflection::ClassDescriptor *>,std::equal_to<const RBX::Reflection::ClassDescriptor *> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xfbea20 | Name: _ZN5boost9unordered13unordered_mapIN3RBX12StreamRegion2IdEiNS_4hashIS4_EENSt3__18equal_toIS4_EENS7_9allocatorINS7_4pairIKS4_iEEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::StreamRegion::Id,int,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id>,std::allocator<std::pair<RBX::StreamRegion::Id const,int>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::StreamRegion::Id,int,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id>,std::allocator<std::pair<const RBX::StreamRegion::Id,int> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::StreamRegion::Id,int> >,RBX::StreamRegion::Id,int,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xfd1b60 | Name: _ZN5boost9unordered13unordered_mapIlNS_8weak_ptrIN3RBX7Network16ServerReplicatorEEENS_4hashIlEENSt3__18equal_toIlEENS9_9allocatorINS9_4pairIKlS6_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<long,boost::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,boost::weak_ptr<RBX::Network::ServerReplicator>>>>::~unordered_map(
        boost::unordered::unordered_map<long,boost::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,boost::weak_ptr<RBX::Network::ServerReplicator> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const long,boost::weak_ptr<RBX::Network::ServerReplicator> > >,long,boost::weak_ptr<RBX::Network::ServerReplicator>,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::unordered::detail::ptr_bucket *next; // rbx
  volatile signed __int32 *v5; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        v5 = (volatile signed __int32 *)next[4].next_;
        if ( v5 )
        {
          if ( !_InterlockedSub(v5 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
        }
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xfd1bf0 | Name: _ZN5boost9unordered13unordered_mapIliNS_4hashIlEENSt3__18equal_toIlEENS4_9allocatorINS4_4pairIKliEEEEED2Ev
void __fastcall boost::unordered::unordered_map<long,int,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,int>>>::~unordered_map(
        boost::unordered::unordered_map<long,int,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,int> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const long,int> >,long,int,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xfd1c50 | Name: _ZN5boost9unordered13unordered_mapIN3RBX12SharedStringEiNS_4hashIS3_EENSt3__18equal_toIS3_EENS6_9allocatorINS6_4pairIKS3_iEEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<RBX::SharedString const,int>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString>,std::allocator<std::pair<const RBX::SharedString,int> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::SharedString,int> >,RBX::SharedString,int,boost::hash<RBX::SharedString>,std::equal_to<RBX::SharedString> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *next; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = (boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->h;
        boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(next + 2);
        operator delete(next);
        --this->table_.size_;
        next = (boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xfd1cd0 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEiNS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_iEEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::string,int,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,int>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,int,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,int> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,int> >,std::string,int,boost::hash<std::string>,std::equal_to<std::string > > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        if ( ((__int64)next[2].next_ & 1) != 0 )
          operator delete(next[4].next_);
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1117da0 | Name: _ZNK3RBX9Scripting14ScriptDebugger8isPausedEv
bool __fastcall RBX::Scripting::ScriptDebugger::isPaused(const RBX::Scripting::ScriptDebugger *this)
{
  return *((_QWORD *)this + 62) != 0;
}


// Address: 0x111b4f0 | Name: _ZN3RBX9Scripting14ScriptDebugger14findBreakpointEi
RBX::Scripting::DebuggerBreakpoint *__fastcall RBX::Scripting::ScriptDebugger::findBreakpoint(
        RBX::Scripting::ScriptDebugger *this,
        int line)
{
  unsigned __int64 v2; // r9
  __int64 **v3; // rax
  __int64 *v4; // rdi

  if ( !*((_QWORD *)this + 18) )
    return 0;
  v2 = *((_QWORD *)this + 17);
  v3 = *(__int64 ***)(*((_QWORD *)this + 21) + 8 * (line % v2));
  if ( !v3 )
    return 0;
  v4 = *v3;
  if ( !*v3 )
    return 0;
  do
  {
    if ( v4[1] == line )
    {
      if ( *((_DWORD *)v4 + 4) == line )
        return (RBX::Scripting::DebuggerBreakpoint *)v4[3];
    }
    else if ( v4[1] % v2 != line % v2 )
    {
      return 0;
    }
    v4 = (__int64 *)*v4;
  }
  while ( v4 );
  return 0;
}


// Address: 0x1121dd0 | Name: _ZN5boost9unordered13unordered_mapImN3RBX9Scripting14ScriptDebugger16PausedThreadDataENS_4hashImEENSt3__18equal_toImEENS8_9allocatorINS8_4pairIKmS5_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<unsigned long const,RBX::Scripting::ScriptDebugger::PausedThreadData>>>::~unordered_map(
        boost::unordered::unordered_map<unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<const unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData> >,unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // rdi
  bucket *v3; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      v3 = &buckets[this->table_.bucket_count_];
      do
        boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<unsigned long const,RBX::Scripting::ScriptDebugger::PausedThreadData>>,unsigned long,RBX::Scripting::ScriptDebugger::PausedThreadData,boost::hash<unsigned long>,std::equal_to<unsigned long>>>::delete_node(
          &this->table_,
          v3);
      while ( v3->next_ );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1121ea0 | Name: _ZN5boost9unordered13unordered_mapIiPN3RBX9Scripting18DebuggerBreakpointENS_4hashIiEENSt3__18equal_toIiEENS8_9allocatorINS8_4pairIKiS5_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<int,RBX::Scripting::DebuggerBreakpoint *,boost::hash<int>,std::equal_to<int>,std::allocator<std::pair<int const,RBX::Scripting::DebuggerBreakpoint *>>>::~unordered_map(
        boost::unordered::unordered_map<int,RBX::Scripting::DebuggerBreakpoint *,boost::hash<int>,std::equal_to<int>,std::allocator<std::pair<const int,RBX::Scripting::DebuggerBreakpoint *> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const int,RBX::Scripting::DebuggerBreakpoint *> >,int,RBX::Scripting::DebuggerBreakpoint *,boost::hash<int>,std::equal_to<int> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1200cd0 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES8_NS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_S8_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<std::string,std::string,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::string>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,std::string,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::string > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::string>>,std::string,std::string,boost::hash<std::string>,std::equal_to<std::string>>>::~table(&this->table_);
}


// Address: 0x1207fe0 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_5queueIS8_NS2_5dequeIS8_NS6_IS8_EEEEEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_SD_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::string,std::queue<std::string>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::queue<std::string>>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,std::queue<std::string>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::queue<std::string> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::queue<std::string> > >,std::string,std::queue<std::string>,boost::hash<std::string>,std::equal_to<std::string > > >::bucket_pointer buckets; // rdi
  bucket *v3; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      v3 = &buckets[this->table_.bucket_count_];
      do
        boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::queue<std::string>>>,std::string,std::queue<std::string>,boost::hash<std::string>,std::equal_to<std::string>>>::delete_node(
          &this->table_,
          v3);
      while ( v3->next_ );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x12137d0 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_10shared_ptrIN3RBX14AsyncHttpQueue7RequestEEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_SD_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<std::string,boost::shared_ptr<RBX::AsyncHttpQueue::Request>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,boost::shared_ptr<RBX::AsyncHttpQueue::Request>>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,boost::shared_ptr<RBX::AsyncHttpQueue::Request>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,boost::shared_ptr<RBX::AsyncHttpQueue::Request> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,boost::shared_ptr<RBX::AsyncHttpQueue::Request>>>,std::string,boost::shared_ptr<RBX::AsyncHttpQueue::Request>,boost::hash<std::string>,std::equal_to<std::string>>>::~table(&this->table_);
}


// Address: 0x1213950 | Name: _ZN5boost9unordered13unordered_mapIN3RBX10HttpTargetENS_10shared_ptrINS2_14AsyncHttpQueue7RequestEEENS2_16HttpTargetHasherENSt3__18equal_toIS3_EENS9_9allocatorINS9_4pairIKS3_S7_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request>,RBX::HttpTargetHasher,std::equal_to<RBX::HttpTarget>,std::allocator<std::pair<RBX::HttpTarget const,boost::shared_ptr<RBX::AsyncHttpQueue::Request>>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request>,RBX::HttpTargetHasher,std::equal_to<RBX::HttpTarget>,std::allocator<std::pair<const RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request> > >,RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request>,RBX::HttpTargetHasher,std::equal_to<RBX::HttpTarget> > >::bucket_pointer buckets; // r12
  size_t bucket_count; // r13
  boost::unordered::detail::ptr_bucket *next; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<RBX::HttpTarget const,boost::shared_ptr<RBX::AsyncHttpQueue::Request>>>>>::destroy<std::pair<RBX::HttpTarget const,boost::shared_ptr<RBX::AsyncHttpQueue::Request>>>(
          (std::allocator<boost::unordered::detail::ptr_node<std::pair<const RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request> > > > *)&this->table_.allocators_,
          (std::pair<const RBX::HttpTarget,boost::shared_ptr<RBX::AsyncHttpQueue::Request> > *)&next[2]);
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x12542f0 | Name: _ZN5boost9unordered13unordered_mapIN3RBX9ContentIdENSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS_4hashIS3_EENS4_8equal_toIS3_EENS8_INS4_4pairIKS3_SA_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<RBX::ContentId,std::string,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<RBX::ContentId const,std::string>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::ContentId,std::string,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>,std::allocator<std::pair<const RBX::ContentId,std::string > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::ContentId const,std::string>>,RBX::ContentId,std::string,boost::hash<RBX::ContentId>,std::equal_to<RBX::ContentId>>>::~table(&this->table_);
}


// Address: 0x125af90 | Name: _ZN5boost9unordered13unordered_mapINSt3__14pairINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES9_EENS2_15__list_iteratorINS3_ISA_NS3_ImN3RBX13CachedContentEEEEEPvEENS_4hashISA_EENS2_8equal_toISA_EENS7_INS3_IKSA_SH_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<std::pair<std::string,std::string>,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::CachedContent>>,void *>,boost::hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::CachedContent>>,void *>>>>::~unordered_map(
        boost::unordered::unordered_map<std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::CachedContent> >,void *>,boost::hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::CachedContent> >,void *> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::CachedContent>>,void *>>>,std::pair<std::string,std::string>,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::CachedContent>>,void *>,boost::hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>>>::~table(&this->table_);
}


// Address: 0x125bdc0 | Name: _ZN5boost9unordered13unordered_mapIN3RBX10HttpTargetENSt3__115__list_iteratorINS4_4pairIS3_NS6_ImNS2_13CachedContentEEEEEPvEENS2_16HttpTargetHasherENS4_8equal_toIS3_EENS4_9allocatorINS6_IKS3_SB_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::HttpTarget,std::__list_iterator<std::pair<RBX::HttpTarget,std::pair<unsigned long,RBX::CachedContent>>,void *>,RBX::HttpTargetHasher,std::equal_to<RBX::HttpTarget>,std::allocator<std::pair<RBX::HttpTarget const,std::__list_iterator<std::pair<RBX::HttpTarget,std::pair<unsigned long,RBX::CachedContent>>,void *>>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::HttpTarget,std::__list_iterator<std::pair<RBX::HttpTarget,std::pair<unsigned long,RBX::CachedContent> >,void *>,RBX::HttpTargetHasher,std::equal_to<RBX::HttpTarget>,std::allocator<std::pair<const RBX::HttpTarget,std::__list_iterator<std::pair<RBX::HttpTarget,std::pair<unsigned long,RBX::CachedContent> >,void *> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::HttpTarget,std::__list_iterator<std::pair<RBX::HttpTarget,std::pair<unsigned long,RBX::CachedContent> >,void *> > >,RBX::HttpTarget,std::__list_iterator<std::pair<RBX::HttpTarget,std::pair<unsigned long,RBX::CachedContent> >,void *>,RBX::HttpTargetHasher,std::equal_to<RBX::HttpTarget> > >::bucket_pointer buckets; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::HttpTarget const,std::__list_iterator<std::pair<RBX::HttpTarget,std::pair<unsigned long,RBX::CachedContent>>,void *>>>,RBX::HttpTarget,std::__list_iterator<std::pair<RBX::HttpTarget,std::pair<unsigned long,RBX::CachedContent>>,void *>,RBX::HttpTargetHasher,std::equal_to<RBX::HttpTarget>>>::delete_nodes(
        &this->table_,
        &buckets[this->table_.bucket_count_],
        0);
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1265260 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_15__list_iteratorINS2_4pairIS8_NSA_ImN3RBX21BatchThumbnailFetcher20BatchThumbnailResultEEEEEPvEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INSA_IKS8_SH_EEEEE4findERSM_
boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult> >,void *>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult> >,void *> > > >::iterator __fastcall boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult>>,void *>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult>>,void *>>>>::find(
        boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult> >,void *>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult> >,void *> > > > *this,
        const boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult> >,void *>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult> >,void *> > > >::key_type *k)
{
  unsigned __int64 v2; // rdx
  char *v3; // r11
  unsigned __int64 v4; // rdx
  __int64 v5; // r9
  unsigned __int64 v6; // rdx
  unsigned __int64 v7; // rax
  unsigned __int64 v8; // rcx

  v2 = *(unsigned __int8 *)k;
  if ( (v2 & 1) == 0 )
  {
    v3 = (char *)k + 1;
    v4 = v2 >> 1;
    if ( v4 )
      goto LABEL_3;
LABEL_7:
    v6 = 0;
    return boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult>>,void *>>>,std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult>>,void *>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
             &this->table_,
             2147483649u
           * ((21
             * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
              ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14)))
            ^ ((21
              * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
               ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14))) >> 28)),
             k,
             (const std::equal_to<std::string > *)&this->table_.funcs_[(unsigned __int8)this->table_.current_]);
  }
  v3 = (char *)*((_QWORD *)k + 2);
  v4 = *((_QWORD *)k + 1);
  if ( !v4 )
    goto LABEL_7;
LABEL_3:
  v5 = v4 & 1;
  if ( v4 == 1 )
  {
    v6 = 0;
    if ( !v5 )
      return boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult>>,void *>>>,std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult>>,void *>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
               &this->table_,
               2147483649u
             * ((21
               * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
                ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14)))
              ^ ((21
                * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
                 ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14))) >> 28)),
               k,
               (const std::equal_to<std::string > *)&this->table_.funcs_[(unsigned __int8)this->table_.current_]);
    goto LABEL_11;
  }
  v7 = v5 - v4;
  v6 = 0;
  do
  {
    v8 = v6 ^ (*v3 + (v6 >> 2) + (v6 << 6) + 2654435769u);
    v6 = v8 ^ (v3[1] + (v8 >> 2) + (v8 << 6) + 2654435769u);
    v3 += 2;
    v7 += 2LL;
  }
  while ( v7 );
  if ( v5 )
LABEL_11:
    v6 ^= (v6 << 6) + 2654435769u + (v6 >> 2) + *v3;
  return boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult>>,void *>>>,std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::BatchThumbnailFetcher::BatchThumbnailResult>>,void *>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
           &this->table_,
           2147483649u
         * ((21
           * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
            ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14)))
          ^ ((21
            * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
             ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14))) >> 28)),
           k,
           (const std::equal_to<std::string > *)&this->table_.funcs_[(unsigned __int8)this->table_.current_]);
}


// Address: 0x12f2880 | Name: _ZN5boost9unordered13unordered_mapINSt3__14pairINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES9_EENS2_15__list_iteratorINS3_ISA_NS3_ImN3RBX13LuaWebService23CachedLuaWebServiceInfoEEEEEPvEENS_4hashISA_EENS2_8equal_toISA_EENS7_INS3_IKSA_SI_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<std::pair<std::string,std::string>,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo>>,void *>,boost::hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo>>,void *>>>>::~unordered_map(
        boost::unordered::unordered_map<std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo> >,void *>,boost::hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo> >,void *> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo>>,void *>>>,std::pair<std::string,std::string>,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedLuaWebServiceInfo>>,void *>,boost::hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>>>::~table(&this->table_);
}


// Address: 0x12f41e0 | Name: _ZN5boost9unordered13unordered_mapINSt3__14pairINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEES9_EENS2_15__list_iteratorINS3_ISA_NS3_ImN3RBX13LuaWebService26CachedRawLuaWebServiceInfoEEEEEPvEENS_4hashISA_EENS2_8equal_toISA_EENS7_INS3_IKSA_SI_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<std::pair<std::string,std::string>,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo>>,void *>,boost::hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>,std::allocator<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo>>,void *>>>>::~unordered_map(
        boost::unordered::unordered_map<std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo> >,void *>,boost::hash<std::pair<std::string,std::string > >,std::equal_to<std::pair<std::string,std::string > >,std::allocator<std::pair<const std::pair<std::string,std::string >,std::__list_iterator<std::pair<std::pair<std::string,std::string >,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo> >,void *> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::pair<std::string,std::string> const,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo>>,void *>>>,std::pair<std::string,std::string>,std::__list_iterator<std::pair<std::pair<std::string,std::string>,std::pair<unsigned long,RBX::LuaWebService::CachedRawLuaWebServiceInfo>>,void *>,boost::hash<std::pair<std::string,std::string>>,std::equal_to<std::pair<std::string,std::string>>>>::~table(&this->table_);
}


// Address: 0x1305e60 | Name: _ZN5boost9unordered13unordered_mapIN12_GLOBAL__N_17NameKeyEPN3RBX4NameENS_4hashIS3_EENSt3__18equal_toIS3_EENS9_9allocatorINS9_4pairIKS3_S6_EEEEE4findERSE_
boost::unordered::unordered_map<(anonymous namespace)::NameKey,RBX::Name *,boost::hash<(anonymous namespace)::NameKey>,std::equal_to<(anonymous namespace)::NameKey>,std::allocator<std::pair<const (anonymous namespace)::NameKey,RBX::Name *> > >::iterator __fastcall boost::unordered::unordered_map<`anonymous namespace'::NameKey,RBX::Name *,boost::hash<`anonymous namespace'::NameKey>,std::equal_to<`anonymous namespace'::NameKey>,std::allocator<std::pair<`anonymous namespace'::NameKey const,RBX::Name *>>>::find(
        boost::unordered::unordered_map<(anonymous namespace)::NameKey,RBX::Name *,boost::hash<(anonymous namespace)::NameKey>,std::equal_to<(anonymous namespace)::NameKey>,std::allocator<std::pair<const (anonymous namespace)::NameKey,RBX::Name *> > > *this,
        const boost::unordered::unordered_map<(anonymous namespace)::NameKey,RBX::Name *,boost::hash<(anonymous namespace)::NameKey>,std::equal_to<(anonymous namespace)::NameKey>,std::allocator<std::pair<const (anonymous namespace)::NameKey,RBX::Name *> > >::key_type *k)
{
  const char *s; // r15
  size_t v3; // rax
  size_t v4; // rcx
  unsigned __int64 v5; // rax
  const char *v6; // rdx
  size_t v7; // rsi
  unsigned __int64 v8; // rbp
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // r12
  size_t v11; // r13
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  boost::unordered::unordered_map<(anonymous namespace)::NameKey,RBX::Name *,boost::hash<(anonymous namespace)::NameKey>,std::equal_to<(anonymous namespace)::NameKey>,std::allocator<std::pair<const (anonymous namespace)::NameKey,RBX::Name *> > >::iterator v13; // rbx
  size_t hash; // rax

  s = k->s;
  v3 = strlen(k->s);
  if ( v3 )
  {
    v4 = v3 & 1;
    if ( v3 == 1 )
    {
      v5 = 0;
      v6 = s;
      if ( !v4 )
        goto LABEL_11;
    }
    else
    {
      v7 = v4 - v3;
      v5 = 0;
      v6 = s;
      do
      {
        v8 = v5 ^ (*v6 + (v5 >> 2) + (v5 << 6) + 2654435769u);
        v5 = v8 ^ (v6[1] + (v8 >> 2) + (v8 << 6) + 2654435769u);
        v6 += 2;
        v7 += 2LL;
      }
      while ( v7 );
      if ( !v4 )
      {
LABEL_11:
        if ( !this->table_.size_ )
          return 0;
        goto LABEL_12;
      }
    }
    v5 ^= (v5 << 6) + 2654435769u + (v5 >> 2) + *v6;
    goto LABEL_11;
  }
  v5 = 0;
  if ( !this->table_.size_ )
    return 0;
LABEL_12:
  v9 = 265 * ((~v5 + (v5 << 21)) ^ ((~v5 + (v5 << 21)) >> 24));
  v10 = 2147483649u * ((21 * (v9 ^ (v9 >> 14))) ^ ((21 * (v9 ^ (v9 >> 14))) >> 28));
  v11 = this->table_.bucket_count_ - 1;
  next = this->table_.buckets_[v11 & v10].next_;
  if ( next )
  {
    v13.node_ = (boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<const (anonymous namespace)::NameKey,RBX::Name *> > >::node_pointer)next->next_;
    if ( next->next_ )
    {
      do
      {
        hash = v13.node_->hash_;
        if ( hash == v10 )
        {
          if ( !strcmp(s, *(const char **)v13.node_->value_base_.data_.data_.buf) )
            return v13;
        }
        else if ( (v11 & hash) != (v11 & v10) )
        {
          return 0;
        }
        v13.node_ = (boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<const (anonymous namespace)::NameKey,RBX::Name *> > >::node_pointer)v13.node_->next_;
      }
      while ( v13.node_ );
    }
  }
  return 0;
}


// Address: 0x1340f20 | Name: _ZN5boost9unordered13unordered_mapImNS_10shared_ptrIN3RBX10Soundscape26NonBlockingFmodSoundLoaderEEENS_4hashImEENSt3__18equal_toImEENS9_9allocatorINS9_4pairIKmS6_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<unsigned long,boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<unsigned long const,boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>>::~unordered_map(
        boost::unordered::unordered_map<unsigned long,boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<const unsigned long,boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<unsigned long const,boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>>>,unsigned long,boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader>,boost::hash<unsigned long>,std::equal_to<unsigned long>>>::~table(&this->table_);
}


// Address: 0x14e4df0 | Name: _ZN5boost9unordered13unordered_mapIN3RBX11ChatService18MessageAndSenderIdENSt3__115__list_iteratorINS5_4pairIS4_NS7_ImNS2_16TextFilterResultEEEEEPvEENS_4hashIS4_EENS5_8equal_toIS4_EENS5_9allocatorINS7_IKS4_SC_EEEEE4findERSI_
boost::unordered::unordered_map<RBX::ChatService::MessageAndSenderId,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult> >,void *>,boost::hash<RBX::ChatService::MessageAndSenderId>,std::equal_to<RBX::ChatService::MessageAndSenderId>,std::allocator<std::pair<const RBX::ChatService::MessageAndSenderId,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult> >,void *> > > >::iterator __fastcall boost::unordered::unordered_map<RBX::ChatService::MessageAndSenderId,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult>>,void *>,boost::hash<RBX::ChatService::MessageAndSenderId>,std::equal_to<RBX::ChatService::MessageAndSenderId>,std::allocator<std::pair<RBX::ChatService::MessageAndSenderId const,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult>>,void *>>>>::find(
        boost::unordered::unordered_map<RBX::ChatService::MessageAndSenderId,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult> >,void *>,boost::hash<RBX::ChatService::MessageAndSenderId>,std::equal_to<RBX::ChatService::MessageAndSenderId>,std::allocator<std::pair<const RBX::ChatService::MessageAndSenderId,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult> >,void *> > > > *this,
        const boost::unordered::unordered_map<RBX::ChatService::MessageAndSenderId,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult> >,void *>,boost::hash<RBX::ChatService::MessageAndSenderId>,std::equal_to<RBX::ChatService::MessageAndSenderId>,std::allocator<std::pair<const RBX::ChatService::MessageAndSenderId,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult> >,void *> > > >::key_type *k)
{
  unsigned __int64 v2; // r10
  char *v3; // r11
  unsigned __int64 v4; // r10
  unsigned __int64 v5; // rdx
  unsigned __int64 v6; // rdx
  unsigned __int64 v7; // rax
  unsigned __int64 v8; // rcx
  unsigned __int64 v9; // rax

  v2 = *(unsigned __int8 *)k;
  if ( (v2 & 1) != 0 )
  {
    v3 = (char *)*((_QWORD *)k + 2);
    v4 = *((_QWORD *)k + 1);
  }
  else
  {
    v3 = (char *)k + 1;
    v4 = v2 >> 1;
  }
  v5 = 2654435769LL;
  if ( v4 )
  {
    if ( v4 == 1 )
    {
      v6 = 0;
    }
    else
    {
      v7 = (v4 & 1) - v4;
      v6 = 0;
      do
      {
        v8 = v6 ^ (*v3 + (v6 >> 2) + (v6 << 6) + 2654435769u);
        v6 = v8 ^ (v3[1] + (v8 >> 2) + (v8 << 6) + 2654435769u);
        v3 += 2;
        v7 += 2LL;
      }
      while ( v7 );
      if ( (v4 & 1) == 0 )
        goto LABEL_11;
    }
    v6 ^= (v6 << 6) + 2654435769u + (v6 >> 2) + *v3;
LABEL_11:
    v5 = v6 + 2654435769u;
  }
  v9 = 21
     * ((265
       * ((~(v5 ^ (*((_QWORD *)k + 3) + 2654435769LL + (v5 << 6) + (v5 >> 2)))
         + ((v5 ^ (*((_QWORD *)k + 3) + 2654435769LL + (v5 << 6) + (v5 >> 2))) << 21))
        ^ ((~(v5 ^ (*((_QWORD *)k + 3) + 2654435769LL + (v5 << 6) + (v5 >> 2)))
          + ((v5 ^ (*((_QWORD *)k + 3) + 2654435769LL + (v5 << 6) + (v5 >> 2))) << 21)) >> 24)))
      ^ ((265
        * ((~(v5 ^ (*((_QWORD *)k + 3) + 2654435769LL + (v5 << 6) + (v5 >> 2)))
          + ((v5 ^ (*((_QWORD *)k + 3) + 2654435769LL + (v5 << 6) + (v5 >> 2))) << 21))
         ^ ((~(v5 ^ (*((_QWORD *)k + 3) + 2654435769LL + (v5 << 6) + (v5 >> 2)))
           + ((v5 ^ (*((_QWORD *)k + 3) + 2654435769LL + (v5 << 6) + (v5 >> 2))) << 21)) >> 24))) >> 14));
  return boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::ChatService::MessageAndSenderId const,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult>>,void *>>>,RBX::ChatService::MessageAndSenderId,std::__list_iterator<std::pair<RBX::ChatService::MessageAndSenderId,std::pair<unsigned long,RBX::TextFilterResult>>,void *>,boost::hash<RBX::ChatService::MessageAndSenderId>,std::equal_to<RBX::ChatService::MessageAndSenderId>>>::find_node_impl<RBX::ChatService::MessageAndSenderId,std::equal_to<RBX::ChatService::MessageAndSenderId>>(
           &this->table_,
           2147483649u * (v9 ^ (v9 >> 28)),
           (const RBX::ChatService::MessageAndSenderId *)k,
           (const std::equal_to<RBX::ChatService::MessageAndSenderId> *)&this->table_.funcs_[(unsigned __int8)this->table_.current_]);
}


// Address: 0x16114e0 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_15__list_iteratorINS2_4pairIS8_NSA_ImN3RBX4TimeEEEEEPvEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INSA_IKS8_SG_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Time>>,void *>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Time>>,void *>>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Time> >,void *>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Time> >,void *> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Time>>,void *>>>,std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Time>>,void *>,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(&this->table_);
}


// Address: 0x1790a80 | Name: _ZN5boost9unordered13unordered_mapIPN3RBX8InstanceEN3rbx7signals17scoped_connectionENS_4hashIS4_EENSt3__18equal_toIS4_EENSA_9allocatorINSA_4pairIKS4_S7_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Instance *,rbx::signals::scoped_connection,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance * const,rbx::signals::scoped_connection>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::Instance *,rbx::signals::scoped_connection,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<std::pair<RBX::Instance *const,rbx::signals::scoped_connection> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,rbx::signals::scoped_connection> >,RBX::Instance *,rbx::signals::scoped_connection,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r13
  rbx::signals::connection *next; // r12
  volatile signed __int32 *v5; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = (rbx::signals::connection *)buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->weak_slot.p_;
        rbx::signals::connection::disconnect(next + 3);
        v5 = (volatile signed __int32 *)&next[3].weak_slot.p_->rbx::intrusive_ptr_target<rbx::signals::slot_base>;
        if ( v5 )
        {
          if ( !_InterlockedSub(v5 + 1, 1u) )
            operator delete((void *)v5);
        }
        operator delete(next);
        --this->table_.size_;
        next = (rbx::signals::connection *)buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1790b50 | Name: _ZN5boost9unordered13unordered_mapINS_10shared_ptrIN3RBX7GuiBaseEEEiNS_4hashIS5_EENSt3__18equal_toIS5_EENS8_9allocatorINS8_4pairIKS5_iEEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<boost::shared_ptr<RBX::GuiBase>,int,boost::hash<boost::shared_ptr<RBX::GuiBase>>,std::equal_to<boost::shared_ptr<RBX::GuiBase>>,std::allocator<std::pair<boost::shared_ptr<RBX::GuiBase> const,int>>>::~unordered_map(
        boost::unordered::unordered_map<boost::shared_ptr<RBX::GuiBase>,int,boost::hash<boost::shared_ptr<RBX::GuiBase> >,std::equal_to<boost::shared_ptr<RBX::GuiBase> >,std::allocator<std::pair<const boost::shared_ptr<RBX::GuiBase>,int> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<boost::shared_ptr<RBX::GuiBase> const,int>>,boost::shared_ptr<RBX::GuiBase>,int,boost::hash<boost::shared_ptr<RBX::GuiBase>>,std::equal_to<boost::shared_ptr<RBX::GuiBase>>>>::~table(&this->table_);
}


// Address: 0x1790bf0 | Name: _ZN5boost9unordered13unordered_mapINS_10shared_ptrIN3RBX11InputObjectEEENSt3__16vectorINS3_17GuiLayerCollector11SunkGuiDataENS6_9allocatorIS9_EEEENS_4hashIS5_EENS6_8equal_toIS5_EENSA_INS6_4pairIKS5_SC_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData>,boost::hash<boost::shared_ptr<RBX::InputObject>>,std::equal_to<boost::shared_ptr<RBX::InputObject>>,std::allocator<std::pair<boost::shared_ptr<RBX::InputObject> const,std::vector<RBX::GuiLayerCollector::SunkGuiData>>>>::~unordered_map(
        boost::unordered::unordered_map<boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData>,boost::hash<boost::shared_ptr<RBX::InputObject> >,std::equal_to<boost::shared_ptr<RBX::InputObject> >,std::allocator<std::pair<const boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData> > >,boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData>,boost::hash<boost::shared_ptr<RBX::InputObject> >,std::equal_to<boost::shared_ptr<RBX::InputObject> > > >::bucket_pointer buckets; // r12
  size_t bucket_count; // r13
  boost::unordered::detail::ptr_bucket *next; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<boost::shared_ptr<RBX::InputObject> const,std::vector<RBX::GuiLayerCollector::SunkGuiData>>>>>::destroy<std::pair<boost::shared_ptr<RBX::InputObject> const,std::vector<RBX::GuiLayerCollector::SunkGuiData>>>(
          (std::allocator<boost::unordered::detail::ptr_node<std::pair<const boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData> > > > *)&this->table_.allocators_,
          (std::pair<const boost::shared_ptr<RBX::InputObject>,std::vector<RBX::GuiLayerCollector::SunkGuiData> > *)&next[2]);
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1963320 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_3setIlNS2_4lessIlEENS6_IlEEEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_SD_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::set<long>>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::~table(&this->table_);
}


// Address: 0x197b800 | Name: _ZN5boost9unordered13unordered_mapIlNSt3__115__list_iteratorINS2_4pairIlNS4_ImNS_10shared_ptrIN3RBX9AnimationEEEEEEEPvEENS_4hashIlEENS2_8equal_toIlEENS2_9allocatorINS4_IKlSC_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<long,std::__list_iterator<std::pair<long,std::pair<unsigned long,boost::shared_ptr<RBX::Animation>>>,void *>,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,std::__list_iterator<std::pair<long,std::pair<unsigned long,boost::shared_ptr<RBX::Animation>>>,void *>>>>::~unordered_map(
        boost::unordered::unordered_map<long,std::__list_iterator<std::pair<long,std::pair<unsigned long,boost::shared_ptr<RBX::Animation> > >,void *>,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,std::__list_iterator<std::pair<long,std::pair<unsigned long,boost::shared_ptr<RBX::Animation> > >,void *> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const long,std::__list_iterator<std::pair<long,std::pair<unsigned long,boost::shared_ptr<RBX::Animation> > >,void *> > >,long,std::__list_iterator<std::pair<long,std::pair<unsigned long,boost::shared_ptr<RBX::Animation> > >,void *>,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1a06370 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_15__list_iteratorINS2_4pairIS8_NSA_ImN3RBX7Players22ThumbnailRequestRecordEEEEEPvEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INSA_IKS8_SH_EEEEE4findERSM_
boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord> >,void *>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord> >,void *> > > >::iterator __fastcall boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>>>>::find(
        boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord> >,void *>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord> >,void *> > > > *this,
        const boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord> >,void *>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord> >,void *> > > >::key_type *k)
{
  unsigned __int64 v2; // rdx
  char *v3; // r11
  unsigned __int64 v4; // rdx
  __int64 v5; // r9
  unsigned __int64 v6; // rdx
  unsigned __int64 v7; // rax
  unsigned __int64 v8; // rcx

  v2 = *(unsigned __int8 *)k;
  if ( (v2 & 1) == 0 )
  {
    v3 = (char *)k + 1;
    v4 = v2 >> 1;
    if ( v4 )
      goto LABEL_3;
LABEL_7:
    v6 = 0;
    return boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>>>,std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
             &this->table_,
             2147483649u
           * ((21
             * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
              ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14)))
            ^ ((21
              * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
               ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14))) >> 28)),
             k,
             (const std::equal_to<std::string > *)&this->table_.funcs_[(unsigned __int8)this->table_.current_]);
  }
  v3 = (char *)*((_QWORD *)k + 2);
  v4 = *((_QWORD *)k + 1);
  if ( !v4 )
    goto LABEL_7;
LABEL_3:
  v5 = v4 & 1;
  if ( v4 == 1 )
  {
    v6 = 0;
    if ( !v5 )
      return boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>>>,std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
               &this->table_,
               2147483649u
             * ((21
               * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
                ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14)))
              ^ ((21
                * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
                 ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14))) >> 28)),
               k,
               (const std::equal_to<std::string > *)&this->table_.funcs_[(unsigned __int8)this->table_.current_]);
    goto LABEL_11;
  }
  v7 = v5 - v4;
  v6 = 0;
  do
  {
    v8 = v6 ^ (*v3 + (v6 >> 2) + (v6 << 6) + 2654435769u);
    v6 = v8 ^ (v3[1] + (v8 >> 2) + (v8 << 6) + 2654435769u);
    v3 += 2;
    v7 += 2LL;
  }
  while ( v7 );
  if ( v5 )
LABEL_11:
    v6 ^= (v6 << 6) + 2654435769u + (v6 >> 2) + *v3;
  return boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>>>,std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
           &this->table_,
           2147483649u
         * ((21
           * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
            ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14)))
          ^ ((21
            * ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24)))
             ^ ((265 * ((~v6 + (v6 << 21)) ^ ((~v6 + (v6 << 21)) >> 24))) >> 14))) >> 28)),
           k,
           (const std::equal_to<std::string > *)&this->table_.funcs_[(unsigned __int8)this->table_.current_]);
}


// Address: 0x1a06f00 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_15__list_iteratorINS2_4pairIS8_NSA_ImN3RBX7Players22ThumbnailRequestRecordEEEEEPvEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INSA_IKS8_SH_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord> >,void *>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord> >,void *> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>>>,std::string,std::__list_iterator<std::pair<std::string,std::pair<unsigned long,RBX::Players::ThumbnailRequestRecord>>,void *>,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(&this->table_);
}


// Address: 0x1b6a8e0 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN3RBX10Reflection7VariantENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_SB_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(&this->table_);
}


// Address: 0x1bbca70 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN3RBX11TextScraper10TimedEntryENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_SB_EEEEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_map<std::string,RBX::TextScraper::TimedEntry,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::TextScraper::TimedEntry>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,RBX::TextScraper::TimedEntry,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::TextScraper::TimedEntry> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::TextScraper::TimedEntry>>,std::string,RBX::TextScraper::TimedEntry,boost::hash<std::string>,std::equal_to<std::string>>>::~table(&this->table_);
}


// Address: 0x1bbca80 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEN3RBX11TextScraper21TimedEntry_deprecatedENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_SB_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::string,RBX::TextScraper::TimedEntry_deprecated,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::TextScraper::TimedEntry_deprecated>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,RBX::TextScraper::TimedEntry_deprecated,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::TextScraper::TimedEntry_deprecated> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::TextScraper::TimedEntry_deprecated> >,std::string,RBX::TextScraper::TimedEntry_deprecated,boost::hash<std::string>,std::equal_to<std::string > > >::bucket_pointer buckets; // r12
  size_t bucket_count; // r13
  boost::unordered::detail::ptr_bucket *next; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        boost::unordered::detail::allocator_traits<std::allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::TextScraper::TimedEntry_deprecated>>>>::destroy<std::pair<std::string const,RBX::TextScraper::TimedEntry_deprecated>>(
          (std::allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,RBX::TextScraper::TimedEntry_deprecated> > > *)&this->table_.allocators_,
          (std::pair<const std::string,RBX::TextScraper::TimedEntry_deprecated> *)&next[2]);
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1bf73c0 | Name: _ZN5boost9unordered13unordered_mapIN3RBX10Controller6ButtonENS3_11BoundButtonENS_4hashIS4_EENSt3__18equal_toIS4_EENS8_9allocatorINS8_4pairIKS4_S5_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Controller::Button,RBX::Controller::BoundButton,boost::hash<RBX::Controller::Button>,std::equal_to<RBX::Controller::Button>,std::allocator<std::pair<RBX::Controller::Button const,RBX::Controller::BoundButton>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::Controller::Button,RBX::Controller::BoundButton,boost::hash<RBX::Controller::Button>,std::equal_to<RBX::Controller::Button>,std::allocator<std::pair<const RBX::Controller::Button,RBX::Controller::BoundButton> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Controller::Button const,RBX::Controller::BoundButton>>,RBX::Controller::Button,RBX::Controller::BoundButton,boost::hash<RBX::Controller::Button>,std::equal_to<RBX::Controller::Button>>>::delete_buckets(&this->table_);
}


// Address: 0x1dea6e0 | Name: _ZN5boost9unordered13unordered_mapImN3RBX9Collision25BulletCollisionBoxSetPool13BoxSetStorageENS_4hashImEENSt3__18equal_toImEENS8_9allocatorINS8_4pairIKmS5_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<unsigned long const,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage>>>::~unordered_map(
        boost::unordered::unordered_map<unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<const unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage> >,unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1e00110 | Name: _ZN5boost9unordered13unordered_mapImPN3RBX9Collision12CellChildrenENS_4hashImEENSt3__18equal_toImEENS8_9allocatorINS8_4pairIKmS5_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<unsigned long,RBX::Collision::CellChildren *,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<unsigned long const,RBX::Collision::CellChildren *>>>::~unordered_map(
        boost::unordered::unordered_map<unsigned long,RBX::Collision::CellChildren *,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<const unsigned long,RBX::Collision::CellChildren *> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::CellChildren *> >,unsigned long,RBX::Collision::CellChildren *,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1e385c0 | Name: _ZN5boost9unordered13unordered_mapIN3RBX12Vector3int32ENS2_10ChunkClumpIPNS2_21SmoothClusterGeometry9ChunkMeshELi2EEENS_4hashIS3_EENSt3__18equal_toIS3_EENSB_9allocatorINSB_4pairIKS3_S8_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Vector3int32,RBX::ChunkClump<RBX::SmoothClusterGeometry::ChunkMesh *,2>,boost::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,std::allocator<std::pair<RBX::Vector3int32 const,RBX::ChunkClump<RBX::SmoothClusterGeometry::ChunkMesh *,2>>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::Vector3int32,RBX::ChunkClump<RBX::SmoothClusterGeometry::ChunkMesh *,2>,boost::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,std::allocator<std::pair<const RBX::Vector3int32,RBX::ChunkClump<RBX::SmoothClusterGeometry::ChunkMesh *,2> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::Vector3int32,RBX::ChunkClump<RBX::SmoothClusterGeometry::ChunkMesh *,2> > >,RBX::Vector3int32,RBX::ChunkClump<RBX::SmoothClusterGeometry::ChunkMesh *,2>,boost::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        RBX::ChunkClump<RBX::SmoothClusterGeometry::ChunkMesh *,2>::~ChunkClump((RBX::ChunkClump<RBX::SmoothClusterGeometry::ChunkMesh *,2> *)&next[4]);
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1e38640 | Name: _ZN5boost9unordered13unordered_mapIN3RBX12Vector3int32EPNS2_21SmoothClusterGeometry9ChunkMeshENS_4hashIS3_EENSt3__18equal_toIS3_EENS9_9allocatorINS9_4pairIKS3_S6_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Vector3int32,RBX::SmoothClusterGeometry::ChunkMesh *,boost::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,std::allocator<std::pair<RBX::Vector3int32 const,RBX::SmoothClusterGeometry::ChunkMesh *>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::Vector3int32,RBX::SmoothClusterGeometry::ChunkMesh *,boost::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32>,std::allocator<std::pair<const RBX::Vector3int32,RBX::SmoothClusterGeometry::ChunkMesh *> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::Vector3int32,RBX::SmoothClusterGeometry::ChunkMesh *> >,RBX::Vector3int32,RBX::SmoothClusterGeometry::ChunkMesh *,boost::hash<RBX::Vector3int32>,std::equal_to<RBX::Vector3int32> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1e54860 | Name: _ZN5boost9unordered13unordered_mapIN3RBX4GuidEPNS2_9PrimitiveENS_4hashIS3_EENSt3__18equal_toIS3_EENS8_9allocatorINS8_4pairIKS3_S5_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Guid,RBX::Primitive *,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid>,std::allocator<std::pair<RBX::Guid const,RBX::Primitive *>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::Guid,RBX::Primitive *,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid>,std::allocator<std::pair<const RBX::Guid,RBX::Primitive *> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::Guid,RBX::Primitive *> >,RBX::Guid,RBX::Primitive *,boost::hash<RBX::Guid>,std::equal_to<RBX::Guid> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1e548c0 | Name: _ZN5boost9unordered13unordered_mapImPN3RBX9PrimitiveENS_4hashImEENSt3__18equal_toImEENS7_9allocatorINS7_4pairIKmS4_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<unsigned long,RBX::Primitive *,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<unsigned long const,RBX::Primitive *>>>::~unordered_map(
        boost::unordered::unordered_map<unsigned long,RBX::Primitive *,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<const unsigned long,RBX::Primitive *> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Primitive *> >,unsigned long,RBX::Primitive *,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1e549d0 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEaNS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_aEEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::string,signed char,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,signed char>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,signed char,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,signed char> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,signed char>>,std::string,signed char,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(&this->table_);
}


// Address: 0x1eac0e0 | Name: _ZN5boost9unordered13unordered_mapIjN3RBX13GlyphProvider16SizeSpecificDataENS_4hashIjEENSt3__18equal_toIjEENS7_9allocatorINS7_4pairIKjS4_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<unsigned int,RBX::GlyphProvider::SizeSpecificData,boost::hash<unsigned int>,std::equal_to<unsigned int>,std::allocator<std::pair<unsigned int const,RBX::GlyphProvider::SizeSpecificData>>>::~unordered_map(
        boost::unordered::unordered_map<unsigned int,RBX::GlyphProvider::SizeSpecificData,boost::hash<unsigned int>,std::equal_to<unsigned int>,std::allocator<std::pair<const unsigned int,RBX::GlyphProvider::SizeSpecificData> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned int,RBX::GlyphProvider::SizeSpecificData> >,unsigned int,RBX::GlyphProvider::SizeSpecificData,boost::hash<unsigned int>,std::equal_to<unsigned int> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1eac140 | Name: _ZN5boost9unordered13unordered_mapINSt3__14pairIjjEEiNS_4hashIS4_EENS2_8equal_toIS4_EENS2_9allocatorINS3_IKS4_iEEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::pair<unsigned int,unsigned int>,int,boost::hash<std::pair<unsigned int,unsigned int>>,std::equal_to<std::pair<unsigned int,unsigned int>>,std::allocator<std::pair<std::pair<unsigned int,unsigned int> const,int>>>::~unordered_map(
        boost::unordered::unordered_map<std::pair<unsigned int,unsigned int>,int,boost::hash<std::pair<unsigned int,unsigned int> >,std::equal_to<std::pair<unsigned int,unsigned int> >,std::allocator<std::pair<const std::pair<unsigned int,unsigned int>,int> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::pair<unsigned int,unsigned int>,int> >,std::pair<unsigned int,unsigned int>,int,boost::hash<std::pair<unsigned int,unsigned int> >,std::equal_to<std::pair<unsigned int,unsigned int> > > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1eac1a0 | Name: _ZN5boost9unordered13unordered_mapINSt3__14pairIjjEEN3RBX10Typesetter5GlyphENS_4hashIS4_EENS2_8equal_toIS4_EENS2_9allocatorINS3_IKS4_S7_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::pair<unsigned int,unsigned int>,RBX::Typesetter::Glyph,boost::hash<std::pair<unsigned int,unsigned int>>,std::equal_to<std::pair<unsigned int,unsigned int>>,std::allocator<std::pair<std::pair<unsigned int,unsigned int> const,RBX::Typesetter::Glyph>>>::~unordered_map(
        boost::unordered::unordered_map<std::pair<unsigned int,unsigned int>,RBX::Typesetter::Glyph,boost::hash<std::pair<unsigned int,unsigned int> >,std::equal_to<std::pair<unsigned int,unsigned int> >,std::allocator<std::pair<const std::pair<unsigned int,unsigned int>,RBX::Typesetter::Glyph> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::pair<unsigned int,unsigned int>,RBX::Typesetter::Glyph> >,std::pair<unsigned int,unsigned int>,RBX::Typesetter::Glyph,boost::hash<std::pair<unsigned int,unsigned int> >,std::equal_to<std::pair<unsigned int,unsigned int> > > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1ec1330 | Name: _ZN5boost9unordered13unordered_mapIN3G3D12Vector2int16ENSt3__115__list_iteratorINS4_4pairIS3_NS6_ImNS_10shared_ptrIN3RBX8TileDataEEEEEEEPvEENS_4hashIS3_EENS4_8equal_toIS3_EENS4_9allocatorINS6_IKS3_SE_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<G3D::Vector2int16,std::__list_iterator<std::pair<G3D::Vector2int16,std::pair<unsigned long,boost::shared_ptr<RBX::TileData>>>,void *>,boost::hash<G3D::Vector2int16>,std::equal_to<G3D::Vector2int16>,std::allocator<std::pair<G3D::Vector2int16 const,std::__list_iterator<std::pair<G3D::Vector2int16,std::pair<unsigned long,boost::shared_ptr<RBX::TileData>>>,void *>>>>::~unordered_map(
        boost::unordered::unordered_map<G3D::Vector2int16,std::__list_iterator<std::pair<G3D::Vector2int16,std::pair<unsigned long,boost::shared_ptr<RBX::TileData> > >,void *>,boost::hash<G3D::Vector2int16>,std::equal_to<G3D::Vector2int16>,std::allocator<std::pair<const G3D::Vector2int16,std::__list_iterator<std::pair<G3D::Vector2int16,std::pair<unsigned long,boost::shared_ptr<RBX::TileData> > >,void *> > > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const G3D::Vector2int16,std::__list_iterator<std::pair<G3D::Vector2int16,std::pair<unsigned long,boost::shared_ptr<RBX::TileData> > >,void *> > >,G3D::Vector2int16,std::__list_iterator<std::pair<G3D::Vector2int16,std::pair<unsigned long,boost::shared_ptr<RBX::TileData> > >,void *>,boost::hash<G3D::Vector2int16>,std::equal_to<G3D::Vector2int16> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1f946d0 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEjNS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_jEEEEED2Ev
void __fastcall boost::unordered::unordered_map<std::string,unsigned int,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,unsigned int>>>::~unordered_map(
        boost::unordered::unordered_map<std::string,unsigned int,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,unsigned int> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,unsigned int>>,std::string,unsigned int,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(&this->table_);
}


// Address: 0x1fe13e0 | Name: _ZN5boost9unordered13unordered_mapIPN3RBX7GfxPartENS2_8Graphics12SceneUpdater12GfxPartEntryENS_4hashIS4_EENSt3__18equal_toIS4_EENS_19fast_pool_allocatorINSA_4pairIPKS3_S7_EENS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::GfxPart *,RBX::Graphics::SceneUpdater::GfxPartEntry,boost::hash<RBX::GfxPart *>,std::equal_to<RBX::GfxPart *>,boost::fast_pool_allocator<std::pair<RBX::GfxPart const*,RBX::Graphics::SceneUpdater::GfxPartEntry>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~unordered_map(
        boost::unordered::unordered_map<RBX::GfxPart *,RBX::Graphics::SceneUpdater::GfxPartEntry,boost::hash<RBX::GfxPart *>,std::equal_to<RBX::GfxPart *>,boost::fast_pool_allocator<std::pair<const RBX::GfxPart *,RBX::Graphics::SceneUpdater::GfxPartEntry>,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<boost::fast_pool_allocator<std::pair<const RBX::GfxPart *,RBX::Graphics::SceneUpdater::GfxPartEntry>,boost::default_user_allocator_new_delete,boost::mutex,32,0>,RBX::GfxPart *,RBX::Graphics::SceneUpdater::GfxPartEntry,boost::hash<RBX::GfxPart *>,std::equal_to<RBX::GfxPart *> > >::bucket_pointer buckets; // r14
  bucket *v2; // rbx
  size_t bucket_count; // rsi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      v2 = &buckets[this->table_.bucket_count_];
      do
        boost::unordered::detail::table<boost::unordered::detail::map<boost::fast_pool_allocator<std::pair<RBX::GfxPart const*,RBX::Graphics::SceneUpdater::GfxPartEntry>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>,RBX::GfxPart*,RBX::Graphics::SceneUpdater::GfxPartEntry,boost::hash<RBX::GfxPart*>,std::equal_to<RBX::GfxPart*>>>::delete_node(
          &this->table_,
          v2);
      while ( v2->next_ );
      buckets = this->table_.buckets_;
    }
    bucket_count = this->table_.bucket_count_;
    if ( bucket_count )
    {
      boost::singleton_pool<boost::fast_pool_allocator_tag,8u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::free(
        buckets,
        bucket_count + 1);
    }
    else
    {
      if ( !byte_29FE162 )
      {
        byte_29FE162 = 1;
        boost::mutex::mutex(&stru_29FE068);
        *(_OWORD *)&stru_29FE090.first = 0;
        stru_29FE090.list.sz = 0;
        *(_OWORD *)&stru_29FE090.requested_size = xmmword_3EA460;
        *(_OWORD *)&stru_29FE090.start_size = 0x20u;
      }
      boost::mutex::lock(&stru_29FE068);
      buckets->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)stru_29FE090.first;
      stru_29FE090.first = buckets;
      boost::mutex::unlock(&stru_29FE068);
    }
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x2058b20 | Name: _ZN5boost9unordered13unordered_mapIN3RBX8Graphics17InstancedCluster23KeyEPNS3_16InstancedEntity2ENS4_6HasherENSt3__18equal_toIS5_EENS9_9allocatorINS9_4pairIKS5_S7_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *,RBX::Graphics::InstancedCluster2::Hasher,std::equal_to<RBX::Graphics::InstancedCluster2::Key>,std::allocator<std::pair<RBX::Graphics::InstancedCluster2::Key const,RBX::Graphics::InstancedEntity2 *>>>::~unordered_map(
        boost::unordered::unordered_map<RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *,RBX::Graphics::InstancedCluster2::Hasher,std::equal_to<RBX::Graphics::InstancedCluster2::Key>,std::allocator<std::pair<const RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *> >,RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *,RBX::Graphics::InstancedCluster2::Hasher,std::equal_to<RBX::Graphics::InstancedCluster2::Key> > >::bucket_pointer buckets; // rdi
  bucket *v3; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      v3 = &buckets[this->table_.bucket_count_];
      do
        boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Graphics::InstancedCluster2::Key const,RBX::Graphics::InstancedEntity2 *>>,RBX::Graphics::InstancedCluster2::Key,RBX::Graphics::InstancedEntity2 *,RBX::Graphics::InstancedCluster2::Hasher,std::equal_to<RBX::Graphics::InstancedCluster2::Key>>>::delete_node(
          &this->table_,
          v3);
      while ( v3->next_ );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x2093b30 | Name: _ZN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_10shared_ptrIN3RBX8Graphics8MaterialEEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_INS2_4pairIKS8_SD_EEEEE5eraseENS0_15iterator_detail10c_iteratorINS0_6detail8ptr_nodeISK_EEEE
boost::unordered::unordered_map<std::string,boost::shared_ptr<RBX::Graphics::Material>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > >::iterator __fastcall boost::unordered::unordered_map<std::string,boost::shared_ptr<RBX::Graphics::Material>,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,boost::shared_ptr<RBX::Graphics::Material>>>>::erase(
        boost::unordered::unordered_map<std::string,boost::shared_ptr<RBX::Graphics::Material>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > > *this,
        boost::unordered::unordered_map<std::string,boost::shared_ptr<RBX::Graphics::Material>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > >::const_iterator_0 position)
{
  boost::unordered::iterator_detail::c_iterator<boost::unordered::detail::ptr_node<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > >::node_pointer node; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r14
  size_t v4; // rbp
  boost::unordered::detail::ptr_node<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > *v5; // rax
  boost::unordered::detail::ptr_node<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > *v6; // r13
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > >,std::string,boost::shared_ptr<RBX::Graphics::Material>,boost::hash<std::string>,std::equal_to<std::string > > >::bucket_pointer buckets; // rcx
  volatile signed __int32 *v8; // r12
  size_t v9; // rax

  node = position.node_;
  next = position.node_->next_;
  v4 = position.node_->hash_ & (this->table_.bucket_count_ - 1);
  v5 = (boost::unordered::detail::ptr_node<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > *)this->table_.buckets_[v4].next_;
  do
  {
    v6 = v5;
    v5 = (boost::unordered::detail::ptr_node<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > *)v5->next_;
  }
  while ( v5 != position.node_ );
  do
  {
    v6->next_ = node->next_;
    v8 = (volatile signed __int32 *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 4);
    if ( v8 )
    {
      if ( !_InterlockedSub(v8 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
        if ( !_InterlockedSub(v8 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
      }
    }
    if ( (node->value_base_.data_.data_.buf[0] & 1) != 0 )
      operator delete(*((void **)&node->value_base_.data_.data_.align_ + 2));
    operator delete(node);
    --this->table_.size_;
    if ( v6->next_ )
    {
      v9 = (__int64)v6->next_[1].next_ & (this->table_.bucket_count_ - 1);
      if ( v9 == v4 )
      {
        v9 = v4;
        goto LABEL_17;
      }
      buckets = this->table_.buckets_;
      buckets[v9].next_ = v6;
      if ( buckets[v4].next_ != v6 )
        goto LABEL_17;
    }
    else
    {
      buckets = this->table_.buckets_;
      v9 = v4;
      if ( buckets[v4].next_ != v6 )
        goto LABEL_17;
    }
    buckets[v4].next_ = 0;
LABEL_17:
    node = (boost::unordered::iterator_detail::c_iterator<boost::unordered::detail::ptr_node<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > >::node_pointer)v6->next_;
    v4 = v9;
  }
  while ( v6->next_ != next );
  return (boost::unordered::unordered_map<std::string,boost::shared_ptr<RBX::Graphics::Material>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,boost::shared_ptr<RBX::Graphics::Material> > > >::iterator)next;
}


// Address: 0x21a3520 | Name: _ZN5boost9unordered13unordered_mapIjPKcNS_4hashIjEENSt3__18equal_toIjEENS6_9allocatorINS6_4pairIKjS3_EEEEEC2ESt16initializer_listISC_EmRKS5_RKS8_RKSD_
void __fastcall boost::unordered::unordered_map<unsigned int,char const*,boost::hash<unsigned int>,std::equal_to<unsigned int>,std::allocator<std::pair<unsigned int const,char const*>>>::unordered_map(
        boost::unordered::unordered_map<unsigned int,const char *,boost::hash<unsigned int>,std::equal_to<unsigned int>,std::allocator<std::pair<const unsigned int,const char *> > > *this,
        std::initializer_list<std::pair<const unsigned int,const char *> > list,
        size_type n,
        const boost::unordered::unordered_map<unsigned int,const char *,boost::hash<unsigned int>,std::equal_to<unsigned int>,std::allocator<std::pair<const unsigned int,const char *> > >::hasher *hf,
        const boost::unordered::unordered_map<unsigned int,const char *,boost::hash<unsigned int>,std::equal_to<unsigned int>,std::allocator<std::pair<const unsigned int,const char *> > >::key_equal *eql)
{
  size_t size; // rdx
  unsigned __int64 v6; // r8
  const boost::unordered::detail::false_type *v8; // rcx
  __int64 v9; // rdi
  const boost::unordered::detail::false_type *v10; // rbx
  __int64 v11; // rax
  const std::pair<const unsigned int,const char *> *v12; // rdx
  size_t *v13; // rdi

  size = list.__size_;
  v6 = ((__int64)(size * 16) >> 4) + 1;
  if ( v6 < n )
    v6 = n;
  this->table_.current_ = 0;
  v8 = &stru_495510;
  v9 = 38;
  do
  {
    v10 = v8;
    v11 = v9 + ~(v9 / 2);
    if ( *(_QWORD *)&v8[8 * (v9 / 2)].gap0 >= v6 )
      v11 = v9 / 2;
    v8 += 8 * (v9 / 2) + 8;
    if ( *(_QWORD *)&v10[8 * (v9 / 2)].gap0 >= v6 )
      v8 = v10;
    v9 = v11;
  }
  while ( v11 );
  v12 = &list.__begin_[size];
  v13 = (size_t *)&v8[-8];
  if ( v8 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v13 = (size_t *)v8;
  this->table_.bucket_count_ = *v13;
  this->table_.size_ = 0;
  this->table_.mlf_ = 1.0;
  *(_OWORD *)&this->table_.max_load_ = 0;
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<unsigned int const,char const*>>,unsigned int,char const*,boost::hash<unsigned int>,std::equal_to<unsigned int>>>::insert_range<std::pair<unsigned int const,char const*> const*>(
    &this->table_,
    list.__begin_,
    v12);
}


// Address: 0x21a3640 | Name: _ZN5boost9unordered13unordered_mapIjPKcNS_4hashIjEENSt3__18equal_toIjEENS6_9allocatorINS6_4pairIKjS3_EEEEED2Ev
void __fastcall boost::unordered::unordered_map<unsigned int,char const*,boost::hash<unsigned int>,std::equal_to<unsigned int>,std::allocator<std::pair<unsigned int const,char const*>>>::~unordered_map(
        boost::unordered::unordered_map<unsigned int,const char *,boost::hash<unsigned int>,std::equal_to<unsigned int>,std::allocator<std::pair<const unsigned int,const char *> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned int,const char *> >,unsigned int,const char *,boost::hash<unsigned int>,std::equal_to<unsigned int> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


