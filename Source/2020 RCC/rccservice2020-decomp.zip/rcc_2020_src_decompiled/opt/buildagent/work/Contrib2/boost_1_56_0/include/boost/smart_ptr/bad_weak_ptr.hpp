// Address: 0xd9f490 | Name: _ZNK5boost12bad_weak_ptr4whatEv
const char *__fastcall boost::bad_weak_ptr::what(const boost::bad_weak_ptr *this)
{
  return "tr1::bad_weak_ptr";
}


// Address: 0xd9f7f0 | Name: _ZN5boost12bad_weak_ptrD0Ev
void __fastcall boost::bad_weak_ptr::~bad_weak_ptr(boost::bad_weak_ptr *this)
{
  std::exception::~exception(this);
  operator delete(this);
}


