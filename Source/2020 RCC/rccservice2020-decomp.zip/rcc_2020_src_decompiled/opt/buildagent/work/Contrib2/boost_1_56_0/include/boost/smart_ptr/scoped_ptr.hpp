// Address: 0xdac030 | Name: _ZN5boost10scoped_ptrI11CWebServiceED2Ev
void __fastcall boost::scoped_ptr<CWebService>::~scoped_ptr(boost::scoped_ptr<CWebService> *this)
{
  CWebService *px; // rbx

  px = this->px;
  if ( this->px )
  {
    CWebService::~CWebService(this->px);
    operator delete(px);
  }
}


// Address: 0xdac7b0 | Name: _ZN5boost10scoped_ptrI19SecurityDataUpdaterED2Ev
void __fastcall boost::scoped_ptr<SecurityDataUpdater>::~scoped_ptr(boost::scoped_ptr<SecurityDataUpdater> *this)
{
  SecurityDataUpdater *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(SecurityDataUpdater *))(*(_QWORD *)px + 16LL))(px);
}


// Address: 0xdac7c0 | Name: _ZN5boost10scoped_ptrI10MD5UpdaterED2Ev
void __fastcall boost::scoped_ptr<MD5Updater>::~scoped_ptr(boost::scoped_ptr<MD5Updater> *this)
{
  MD5Updater *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(MD5Updater *))(*(_QWORD *)px + 16LL))(px);
}


// Address: 0xdac820 | Name: _ZN5boost10scoped_ptrINS_6threadEED2Ev
void __fastcall boost::scoped_ptr<boost::thread>::~scoped_ptr(boost::scoped_ptr<boost::thread> *this)
{
  boost::thread *px; // rbx
  volatile signed __int32 *pi; // r14

  px = this->px;
  if ( this->px )
  {
    boost::thread::detach(this->px);
    pi = (volatile signed __int32 *)px->thread_info.pn.pi_;
    if ( pi && !_InterlockedSub(pi + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
      if ( !_InterlockedSub(pi + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
    }
    operator delete(px);
  }
}


// Address: 0xebfad0 | Name: _ZN3RBX9HeapValueImLi0EED2Ev
void __fastcall RBX::HeapValue<unsigned long,0>::~HeapValue(RBX::HeapValue<unsigned long,0> *this)
{
  RBX::ObscureValue<unsigned long,0> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0xecf5c0 | Name: _ZN5boost10scoped_ptrIN3RBX11AutoMemPoolEED2Ev
void __fastcall boost::scoped_ptr<RBX::AutoMemPool>::~scoped_ptr(boost::scoped_ptr<RBX::AutoMemPool> *this)
{
  RBX::AutoMemPool *px; // r15
  boost::pool<RBX::TrackedAllocator> *v2; // r14
  char *ptr; // r12
  boost::details::PODptr<unsigned long>::size_type sz; // rbx
  char *v5; // rdi

  px = this->px;
  if ( this->px )
  {
    v2 = px->pool.px;
    if ( px->pool.px )
    {
      ptr = v2->list.ptr;
      if ( ptr )
      {
        sz = v2->list.sz;
        do
        {
          v5 = ptr;
          ptr = *(char **)&ptr[sz - 16];
          sz = *(_QWORD *)&v5[sz - 8];
          RBX::Memory::deallocate(v5);
        }
        while ( ptr );
      }
      operator delete(v2);
    }
    operator delete(px);
  }
}


// Address: 0xf42570 | Name: _ZN3RBX7Network15PhysicsSenderS215hasFramesToSendEPNS_12PartInstanceE
bool __fastcall RBX::Network::PhysicsSenderS2::hasFramesToSend(
        RBX::Network::PhysicsSenderS2 *this,
        RBX::PartInstance *part)
{
  _QWORD *v2; // rax
  char *v3; // rcx
  char v4; // dl

  v2 = (_QWORD *)*((_QWORD *)part->primitive.px + 16);
  if ( !v2 )
    return 0;
  if ( !v2[8] )
    return 0;
  v3 = (char *)v2[6];
  if ( !v3 )
    return 0;
  do
  {
    v4 = *v3;
    if ( *v3 )
      break;
    v3 += 96;
    if ( v3 == (char *)v2[5] )
    {
      v3 = (char *)v2[4];
      if ( v3 == (char *)v2[7] )
        return v4 != 0;
    }
    else if ( v3 == (char *)v2[7] )
    {
      return v4 != 0;
    }
  }
  while ( v3 );
  return v4 != 0;
}


// Address: 0xf69f70 | Name: _ZN3RBX7Network10Replicator23testAddToEventWhitelistEPKNS_10Reflection15EventDescriptorE
void __fastcall RBX::Network::Replicator::testAddToEventWhitelist(
        RBX::Network::Replicator *this,
        const RBX::Reflection::EventDescriptor *desc)
{
  RBX::Network::StrictNetworkFilter::testAddToEventWhitelist(*((RBX::Network::StrictNetworkFilter **)this + 967), desc);
}


// Address: 0xfe60f0 | Name: _ZN5boost10scoped_ptrIN3RBX7Network13NetworkFilterEED2Ev
void __fastcall boost::scoped_ptr<RBX::Network::NetworkFilter>::~scoped_ptr(
        boost::scoped_ptr<RBX::Network::NetworkFilter> *this)
{
  RBX::Network::NetworkFilter *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Network::NetworkFilter::~NetworkFilter(this->px);
    operator delete(px);
  }
}


// Address: 0x106eef0 | Name: _ZN3RBX8Humanoid19setPlatformStandingEb
void __fastcall RBX::Humanoid::setPlatformStanding(RBX::Humanoid *this, bool value)
{
  _DWORD *v2; // rax

  v2 = (_DWORD *)*((_QWORD *)this + 89);
  if ( (value ^ (*(_BYTE *)v2 != (unsigned __int8)v2)) == 1 )
  {
    *v2 = (_DWORD)v2 + value;
    RBX::Instance::raisePropertyChanged((RBX::Instance *)this, &stru_2A05CA0);
  }
}


// Address: 0x1090c90 | Name: _ZNK3RBX8Humanoid16getLostAllHealthEv
bool __fastcall RBX::Humanoid::getLostAllHealth(const RBX::Humanoid *this)
{
  return COERCE_FLOAT(*((_QWORD *)this + 79) - **((_DWORD **)this + 79)) <= 0.0 && *((_BYTE *)this + 941) != 0;
}


// Address: 0x10a2d10 | Name: _ZNK3RBX8Humanoid9getHealthEv
float __fastcall RBX::Humanoid::getHealth(const RBX::Humanoid *this)
{
  float result; // xmm0_4

  LODWORD(result) = *((_QWORD *)this + 79) - **((_DWORD **)this + 79);
  return result;
}


// Address: 0x10a2e70 | Name: _ZNK3RBX8Humanoid12getMaxHealthEv
float __fastcall RBX::Humanoid::getMaxHealth(const RBX::Humanoid *this)
{
  float result; // xmm0_4

  LODWORD(result) = **((_DWORD **)this + 80) - *((_QWORD *)this + 80);
  return result;
}


// Address: 0x10a2e80 | Name: _ZNK3RBX8Humanoid12getWalkSpeedEv
float __fastcall RBX::Humanoid::getWalkSpeed(const RBX::Humanoid *this)
{
  float result; // xmm0_4

  LODWORD(result) = **((_DWORD **)this + 76) - *((_QWORD *)this + 76);
  return result;
}


// Address: 0x10a2ff0 | Name: _ZNK3RBX8Humanoid12getJumpPowerEv
float __fastcall RBX::Humanoid::getJumpPower(const RBX::Humanoid *this)
{
  float result; // xmm0_4

  LODWORD(result) = *((_QWORD *)this + 82) + **((_DWORD **)this + 82);
  return result;
}


// Address: 0x10a3010 | Name: _ZNK3RBX8Humanoid13getJumpHeightEv
float __fastcall RBX::Humanoid::getJumpHeight(const RBX::Humanoid *this)
{
  float result; // xmm0_4

  LODWORD(result) = **((_DWORD **)this + 84) - *((_QWORD *)this + 84);
  return result;
}


// Address: 0x10a3020 | Name: _ZNK3RBX8Humanoid16getMaxSlopeAngleEv
float __fastcall RBX::Humanoid::getMaxSlopeAngle(const RBX::Humanoid *this)
{
  float result; // xmm0_4

  LODWORD(result) = *((_QWORD *)this + 85) - **((_DWORD **)this + 85);
  return result;
}


// Address: 0x10a3030 | Name: _ZNK3RBX8Humanoid12getHipHeightEv
float __fastcall RBX::Humanoid::getHipHeight(const RBX::Humanoid *this)
{
  float result; // xmm0_4

  LODWORD(result) = *((_QWORD *)this + 86) + **((_DWORD **)this + 86);
  return result;
}


// Address: 0x10a3040 | Name: _ZNK3RBX8Humanoid26getAutomaticScalingEnabledEv
bool __fastcall RBX::Humanoid::getAutomaticScalingEnabled(const RBX::Humanoid *this)
{
  return **((_BYTE **)this + 90) != (unsigned __int8)*((_QWORD *)this + 90);
}


// Address: 0x10a33b0 | Name: _ZNK3RBX8Humanoid19getPlatformStandingEv
bool __fastcall RBX::Humanoid::getPlatformStanding(const RBX::Humanoid *this)
{
  return **((_BYTE **)this + 89) != (unsigned __int8)*((_QWORD *)this + 89);
}


// Address: 0x10acee0 | Name: _ZN3RBX9HeapValueIbLi0EED2Ev
void __fastcall RBX::HeapValue<bool,0>::~HeapValue(RBX::HeapValue<bool,0> *this)
{
  RBX::ObscureValue<bool,0> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acef0 | Name: _ZN3RBX9HeapValueIfLi1313402314EED2Ev
void __fastcall RBX::HeapValue<float,1313402314>::~HeapValue(RBX::HeapValue<float,1313402314> *this)
{
  RBX::ObscureValue<float,1313402314> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acf00 | Name: _ZN3RBX9HeapValueIfLi20522067EED2Ev
void __fastcall RBX::HeapValue<float,20522067>::~HeapValue(RBX::HeapValue<float,20522067> *this)
{
  RBX::ObscureValue<float,20522067> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acf10 | Name: _ZN3RBX9HeapValueIfLi82087792EED2Ev
void __fastcall RBX::HeapValue<float,82087792>::~HeapValue(RBX::HeapValue<float,82087792> *this)
{
  RBX::ObscureValue<float,82087792> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acf20 | Name: _ZN3RBX9HeapValueIfLi1313402310EED2Ev
void __fastcall RBX::HeapValue<float,1313402310>::~HeapValue(RBX::HeapValue<float,1313402310> *this)
{
  RBX::ObscureValue<float,1313402310> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acf30 | Name: _ZN3RBX9HeapValueIfLi82087788EED2Ev
void __fastcall RBX::HeapValue<float,82087788>::~HeapValue(RBX::HeapValue<float,82087788> *this)
{
  RBX::ObscureValue<float,82087788> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acf40 | Name: _ZN3RBX9HeapValueIfLi328350691EED2Ev
void __fastcall RBX::HeapValue<float,328350691>::~HeapValue(RBX::HeapValue<float,328350691> *this)
{
  RBX::ObscureValue<float,328350691> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acf50 | Name: _ZN3RBX9HeapValueIfLi1313402306EED2Ev
void __fastcall RBX::HeapValue<float,1313402306>::~HeapValue(RBX::HeapValue<float,1313402306> *this)
{
  RBX::ObscureValue<float,1313402306> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acf60 | Name: _ZN3RBX9HeapValueIfLi20522059EED2Ev
void __fastcall RBX::HeapValue<float,20522059>::~HeapValue(RBX::HeapValue<float,20522059> *this)
{
  RBX::ObscureValue<float,20522059> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10acf70 | Name: _ZN3RBX9HeapValueIfLi82087784EED2Ev
void __fastcall RBX::HeapValue<float,82087784>::~HeapValue(RBX::HeapValue<float,82087784> *this)
{
  RBX::ObscureValue<float,82087784> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10e47e0 | Name: _ZN3RBX9HeapValueINS_5HUMAN9StateTypeELi0EED2Ev
void __fastcall RBX::HeapValue<RBX::HUMAN::StateType,0>::~HeapValue(RBX::HeapValue<RBX::HUMAN::StateType,0> *this)
{
  RBX::ObscureValue<RBX::HUMAN::StateType,0> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x10e47f0 | Name: _ZN3RBX9HeapValueIiLi0EED2Ev
void __fastcall RBX::HeapValue<int,0>::~HeapValue(RBX::HeapValue<int,0> *this)
{
  RBX::ObscureValue<int,0> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x1121e70 | Name: _ZN5boost10scoped_ptrIN3RBX9Scripting18ISpecialBreakpointEED2Ev
void __fastcall boost::scoped_ptr<RBX::Scripting::ISpecialBreakpoint>::~scoped_ptr(
        boost::scoped_ptr<RBX::Scripting::ISpecialBreakpoint> *this)
{
  RBX::Scripting::ISpecialBreakpoint *px; // rdi

  px = this->px;
  if ( px )
    (*((void (__fastcall **)(RBX::Scripting::ISpecialBreakpoint *))px->_vptr$ISpecialBreakpoint + 1))(px);
}


// Address: 0x11cecd0 | Name: _ZN5boost10scoped_ptrIN3RBX3Lua13ContinuationsEED2Ev
void __fastcall boost::scoped_ptr<RBX::Lua::Continuations>::~scoped_ptr(
        boost::scoped_ptr<RBX::Lua::Continuations> *this)
{
  RBX::Lua::Continuations *px; // rbx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v3)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v4; // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax

  px = this->px;
  if ( this->px )
  {
    vtable = px->error.vtable;
    if ( vtable )
    {
      if ( ((unsigned __int8)vtable & 1) == 0 )
      {
        v3 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v3 )
          v3(&px->error.functor, &px->error.functor, 2);
      }
      px->error.vtable = 0;
    }
    v4 = px->success.vtable;
    if ( px->success.vtable && ((unsigned __int8)v4 & 1) == 0 )
    {
      v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v4 & 0xFFFFFFFFFFFFFFFELL);
      if ( v5 )
        v5(&px->success.functor, &px->success.functor, 2);
    }
    operator delete(px);
  }
}


// Address: 0x1225e80 | Name: _ZN3RBX24CacheableContentProvider12setCacheSizeEi
void __fastcall RBX::CacheableContentProvider::setCacheSize(RBX::CacheableContentProvider *this, int size)
{
  RBX::ConcurrentControlledLRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>>::resize(
    this->lruCache.px,
    size);
}


// Address: 0x1225e90 | Name: _ZN3RBX24CacheableContentProvider12clearContentEv
bool __fastcall RBX::CacheableContentProvider::clearContent(RBX::CacheableContentProvider *this)
{
  return RBX::ConcurrentControlledLRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>>::evictAll(this->lruCache.px);
}


// Address: 0x1225ea0 | Name: _ZN3RBX24CacheableContentProvider13memSizePinnedEv
unsigned __int64 __fastcall RBX::CacheableContentProvider::memSizePinned(RBX::CacheableContentProvider *this)
{
  return this->lruCache.px->cache.pinnedCache.px->totalMemory;
}


// Address: 0x1225eb0 | Name: _ZN3RBX24CacheableContentProvider16memSizeEvictableEv
unsigned __int64 __fastcall RBX::CacheableContentProvider::memSizeEvictable(RBX::CacheableContentProvider *this)
{
  return this->lruCache.px->cache.evictableCache.px->totalMemory;
}


// Address: 0x1227b50 | Name: _ZN3RBX24CacheableContentProvider13updateContentERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEN5boost10shared_ptrINS0_10CachedItemEEE
void __fastcall RBX::CacheableContentProvider::updateContent(
        RBX::CacheableContentProvider *this,
        const std::string *id,
        boost::shared_ptr<RBX::CacheableContentProvider::CachedItem> cachedItem)
{
  RBX::ConcurrentControlledLRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>>::insert(
    this->lruCache.px,
    id,
    (const boost::shared_ptr<RBX::CacheableContentProvider::CachedItem> *)cachedItem.px,
    0);
}


// Address: 0x12281c0 | Name: _ZN5boost10scoped_ptrIN3RBX28ConcurrentControlledLRUCacheINSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10shared_ptrINS1_24CacheableContentProvider10CachedItemEEEEEED2Ev
void __fastcall boost::scoped_ptr<RBX::ConcurrentControlledLRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>>>::~scoped_ptr(
        boost::scoped_ptr<RBX::ConcurrentControlledLRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem> > > *this)
{
  RBX::ConcurrentControlledLRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem> > *px; // r14
  RBX::LRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>,boost::hash<std::string> > *v2; // rdi
  RBX::LRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>,boost::hash<std::string> > *v3; // rdi

  px = this->px;
  if ( this->px )
  {
    while ( pthread_mutex_destroy(&px->mx.m) == 4 )
      ;
    v2 = px->cache.pinnedCache.px;
    if ( v2 )
      (*((void (__fastcall **)(RBX::LRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>,boost::hash<std::string> > *))v2->_vptr$LRUCache
       + 1))(v2);
    v3 = px->cache.evictableCache.px;
    if ( v3 )
      (*((void (__fastcall **)(RBX::LRUCache<std::string,boost::shared_ptr<RBX::CacheableContentProvider::CachedItem>,boost::hash<std::string> > *))v3->_vptr$LRUCache
       + 1))(v3);
    operator delete(px);
  }
}


// Address: 0x122de10 | Name: _ZN5boost10scoped_ptrIN3RBX18LegacyContentTableEED2Ev
void __fastcall boost::scoped_ptr<RBX::LegacyContentTable>::~scoped_ptr(
        boost::scoped_ptr<RBX::LegacyContentTable> *this)
{
  RBX::LegacyContentTable *px; // rbx

  px = this->px;
  if ( this->px )
  {
    if ( (*((_BYTE *)px + 48) & 1) != 0 )
      operator delete(*((void **)px + 8));
    boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::string>>,std::string,std::string,boost::hash<std::string>,std::equal_to<std::string>>>::~table((boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::string > >,std::string,std::string,boost::hash<std::string>,std::equal_to<std::string > > > *)px);
    operator delete(px);
  }
}


// Address: 0x1575d30 | Name: _ZN3RBX9DataModel24getPlaceIDOrZeroInStudioEv
int64_t __fastcall RBX::DataModel::getPlaceIDOrZeroInStudio(RBX::DataModel *this)
{
  return ((unsigned __int64)(*(_DWORD *)(*((_QWORD *)this + 230) + 4LL) - (unsigned int)*((_QWORD *)this + 230)) << 32)
       | (**((_DWORD **)this + 230) - (unsigned int)*((_QWORD *)this + 230));
}


// Address: 0x1581060 | Name: _ZNK3RBX9DataModel10getPlaceIDEv
int64_t __fastcall RBX::DataModel::getPlaceID(const RBX::DataModel *this)
{
  return ((unsigned __int64)(*(_DWORD *)(*((_QWORD *)this + 230) + 4LL) - (unsigned int)*((_QWORD *)this + 230)) << 32)
       | (**((_DWORD **)this + 230) - (unsigned int)*((_QWORD *)this + 230));
}


// Address: 0x15811d0 | Name: _ZNK3RBX9DataModel12getCreatorIDEv
int64_t __fastcall RBX::DataModel::getCreatorID(const RBX::DataModel *this)
{
  return ((unsigned __int64)(*(_DWORD *)(*((_QWORD *)this + 234) + 4LL) - (unsigned int)*((_QWORD *)this + 234)) << 32)
       | (**((_DWORD **)this + 234) - (unsigned int)*((_QWORD *)this + 234));
}


// Address: 0x1593ca0 | Name: _ZN5boost10scoped_ptrIN3RBX9DataModel21scoped_write_transferEED2Ev
void __fastcall boost::scoped_ptr<RBX::DataModel::scoped_write_transfer>::~scoped_ptr(
        boost::scoped_ptr<RBX::DataModel::scoped_write_transfer> *this)
{
  RBX::DataModel::scoped_write_transfer *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::DataModel::scoped_write_transfer::~scoped_write_transfer(this->px);
    operator delete(px);
  }
}


// Address: 0x1790c70 | Name: _ZN5boost10scoped_ptrIN3RBX10UIQuadTreeEED2Ev
void __fastcall boost::scoped_ptr<RBX::UIQuadTree>::~scoped_ptr(boost::scoped_ptr<RBX::UIQuadTree> *this)
{
  RBX::UIQuadTree *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::UIQuadTree::~UIQuadTree(this->px);
    operator delete(px);
  }
}


// Address: 0x18e3c90 | Name: _ZN5boost10scoped_ptrIN3RBX6Voxel213MaterialTableEED2Ev
void __fastcall boost::scoped_ptr<RBX::Voxel2::MaterialTable>::~scoped_ptr(
        boost::scoped_ptr<RBX::Voxel2::MaterialTable> *this)
{
  RBX::Voxel2::MaterialTable *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Voxel2::MaterialTable::~MaterialTable(this->px);
    operator delete(px);
  }
}


// Address: 0x1912420 | Name: _ZN3RBX12PartInstance10isGroundedEv
bool __fastcall RBX::PartInstance::isGrounded(RBX::PartInstance *this)
{
  RBX::Primitive *px; // rdi

  px = this->primitive.px;
  return px && RBX::Primitive::computeIsGrounded(px);
}


// Address: 0x1913f30 | Name: _ZNK3RBX12PartInstance14getPartSizeXmlEv
const RBX::Vector3 *__fastcall RBX::PartInstance::getPartSizeXml(const RBX::PartInstance *this)
{
  return (const RBX::Vector3 *)(*((_QWORD *)this->primitive.px + 18) + 8LL);
}


// Address: 0x1913f50 | Name: _ZNK3RBX12PartInstance13getPartSizeUiEv
RBX::Vector3 __fastcall RBX::PartInstance::getPartSizeUi(const RBX::PartInstance *this)
{
  __int64 v1; // rax
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  v1 = *((_QWORD *)this->primitive.px + 18);
  *(_QWORD *)&result.x = *(_QWORD *)(v1 + 8);
  result.z = *(float *)(v1 + 16);
  return result;
}


// Address: 0x1913f70 | Name: _ZNK3RBX12PartInstance13getElasticityEv
float __fastcall RBX::PartInstance::getElasticity(const RBX::PartInstance *this)
{
  return *((float *)this->primitive.px + 145);
}


// Address: 0x1913f80 | Name: _ZNK3RBX12PartInstance11getFrictionEv
float __fastcall RBX::PartInstance::getFriction(const RBX::PartInstance *this)
{
  return *((float *)this->primitive.px + 144);
}


// Address: 0x1913f90 | Name: _ZNK3RBX12PartInstance21getPhysicalPropertiesEv
const RBX::PhysicalProperties *__fastcall RBX::PartInstance::getPhysicalProperties(const RBX::PartInstance *this)
{
  return (const RBX::PhysicalProperties *)*((_QWORD *)this->primitive.px + 73);
}


// Address: 0x1913fa0 | Name: _ZNK3RBX12PartInstance15getRootPriorityEv
int __fastcall RBX::PartInstance::getRootPriority(const RBX::PartInstance *this)
{
  return *((char *)this->primitive.px + 600);
}


// Address: 0x19141d0 | Name: _ZNK3RBX12PartInstance17getRenderMaterialEv
RBX::PartMaterial __fastcall RBX::PartInstance::getRenderMaterial(const RBX::PartInstance *this)
{
  return *((unsigned __int16 *)this->primitive.px + 296);
}


// Address: 0x19141e0 | Name: _ZNK3RBX12PartInstance23getNetworkOwnershipRuleEv
RBX::NetworkOwnership __fastcall RBX::PartInstance::getNetworkOwnershipRule(const RBX::PartInstance *this)
{
  return *((unsigned __int8 *)this->primitive.px + 601);
}


// Address: 0x1914260 | Name: _ZNK3RBX12PartInstance11getAnchoredEv
bool __fastcall RBX::PartInstance::getAnchored(const RBX::PartInstance *this)
{
  return *((_BYTE *)this->primitive.px + 595);
}


// Address: 0x1914270 | Name: _ZNK3RBX12PartInstance13getCanCollideEv
bool __fastcall RBX::PartInstance::getCanCollide(const RBX::PartInstance *this)
{
  return *((_BYTE *)this->primitive.px + 596) == 0;
}


// Address: 0x19142e0 | Name: _ZNK3RBX12PartInstance15getNetworkOwnerEv
RBX::SystemAddress __fastcall RBX::PartInstance::getNetworkOwner(const RBX::PartInstance *this)
{
  return (RBX::SystemAddress)*((_QWORD *)this->primitive.px + 65);
}


// Address: 0x1914530 | Name: _ZNK3RBX12PartInstance20getNetworkIsSleepingEv
bool __fastcall RBX::PartInstance::getNetworkIsSleeping(const RBX::PartInstance *this)
{
  return *((_BYTE *)this->primitive.px + 597);
}


// Address: 0x1914570 | Name: _ZNK3RBX12PartInstance11getDraggingEv
bool __fastcall RBX::PartInstance::getDragging(const RBX::PartInstance *this)
{
  return *((_BYTE *)this->primitive.px + 594);
}


// Address: 0x19145c0 | Name: _ZNK3RBX12PartInstance18getReceiveIntervalEv
float __fastcall RBX::PartInstance::getReceiveInterval(const RBX::PartInstance *this)
{
  RBX::Primitive *px; // rdi

  px = this->primitive.px;
  if ( px )
    return RBX::Primitive::getAverageFramesInterval(px);
  else
    return 0.0;
}


// Address: 0x1915840 | Name: _ZN3RBX12PartInstance13onGuidChangedEv
void __fastcall RBX::PartInstance::onGuidChanged(RBX::PartInstance *this)
{
  RBX::Primitive::setGuid(this->primitive.px, &this->guid);
}


// Address: 0x1916de0 | Name: _ZN3RBX12PartInstance8getClumpEv
RBX::Clump *__fastcall RBX::PartInstance::getClump(RBX::PartInstance *this)
{
  RBX::Primitive *px; // rdi

  px = this->primitive.px;
  if ( px )
    return RBX::Clump::getPrimitiveClump(px);
  else
    return 0;
}


// Address: 0x1916e00 | Name: _ZNK3RBX12PartInstance13getConstClumpEv
const RBX::Clump *__fastcall RBX::PartInstance::getConstClump(const RBX::PartInstance *this)
{
  RBX::Primitive *px; // rdi

  px = this->primitive.px;
  if ( px )
    return RBX::Clump::getConstPrimitiveClump(px);
  else
    return 0;
}


// Address: 0x19173b0 | Name: _ZNK3RBX12PartInstance14getSurfaceTypeENS_8NormalIdE
RBX::SurfaceType __fastcall RBX::PartInstance::getSurfaceType(const RBX::PartInstance *this, RBX::NormalId surfId)
{
  return *((unsigned __int8 *)this->primitive.px + (unsigned int)surfId + 604);
}


// Address: 0x191b0f0 | Name: _ZNK3RBX12PartInstance7getMassEv
float __fastcall RBX::PartInstance::getMass(const RBX::PartInstance *this)
{
  RBX::Primitive *px; // rax
  float result; // xmm0_4

  px = this->primitive.px;
  if ( !*((_BYTE *)px + 236) )
    return *((float *)px + 78);
  result = 0.0;
  if ( *((RBX::Primitive **)px + 25) == (RBX::Primitive *)((char *)px + 152) )
    return *((float *)px + 78);
  return result;
}


// Address: 0x191e170 | Name: _ZNK3RBX12PartInstance14isStandardPartEv
bool __fastcall RBX::PartInstance::isStandardPart(const RBX::PartInstance *this)
{
  RBX::Primitive *px; // rax

  px = this->primitive.px;
  if ( *((_BYTE *)px + 608) != 4 )
    return 0;
  if ( *((_BYTE *)px + 609) )
    return 0;
  if ( *((_BYTE *)px + 606) )
    return 0;
  if ( *((_BYTE *)px + 607) )
    return 0;
  return *((_BYTE *)px + 604) == 0;
}


// Address: 0x191eda0 | Name: _ZNK3RBX12PartInstance19getCollisionGroupIdEv
int8_t __fastcall RBX::PartInstance::getCollisionGroupId(const RBX::PartInstance *this)
{
  return *((_BYTE *)this->primitive.px + 599);
}


// Address: 0x1922a50 | Name: _ZN5boost10scoped_ptrIN3RBX9PrimitiveEED2Ev
void __fastcall boost::scoped_ptr<RBX::Primitive>::~scoped_ptr(boost::scoped_ptr<RBX::Primitive> *this)
{
  RBX::Primitive *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Primitive *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x19633a0 | Name: _ZN5boost10scoped_ptrIN3RBX6Player9SpawnDataEED2Ev
void __fastcall boost::scoped_ptr<RBX::Player::SpawnData>::~scoped_ptr(boost::scoped_ptr<RBX::Player::SpawnData> *this)
{
  RBX::Player::SpawnData *px; // rdi

  px = this->px;
  if ( px )
    operator delete(px);
}


// Address: 0x19f2c00 | Name: _ZN5boost10scoped_ptrIN3RBX13AbuseReporterEED2Ev
void __fastcall boost::scoped_ptr<RBX::AbuseReporter>::~scoped_ptr(boost::scoped_ptr<RBX::AbuseReporter> *this)
{
  RBX::AbuseReporter *px; // r15
  RBX::worker_thread *v2; // rbx
  volatile signed __int32 *pi; // r14

  px = this->px;
  if ( this->px )
  {
    v2 = px->requestProcessor.px;
    if ( v2 )
    {
      RBX::worker_thread::~worker_thread(px->requestProcessor.px);
      operator delete(v2);
    }
    pi = (volatile signed __int32 *)px->_data.pn.pi_;
    if ( pi && !_InterlockedSub(pi + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
      if ( !_InterlockedSub(pi + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
    }
    operator delete(px);
  }
}


// Address: 0x1ab3720 | Name: _ZN3RBX18SkateboardPlatform13getEngineBodyEv
RBX::Body *__fastcall RBX::SkateboardPlatform::getEngineBody(RBX::SkateboardPlatform *this)
{
  return (RBX::Body *)*((_QWORD *)this->primitive.px + 25);
}


// Address: 0x1ab3730 | Name: _ZThn360_N3RBX18SkateboardPlatform13getEngineBodyEv
void __fastcall `non-virtual thunk to'RBX::SkateboardPlatform::getEngineBody(RBX::SkateboardPlatform *this)
{
  ;
}


// Address: 0x1b6a8d0 | Name: _ZN3RBX9HeapValueIlLi0EED2Ev
void __fastcall RBX::HeapValue<long,0>::~HeapValue(RBX::HeapValue<long,0>_0 *this)
{
  RBX::ObscureValue<long,0> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x1c23ef0 | Name: _ZN3RBX11VehicleSeat13getEngineBodyEv
RBX::Body *__fastcall RBX::VehicleSeat::getEngineBody(RBX::VehicleSeat *this)
{
  return (RBX::Body *)*((_QWORD *)this->primitive.px + 25);
}


// Address: 0x1c23f00 | Name: _ZThn384_N3RBX11VehicleSeat13getEngineBodyEv
void __fastcall `non-virtual thunk to'RBX::VehicleSeat::getEngineBody(RBX::VehicleSeat *this)
{
  ;
}


// Address: 0x1c4e060 | Name: _ZN3RBX9HeapValueIfLi0EED2Ev
void __fastcall RBX::HeapValue<float,0>::~HeapValue(RBX::HeapValue<float,0> *this)
{
  RBX::ObscureValue<float,0> *px; // rdi

  px = this->storage.px;
  if ( px )
    operator delete(px);
}


// Address: 0x1c4e190 | Name: _ZN5boost10scoped_ptrIN3RBX30WorkspaceInterpolatorInterfaceEED2Ev
void __fastcall boost::scoped_ptr<RBX::WorkspaceInterpolatorInterface>::~scoped_ptr(
        boost::scoped_ptr<RBX::WorkspaceInterpolatorInterface> *this)
{
  RBX::WorkspaceInterpolatorInterface *px; // rdi

  px = this->px;
  if ( px )
    (*((void (__fastcall **)(RBX::WorkspaceInterpolatorInterface *))px->_vptr$WorkspaceInterpolatorInterface + 1))(px);
}


// Address: 0x1d3e2a0 | Name: _ZNK3RBX8Instance12onDemandReadEv
const RBX::OnDemandInstance *__fastcall RBX::Instance::onDemandRead(const RBX::Instance *this)
{
  return this->onDemandPtr.px;
}


// Address: 0x1d44750 | Name: _ZNK3RBX8Instance20getCanDirtyDataModelEv
bool __fastcall RBX::Instance::getCanDirtyDataModel(const RBX::Instance *this)
{
  RBX::OnDemandInstance *px; // rax

  px = this->onDemandPtr.px;
  return !px || *((_BYTE *)px + 64) != 0;
}


// Address: 0x1e386a0 | Name: _ZN5boost10scoped_ptrIN3RBX22TerrainPartitionSmoothEED2Ev
void __fastcall boost::scoped_ptr<RBX::TerrainPartitionSmooth>::~scoped_ptr(
        boost::scoped_ptr<RBX::TerrainPartitionSmooth> *this)
{
  RBX::TerrainPartitionSmooth *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::TerrainPartitionSmooth::~TerrainPartitionSmooth(this->px);
    operator delete(px);
  }
}


// Address: 0x1f7ff50 | Name: _ZN3RBX8Graphics10RenderView17setScreenDPIScaleEf
void __fastcall RBX::Graphics::RenderView::setScreenDPIScale(RBX::Graphics::RenderView *this, double a2, float scale)
{
  RBX::Graphics::VisualEngine::setScreenDPIScale(this->visualEngine.px, scale);
}


// Address: 0x1f7ff60 | Name: _ZN3RBX8Graphics10RenderView19getFrameRateManagerEv
RBX::FrameRateManager *__fastcall RBX::Graphics::RenderView::getFrameRateManager(RBX::Graphics::RenderView *this)
{
  return (RBX::FrameRateManager *)*((_QWORD *)this->visualEngine.px + 208);
}


// Address: 0x1f87e50 | Name: _ZN3RBX8Graphics10RenderView14getRenderStatsEv
RBX::RenderStats *__fastcall RBX::Graphics::RenderView::getRenderStats(RBX::Graphics::RenderView *this)
{
  return (RBX::RenderStats *)*((_QWORD *)this->visualEngine.px + 218);
}


// Address: 0x1f89d90 | Name: _ZN3RBX8Graphics10RenderView16queueAssetReloadERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall RBX::Graphics::RenderView::queueAssetReload(
        RBX::Graphics::RenderView *this,
        const std::string *filePath)
{
  RBX::Graphics::VisualEngine::queueAssetReload(this->visualEngine.px, filePath);
}


// Address: 0x1f89da0 | Name: _ZN3RBX8Graphics10RenderView20immediateAssetReloadERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
void __fastcall RBX::Graphics::RenderView::immediateAssetReload(
        RBX::Graphics::RenderView *this,
        const std::string *filePath)
{
  RBX::Graphics::VisualEngine::immediateAssetReload(this->visualEngine.px, filePath);
}


// Address: 0x1f89db0 | Name: _ZN3RBX8Graphics10RenderView11setViewportEii
void __fastcall RBX::Graphics::RenderView::setViewport(RBX::Graphics::RenderView *this, int width, int height)
{
  RBX::Graphics::VisualEngine::setViewport(this->visualEngine.px, width, height);
}


// Address: 0x1f89e70 | Name: _ZN3RBX8Graphics10RenderView11exportSceneERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_16ExporterSaveTypeENS_14ExporterFormatE
bool __fastcall RBX::Graphics::RenderView::exportScene(
        RBX::Graphics::RenderView *this,
        const std::string *filePath,
        RBX::ExporterSaveType saveType,
        RBX::ExporterFormat format)
{
  return RBX::Graphics::ObjectExporter::exportToFile(
           filePath,
           saveType,
           format,
           (RBX::DataModel *)this->dataModel.px,
           this->visualEngine.px);
}


// Address: 0x1f89e90 | Name: _ZN3RBX8Graphics10RenderView11suspendViewEv
void __fastcall RBX::Graphics::RenderView::suspendView(RBX::Graphics::RenderView *this)
{
  (*(void (__fastcall **)(RBX::Graphics::Device *))(*(_QWORD *)this->device.px + 144LL))(this->device.px);
}


// Address: 0x1f89ea0 | Name: _ZN3RBX8Graphics10RenderView10resumeViewEv
void __fastcall RBX::Graphics::RenderView::resumeView(RBX::Graphics::RenderView *this)
{
  (*(void (__fastcall **)(RBX::Graphics::Device *))(*(_QWORD *)this->device.px + 152LL))(this->device.px);
}


// Address: 0x1f89eb0 | Name: _ZN3RBX8Graphics10RenderView18updateWindowHandleEPv
void __fastcall RBX::Graphics::RenderView::updateWindowHandle(RBX::Graphics::RenderView *this, void *hwnd)
{
  (*(void (__fastcall **)(RBX::Graphics::Device *, void *))(*(_QWORD *)this->device.px + 160LL))(this->device.px, hwnd);
}


// Address: 0x1f89ec0 | Name: _ZN3RBX8Graphics10RenderView40updatePreloadTexturesWithContentProviderEPNS_15ContentProviderE
void __fastcall RBX::Graphics::RenderView::updatePreloadTexturesWithContentProvider(
        RBX::Graphics::RenderView *this,
        RBX::ContentProvider *contentProvider)
{
  RBX::Graphics::TextureManager::updatePreloadTexturesWithContentProvider(
    *((RBX::Graphics::TextureManager **)this->visualEngine.px + 204),
    contentProvider);
}


// Address: 0x1f89ed0 | Name: _ZN3RBX8Graphics10RenderView29processPendingTextureRequestsEv
void __fastcall RBX::Graphics::RenderView::processPendingTextureRequests(RBX::Graphics::RenderView *this)
{
  RBX::Graphics::TextureManager::processPendingRequests(*((RBX::Graphics::TextureManager **)this->visualEngine.px + 204));
}


// Address: 0x1f8a5a0 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics14VertexStreamerEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::VertexStreamer>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::VertexStreamer> *this)
{
  RBX::Graphics::VertexStreamer *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::VertexStreamer::~VertexStreamer(this->px);
    operator delete(px);
  }
}


// Address: 0x1f8a600 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics13ProfilerAdornEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::ProfilerAdorn>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::ProfilerAdorn> *this)
{
  RBX::Graphics::ProfilerAdorn *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::ProfilerAdorn *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x1f8a610 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics16ProfilerRendererEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::ProfilerRenderer>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::ProfilerRenderer> *this)
{
  RBX::Graphics::ProfilerRenderer *px; // rdi

  px = this->px;
  if ( px )
    (*((void (__fastcall **)(RBX::Graphics::ProfilerRenderer *))px->_vptr$Renderer + 1))(px);
}


// Address: 0x1f8a730 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics12VisualEngineEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::VisualEngine>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::VisualEngine> *this)
{
  RBX::Graphics::VisualEngine *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::VisualEngine *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x1f8a740 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics6DeviceEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::Device>::~scoped_ptr(boost::scoped_ptr<RBX::Graphics::Device> *this)
{
  RBX::Graphics::Device *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::Device *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x1f93a70 | Name: _ZNK3RBX8Graphics12VisualEngine29bindLightingResourcesFallbackEPNS0_13DeviceContextE
void __fastcall RBX::Graphics::VisualEngine::bindLightingResourcesFallback(
        const RBX::Graphics::VisualEngine *this,
        RBX::Graphics::DeviceContext *context)
{
  (*(void (__fastcall **)(_QWORD, RBX::Graphics::DeviceContext *))(**((_QWORD **)this + 219) + 24LL))(
    *((_QWORD *)this + 219),
    context);
}


// Address: 0x1f94610 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics17PartMaterialTableEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::PartMaterialTable>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::PartMaterialTable> *this)
{
  RBX::Graphics::PartMaterialTable *px; // r14
  __int64 v2; // rbx

  px = this->px;
  if ( this->px )
  {
    v2 = 6336;
    while ( 1 )
    {
      if ( (*((_BYTE *)px + v2 - 24) & 1) != 0 )
      {
        operator delete(*(void **)((char *)px + v2 - 8));
        if ( (*((_BYTE *)px + v2 - 48) & 1) != 0 )
          goto LABEL_10;
LABEL_5:
        if ( (*((_BYTE *)px + v2 - 72) & 1) == 0 )
          goto LABEL_6;
LABEL_11:
        operator delete(*(void **)((char *)px + v2 - 56));
        if ( (*((_BYTE *)px + v2 - 96) & 1) == 0 )
          goto LABEL_7;
LABEL_12:
        operator delete(*(void **)((char *)px + v2 - 80));
        v2 -= 264;
        if ( !v2 )
        {
LABEL_13:
          operator delete(px);
          return;
        }
      }
      else
      {
        if ( (*((_BYTE *)px + v2 - 48) & 1) == 0 )
          goto LABEL_5;
LABEL_10:
        operator delete(*(void **)((char *)px + v2 - 32));
        if ( (*((_BYTE *)px + v2 - 72) & 1) != 0 )
          goto LABEL_11;
LABEL_6:
        if ( (*((_BYTE *)px + v2 - 96) & 1) != 0 )
          goto LABEL_12;
LABEL_7:
        v2 -= 264;
        if ( !v2 )
          goto LABEL_13;
      }
    }
  }
}


// Address: 0x1f946e0 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics12DebugOverlayEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::DebugOverlay>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::DebugOverlay> *this)
{
  RBX::Graphics::DebugOverlay *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::DebugOverlay *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x1f946f0 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics7Shadows15ShadowMapSystemEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::Shadows::ShadowMapSystem>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::Shadows::ShadowMapSystem> *this)
{
  RBX::Graphics::Shadows::ShadowMapSystem *px; // rdi

  px = this->px;
  if ( px )
    (*((void (__fastcall **)(RBX::Graphics::Shadows::ShadowMapSystem *))px->_vptr$ShadowMapSystem + 1))(px);
}


// Address: 0x1f94740 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics17MaterialGeneratorEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::MaterialGenerator>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::MaterialGenerator> *this)
{
  RBX::Graphics::MaterialGenerator *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::MaterialGenerator::~MaterialGenerator(this->px);
    operator delete(px);
  }
}


// Address: 0x1f947f0 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics12TextureAtlasEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::TextureAtlas>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::TextureAtlas> *this)
{
  RBX::Graphics::TextureAtlas *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::TextureAtlas *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x1f94890 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics9LightGridEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::LightGrid>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::LightGrid> *this)
{
  RBX::Graphics::LightGrid *px; // rdi

  px = this->px;
  if ( px )
    (*((void (__fastcall **)(RBX::Graphics::LightGrid *))px->_vptr$LightGrid + 1))(px);
}


// Address: 0x1f948a0 | Name: _ZN5boost10scoped_ptrIN3RBX11RenderStatsEED2Ev
void __fastcall boost::scoped_ptr<RBX::RenderStats>::~scoped_ptr(boost::scoped_ptr<RBX::RenderStats>_0 *this)
{
  RBX::RenderStats *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::RenderStats::~RenderStats(this->px);
    operator delete(px);
  }
}


// Address: 0x1f948c0 | Name: _ZN5boost10scoped_ptrIN3RBX10RenderCapsEED2Ev
void __fastcall boost::scoped_ptr<RBX::RenderCaps>::~scoped_ptr(boost::scoped_ptr<RBX::RenderCaps> *this)
{
  RBX::RenderCaps *px; // rbx

  px = this->px;
  if ( this->px )
  {
    if ( (*((_BYTE *)px + 8) & 1) != 0 )
      operator delete(*((void **)px + 3));
    operator delete(px);
  }
}


// Address: 0x1f948f0 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics10BufferPoolEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::BufferPool>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::BufferPool> *this)
{
  RBX::Graphics::BufferPool *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::BufferPool::~BufferPool(this->px);
    operator delete(px);
  }
}


// Address: 0x1f94910 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics11MeshManagerEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::MeshManager>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::MeshManager> *this)
{
  RBX::Graphics::MeshManager *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::MeshManager::~MeshManager(this->px);
    operator delete(px);
  }
}


// Address: 0x1f94930 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics17PlaneEffectSharedEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::PlaneEffectShared>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::PlaneEffectShared> *this)
{
  RBX::Graphics::PlaneEffectShared *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::PlaneEffectShared::~PlaneEffectShared(this->px);
    operator delete(px);
  }
}


// Address: 0x1f94950 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics13EmitterSharedEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::EmitterShared>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::EmitterShared> *this)
{
  RBX::Graphics::EmitterShared *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::EmitterShared::~EmitterShared(this->px);
    operator delete(px);
  }
}


// Address: 0x1f94970 | Name: _ZN5boost10scoped_ptrIN3RBX16FrameRateManagerEED2Ev
void __fastcall boost::scoped_ptr<RBX::FrameRateManager>::~scoped_ptr(boost::scoped_ptr<RBX::FrameRateManager> *this)
{
  RBX::FrameRateManager *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::FrameRateManager::~FrameRateManager(this->px);
    operator delete(px);
  }
}


// Address: 0x1f94990 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics12SceneManagerEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::SceneManager>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::SceneManager> *this)
{
  RBX::Graphics::SceneManager *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::SceneManager::~SceneManager(this->px);
    operator delete(px);
  }
}


// Address: 0x1f949b0 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics13ShaderManagerEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::ShaderManager>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::ShaderManager> *this)
{
  RBX::Graphics::ShaderManager *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::ShaderManager::~ShaderManager(this->px);
    operator delete(px);
  }
}


// Address: 0x1f949d0 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics12VideoManagerEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::VideoManager>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::VideoManager> *this)
{
  RBX::Graphics::VideoManager *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::VideoManager::~VideoManager(this->px);
    operator delete(px);
  }
}


// Address: 0x1f949f0 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics14TextureManagerEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::TextureManager>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::TextureManager> *this)
{
  RBX::Graphics::TextureManager *px; // rbx

  px = this->px;
  if ( this->px )
  {
    RBX::Graphics::TextureManager::~TextureManager(this->px);
    operator delete(px);
  }
}


// Address: 0x1f94a10 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics17TextureCompositorEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::TextureCompositor>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::TextureCompositor> *this)
{
  RBX::Graphics::TextureCompositor *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::TextureCompositor *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x1f94a20 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics12SceneUpdaterEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::SceneUpdater>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::SceneUpdater> *this)
{
  RBX::Graphics::SceneUpdater *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::SceneUpdater *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x1fad4d0 | Name: _ZN3RBX8Graphics12SceneManager18canReadMainRTDepthEv
bool __fastcall RBX::Graphics::SceneManager::canReadMainRTDepth(RBX::Graphics::SceneManager *this)
{
  return *(_DWORD *)(*((_QWORD *)this + 116) + 96LL) == 1;
}


// Address: 0x1fb4730 | Name: _ZN3RBX8Graphics12SceneManager9renderSkyEPNS0_13DeviceContextERKNS0_12RenderCameraEbb
void __fastcall RBX::Graphics::SceneManager::renderSky(
        RBX::Graphics::SceneManager *this,
        RBX::Graphics::DeviceContext *context,
        const RBX::Graphics::RenderCamera *camera,
        bool envMapPass,
        bool outputLinear)
{
  RBX::Graphics::Sky::render(*((RBX::Graphics::Sky **)this + 114), context, camera, envMapPass, outputLinear);
}


// Address: 0x1fb4d10 | Name: _ZN3RBX8Graphics12SceneManager23setColorCorrectionParamEbfffRKN3G3D6Color3E
void __fastcall RBX::Graphics::SceneManager::setColorCorrectionParam(
        RBX::Graphics::SceneManager *this,
        bool enabled,
        float brightness,
        float contrast,
        float grayscale,
        const RBX::Color3 *tint)
{
  __int64 v6; // rax

  v6 = *((_QWORD *)this + 122);
  *(_BYTE *)(v6 + 8) = enabled;
  *(float *)(v6 + 24) = brightness;
  *(float *)(v6 + 28) = contrast;
  *(float *)(v6 + 32) = grayscale;
  *(RBX::Color3 *)(v6 + 12) = *tint;
}


// Address: 0x1fb4d40 | Name: _ZN3RBX8Graphics12SceneManager12setGlowParamEbff
void __fastcall RBX::Graphics::SceneManager::setGlowParam(
        RBX::Graphics::SceneManager *this,
        bool enabled,
        float a3,
        float glowStrength,
        float glowSize)
{
  __int64 v5; // rax

  v5 = *((_QWORD *)this + 118);
  *(_BYTE *)v5 = enabled;
  *(float *)(v5 + 4) = a3;
  *(float *)(v5 + 8) = glowStrength;
}


// Address: 0x1fb4d60 | Name: _ZN3RBX8Graphics12SceneManager13setBloomParamEbfff
void __fastcall RBX::Graphics::SceneManager::setBloomParam(
        RBX::Graphics::SceneManager *this,
        bool enable,
        float a3,
        float bloomIntensity,
        float bloomThreshold,
        float bloomSize)
{
  __int64 v6; // rax

  v6 = *((_QWORD *)this + 118);
  *(_BYTE *)(v6 + 12) = enable;
  *(float *)(v6 + 16) = a3;
  *(float *)(v6 + 24) = bloomIntensity;
  *(float *)(v6 + 20) = bloomThreshold;
}


// Address: 0x1fb4d80 | Name: _ZN3RBX8Graphics12SceneManager12setBlurParamEbf
void __fastcall RBX::Graphics::SceneManager::setBlurParam(
        RBX::Graphics::SceneManager *this,
        bool enabled,
        float a3,
        float intensity)
{
  __int64 v4; // rax

  v4 = *((_QWORD *)this + 119);
  *(_BYTE *)(v4 + 8) = enabled;
  *(float *)(v4 + 12) = a3;
}


// Address: 0x1fb4eb0 | Name: _ZNK3RBX8Graphics12SceneManager14getColorOpaqueEv
const RBX::Graphics::TextureRef *__fastcall RBX::Graphics::SceneManager::getColorOpaque(
        const RBX::Graphics::SceneManager *this)
{
  return (const RBX::Graphics::TextureRef *)(*((_QWORD *)this + 116) + 56LL);
}


// Address: 0x1fb4ec0 | Name: _ZNK3RBX8Graphics12SceneManager14getDepthOpaqueEv
const RBX::Graphics::TextureRef *__fastcall RBX::Graphics::SceneManager::getDepthOpaque(
        const RBX::Graphics::SceneManager *this)
{
  return (const RBX::Graphics::TextureRef *)(*((_QWORD *)this + 116) + 72LL);
}


// Address: 0x1fb5c20 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics6RTPoolEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::RTPool>::~scoped_ptr(boost::scoped_ptr<RBX::Graphics::RTPool> *this)
{
  RBX::Graphics::RTPool *px; // r14
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // r12
  void *v5; // rdi

  px = this->px;
  if ( this->px )
  {
    v2 = *((_QWORD *)px + 1);
    if ( v2 )
    {
      v3 = *((_QWORD *)px + 2);
      if ( v3 == v2 )
      {
        v5 = (void *)*((_QWORD *)px + 1);
      }
      else
      {
        do
        {
          v4 = *(volatile signed __int32 **)(v3 - 8);
          if ( v4 && !_InterlockedSub(v4 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
            if ( !_InterlockedSub(v4 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
          }
          v3 -= 16;
        }
        while ( v2 != v3 );
        v5 = (void *)*((_QWORD *)px + 1);
      }
      *((_QWORD *)px + 2) = v2;
      operator delete(v5);
    }
    operator delete(px);
  }
}


// Address: 0x1fb9d80 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics6RTPool2RTEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::RTPool::RT>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::RTPool::RT> *this)
{
  RBX::Graphics::RTPool::RT *px; // r14
  volatile signed __int32 *pi; // rbx
  volatile signed __int32 *v3; // rbx

  px = this->px;
  if ( this->px )
  {
    pi = (volatile signed __int32 *)px->frameBuffer.pn.pi_;
    if ( pi )
    {
      if ( !_InterlockedSub(pi + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
        if ( !_InterlockedSub(pi + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
      }
    }
    v3 = (volatile signed __int32 *)px->tex.pn.pi_;
    if ( v3 && !_InterlockedSub(v3 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
      if ( !_InterlockedSub(v3 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
    }
    operator delete(px);
  }
}


// Address: 0x1febf40 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics7Shadows12ShadowObjectEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::Shadows::ShadowObject>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::Shadows::ShadowObject> *this)
{
  RBX::Graphics::Shadows::ShadowObject *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::Shadows::ShadowObject *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x1febf50 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics14LightShadowMapEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::LightShadowMap>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::LightShadowMap> *this)
{
  RBX::Graphics::LightShadowMap *px; // rbx
  unsigned __int8 *v2; // rdi
  unsigned __int8 *v3; // rdi
  unsigned __int8 *v4; // rdi
  unsigned __int8 *v5; // rdi

  px = this->px;
  if ( this->px )
  {
    v2 = px->sliceZ.data.px;
    if ( v2 )
      operator delete[](v2);
    v3 = px->sliceY1.data.px;
    if ( v3 )
      operator delete[](v3);
    v4 = px->sliceY0.data.px;
    if ( v4 )
      operator delete[](v4);
    v5 = px->sliceX.data.px;
    if ( v5 )
      operator delete[](v5);
    operator delete(px);
  }
}


// Address: 0x200d610 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics7EmitterEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::Emitter>::~scoped_ptr(boost::scoped_ptr<RBX::Graphics::Emitter> *this)
{
  RBX::Graphics::Emitter *px; // rdi

  px = this->px;
  if ( px )
    (*(void (__fastcall **)(RBX::Graphics::Emitter *))(*(_QWORD *)px + 8LL))(px);
}


// Address: 0x2037e50 | Name: _ZN5boost10scoped_ptrIN3RBX8Graphics13SmoothCluster5ChunkEED2Ev
void __fastcall boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(
        boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk> *this)
{
  boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk> *px; // rbx
  RBX::Graphics::SmoothCluster::Chunk *v2; // rdi
  RBX::Graphics::SmoothCluster::Chunk *v3; // rdi
  RBX::Graphics::SmoothCluster::Chunk *v4; // rdi
  RBX::Graphics::SmoothCluster::Chunk *v5; // rdi
  RBX::Graphics::SmoothCluster::Chunk *v6; // rdi
  RBX::Graphics::SmoothCluster::Chunk *v7; // rdi

  px = (boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk> *)this->px;
  if ( this->px )
  {
    v2 = px[23].px;
    if ( v2 )
      (*(void (__fastcall **)(RBX::Graphics::SmoothCluster::Chunk *))(*(_QWORD *)v2 + 8LL))(v2);
    v3 = px[22].px;
    if ( v3 )
      (*(void (__fastcall **)(RBX::Graphics::SmoothCluster::Chunk *))(*(_QWORD *)v3 + 8LL))(v3);
    v4 = px[21].px;
    if ( v4 )
      (*(void (__fastcall **)(RBX::Graphics::SmoothCluster::Chunk *))(*(_QWORD *)v4 + 8LL))(v4);
    v5 = px[20].px;
    if ( v5 )
      (*(void (__fastcall **)(RBX::Graphics::SmoothCluster::Chunk *))(*(_QWORD *)v5 + 8LL))(v5);
    v6 = px[13].px;
    if ( v6 )
    {
      px[14].px = v6;
      operator delete(v6);
    }
    v7 = px[12].px;
    if ( v7 )
      (*(void (__fastcall **)(RBX::Graphics::SmoothCluster::Chunk *))(*(_QWORD *)v7 + 8LL))(v7);
    boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(px + 11);
    boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(px + 10);
    boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(px + 9);
    boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(px + 8);
    boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(px + 7);
    boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(px + 6);
    boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(px + 5);
    boost::scoped_ptr<RBX::Graphics::SmoothCluster::Chunk>::~scoped_ptr(px + 4);
    operator delete(px);
  }
}


