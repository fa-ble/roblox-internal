// Address: 0xe63040 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet5do_inER11__mbstate_tPKcS6_RS6_PwS8_RS8_
std::codecvt_base::result __fastcall boost::program_options::detail::utf8_codecvt_facet::do_in(
        const boost::program_options::detail::utf8_codecvt_facet *this,
        mbstate_t *a2,
        const char *from,
        const char *from_end,
        const char **from_next,
        wchar_t *to,
        wchar_t *to_end,
        wchar_t **to_next)
{
  std::codecvt_base::result result; // eax
  int v9; // ebp
  unsigned int v10; // edi
  wchar_t v11; // ebp
  const char *v12; // rsi
  bool v13; // al
  __int64 v14; // rbx
  unsigned __int8 v15; // bl
  unsigned __int8 v16; // bl
  unsigned __int8 v17; // bl
  unsigned __int8 v18; // bl
  unsigned __int8 v19; // bl
  wchar_t *v20; // rsi

  LOBYTE(result) = from != from_end;
  if ( to == to_end || from == from_end )
  {
    v20 = to;
LABEL_38:
    *from_next = from;
    *to_next = v20;
    return (unsigned __int8)result;
  }
  while ( 1 )
  {
    v9 = *(unsigned __int8 *)from;
    if ( (unsigned __int8)v9 > 0xFDu || (unsigned __int8)v9 < 0xC0u && (v9 & 0x80u) != 0 )
    {
      *from_next = from;
      goto LABEL_42;
    }
    v10 = 0;
    if ( (v9 & 0x80u) != 0 )
    {
      v10 = 1;
      if ( (v9 & 0xE0) != 0xC0 )
      {
        v10 = 2;
        if ( (v9 & 0xF0) != 0xE0 )
        {
          v10 = 3;
          if ( (v9 & 0xF8) != 0xF0 )
            v10 = ((v9 & 0xFC) == 0xF8) ^ 5;
        }
      }
    }
    v11 = v9 - dword_498F40[v10];
    v12 = from + 1;
    v13 = v10 != 0;
    v14 = -1;
    if ( from + 1 == from_end || !v10 )
    {
LABEL_32:
      from = v12;
      if ( v12 != from_end )
        goto LABEL_34;
LABEL_33:
      if ( v13 )
      {
        *from_next = &from_end[v14];
        *to_next = to;
        return std::__1::codecvt_base::result::partial;
      }
      goto LABEL_34;
    }
    v15 = *v12;
    if ( *v12 >= 0 || v15 >= 0xC0u )
      break;
    v11 = v15 + (v11 << 6) - 128;
    v12 = from + 2;
    v13 = v10 != 1;
    v14 = -2;
    if ( from + 2 == from_end || v10 == 1 )
      goto LABEL_32;
    v16 = *v12;
    if ( *v12 >= 0 || v16 > 0xBFu )
      break;
    v11 = v16 + (v11 << 6) - 128;
    v12 = from + 3;
    v13 = v10 != 2;
    v14 = -3;
    if ( from + 3 == from_end || v10 == 2 )
      goto LABEL_32;
    v17 = *v12;
    if ( *v12 >= 0 || v17 > 0xBFu )
      break;
    v11 = v17 + (v11 << 6) - 128;
    v12 = from + 4;
    v13 = v10 != 3;
    v14 = -4;
    if ( from + 4 == from_end || v10 == 3 )
      goto LABEL_32;
    v18 = *v12;
    if ( *v12 >= 0 || v18 > 0xBFu )
      break;
    v11 = v18 + (v11 << 6) - 128;
    v12 = from + 5;
    v13 = v10 != 4;
    v14 = -5;
    if ( from + 5 == from_end || v10 == 4 )
      goto LABEL_32;
    v19 = *v12;
    if ( *v12 >= 0 || v19 > 0xBFu )
      break;
    v11 = v19 + (v11 << 6) - 128;
    from += 6;
    v13 = v10 != 5;
    v14 = -6;
    if ( from == from_end )
      goto LABEL_33;
LABEL_34:
    v20 = to + 1;
    *to = v11;
    LOBYTE(result) = from != from_end;
    if ( to_end - 1 != to )
    {
      ++to;
      if ( from != from_end )
        continue;
    }
    goto LABEL_38;
  }
  *from_next = v12;
LABEL_42:
  *to_next = to;
  return std::__1::codecvt_base::result::error;
}


// Address: 0xe632a0 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet6do_outER11__mbstate_tPKwS6_RS6_PcS8_RS8_
std::codecvt_base::result __fastcall boost::program_options::detail::utf8_codecvt_facet::do_out(
        const boost::program_options::detail::utf8_codecvt_facet *this,
        mbstate_t *a2,
        const wchar_t *from,
        const wchar_t *from_end,
        const wchar_t **from_next,
        char *to,
        char *to_end,
        char **to_next)
{
  const wchar_t *v9; // rsi
  bool v10; // cl
  const wchar_t *v11; // r10
  int v12; // eax
  int v13; // ebx
  char v14; // r12
  char *v15; // rax
  bool v16; // cl
  __int64 v17; // rdi
  bool v18; // dl
  char *v19; // r9

  v9 = from;
  v10 = from != from_end;
  if ( to == to_end || from == from_end )
  {
    v15 = to;
LABEL_26:
    *from_next = from;
    *to_next = v15;
    return v10;
  }
  else
  {
    v11 = from_end - 1;
    while ( 1 )
    {
      v12 = *v9;
      v13 = 0;
      if ( *v9 >= 128 )
      {
        v13 = 1;
        if ( v12 >= 2048 )
        {
          v13 = 2;
          if ( v12 >= 0x10000 )
          {
            v13 = 3;
            if ( v12 >= 0x200000 )
              v13 = (v12 < 0x4000000) ^ 5;
          }
        }
      }
      v14 = 6 * v13;
      *to = LOBYTE(dword_498F40[v13]) + v12 / (1 << (6 * v13));
      v15 = to + 1;
      v16 = v13 == 0;
      v17 = -1;
      v18 = to + 1 == to_end;
      if ( to + 1 != to_end )
      {
        if ( v13 )
        {
          to[1] = (*v9 / (1 << (v14 - 6)) % 64) ^ 0x80;
          v15 = to + 2;
          v16 = v13 == 1;
          v17 = -2;
          v18 = to + 2 == to_end;
          if ( to + 2 != to_end && v13 != 1 )
          {
            to[2] = (*v9 / (1 << (v14 - 12)) % 64) ^ 0x80;
            v15 = to + 3;
            v16 = v13 == 2;
            v17 = -3;
            v18 = to + 3 == to_end;
            if ( to + 3 != to_end && v13 != 2 )
            {
              to[3] = (*v9 / (1 << (v14 - 18)) % 64) ^ 0x80;
              v15 = to + 4;
              v16 = v13 == 3;
              v17 = -4;
              v18 = to + 4 == to_end;
              if ( to + 4 != to_end && v13 != 3 )
              {
                to[4] = (*v9 / (1 << (v14 - 24)) % 64) ^ 0x80;
                v15 = to + 5;
                v16 = v13 == 4;
                v17 = -5;
                v18 = to + 5 == to_end;
                if ( to + 5 != to_end && v13 != 4 )
                {
                  to[5] = (*v9 / (1 << (v14 - 30)) % 64) ^ 0x80;
                  v19 = to + 6;
                  v16 = v13 == 5;
                  v18 = v19 == to_end;
                  v17 = -6;
                  v15 = v19;
                }
              }
            }
          }
        }
      }
      if ( !v16 && v18 )
        break;
      from = v9 + 1;
      v10 = v11 != v9;
      if ( v15 != to_end )
      {
        to = v15;
        if ( v11 != v9++ )
          continue;
      }
      goto LABEL_26;
    }
    *from_next = v9;
    *to_next = &v15[v17];
    return std::__1::codecvt_base::result::partial;
  }
}


// Address: 0xe63530 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet24get_cont_octet_out_countEw
int __fastcall boost::program_options::detail::utf8_codecvt_facet::get_cont_octet_out_count(
        const boost::program_options::detail::utf8_codecvt_facet *this,
        wchar_t word)
{
  int result; // eax

  result = 0;
  if ( word >= 128 )
  {
    result = 1;
    if ( word >= 2048 )
    {
      result = 2;
      if ( word >= 0x10000 )
      {
        result = 3;
        if ( word >= 0x200000 )
          return (word < 0x4000000) ^ 5;
      }
    }
  }
  return result;
}


// Address: 0xe63570 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet9do_lengthERK11__mbstate_tPKcS7_m
int __fastcall boost::program_options::detail::utf8_codecvt_facet::do_length(
        const boost::program_options::detail::utf8_codecvt_facet *this,
        const mbstate_t *a2,
        const char *from,
        const char *from_end,
        size_t max_limit)
{
  size_t v6; // rsi
  const char *v7; // rax
  char v8; // di
  __int64 v9; // rdx

  if ( from > from_end )
    return (_DWORD)from - (_DWORD)from_end;
  v6 = 1;
  do
  {
    v7 = from;
    v8 = *from;
    if ( *from < 0 )
    {
      if ( (v8 & 0xE0) == 0xC0 )
      {
        v9 = 2;
        if ( v6 > max_limit )
          return (_DWORD)v7 - (_DWORD)from_end;
      }
      else if ( (v8 & 0xF0) == 0xE0 )
      {
        v9 = 3;
        if ( v6 > max_limit )
          return (_DWORD)v7 - (_DWORD)from_end;
      }
      else if ( (v8 & 0xF8) == 0xF0 )
      {
        v9 = 4;
        if ( v6 > max_limit )
          return (_DWORD)v7 - (_DWORD)from_end;
      }
      else
      {
        v9 = 6LL - ((v8 & 0xFC) == 0xF8);
        if ( v6 > max_limit )
          return (_DWORD)v7 - (_DWORD)from_end;
      }
    }
    else
    {
      v9 = 1;
      if ( v6 > max_limit )
        return (_DWORD)v7 - (_DWORD)from_end;
    }
    from = &v7[v9];
    ++v6;
  }
  while ( from <= from_end );
  return (_DWORD)v7 - (_DWORD)from_end;
}


// Address: 0xe63620 | Name: _ZN5boost15program_options6detail18utf8_codecvt_facet15get_octet_countEh
unsigned int __fastcall boost::program_options::detail::utf8_codecvt_facet::get_octet_count(unsigned __int8 lead_octet)
{
  unsigned int result; // eax

  result = 1;
  if ( (lead_octet & 0x80u) != 0 )
  {
    result = 2;
    if ( (lead_octet & 0xE0) != 0xC0 )
    {
      result = 3;
      if ( (lead_octet & 0xF0) != 0xE0 )
      {
        result = 4;
        if ( (lead_octet & 0xF8) != 0xF0 )
          return 6 - ((lead_octet & 0xFC) == 0xF8);
      }
    }
  }
  return result;
}


// Address: 0xe63670 | Name: _ZN5boost15program_options6detail6detail29get_cont_octet_out_count_implILm4EEEiw
int __fastcall boost::program_options::detail::detail::get_cont_octet_out_count_impl<4ul>(wchar_t word)
{
  int result; // eax

  result = 0;
  if ( word >= 128 )
  {
    result = 1;
    if ( word >= 2048 )
    {
      result = 2;
      if ( word >= 0x10000 )
      {
        result = 3;
        if ( word >= 0x200000 )
          return (word < 0x4000000) ^ 5;
      }
    }
  }
  return result;
}


