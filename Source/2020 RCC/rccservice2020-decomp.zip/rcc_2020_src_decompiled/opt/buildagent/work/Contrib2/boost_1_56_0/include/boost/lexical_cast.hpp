// Address: 0x19f5980 | Name: _ZN5boost12lexical_castINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEiEET_RKT0_
char *__fastcall boost::lexical_cast<std::string,int>(char *a1, int *a2)
{
  int v3; // ebp
  signed int v4; // eax
  char *v5; // rax
  unsigned __int64 v6; // rbx
  unsigned __int8 v7; // al
  unsigned __int64 v8; // r15
  unsigned __int64 v9; // rsi
  __int64 v10; // rcx
  __int64 v11; // rcx
  unsigned __int64 v12; // rbp
  unsigned __int64 v13; // rcx
  unsigned __int64 v14; // rcx
  _BYTE *v15; // rsi
  unsigned __int64 v17; // r8
  __int64 v18; // rsi
  __int64 v19; // rdi
  __int64 v20; // rdx
  __int128 v21; // xmm1
  __int128 v22; // xmm1
  __int128 v23; // xmm1
  __int128 v24; // xmm1
  __int64 v25; // rdi
  __int64 v26; // rsi
  __int128 v27; // xmm1
  boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned int,char> v28; // [rsp+8h] [rbp-70h] BYREF
  _BYTE v30[21]; // [rsp+21h] [rbp-57h] BYREF
  _BYTE v31[2]; // [rsp+36h] [rbp-42h] BYREF
  _BYTE *v32; // [rsp+38h] [rbp-40h]
  _BYTE *v33; // [rsp+40h] [rbp-38h]
  unsigned __int64 v34; // [rsp+48h] [rbp-30h]

  v34 = __readfsqword(0x28u);
  *(_OWORD *)a1 = 0;
  *((_QWORD *)a1 + 2) = 0;
  v32 = v30;
  v33 = v31;
  v3 = *a2;
  v4 = -*a2;
  if ( v4 < 1 )
    v4 = *a2;
  v28.m_value = v4;
  v28.m_finish = v31;
  v28.m_czero = 48;
  v28.m_zero = 48;
  v5 = boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned int,char>::convert(&v28);
  v6 = (unsigned __int64)v5;
  if ( v3 < 0 )
  {
    *(v5 - 1) = 45;
    v6 = (unsigned __int64)(v5 - 1);
    v7 = *a1;
  }
  else
  {
    v7 = 0;
  }
  v32 = (_BYTE *)v6;
  v33 = v31;
  v8 = (unsigned __int64)&v31[-v6];
  if ( (v7 & 1) != 0 )
  {
    v10 = *(_QWORD *)a1;
    v9 = (*(_QWORD *)a1 & 0xFFFFFFFFFFFFFFFELL) - 1;
  }
  else
  {
    v9 = 22;
    LOBYTE(v10) = v7;
  }
  if ( v8 > v9 )
  {
    if ( (v7 & 1) != 0 )
      v11 = *((_QWORD *)a1 + 1);
    else
      v11 = v7 >> 1;
    std::string::__grow_by(a1, v9, v8 - v9, v11, 0, v11, 0);
    LOBYTE(v10) = *a1;
  }
  if ( (v10 & 1) == 0 )
  {
    v12 = (unsigned __int64)(a1 + 1);
    if ( (_BYTE *)v6 == v31 )
      goto LABEL_25;
LABEL_18:
    v13 = (unsigned __int64)&v30[21 - v6];
    if ( v13 < 0x20 || v12 < (unsigned __int64)v31 && v6 < (unsigned __int64)&v30[21 - v6 + v12] )
    {
      v14 = v12;
      goto LABEL_22;
    }
    v17 = v13 & 0xFFFFFFFFFFFFFFE0LL;
    v18 = ((unsigned __int8)(((v13 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
    if ( (v13 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
    {
      v20 = v18 - ((((v13 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
      v19 = 0;
      do
      {
        v21 = *(_OWORD *)(v6 + v19 + 16);
        *(_OWORD *)(v12 + v19) = *(_OWORD *)(v6 + v19);
        *(_OWORD *)(v12 + v19 + 16) = v21;
        v22 = *(_OWORD *)(v6 + v19 + 48);
        *(_OWORD *)(v12 + v19 + 32) = *(_OWORD *)(v6 + v19 + 32);
        *(_OWORD *)(v12 + v19 + 48) = v22;
        v23 = *(_OWORD *)(v6 + v19 + 80);
        *(_OWORD *)(v12 + v19 + 64) = *(_OWORD *)(v6 + v19 + 64);
        *(_OWORD *)(v12 + v19 + 80) = v23;
        v24 = *(_OWORD *)(v6 + v19 + 112);
        *(_OWORD *)(v12 + v19 + 96) = *(_OWORD *)(v6 + v19 + 96);
        *(_OWORD *)(v12 + v19 + 112) = v24;
        v19 += 128;
        v20 += 4;
      }
      while ( v20 );
      if ( (((unsigned __int8)(((v13 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
        goto LABEL_37;
    }
    else
    {
      v19 = 0;
      if ( (((unsigned __int8)(((v13 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
      {
LABEL_37:
        if ( v17 == v13 )
        {
LABEL_24:
          v12 += v8;
          goto LABEL_25;
        }
        v14 = v17 + v12;
        v6 += v17;
LABEL_22:
        v15 = 0;
        do
        {
          v15[v14] = v15[v6];
          ++v15;
        }
        while ( &v30[21 - v6] != v15 );
        goto LABEL_24;
      }
    }
    v25 = v19 + 16;
    v26 = -v18;
    do
    {
      v27 = *(_OWORD *)(v6 + v25);
      *(_OWORD *)(v12 + v25 - 16) = *(_OWORD *)(v6 + v25 - 16);
      *(_OWORD *)(v12 + v25) = v27;
      v25 += 32;
      ++v26;
    }
    while ( v26 );
    goto LABEL_37;
  }
  v12 = *((_QWORD *)a1 + 2);
  if ( (_BYTE *)v6 != v31 )
    goto LABEL_18;
LABEL_25:
  *(_BYTE *)v12 = 0;
  if ( (*a1 & 1) != 0 )
    *((_QWORD *)a1 + 1) = v8;
  else
    *a1 = 2 * v8;
  return a1;
}


// Address: 0x1c4e770 | Name: _ZN5boost12lexical_castINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEElEET_RKT0_
char *__fastcall boost::lexical_cast<std::string,long>(char *a1, __int64 *a2)
{
  __int64 v3; // r15
  signed __int64 v4; // rax
  char *v5; // rax
  char *v6; // rbx
  unsigned __int8 v7; // al
  unsigned __int64 v8; // r15
  unsigned __int64 v9; // rsi
  __int64 v10; // rcx
  __int64 v11; // rcx
  char **v12; // r8
  char **v13; // rdx
  _BYTE *v14; // rsi
  unsigned __int64 v16; // rcx
  __int64 v17; // rdx
  __int64 v18; // rsi
  __int64 v19; // rdi
  __int128 v20; // xmm1
  __int128 v21; // xmm1
  __int128 v22; // xmm1
  __int128 v23; // xmm1
  __int64 v24; // rsi
  __int64 v25; // rdx
  __int128 v26; // xmm1
  boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned long,char> v27; // [rsp+10h] [rbp-78h] BYREF
  char v28; // [rsp+28h] [rbp-60h] BYREF
  char v29; // [rsp+29h] [rbp-5Fh] BYREF
  char *v30; // [rsp+50h] [rbp-38h] BYREF
  char **v31; // [rsp+58h] [rbp-30h]
  unsigned __int64 v32; // [rsp+60h] [rbp-28h]

  v32 = __readfsqword(0x28u);
  *(_OWORD *)a1 = 0;
  *((_QWORD *)a1 + 2) = 0;
  v30 = &v29;
  v31 = &v30;
  v3 = *a2;
  v4 = -*a2;
  if ( v4 < 1 )
    v4 = *a2;
  v27.m_value = v4;
  v27.m_finish = (char *)&v30;
  v27.m_czero = 48;
  v27.m_zero = 48;
  v5 = boost::detail::lcast_put_unsigned<std::char_traits<char>,unsigned long,char>::convert(&v27);
  v6 = v5;
  if ( v3 < 0 )
  {
    *(v5 - 1) = 45;
    v6 = v5 - 1;
    v7 = *a1;
  }
  else
  {
    v7 = 0;
  }
  v30 = v6;
  v31 = &v30;
  v8 = (char *)&v30 - v6;
  if ( (v7 & 1) != 0 )
  {
    v10 = *(_QWORD *)a1;
    v9 = (*(_QWORD *)a1 & 0xFFFFFFFFFFFFFFFELL) - 1;
  }
  else
  {
    v9 = 22;
    LOBYTE(v10) = v7;
  }
  if ( v8 > v9 )
  {
    if ( (v7 & 1) != 0 )
      v11 = *((_QWORD *)a1 + 1);
    else
      v11 = v7 >> 1;
    std::string::__grow_by(a1, v9, v8 - v9, v11, 0, v11, 0);
    LOBYTE(v10) = *a1;
  }
  if ( (v10 & 1) != 0 )
  {
    v12 = (char **)*((_QWORD *)a1 + 2);
    if ( v6 == (char *)&v30 )
      goto LABEL_24;
LABEL_16:
    if ( v8 < 0x20 || v12 < &v30 && v6 < (char *)v12 + v8 )
    {
      v13 = v12;
      goto LABEL_20;
    }
    v16 = v8 & 0xFFFFFFFFFFFFFFE0LL;
    v17 = ((unsigned __int8)(((v8 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
    if ( (v8 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
    {
      v19 = v17 - ((((v8 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
      v18 = 0;
      do
      {
        v20 = *(_OWORD *)&v6[v18 * 8 + 16];
        *(_OWORD *)&v12[v18] = *(_OWORD *)&v6[v18 * 8];
        *(_OWORD *)&v12[v18 + 2] = v20;
        v21 = *(_OWORD *)&v6[v18 * 8 + 48];
        *(_OWORD *)&v12[v18 + 4] = *(_OWORD *)&v6[v18 * 8 + 32];
        *(_OWORD *)&v12[v18 + 6] = v21;
        v22 = *(_OWORD *)&v6[v18 * 8 + 80];
        *(_OWORD *)&v12[v18 + 8] = *(_OWORD *)&v6[v18 * 8 + 64];
        *(_OWORD *)&v12[v18 + 10] = v22;
        v23 = *(_OWORD *)&v6[v18 * 8 + 112];
        *(_OWORD *)&v12[v18 + 12] = *(_OWORD *)&v6[v18 * 8 + 96];
        *(_OWORD *)&v12[v18 + 14] = v23;
        v18 += 16;
        v19 += 4;
      }
      while ( v19 );
      if ( (((unsigned __int8)(((v8 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
        goto LABEL_36;
    }
    else
    {
      v18 = 0;
      if ( (((unsigned __int8)(((v8 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
      {
LABEL_36:
        if ( v8 == v16 )
        {
LABEL_22:
          v12 = (char **)((char *)v12 + v8);
          goto LABEL_24;
        }
        v13 = (char **)((char *)v12 + v16);
        v6 += v16;
LABEL_20:
        v14 = 0;
        do
        {
          v14[(_QWORD)v13] = v14[(_QWORD)v6];
          ++v14;
        }
        while ( (_BYTE *)(&v28 - v6 + 40) != v14 );
        goto LABEL_22;
      }
    }
    v24 = v18 * 8 + 16;
    v25 = -v17;
    do
    {
      v26 = *(_OWORD *)&v6[v24];
      *(_OWORD *)((char *)v12 + v24 - 16) = *(_OWORD *)&v6[v24 - 16];
      *(_OWORD *)((char *)v12 + v24) = v26;
      v24 += 32;
      ++v25;
    }
    while ( v25 );
    goto LABEL_36;
  }
  v12 = (char **)(a1 + 1);
  if ( v6 != (char *)&v30 )
    goto LABEL_16;
LABEL_24:
  *(_BYTE *)v12 = 0;
  if ( (*a1 & 1) != 0 )
    *((_QWORD *)a1 + 1) = v8;
  else
    *a1 = 2 * v8;
  return a1;
}


