// Address: 0x26046b0 | Name: _ZNK5boost4asio2ip10address_v49to_stringERNS_6system10error_codeE
boost::asio::ip::address_v4 *__fastcall boost::asio::ip::address_v4::to_string(
        boost::asio::ip::address_v4 *this,
        boost::system::error_code *a2,
        __int64 a3)
{
  int *v4; // rbx
  const char *v5; // r14
  int v6; // ebx
  const boost::system::error_category *v7; // rax
  size_t v8; // rax
  size_t v9; // r13
  char *v10; // r12
  const boost::system::error_category *v11; // rax
  size_t v12; // rbx
  char v14[24]; // [rsp+0h] [rbp-48h] BYREF
  unsigned __int64 v15; // [rsp+18h] [rbp-30h]

  v15 = __readfsqword(0x28u);
  v4 = __errno_location();
  *v4 = 0;
  v5 = inet_ntop(2, a2, v14, 0x10u);
  v6 = *v4;
  v7 = boost::system::system_category();
  *(_DWORD *)a3 = v6;
  *(_QWORD *)(a3 + 8) = v7;
  if ( v5 )
  {
    *(_OWORD *)&this->addr_.s_addr = 0;
    *((_QWORD *)this + 2) = 0;
    v8 = strlen(v5);
    if ( v8 >= 0xFFFFFFFFFFFFFFF0LL )
    {
      std::__basic_string_common<true>::__throw_length_error(this);
      JUMPOUT(0x26047DA);
    }
    v9 = v8;
    if ( v8 >= 0x17 )
    {
      v12 = (v8 + 16) & 0xFFFFFFFFFFFFFFF0LL;
      v10 = (char *)operator new(v12);
      *((_QWORD *)this + 2) = v10;
      *(_QWORD *)&this->addr_.s_addr = v12 | 1;
      *((_QWORD *)this + 1) = v9;
    }
    else
    {
      LOBYTE(this->addr_.s_addr) = 2 * v8;
      v10 = (char *)&this->addr_.s_addr + 1;
      if ( !v8 )
        goto LABEL_11;
    }
    memcpy(v10, v5, v9);
LABEL_11:
    v10[v9] = 0;
    return this;
  }
  if ( !v6 )
  {
    v11 = boost::system::system_category();
    *(_DWORD *)a3 = 22;
    *(_QWORD *)(a3 + 8) = v11;
  }
  *(_OWORD *)&this->addr_.s_addr = 0;
  *((_QWORD *)this + 2) = 0;
  return this;
}


