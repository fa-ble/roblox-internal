// Address: 0x2625860 | Name: _ZN5boost4asio6detail26reactive_socket_connect_opINS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EENS4_23basic_resolver_iteratorIS5_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSG_6config15asio_tls_client16transport_configEEEFvNSE_10shared_ptrINSI_10connectionISM_EEEENSO_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISU_EENS0_22deadline_timer_serviceISU_SW_EEEEEENSE_8functionIFvRKNSE_10error_codeEEEERKNS_6system10error_codeEEJPSN_RSR_RS10_RS16_RKNSE_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES1A_m
void __fastcall boost::asio::detail::reactive_socket_connect_op<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> v4; // [rsp+0h] [rbp-F8h] BYREF
  unsigned __int64 v5; // [rsp+D8h] [rbp-20h]

  v5 = __readfsqword(0x28u);
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    &v4.handler_,
    (boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[2].task_result_);
  v4.arg1_ = *(boost::system::error_code *)&base[1].next_;
  if ( base )
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op((boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[2].task_result_);
  operator delete(base);
  if ( owner )
  {
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      &v4,
      &v4.handler_.handler_);
    _mm_sfence();
  }
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&v4.handler_);
}


// Address: 0x2626330 | Name: _ZN5boost4asio6detail31reactive_socket_connect_op_base10do_performEPNS1_10reactor_opE
bool __fastcall boost::asio::detail::reactive_socket_connect_op_base::do_perform(boost::asio::detail::reactor_op *base)
{
  return boost::asio::detail::socket_ops::non_blocking_connect(
           (boost::asio::detail::socket_type)base[1].next_,
           &base->ec_);
}


// Address: 0x26672e0 | Name: _ZN5boost4asio6detail26reactive_socket_connect_opINS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EENS4_23basic_resolver_iteratorIS5_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSG_6config11asio_client16transport_configEEEFvNSE_10shared_ptrINSI_10connectionISM_EEEENSO_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISU_EENS0_22deadline_timer_serviceISU_SW_EEEEEENSE_8functionIFvRKNSE_10error_codeEEEERKNS_6system10error_codeEEJPSN_RSR_RS10_RS16_RKNSE_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES1A_m
void __fastcall boost::asio::detail::reactive_socket_connect_op<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> v4; // [rsp+0h] [rbp-F8h] BYREF
  unsigned __int64 v5; // [rsp+D8h] [rbp-20h]

  v5 = __readfsqword(0x28u);
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    &v4.handler_,
    (boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[2].task_result_);
  v4.arg1_ = *(boost::system::error_code *)&base[1].next_;
  if ( base )
    boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op((boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&base[2].task_result_);
  operator delete(base);
  if ( owner )
  {
    boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
      &v4,
      &v4.handler_.handler_);
    _mm_sfence();
  }
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&v4.handler_);
}


// Address: 0x26a1870 | Name: _ZN5boost4asio6detail26reactive_socket_connect_opINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSH_3tcpEEEEENS3_5list3INS3_5valueINSt3__110shared_ptrISC_EEEEPFNS_3argILi1EEEvENSN_ISK_EEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESG_m
void __fastcall boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v5; // rbx
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > >::ptr v6; // [rsp+0h] [rbp-78h] BYREF
  _BYTE f[24]; // [rsp+18h] [rbp-60h] BYREF
  boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > v8; // [rsp+30h] [rbp-48h] BYREF
  __int128 v9; // [rsp+58h] [rbp-20h] BYREF

  v6.v = base;
  v6.p = (boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > > *)base;
  *(_OWORD *)&f[8] = *(_OWORD *)&base[2].task_result_;
  v8.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> = *(boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> *)&base[3].func_;
  *(_OWORD *)&base[3].func_ = 0;
  v8.a3_.t_.values_ = *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)&base[4].next_;
  *(_OWORD *)&base[4].next_ = 0;
  v8.a3_.t_.index_ = *(_QWORD *)&base[4].task_result_;
  v9 = *(_OWORD *)&base[1].next_;
  v6.h = (boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *)&f[8];
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::ptr::reset(&v6);
  if ( owner )
  {
    *(_QWORD *)f = &v9;
    boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::operator()<boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list1<boost::system::error_code const&>>(
      &v8,
      (const boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&f[8],
      (boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)f,
      0);
    _mm_sfence();
  }
  cntrl = v8.a3_.t_.values_.__cntrl_;
  if ( v8.a3_.t_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v8.a3_.t_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v5 = v8.a1_.t_.__cntrl_;
  if ( v8.a1_.t_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v8.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
  }
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::ptr::reset(&v6);
}


// Address: 0x26a19f0 | Name: _ZN5boost4asio6detail26reactive_socket_connect_opINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSH_3tcpEEEEENS3_5list3INS3_5valueINSt3__110shared_ptrISC_EEEEPFNS_3argILi1EEEvENSN_ISK_EEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::ptr::reset(
        boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > >::ptr *this)
{
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > > *p; // rbx
  volatile signed __int64 *cntrl; // r15
  volatile signed __int64 *v4; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.l_.a3_.t_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    v4 = (volatile signed __int64 *)p->handler_.l_.a1_.t_.__cntrl_;
    if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[120];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


// Address: 0x26bc780 | Name: _ZN5boost4asio6detail26reactive_socket_connect_opINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSG_3tcpEEEEENS3_5list3INS3_5valueINSt3__110shared_ptrISB_EEEEPFNS_3argILi1EEEvENSM_ISJ_EEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESF_m
void __fastcall boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v5; // rbx
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > >::ptr v6; // [rsp+0h] [rbp-78h] BYREF
  _BYTE f[24]; // [rsp+18h] [rbp-60h] BYREF
  boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > v8; // [rsp+30h] [rbp-48h] BYREF
  __int128 v9; // [rsp+58h] [rbp-20h] BYREF

  v6.v = base;
  v6.p = (boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > > *)base;
  *(_OWORD *)&f[8] = *(_OWORD *)&base[2].task_result_;
  v8.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = *(boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> *)&base[3].func_;
  *(_OWORD *)&base[3].func_ = 0;
  v8.a3_.t_.values_ = *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)&base[4].next_;
  *(_OWORD *)&base[4].next_ = 0;
  v8.a3_.t_.index_ = *(_QWORD *)&base[4].task_result_;
  v9 = *(_OWORD *)&base[1].next_;
  v6.h = (boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *)&f[8];
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::ptr::reset(&v6);
  if ( owner )
  {
    *(_QWORD *)f = &v9;
    boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::operator()<boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list1<boost::system::error_code const&>>(
      &v8,
      (const boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&f[8],
      (boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)f,
      0);
    _mm_sfence();
  }
  cntrl = v8.a3_.t_.values_.__cntrl_;
  if ( v8.a3_.t_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v8.a3_.t_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v5 = v8.a1_.t_.__cntrl_;
  if ( v8.a1_.t_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v8.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
  }
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::ptr::reset(&v6);
}


// Address: 0x26bc900 | Name: _ZN5boost4asio6detail26reactive_socket_connect_opINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSG_3tcpEEEEENS3_5list3INS3_5valueINSt3__110shared_ptrISB_EEEEPFNS_3argILi1EEEvENSM_ISJ_EEEEEEE3ptr5resetEv
void __fastcall boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>::ptr::reset(
        boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > >::ptr *this)
{
  boost::asio::detail::reactive_socket_connect_op<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > > *p; // rbx
  volatile signed __int64 *cntrl; // r15
  volatile signed __int64 *v4; // rbx
  _BYTE *v; // rdi
  unsigned __int64 v6; // rax
  _QWORD *v7; // rax

  p = this->p;
  if ( p )
  {
    cntrl = (volatile signed __int64 *)p->handler_.l_.a3_.t_.values_.__cntrl_;
    if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
    }
    v4 = (volatile signed __int64 *)p->handler_.l_.a1_.t_.__cntrl_;
    if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
    }
    this->p = 0;
  }
  v = this->v;
  if ( v )
  {
    v6 = __readfsqword(0xFFFFFFD8);
    if ( v6 && (v7 = *(_QWORD **)(v6 + 8)) != 0 && !*v7 )
    {
      *v = v[120];
      *v7 = v;
    }
    else
    {
      operator delete(v);
    }
    this->v = 0;
  }
}


