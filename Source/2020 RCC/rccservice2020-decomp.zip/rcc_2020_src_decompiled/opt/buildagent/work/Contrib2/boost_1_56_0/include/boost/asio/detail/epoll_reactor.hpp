// Address: 0x25f8970 | Name: _ZN5boost4asio6detail13epoll_reactor16descriptor_stateD2Ev
void __fastcall boost::asio::detail::epoll_reactor::descriptor_state::~descriptor_state(
        boost::asio::detail::epoll_reactor::descriptor_state *this)
{
  boost::asio::detail::reactor_op *i; // rbx
  boost::asio::detail::reactor_op *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  boost::asio::detail::reactor_op *j; // rbx
  boost::asio::detail::reactor_op *v5; // rax
  void (__fastcall *v6)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  boost::asio::detail::reactor_op *k; // rbx
  boost::asio::detail::reactor_op *v8; // rax
  void (__fastcall *v9)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v10; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v11; // [rsp+10h] [rbp-28h]

  for ( i = this->op_queue_[2].front_; i; i = this->op_queue_[2].front_ )
  {
    next = (boost::asio::detail::reactor_op *)i->next_;
    this->op_queue_[2].front_ = (boost::asio::detail::reactor_op *)i->next_;
    if ( !next )
      this->op_queue_[2].back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v10 = 0;
    v11 = boost::system::system_category();
    func(0, i, &v10, 0);
  }
  for ( j = this->op_queue_[1].front_; j; j = this->op_queue_[1].front_ )
  {
    v5 = (boost::asio::detail::reactor_op *)j->next_;
    this->op_queue_[1].front_ = (boost::asio::detail::reactor_op *)j->next_;
    if ( !v5 )
      this->op_queue_[1].back_ = 0;
    j->next_ = 0;
    v6 = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))j->func_;
    v10 = 0;
    v11 = boost::system::system_category();
    v6(0, j, &v10, 0);
  }
  for ( k = this->op_queue_[0].front_; k; k = this->op_queue_[0].front_ )
  {
    v8 = (boost::asio::detail::reactor_op *)k->next_;
    this->op_queue_[0].front_ = (boost::asio::detail::reactor_op *)k->next_;
    if ( !v8 )
      this->op_queue_[0].back_ = 0;
    k->next_ = 0;
    v9 = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))k->func_;
    v10 = 0;
    v11 = boost::system::system_category();
    v9(0, k, &v10, 0);
  }
  pthread_mutex_destroy(&this->mutex_.mutex_);
}


