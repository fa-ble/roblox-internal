// Address: 0x2606050 | Name: _ZN5boost4asio11time_traitsINS_10posix_time5ptimeEE8subtractERKS3_S6_
boost::asio::time_traits<boost::posix_time::ptime>::duration_type __fastcall boost::asio::time_traits<boost::posix_time::ptime>::subtract(
        boost::date_time::int_adapter<long>::int_type *a1,
        const boost::asio::time_traits<boost::posix_time::ptime>::time_type *t1,
        const boost::asio::time_traits<boost::posix_time::ptime>::time_type *t2)
{
  unsigned __int64 v3; // r11
  boost::date_time::int_adapter<long>::int_type value; // rcx
  unsigned __int64 v5; // rax
  boost::date_time::int_adapter<long>::int_type v6; // rdx
  unsigned __int64 v7; // rsi
  unsigned __int64 v8; // r9
  unsigned __int64 v9; // r10
  __int64 v10; // rsi
  unsigned __int64 v11; // rax

  v3 = 0x7FFFFFFFFFFFFFFELL;
  value = t1->time_.time_count_.value_;
  v5 = t1->time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL;
  v6 = t2->time_.time_count_.value_;
  v7 = v6 - 0x7FFFFFFFFFFFFFFELL;
  if ( v5 < 3 || v7 <= 2 )
  {
    if ( value != 0x8000000000000000LL )
    {
      if ( value == 0x7FFFFFFFFFFFFFFELL )
        goto LABEL_29;
      if ( value != 0x7FFFFFFFFFFFFFFFLL && v7 > 2 )
      {
LABEL_22:
        value -= v6;
        goto LABEL_23;
      }
    }
    if ( v6 == 0x7FFFFFFFFFFFFFFELL )
    {
LABEL_28:
      value = v3;
      goto LABEL_29;
    }
    v8 = value - 0x7FFFFFFFFFFFFFFFLL;
    if ( value == 0x8000000000000000LL )
    {
      v9 = 0x8000000000000000LL;
    }
    else
    {
      if ( value != 0x7FFFFFFFFFFFFFFFLL )
      {
        if ( v8 < 2 )
        {
LABEL_23:
          v10 = value;
LABEL_24:
          v11 = 0x8000000000000000LL;
          if ( v10 != 0x8000000000000000LL )
            v11 = 0x7FFFFFFFFFFFFFFELL;
          v3 = 0x7FFFFFFFFFFFFFFFLL;
          if ( v10 != 0x7FFFFFFFFFFFFFFFLL )
            v3 = v11;
          goto LABEL_28;
        }
        goto LABEL_19;
      }
      v9 = 0x7FFFFFFFFFFFFFFFLL;
    }
    v10 = v9;
    if ( v6 == v9 )
      v10 = 0x7FFFFFFFFFFFFFFELL;
    if ( v8 < 2 || v6 == v9 )
      goto LABEL_24;
LABEL_19:
    if ( v6 == 0x8000000000000000LL )
    {
      v3 = 0x7FFFFFFFFFFFFFFFLL;
      goto LABEL_28;
    }
    if ( v6 == 0x7FFFFFFFFFFFFFFFLL )
    {
      v3 = 0x8000000000000000LL;
      goto LABEL_28;
    }
    goto LABEL_22;
  }
  value -= v6;
LABEL_29:
  *a1 = value;
  return (boost::asio::time_traits<boost::posix_time::ptime>::duration_type)a1;
}


