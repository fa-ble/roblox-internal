// Address: 0xf2fae0 | Name: j__ZN5boost10flyweights6detail17refcounted_handleIPKNS1_16refcounted_valueINS1_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeES7_EENS1_30flyweight_core_tracking_helperIS8_N4mpl_2naENS0_10refcountedENS0_14hashed_factoryISF_SF_SF_Li0EEENS0_14simple_lockingENS0_13static_holderEEEED2Ev
// attributes: thunk
void __fastcall boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(
        char *dest)
{
  _ZN5boost10flyweights6detail17refcounted_handleIPKNS1_16refcounted_valueINS1_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeES7_EENS1_30flyweight_core_tracking_helperIS8_N4mpl_2naENS0_10refcountedENS0_14hashed_factoryISF_SF_SF_Li0EEENS0_14simple_lockingENS0_13static_holderEEEED2Ev((boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *)dest);
}


// Address: 0x1311ae0 | Name: j__ZN5boost10flyweights6detail17refcounted_handleIPKNS1_16refcounted_valueINS1_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeES7_EENS1_30flyweight_core_tracking_helperIS8_N4mpl_2naENS0_10refcountedENS0_14hashed_factoryISF_SF_SF_Li0EEENS0_14simple_lockingENS0_13static_holderEEEED2Ev_0
// attributes: thunk
void __fastcall boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(
        boost::flyweights::flyweight<RBX::SharedString::Data,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_> *this)
{
  _ZN5boost10flyweights6detail17refcounted_handleIPKNS1_16refcounted_valueINS1_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeES7_EENS1_30flyweight_core_tracking_helperIS8_N4mpl_2naENS0_10refcountedENS0_14hashed_factoryISF_SF_SF_Li0EEENS0_14simple_lockingENS0_13static_holderEEEED2Ev(&this->h);
}


// Address: 0x1e2d780 | Name: _ZN5boost10flyweights9flyweightIN3RBX18PhysicalPropertiesENS_9parameter5void_ES5_S5_S5_S5_ED2Ev
// attributes: thunk
void __fastcall boost::flyweights::flyweight<RBX::PhysicalProperties,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_>::~flyweight(
        boost::flyweights::flyweight<RBX::PhysicalProperties,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_,boost::parameter::void_> *this)
{
  boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(&this->h);
}


