// Address: 0xfe9630 | Name: _ZN5boost9date_time14microsec_clockINS_10posix_time5ptimeEE11create_timeEPFP2tmPKlS6_E
boost::posix_time::ptime __fastcall boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(
        time_converter_0 converter)
{
  __int64 tv_usec_low; // r14
  tm *v2; // rbx
  int v3; // eax
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,12,boost::gregorian::bad_month> >::value_type v4; // ax
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,31,boost::gregorian::bad_day_of_month> >::value_type tm_mday; // si
  __int64 tm_hour; // rax
  __int64 tm_min; // rcx
  __int64 tm_sec; // rdx
  boost::posix_time::ptime v9; // r14
  __int64 v10; // rsi
  __int64 v11; // rdx
  __int64 v12; // rcx
  boost::posix_time::ptime v13; // rdx
  boost::posix_time::ptime result; // rax
  unsigned __int64 v15; // rsi
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,31,boost::gregorian::bad_day_of_month> > v16[2]; // [rsp+8h] [rbp-80h] BYREF
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,12,boost::gregorian::bad_month> > v17[2]; // [rsp+10h] [rbp-78h] BYREF
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1400,10000,boost::gregorian::bad_year> > v18[2]; // [rsp+18h] [rbp-70h] BYREF
  boost::gregorian::date v19; // [rsp+20h] [rbp-68h] BYREF
  __time_t tv_sec; // [rsp+28h] [rbp-60h] BYREF
  struct timeval tv; // [rsp+30h] [rbp-58h] BYREF
  tm v22; // [rsp+40h] [rbp-48h] BYREF

  gettimeofday(&tv, 0);
  tv_sec = tv.tv_sec;
  tv_usec_low = LODWORD(tv.tv_usec);
  v2 = converter(&tv_sec, &v22);
  v3 = v2->tm_year + 1900;
  v18[0].value_ = 1400;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1400,(unsigned short)10000,boost::gregorian::bad_year>>::assign(
    v18,
    v3);
  v4 = v2->tm_mon + 1;
  v17[0].value_ = 1;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)12,boost::gregorian::bad_month>>::assign(
    v17,
    v4);
  tm_mday = v2->tm_mday;
  v16[0].value_ = 1;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)31,boost::gregorian::bad_day_of_month>>::assign(
    v16,
    tm_mday);
  boost::gregorian::date::date(
    &v19,
    (boost::gregorian::date::year_type_0)v18[0].value_,
    (boost::gregorian::date::month_type_0)v17[0].value_,
    (boost::gregorian::date::day_type)v16[0].value_);
  tm_hour = v2->tm_hour;
  tm_min = v2->tm_min;
  tm_sec = v2->tm_sec;
  if ( (int)(tm_sec | tm_hour | v2->tm_min) < 0 )
  {
    v10 = (unsigned int)-(int)tm_sec;
    if ( -(int)tm_sec < 1 )
      v10 = (unsigned int)tm_sec;
    v11 = (unsigned int)-(int)tm_min;
    if ( -(int)tm_min < 1 )
      v11 = (unsigned int)tm_min;
    v12 = (unsigned int)-(int)tm_hour;
    if ( -(int)tm_hour < 1 )
      v12 = (unsigned int)tm_hour;
    v9.time_.time_count_.value_ = -(1000000 * (3600 * v12 + 60 * v11 + v10) + tv_usec_low);
  }
  else
  {
    v9.time_.time_count_.value_ = 1000000 * (tm_sec + 3600 * tm_hour + 60 * tm_min) + tv_usec_low;
  }
  v13.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFELL;
  if ( v19.days_ + 2 >= 3 && (unsigned __int64)(v9.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) > 2 )
    return (boost::posix_time::ptime)(v9.time_.time_count_.value_ + 86400000000LL * v19.days_);
  switch ( v9.time_.time_count_.value_ )
  {
    case 0x8000000000000000LL:
      goto LABEL_14;
    case 0x7FFFFFFFFFFFFFFELL:
      return v9;
    case 0x7FFFFFFFFFFFFFFFLL:
LABEL_14:
      if ( v19.days_ == -2 )
        return v13;
      break;
    default:
      if ( v19.days_ + 1 >= 2 )
      {
        result.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFELL;
        if ( v19.days_ == -2 )
          return result;
        return (boost::posix_time::ptime)(v19.days_ + v9.time_.time_count_.value_);
      }
      break;
  }
  v15 = v9.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFFLL;
  if ( v9.time_.time_count_.value_ != 0x8000000000000000LL )
  {
    if ( v9.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
    {
      result.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFFLL;
      if ( !v19.days_ )
        return (boost::posix_time::ptime)0x7FFFFFFFFFFFFFFELL;
      goto LABEL_23;
    }
    if ( v15 >= 2 )
      goto LABEL_31;
    return v9;
  }
  result.time_.time_count_.value_ = 0x8000000000000000LL;
  if ( v19.days_ == -1 )
    return (boost::posix_time::ptime)0x7FFFFFFFFFFFFFFELL;
LABEL_23:
  if ( v15 >= 2 )
  {
LABEL_31:
    if ( v19.days_ == -1 )
      return (boost::posix_time::ptime)0x7FFFFFFFFFFFFFFFLL;
    if ( !v19.days_ )
      return (boost::posix_time::ptime)0x8000000000000000LL;
    return (boost::posix_time::ptime)(v19.days_ + v9.time_.time_count_.value_);
  }
  return result;
}


