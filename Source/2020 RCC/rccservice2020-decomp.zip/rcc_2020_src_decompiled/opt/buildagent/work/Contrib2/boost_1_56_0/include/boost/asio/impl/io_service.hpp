// Address: 0x25f99d0 | Name: _ZN5boost4asio10io_service4workD2Ev
void __fastcall boost::asio::io_service::work::~work(boost::asio::io_service::work *this)
{
  boost::asio::detail::io_service_impl *io_service_impl; // rbx
  boost::asio::detail::reactor *task; // rax
  struct epoll_event event; // [rsp+8h] [rbp-20h] BYREF

  io_service_impl = this->io_service_impl_;
  if ( !_InterlockedSub64(&this->io_service_impl_->outstanding_work_.__a_, 1u) )
  {
    pthread_mutex_lock(&io_service_impl->mutex_.mutex_);
    io_service_impl->stopped_ = 1;
    LOBYTE(io_service_impl->wakeup_event_.state_) |= 1u;
    pthread_cond_broadcast(&io_service_impl->wakeup_event_.cond_);
    if ( !io_service_impl->task_interrupted_ )
    {
      task = io_service_impl->task_;
      if ( task )
      {
        io_service_impl->task_interrupted_ = 1;
        event.events = -2147483639;
        event.data.u64 = (uint64_t)&task->interrupter_;
        epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, &event);
      }
    }
    pthread_mutex_unlock(&io_service_impl->mutex_.mutex_);
  }
}


// Address: 0x26a10e0 | Name: _ZN5boost4asio10io_service4postINS0_6detail7binder1INS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSJ_3tcpEEEEENS5_5list3INS5_5valueINSt3__110shared_ptrISE_EEEEPFNS_3argILi1EEEvENSP_ISM_EEEEEESG_EEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS14_
boost::asio::async_result<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> >::type __fastcall boost::asio::io_service::post<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>(
        boost::asio::io_service *this,
        boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v3; // rbx
  boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> v4; // [rsp+0h] [rbp-68h] BYREF

  v4.handler_.f_ = handler->handler_.f_;
  v4.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> = handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()>;
  handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> = 0;
  v4.handler_.l_.a3_.t_.values_ = handler->handler_.l_.a3_.t_.values_;
  handler->handler_.l_.a3_.t_.values_ = 0;
  v4.handler_.l_.a3_.t_.index_ = handler->handler_.l_.a3_.t_.index_;
  v4.arg1_ = handler->arg1_;
  boost::asio::detail::task_io_service::post<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>(
    this->impl_,
    &v4);
  cntrl = v4.handler_.l_.a3_.t_.values_.__cntrl_;
  if ( v4.handler_.l_.a3_.t_.values_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v4.handler_.l_.a3_.t_.values_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v3 = v4.handler_.l_.a1_.t_.__cntrl_;
  if ( v4.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v4.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(v3);
      std::__shared_weak_count::__release_weak(v3);
    }
  }
}


// Address: 0x26bbff0 | Name: _ZN5boost4asio10io_service4postINS0_6detail7binder1INS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINSI_3tcpEEEEENS5_5list3INS5_5valueINSt3__110shared_ptrISD_EEEEPFNS_3argILi1EEEvENSO_ISL_EEEEEESF_EEEENS0_12async_resultINS0_12handler_typeIT_FvvEE4typeEE4typeEOS13_
boost::asio::async_result<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> >::type __fastcall boost::asio::io_service::post<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>(
        boost::asio::io_service *this,
        boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v3; // rbx
  boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > >,boost::system::error_code> v4; // [rsp+0h] [rbp-68h] BYREF

  v4.handler_.f_ = handler->handler_.f_;
  v4.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  v4.handler_.l_.a3_.t_.values_ = handler->handler_.l_.a3_.t_.values_;
  handler->handler_.l_.a3_.t_.values_ = 0;
  v4.handler_.l_.a3_.t_.index_ = handler->handler_.l_.a3_.t_.index_;
  v4.arg1_ = handler->arg1_;
  boost::asio::detail::task_io_service::post<boost::asio::detail::binder1<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>,boost::system::error_code>>(
    this->impl_,
    &v4);
  cntrl = v4.handler_.l_.a3_.t_.values_.__cntrl_;
  if ( v4.handler_.l_.a3_.t_.values_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v4.handler_.l_.a3_.t_.values_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v3 = v4.handler_.l_.a1_.t_.__cntrl_;
  if ( v4.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v4.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(v3);
      std::__shared_weak_count::__release_weak(v3);
    }
  }
}


