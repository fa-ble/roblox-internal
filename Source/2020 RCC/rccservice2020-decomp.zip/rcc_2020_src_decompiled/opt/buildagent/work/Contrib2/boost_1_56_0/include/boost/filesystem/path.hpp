// Address: 0xefb300 | Name: _ZNK5boost10filesystem4path7compareEPKc
int __fastcall boost::filesystem::path::compare(
        const boost::filesystem::path *this,
        const boost::filesystem::path::value_type *s)
{
  size_t v2; // rax
  size_t v3; // r13
  char *v4; // r12
  size_t v5; // rbx
  int v6; // ebx
  __int128 dest; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  dest = 0;
  ptr = 0;
  v2 = strlen(s);
  if ( v2 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(&dest);
    JUMPOUT(0xEFB3C3);
  }
  v3 = v2;
  if ( v2 >= 0x17 )
  {
    v5 = (v2 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v4 = (char *)operator new(v5);
    ptr = v4;
    *(_QWORD *)&dest = v5 | 1;
    *((_QWORD *)&dest + 1) = v3;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v2;
  v4 = (char *)&dest + 1;
  if ( v2 )
LABEL_6:
    memcpy(v4, s, v3);
  v4[v3] = 0;
  v6 = boost::filesystem::path::compare(this, (const boost::filesystem::path *)&dest);
  if ( (dest & 1) != 0 )
    operator delete(ptr);
  return v6;
}


// Address: 0x1a334c0 | Name: _ZN3RBX6Plugin15setCompletePathEN5boost10filesystem4pathE
void __fastcall RBX::Plugin::setCompletePath(__int64 a1, int a2, int a3, void *a4, size_t a5, const void *a6)
{
  std::string::operator=((soap *)(a1 + 240), a2, a3, a4, a5, a6);
}


// Address: 0x283de60 | Name: _ZN5boost10filesystem4path6assignIPcEERS1_T_S5_
boost::filesystem::path *__fastcall boost::filesystem::path::assign<char *>(
        boost::filesystem::path *this,
        char *begin,
        char *end)
{
  char *v4; // rbx
  unsigned __int64 v6; // r13
  char *v7; // rax
  unsigned __int64 v8; // r8
  __int64 v9; // rdx
  __int64 v10; // rsi
  char *v11; // r8
  __int64 v12; // rdi
  __int128 v13; // xmm1
  __int128 v14; // xmm1
  __int128 v15; // xmm1
  __int128 v16; // xmm1
  __int64 v17; // rsi
  __int64 v18; // rdx
  __int128 v19; // xmm1
  char *v20; // r15
  char *v21; // rdx
  const char *v22; // rsi
  unsigned __int64 v23; // rdx
  struct _Unwind_Exception *v25; // rax
  struct _Unwind_Exception *v26; // rbx
  char __first[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  v4 = begin;
  if ( (*(_BYTE *)this & 1) != 0 )
  {
    **((_BYTE **)this + 2) = 0;
    *((_QWORD *)this + 1) = 0;
    if ( begin == end )
      return this;
  }
  else
  {
    *(_WORD *)this = 0;
    if ( begin == end )
      return this;
  }
  *(_OWORD *)__first = 0;
  ptr = 0;
  v6 = end - begin;
  if ( (unsigned __int64)(end - begin) >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(__first);
    v26 = v25;
    if ( (__first[0] & 1) != 0 )
      operator delete(ptr);
    _Unwind_Resume(v26);
  }
  if ( v6 <= 0x16 )
  {
    __first[0] = 2 * v6;
    v7 = &__first[1];
LABEL_12:
    v11 = v7;
    goto LABEL_20;
  }
  v7 = (char *)operator new((v6 + 16) & 0xFFFFFFFFFFFFFFF0LL);
  ptr = v7;
  *(_QWORD *)__first = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL | 1;
  *(_QWORD *)&__first[8] = end - begin;
  if ( v6 < 0x20 )
    goto LABEL_12;
  v8 = v6 & 0xFFFFFFFFFFFFFFE0LL;
  v9 = ((unsigned __int8)(((v6 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
  if ( (v6 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
  {
    v12 = v9 - ((((v6 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
    v10 = 0;
    do
    {
      v13 = *(_OWORD *)&v4[v10 + 16];
      *(_OWORD *)&v7[v10] = *(_OWORD *)&v4[v10];
      *(_OWORD *)&v7[v10 + 16] = v13;
      v14 = *(_OWORD *)&v4[v10 + 48];
      *(_OWORD *)&v7[v10 + 32] = *(_OWORD *)&v4[v10 + 32];
      *(_OWORD *)&v7[v10 + 48] = v14;
      v15 = *(_OWORD *)&v4[v10 + 80];
      *(_OWORD *)&v7[v10 + 64] = *(_OWORD *)&v4[v10 + 64];
      *(_OWORD *)&v7[v10 + 80] = v15;
      v16 = *(_OWORD *)&v4[v10 + 112];
      *(_OWORD *)&v7[v10 + 96] = *(_OWORD *)&v4[v10 + 96];
      *(_OWORD *)&v7[v10 + 112] = v16;
      v10 += 128;
      v12 += 4;
    }
    while ( v12 );
    if ( (((unsigned __int8)(((v6 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
      goto LABEL_18;
    goto LABEL_16;
  }
  v10 = 0;
  if ( (((unsigned __int8)(((v6 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) != 0 )
  {
LABEL_16:
    v17 = v10 + 16;
    v18 = -v9;
    do
    {
      v19 = *(_OWORD *)&v4[v17];
      *(_OWORD *)&v7[v17 - 16] = *(_OWORD *)&v4[v17 - 16];
      *(_OWORD *)&v7[v17] = v19;
      v17 += 32;
      ++v18;
    }
    while ( v18 );
  }
LABEL_18:
  if ( v6 == v8 )
    goto LABEL_22;
  v4 += v8;
  v11 = &v7[v8];
LABEL_20:
  v20 = (char *)(end - v4);
  v21 = 0;
  do
  {
    v21[(_QWORD)v11] = v21[(_QWORD)v4];
    ++v21;
  }
  while ( v20 != v21 );
LABEL_22:
  v7[v6] = 0;
  if ( (__first[0] & 1) != 0 )
  {
    v22 = (const char *)ptr;
    v23 = *(_QWORD *)&__first[8];
  }
  else
  {
    v23 = (unsigned __int64)(unsigned __int8)__first[0] >> 1;
    v22 = &__first[1];
  }
  std::string::__append_forward_unsafe<char const*>(this, v22, &v22[v23]);
  if ( (__first[0] & 1) != 0 )
    operator delete(ptr);
  return this;
}


// Address: 0x2841f30 | Name: _ZN5boost10filesystem4pathC2IPKcEET_S5_
void __fastcall boost::filesystem::path::path<char const*>(
        boost::filesystem::path *this,
        const char *begin,
        const char *end)
{
  const char *v4; // rbx
  unsigned __int64 v6; // r13
  char *v7; // rax
  char *v8; // r8
  unsigned __int64 v9; // r8
  __int64 v10; // rdx
  __int64 v11; // rsi
  __int64 v12; // rdi
  __int128 v13; // xmm1
  __int128 v14; // xmm1
  __int128 v15; // xmm1
  __int128 v16; // xmm1
  __int64 v17; // rsi
  __int64 v18; // rdx
  __int128 v19; // xmm1
  const char *v20; // r15
  const char *v21; // rdx
  const char *v22; // rsi
  unsigned __int64 v23; // rdx
  struct _Unwind_Exception *v24; // rax
  struct _Unwind_Exception *v25; // rbx
  char __first[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  if ( begin == end )
    return;
  v4 = begin;
  *(_OWORD *)__first = 0;
  ptr = 0;
  v6 = end - begin;
  if ( (unsigned __int64)(end - begin) >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(__first);
    v25 = v24;
    if ( (*(_BYTE *)this & 1) == 0 )
      _Unwind_Resume(v24);
    operator delete(*((void **)this + 2));
    _Unwind_Resume(v25);
  }
  if ( v6 <= 0x16 )
  {
    __first[0] = 2 * v6;
    v7 = &__first[1];
LABEL_5:
    v8 = v7;
    goto LABEL_17;
  }
  v7 = (char *)operator new((v6 + 16) & 0xFFFFFFFFFFFFFFF0LL);
  ptr = v7;
  *(_QWORD *)__first = (v6 + 16) & 0xFFFFFFFFFFFFFFF0LL | 1;
  *(_QWORD *)&__first[8] = v6;
  if ( v6 < 0x20 )
    goto LABEL_5;
  v9 = v6 & 0xFFFFFFFFFFFFFFE0LL;
  v10 = ((unsigned __int8)(((v6 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
  if ( (v6 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
  {
    v12 = v10 - ((((v6 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
    v11 = 0;
    do
    {
      v13 = *(_OWORD *)&v4[v11 + 16];
      *(_OWORD *)&v7[v11] = *(_OWORD *)&v4[v11];
      *(_OWORD *)&v7[v11 + 16] = v13;
      v14 = *(_OWORD *)&v4[v11 + 48];
      *(_OWORD *)&v7[v11 + 32] = *(_OWORD *)&v4[v11 + 32];
      *(_OWORD *)&v7[v11 + 48] = v14;
      v15 = *(_OWORD *)&v4[v11 + 80];
      *(_OWORD *)&v7[v11 + 64] = *(_OWORD *)&v4[v11 + 64];
      *(_OWORD *)&v7[v11 + 80] = v15;
      v16 = *(_OWORD *)&v4[v11 + 112];
      *(_OWORD *)&v7[v11 + 96] = *(_OWORD *)&v4[v11 + 96];
      *(_OWORD *)&v7[v11 + 112] = v16;
      v11 += 128;
      v12 += 4;
    }
    while ( v12 );
    if ( (((unsigned __int8)(((v6 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
      goto LABEL_15;
    goto LABEL_13;
  }
  v11 = 0;
  if ( (((unsigned __int8)(((v6 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) != 0 )
  {
LABEL_13:
    v17 = v11 + 16;
    v18 = -v10;
    do
    {
      v19 = *(_OWORD *)&v4[v17];
      *(_OWORD *)&v7[v17 - 16] = *(_OWORD *)&v4[v17 - 16];
      *(_OWORD *)&v7[v17] = v19;
      v17 += 32;
      ++v18;
    }
    while ( v18 );
  }
LABEL_15:
  if ( v6 == v9 )
    goto LABEL_19;
  v4 += v9;
  v8 = &v7[v9];
LABEL_17:
  v20 = (const char *)(end - v4);
  v21 = 0;
  do
  {
    v21[(_QWORD)v8] = v21[(_QWORD)v4];
    ++v21;
  }
  while ( v20 != v21 );
LABEL_19:
  v7[v6] = 0;
  if ( (__first[0] & 1) != 0 )
  {
    v22 = (const char *)ptr;
    v23 = *(_QWORD *)&__first[8];
  }
  else
  {
    v23 = (unsigned __int64)(unsigned __int8)__first[0] >> 1;
    v22 = &__first[1];
  }
  std::string::__append_forward_unsafe<char const*>(this, v22, &v22[v23]);
  if ( (__first[0] & 1) != 0 )
    operator delete(ptr);
}


