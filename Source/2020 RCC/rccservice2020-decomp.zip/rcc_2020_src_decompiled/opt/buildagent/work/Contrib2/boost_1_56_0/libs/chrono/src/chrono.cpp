// Address: 0x2839950 | Name: _GLOBAL__sub_I_chrono.cpp
void __cdecl GLOBAL__sub_I_chrono_cpp()
{
  qword_2CE5538 = (__int64)boost::system::generic_category();
  qword_2CE5540 = (__int64)boost::system::generic_category();
  qword_2CE5548 = (__int64)boost::system::system_category();
}


