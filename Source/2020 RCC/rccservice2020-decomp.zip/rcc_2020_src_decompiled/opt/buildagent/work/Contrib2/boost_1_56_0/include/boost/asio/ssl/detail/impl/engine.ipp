// Address: 0x2609c10 | Name: _ZNK5boost4asio3ssl6detail6engine14map_error_codeERNS_6system10error_codeE
const boost::system::error_code *__fastcall boost::asio::ssl::detail::engine::map_error_code(
        const boost::asio::ssl::detail::engine *this,
        boost::system::error_code *ec)
{
  if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
    __cxa_guard_release(&byte_2B114E0);
  if ( (void (__fastcall ***)(boost::system::error_category *__hidden))ec->m_cat == off_2870A08
    && ec->m_val == 2
    && ((unsigned int)BIO_ctrl(this->ext_bio_, 13, 0, 0) || (SSL_get_shutdown(this->ssl_) & 2) == 0) )
  {
    if ( !(_BYTE)byte_2B114F0 && __cxa_guard_acquire(&byte_2B114F0) )
      __cxa_guard_release(&byte_2B114F0);
    ec->m_val = 1;
    ec->m_cat = (const boost::system::error_category *)&off_2870A18;
  }
  return ec;
}


// Address: 0x2609cc0 | Name: _ZN5boost4asio3ssl6detail6engine7performEMS3_FiPvmES4_mRNS_6system10error_codeEPm
__int64 __fastcall boost::asio::ssl::detail::engine::perform(
        boost::asio::ssl::detail::engine *this,
        int (*op)(boost::asio::ssl::detail::engine *, void *, size_t),
        char *data,
        size_t length,
        boost::system::error_code *ec,
        size_t *bytes_transferred,
        _QWORD *a7)
{
  int (*v10)(boost::asio::ssl::detail::engine *, void *, size_t); // rbp
  boost::asio::ssl::detail::engine *v11; // r15
  __int64 v12; // r13
  int error; // ebp
  int v14; // r12d
  unsigned __int64 v15; // rax
  void (__fastcall ***v16)(boost::system::error_category *__hidden); // rax
  const boost::system::error_category *v18; // rax
  const boost::system::error_category *v19; // rax
  const boost::system::error_category *v20; // rax
  unsigned __int64 v21; // [rsp+0h] [rbp-38h]

  v10 = op;
  v11 = (boost::asio::ssl::detail::engine *)&data[(_QWORD)this];
  v21 = BIO_ctrl_pending(this->ext_bio_);
  if ( ((unsigned __int8)op & 1) != 0 )
    v10 = *(int (**)(boost::asio::ssl::detail::engine *, void *, size_t))((char *)v11->ssl_ + (unsigned __int64)op - 1);
  v12 = (unsigned int)v10(v11, (void *)length, (size_t)ec);
  error = SSL_get_error(this->ssl_, v12);
  v14 = ERR_get_error();
  v15 = BIO_ctrl_pending(this->ext_bio_);
  if ( error == 5 )
  {
    v16 = (void (__fastcall ***)(boost::system::error_category *__hidden))boost::system::system_category();
    *(_DWORD *)bytes_transferred = v14;
  }
  else if ( error == 1 )
  {
    if ( !(_BYTE)byte_2B114E8 )
    {
      if ( __cxa_guard_acquire(&byte_2B114E8) )
        __cxa_guard_release(&byte_2B114E8);
    }
    *(_DWORD *)bytes_transferred = v14;
    v16 = off_2870A10;
  }
  else
  {
    if ( a7 && (int)v12 > 0 )
      *a7 = (int)v12;
    if ( error == 3 )
    {
      v18 = boost::system::system_category();
      *(_DWORD *)bytes_transferred = 0;
      bytes_transferred[1] = (size_t)v18;
      return 0xFFFFFFFFLL;
    }
    if ( v15 > v21 )
    {
      v19 = boost::system::system_category();
      *(_DWORD *)bytes_transferred = 0;
      bytes_transferred[1] = (size_t)v19;
      return 2 * (unsigned int)((int)v12 > 0) - 1;
    }
    if ( error == 2 )
    {
      v20 = boost::system::system_category();
      *(_DWORD *)bytes_transferred = 0;
      bytes_transferred[1] = (size_t)v20;
      return 4294967294LL;
    }
    if ( (SSL_get_shutdown(this->ssl_) & 2) != 0 )
    {
      if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
        __cxa_guard_release(&byte_2B114E0);
      *(_DWORD *)bytes_transferred = 2;
      v16 = off_2870A08;
    }
    else
    {
      v16 = (void (__fastcall ***)(boost::system::error_category *__hidden))boost::system::system_category();
      *(_DWORD *)bytes_transferred = 0;
    }
  }
  bytes_transferred[1] = (size_t)v16;
  return 0;
}


// Address: 0x2609e60 | Name: _ZN5boost4asio3ssl6detail6engine11do_shutdownEPvm
int __fastcall boost::asio::ssl::detail::engine::do_shutdown(
        boost::asio::ssl::detail::engine *this,
        void *a2,
        size_t a3)
{
  int result; // eax
  __int64 v4; // rdx

  result = SSL_shutdown(this->ssl_, a2, a3);
  if ( !result )
    return SSL_shutdown(this->ssl_, a2, v4);
  return result;
}


// Address: 0x2612b80 | Name: _ZN5boost4asio3ssl6detail6engine5writeERKNS0_12const_bufferERNS_6system10error_codeERm
boost::asio::ssl::detail::engine::want __fastcall boost::asio::ssl::detail::engine::write(
        boost::asio::ssl::detail::engine *this,
        const boost::asio::const_buffer *data,
        boost::system::error_code *ec,
        size_t *bytes_transferred)
{
  size_t size; // rbp
  const void *v8; // r12
  SSL *ssl; // rdi
  __int64 v10; // rdx
  __int64 v11; // rbp
  int error; // r12d
  int v13; // r13d
  unsigned __int64 v14; // rax
  void (__fastcall ***v15)(boost::system::error_category *__hidden); // rax
  const boost::system::error_category *v16; // rax
  const boost::system::error_category *v18; // rax
  const boost::system::error_category *v19; // rax
  unsigned __int64 v20; // [rsp+0h] [rbp-38h]

  size = data->size_;
  if ( !size )
  {
LABEL_18:
    v15 = (void (__fastcall ***)(boost::system::error_category *__hidden))boost::system::system_category();
    ec->m_val = 0;
    goto LABEL_19;
  }
  v8 = data->data_;
  v20 = BIO_ctrl_pending(this->ext_bio_);
  ssl = this->ssl_;
  v10 = 0x7FFFFFFF;
  if ( size < 0x7FFFFFFF )
    v10 = (unsigned int)size;
  v11 = (unsigned int)SSL_write(ssl, v8, v10);
  error = SSL_get_error(this->ssl_, v11);
  v13 = ERR_get_error();
  v14 = BIO_ctrl_pending(this->ext_bio_);
  if ( error != 5 )
  {
    if ( error == 1 )
    {
      if ( !(_BYTE)byte_2B114E8 )
      {
        if ( __cxa_guard_acquire(&byte_2B114E8) )
          __cxa_guard_release(&byte_2B114E8);
      }
      ec->m_val = v13;
      v15 = off_2870A10;
      goto LABEL_19;
    }
    if ( (int)v11 > 0 )
      *bytes_transferred = (int)v11;
    if ( error == 3 )
    {
      v16 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v16;
      return boost::asio::ssl::detail::engine::want::want_output_and_retry;
    }
    if ( v14 > v20 )
    {
      v18 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v18;
      return 2 * ((int)v11 > 0) - 1;
    }
    if ( error == 2 )
    {
      v19 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v19;
      return boost::asio::ssl::detail::engine::want::want_input_and_retry;
    }
    if ( (SSL_get_shutdown(this->ssl_) & 2) != 0 )
    {
      if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
        __cxa_guard_release(&byte_2B114E0);
      ec->m_val = 2;
      v15 = off_2870A08;
      goto LABEL_19;
    }
    goto LABEL_18;
  }
  v15 = (void (__fastcall ***)(boost::system::error_category *__hidden))boost::system::system_category();
  ec->m_val = v13;
LABEL_19:
  ec->m_cat = (const boost::system::error_category *)v15;
  return boost::asio::ssl::detail::engine::want::want_nothing;
}


// Address: 0x2616710 | Name: _ZN5boost4asio3ssl6detail6engine4readERKNS0_14mutable_bufferERNS_6system10error_codeERm
boost::asio::ssl::detail::engine::want __fastcall boost::asio::ssl::detail::engine::read(
        boost::asio::ssl::detail::engine *this,
        const boost::asio::mutable_buffer *data,
        boost::system::error_code *ec,
        size_t *bytes_transferred)
{
  size_t size; // rbp
  void *v8; // r12
  SSL *ssl; // rdi
  __int64 v10; // rdx
  __int64 v11; // rbp
  int error; // r12d
  int v13; // r13d
  unsigned __int64 v14; // rax
  void (__fastcall ***v15)(boost::system::error_category *__hidden); // rax
  const boost::system::error_category *v16; // rax
  const boost::system::error_category *v18; // rax
  const boost::system::error_category *v19; // rax
  unsigned __int64 v20; // [rsp+0h] [rbp-38h]

  size = data->size_;
  if ( !size )
  {
LABEL_18:
    v15 = (void (__fastcall ***)(boost::system::error_category *__hidden))boost::system::system_category();
    ec->m_val = 0;
    goto LABEL_19;
  }
  v8 = data->data_;
  v20 = BIO_ctrl_pending(this->ext_bio_);
  ssl = this->ssl_;
  v10 = 0x7FFFFFFF;
  if ( size < 0x7FFFFFFF )
    v10 = (unsigned int)size;
  v11 = (unsigned int)SSL_read(ssl, v8, v10);
  error = SSL_get_error(this->ssl_, v11);
  v13 = ERR_get_error();
  v14 = BIO_ctrl_pending(this->ext_bio_);
  if ( error != 5 )
  {
    if ( error == 1 )
    {
      if ( !(_BYTE)byte_2B114E8 )
      {
        if ( __cxa_guard_acquire(&byte_2B114E8) )
          __cxa_guard_release(&byte_2B114E8);
      }
      ec->m_val = v13;
      v15 = off_2870A10;
      goto LABEL_19;
    }
    if ( (int)v11 > 0 )
      *bytes_transferred = (int)v11;
    if ( error == 3 )
    {
      v16 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v16;
      return boost::asio::ssl::detail::engine::want::want_output_and_retry;
    }
    if ( v14 > v20 )
    {
      v18 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v18;
      return 2 * ((int)v11 > 0) - 1;
    }
    if ( error == 2 )
    {
      v19 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v19;
      return boost::asio::ssl::detail::engine::want::want_input_and_retry;
    }
    if ( (SSL_get_shutdown(this->ssl_) & 2) != 0 )
    {
      if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
        __cxa_guard_release(&byte_2B114E0);
      ec->m_val = 2;
      v15 = off_2870A08;
      goto LABEL_19;
    }
    goto LABEL_18;
  }
  v15 = (void (__fastcall ***)(boost::system::error_category *__hidden))boost::system::system_category();
  ec->m_val = v13;
LABEL_19:
  ec->m_cat = (const boost::system::error_category *)v15;
  return boost::asio::ssl::detail::engine::want::want_nothing;
}


// Address: 0x261a750 | Name: _ZN5boost4asio3ssl6detail6engineC2EP10ssl_ctx_st
void __fastcall boost::asio::ssl::detail::engine::engine(boost::asio::ssl::detail::engine *this, SSL_CTX *context)
{
  SSL *ssl; // rax
  int error; // r14d
  _QWORD v4[2]; // [rsp+8h] [rbp-50h] BYREF
  int v5; // [rsp+18h] [rbp-40h]
  void (__fastcall ***v6)(boost::system::error_category *__hidden); // [rsp+20h] [rbp-38h]
  __int128 v7; // [rsp+28h] [rbp-30h]
  void *ptr; // [rsp+38h] [rbp-20h]

  ssl = (SSL *)SSL_new(context);
  this->ssl_ = ssl;
  if ( !ssl )
  {
    error = ERR_get_error();
    if ( (_BYTE)byte_2B114E8 || !__cxa_guard_acquire(&byte_2B114E8) )
    {
      if ( error )
        goto LABEL_8;
    }
    else
    {
      __cxa_guard_release(&byte_2B114E8);
      if ( error )
      {
LABEL_8:
        std::runtime_error::runtime_error((std::runtime_error *)v4, "engine");
        v4[0] = off_2875F00;
        v5 = error;
        v6 = off_2870A10;
        v7 = 0;
        ptr = 0;
        boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v4);
      }
    }
    ssl = this->ssl_;
  }
  SSL_ctrl(ssl, 33, 1, 0);
  SSL_ctrl(this->ssl_, 33, 2, 0);
  SSL_ctrl(this->ssl_, 33, 16, 0);
  v4[0] = 0;
  BIO_new_bio_pair(v4, 0, &this->ext_bio_, 0);
  SSL_set_bio(this->ssl_, v4[0], v4[0]);
}


// Address: 0x26325e0 | Name: _ZN5boost4asio3ssl6detail6engine10do_connectEPvm
int __fastcall boost::asio::ssl::detail::engine::do_connect(
        boost::asio::ssl::detail::engine *this,
        void *a2,
        size_t a3)
{
  return SSL_connect(this->ssl_, a2, a3);
}


// Address: 0x26325f0 | Name: _ZN5boost4asio3ssl6detail6engine9do_acceptEPvm
int __fastcall boost::asio::ssl::detail::engine::do_accept(boost::asio::ssl::detail::engine *this, void *a2, size_t a3)
{
  int v3; // ebx

  pthread_mutex_lock(&stru_2B128D8);
  v3 = SSL_accept(this->ssl_, a2);
  pthread_mutex_unlock(&stru_2B128D8);
  return v3;
}


// Address: 0x26a8600 | Name: _ZN5boost4asio3ssl6detail6engine24verify_callback_functionEiP17x509_store_ctx_st
int __fastcall boost::asio::ssl::detail::engine::verify_callback_function(int preverified, X509_STORE_CTX *ctx)
{
  X509_STORE_CTX *v2; // rax
  int v3; // ebp
  unsigned int v4; // eax
  __int64 v5; // rax
  __int64 v6; // r15
  __int64 v7; // rax
  X509_STORE_CTX *v9; // [rsp+0h] [rbp-28h] BYREF

  v9 = v2;
  v3 = 0;
  if ( ctx )
  {
    v4 = SSL_get_ex_data_X509_STORE_CTX_idx(preverified);
    v5 = X509_STORE_CTX_get_ex_data(ctx, v4);
    if ( v5 )
    {
      v6 = v5;
      v3 = 0;
      if ( SSL_get_ex_data(v5, 0) )
      {
        v7 = SSL_get_ex_data(v6, 0);
        v9 = ctx;
        return (*(unsigned __int8 (__fastcall **)(__int64, bool, X509_STORE_CTX **))(*(_QWORD *)v7 + 16LL))(
                 v7,
                 preverified != 0,
                 &v9);
      }
    }
  }
  return v3;
}


