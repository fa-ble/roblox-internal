// Address: 0x2029880 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE7seekoffExNS5_8ios_base7seekdirEj
// attributes: thunk
boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::pos_type __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::seekoff(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this,
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::off_type off,
        std::ios_base::seekdir way,
        std::ios_base::openmode which)
{
  return boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::seek_impl(
           this,
           off,
           way,
           which);
}


// Address: 0x2029890 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE7seekposENS5_4fposI11__mbstate_tEEj
boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::pos_type __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::seekpos(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this,
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::pos_type sp,
        std::ios_base::openmode which)
{
  return boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::seek_impl(
           this,
           sp.__off_,
           std::__1::ios_base::seekdir::beg,
           which);
}


// Address: 0x20298a0 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE9underflowEv
boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::int_type __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::underflow(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this)
{
  unsigned __int8 *v1; // rcx
  unsigned __int8 *v2; // rdx
  unsigned __int8 *v4; // rax
  unsigned __int8 *v5; // rdx
  __int64 v6; // rsi
  std::error_code v7; // [rsp+0h] [rbp-38h] BYREF
  _BYTE v8[40]; // [rsp+10h] [rbp-28h] BYREF

  v1 = (unsigned __int8 *)*((_QWORD *)this + 12);
  if ( !v1 )
  {
    v7.__val_ = 1;
    v7.__cat_ = (const std::error_category *)std::iostream_category();
    std::ios_base::failure::failure((std::ios_base::failure *)v8, "no read access", &v7);
    boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v8);
  }
  v2 = (unsigned __int8 *)*((_QWORD *)this + 3);
  if ( v2 )
  {
    if ( v2 != *((unsigned __int8 **)this + 13) )
      return *v2;
  }
  else
  {
    v4 = (unsigned __int8 *)*((_QWORD *)this + 13);
    v5 = (unsigned __int8 *)*((_QWORD *)this + 14);
    *((_QWORD *)this + 2) = v1;
    *((_QWORD *)this + 3) = v1;
    *((_QWORD *)this + 4) = v4;
    if ( v1 == v5 )
    {
      v6 = *((_QWORD *)this + 6);
      if ( v6 )
      {
        v1 += (int)v6 - (int)v5;
        *((_QWORD *)this + 3) = v1;
        *(_OWORD *)((char *)this + 40) = 0;
        *((_QWORD *)this + 7) = 0;
      }
    }
    v2 = v1;
    if ( v1 != v4 )
      return *v2;
  }
  return -1;
}


// Address: 0x2029960 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE9pbackfailEi
boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::int_type __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::pbackfail(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this,
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::int_type c)
{
  __int64 v2; // rcx
  __int64 v3; // rax
  _BYTE *v4; // rax
  boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::int_type result; // eax
  std::error_code v6; // [rsp+0h] [rbp-38h] BYREF
  _BYTE v7[40]; // [rsp+10h] [rbp-28h] BYREF

  v2 = *((_QWORD *)this + 12);
  if ( !v2 )
  {
    v6.__val_ = 1;
    v6.__cat_ = (const std::error_category *)std::iostream_category();
    std::ios_base::failure::failure((std::ios_base::failure *)v7, "no read access", &v6);
    boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v7);
  }
  v3 = *((_QWORD *)this + 3);
  if ( !v3 || v3 == v2 )
  {
    v6.__val_ = 1;
    v6.__cat_ = (const std::error_category *)std::iostream_category();
    std::ios_base::failure::failure((std::ios_base::failure *)v7, "putback buffer full", &v6);
    boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v7);
  }
  v4 = (_BYTE *)(v3 - 1);
  *((_QWORD *)this + 3) = v4;
  if ( c != -1 )
    *v4 = c;
  result = 0;
  if ( c != -1 )
    return c;
  return result;
}


// Address: 0x2029a20 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE8overflowEi
boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::int_type __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::overflow(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this,
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::int_type c)
{
  _BYTE *v2; // rax
  _BYTE *v3; // rcx
  _BYTE *v4; // rcx
  __int64 v5; // rdx
  __int64 v6; // rdx
  std::error_code v8; // [rsp+0h] [rbp-38h] BYREF
  _BYTE v9[40]; // [rsp+10h] [rbp-28h] BYREF

  v2 = (_BYTE *)*((_QWORD *)this + 14);
  if ( !v2 )
  {
    v8.__val_ = 1;
    v8.__cat_ = (const std::error_category *)std::iostream_category();
    std::ios_base::failure::failure((std::ios_base::failure *)v9, "no write access", &v8);
    boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v9);
  }
  v3 = (_BYTE *)*((_QWORD *)this + 6);
  if ( !v3 )
  {
    v4 = (_BYTE *)*((_QWORD *)this + 12);
    v5 = *((_QWORD *)this + 15);
    *((_QWORD *)this + 6) = v2;
    *((_QWORD *)this + 5) = v2;
    *((_QWORD *)this + 7) = v5;
    if ( v4 )
    {
      if ( v4 == v2 )
      {
        v6 = *((_QWORD *)this + 3);
        if ( v6 )
        {
          v2 += (int)v6 - (int)v4;
          *((_QWORD *)this + 6) = v2;
          *((_OWORD *)this + 1) = 0;
          *((_QWORD *)this + 4) = 0;
        }
      }
    }
    v3 = v2;
    if ( c != -1 )
      goto LABEL_4;
    return 0;
  }
  if ( c == -1 )
    return 0;
LABEL_4:
  if ( v3 == *((_BYTE **)this + 15) )
  {
    v8.__val_ = 1;
    v8.__cat_ = (const std::error_category *)std::iostream_category();
    std::ios_base::failure::failure((std::ios_base::failure *)v9, "write area exhausted", &v8);
    boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v9);
  }
  *v3 = c;
  ++*((_QWORD *)this + 6);
  return c;
}


// Address: 0x2029b30 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE10close_implEj
void __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::close_impl(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this,
        std::ios_base::openmode which)
{
  char *v2; // rax
  __int128 v3; // xmm0

  if ( which == 16 )
  {
    if ( !*((_QWORD *)this + 14) )
      return;
    (*(void (__fastcall **)(boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *))(*(_QWORD *)this + 48LL))(this);
    v3 = 0;
    *(_OWORD *)((char *)this + 40) = 0;
    *((_QWORD *)this + 7) = 0;
    v2 = (char *)this + 112;
    goto LABEL_7;
  }
  if ( which == 8 && *((_QWORD *)this + 12) )
  {
    v2 = (char *)this + 96;
    v3 = 0;
    *((_OWORD *)this + 1) = 0;
    *((_QWORD *)this + 4) = 0;
LABEL_7:
    *(_OWORD *)v2 = v3;
  }
}


// Address: 0x2029b90 | Name: _ZNK5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE10auto_closeEv
bool __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::auto_close(
        const boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this)
{
  return *((_BYTE *)this + 128);
}


// Address: 0x2029ba0 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE14set_auto_closeEb
void __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::set_auto_close(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this,
        bool close)
{
  *((_BYTE *)this + 128) = close;
}


// Address: 0x2029bb0 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE11strict_syncEv
bool __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::strict_sync(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this)
{
  return 1;
}


// Address: 0x2029bc0 | Name: _ZNK5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE14component_typeEv
const std::type_info *__fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::component_type(
        const boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this)
{
  return (const std::type_info *)&`typeinfo for'boost::iostreams::basic_array_source<char>;
}


// Address: 0x2029bd0 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE14component_implEv
void *__fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::component_impl(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this)
{
  return (char *)this + 72;
}


// Address: 0x2029ce0 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEED2Ev
void __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::~direct_streambuf(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this)
{
  *(_QWORD *)this = &off_29A6BE8;
  if ( *((_BYTE *)this + 88) )
    *((_BYTE *)this + 88) = 0;
  std::streambuf::~streambuf();
}


// Address: 0x2029d00 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEED0Ev
void __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::~direct_streambuf(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this)
{
  *(_QWORD *)this = &off_29A6BE8;
  if ( *((_BYTE *)this + 88) )
    *((_BYTE *)this + 88) = 0;
  std::streambuf::~streambuf();
  operator delete(this);
}


// Address: 0x2029d30 | Name: _ZN5boost9iostreams6detail16direct_streambufINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEEE9seek_implElNS5_8ios_base7seekdirEj
boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::pos_type __fastcall boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char>>::seek_impl(
        boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> > *this,
        boost::iostreams::stream_offset off,
        std::ios_base::seekdir way,
        std::ios_base::openmode which)
{
  __int64 v4; // r10
  boost::iostreams::stream_offset v5; // r8
  __int64 v6; // rbx
  char v7; // r9
  __int64 v8; // rbx
  __int64 v9; // rax
  __int64 v10; // rcx
  __int64 v11; // rcx
  __int64 v12; // r8
  __int64 v13; // rax
  __int64 v14; // rax
  __int64 v15; // rbx
  __int64 v17; // rax
  std::error_code v18; // [rsp+0h] [rbp-38h] BYREF
  _BYTE v19[40]; // [rsp+10h] [rbp-28h] BYREF
  boost::iostreams::detail::direct_streambuf<boost::iostreams::basic_array_source<char>,std::char_traits<char> >::pos_type result; // 0:rax.16

  v4 = *((_QWORD *)this + 12);
  v5 = -1;
  if ( !v4 )
  {
    v7 = 0;
    goto LABEL_10;
  }
  v6 = *((_QWORD *)this + 14);
  if ( (which & 0x18) == 0x18 && v4 != v6 && v6 )
  {
    v18.__val_ = 1;
    v18.__cat_ = (const std::error_category *)std::iostream_category();
    std::ios_base::failure::failure((std::ios_base::failure *)v19, "bad seek", &v18);
    boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v19);
  }
  if ( v4 != v6 )
  {
    v7 = 0;
    if ( (which & 8) != 0 )
    {
      v8 = *((_QWORD *)this + 3);
      v7 = 0;
      if ( v8 )
        goto LABEL_24;
LABEL_21:
      v14 = *((_QWORD *)this + 13);
      *((_QWORD *)this + 2) = v4;
      *((_QWORD *)this + 3) = v4;
      *((_QWORD *)this + 4) = v14;
LABEL_22:
      v8 = v4;
      goto LABEL_24;
    }
LABEL_10:
    if ( (which & 0x10) == 0 )
      goto LABEL_42;
LABEL_11:
    if ( v7 )
      goto LABEL_42;
    v9 = *((_QWORD *)this + 14);
    if ( !v9 )
      goto LABEL_42;
    v10 = *((_QWORD *)this + 6);
    if ( !v10 )
    {
      v11 = *((_QWORD *)this + 15);
      *((_QWORD *)this + 6) = v9;
      *((_QWORD *)this + 5) = v9;
      *((_QWORD *)this + 7) = v11;
      v10 = v9;
    }
    if ( way )
    {
      if ( way == std::__1::ios_base::seekdir::end )
      {
        off = *((_QWORD *)this + 15) + off - v9;
      }
      else
      {
        if ( way != std::__1::ios_base::seekdir::cur )
        {
          v5 = 0;
LABEL_40:
          if ( v5 <= *((_QWORD *)this + 15) - v9 )
          {
            *((_QWORD *)this + 6) = v10 + (int)v5 + (int)v9 - (int)v10;
            goto LABEL_42;
          }
LABEL_46:
          v18.__val_ = 1;
          v18.__cat_ = (const std::error_category *)std::iostream_category();
          std::ios_base::failure::failure((std::ios_base::failure *)v19, "bad seek", &v18);
          boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v19);
        }
        off = off + v10 - v9;
      }
    }
    v5 = off;
    if ( off < 0 )
      goto LABEL_46;
    goto LABEL_40;
  }
  v12 = *((_QWORD *)this + 6);
  if ( v12 )
  {
    v13 = *((_QWORD *)this + 13);
    *((_QWORD *)this + 2) = v4;
    *((_QWORD *)this + 3) = v4;
    *((_QWORD *)this + 4) = v13;
    v8 = v4 + (int)v12 - (int)v4;
    *((_QWORD *)this + 3) = v8;
    *(_OWORD *)((char *)this + 40) = 0;
    *((_QWORD *)this + 7) = 0;
    v7 = 1;
    if ( v8 )
      goto LABEL_24;
    goto LABEL_21;
  }
  v8 = *((_QWORD *)this + 3);
  v7 = 1;
  if ( !v8 )
  {
    v17 = *((_QWORD *)this + 13);
    *((_QWORD *)this + 2) = v4;
    *((_QWORD *)this + 3) = v4;
    *((_QWORD *)this + 4) = v17;
    goto LABEL_22;
  }
LABEL_24:
  v5 = off;
  if ( way )
  {
    if ( way != std::__1::ios_base::seekdir::end )
    {
      if ( way == std::__1::ios_base::seekdir::cur )
      {
        v5 = off + v8 - v4;
        if ( v5 < 0 )
          goto LABEL_44;
      }
      else
      {
        v5 = 0;
      }
      goto LABEL_33;
    }
    v5 = off + *((_QWORD *)this + 13) - v4;
  }
  if ( v5 < 0 )
  {
LABEL_44:
    v18.__val_ = 1;
    v18.__cat_ = (const std::error_category *)std::iostream_category();
    std::ios_base::failure::failure((std::ios_base::failure *)v19, "bad seek", &v18);
    boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v19);
  }
LABEL_33:
  v15 = *((_QWORD *)this + 13);
  if ( v5 > v15 - v4 )
    goto LABEL_44;
  *((_QWORD *)this + 2) = v4;
  *((_QWORD *)this + 3) = v5 + v4;
  *((_QWORD *)this + 4) = v15;
  if ( (which & 0x10) != 0 )
    goto LABEL_11;
LABEL_42:
  result.__st_ = 0;
  result.__off_ = v5;
  return result;
}


