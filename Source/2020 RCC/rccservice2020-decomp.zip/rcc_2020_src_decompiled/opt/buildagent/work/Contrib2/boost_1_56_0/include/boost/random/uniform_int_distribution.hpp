// Address: 0x12832d0 | Name: _ZN5boost6random6detail20generate_uniform_intINS0_23mersenne_twister_engineIjLm32ELm624ELm397ELm31ELj2567483615ELm11ELj4294967295ELm7ELj2636928640ELm15ELj4022730752ELm18ELj1812433253EEEmEET0_RT_S5_S5_N4mpl_5bool_ILb1EEE
unsigned __int64 __fastcall boost::random::detail::generate_uniform_int<boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>,unsigned long>(
        boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> *eng,
        unsigned __int64 min_value,
        unsigned __int64 max_value,
        mpl_::true_ a4)
{
  unsigned __int64 v4; // r14
  unsigned __int64 v5; // r15
  size_t i; // rax
  unsigned int v7; // ecx
  unsigned int v8; // ecx
  unsigned __int64 v9; // rcx
  unsigned __int64 v10; // r13
  size_t v11; // rax
  unsigned __int64 v12; // r14
  __int64 v13; // rbp
  unsigned int v14; // ecx
  unsigned int v15; // ecx
  unsigned __int64 v16; // rcx
  bool v17; // cf
  size_t v18; // rcx
  unsigned int v19; // eax
  unsigned int v20; // eax
  unsigned int v21; // eax

  v4 = min_value;
  v5 = max_value - min_value;
  if ( max_value != min_value )
  {
    if ( v5 == 0xFFFFFFFF )
    {
      i = eng->i;
      if ( i == 624 )
      {
        boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>::twist(eng);
        i = eng->i;
      }
      v7 = eng->x[i];
      eng->i = i + 1;
      v8 = v7 ^ (v7 >> 11) ^ ((v7 ^ (v7 >> 11)) << 7) & 0x9D2C5680;
      return (v8 ^ (v8 << 15) & 0xEFC60000 ^ ((v8 ^ (v8 << 15) & 0xEFC60000) >> 18)) + min_value;
    }
    else if ( HIDWORD(v5) )
    {
      v9 = (_DWORD)v5 == -1;
      v10 = (v5 + 1) >> 32;
      if ( v5 == -1 )
        v10 = v9 + 0xFFFFFFFF;
      while ( !v10 )
      {
        v13 = 0;
        v12 = 1;
LABEL_17:
        v9 = boost::random::detail::generate_uniform_int<boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>,unsigned long>(
               eng,
               0,
               v5 / v12,
               (mpl_::true_)v9);
        if ( 0xFFFFFFFFFFFFFFFFLL / v12 >= v9 )
        {
          v16 = v12 * v9;
          v17 = __CFADD__(v13, v16);
          v9 = v13 + v16;
          if ( !v17 && v9 <= v5 )
            return v9 + min_value;
        }
      }
      v11 = eng->i;
      v12 = 1;
      v13 = 0;
      while ( 1 )
      {
        if ( v11 == 624 )
        {
          boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>::twist(eng);
          v11 = eng->i;
        }
        v14 = eng->x[v11++];
        eng->i = v11;
        v15 = v14 ^ (v14 >> 11) ^ ((v14 ^ (v14 >> 11)) << 7) & 0x9D2C5680;
        v9 = v12 * (v15 ^ (v15 << 15) & 0xEFC60000 ^ ((v15 ^ (v15 << 15) & 0xEFC60000) >> 18));
        v13 += v9;
        v12 <<= 32;
        if ( v12 == v5 + 1 )
          return v13;
        if ( v12 > v10 )
          goto LABEL_17;
      }
    }
    else
    {
      v18 = eng->i;
      do
      {
        if ( v18 == 624 )
        {
          boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>::twist(eng);
          v18 = eng->i;
        }
        v19 = eng->x[v18++];
        eng->i = v18;
        v20 = v19 ^ (v19 >> 11) ^ ((v19 ^ (v19 >> 11)) << 7) & 0x9D2C5680;
        v21 = (v20 ^ (v20 << 15) & 0xEFC60000 ^ (unsigned __int64)((v20 ^ (v20 << 15) & 0xEFC60000) >> 18))
            / (0xFFFFFFFF / ((int)v5 + 1) + (0xFFFFFFFF % ((int)v5 + 1) == (_DWORD)v5));
      }
      while ( v21 > (unsigned int)v5 );
      return v21 + min_value;
    }
  }
  return v4;
}


