// Address: 0xf126d0 | Name: _ZNK3RBX7Network9ItemQueue4sizeEv
size_t __fastcall RBX::Network::ItemQueue::size(const RBX::Network::ItemQueue *this)
{
  return this->itemList.data_.root_plus_size_.size_;
}


