// Address: 0x1036120 | Name: _ZN5boost15recursive_mutexC2Ev
void __fastcall boost::recursive_mutex::recursive_mutex(boost::recursive_mutex *this)
{
  int v1; // eax
  int v2; // eax
  int v3; // ebx
  int v4; // ebp
  const boost::system::error_category *v5; // rbx
  int v6; // ebp
  const boost::system::error_category *v7; // rbx
  const boost::system::error_category *v8; // rbp
  pthread_mutexattr_t v9; // [rsp+0h] [rbp-58h] BYREF
  _QWORD v10[2]; // [rsp+8h] [rbp-50h] BYREF
  int v11; // [rsp+18h] [rbp-40h]
  const boost::system::error_category *v12; // [rsp+20h] [rbp-38h]
  __int128 v13; // [rsp+28h] [rbp-30h]
  void *ptr; // [rsp+38h] [rbp-20h]

  v1 = pthread_mutexattr_init(&v9);
  if ( v1 )
  {
    v4 = v1;
    v5 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)v10,
      "boost:: recursive_mutex constructor failed in pthread_mutexattr_init");
    v11 = v4;
    v12 = v5;
    v13 = 0;
    ptr = 0;
    v10[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v10);
  }
  v2 = pthread_mutexattr_settype(&v9, 1);
  if ( v2 )
  {
    v6 = v2;
    pthread_mutexattr_destroy(&v9);
    v7 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)v10,
      "boost:: recursive_mutex constructor failed in pthread_mutexattr_settype");
    v11 = v6;
    v12 = v7;
    v13 = 0;
    ptr = 0;
    v10[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v10);
  }
  v3 = pthread_mutex_init(&this->m, &v9);
  pthread_mutexattr_destroy(&v9);
  if ( v3 )
  {
    v8 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)v10,
      "boost:: recursive_mutex constructor failed in pthread_mutex_init");
    v11 = v3;
    v12 = v8;
    v13 = 0;
    ptr = 0;
    v10[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v10);
  }
}


// Address: 0x12138c0 | Name: _ZN5boost15recursive_mutexD2Ev
// Alternative name is 'j_.pthread_mutex_destroy_0'
// attributes: thunk
void __fastcall boost::recursive_mutex::~recursive_mutex(boost::recursive_mutex *this)
{
  pthread_mutex_destroy(&this->m);
}


