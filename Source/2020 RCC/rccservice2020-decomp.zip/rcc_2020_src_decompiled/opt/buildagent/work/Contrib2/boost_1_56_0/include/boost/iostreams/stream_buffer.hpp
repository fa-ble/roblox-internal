// Address: 0x20297a0 | Name: _ZN5boost9iostreams13stream_bufferINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS4_9allocatorIcEENS0_14input_seekableEED2Ev
// local variable allocation has failed, the output may be wrong!
void __fastcall boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer(
        boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable> *this)
{
  int v1; // esi
  boost::iostreams::detail::member_close_operation<boost::iostreams::detail::linked_streambuf<char,std::char_traits<char> > > v2; // 0:rdx.12

  *(_QWORD *)this = &off_29A6AD8;
  if ( *((_QWORD *)this + 12) || *((_QWORD *)this + 14) )
  {
    if ( *((_BYTE *)this + 128) )
    {
      v1 = 8;
      v2.which_ = 16;
      v2.t_ = this;
      boost::iostreams::detail::execute_all<boost::iostreams::detail::member_close_operation<boost::iostreams::detail::linked_streambuf<char,std::char_traits<char>>>,boost::iostreams::detail::member_close_operation<boost::iostreams::detail::linked_streambuf<char,std::char_traits<char>>>>(
        *(boost::iostreams::detail::member_close_operation<boost::iostreams::detail::linked_streambuf<char,std::char_traits<char> > > *)&this,
        v2);
      if ( *((_BYTE *)this + 88) )
        *((_BYTE *)this + 88) = 0;
    }
  }
  *(_QWORD *)this = &off_29A6BE8;
  if ( *((_BYTE *)this + 88) )
    *((_BYTE *)this + 88) = 0;
  std::streambuf::~streambuf();
}


// Address: 0x2029860 | Name: _ZN5boost9iostreams13stream_bufferINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS4_9allocatorIcEENS0_14input_seekableEED0Ev
void __fastcall boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer(
        boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable> *this)
{
  boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::~stream_buffer(this);
  operator delete(this);
}


// Address: 0x202a740 | Name: _ZN5boost9iostreams13stream_bufferINS0_18basic_array_sourceIcEENSt3__111char_traitsIcEENS4_9allocatorIcEENS0_14input_seekableEE9open_implERKS3_ll
void __fastcall boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable>::open_impl(
        boost::iostreams::stream_buffer<boost::iostreams::basic_array_source<char>,std::char_traits<char>,std::allocator<char>,boost::iostreams::input_seekable> *this,
        const boost::iostreams::basic_array_source<char> *t,
        std::streamsize buffer_size,
        std::streamsize pback_size)
{
  std::error_code v4; // [rsp+0h] [rbp-38h] BYREF
  _BYTE v5[40]; // [rsp+10h] [rbp-28h] BYREF

  if ( *((_QWORD *)this + 12) || *((_QWORD *)this + 14) )
  {
    v4.__val_ = 1;
    v4.__cat_ = (const std::error_category *)std::iostream_category();
    std::ios_base::failure::failure((std::ios_base::failure *)v5, "already open", &v4);
    boost::throw_exception<std::ios_base::failure>((const std::ios_base::failure *)v5);
  }
  if ( *((_BYTE *)this + 88) )
    *((_BYTE *)this + 88) = 0;
  *(boost::iostreams::basic_array_source<char> *)((char *)this + 72) = *t;
  *((_BYTE *)this + 88) = 1;
  *((_OWORD *)this + 6) = *(_OWORD *)((char *)this + 72);
  *((_OWORD *)this + 3) = 0;
  *((_OWORD *)this + 2) = 0;
  *((_OWORD *)this + 1) = 0;
  *((_BYTE *)this + 64) &= 0xF9u;
}


