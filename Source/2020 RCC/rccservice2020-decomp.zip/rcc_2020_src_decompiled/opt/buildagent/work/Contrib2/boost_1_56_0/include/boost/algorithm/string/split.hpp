// Address: 0xfe6200 | Name: _ZN5boost9algorithm5splitINSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEEKS9_NS0_6detail10is_any_ofFIcEEEERT_SH_RT0_T1_NS0_24token_compress_mode_typeE
std::vector<std::string> *__fastcall boost::algorithm::split<std::vector<std::string>,std::string const,boost::algorithm::detail::is_any_ofF<char>>(
        std::vector<std::string> *Result,
        const std::string *Input,
        _QWORD *eCompress,
        int a4)
{
  _QWORD *v5; // rbx
  size_t v8; // rbp
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *p_src; // rdi
  size_t m_Size; // r13
  void *v11; // rdi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  size_t v13; // rbp
  void *v14; // rbx
  std::vector<std::string> *v15; // rbp
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > src; // [rsp+0h] [rbp-88h] BYREF
  size_t v18; // [rsp+28h] [rbp-60h]
  int v19; // [rsp+30h] [rbp-58h]
  void *ptr[2]; // [rsp+38h] [rbp-50h] BYREF
  size_t n; // [rsp+48h] [rbp-40h]
  unsigned __int64 v22; // [rsp+50h] [rbp-38h]

  v5 = eCompress;
  v22 = __readfsqword(0x28u);
  v8 = eCompress[2];
  src.m_Pred.m_Size = v8;
  src.m_Pred.m_Storage.m_dynSet = 0;
  if ( v8 > 0x10 )
  {
    p_src = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)operator new[](v8);
    src.m_Pred.m_Storage.m_dynSet = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)p_src;
    v5 = (_QWORD *)*v5;
  }
  else
  {
    p_src = &src;
  }
  memcpy(p_src, v5, v8);
  m_Size = src.m_Pred.m_Size;
  n = src.m_Pred.m_Size;
  ptr[0] = 0;
  if ( src.m_Pred.m_Size > 0x10 )
  {
    v11 = operator new[](src.m_Pred.m_Size);
    ptr[0] = v11;
    m_dynSet = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)src.m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    v11 = ptr;
    m_dynSet = &src;
  }
  memcpy(v11, m_dynSet, m_Size);
  v13 = n;
  v18 = n;
  *(_QWORD *)&src.m_eCompress = 0;
  if ( n > 0x10 )
  {
    *(_QWORD *)&src.m_eCompress = operator new[](n);
    v14 = ptr[0];
    memcpy(*(void **)&src.m_eCompress, ptr[0], v13);
    v19 = a4;
    if ( v14 )
      operator delete[](v14);
  }
  else
  {
    memcpy(&src.m_eCompress, ptr, n);
    v19 = a4;
  }
  v15 = boost::algorithm::iter_split<std::vector<std::string>,std::string const,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
          Result,
          Input,
          src);
  if ( v18 >= 0x11 && *(_QWORD *)&src.m_eCompress )
    operator delete[](*(void **)&src.m_eCompress);
  if ( m_Size >= 0x11 && src.m_Pred.m_Storage.m_dynSet )
    operator delete[](src.m_Pred.m_Storage.m_dynSet);
  return v15;
}


// Address: 0x1013ba0 | Name: _ZN5boost9algorithm5splitINSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEES9_NS0_6detail10is_any_ofFIcEEEERT_SG_RT0_T1_NS0_24token_compress_mode_typeE
std::vector<std::string> *__fastcall boost::algorithm::split<std::vector<std::string>,std::string,boost::algorithm::detail::is_any_ofF<char>>(
        std::vector<std::string> *Result,
        std::string *Input,
        _QWORD *eCompress,
        int a4)
{
  _QWORD *v5; // rbx
  size_t v8; // rbp
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *p_src; // rdi
  size_t m_Size; // r13
  void *v11; // rdi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  size_t v13; // rbp
  void *v14; // rbx
  std::vector<std::string> *v15; // rbp
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > src; // [rsp+0h] [rbp-88h] BYREF
  size_t v18; // [rsp+28h] [rbp-60h]
  int v19; // [rsp+30h] [rbp-58h]
  void *ptr[2]; // [rsp+38h] [rbp-50h] BYREF
  size_t n; // [rsp+48h] [rbp-40h]
  unsigned __int64 v22; // [rsp+50h] [rbp-38h]

  v5 = eCompress;
  v22 = __readfsqword(0x28u);
  v8 = eCompress[2];
  src.m_Pred.m_Size = v8;
  src.m_Pred.m_Storage.m_dynSet = 0;
  if ( v8 > 0x10 )
  {
    p_src = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)operator new[](v8);
    src.m_Pred.m_Storage.m_dynSet = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)p_src;
    v5 = (_QWORD *)*v5;
  }
  else
  {
    p_src = &src;
  }
  memcpy(p_src, v5, v8);
  m_Size = src.m_Pred.m_Size;
  n = src.m_Pred.m_Size;
  ptr[0] = 0;
  if ( src.m_Pred.m_Size > 0x10 )
  {
    v11 = operator new[](src.m_Pred.m_Size);
    ptr[0] = v11;
    m_dynSet = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)src.m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    v11 = ptr;
    m_dynSet = &src;
  }
  memcpy(v11, m_dynSet, m_Size);
  v13 = n;
  v18 = n;
  *(_QWORD *)&src.m_eCompress = 0;
  if ( n > 0x10 )
  {
    *(_QWORD *)&src.m_eCompress = operator new[](n);
    v14 = ptr[0];
    memcpy(*(void **)&src.m_eCompress, ptr[0], v13);
    v19 = a4;
    if ( v14 )
      operator delete[](v14);
  }
  else
  {
    memcpy(&src.m_eCompress, ptr, n);
    v19 = a4;
  }
  v15 = boost::algorithm::iter_split<std::vector<std::string>,std::string,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
          Result,
          Input,
          src);
  if ( v18 >= 0x11 && *(_QWORD *)&src.m_eCompress )
    operator delete[](*(void **)&src.m_eCompress);
  if ( m_Size >= 0x11 && src.m_Pred.m_Storage.m_dynSet )
    operator delete[](src.m_Pred.m_Storage.m_dynSet);
  return v15;
}


// Address: 0x1014e40 | Name: _ZN5boost9algorithm5splitINSt3__13setINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_4lessIS9_EENS7_IS9_EEEEKS9_NS0_6detail10is_any_ofFIcEEEERT_SJ_RT0_T1_NS0_24token_compress_mode_typeE
std::set<std::string> *__fastcall boost::algorithm::split<std::set<std::string>,std::string const,boost::algorithm::detail::is_any_ofF<char>>(
        std::set<std::string> *Result,
        const std::string *Input,
        _QWORD *eCompress,
        int a4)
{
  _QWORD *v5; // rbx
  size_t v8; // rbp
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *p_src; // rdi
  size_t m_Size; // r13
  void *v11; // rdi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  size_t v13; // rbp
  void *v14; // rbx
  std::set<std::string> *v15; // rbp
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > src; // [rsp+0h] [rbp-88h] BYREF
  size_t v18; // [rsp+28h] [rbp-60h]
  int v19; // [rsp+30h] [rbp-58h]
  void *ptr[2]; // [rsp+38h] [rbp-50h] BYREF
  size_t n; // [rsp+48h] [rbp-40h]
  unsigned __int64 v22; // [rsp+50h] [rbp-38h]

  v5 = eCompress;
  v22 = __readfsqword(0x28u);
  v8 = eCompress[2];
  src.m_Pred.m_Size = v8;
  src.m_Pred.m_Storage.m_dynSet = 0;
  if ( v8 > 0x10 )
  {
    p_src = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)operator new[](v8);
    src.m_Pred.m_Storage.m_dynSet = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)p_src;
    v5 = (_QWORD *)*v5;
  }
  else
  {
    p_src = &src;
  }
  memcpy(p_src, v5, v8);
  m_Size = src.m_Pred.m_Size;
  n = src.m_Pred.m_Size;
  ptr[0] = 0;
  if ( src.m_Pred.m_Size > 0x10 )
  {
    v11 = operator new[](src.m_Pred.m_Size);
    ptr[0] = v11;
    m_dynSet = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)src.m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    v11 = ptr;
    m_dynSet = &src;
  }
  memcpy(v11, m_dynSet, m_Size);
  v13 = n;
  v18 = n;
  *(_QWORD *)&src.m_eCompress = 0;
  if ( n > 0x10 )
  {
    *(_QWORD *)&src.m_eCompress = operator new[](n);
    v14 = ptr[0];
    memcpy(*(void **)&src.m_eCompress, ptr[0], v13);
    v19 = a4;
    if ( v14 )
      operator delete[](v14);
  }
  else
  {
    memcpy(&src.m_eCompress, ptr, n);
    v19 = a4;
  }
  v15 = boost::algorithm::iter_split<std::set<std::string>,std::string const,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
          Result,
          Input,
          src);
  if ( v18 >= 0x11 && *(_QWORD *)&src.m_eCompress )
    operator delete[](*(void **)&src.m_eCompress);
  if ( m_Size >= 0x11 && src.m_Pred.m_Storage.m_dynSet )
    operator delete[](src.m_Pred.m_Storage.m_dynSet);
  return v15;
}


// Address: 0x110e610 | Name: _ZN5boost9algorithm5splitINSt3__16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEENS_16basic_string_refIcS6_EENS0_6detail10is_any_ofFIcEEEERT_SI_RT0_T1_NS0_24token_compress_mode_typeE
std::vector<std::string> *__fastcall boost::algorithm::split<std::vector<std::string>,boost::basic_string_ref<char,std::char_traits<char>>,boost::algorithm::detail::is_any_ofF<char>>(
        std::vector<std::string> *Result,
        boost::basic_string_ref<char,std::char_traits<char> > *Input,
        _QWORD *eCompress,
        int a4)
{
  _QWORD *v5; // rbx
  size_t v8; // rbp
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *p_src; // rdi
  size_t m_Size; // r13
  void *v11; // rdi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  size_t v13; // rbp
  void *v14; // rbx
  std::vector<std::string> *v15; // rbp
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > src; // [rsp+0h] [rbp-88h] BYREF
  size_t v18; // [rsp+28h] [rbp-60h]
  int v19; // [rsp+30h] [rbp-58h]
  void *ptr[2]; // [rsp+38h] [rbp-50h] BYREF
  size_t n; // [rsp+48h] [rbp-40h]
  unsigned __int64 v22; // [rsp+50h] [rbp-38h]

  v5 = eCompress;
  v22 = __readfsqword(0x28u);
  v8 = eCompress[2];
  src.m_Pred.m_Size = v8;
  src.m_Pred.m_Storage.m_dynSet = 0;
  if ( v8 > 0x10 )
  {
    p_src = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)operator new[](v8);
    src.m_Pred.m_Storage.m_dynSet = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)p_src;
    v5 = (_QWORD *)*v5;
  }
  else
  {
    p_src = &src;
  }
  memcpy(p_src, v5, v8);
  m_Size = src.m_Pred.m_Size;
  n = src.m_Pred.m_Size;
  ptr[0] = 0;
  if ( src.m_Pred.m_Size > 0x10 )
  {
    v11 = operator new[](src.m_Pred.m_Size);
    ptr[0] = v11;
    m_dynSet = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)src.m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    v11 = ptr;
    m_dynSet = &src;
  }
  memcpy(v11, m_dynSet, m_Size);
  v13 = n;
  v18 = n;
  *(_QWORD *)&src.m_eCompress = 0;
  if ( n > 0x10 )
  {
    *(_QWORD *)&src.m_eCompress = operator new[](n);
    v14 = ptr[0];
    memcpy(*(void **)&src.m_eCompress, ptr[0], v13);
    v19 = a4;
    if ( v14 )
      operator delete[](v14);
  }
  else
  {
    memcpy(&src.m_eCompress, ptr, n);
    v19 = a4;
  }
  v15 = boost::algorithm::iter_split<std::vector<std::string>,boost::basic_string_ref<char,std::char_traits<char>>,boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
          Result,
          Input,
          src);
  if ( v18 >= 0x11 && *(_QWORD *)&src.m_eCompress )
    operator delete[](*(void **)&src.m_eCompress);
  if ( m_Size >= 0x11 && src.m_Pred.m_Storage.m_dynSet )
    operator delete[](src.m_Pred.m_Storage.m_dynSet);
  return v15;
}


