// Address: 0x26059e0 | Name: _ZN5boost4asio6detail11noncopyableD2Ev
void __fastcall boost::asio::detail::noncopyable::~noncopyable(boost::asio::detail::noncopyable *this)
{
  ;
}


