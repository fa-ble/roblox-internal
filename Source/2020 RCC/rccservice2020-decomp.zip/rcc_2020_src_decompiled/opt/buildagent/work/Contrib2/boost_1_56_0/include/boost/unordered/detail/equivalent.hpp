// Address: 0x16b02c0 | Name: _ZN5boost9unordered6detail18grouped_table_implINS1_8multimapINSt3__19allocatorINS4_4pairIKmmEEEEmmNS_4hashImEENS4_8equal_toImEEEEE12emplace_implERNS1_16node_constructorINS5_INS1_16grouped_ptr_nodeIS8_EEEEEE
boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::iterator __fastcall boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<unsigned long const,unsigned long>>,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long>>>::emplace_impl(
        boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > > *this,
        boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::node_constructor *a)
{
  size_t v4; // r12
  size_t bucket_count; // rdi
  size_t size; // rsi
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  _QWORD *p_next; // rbx
  boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> > > >::node_pointer node; // rcx
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> > *v10; // rax
  size_t v11; // rdi
  size_t v12; // rsi
  size_t v13; // rbx
  boost::unordered::detail::table<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // rdi
  size_t v15; // rsi
  _QWORD *v16; // rax
  boost::unordered::detail::ptr_bucket *v17; // r8

  v4 = *(_QWORD *)a->node_->value_base_.data_.data_.buf;
  bucket_count = this->bucket_count_;
  size = this->size_;
  if ( size )
  {
    next = this->buckets_[v4 % bucket_count].next_;
    if ( next )
    {
      while ( 1 )
      {
        p_next = &next->next_->next_;
        if ( !next->next_ )
          break;
        if ( p_next[2] == v4 )
        {
          if ( v4 == p_next[3] )
            goto LABEL_11;
        }
        else if ( p_next[2] % bucket_count != v4 % bucket_count )
        {
          break;
        }
        next = (boost::unordered::detail::ptr_bucket::link_pointer)p_next[1];
      }
    }
  }
  p_next = 0;
LABEL_11:
  boost::unordered::detail::table<boost::unordered::detail::multimap<std::allocator<std::pair<unsigned long const,unsigned long>>,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long>>>::reserve_for_insert(
    this,
    size + 1);
  node = a->node_;
  a->node_ = 0;
  node->hash_ = v4;
  if ( p_next )
  {
    v10 = (boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> > *)p_next[1];
    node->next_ = v10->next_;
    node->group_prev_ = v10;
    *(_QWORD *)p_next[1] = node;
    p_next[1] = node;
    if ( node->next_ )
    {
      v11 = this->bucket_count_;
      v12 = (size_t)node->next_[2].next_ % v11;
      if ( v12 != v4 % v11 )
        this->buckets_[v12].next_ = node;
    }
  }
  else
  {
    v13 = this->bucket_count_;
    buckets = this->buckets_;
    v15 = v4 % v13;
    v16 = &buckets[v4 % v13].next_->next_;
    if ( v16 )
    {
      node->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)*v16;
      buckets[v15].next_->next_ = node;
    }
    else
    {
      v17 = &buckets[v13];
      if ( v17->next_ )
        buckets[(size_t)v17->next_[2].next_ % v13].next_ = node;
      buckets[v15].next_ = v17;
      node->next_ = v17->next_;
      v17->next_ = node;
    }
  }
  ++this->size_;
  return (boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::iterator)node;
}


// Address: 0x16b07a0 | Name: _ZN5boost9unordered6detail18grouped_table_implINS1_8multimapINSt3__19allocatorINS4_4pairIKmmEEEEmmNS_4hashImEENS4_8equal_toImEEEEE11erase_nodesEPNS1_16grouped_ptr_nodeIS8_EESI_
boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::link_pointer __fastcall boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<unsigned long const,unsigned long>>,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long>>>::erase_nodes(
        boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > > *this,
        boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::node_pointer i,
        boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::node_pointer j)
{
  boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::node_pointer v3; // r14
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> >::node_pointer group_prev; // rcx
  size_t v6; // r12
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> >::node_pointer v7; // rbx
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> >::node_pointer *p_group_prev; // rax
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> >::node_pointer *v9; // rdi
  boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::node_pointer *v10; // rcx
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> >::node_pointer v11; // rdi
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> >::node_pointer v12; // rax
  boost::unordered::detail::table<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer *p_buckets; // r13
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> > ***v14; // rax
  boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> > *v15; // rcx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdi
  boost::unordered::detail::table<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer v17; // rax
  boost::unordered::detail::ptr_bucket *v18; // rbp
  size_t v19; // rdx

  v3 = j;
  group_prev = i->group_prev_;
  v6 = i->hash_ % this->bucket_count_;
  v7 = 0;
  if ( group_prev->next_ == i )
    v7 = i->group_prev_;
  if ( !j )
    goto LABEL_11;
  p_group_prev = &j->group_prev_;
  v9 = &j->group_prev_;
  if ( j != i )
  {
    v9 = &j->group_prev_;
    while ( (*v9)->next_ == j )
    {
      j = j->group_prev_;
      v9 = &j->group_prev_;
      if ( j == i )
        goto LABEL_8;
    }
    v11 = j->group_prev_;
    j->group_prev_ = *p_group_prev;
    *p_group_prev = v11;
LABEL_11:
    if ( v7 )
    {
      do
      {
        v12 = group_prev;
        group_prev = group_prev->group_prev_;
      }
      while ( group_prev->next_ == v12 );
      v12->group_prev_ = i->group_prev_;
      i->group_prev_ = group_prev;
      goto LABEL_14;
    }
LABEL_15:
    p_buckets = &this->buckets_;
    v14 = (boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> > ***)&this->buckets_[v6];
    do
    {
      v7 = (boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> >::node_pointer)*v14;
      v15 = **v14;
      v14 = (boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> > ***)&v15->group_prev_;
    }
    while ( v15 != i );
    goto LABEL_17;
  }
LABEL_8:
  v10 = (boost::unordered::detail::grouped_table_impl<boost::unordered::detail::multimap<std::allocator<std::pair<const unsigned long,unsigned long> >,unsigned long,unsigned long,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::node_pointer *)*v9;
  *v9 = *p_group_prev;
  *p_group_prev = (boost::unordered::detail::grouped_ptr_node<std::pair<const unsigned long,unsigned long> >::node_pointer)v10;
  if ( !v7 )
    goto LABEL_15;
LABEL_14:
  p_buckets = &this->buckets_;
LABEL_17:
  next = v7->next_;
  do
  {
    v18 = next[1].next_->next_;
    do
    {
      v7->next_ = next->next_;
      operator delete(next);
      --this->size_;
      next = v7->next_;
    }
    while ( v7->next_ != v18 );
    if ( v18 )
    {
      v19 = (unsigned __int64)v18[2].next_ % this->bucket_count_;
      if ( v19 == v6 )
      {
        v19 = v6;
        goto LABEL_27;
      }
      v17 = *p_buckets;
      v17[v19].next_ = v7;
      if ( v17[v6].next_ != v7 )
        goto LABEL_27;
    }
    else
    {
      v17 = *p_buckets;
      v19 = v6;
      if ( (*p_buckets)[v6].next_ != v7 )
        goto LABEL_27;
    }
    v17[v6].next_ = 0;
LABEL_27:
    next = v7->next_;
    v6 = v19;
  }
  while ( v7->next_ != v3 );
  return v7;
}


