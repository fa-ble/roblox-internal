// Address: 0x2606bd0 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS9_6config15asio_tls_client16transport_configEEEFvNS7_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeEEJNSH_ISG_EERSQ_RSW_RKNS7_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEESY_EES6_S1B_S1C_EEvRT_PNS4_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> *f; // rdi
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v4; // [rsp+0h] [rbp-1E8h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > handler; // [rsp+E0h] [rbp-108h] BYREF
  unsigned __int64 v6; // [rsp+1D0h] [rbp-18h]

  v6 = __readfsqword(0x28u);
  *(_OWORD *)&v4.context_.__f_ = *(_OWORD *)&this_handler->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul>,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>>::__tuple_impl(
    &v4.context_.__bound_args_.__base_,
    &this_handler->handler_.__bound_args_.__base_);
  v4.handler_.handler_.dispatcher_ = function->handler_.dispatcher_;
  *(_OWORD *)&v4.handler_.handler_.handler_.__f_ = *(_OWORD *)&function->handler_.handler_.__f_;
  v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> *)function->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> *))f->handler_.dispatcher_.service_->owner_)(f);
    }
    else
    {
      v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = function->handler_.handler_.__bound_args_.__base_.__value_.__f_;
      function->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v4.handler_.arg1_ = function->arg1_;
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &handler,
    &v4);
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    &handler);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler(&handler);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler(&v4);
}


// Address: 0x2606d20 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS9_6config15asio_tls_client16transport_configEEEFvNS7_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeEEJNSH_ISG_EERSQ_RSW_RKNS7_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEESY_EES1B_ED2Ev
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this)
{
  std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *v2; // rax
  std::function<void (const std::error_code &)>::__base *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  volatile signed __int64 *v5; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *v6; // rdi
  volatile signed __int64 *v7; // rbx
  volatile signed __int64 *v8; // rbx

  v2 = &this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
  f = this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v2 == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 4))(f);
  }
  else if ( f )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 5))(f);
  }
  cntrl = (volatile signed __int64 *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
  v5 = (volatile signed __int64 *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
  }
  v6 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)this->context_.__bound_args_.__base_.__value_.__f_;
  if ( &this->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v6 )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *))v6->context_.__f_
     + 4))(v6);
  }
  else if ( v6 )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *))v6->context_.__f_
     + 5))(v6);
  }
  v7 = (volatile signed __int64 *)this->context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v7 && !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(v7);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
  }
  v8 = (volatile signed __int64 *)this->context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8 )
  {
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v8 + 16))(v8);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
  }
}


// Address: 0x26070c0 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS9_6config15asio_tls_client16transport_configEEEFvNS7_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeEEJNSH_ISG_EERSQ_RSW_RKNS7_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEESY_EES1B_EC2EOS1F_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  std::function<void (const std::error_code &)>::__base *f; // rax
  std::function<void (const std::error_code &)>::__base *v3; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->context_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.handler_.dispatcher_ = other->handler_.handler_.dispatcher_;
  *(_OWORD *)&this->handler_.handler_.handler_.__f_ = *(_OWORD *)&other->handler_.handler_.handler_.__f_;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  v3 = other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = v3;
      other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.arg1_ = other->handler_.arg1_;
}


// Address: 0x26073d0 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config15asio_tls_client16transport_configEEEFvNS5_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISI_EENS0_22deadline_timer_serviceISI_SK_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNSF_ISE_EERSO_RSU_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEclISW_EEvRKT_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1)
{
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v3; // rbx
  std::__shared_weak_count *v4; // rbx
  std::__shared_weak_count *v5; // rbx
  __int128 v6; // [rsp+0h] [rbp-F8h]
  std::__tuple_impl<std::__tuple_indices<0,1,2,3>,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,std::placeholders::__ph<1> > v7; // [rsp+10h] [rbp-E8h] BYREF
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> handler; // [rsp+60h] [rbp-98h] BYREF
  unsigned __int64 v9; // [rsp+D8h] [rbp-20h]

  v9 = __readfsqword(0x28u);
  v6 = *(_OWORD *)&this->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul>,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>>::__tuple_impl(
    &v7,
    &this->handler_.__bound_args_.__base_);
  *(_OWORD *)&handler.handler_.__f_ = v6;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = v7.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  memset(&v7, 0, 32);
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = v7.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  if ( v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    if ( &v7.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *))v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
       + 3))(
        v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_;
      v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = *arg1;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
    &this->dispatcher_,
    &handler);
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v3 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(v3);
    std::__shared_weak_count::__release_weak(v3);
  }
  if ( &v7.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 4))(v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_);
  }
  else if ( v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (**)(void))v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 5))();
  }
  v4 = v7.std::__1::__tuple_leaf<1,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_;
  if ( v7.std::__1::__tuple_leaf<1,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v7.std::__1::__tuple_leaf<1,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
  }
  v5 = v7.std::__1::__tuple_leaf<0,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_;
  if ( v7.std::__1::__tuple_leaf<0,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v7.std::__1::__tuple_leaf<0,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
      std::__shared_weak_count::__release_weak(v5);
    }
  }
}


// Address: 0x260fc40 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_15wrapped_handlerINS0_10io_service6strandENSt3__18functionIFvvEEENS1_26is_continuation_if_runningEEES5_S9_SA_EEvRT_PNS3_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *v4; // rdi
  boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > v5; // [rsp+0h] [rbp-98h] BYREF
  unsigned __int64 v6; // [rsp+70h] [rbp-28h]

  v6 = __readfsqword(0x28u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *)this_handler->handler_.__f_;
  if ( f )
  {
    if ( &this_handler->handler_ == (std::function<void ()> *)f )
    {
      v5.context_.__f_ = (std::function<void ()>::__base *)&v5;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *))f->dispatcher_.service_->owner_)(f);
    }
    else
    {
      v5.context_.__f_ = (std::function<void ()>::__base *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *))f->dispatcher_.service_->key_.id_)(f);
    }
  }
  else
  {
    v5.context_.__f_ = 0;
  }
  v5.handler_.dispatcher_ = function->dispatcher_;
  v4 = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *)function->handler_.__f_;
  if ( v4 )
  {
    if ( &function->handler_ == (std::function<void ()> *)v4 )
    {
      v5.handler_.handler_.__f_ = (std::function<void ()>::__base *)&v5.handler_.handler_;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running> *, std::function<void ()> *))v4->dispatcher_.service_->owner_)(
        v4,
        &v5.handler_.handler_);
    }
    else
    {
      v5.handler_.handler_.__f_ = function->handler_.__f_;
      function->handler_.__f_ = 0;
    }
  }
  else
  {
    v5.handler_.handler_.__f_ = 0;
  }
  boost::asio::io_service::strand::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()(void)>,boost::asio::detail::is_continuation_if_running>,std::function<void ()(void)>>>(
    &this_handler->dispatcher_,
    &v5);
  if ( &v5.handler_.handler_ == (std::function<void ()> *)v5.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void ()>::__base *))v5.handler_.handler_.__f_->_vptr$__base + 4))(v5.handler_.handler_.__f_);
  }
  else if ( v5.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v5.handler_.handler_.__f_->_vptr$__base + 5))();
  }
  if ( &v5 == (boost::asio::detail::rewrapped_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::function<void ()>,boost::asio::detail::is_continuation_if_running>,std::function<void ()> > *)v5.context_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void ()>::__base *))v5.context_.__f_->_vptr$__base + 4))(v5.context_.__f_);
  }
  else if ( v5.context_.__f_ )
  {
    (*((void (**)(void))v5.context_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x26199f0 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config15asio_tls_client16transport_configEEEFvRKNS_6system10error_codeEmEJNS5_10shared_ptrISE_EERKNS5_12placeholders4__phILi1EEERKNSO_ILi2EEEEEENS1_26is_continuation_if_runningEEclISG_mEEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const unsigned __int64 *arg2)
{
  __int128 v3; // xmm0
  std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rcx
  std::__shared_weak_count *v6; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> v7; // [rsp+0h] [rbp-48h] BYREF

  v3 = *(_OWORD *)&this->handler_.__f_;
  ptr = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  *(_OWORD *)&v7.handler_.__f_ = v3;
  v7.handler_.__bound_args_.__base_.__value_.__ptr_ = ptr;
  v7.handler_.__bound_args_.__base_.__value_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  v7.arg1_ = *arg1;
  v7.arg2_ = *arg2;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
    &this->dispatcher_,
    &v7);
  v6 = v7.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v7.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v7.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
      std::__shared_weak_count::__release_weak(v6);
    }
  }
}


// Address: 0x26213f0 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS9_6config15asio_tls_client16transport_configEEEFvNS7_10shared_ptrINSB_10connectionISF_EEEENSH_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISN_EENS0_22deadline_timer_serviceISN_SP_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS14_3tcpEEEEJPSG_RSK_RST_RSZ_RKNS7_12placeholders4__phILi1EEERKNS1F_ILi2EEEEEENS1_26is_continuation_if_runningEEES11_S17_EES6_S1M_S1N_EEvRT_PNS4_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *f; // rdi
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > v4; // [rsp+0h] [rbp-268h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > handler; // [rsp+120h] [rbp-148h] BYREF
  unsigned __int64 v6; // [rsp+250h] [rbp-18h]

  v6 = __readfsqword(0x28u);
  *(_OWORD *)&v4.context_.__f_ = *(_OWORD *)&this_handler->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul,4ul,5ul>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>,std::placeholders::__ph<2>>::__tuple_impl(
    &v4.context_.__bound_args_.__base_,
    &this_handler->handler_.__bound_args_.__base_);
  v4.handler_.handler_.dispatcher_ = function->handler_.dispatcher_;
  *(_OWORD *)&v4.handler_.handler_.handler_.__f_ = *(_OWORD *)&function->handler_.handler_.__f_;
  *(_OWORD *)&v4.handler_.handler_.handler_.__bound_args_.__base_.__value_ = *(_OWORD *)&function->handler_.handler_.__bound_args_.__base_.__value_;
  v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ = function->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)function->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))f->handler_.dispatcher_.service_->owner_)(f);
    }
    else
    {
      v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = function->handler_.handler_.__bound_args_.__base_.__value_.__f_;
      function->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v4.handler_.arg1_ = function->arg1_;
  v4.handler_.arg2_.values_ = function->arg2_.values_;
  function->arg2_.values_ = 0;
  v4.handler_.arg2_.index_ = function->arg2_.index_;
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
    &handler,
    &v4);
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    &handler);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(&handler);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(&v4);
}


// Address: 0x2621580 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS9_6config15asio_tls_client16transport_configEEEFvNS7_10shared_ptrINSB_10connectionISF_EEEENSH_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISN_EENS0_22deadline_timer_serviceISN_SP_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS14_3tcpEEEEJPSG_RSK_RST_RSZ_RKNS7_12placeholders4__phILi1EEERKNS1F_ILi2EEEEEENS1_26is_continuation_if_runningEEES11_S17_EES1M_ED2Ev
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this)
{
  volatile signed __int64 *cntrl; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *f; // rdi
  volatile signed __int64 *v4; // rbx
  volatile signed __int64 *v5; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *v6; // rdi
  volatile signed __int64 *v7; // rbx
  volatile signed __int64 *v8; // rbx

  cntrl = (volatile signed __int64 *)this->handler_.arg2_.values_.__cntrl_;
  if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
  f = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( &this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))f->context_.__f_
     + 4))(f);
  }
  else if ( f )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))f->context_.__f_
     + 5))(f);
  }
  v4 = (volatile signed __int64 *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
  }
  v5 = (volatile signed __int64 *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
  }
  v6 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)this->context_.__bound_args_.__base_.__value_.__f_;
  if ( &this->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v6 )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))v6->context_.__f_
     + 4))(v6);
  }
  else if ( v6 )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))v6->context_.__f_
     + 5))(v6);
  }
  v7 = (volatile signed __int64 *)this->context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v7 && !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(v7);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
  }
  v8 = (volatile signed __int64 *)this->context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8 )
  {
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v8 + 16))(v8);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
  }
}


// Address: 0x2621960 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS9_6config15asio_tls_client16transport_configEEEFvNS7_10shared_ptrINSB_10connectionISF_EEEENSH_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISN_EENS0_22deadline_timer_serviceISN_SP_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS14_3tcpEEEEJPSG_RSK_RST_RSZ_RKNS7_12placeholders4__phILi1EEERKNS1F_ILi2EEEEEENS1_26is_continuation_if_runningEEES11_S17_EES1M_EC2EOS1Q_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *other)
{
  std::function<void (const std::error_code &)>::__base *f; // rax
  std::function<void (const std::error_code &)>::__base *v3; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.__value_ = other->context_.__bound_args_.__base_.__value_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->context_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.handler_.dispatcher_ = other->handler_.handler_.dispatcher_;
  *(_OWORD *)&this->handler_.handler_.handler_.__f_ = *(_OWORD *)&other->handler_.handler_.handler_.__f_;
  this->handler_.handler_.handler_.__bound_args_.__base_.__value_ = other->handler_.handler_.handler_.__bound_args_.__base_.__value_;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  v3 = other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = v3;
      other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.arg1_ = other->handler_.arg1_;
  this->handler_.arg2_.values_ = other->handler_.arg2_.values_;
  other->handler_.arg2_.values_ = 0;
  this->handler_.arg2_.index_ = other->handler_.arg2_.index_;
}


// Address: 0x2621ba0 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS7_6config15asio_tls_client16transport_configEEEFvNS5_10shared_ptrINS9_10connectionISD_EEEENSF_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS12_3tcpEEEEJPSE_RSI_RSR_RSX_RKNS5_12placeholders4__phILi1EEERKNS1D_ILi2EEEEEENS1_26is_continuation_if_runningEEclISZ_S15_EEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *arg2)
{
  volatile signed __int64 *cntrl; // rcx
  size_t index; // rcx
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7; // rbx
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  __int128 v14; // [rsp+0h] [rbp-1E8h]
  std::__tuple_impl<std::__tuple_indices<0,1,2,3,4,5>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,std::placeholders::__ph<1>,std::placeholders::__ph<2> > v15; // [rsp+10h] [rbp-1D8h] BYREF
  __int128 v16; // [rsp+70h] [rbp-178h]
  _BYTE v17[24]; // [rsp+80h] [rbp-168h]
  std::__shared_weak_count *v18[2]; // [rsp+98h] [rbp-150h]
  _BYTE v19[32]; // [rsp+B0h] [rbp-138h] BYREF
  std::function<void (const std::error_code &)>::__base *f; // [rsp+D0h] [rbp-118h]
  boost::system::error_code v21; // [rsp+E0h] [rbp-108h]
  std::__shared_weak_count *v22[2]; // [rsp+F0h] [rbp-F8h]
  size_t v23; // [rsp+100h] [rbp-E8h]
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > handler; // [rsp+110h] [rbp-D8h] BYREF
  unsigned __int64 v25; // [rsp+1C0h] [rbp-28h]

  v25 = __readfsqword(0x28u);
  v14 = *(_OWORD *)&this->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul,4ul,5ul>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>,std::placeholders::__ph<2>>::__tuple_impl(
    &v15,
    &this->handler_.__bound_args_.__base_);
  v16 = v14;
  *(_OWORD *)v17 = *(_OWORD *)&v15.std::__1::__tuple_leaf<0,websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,false>::__value_;
  *(_QWORD *)&v17[16] = v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_;
  memset(
    &v15.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>,
    0,
    32);
  *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)v18 = v15.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  if ( v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    if ( &v15.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
    {
      f = (std::function<void (const std::error_code &)>::__base *)v19;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
       + 3))(
        v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_,
        v19);
    }
    else
    {
      f = v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_;
      v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ = 0;
    }
  }
  else
  {
    f = 0;
  }
  v21 = *arg1;
  v22[0] = (std::__shared_weak_count *)arg2->values_.__ptr_;
  cntrl = (volatile signed __int64 *)arg2->values_.__cntrl_;
  v22[1] = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  index = arg2->index_;
  v23 = index;
  *(_OWORD *)&handler.handler_.__f_ = v16;
  *(_OWORD *)&handler.handler_.__bound_args_.__base_.__value_ = *(_OWORD *)v17;
  handler.handler_.__bound_args_.__base_.__value_.__cntrl_ = *(std::__shared_weak_count **)&v17[16];
  *(_OWORD *)&v17[8] = 0;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)v18;
  *(_OWORD *)v18 = 0;
  if ( f )
  {
    if ( v19 == (_BYTE *)f )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *))f->_vptr$__base
       + 3))(
        f,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>);
      index = v23;
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = f;
      f = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = v21;
  handler.arg2_.values_ = *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)v22;
  *(_OWORD *)v22 = 0;
  handler.arg2_.index_ = index;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>(
    this->dispatcher_.service_,
    &this->dispatcher_.impl_,
    &handler);
  v6 = handler.arg2_.values_.__cntrl_;
  if ( handler.arg2_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)handler.arg2_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v7 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  v8 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  v9 = v22[1];
  if ( v22[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
    std::__shared_weak_count::__release_weak(v9);
  }
  if ( v19 == (_BYTE *)f )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 4))(f);
  }
  else if ( f )
  {
    (*((void (**)(void))f->_vptr$__base + 5))();
  }
  v10 = v18[1];
  if ( v18[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  v11 = *(std::__shared_weak_count **)&v17[16];
  if ( *(_QWORD *)&v17[16]
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v17[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  if ( &v15.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 4))(v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_);
  }
  else if ( v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (**)(void))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 5))();
  }
  v12 = v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_;
  if ( v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  v13 = v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_;
  if ( v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x2624750 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS7_6config15asio_tls_client16transport_configEEEFvNS5_10shared_ptrINS9_10connectionISD_EEEENSF_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJPSE_RSI_RSR_RSX_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEclISZ_NS0_2ip23basic_resolver_iteratorINS1H_3tcpEEEEEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *arg2)
{
  volatile signed __int64 *cntrl; // rcx
  size_t index; // rcx
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7; // rbx
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  __int128 v14; // [rsp+0h] [rbp-1E8h]
  std::__tuple_impl<std::__tuple_indices<0,1,2,3,4>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,std::placeholders::__ph<1> > v15; // [rsp+10h] [rbp-1D8h] BYREF
  __int128 v16; // [rsp+70h] [rbp-178h]
  _BYTE v17[24]; // [rsp+80h] [rbp-168h]
  std::__shared_weak_count *v18[2]; // [rsp+98h] [rbp-150h]
  _BYTE v19[32]; // [rsp+B0h] [rbp-138h] BYREF
  std::function<void (const std::error_code &)>::__base *f; // [rsp+D0h] [rbp-118h]
  boost::system::error_code v21; // [rsp+E0h] [rbp-108h]
  std::__shared_weak_count *v22[2]; // [rsp+F0h] [rbp-F8h]
  size_t v23; // [rsp+100h] [rbp-E8h]
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > handler; // [rsp+110h] [rbp-D8h] BYREF
  unsigned __int64 v25; // [rsp+1C0h] [rbp-28h]

  v25 = __readfsqword(0x28u);
  v14 = *(_OWORD *)&this->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul,4ul>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>>::__tuple_impl(
    &v15,
    &this->handler_.__bound_args_.__base_);
  v16 = v14;
  *(_OWORD *)v17 = *(_OWORD *)&v15.std::__1::__tuple_leaf<0,websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,false>::__value_;
  *(_QWORD *)&v17[16] = v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_;
  memset(
    &v15.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>,
    0,
    32);
  *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)v18 = v15.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  if ( v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    if ( &v15.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
    {
      f = (std::function<void (const std::error_code &)>::__base *)v19;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
       + 3))(
        v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_,
        v19);
    }
    else
    {
      f = v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_;
      v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ = 0;
    }
  }
  else
  {
    f = 0;
  }
  v21 = *arg1;
  v22[0] = (std::__shared_weak_count *)arg2->values_.__ptr_;
  cntrl = (volatile signed __int64 *)arg2->values_.__cntrl_;
  v22[1] = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  index = arg2->index_;
  v23 = index;
  *(_OWORD *)&handler.handler_.__f_ = v16;
  *(_OWORD *)&handler.handler_.__bound_args_.__base_.__value_ = *(_OWORD *)v17;
  handler.handler_.__bound_args_.__base_.__value_.__cntrl_ = *(std::__shared_weak_count **)&v17[16];
  *(_OWORD *)&v17[8] = 0;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)v18;
  *(_OWORD *)v18 = 0;
  if ( f )
  {
    if ( v19 == (_BYTE *)f )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *))f->_vptr$__base
       + 3))(
        f,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>);
      index = v23;
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = f;
      f = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = v21;
  handler.arg2_.values_ = *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)v22;
  *(_OWORD *)v22 = 0;
  handler.arg2_.index_ = index;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>(
    this->dispatcher_.service_,
    &this->dispatcher_.impl_,
    &handler);
  v6 = handler.arg2_.values_.__cntrl_;
  if ( handler.arg2_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)handler.arg2_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v7 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  v8 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  v9 = v22[1];
  if ( v22[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
    std::__shared_weak_count::__release_weak(v9);
  }
  if ( v19 == (_BYTE *)f )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 4))(f);
  }
  else if ( f )
  {
    (*((void (**)(void))f->_vptr$__base + 5))();
  }
  v10 = v18[1];
  if ( v18[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  v11 = *(std::__shared_weak_count **)&v17[16];
  if ( *(_QWORD *)&v17[16]
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v17[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  if ( &v15.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 4))(v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_);
  }
  else if ( v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (**)(void))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 5))();
  }
  v12 = v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_;
  if ( v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  v13 = v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_;
  if ( v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>::__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x2625930 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EENS5_23basic_resolver_iteratorIS6_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSH_6config15asio_tls_client16transport_configEEEFvNSF_10shared_ptrINSJ_10connectionISN_EEEENSP_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISV_EENS0_22deadline_timer_serviceISV_SX_EEEEEENSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJPSO_RSS_RS11_RS17_RKNSF_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES19_EESE_S1N_S1O_EEvRT_PNSC_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  boost::asio::detail::strand_service::implementation_type *p_impl; // rsi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v8; // [rsp+0h] [rbp-2B8h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > handler; // [rsp+140h] [rbp-178h] BYREF
  unsigned __int64 v10; // [rsp+298h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v8.context_.__f_ = *(_OWORD *)&this_handler->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul,4ul>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>>::__tuple_impl(
    &v8.context_.__bound_args_.__base_,
    &this_handler->handler_.__bound_args_.__base_);
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    &v8.handler_.handler_,
    &function->handler_);
  v8.handler_.arg1_ = function->arg1_;
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &handler,
    &v8);
  p_impl = &this_handler->dispatcher_.impl_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    &handler);
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&handler.handler_.handler_);
  if ( &handler.context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)handler.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::strand_service::implementation_type *))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(
      handler.context_.__bound_args_.__base_.__value_.__f_,
      p_impl);
  }
  cntrl = handler.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v5 = handler.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
  }
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&v8.handler_.handler_);
  if ( &v8.context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v8.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::strand_service::implementation_type *))v8.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(
      v8.context_.__bound_args_.__base_.__value_.__f_,
      p_impl);
  }
  v6 = v8.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  v7 = v8.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v8.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
      std::__shared_weak_count::__release_weak(v7);
    }
  }
}


// Address: 0x2625f20 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EENS5_23basic_resolver_iteratorIS6_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSH_6config15asio_tls_client16transport_configEEEFvNSF_10shared_ptrINSJ_10connectionISN_EEEENSP_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISV_EENS0_22deadline_timer_serviceISV_SX_EEEEEENSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJPSO_RSS_RS11_RS17_RKNSF_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES19_EES1N_EC2EOS1S_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *v2; // r12
  std::function<void (const std::error_code &)>::__base *f; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.__value_ = other->context_.__bound_args_.__base_.__value_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  v2 = &this->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)v2;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        other->context_.__bound_args_.__base_.__value_.__f_,
        v2);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    &this->handler_.handler_,
    &other->handler_.handler_);
  this->handler_.arg1_ = other->handler_.arg1_;
}


// Address: 0x2629f80 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config15asio_tls_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISE_EERSK_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEclISM_mEEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const unsigned __int64 *arg2)
{
  std::__shared_weak_count *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::function<void (const std::error_code &)>::__base *v7; // rax
  std::__shared_weak_count *v8; // rbx
  __int128 v9; // [rsp+0h] [rbp-F8h]
  std::__shared_weak_count *v10[2]; // [rsp+10h] [rbp-E8h]
  _BYTE v11[32]; // [rsp+20h] [rbp-D8h] BYREF
  std::function<void (const std::error_code &)>::__base *v12; // [rsp+40h] [rbp-B8h]
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> handler; // [rsp+50h] [rbp-A8h] BYREF
  unsigned __int64 v14; // [rsp+C8h] [rbp-30h]

  v14 = __readfsqword(0x28u);
  v9 = *(_OWORD *)&this->handler_.__f_;
  v10[0] = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v10[1] = cntrl;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v12 = (std::function<void (const std::error_code &)>::__base *)v11;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v11);
      v7 = v12;
    }
    else
    {
      v7 = (std::function<void (const std::error_code &)>::__base *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *))f->dispatcher_.service_->key_.id_)(f);
      v12 = v7;
    }
  }
  else
  {
    v12 = 0;
    v7 = 0;
  }
  *(_OWORD *)&handler.handler_.__f_ = v9;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)v10;
  if ( v7 )
  {
    if ( v11 == (_BYTE *)v7 )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v7->_vptr$__base
       + 3))(
        v7,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = v7;
      v12 = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = *arg1;
  handler.arg2_ = *arg2;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>(
    &this->dispatcher_,
    &handler);
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v8 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  if ( v11 == (_BYTE *)v12 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v12->_vptr$__base + 4))(v12);
  }
  else if ( v12 )
  {
    (*((void (**)(void))v12->_vptr$__base + 5))();
  }
}


// Address: 0x262a8a0 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__16vectorINS0_12const_bufferENSB_9allocatorISD_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSM_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrIST_EERSZ_RKNSB_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES11_mEESK_S1E_S1F_EEvRT_PNSI_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  volatile signed __int64 *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *v9; // rdi
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  __int128 v14; // [rsp+0h] [rbp-298h] BYREF
  std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *v15; // [rsp+10h] [rbp-288h]
  std::__shared_weak_count *v16; // [rsp+18h] [rbp-280h]
  _BYTE v17[32]; // [rsp+20h] [rbp-278h] BYREF
  _BYTE *v18; // [rsp+40h] [rbp-258h]
  __int64 v19; // [rsp+50h] [rbp-248h]
  void *v20[8]; // [rsp+58h] [rbp-240h] BYREF
  int v21; // [rsp+98h] [rbp-200h]
  __int64 v22; // [rsp+A0h] [rbp-1F8h]
  __int128 v23; // [rsp+B0h] [rbp-1E8h]
  __int128 v24; // [rsp+C0h] [rbp-1D8h]
  std::__shared_weak_count *v25[2]; // [rsp+D0h] [rbp-1C8h]
  _BYTE v26[32]; // [rsp+E0h] [rbp-1B8h] BYREF
  _BYTE *v27; // [rsp+100h] [rbp-198h]
  __int128 v28; // [rsp+110h] [rbp-188h]
  __int64 v29; // [rsp+120h] [rbp-178h]
  _BYTE v30[24]; // [rsp+130h] [rbp-168h] BYREF
  std::__shared_weak_count *v31; // [rsp+148h] [rbp-150h]
  char v32; // [rsp+150h] [rbp-148h] BYREF
  char *v33; // [rsp+170h] [rbp-128h]
  void *ptr; // [rsp+188h] [rbp-110h]
  void *v35; // [rsp+190h] [rbp-108h]
  std::__shared_weak_count *v36; // [rsp+208h] [rbp-90h]
  char v37; // [rsp+210h] [rbp-88h] BYREF
  char *v38; // [rsp+230h] [rbp-68h]
  unsigned __int64 v39; // [rsp+270h] [rbp-28h]

  v39 = __readfsqword(0x28u);
  v14 = *(_OWORD *)&this_handler->handler_.__f_;
  v15 = this_handler->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this_handler->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v16 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this_handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this_handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v18 = v17;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *, __int64, __int64, __int64, __int64, _QWORD, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *))f->dispatcher_.service_->owner_)(
        f,
        v17,
        v2,
        v3,
        v4,
        v5,
        v14,
        *((_QWORD *)&v14 + 1),
        v15);
    }
    else
    {
      v18 = (_BYTE *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, __int64, __int64, __int64, __int64, _QWORD, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *))f->dispatcher_.service_->key_.id_)(
                       f,
                       this_handler,
                       v2,
                       v3,
                       v4,
                       v5,
                       v14,
                       *((_QWORD *)&v14 + 1),
                       v15);
    }
  }
  else
  {
    v18 = 0;
  }
  v19 = *(_QWORD *)function;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)v20,
    (boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)((char *)function + 8));
  v21 = *((_DWORD *)function + 18);
  v22 = *((_QWORD *)function + 10);
  v23 = *((_OWORD *)function + 6);
  v24 = *((_OWORD *)function + 7);
  *(_OWORD *)v25 = *((_OWORD *)function + 8);
  *((_OWORD *)function + 8) = 0;
  v9 = (boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)*((_QWORD *)function + 22);
  if ( v9 )
  {
    if ( (boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)((char *)function + 144) == v9 )
    {
      v27 = v26;
      (*(void (__fastcall **)(boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *, _BYTE *))(*(_QWORD *)v9 + 24LL))(
        v9,
        v26);
    }
    else
    {
      v27 = (_BYTE *)*((_QWORD *)function + 22);
      *((_QWORD *)function + 22) = 0;
    }
  }
  else
  {
    v27 = 0;
  }
  v29 = *((_QWORD *)function + 26);
  v28 = *((_OWORD *)function + 12);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)v30,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&v14);
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)v30);
  if ( &v37 == v38 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v38 + 32LL))(v38);
  }
  else if ( v38 )
  {
    (*(void (**)(void))(*(_QWORD *)v38 + 40LL))();
  }
  v10 = v36;
  if ( v36 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v36 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  if ( ptr )
  {
    v35 = ptr;
    operator delete(ptr);
  }
  if ( &v32 == v33 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v33 + 32LL))(v33);
  }
  else if ( v33 )
  {
    (*(void (**)(void))(*(_QWORD *)v33 + 40LL))();
  }
  v11 = v31;
  if ( v31 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v31 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  if ( v26 == v27 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v27 + 32LL))(v27);
  }
  else if ( v27 )
  {
    (*(void (**)(void))(*(_QWORD *)v27 + 40LL))();
  }
  v12 = v25[1];
  if ( v25[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v25[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  if ( v20[0] )
  {
    v20[1] = v20[0];
    operator delete(v20[0]);
  }
  if ( v17 == v18 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v18 + 32LL))(v18);
  }
  else if ( v18 )
  {
    (*(void (**)(void))(*(_QWORD *)v18 + 40LL))();
  }
  v13 = v16;
  if ( v16 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v16 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x262b090 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__16vectorINS0_12const_bufferENSB_9allocatorISD_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSM_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrIST_EERSZ_RKNSB_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES11_mEES1E_EC2EOS1J_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  char *v2; // r15
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *v3; // rax
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *v4; // rax

  *(_OWORD *)this = *(_OWORD *)other;
  *((_OWORD *)this + 1) = *((_OWORD *)other + 1);
  *((_OWORD *)other + 1) = 0;
  v2 = (char *)this + 32;
  v3 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)*((_QWORD *)other + 8);
  if ( v3 )
  {
    if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)other + 32) == v3 )
    {
      *((_QWORD *)this + 8) = v2;
      (*(void (__fastcall **)(_QWORD, char *))(**((_QWORD **)other + 8) + 24LL))(*((_QWORD *)other + 8), v2);
    }
    else
    {
      *((_QWORD *)this + 8) = v3;
      *((_QWORD *)other + 8) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 8) = 0;
  }
  *((_QWORD *)this + 10) = *((_QWORD *)other + 10);
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)this + 88),
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)other + 88));
  *((_DWORD *)this + 38) = *((_DWORD *)other + 38);
  *((_QWORD *)this + 20) = *((_QWORD *)other + 20);
  *((_OWORD *)this + 11) = *((_OWORD *)other + 11);
  *((_OWORD *)this + 12) = *((_OWORD *)other + 12);
  *((_OWORD *)this + 13) = *((_OWORD *)other + 13);
  *((_OWORD *)other + 13) = 0;
  v4 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)*((_QWORD *)other + 32);
  if ( v4 )
  {
    if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)other + 224) == v4 )
    {
      *((_QWORD *)this + 32) = (char *)this + 224;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)other + 32) + 24LL))(*((_QWORD *)other + 32));
    }
    else
    {
      *((_QWORD *)this + 32) = v4;
      *((_QWORD *)other + 32) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 32) = 0;
  }
  *((_QWORD *)this + 36) = *((_QWORD *)other + 36);
  *((_OWORD *)this + 17) = *((_OWORD *)other + 17);
}


// Address: 0x262d680 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config15asio_tls_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEmEJNS5_10shared_ptrISE_EERSK_RKNS5_12placeholders4__phILi1EEERKNSV_ILi2EEEEEENS1_26is_continuation_if_runningEEclISM_mEEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const unsigned __int64 *arg2)
{
  std::__shared_weak_count *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::function<void (const std::error_code &)>::__base *v7; // rax
  std::__shared_weak_count *v8; // rbx
  __int128 v9; // [rsp+0h] [rbp-F8h]
  std::__shared_weak_count *v10[2]; // [rsp+10h] [rbp-E8h]
  _BYTE v11[32]; // [rsp+20h] [rbp-D8h] BYREF
  std::function<void (const std::error_code &)>::__base *v12; // [rsp+40h] [rbp-B8h]
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> handler; // [rsp+50h] [rbp-A8h] BYREF
  unsigned __int64 v14; // [rsp+C8h] [rbp-30h]

  v14 = __readfsqword(0x28u);
  v9 = *(_OWORD *)&this->handler_.__f_;
  v10[0] = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v10[1] = cntrl;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v12 = (std::function<void (const std::error_code &)>::__base *)v11;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v11);
      v7 = v12;
    }
    else
    {
      v7 = (std::function<void (const std::error_code &)>::__base *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *))f->dispatcher_.service_->key_.id_)(f);
      v12 = v7;
    }
  }
  else
  {
    v12 = 0;
    v7 = 0;
  }
  *(_OWORD *)&handler.handler_.__f_ = v9;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)v10;
  if ( v7 )
  {
    if ( v11 == (_BYTE *)v7 )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v7->_vptr$__base
       + 3))(
        v7,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = v7;
      v12 = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = *arg1;
  handler.arg2_ = *arg2;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
    &this->dispatcher_,
    &handler);
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v8 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  if ( v11 == (_BYTE *)v12 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v12->_vptr$__base + 4))(v12);
  }
  else if ( v12 )
  {
    (*((void (**)(void))v12->_vptr$__base + 5))();
  }
}


// Address: 0x262df20 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESX_mEES1D_EC2ERS1H_RKS1D_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this,
        boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *handler,
        const std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> *context)
{
  std::__shared_weak_count *cntrl; // rax
  std::function<void (const std::error_code &)>::__base *f; // rdi
  boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *v6; // rax

  *(_OWORD *)this = *(_OWORD *)&context->__f_;
  *((_QWORD *)this + 2) = context->__bound_args_.__base_.__value_.__ptr_;
  cntrl = context->__bound_args_.__base_.__value_.__cntrl_;
  *((_QWORD *)this + 3) = cntrl;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  f = context->__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &context->__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)this + 8) = (char *)this + 32;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))context->__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(context->__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      *((_QWORD *)this + 8) = (*((__int64 (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base
                               + 2))(f);
    }
  }
  else
  {
    *((_QWORD *)this + 8) = 0;
  }
  *((_QWORD *)this + 10) = *(_QWORD *)handler;
  *((_QWORD *)this + 11) = *((_QWORD *)handler + 1);
  *((_QWORD *)this + 14) = *((_QWORD *)handler + 4);
  *((_OWORD *)this + 6) = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  *((_DWORD *)this + 30) = *((_DWORD *)handler + 10);
  *((_QWORD *)this + 16) = *((_QWORD *)handler + 6);
  *((_OWORD *)this + 9) = *((_OWORD *)handler + 4);
  *((_OWORD *)this + 10) = *((_OWORD *)handler + 5);
  *((_OWORD *)this + 11) = *((_OWORD *)handler + 6);
  *((_OWORD *)handler + 6) = 0;
  v6 = (boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)*((_QWORD *)handler + 18);
  if ( v6 )
  {
    if ( (boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)((char *)handler + 112) == v6 )
    {
      *((_QWORD *)this + 28) = (char *)this + 192;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)handler + 18) + 24LL))(*((_QWORD *)handler + 18));
    }
    else
    {
      *((_QWORD *)this + 28) = v6;
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 28) = 0;
  }
  *((_QWORD *)this + 32) = *((_QWORD *)handler + 22);
  *((_OWORD *)this + 15) = *((_OWORD *)handler + 10);
}


// Address: 0x262e0b0 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESX_mEES1D_ED2Ev
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this)
{
  char *v2; // rax
  char *v3; // rdi
  volatile signed __int64 *v4; // r14
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *v5; // rdi
  volatile signed __int64 *v6; // rbx

  v2 = (char *)this + 192;
  v3 = (char *)*((_QWORD *)this + 28);
  if ( v2 == v3 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + 32LL))(v3);
  }
  else if ( v3 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + 40LL))(v3);
  }
  v4 = (volatile signed __int64 *)*((_QWORD *)this + 23);
  if ( !v4 || _InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    if ( (*((_BYTE *)this + 96) & 1) == 0 )
      goto LABEL_9;
    goto LABEL_8;
  }
  (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
  std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
LABEL_8:
    operator delete(*((void **)this + 14));
LABEL_9:
  v5 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)*((_QWORD *)this + 8);
  if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)((char *)this + 32) == v5 )
  {
    (*(void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))(*(_QWORD *)v5 + 32LL))(v5);
  }
  else if ( v5 )
  {
    (*(void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))(*(_QWORD *)v5 + 40LL))(v5);
  }
  v6 = (volatile signed __int64 *)*((_QWORD *)this + 3);
  if ( v6 )
  {
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
  }
}


// Address: 0x262e410 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config15asio_tls_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESX_mEES1D_EC2EOS1I_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *other)
{
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *v2; // rax
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *v3; // rax

  *(_OWORD *)this = *(_OWORD *)other;
  *((_OWORD *)this + 1) = *((_OWORD *)other + 1);
  *((_OWORD *)other + 1) = 0;
  v2 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)*((_QWORD *)other + 8);
  if ( v2 )
  {
    if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)((char *)other + 32) == v2 )
    {
      *((_QWORD *)this + 8) = (char *)this + 32;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)other + 8) + 24LL))(*((_QWORD *)other + 8));
    }
    else
    {
      *((_QWORD *)this + 8) = v2;
      *((_QWORD *)other + 8) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 8) = 0;
  }
  *((_QWORD *)this + 10) = *((_QWORD *)other + 10);
  *((_QWORD *)this + 11) = *((_QWORD *)other + 11);
  *((_QWORD *)this + 14) = *((_QWORD *)other + 14);
  *((_OWORD *)this + 6) = *((_OWORD *)other + 6);
  *((_OWORD *)other + 6) = 0;
  *((_QWORD *)other + 14) = 0;
  *((_DWORD *)this + 30) = *((_DWORD *)other + 30);
  *((_QWORD *)this + 16) = *((_QWORD *)other + 16);
  *((_OWORD *)this + 9) = *((_OWORD *)other + 9);
  *((_OWORD *)this + 10) = *((_OWORD *)other + 10);
  *((_OWORD *)this + 11) = *((_OWORD *)other + 11);
  *((_OWORD *)other + 11) = 0;
  v3 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)*((_QWORD *)other + 28);
  if ( v3 )
  {
    if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)((char *)other + 192) == v3 )
    {
      *((_QWORD *)this + 28) = (char *)this + 192;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)other + 28) + 24LL))(*((_QWORD *)other + 28));
    }
    else
    {
      *((_QWORD *)this + 28) = v3;
      *((_QWORD *)other + 28) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 28) = 0;
  }
  *((_QWORD *)this + 32) = *((_QWORD *)other + 32);
  *((_OWORD *)this + 15) = *((_OWORD *)other + 15);
}


// Address: 0x2632cc0 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder2INS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJNSH_10shared_ptrISN_EERST_RKNSH_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEESV_mEESG_S18_S19_EEvRT_PNSE_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  volatile signed __int64 *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *v9; // rdi
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v14; // [rsp+0h] [rbp-258h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > handler; // [rsp+110h] [rbp-148h] BYREF
  unsigned __int64 v16; // [rsp+230h] [rbp-28h]

  v16 = __readfsqword(0x28u);
  *(_OWORD *)&v14.context_.__f_ = *(_OWORD *)&this_handler->handler_.__f_;
  v14.context_.__bound_args_.__base_.__value_.__ptr_ = this_handler->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this_handler->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v14.context_.__bound_args_.__base_.__value_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this_handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this_handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v14.context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v14.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>::element_type *))f->dispatcher_.service_->owner_)(
        f,
        &v14.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v14.context_.__f_,
        *((_QWORD *)&v14.context_.__f_ + 1),
        v14.context_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v14.context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>::element_type *))f->dispatcher_.service_->key_.id_)(f, this_handler, v2, v3, v4, v5, v14.context_.__f_, *((_QWORD *)&v14.context_.__f_ + 1), v14.context_.__bound_args_.__base_.__value_.__ptr_);
    }
  }
  else
  {
    v14.context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  *(_OWORD *)&v14.handler_.handler_.next_layer_ = *(_OWORD *)&function->handler_.next_layer_;
  v14.handler_.handler_.op_.type_ = function->handler_.op_.type_;
  v14.handler_.handler_.start_ = function->handler_.start_;
  v14.handler_.handler_.want_ = function->handler_.want_;
  v14.handler_.handler_.ec_ = function->handler_.ec_;
  v14.handler_.handler_.bytes_transferred_ = function->handler_.bytes_transferred_;
  v14.handler_.handler_.handler_.dispatcher_ = function->handler_.handler_.dispatcher_;
  *(_OWORD *)&v14.handler_.handler_.handler_.handler_.__f_ = *(_OWORD *)&function->handler_.handler_.handler_.__f_;
  v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = function->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  function->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  v9 = (boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)function->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v9 )
  {
    if ( &function->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9 )
    {
      v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v9->handler_.next_layer_->service_)(
        v9,
        &v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = function->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
      function->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v14.handler_.arg2_ = function->arg2_;
  v14.handler_.arg1_ = function->arg1_;
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &handler,
    &v14);
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    &handler);
  if ( &handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v10 = handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  if ( &handler.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v11 = handler.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  if ( &v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v12 = v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  if ( &v14.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v14.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v14.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v14.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v14.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v14.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v13 = v14.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v14.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v14.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x2633450 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJNSH_10shared_ptrISN_EERST_RKNSH_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEESV_mEES18_EC2EOS1D_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  std::function<void (const std::error_code &)>::__base *f; // rax
  std::function<void (const std::error_code &)>::__base *v3; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->context_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.handler_.next_layer_ = other->handler_.handler_.next_layer_;
  this->handler_.handler_.core_ = other->handler_.handler_.core_;
  this->handler_.handler_.op_.type_ = other->handler_.handler_.op_.type_;
  this->handler_.handler_.start_ = other->handler_.handler_.start_;
  this->handler_.handler_.want_ = other->handler_.handler_.want_;
  this->handler_.handler_.ec_ = other->handler_.handler_.ec_;
  this->handler_.handler_.bytes_transferred_ = other->handler_.handler_.bytes_transferred_;
  this->handler_.handler_.handler_.dispatcher_ = other->handler_.handler_.handler_.dispatcher_;
  *(_OWORD *)&this->handler_.handler_.handler_.handler_.__f_ = *(_OWORD *)&other->handler_.handler_.handler_.handler_.__f_;
  this->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = other->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  other->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  v3 = other->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &other->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      this->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = v3;
      other->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.arg2_ = other->handler_.arg2_;
  this->handler_.arg1_ = other->handler_.arg1_;
}


// Address: 0x2633f70 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder1INS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJNSH_10shared_ptrISN_EERST_RKNSH_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEESV_EESG_S18_S19_EEvRT_PNSE_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  volatile signed __int64 *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> *v9; // rdi
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v14; // [rsp+0h] [rbp-238h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > handler; // [rsp+100h] [rbp-138h] BYREF
  unsigned __int64 v16; // [rsp+210h] [rbp-28h]

  v16 = __readfsqword(0x28u);
  *(_OWORD *)&v14.context_.__f_ = *(_OWORD *)&this_handler->handler_.__f_;
  v14.context_.__bound_args_.__base_.__value_.__ptr_ = this_handler->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this_handler->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v14.context_.__bound_args_.__base_.__value_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this_handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this_handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v14.context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v14.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>::element_type *))f->dispatcher_.service_->owner_)(
        f,
        &v14.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v2,
        v3,
        v4,
        v5,
        v14.context_.__f_,
        *((_QWORD *)&v14.context_.__f_ + 1),
        v14.context_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v14.context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, __int64, __int64, __int64, __int64, std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>::element_type *))f->dispatcher_.service_->key_.id_)(f, this_handler, v2, v3, v4, v5, v14.context_.__f_, *((_QWORD *)&v14.context_.__f_ + 1), v14.context_.__bound_args_.__base_.__value_.__ptr_);
    }
  }
  else
  {
    v14.context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  *(_OWORD *)&v14.handler_.handler_.next_layer_ = *(_OWORD *)&function->handler_.next_layer_;
  v14.handler_.handler_.op_.type_ = function->handler_.op_.type_;
  v14.handler_.handler_.start_ = function->handler_.start_;
  v14.handler_.handler_.want_ = function->handler_.want_;
  v14.handler_.handler_.ec_ = function->handler_.ec_;
  v14.handler_.handler_.bytes_transferred_ = function->handler_.bytes_transferred_;
  v14.handler_.handler_.handler_.dispatcher_ = function->handler_.handler_.dispatcher_;
  *(_OWORD *)&v14.handler_.handler_.handler_.handler_.__f_ = *(_OWORD *)&function->handler_.handler_.handler_.__f_;
  v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = function->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  function->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  v9 = (boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> *)function->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v9 )
  {
    if ( &function->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9 )
    {
      v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v9->handler_.next_layer_->service_)(
        v9,
        &v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = function->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
      function->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v14.handler_.arg1_ = function->arg1_;
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &handler,
    &v14);
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    &handler);
  if ( &handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v10 = handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  if ( &handler.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v11 = handler.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  if ( &v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v12 = v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v14.handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  if ( &v14.context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v14.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v14.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v14.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v14.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v14.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v13 = v14.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v14.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v14.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x26346e0 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder1INS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS9_EEEENS5_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJNSH_10shared_ptrISN_EERST_RKNSH_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEESV_EES18_EC2EOS1D_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  std::function<void (const std::error_code &)>::__base *f; // rax
  std::function<void (const std::error_code &)>::__base *v3; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->context_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.handler_.next_layer_ = other->handler_.handler_.next_layer_;
  this->handler_.handler_.core_ = other->handler_.handler_.core_;
  this->handler_.handler_.op_.type_ = other->handler_.handler_.op_.type_;
  this->handler_.handler_.start_ = other->handler_.handler_.start_;
  this->handler_.handler_.want_ = other->handler_.handler_.want_;
  this->handler_.handler_.ec_ = other->handler_.handler_.ec_;
  this->handler_.handler_.bytes_transferred_ = other->handler_.handler_.bytes_transferred_;
  this->handler_.handler_.handler_.dispatcher_ = other->handler_.handler_.handler_.dispatcher_;
  *(_OWORD *)&this->handler_.handler_.handler_.handler_.__f_ = *(_OWORD *)&other->handler_.handler_.handler_.handler_.__f_;
  this->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = other->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  other->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  v3 = other->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &other->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      this->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = v3;
      other->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.arg1_ = other->handler_.arg1_;
}


// Address: 0x26354a0 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENS0_17mutable_buffers_1ENS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSE_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSK_8functionIFvRKNSK_10error_codeEEEERKNS_6system10error_codeEEJNSK_10shared_ptrISQ_EERSW_RKNSK_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEESY_mEES1B_EC2ERS1G_RKS1B_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long> *handler,
        const std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *context)
{
  volatile signed __int64 *cntrl; // rax
  std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *v5; // r15
  std::function<void (const std::error_code &)>::__base *f; // rdi

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&context->__f_;
  this->context_.__bound_args_.__base_.__value_.__ptr_ = context->__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)context->__bound_args_.__base_.__value_.__cntrl_;
  this->context_.__bound_args_.__base_.__value_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v5 = &this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
  f = context->__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &context->__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)v5;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))context->__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        context->__bound_args_.__base_.__value_.__f_,
        &this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)(*((__int64 (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 2))(f);
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::write_op(
    &this->handler_.handler_,
    &handler->handler_);
  this->handler_.arg2_ = handler->arg2_;
  this->handler_.arg1_ = handler->arg1_;
}


// Address: 0x2635940 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENS0_17mutable_buffers_1ENS1_14transfer_all_tENS0_3ssl6detail5io_opISA_NSE_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSK_8functionIFvRKNSK_10error_codeEEEERKNS_6system10error_codeEEJNSK_10shared_ptrISQ_EERSW_RKNSK_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEESY_mEES1B_EC2EOS1H_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *v2; // r15
  std::function<void (const std::error_code &)>::__base *f; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  v2 = &this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)v2;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        other->context_.__bound_args_.__base_.__value_.__f_,
        v2);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::write_op(
    &this->handler_.handler_,
    &other->handler_.handler_);
  this->handler_.arg2_ = other->handler_.arg2_;
  this->handler_.arg1_ = other->handler_.arg1_;
}


// Address: 0x2635e20 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISB_EERSH_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEclISJ_EEvRKT_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1)
{
  std::__shared_weak_count *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::function<void (const std::error_code &)>::__base *v5; // rax
  std::__shared_weak_count *v6; // rbx
  __int128 v7; // [rsp+0h] [rbp-D8h]
  std::__shared_weak_count *v8[2]; // [rsp+10h] [rbp-C8h]
  _BYTE v9[32]; // [rsp+20h] [rbp-B8h] BYREF
  std::function<void (const std::error_code &)>::__base *v10; // [rsp+40h] [rbp-98h]
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> handler; // [rsp+50h] [rbp-88h] BYREF
  unsigned __int64 v12; // [rsp+B0h] [rbp-28h]

  v12 = __readfsqword(0x28u);
  v7 = *(_OWORD *)&this->handler_.__f_;
  v8[0] = (std::__shared_weak_count *)this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v8[1] = cntrl;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v10 = (std::function<void (const std::error_code &)>::__base *)v9;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v9);
      v5 = v10;
    }
    else
    {
      v5 = (std::function<void (const std::error_code &)>::__base *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *))f->dispatcher_.service_->key_.id_)(f);
      v10 = v5;
    }
  }
  else
  {
    v10 = 0;
    v5 = 0;
  }
  *(_OWORD *)&handler.handler_.__f_ = v7;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)v8;
  if ( v5 )
  {
    if ( v9 == (_BYTE *)v5 )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v5->_vptr$__base
       + 3))(
        v5,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = v5;
      v10 = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = *arg1;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
    &this->dispatcher_,
    &handler);
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v6 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  if ( v9 == (_BYTE *)v10 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v10->_vptr$__base + 4))(v10);
  }
  else if ( v10 )
  {
    (*((void (**)(void))v10->_vptr$__base + 5))();
  }
}


// Address: 0x2656f40 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS9_6config11asio_client16transport_configEEEFvNS7_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeEEJNSH_ISG_EERSQ_RSW_RKNS7_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEESY_EES6_S1B_S1C_EEvRT_PNS4_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> *f; // rdi
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v4; // [rsp+0h] [rbp-1E8h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > handler; // [rsp+E0h] [rbp-108h] BYREF
  unsigned __int64 v6; // [rsp+1D0h] [rbp-18h]

  v6 = __readfsqword(0x28u);
  *(_OWORD *)&v4.context_.__f_ = *(_OWORD *)&this_handler->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul>,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>>::__tuple_impl(
    &v4.context_.__bound_args_.__base_,
    &this_handler->handler_.__bound_args_.__base_);
  v4.handler_.handler_.dispatcher_ = function->handler_.dispatcher_;
  *(_OWORD *)&v4.handler_.handler_.handler_.__f_ = *(_OWORD *)&function->handler_.handler_.__f_;
  v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> *)function->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code> *))f->handler_.dispatcher_.service_->owner_)(f);
    }
    else
    {
      v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = function->handler_.handler_.__bound_args_.__base_.__value_.__f_;
      function->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v4.handler_.arg1_ = function->arg1_;
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &handler,
    &v4);
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    &handler);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler(&handler);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler(&v4);
}


// Address: 0x2657090 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS9_6config11asio_client16transport_configEEEFvNS7_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeEEJNSH_ISG_EERSQ_RSW_RKNS7_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEESY_EES1B_ED2Ev
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::~rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this)
{
  std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *v2; // rax
  std::function<void (const std::error_code &)>::__base *f; // rdi
  volatile signed __int64 *cntrl; // rbx
  volatile signed __int64 *v5; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *v6; // rdi
  volatile signed __int64 *v7; // rbx
  volatile signed __int64 *v8; // rbx

  v2 = &this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
  f = this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v2 == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 4))(f);
  }
  else if ( f )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 5))(f);
  }
  cntrl = (volatile signed __int64 *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
  v5 = (volatile signed __int64 *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
  }
  v6 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)this->context_.__bound_args_.__base_.__value_.__f_;
  if ( &this->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v6 )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *))v6->context_.__f_
     + 4))(v6);
  }
  else if ( v6 )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *))v6->context_.__f_
     + 5))(v6);
  }
  v7 = (volatile signed __int64 *)this->context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v7 && !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(v7);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
  }
  v8 = (volatile signed __int64 *)this->context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8 )
  {
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v8 + 16))(v8);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
  }
}


// Address: 0x2657430 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder1INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS9_6config11asio_client16transport_configEEEFvNS7_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISK_EENS0_22deadline_timer_serviceISK_SM_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeEEJNSH_ISG_EERSQ_RSW_RKNS7_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEESY_EES1B_EC2EOS1F_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  std::function<void (const std::error_code &)>::__base *f; // rax
  std::function<void (const std::error_code &)>::__base *v3; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->context_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.handler_.dispatcher_ = other->handler_.handler_.dispatcher_;
  *(_OWORD *)&this->handler_.handler_.handler_.__f_ = *(_OWORD *)&other->handler_.handler_.handler_.__f_;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  v3 = other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = v3;
      other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.arg1_ = other->handler_.arg1_;
}


// Address: 0x2657630 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config11asio_client16transport_configEEEFvNS5_10shared_ptrINS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISI_EENS0_22deadline_timer_serviceISI_SK_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNSF_ISE_EERSO_RSU_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEclISW_EEvRKT_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1)
{
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v3; // rbx
  std::__shared_weak_count *v4; // rbx
  std::__shared_weak_count *v5; // rbx
  __int128 v6; // [rsp+0h] [rbp-F8h]
  std::__tuple_impl<std::__tuple_indices<0,1,2,3>,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,std::placeholders::__ph<1> > v7; // [rsp+10h] [rbp-E8h] BYREF
  boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code> handler; // [rsp+60h] [rbp-98h] BYREF
  unsigned __int64 v9; // [rsp+D8h] [rbp-20h]

  v9 = __readfsqword(0x28u);
  v6 = *(_OWORD *)&this->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul>,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>>::__tuple_impl(
    &v7,
    &this->handler_.__bound_args_.__base_);
  *(_OWORD *)&handler.handler_.__f_ = v6;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = v7.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  memset(&v7, 0, 32);
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = v7.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  if ( v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    if ( &v7.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *))v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
       + 3))(
        v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_;
      v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = *arg1;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder1<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code>>(
    &this->dispatcher_,
    &handler);
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v3 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(v3);
    std::__shared_weak_count::__release_weak(v3);
  }
  if ( &v7.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 4))(v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_);
  }
  else if ( v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (**)(void))v7.std::__1::__tuple_leaf<2,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 5))();
  }
  v4 = v7.std::__1::__tuple_leaf<1,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_;
  if ( v7.std::__1::__tuple_leaf<1,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v7.std::__1::__tuple_leaf<1,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v4 + 16LL))(v4);
    std::__shared_weak_count::__release_weak(v4);
  }
  v5 = v7.std::__1::__tuple_leaf<0,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_;
  if ( v7.std::__1::__tuple_leaf<0,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v7.std::__1::__tuple_leaf<0,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
      std::__shared_weak_count::__release_weak(v5);
    }
  }
}


// Address: 0x265f7b0 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config11asio_client16transport_configEEEFvRKNS_6system10error_codeEmEJNS5_10shared_ptrISE_EERKNS5_12placeholders4__phILi1EEERKNSO_ILi2EEEEEENS1_26is_continuation_if_runningEEclISG_mEEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const unsigned __int64 *arg2)
{
  __int128 v3; // xmm0
  std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rcx
  std::__shared_weak_count *v6; // rbx
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> v7; // [rsp+0h] [rbp-48h] BYREF

  v3 = *(_OWORD *)&this->handler_.__f_;
  ptr = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  *(_OWORD *)&v7.handler_.__f_ = v3;
  v7.handler_.__bound_args_.__base_.__value_.__ptr_ = ptr;
  v7.handler_.__bound_args_.__base_.__value_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  v7.arg1_ = *arg1;
  v7.arg2_ = *arg2;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
    &this->dispatcher_,
    &v7);
  v6 = v7.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v7.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v7.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
      std::__shared_weak_count::__release_weak(v6);
    }
  }
}


// Address: 0x26638a0 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS9_6config11asio_client16transport_configEEEFvNS7_10shared_ptrINSB_10connectionISF_EEEENSH_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISN_EENS0_22deadline_timer_serviceISN_SP_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS14_3tcpEEEEJPSG_RSK_RST_RSZ_RKNS7_12placeholders4__phILi1EEERKNS1F_ILi2EEEEEENS1_26is_continuation_if_runningEEES11_S17_EES6_S1M_S1N_EEvRT_PNS4_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *f; // rdi
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > v4; // [rsp+0h] [rbp-268h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > handler; // [rsp+120h] [rbp-148h] BYREF
  unsigned __int64 v6; // [rsp+250h] [rbp-18h]

  v6 = __readfsqword(0x28u);
  *(_OWORD *)&v4.context_.__f_ = *(_OWORD *)&this_handler->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul,4ul,5ul>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>,std::placeholders::__ph<2>>::__tuple_impl(
    &v4.context_.__bound_args_.__base_,
    &this_handler->handler_.__bound_args_.__base_);
  v4.handler_.handler_.dispatcher_ = function->handler_.dispatcher_;
  *(_OWORD *)&v4.handler_.handler_.handler_.__f_ = *(_OWORD *)&function->handler_.handler_.__f_;
  *(_OWORD *)&v4.handler_.handler_.handler_.__bound_args_.__base_.__value_ = *(_OWORD *)&function->handler_.handler_.__bound_args_.__base_.__value_;
  v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ = function->handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)function->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &function->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v4.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *))f->handler_.dispatcher_.service_->owner_)(f);
    }
    else
    {
      v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = function->handler_.handler_.__bound_args_.__base_.__value_.__f_;
      function->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v4.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v4.handler_.arg1_ = function->arg1_;
  v4.handler_.arg2_.values_ = function->arg2_.values_;
  function->arg2_.values_ = 0;
  v4.handler_.arg2_.index_ = function->arg2_.index_;
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
    &handler,
    &v4);
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    &handler);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(&handler);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(&v4);
}


// Address: 0x2663a30 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS9_6config11asio_client16transport_configEEEFvNS7_10shared_ptrINSB_10connectionISF_EEEENSH_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISN_EENS0_22deadline_timer_serviceISN_SP_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS14_3tcpEEEEJPSG_RSK_RST_RSZ_RKNS7_12placeholders4__phILi1EEERKNS1F_ILi2EEEEEENS1_26is_continuation_if_runningEEES11_S17_EES1M_ED2Ev
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this)
{
  volatile signed __int64 *cntrl; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *f; // rdi
  volatile signed __int64 *v4; // rbx
  volatile signed __int64 *v5; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *v6; // rdi
  volatile signed __int64 *v7; // rbx
  volatile signed __int64 *v8; // rbx

  cntrl = (volatile signed __int64 *)this->handler_.arg2_.values_.__cntrl_;
  if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
  }
  f = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( &this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))f->context_.__f_
     + 4))(f);
  }
  else if ( f )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))f->context_.__f_
     + 5))(f);
  }
  v4 = (volatile signed __int64 *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
  }
  v5 = (volatile signed __int64 *)this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v5 && !_InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
  }
  v6 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)this->context_.__bound_args_.__base_.__value_.__f_;
  if ( &this->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v6 )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))v6->context_.__f_
     + 4))(v6);
  }
  else if ( v6 )
  {
    (*((void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))v6->context_.__f_
     + 5))(v6);
  }
  v7 = (volatile signed __int64 *)this->context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v7 && !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(v7);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
  }
  v8 = (volatile signed __int64 *)this->context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8 )
  {
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v8 + 16))(v8);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
  }
}


// Address: 0x2663e10 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS9_6config11asio_client16transport_configEEEFvNS7_10shared_ptrINSB_10connectionISF_EEEENSH_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISN_EENS0_22deadline_timer_serviceISN_SP_EEEEEENS7_8functionIFvRKNS7_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS14_3tcpEEEEJPSG_RSK_RST_RSZ_RKNS7_12placeholders4__phILi1EEERKNS1F_ILi2EEEEEENS1_26is_continuation_if_runningEEES11_S17_EES1M_EC2EOS1Q_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *other)
{
  std::function<void (const std::error_code &)>::__base *f; // rax
  std::function<void (const std::error_code &)>::__base *v3; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.__value_ = other->context_.__bound_args_.__base_.__value_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->context_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.handler_.dispatcher_ = other->handler_.handler_.dispatcher_;
  *(_OWORD *)&this->handler_.handler_.handler_.__f_ = *(_OWORD *)&other->handler_.handler_.handler_.__f_;
  this->handler_.handler_.handler_.__bound_args_.__base_.__value_ = other->handler_.handler_.handler_.__bound_args_.__base_.__value_;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  v3 = other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( v3 )
  {
    if ( &other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v3 )
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = v3;
      other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  this->handler_.arg1_ = other->handler_.arg1_;
  this->handler_.arg2_.values_ = other->handler_.arg2_.values_;
  other->handler_.arg2_.values_ = 0;
  this->handler_.arg2_.index_ = other->handler_.arg2_.index_;
}


// Address: 0x2664050 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS7_6config11asio_client16transport_configEEEFvNS5_10shared_ptrINS9_10connectionISD_EEEENSF_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeENS0_2ip23basic_resolver_iteratorINS12_3tcpEEEEJPSE_RSI_RSR_RSX_RKNS5_12placeholders4__phILi1EEERKNS1D_ILi2EEEEEENS1_26is_continuation_if_runningEEclISZ_S15_EEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *arg2)
{
  volatile signed __int64 *cntrl; // rcx
  size_t index; // rcx
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7; // rbx
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  __int128 v14; // [rsp+0h] [rbp-1E8h]
  std::__tuple_impl<std::__tuple_indices<0,1,2,3,4,5>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,std::placeholders::__ph<1>,std::placeholders::__ph<2> > v15; // [rsp+10h] [rbp-1D8h] BYREF
  __int128 v16; // [rsp+70h] [rbp-178h]
  _BYTE v17[24]; // [rsp+80h] [rbp-168h]
  std::__shared_weak_count *v18[2]; // [rsp+98h] [rbp-150h]
  _BYTE v19[32]; // [rsp+B0h] [rbp-138h] BYREF
  std::function<void (const std::error_code &)>::__base *f; // [rsp+D0h] [rbp-118h]
  boost::system::error_code v21; // [rsp+E0h] [rbp-108h]
  std::__shared_weak_count *v22[2]; // [rsp+F0h] [rbp-F8h]
  size_t v23; // [rsp+100h] [rbp-E8h]
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > handler; // [rsp+110h] [rbp-D8h] BYREF
  unsigned __int64 v25; // [rsp+1C0h] [rbp-28h]

  v25 = __readfsqword(0x28u);
  v14 = *(_OWORD *)&this->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul,4ul,5ul>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>,std::placeholders::__ph<2>>::__tuple_impl(
    &v15,
    &this->handler_.__bound_args_.__base_);
  v16 = v14;
  *(_OWORD *)v17 = *(_OWORD *)&v15.std::__1::__tuple_leaf<0,websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,false>::__value_;
  *(_QWORD *)&v17[16] = v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_;
  memset(
    &v15.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>,
    0,
    32);
  *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)v18 = v15.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  if ( v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    if ( &v15.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
    {
      f = (std::function<void (const std::error_code &)>::__base *)v19;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
       + 3))(
        v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_,
        v19);
    }
    else
    {
      f = v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_;
      v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ = 0;
    }
  }
  else
  {
    f = 0;
  }
  v21 = *arg1;
  v22[0] = (std::__shared_weak_count *)arg2->values_.__ptr_;
  cntrl = (volatile signed __int64 *)arg2->values_.__cntrl_;
  v22[1] = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  index = arg2->index_;
  v23 = index;
  *(_OWORD *)&handler.handler_.__f_ = v16;
  *(_OWORD *)&handler.handler_.__bound_args_.__base_.__value_ = *(_OWORD *)v17;
  handler.handler_.__bound_args_.__base_.__value_.__cntrl_ = *(std::__shared_weak_count **)&v17[16];
  *(_OWORD *)&v17[8] = 0;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)v18;
  *(_OWORD *)v18 = 0;
  if ( f )
  {
    if ( v19 == (_BYTE *)f )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *))f->_vptr$__base
       + 3))(
        f,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>);
      index = v23;
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = f;
      f = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = v21;
  handler.arg2_.values_ = *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)v22;
  *(_OWORD *)v22 = 0;
  handler.arg2_.index_ = index;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>(
    this->dispatcher_.service_,
    &this->dispatcher_.impl_,
    &handler);
  v6 = handler.arg2_.values_.__cntrl_;
  if ( handler.arg2_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)handler.arg2_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v7 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  v8 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  v9 = v22[1];
  if ( v22[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
    std::__shared_weak_count::__release_weak(v9);
  }
  if ( v19 == (_BYTE *)f )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 4))(f);
  }
  else if ( f )
  {
    (*((void (**)(void))f->_vptr$__base + 5))();
  }
  v10 = v18[1];
  if ( v18[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  v11 = *(std::__shared_weak_count **)&v17[16];
  if ( *(_QWORD *)&v17[16]
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v17[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  if ( &v15.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 4))(v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_);
  }
  else if ( v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (**)(void))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 5))();
  }
  v12 = v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_;
  if ( v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  v13 = v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_;
  if ( v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x2666ac0 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINS7_6config11asio_client16transport_configEEEFvNS5_10shared_ptrINS9_10connectionISD_EEEENSF_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISL_EENS0_22deadline_timer_serviceISL_SN_EEEEEENS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJPSE_RSI_RSR_RSX_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEclISZ_NS0_2ip23basic_resolver_iteratorINS1H_3tcpEEEEEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> *arg2)
{
  volatile signed __int64 *cntrl; // rcx
  size_t index; // rcx
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7; // rbx
  std::__shared_weak_count *v8; // rbx
  std::__shared_weak_count *v9; // rbx
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  __int128 v14; // [rsp+0h] [rbp-1E8h]
  std::__tuple_impl<std::__tuple_indices<0,1,2,3,4>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,std::placeholders::__ph<1> > v15; // [rsp+10h] [rbp-1D8h] BYREF
  __int128 v16; // [rsp+70h] [rbp-178h]
  _BYTE v17[24]; // [rsp+80h] [rbp-168h]
  std::__shared_weak_count *v18[2]; // [rsp+98h] [rbp-150h]
  _BYTE v19[32]; // [rsp+B0h] [rbp-138h] BYREF
  std::function<void (const std::error_code &)>::__base *f; // [rsp+D0h] [rbp-118h]
  boost::system::error_code v21; // [rsp+E0h] [rbp-108h]
  std::__shared_weak_count *v22[2]; // [rsp+F0h] [rbp-F8h]
  size_t v23; // [rsp+100h] [rbp-E8h]
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > handler; // [rsp+110h] [rbp-D8h] BYREF
  unsigned __int64 v25; // [rsp+1C0h] [rbp-28h]

  v25 = __readfsqword(0x28u);
  v14 = *(_OWORD *)&this->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul,4ul>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>>::__tuple_impl(
    &v15,
    &this->handler_.__bound_args_.__base_);
  v16 = v14;
  *(_OWORD *)v17 = *(_OWORD *)&v15.std::__1::__tuple_leaf<0,websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,false>::__value_;
  *(_QWORD *)&v17[16] = v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_;
  memset(
    &v15.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>,
    0,
    32);
  *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)v18 = v15.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  if ( v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    if ( &v15.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
    {
      f = (std::function<void (const std::error_code &)>::__base *)v19;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
       + 3))(
        v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_,
        v19);
    }
    else
    {
      f = v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_;
      v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ = 0;
    }
  }
  else
  {
    f = 0;
  }
  v21 = *arg1;
  v22[0] = (std::__shared_weak_count *)arg2->values_.__ptr_;
  cntrl = (volatile signed __int64 *)arg2->values_.__cntrl_;
  v22[1] = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  index = arg2->index_;
  v23 = index;
  *(_OWORD *)&handler.handler_.__f_ = v16;
  *(_OWORD *)&handler.handler_.__bound_args_.__base_.__value_ = *(_OWORD *)v17;
  handler.handler_.__bound_args_.__base_.__value_.__cntrl_ = *(std::__shared_weak_count **)&v17[16];
  *(_OWORD *)&v17[8] = 0;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)v18;
  *(_OWORD *)v18 = 0;
  if ( f )
  {
    if ( v19 == (_BYTE *)f )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *))f->_vptr$__base
       + 3))(
        f,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>);
      index = v23;
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = f;
      f = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = v21;
  handler.arg2_.values_ = *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)v22;
  *(_OWORD *)v22 = 0;
  handler.arg2_.index_ = index;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>(
    this->dispatcher_.service_,
    &this->dispatcher_.impl_,
    &handler);
  v6 = handler.arg2_.values_.__cntrl_;
  if ( handler.arg2_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)handler.arg2_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v7 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
    std::__shared_weak_count::__release_weak(v7);
  }
  v8 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  v9 = v22[1];
  if ( v22[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
    std::__shared_weak_count::__release_weak(v9);
  }
  if ( v19 == (_BYTE *)f )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base + 4))(f);
  }
  else if ( f )
  {
    (*((void (**)(void))f->_vptr$__base + 5))();
  }
  v10 = v18[1];
  if ( v18[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  v11 = *(std::__shared_weak_count **)&v17[16];
  if ( *(_QWORD *)&v17[16]
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)(*(_QWORD *)&v17[16] + 8LL), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  if ( &v15.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 4))(v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_);
  }
  else if ( v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_ )
  {
    (*((void (**)(void))v15.std::__1::__tuple_leaf<3,std::__1::function<void (const std::__1::error_code &)>,false>::__value_.__f_->_vptr$__base
     + 5))();
  }
  v12 = v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_;
  if ( v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v15.std::__1::__tuple_leaf<2,std::__1::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>::__value_.__cntrl_
        + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  v13 = v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_;
  if ( v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v15.std::__1::__tuple_leaf<1,std::__1::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>::__value_.__cntrl_
          + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x26673b0 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EENS5_23basic_resolver_iteratorIS6_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSH_6config11asio_client16transport_configEEEFvNSF_10shared_ptrINSJ_10connectionISN_EEEENSP_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISV_EENS0_22deadline_timer_serviceISV_SX_EEEEEENSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJPSO_RSS_RS11_RS17_RKNSF_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES19_EESE_S1N_S1O_EEvRT_PNSC_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  boost::asio::detail::strand_service::implementation_type *p_impl; // rsi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v6; // rbx
  std::__shared_weak_count *v7; // rbx
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v8; // [rsp+0h] [rbp-2B8h] BYREF
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > handler; // [rsp+140h] [rbp-178h] BYREF
  unsigned __int64 v10; // [rsp+298h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v8.context_.__f_ = *(_OWORD *)&this_handler->handler_.__f_;
  std::__tuple_impl<std::__tuple_indices<0ul,1ul,2ul,3ul,4ul>,websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,std::placeholders::__ph<1>>::__tuple_impl(
    &v8.context_.__bound_args_.__base_,
    &this_handler->handler_.__bound_args_.__base_);
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    &v8.handler_.handler_,
    &function->handler_);
  v8.handler_.arg1_ = function->arg1_;
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    &handler,
    &v8);
  p_impl = &this_handler->dispatcher_.impl_;
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    &handler);
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&handler.handler_.handler_);
  if ( &handler.context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)handler.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::strand_service::implementation_type *))handler.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(
      handler.context_.__bound_args_.__base_.__value_.__f_,
      p_impl);
  }
  cntrl = handler.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v5 = handler.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
  }
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::~connect_op(&v8.handler_.handler_);
  if ( &v8.context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)v8.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.context_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.context_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, boost::asio::detail::strand_service::implementation_type *))v8.context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 5))(
      v8.context_.__bound_args_.__base_.__value_.__f_,
      p_impl);
  }
  v6 = v8.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.context_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v8.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
    std::__shared_weak_count::__release_weak(v6);
  }
  v7 = v8.context_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.context_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v8.context_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v7 + 16LL))(v7);
      std::__shared_weak_count::__release_weak(v7);
    }
  }
}


// Address: 0x26679a0 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder1INS1_10connect_opINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EENS5_23basic_resolver_iteratorIS6_EENS1_25default_connect_conditionENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSH_6config11asio_client16transport_configEEEFvNSF_10shared_ptrINSJ_10connectionISN_EEEENSP_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISV_EENS0_22deadline_timer_serviceISV_SX_EEEEEENSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJPSO_RSS_RS11_RS17_RKNSF_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES19_EES1N_EC2EOS1S_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder1<boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code>,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *v2; // r12
  std::function<void (const std::error_code &)>::__base *f; // rax

  *(_OWORD *)&this->context_.__f_ = *(_OWORD *)&other->context_.__f_;
  this->context_.__bound_args_.__base_.__value_ = other->context_.__bound_args_.__base_.__value_;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  this->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  other->context_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  v2 = &this->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
  f = other->context_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->context_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)v2;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *))other->context_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        other->context_.__bound_args_.__base_.__value_.__f_,
        v2);
    }
    else
    {
      this->context_.__bound_args_.__base_.__value_.__f_ = f;
      other->context_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->context_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::connect_op<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,boost::asio::detail::default_connect_condition,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::connect_op(
    &this->handler_.handler_,
    &other->handler_.handler_);
  this->handler_.arg1_ = other->handler_.arg1_;
}


// Address: 0x266b3a0 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config11asio_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEEJNS5_10shared_ptrISE_EERSK_RKNS5_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEclISM_mEEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const unsigned __int64 *arg2)
{
  std::__shared_weak_count *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::function<void (const std::error_code &)>::__base *v7; // rax
  std::__shared_weak_count *v8; // rbx
  __int128 v9; // [rsp+0h] [rbp-F8h]
  std::__shared_weak_count *v10[2]; // [rsp+10h] [rbp-E8h]
  _BYTE v11[32]; // [rsp+20h] [rbp-D8h] BYREF
  std::function<void (const std::error_code &)>::__base *v12; // [rsp+40h] [rbp-B8h]
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::system::error_code,unsigned long> handler; // [rsp+50h] [rbp-A8h] BYREF
  unsigned __int64 v14; // [rsp+C8h] [rbp-30h]

  v14 = __readfsqword(0x28u);
  v9 = *(_OWORD *)&this->handler_.__f_;
  v10[0] = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v10[1] = cntrl;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v12 = (std::function<void (const std::error_code &)>::__base *)v11;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v11);
      v7 = v12;
    }
    else
    {
      v7 = (std::function<void (const std::error_code &)>::__base *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *))f->dispatcher_.service_->key_.id_)(f);
      v12 = v7;
    }
  }
  else
  {
    v12 = 0;
    v7 = 0;
  }
  *(_OWORD *)&handler.handler_.__f_ = v9;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)v10;
  if ( v7 )
  {
    if ( v11 == (_BYTE *)v7 )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v7->_vptr$__base
       + 3))(
        v7,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = v7;
      v12 = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = *arg1;
  handler.arg2_ = *arg2;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::system::error_code,unsigned long>>(
    &this->dispatcher_,
    &handler);
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v8 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  if ( v11 == (_BYTE *)v12 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v12->_vptr$__base + 4))(v12);
  }
  else if ( v12 )
  {
    (*((void (**)(void))v12->_vptr$__base + 5))();
  }
}


// Address: 0x266bcc0 | Name: _ZN5boost4asio6detail19asio_handler_invokeINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__16vectorINS0_12const_bufferENSB_9allocatorISD_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSM_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrIST_EERSZ_RKNSB_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES11_mEESK_S1E_S1F_EEvRT_PNSI_IT0_T1_T2_EE
void __fastcall boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>(
        boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *function,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *this_handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  volatile signed __int64 *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *v9; // rdi
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  __int128 v14; // [rsp+0h] [rbp-298h] BYREF
  std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *v15; // [rsp+10h] [rbp-288h]
  std::__shared_weak_count *v16; // [rsp+18h] [rbp-280h]
  _BYTE v17[32]; // [rsp+20h] [rbp-278h] BYREF
  _BYTE *v18; // [rsp+40h] [rbp-258h]
  __int64 v19; // [rsp+50h] [rbp-248h]
  void *v20[8]; // [rsp+58h] [rbp-240h] BYREF
  int v21; // [rsp+98h] [rbp-200h]
  __int64 v22; // [rsp+A0h] [rbp-1F8h]
  __int128 v23; // [rsp+B0h] [rbp-1E8h]
  __int128 v24; // [rsp+C0h] [rbp-1D8h]
  std::__shared_weak_count *v25[2]; // [rsp+D0h] [rbp-1C8h]
  _BYTE v26[32]; // [rsp+E0h] [rbp-1B8h] BYREF
  _BYTE *v27; // [rsp+100h] [rbp-198h]
  __int128 v28; // [rsp+110h] [rbp-188h]
  __int64 v29; // [rsp+120h] [rbp-178h]
  _BYTE v30[24]; // [rsp+130h] [rbp-168h] BYREF
  std::__shared_weak_count *v31; // [rsp+148h] [rbp-150h]
  char v32; // [rsp+150h] [rbp-148h] BYREF
  char *v33; // [rsp+170h] [rbp-128h]
  void *ptr; // [rsp+188h] [rbp-110h]
  void *v35; // [rsp+190h] [rbp-108h]
  std::__shared_weak_count *v36; // [rsp+208h] [rbp-90h]
  char v37; // [rsp+210h] [rbp-88h] BYREF
  char *v38; // [rsp+230h] [rbp-68h]
  unsigned __int64 v39; // [rsp+270h] [rbp-28h]

  v39 = __readfsqword(0x28u);
  v14 = *(_OWORD *)&this_handler->handler_.__f_;
  v15 = this_handler->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = (volatile signed __int64 *)this_handler->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v16 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this_handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this_handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v18 = v17;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *, __int64, __int64, __int64, __int64, _QWORD, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *))f->dispatcher_.service_->owner_)(
        f,
        v17,
        v2,
        v3,
        v4,
        v5,
        v14,
        *((_QWORD *)&v14 + 1),
        v15);
    }
    else
    {
      v18 = (_BYTE *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, __int64, __int64, __int64, __int64, _QWORD, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *))f->dispatcher_.service_->key_.id_)(
                       f,
                       this_handler,
                       v2,
                       v3,
                       v4,
                       v5,
                       v14,
                       *((_QWORD *)&v14 + 1),
                       v15);
    }
  }
  else
  {
    v18 = 0;
  }
  v19 = *(_QWORD *)function;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)v20,
    (boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)((char *)function + 8));
  v21 = *((_DWORD *)function + 18);
  v22 = *((_QWORD *)function + 10);
  v23 = *((_OWORD *)function + 6);
  v24 = *((_OWORD *)function + 7);
  *(_OWORD *)v25 = *((_OWORD *)function + 8);
  *((_OWORD *)function + 8) = 0;
  v9 = (boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)*((_QWORD *)function + 22);
  if ( v9 )
  {
    if ( (boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)((char *)function + 144) == v9 )
    {
      v27 = v26;
      (*(void (__fastcall **)(boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *, _BYTE *))(*(_QWORD *)v9 + 24LL))(
        v9,
        v26);
    }
    else
    {
      v27 = (_BYTE *)*((_QWORD *)function + 22);
      *((_QWORD *)function + 22) = 0;
    }
  }
  else
  {
    v27 = 0;
  }
  v29 = *((_QWORD *)function + 26);
  v28 = *((_OWORD *)function + 12);
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)v30,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)&v14);
  boost::asio::detail::strand_service::dispatch<boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    this_handler->dispatcher_.service_,
    &this_handler->dispatcher_.impl_,
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)v30);
  if ( &v37 == v38 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v38 + 32LL))(v38);
  }
  else if ( v38 )
  {
    (*(void (**)(void))(*(_QWORD *)v38 + 40LL))();
  }
  v10 = v36;
  if ( v36 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v36 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v10 + 16LL))(v10);
    std::__shared_weak_count::__release_weak(v10);
  }
  if ( ptr )
  {
    v35 = ptr;
    operator delete(ptr);
  }
  if ( &v32 == v33 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v33 + 32LL))(v33);
  }
  else if ( v33 )
  {
    (*(void (**)(void))(*(_QWORD *)v33 + 40LL))();
  }
  v11 = v31;
  if ( v31 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v31 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  if ( v26 == v27 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v27 + 32LL))(v27);
  }
  else if ( v27 )
  {
    (*(void (**)(void))(*(_QWORD *)v27 + 40LL))();
  }
  v12 = v25[1];
  if ( v25[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v25[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  if ( v20[0] )
  {
    v20[1] = v20[0];
    operator delete(v20[0]);
  }
  if ( v17 == v18 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v18 + 32LL))(v18);
  }
  else if ( v18 )
  {
    (*(void (**)(void))(*(_QWORD *)v18 + 40LL))();
  }
  v13 = v16;
  if ( v16 )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v16 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
      std::__shared_weak_count::__release_weak(v13);
    }
  }
}


// Address: 0x266c4b0 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__16vectorINS0_12const_bufferENSB_9allocatorISD_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSM_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrIST_EERSZ_RKNSB_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEES11_mEES1E_EC2EOS1J_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *other)
{
  char *v2; // r15
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *v3; // rax
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *v4; // rax

  *(_OWORD *)this = *(_OWORD *)other;
  *((_OWORD *)this + 1) = *((_OWORD *)other + 1);
  *((_OWORD *)other + 1) = 0;
  v2 = (char *)this + 32;
  v3 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)*((_QWORD *)other + 8);
  if ( v3 )
  {
    if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)other + 32) == v3 )
    {
      *((_QWORD *)this + 8) = v2;
      (*(void (__fastcall **)(_QWORD, char *))(**((_QWORD **)other + 8) + 24LL))(*((_QWORD *)other + 8), v2);
    }
    else
    {
      *((_QWORD *)this + 8) = v3;
      *((_QWORD *)other + 8) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 8) = 0;
  }
  *((_QWORD *)this + 10) = *((_QWORD *)other + 10);
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)this + 88),
    (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)other + 88));
  *((_DWORD *)this + 38) = *((_DWORD *)other + 38);
  *((_QWORD *)this + 20) = *((_QWORD *)other + 20);
  *((_OWORD *)this + 11) = *((_OWORD *)other + 11);
  *((_OWORD *)this + 12) = *((_OWORD *)other + 12);
  *((_OWORD *)this + 13) = *((_OWORD *)other + 13);
  *((_OWORD *)other + 13) = 0;
  v4 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)*((_QWORD *)other + 32);
  if ( v4 )
  {
    if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)((char *)other + 224) == v4 )
    {
      *((_QWORD *)this + 32) = (char *)this + 224;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)other + 32) + 24LL))(*((_QWORD *)other + 32));
    }
    else
    {
      *((_QWORD *)this + 32) = v4;
      *((_QWORD *)other + 32) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 32) = 0;
  }
  *((_QWORD *)this + 36) = *((_QWORD *)other + 36);
  *((_OWORD *)this + 17) = *((_OWORD *)other + 17);
}


// Address: 0x266e9b0 | Name: _ZN5boost4asio6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINS7_6config11asio_client16transport_configEEEFvNS5_8functionIFvRKNS5_10error_codeEEEERKNS_6system10error_codeEmEJNS5_10shared_ptrISE_EERSK_RKNS5_12placeholders4__phILi1EEERKNSV_ILi2EEEEEENS1_26is_continuation_if_runningEEclISM_mEEvRKT_RKT0_
void __fastcall boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *this,
        const boost::system::error_code *arg1,
        const unsigned __int64 *arg2)
{
  std::__shared_weak_count *cntrl; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::function<void (const std::error_code &)>::__base *v7; // rax
  std::__shared_weak_count *v8; // rbx
  __int128 v9; // [rsp+0h] [rbp-F8h]
  std::__shared_weak_count *v10[2]; // [rsp+10h] [rbp-E8h]
  _BYTE v11[32]; // [rsp+20h] [rbp-D8h] BYREF
  std::function<void (const std::error_code &)>::__base *v12; // [rsp+40h] [rbp-B8h]
  boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::system::error_code,unsigned long> handler; // [rsp+50h] [rbp-A8h] BYREF
  unsigned __int64 v14; // [rsp+C8h] [rbp-30h]

  v14 = __readfsqword(0x28u);
  v9 = *(_OWORD *)&this->handler_.__f_;
  v10[0] = this->handler_.__bound_args_.__base_.__value_.__ptr_;
  cntrl = this->handler_.__bound_args_.__base_.__value_.__cntrl_;
  v10[1] = cntrl;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *)this->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &this->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v12 = (std::function<void (const std::error_code &)>::__base *)v11;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v11);
      v7 = v12;
    }
    else
    {
      v7 = (std::function<void (const std::error_code &)>::__base *)((__int64 (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *))f->dispatcher_.service_->key_.id_)(f);
      v12 = v7;
    }
  }
  else
  {
    v12 = 0;
    v7 = 0;
  }
  *(_OWORD *)&handler.handler_.__f_ = v9;
  handler.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)v10;
  if ( v7 )
  {
    if ( v11 == (_BYTE *)v7 )
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))v7->_vptr$__base
       + 3))(
        v7,
        &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      handler.handler_.__bound_args_.__base_.__value_.__f_ = v7;
      v12 = 0;
    }
  }
  else
  {
    handler.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  handler.arg1_ = *arg1;
  handler.arg2_ = *arg2;
  boost::asio::io_service::strand::dispatch<boost::asio::detail::binder2<std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::system::error_code,unsigned long>>(
    &this->dispatcher_,
    &handler);
  if ( &handler.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(handler.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( handler.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))handler.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  v8 = handler.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( handler.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)handler.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
    std::__shared_weak_count::__release_weak(v8);
  }
  if ( v11 == (_BYTE *)v12 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v12->_vptr$__base + 4))(v12);
  }
  else if ( v12 )
  {
    (*((void (**)(void))v12->_vptr$__base + 5))();
  }
}


// Address: 0x266f250 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESX_mEES1D_EC2ERS1H_RKS1D_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this,
        boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *handler,
        const std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> *context)
{
  std::__shared_weak_count *cntrl; // rax
  std::function<void (const std::error_code &)>::__base *f; // rdi
  boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *v6; // rax

  *(_OWORD *)this = *(_OWORD *)&context->__f_;
  *((_QWORD *)this + 2) = context->__bound_args_.__base_.__value_.__ptr_;
  cntrl = context->__bound_args_.__base_.__value_.__cntrl_;
  *((_QWORD *)this + 3) = cntrl;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  f = context->__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &context->__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)this + 8) = (char *)this + 32;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))context->__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(context->__bound_args_.__base_.__value_.__f_);
    }
    else
    {
      *((_QWORD *)this + 8) = (*((__int64 (__fastcall **)(std::function<void (const std::error_code &)>::__base *))f->_vptr$__base
                               + 2))(f);
    }
  }
  else
  {
    *((_QWORD *)this + 8) = 0;
  }
  *((_QWORD *)this + 10) = *(_QWORD *)handler;
  *((_QWORD *)this + 11) = *((_QWORD *)handler + 1);
  *((_QWORD *)this + 14) = *((_QWORD *)handler + 4);
  *((_OWORD *)this + 6) = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  *((_DWORD *)this + 30) = *((_DWORD *)handler + 10);
  *((_QWORD *)this + 16) = *((_QWORD *)handler + 6);
  *((_OWORD *)this + 9) = *((_OWORD *)handler + 4);
  *((_OWORD *)this + 10) = *((_OWORD *)handler + 5);
  *((_OWORD *)this + 11) = *((_OWORD *)handler + 6);
  *((_OWORD *)handler + 6) = 0;
  v6 = (boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)*((_QWORD *)handler + 18);
  if ( v6 )
  {
    if ( (boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long> *)((char *)handler + 112) == v6 )
    {
      *((_QWORD *)this + 28) = (char *)this + 192;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)handler + 18) + 24LL))(*((_QWORD *)handler + 18));
    }
    else
    {
      *((_QWORD *)this + 28) = v6;
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 28) = 0;
  }
  *((_QWORD *)this + 32) = *((_QWORD *)handler + 22);
  *((_OWORD *)this + 15) = *((_OWORD *)handler + 10);
}


// Address: 0x266f3e0 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESX_mEES1D_ED2Ev
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::~rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this)
{
  char *v2; // rax
  char *v3; // rdi
  volatile signed __int64 *v4; // r14
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *v5; // rdi
  volatile signed __int64 *v6; // rbx

  v2 = (char *)this + 192;
  v3 = (char *)*((_QWORD *)this + 28);
  if ( v2 == v3 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + 32LL))(v3);
  }
  else if ( v3 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + 40LL))(v3);
  }
  v4 = (volatile signed __int64 *)*((_QWORD *)this + 23);
  if ( !v4 || _InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    if ( (*((_BYTE *)this + 96) & 1) == 0 )
      goto LABEL_9;
    goto LABEL_8;
  }
  (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
  std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
LABEL_8:
    operator delete(*((void **)this + 14));
LABEL_9:
  v5 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)*((_QWORD *)this + 8);
  if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)((char *)this + 32) == v5 )
  {
    (*(void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))(*(_QWORD *)v5 + 32LL))(v5);
  }
  else if ( v5 )
  {
    (*(void (__fastcall **)(boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *))(*(_QWORD *)v5 + 40LL))(v5);
  }
  v6 = (volatile signed __int64 *)*((_QWORD *)this + 3);
  if ( v6 )
  {
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v6 + 16))(v6);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
  }
}


// Address: 0x266f740 | Name: _ZN5boost4asio6detail17rewrapped_handlerINS1_7binder2INS1_26read_until_delim_string_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEENSt3__19allocatorIcEENS1_15wrapped_handlerINS0_10io_service6strandENSB_6__bindIMN11websocketpp9transport4asio10connectionINSI_6config11asio_client16transport_configEEEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEmEJNSB_10shared_ptrISP_EERSV_RKNSB_12placeholders4__phILi1EEERKNS16_ILi2EEEEEENS1_26is_continuation_if_runningEEEEESX_mEES1D_EC2EOS1I_
void __fastcall boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>>::rewrapped_handler(
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *this,
        boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *other)
{
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *v2; // rax
  boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *v3; // rax

  *(_OWORD *)this = *(_OWORD *)other;
  *((_OWORD *)this + 1) = *((_OWORD *)other + 1);
  *((_OWORD *)other + 1) = 0;
  v2 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)*((_QWORD *)other + 8);
  if ( v2 )
  {
    if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)((char *)other + 32) == v2 )
    {
      *((_QWORD *)this + 8) = (char *)this + 32;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)other + 8) + 24LL))(*((_QWORD *)other + 8));
    }
    else
    {
      *((_QWORD *)this + 8) = v2;
      *((_QWORD *)other + 8) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 8) = 0;
  }
  *((_QWORD *)this + 10) = *((_QWORD *)other + 10);
  *((_QWORD *)this + 11) = *((_QWORD *)other + 11);
  *((_QWORD *)this + 14) = *((_QWORD *)other + 14);
  *((_OWORD *)this + 6) = *((_OWORD *)other + 6);
  *((_OWORD *)other + 6) = 0;
  *((_QWORD *)other + 14) = 0;
  *((_DWORD *)this + 30) = *((_DWORD *)other + 30);
  *((_QWORD *)this + 16) = *((_QWORD *)other + 16);
  *((_OWORD *)this + 9) = *((_OWORD *)other + 9);
  *((_OWORD *)this + 10) = *((_OWORD *)other + 10);
  *((_OWORD *)this + 11) = *((_OWORD *)other + 11);
  *((_OWORD *)other + 11) = 0;
  v3 = (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)*((_QWORD *)other + 28);
  if ( v3 )
  {
    if ( (boost::asio::detail::rewrapped_handler<boost::asio::detail::binder2<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >,boost::system::error_code,unsigned long>,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &,unsigned long),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &> > *)((char *)other + 192) == v3 )
    {
      *((_QWORD *)this + 28) = (char *)this + 192;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)other + 28) + 24LL))(*((_QWORD *)other + 28));
    }
    else
    {
      *((_QWORD *)this + 28) = v3;
      *((_QWORD *)other + 28) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 28) = 0;
  }
  *((_QWORD *)this + 32) = *((_QWORD *)other + 32);
  *((_OWORD *)this + 15) = *((_OWORD *)other + 15);
}


