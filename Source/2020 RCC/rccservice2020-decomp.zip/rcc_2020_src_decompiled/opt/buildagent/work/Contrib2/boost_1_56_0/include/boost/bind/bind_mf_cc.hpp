// Address: 0xdb3260 | Name: _ZN5boost4bindIv11CWebServiceNS_10shared_ptrINS1_7JobItemEEEPS1_S4_EENS_3_bi6bind_tIT_NS_4_mfi3mf1IS8_T0_T1_EENS6_9list_av_2IT2_T3_E4typeEEEMSB_FS8_SC_ESF_SG_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,CWebService,boost::shared_ptr<CWebService::JobItem> >,boost::_bi::list2<boost::_bi::value<CWebService *>,boost::_bi::value<boost::shared_ptr<CWebService::JobItem> > > > *__fastcall boost::bind<void,CWebService,boost::shared_ptr<CWebService::JobItem>,CWebService*,boost::shared_ptr<CWebService::JobItem>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,CWebService,boost::shared_ptr<CWebService::JobItem> >,boost::_bi::list2<boost::_bi::value<CWebService *>,boost::_bi::value<boost::shared_ptr<CWebService::JobItem> > > > *__return_ptr retstr,
        void (*f)(CWebService *, boost::shared_ptr<CWebService::JobItem>),
        CWebService *a1,
        boost::shared_ptr<CWebService::JobItem> a2)
{
  CWebService *px; // r15
  int (**v6)(void); // rbp
  boost::detail::sp_counted_base *v7; // rbx

  px = (CWebService *)a2.px;
  v6 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v6;
  retstr->l_.a2_.t_.pn.pi_ = v7;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  return retstr;
}


// Address: 0xdb3870 | Name: _ZN5boost4bindIv11CWebServiceRNS_10shared_ptrIN3RBX9DataModelEEEPS1_S5_EENS_3_bi6bind_tIT_NS_4_mfi3mf1ISA_T0_T1_EENS8_9list_av_2IT2_T3_E4typeEEEMSD_FSA_SE_ESH_SI_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,CWebService,boost::shared_ptr<RBX::DataModel> &>,boost::_bi::list2<boost::_bi::value<CWebService *>,boost::_bi::value<boost::shared_ptr<RBX::DataModel> > > > *__fastcall boost::bind<void,CWebService,boost::shared_ptr<RBX::DataModel> &,CWebService*,boost::shared_ptr<RBX::DataModel>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,CWebService,boost::shared_ptr<RBX::DataModel> &>,boost::_bi::list2<boost::_bi::value<CWebService *>,boost::_bi::value<boost::shared_ptr<RBX::DataModel> > > > *__return_ptr retstr,
        void (*f)(CWebService *, boost::shared_ptr<RBX::DataModel> *),
        CWebService *a1,
        boost::shared_ptr<RBX::DataModel> a2)
{
  CWebService *px; // r15
  int (**v6)(void); // rbp
  boost::detail::sp_counted_base *v7; // rbx

  px = (CWebService *)a2.px;
  v6 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v6;
  retstr->l_.a2_.t_.pn.pi_ = v7;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  return retstr;
}


// Address: 0xdd2650 | Name: _ZN5boost4bindIv11CWebServiceRKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEP20ns1__ScriptExecutionPNS2_6vectorIP13ns1__LuaValueNS6_ISF_EEEEP4soapPS1_S8_SC_SI_SK_EENS_3_bi6bind_tIT_NS_4_mfi3mf4ISO_T0_T1_T2_T3_T4_EENSM_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMSR_FSO_SS_ST_SU_SV_ESY_SZ_S10_S11_S12_
__int64 __fastcall boost::bind<void,CWebService,std::string const&,ns1__ScriptExecution *,std::vector<ns1__LuaValue *> *,soap *,CWebService*,std::string,ns1__ScriptExecution *,std::vector<ns1__LuaValue *> *,soap *>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        __int64 a5,
        int a6,
        __int64 a7,
        __int64 a8)
{
  _BYTE v12[16]; // [rsp+8h] [rbp-80h] BYREF
  void *v13; // [rsp+18h] [rbp-70h]
  __int64 v14; // [rsp+20h] [rbp-68h] BYREF
  _BYTE v15[16]; // [rsp+28h] [rbp-60h] BYREF
  void *ptr; // [rsp+38h] [rbp-50h]
  __int128 v17; // [rsp+40h] [rbp-48h]
  __int64 v18; // [rsp+50h] [rbp-38h]

  std::string::basic_string(v12, a5);
  boost::_bi::list5<boost::_bi::value<CWebService *>,boost::_bi::value<std::string>,boost::_bi::value<ns1__ScriptExecution *>,boost::_bi::value<std::vector<ns1__LuaValue *> *>,boost::_bi::value<soap *>>::list5(
    (unsigned int)&v14,
    a4,
    (unsigned int)v12,
    a6,
    a7,
    a8);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a3;
  *(_QWORD *)(a1 + 16) = v14;
  std::string::basic_string(a1 + 24, v15);
  *(_OWORD *)(a1 + 48) = v17;
  *(_QWORD *)(a1 + 64) = v18;
  if ( (v15[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v12[0] & 1) != 0 )
    operator delete(v13);
  return a1;
}


// Address: 0xde37a0 | Name: _ZN5boost4bindIvN3RBX13RCCMonitoringEiRKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEESB_PS2_iS9_PKcEENS_3_bi6bind_tIT_NS_4_mfi3mf3ISH_T0_T1_T2_T3_EENSF_9list_av_4IT4_T5_T6_T7_E4typeEEEMSK_FSH_SL_SM_SN_ESQ_SR_SS_ST_
__int64 __fastcall boost::bind<void,RBX::RCCMonitoring,int,std::string const&,std::string const&,RBX::RCCMonitoring*,int,std::string,char const*>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        int a5,
        __int64 a6,
        __int64 a7)
{
  int v10; // r9d
  int v12; // [rsp+0h] [rbp-78h] BYREF
  void *v13; // [rsp+8h] [rbp-70h]
  void *v14; // [rsp+10h] [rbp-68h]
  __int128 v15; // [rsp+18h] [rbp-60h] BYREF
  _BYTE v16[16]; // [rsp+28h] [rbp-50h] BYREF
  void *ptr; // [rsp+38h] [rbp-40h]
  __int64 v18; // [rsp+40h] [rbp-38h]

  std::string::basic_string(&v12, a6);
  boost::_bi::list4<boost::_bi::value<RBX::RCCMonitoring *>,boost::_bi::value<int>,boost::_bi::value<std::string>,boost::_bi::value<char const*>>::list4(
    (unsigned int)&v15,
    a4,
    a5,
    (unsigned int)&v12,
    a7,
    v10,
    v12,
    v13,
    (char)v14,
    v15,
    *((void **)&v15 + 1));
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a3;
  *(_OWORD *)(a1 + 16) = v15;
  std::string::basic_string(a1 + 32, v16);
  *(_QWORD *)(a1 + 56) = v18;
  if ( (v16[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v12 & 1) != 0 )
    operator delete(v14);
  return a1;
}


// Address: 0xef9380 | Name: _ZN5boost4bindIvN3RBX16PlayerConfigurerERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEESB_SB_iPS2_S9_S9_PKciEENS_3_bi6bind_tIT_NS_4_mfi3mf4ISH_T0_T1_T2_T3_T4_EENSF_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMSK_FSH_SL_SM_SN_SO_ESR_SS_ST_SU_SV_
__int64 __fastcall boost::bind<void,RBX::PlayerConfigurer,std::string const&,std::string const&,std::string const&,int,RBX::PlayerConfigurer*,std::string,std::string,char const*,int>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        __int64 a5,
        __int64 a6,
        __int64 a7,
        int a8)
{
  _BYTE v12[16]; // [rsp+8h] [rbp-A0h] BYREF
  void *v13; // [rsp+18h] [rbp-90h]
  _BYTE v14[16]; // [rsp+20h] [rbp-88h] BYREF
  void *ptr; // [rsp+30h] [rbp-78h]
  __int64 v16; // [rsp+38h] [rbp-70h] BYREF
  _BYTE v17[16]; // [rsp+40h] [rbp-68h] BYREF
  void *v18; // [rsp+50h] [rbp-58h]
  _BYTE v19[16]; // [rsp+58h] [rbp-50h] BYREF
  void *v20; // [rsp+68h] [rbp-40h]
  __int64 v21; // [rsp+70h] [rbp-38h]
  int v22; // [rsp+78h] [rbp-30h]

  std::string::basic_string(v14, a5);
  std::string::basic_string(v12, a6);
  boost::_bi::list5<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string>,boost::_bi::value<std::string>,boost::_bi::value<char const*>,boost::_bi::value<int>>::list5(
    (unsigned int)&v16,
    a4,
    (unsigned int)v14,
    (unsigned int)v12,
    a7,
    a8);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a3;
  *(_QWORD *)(a1 + 16) = v16;
  std::string::basic_string(a1 + 24, v17);
  std::string::basic_string(a1 + 48, v19);
  *(_QWORD *)(a1 + 72) = v21;
  *(_DWORD *)(a1 + 80) = v22;
  if ( (v19[0] & 1) != 0 )
  {
    operator delete(v20);
    if ( (v17[0] & 1) == 0 )
    {
LABEL_3:
      if ( (v12[0] & 1) == 0 )
        goto LABEL_4;
LABEL_9:
      operator delete(v13);
      if ( (v14[0] & 1) == 0 )
        return a1;
      goto LABEL_5;
    }
  }
  else if ( (v17[0] & 1) == 0 )
  {
    goto LABEL_3;
  }
  operator delete(v18);
  if ( (v12[0] & 1) != 0 )
    goto LABEL_9;
LABEL_4:
  if ( (v14[0] & 1) != 0 )
LABEL_5:
    operator delete(ptr);
  return a1;
}


// Address: 0xef9b30 | Name: _ZN5boost4bindIvN3RBX16PlayerConfigurerENS_10shared_ptrIbEEPS2_S4_EENS_3_bi6bind_tIT_NS_4_mfi3mf1IS8_T0_T1_EENS6_9list_av_2IT2_T3_E4typeEEEMSB_FS8_SC_ESF_SG_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<bool> >,boost::_bi::list2<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<boost::shared_ptr<bool> > > > *__fastcall boost::bind<void,RBX::PlayerConfigurer,boost::shared_ptr<bool>,RBX::PlayerConfigurer*,boost::shared_ptr<bool>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::PlayerConfigurer,boost::shared_ptr<bool> >,boost::_bi::list2<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<boost::shared_ptr<bool> > > > *__return_ptr retstr,
        void (*f)(RBX::PlayerConfigurer *, boost::shared_ptr<bool>),
        RBX::PlayerConfigurer *a1,
        boost::shared_ptr<bool> a2)
{
  boost::shared_ptr<bool>::element_type *px; // r15
  int (**v6)(void); // rbp
  boost::detail::sp_counted_base *v7; // rbx

  px = a2.px;
  v6 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = (RBX::PlayerConfigurer *)px;
  retstr->l_.a2_.t_.px = (boost::shared_ptr<bool>::element_type *)v6;
  retstr->l_.a2_.t_.pn.pi_ = v7;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  return retstr;
}


// Address: 0xefa520 | Name: _ZN5boost4bindIvN3RBX14GameConfigurerERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEllPNS1_16PlayerConfigurerES9_llEENS_3_bi6bind_tIT_NS_4_mfi3mf3ISG_T0_T1_T2_T3_EENSE_9list_av_4IT4_T5_T6_T7_E4typeEEEMSJ_FSG_SK_SL_SM_ESP_SQ_SR_SS_
__int64 __fastcall boost::bind<void,RBX::GameConfigurer,std::string const&,long,long,RBX::PlayerConfigurer *,std::string,long,long>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        __int64 a5,
        int a6,
        __int64 a7)
{
  int v10; // r9d
  _BYTE v12[16]; // [rsp+8h] [rbp-90h] BYREF
  void *ptr; // [rsp+18h] [rbp-80h]
  _BYTE v14[16]; // [rsp+20h] [rbp-78h] BYREF
  void *v15; // [rsp+30h] [rbp-68h]
  __int64 v16; // [rsp+38h] [rbp-60h] BYREF
  _BYTE v17[16]; // [rsp+40h] [rbp-58h] BYREF
  void *v18; // [rsp+50h] [rbp-48h]
  __int128 v19; // [rsp+58h] [rbp-40h]

  std::string::basic_string(v14, a5);
  std::string::basic_string(v12, v14);
  boost::_bi::storage4<boost::_bi::value<RBX::PlayerConfigurer *>,boost::_bi::value<std::string>,boost::_bi::value<long>,boost::_bi::value<long>>::storage4(
    (unsigned int)&v16,
    a4,
    (unsigned int)v12,
    a6,
    a7,
    v10);
  if ( (v12[0] & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a3;
  *(_QWORD *)(a1 + 16) = v16;
  std::string::basic_string(a1 + 24, v17);
  *(_OWORD *)(a1 + 48) = v19;
  if ( (v17[0] & 1) != 0 )
    operator delete(v18);
  if ( (v14[0] & 1) != 0 )
    operator delete(v15);
  return a1;
}


// Address: 0xefa6f0 | Name: _ZN5boost4bindIvN3RBX15GamePerfMonitorEbNS_10shared_ptrIS2_EEbEENS_3_bi6bind_tIT_NS_4_mfi3mf1IS7_T0_T1_EENS5_9list_av_2IT2_T3_E4typeEEEMSA_FS7_SB_ESE_SF_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GamePerfMonitor,bool>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GamePerfMonitor> >,boost::_bi::value<bool> > > *__fastcall boost::bind<void,RBX::GamePerfMonitor,bool,boost::shared_ptr<RBX::GamePerfMonitor>,bool>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GamePerfMonitor,bool>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GamePerfMonitor> >,boost::_bi::value<bool> > > *__return_ptr retstr,
        void (*f)(RBX::GamePerfMonitor *, bool),
        boost::shared_ptr<RBX::GamePerfMonitor> a1,
        bool a2)
{
  boost::shared_ptr<RBX::GamePerfMonitor>::element_type *px; // r12
  int (**v6)(void); // r13
  boost::detail::sp_counted_base *v7; // rbx

  px = a1.px;
  v6 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = v6;
    retstr->l_.a1_.t_.pn.pi_ = v7;
    _InterlockedAdd(&v7->use_count_, 1u);
    retstr->l_.a2_.t_ = a2;
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = v6;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = a2;
  }
  return retstr;
}


// Address: 0xf75af0 | Name: _ZN5boost4bindIvN3RBX7Network10ReplicatorERKN6RakNet13SystemAddressERKNS_10shared_ptrINS2_13NetworkStreamEEENS8_INS1_8InstanceEEERKNS1_16TextFilterResultENS8_IS3_EENS_3argILi1EEENSJ_ILi2EEENSJ_ILi3EEENSJ_ILi4EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf4ISQ_T0_T1_T2_T3_T4_EENSO_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMST_FSQ_SU_SV_SW_SX_ES10_S11_S12_S13_S14_
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::Network::Replicator,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,const RBX::TextFilterResult &>,boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > > *__fastcall boost::bind<void,RBX::Network::Replicator,RakNet::SystemAddress const&,boost::shared_ptr<RBX::Network::NetworkStream> const&,boost::shared_ptr<RBX::Instance>,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Network::Replicator>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::Network::Replicator,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,const RBX::TextFilterResult &>,boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > > *__return_ptr retstr,
        void (*f)(RBX::Network::Replicator *, const RakNet::SystemAddress *, const boost::shared_ptr<RBX::Network::NetworkStream> *, boost::shared_ptr<RBX::Instance>, const RBX::TextFilterResult *),
        boost::shared_ptr<RBX::Network::Replicator> a1,
        boost::arg<1> a2,
        boost::arg<2> a3)
{
  boost::shared_ptr<RBX::Network::Replicator>::element_type *px; // r14
  volatile signed __int32 *v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // r14
  volatile signed __int32 *v9; // rbx
  boost::arg<4> v11[8]; // [rsp+0h] [rbp-38h] BYREF
  volatile signed __int32 *v12; // [rsp+8h] [rbp-30h]
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > v13; // [rsp+10h] [rbp-28h] BYREF

  px = a1.px;
  *(_QWORD *)&v11[0].gap0 = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v12 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator>>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>::list5(
    &v13,
    (boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> >)__PAIR128__((unsigned __int64)a1.px, v11),
    (boost::arg<1>)a1.pn.pi_,
    (boost::arg<2>)a2.gap0,
    (boost::arg<3>)a3.gap0,
    v11[0]);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v13.a1_.t_.px;
  pi = v13.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v13.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v8 = v13.a1_.t_.pn.pi_;
    if ( v13.a1_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v13.a1_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  v9 = v12;
  if ( v12 )
  {
    if ( !_InterlockedSub(v12 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  return retstr;
}


// Address: 0xf76630 | Name: _ZN5boost4bindIvN3RBX7Network10ReplicatorENS_10shared_ptrIS3_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf0IS8_T0_EENS6_9list_av_1IT1_E4typeEEEMSB_FS8_vESE_
boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Network::Replicator>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> > > > *__fastcall boost::bind<void,RBX::Network::Replicator,boost::shared_ptr<RBX::Network::Replicator>>(
        boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Network::Replicator>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> > > > *__return_ptr retstr,
        void (*f)(RBX::Network::Replicator *),
        boost::shared_ptr<RBX::Network::Replicator> a1)
{
  boost::shared_ptr<RBX::Network::Replicator>::element_type *px; // r15
  int (**v4)(void); // r13
  boost::detail::sp_counted_base *v5; // rbx

  px = a1.px;
  v4 = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0xf76d70 | Name: _ZN5boost4bindIvN3RBX7Network10ReplicatorENS_8weak_ptrINS1_9DataModelEEEdNS_10shared_ptrIS3_EES6_fEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISB_T0_T1_T2_EENS9_9list_av_3IT3_T4_T5_E4typeEEEMSE_FSB_SF_SG_ESJ_SK_SL_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Network::Replicator,boost::weak_ptr<RBX::DataModel>,double>,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<float> > > *__fastcall boost::bind<void,RBX::Network::Replicator,boost::weak_ptr<RBX::DataModel>,double,boost::shared_ptr<RBX::Network::Replicator>,boost::weak_ptr<RBX::DataModel>,float>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Network::Replicator,boost::weak_ptr<RBX::DataModel>,double>,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<float> > > *__return_ptr retstr,
        void (*f)(RBX::Network::Replicator *, boost::weak_ptr<RBX::DataModel>, double),
        boost::shared_ptr<RBX::Network::Replicator> a1,
        boost::weak_ptr<RBX::DataModel> a2,
        float a3)
{
  boost::shared_ptr<RBX::Network::Replicator>::element_type *px; // r14
  boost::detail::sp_counted_base *v7; // rax
  __int64 v8; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v10; // rax
  boost::detail::sp_counted_base *v11; // rdi
  boost::detail::sp_counted_base *v12; // rbx
  __int64 v13; // rdi
  boost::detail::sp_counted_base *v14; // rbx
  __int64 v16; // [rsp+0h] [rbp-68h] BYREF
  __int64 v17; // [rsp+8h] [rbp-60h]
  boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> > a1a; // [rsp+10h] [rbp-58h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<float> > v19; // [rsp+20h] [rbp-48h] BYREF

  px = a1.px;
  a1a.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  a1a.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  v16 = *(_QWORD *)a2.px;
  v8 = *((_QWORD *)a2.px + 1);
  v17 = v8;
  if ( v8 )
    _InterlockedAdd((volatile signed __int32 *)(v8 + 12), 1u);
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<float>>::list3(
    &v19,
    (boost::_bi::value<boost::shared_ptr<RBX::Network::Replicator> >)__PAIR128__(&v16, &a1a),
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__(
                                                           (unsigned __int64)a2.px,
                                                           (unsigned __int64)a1.pn.pi_),
    LODWORD(a3));
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v19.a1_.t_.px;
  pi = v19.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v19.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a2_.t_.px = v19.a2_.t_.px;
  v10 = v19.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v19.a2_.t_.pn.pi_;
  if ( v10 )
  {
    _InterlockedAdd(&v10->weak_count_, 1u);
    v11 = v19.a2_.t_.pn.pi_;
    retstr->l_.a3_.t_ = v19.a3_.t_;
    if ( v11 && !_InterlockedSub(&v11->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
  }
  else
  {
    retstr->l_.a3_.t_ = v19.a3_.t_;
  }
  v12 = v19.a1_.t_.pn.pi_;
  if ( v19.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v19.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  v13 = v17;
  if ( v17 && !_InterlockedSub((volatile signed __int32 *)(v17 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v13 + 24LL))(v13);
  v14 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
      if ( !_InterlockedSub(&v14->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
    }
  }
  return retstr;
}


// Address: 0x10adf60 | Name: _ZN5boost4bindIvN3RBX8HumanoidENS_10shared_ptrINS1_8InstanceEEES5_PS2_NS_3argILi1EEENS3_INS1_12PartInstanceEEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISD_T0_T1_T2_EENSB_9list_av_3IT3_T4_T5_E4typeEEEMSG_FSD_SH_SI_ESL_SM_SN_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::Humanoid *>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::PartInstance> > > > *__fastcall boost::bind<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,RBX::Humanoid*,boost::arg<1>,boost::shared_ptr<RBX::PartInstance>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::Humanoid *>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::PartInstance> > > > *__return_ptr retstr,
        void (*f)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>),
        RBX::Humanoid *a1,
        RBX::Humanoid *a2,
        boost::shared_ptr<RBX::PartInstance> a3)
{
  __int64 v5; // rax
  int (**v8)(void); // rbp
  boost::detail::sp_counted_base *px; // rbx

  v8 = a3.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)a3.px->weak_this_.px;
  if ( px )
  {
    _InterlockedAdd(&px->use_count_, 1u);
    _InterlockedAdd(&px->use_count_, 1u);
    _InterlockedAdd(&px->use_count_, 1u);
    if ( !_InterlockedSub(&px->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, RBX::Humanoid *, boost::shared_ptr<RBX::PartInstance>::element_type *, boost::detail::sp_counted_base *, __int64))px->_vptr$sp_counted_base
       + 2))(
        px,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_,
        v5);
      if ( !_InterlockedSub(&px->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 3))(px);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = a2;
  retstr->l_.a3_.t_.px = (boost::shared_ptr<RBX::PartInstance>::element_type *)v8;
  retstr->l_.a3_.t_.pn.pi_ = px;
  if ( px )
  {
    _InterlockedAdd(&px->use_count_, 1u);
    if ( !_InterlockedSub(&px->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, RBX::Humanoid *, boost::shared_ptr<RBX::PartInstance>::element_type *, boost::detail::sp_counted_base *))px->_vptr$sp_counted_base
       + 2))(
        px,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_);
      if ( !_InterlockedSub(&px->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 3))(px);
    }
    if ( !_InterlockedSub(&px->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, RBX::Humanoid *, boost::shared_ptr<RBX::PartInstance>::element_type *, boost::detail::sp_counted_base *))px->_vptr$sp_counted_base
       + 2))(
        px,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_);
      if ( !_InterlockedSub(&px->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 3))(px);
    }
  }
  return retstr;
}


// Address: 0x10ae300 | Name: _ZN5boost4bindIvN3RBX8HumanoidENS_10shared_ptrINS1_8InstanceEEEPS2_S5_EENS_3_bi6bind_tIT_NS_4_mfi3mf1IS9_T0_T1_EENS7_9list_av_2IT2_T3_E4typeEEEMSC_FS9_SD_ESG_SH_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance> >,boost::_bi::list2<boost::_bi::value<RBX::Humanoid *>,boost::_bi::value<boost::shared_ptr<RBX::Instance> > > > *__fastcall boost::bind<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,RBX::Humanoid*,boost::shared_ptr<RBX::Instance>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance> >,boost::_bi::list2<boost::_bi::value<RBX::Humanoid *>,boost::_bi::value<boost::shared_ptr<RBX::Instance> > > > *__return_ptr retstr,
        void (*f)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>),
        RBX::Humanoid *a1,
        boost::shared_ptr<RBX::Instance> a2)
{
  boost::shared_ptr<RBX::Instance>::element_type *px; // r15
  int (**v6)(void); // rbp
  boost::detail::sp_counted_base *v7; // rbx

  px = a2.px;
  v6 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = (RBX::Humanoid *)px;
  retstr->l_.a2_.t_.px = (boost::shared_ptr<RBX::Instance>::element_type *)v6;
  retstr->l_.a2_.t_.pn.pi_ = v7;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  return retstr;
}


// Address: 0x10aff00 | Name: _ZN5boost4bindIvN3RBX8HumanoidENS_10shared_ptrINS1_8InstanceEEES5_PS2_NS3_INS1_10AttachmentEEENS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISD_T0_T1_T2_EENSB_9list_av_3IT3_T4_T5_E4typeEEEMSG_FSD_SH_SI_ESL_SM_SN_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::Humanoid *>,boost::_bi::value<boost::shared_ptr<RBX::Attachment> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,RBX::Humanoid*,boost::shared_ptr<RBX::Attachment>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::Humanoid *>,boost::_bi::value<boost::shared_ptr<RBX::Attachment> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>),
        RBX::Humanoid *a1,
        boost::shared_ptr<RBX::Attachment> a2,
        __int64 a3)
{
  __int64 v5; // rax
  RBX::Humanoid *px; // r15
  int (**v8)(void); // rbp
  boost::detail::sp_counted_base *v9; // rbx

  px = (RBX::Humanoid *)a2.px;
  v8 = a2.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::Attachment>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3,
        v5);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::Attachment>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = (boost::shared_ptr<RBX::Attachment>::element_type *)v8;
  retstr->l_.a2_.t_.pn.pi_ = v9;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::Attachment>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::Attachment>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x10b00e0 | Name: _ZN5boost4bindIvN3RBX8HumanoidENS_10shared_ptrINS1_8InstanceEEES5_PS2_NS3_INS1_12PartInstanceEEENS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISD_T0_T1_T2_EENSB_9list_av_3IT3_T4_T5_E4typeEEEMSG_FSD_SH_SI_ESL_SM_SN_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::Humanoid *>,boost::_bi::value<boost::shared_ptr<RBX::PartInstance> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,RBX::Humanoid*,boost::shared_ptr<RBX::PartInstance>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::Humanoid *>,boost::_bi::value<boost::shared_ptr<RBX::PartInstance> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>),
        RBX::Humanoid *a1,
        boost::shared_ptr<RBX::PartInstance> a2,
        __int64 a3)
{
  __int64 v5; // rax
  RBX::Humanoid *px; // r15
  int (**v8)(void); // rbp
  boost::detail::sp_counted_base *v9; // rbx

  px = (RBX::Humanoid *)a2.px;
  v8 = a2.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::PartInstance>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3,
        v5);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::PartInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = (boost::shared_ptr<RBX::PartInstance>::element_type *)v8;
  retstr->l_.a2_.t_.pn.pi_ = v9;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::PartInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::PartInstance>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x10b02c0 | Name: _ZN5boost4bindIvN3RBX8HumanoidENS_10shared_ptrINS1_8InstanceEEES5_PS2_NS3_INS1_12SpecialShapeEEENS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISD_T0_T1_T2_EENSB_9list_av_3IT3_T4_T5_E4typeEEEMSG_FSD_SH_SI_ESL_SM_SN_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::Humanoid *>,boost::_bi::value<boost::shared_ptr<RBX::SpecialShape> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>,RBX::Humanoid*,boost::shared_ptr<RBX::SpecialShape>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::Humanoid,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::Humanoid *>,boost::_bi::value<boost::shared_ptr<RBX::SpecialShape> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>),
        RBX::Humanoid *a1,
        boost::shared_ptr<RBX::SpecialShape> a2,
        __int64 a3)
{
  __int64 v5; // rax
  RBX::Humanoid *px; // r15
  int (**v8)(void); // rbp
  boost::detail::sp_counted_base *v9; // rbx

  px = (RBX::Humanoid *)a2.px;
  v8 = a2.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::SpecialShape>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3,
        v5);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::SpecialShape>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v8;
  retstr->l_.a2_.t_.pn.pi_ = v9;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::SpecialShape>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::Humanoid *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::Instance>), RBX::Humanoid *, boost::shared_ptr<RBX::SpecialShape>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x110e030 | Name: _ZN5boost4bindIvN3RBX10Reflection7Logging16ReflectionLoggerEPKNS2_15ClassDescriptorEP8_IO_FILERKNS3_29ReflectedFileIOWriteFunctionsEPS4_NS_3argILi1EEES9_SA_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISI_T0_T1_T2_T3_EENSG_9list_av_4IT4_T5_T6_T7_E4typeEEEMSL_FSI_SM_SN_SO_ESR_SS_ST_SU_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Reflection::Logging::ReflectionLogger,const RBX::Reflection::ClassDescriptor *,_IO_FILE *,const RBX::Reflection::Logging::ReflectedFileIOWriteFunctions &>,boost::_bi::list4<boost::_bi::value<RBX::Reflection::Logging::ReflectionLogger *>,boost::arg<1>,boost::_bi::value<_IO_FILE *>,boost::_bi::value<RBX::Reflection::Logging::ReflectedFileIOWriteFunctions> > > *__fastcall boost::bind<void,RBX::Reflection::Logging::ReflectionLogger,RBX::Reflection::ClassDescriptor const*,_IO_FILE *,RBX::Reflection::Logging::ReflectedFileIOWriteFunctions const&,RBX::Reflection::Logging::ReflectionLogger*,boost::arg<1>,_IO_FILE *,RBX::Reflection::Logging::ReflectedFileIOWriteFunctions>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Reflection::Logging::ReflectionLogger,const RBX::Reflection::ClassDescriptor *,_IO_FILE *,const RBX::Reflection::Logging::ReflectedFileIOWriteFunctions &>,boost::_bi::list4<boost::_bi::value<RBX::Reflection::Logging::ReflectionLogger *>,boost::arg<1>,boost::_bi::value<_IO_FILE *>,boost::_bi::value<RBX::Reflection::Logging::ReflectedFileIOWriteFunctions> > > *__return_ptr retstr,
        void (*f)(RBX::Reflection::Logging::ReflectionLogger *, const RBX::Reflection::ClassDescriptor *, _IO_FILE *, const RBX::Reflection::Logging::ReflectedFileIOWriteFunctions *),
        RBX::Reflection::Logging::ReflectionLogger *a1,
        RBX::Reflection::Logging::ReflectionLogger *a2,
        _IO_FILE *a3,
        const RBX::Reflection::Logging::ReflectedFileIOWriteFunctions *a6)
{
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions vars0; // [rsp+0h] [rbp+0h] BYREF
  boost::_bi::storage3<boost::_bi::value<RBX::Reflection::Logging::ReflectionLogger *>,boost::arg<1>,boost::_bi::value<_IO_FILE *> > vars180; // [rsp+180h] [rbp+180h]
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions vars190; // [rsp+190h] [rbp+190h] BYREF
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions vars310; // [rsp+310h] [rbp+310h] BYREF
  unsigned __int64 vars490; // [rsp+490h] [rbp+490h]

  vars490 = __readfsqword(0x28u);
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions::ReflectedFileIOWriteFunctions(&vars0, a6);
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions::ReflectedFileIOWriteFunctions(&vars310, &vars0);
  vars180.a1_.t_ = a2;
  vars180.a3_.t_ = a3;
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions::ReflectedFileIOWriteFunctions(&vars190, &vars310);
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions::~ReflectedFileIOWriteFunctions(&vars310);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.boost::_bi::storage3<boost::_bi::value<RBX::Reflection::Logging::ReflectionLogger *>,boost::arg<1>,boost::_bi::value<_IO_FILE *> > = vars180;
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions::ReflectedFileIOWriteFunctions(&retstr->l_.a4_.t_, &vars190);
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions::~ReflectedFileIOWriteFunctions(&vars190);
  RBX::Reflection::Logging::ReflectedFileIOWriteFunctions::~ReflectedFileIOWriteFunctions(&vars0);
  return retstr;
}


// Address: 0x11284a0 | Name: _ZN5boost4bindIvN3RBX9Scripting14ScriptDebuggerEP9lua_StateNS_8functionIFNS1_10Reflection7VariantES5_EEERS8_RNS_10shared_ptrINSt3__112basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEEEEPS3_NS_3argILi1EEESA_NS_17reference_wrapperIS8_EENSP_ISK_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf4ISU_T0_T1_T2_T3_T4_EENSS_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMSX_FSU_SY_SZ_S10_S11_ES14_S15_S16_S17_S18_
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<RBX::Reflection::Variant (lua_State *)>,RBX::Reflection::Variant &,boost::shared_ptr<std::string > &>,boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<RBX::Reflection::Variant (lua_State *)> >,boost::reference_wrapper<RBX::Reflection::Variant>,boost::reference_wrapper<boost::shared_ptr<std::string > > > > *__fastcall boost::bind<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<RBX::Reflection::Variant ()(lua_State *)>,RBX::Reflection::Variant&,boost::shared_ptr<std::string> &,RBX::Scripting::ScriptDebugger*,boost::arg<1>,boost::function<RBX::Reflection::Variant ()(lua_State *)>,boost::reference_wrapper<RBX::Reflection::Variant>,boost::reference_wrapper<boost::shared_ptr<std::string>>>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<RBX::Reflection::Variant (lua_State *)>,RBX::Reflection::Variant &,boost::shared_ptr<std::string > &>,boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<RBX::Reflection::Variant (lua_State *)> >,boost::reference_wrapper<RBX::Reflection::Variant>,boost::reference_wrapper<boost::shared_ptr<std::string > > > > *__return_ptr retstr,
        void (*f)(RBX::Scripting::ScriptDebugger *, lua_State_0 *, boost::function<RBX::Reflection::Variant (lua_State *)>, RBX::Reflection::Variant *, boost::shared_ptr<std::string > *),
        RBX::Scripting::ScriptDebugger *a1,
        boost::_bi::value<RBX::Scripting::ScriptDebugger *> a2,
        boost::reference_wrapper<RBX::Reflection::Variant> a4,
        boost::reference_wrapper<boost::shared_ptr<std::string > > a5,
        boost::function<RBX::Reflection::Variant (lua_State *)> a3)
{
  const RBX::Reflection::Type *type; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<RBX::Reflection::Variant (lua_State *)> > v15; // [rsp+0h] [rbp-88h] BYREF
  boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<RBX::Reflection::Variant (lua_State *)> >,boost::reference_wrapper<RBX::Reflection::Variant>,boost::reference_wrapper<boost::shared_ptr<std::string > > > v16; // [rsp+20h] [rbp-68h] BYREF

  v15.t_.vtable = 0;
  type = a4.t_->_type;
  if ( a4.t_->_type )
  {
    v15.t_.vtable = (boost::detail::function::vtable_base *)a4.t_->_type;
    if ( ((unsigned __int8)type & 1) != 0 )
      v15.t_.functor = *(boost::detail::function::function_buffer *)&a4.t_->value.holder;
    else
      (*(void (__fastcall **)(rbx::placement_any<RBX::Reflection::Variant::Storage> *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)type & 0xFFFFFFFFFFFFFFFELL))(
        &a4.t_->value,
        &v15.t_.functor,
        0);
  }
  boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<RBX::Reflection::Variant ()(lua_State *)>>,boost::reference_wrapper<RBX::Reflection::Variant>,boost::reference_wrapper<boost::shared_ptr<std::string>>>::list5(
    &v16,
    a2,
    (boost::arg<1>)&v15,
    v15,
    (boost::reference_wrapper<RBX::Reflection::Variant>)a5.t_,
    (boost::reference_wrapper<boost::shared_ptr<std::string > >)a3.vtable);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v16.a1_.t_;
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v16.a3_.t_.vtable;
  if ( v16.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v16.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v16.a3_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v16.a3_.t_.functor,
        &retstr->l_.a3_.t_.functor,
        0);
      vtable = v16.a3_.t_.vtable;
    }
  }
  else
  {
    vtable = 0;
  }
  *(_OWORD *)&retstr->l_.a4_.t_ = *(_OWORD *)&v16.a4_.t_;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v16.a3_.t_.functor, &v16.a3_.t_.functor, 2);
    }
    v16.a3_.t_.vtable = 0;
  }
  if ( v15.t_.vtable )
  {
    if ( ((__int64)v15.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v15.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v15.t_.functor, &v15.t_.functor, 2);
    }
    v15.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x112b660 | Name: _ZN5boost4bindIvN3RBX9Scripting14ScriptDebuggerEP9lua_StateNS_8functionIFNS_10shared_ptrIKNSt3__13mapINS8_12basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEENS1_10Reflection7VariantENS8_4lessISF_EENSD_INS8_4pairIKSF_SH_EEEEEEEES5_EEERSQ_RNS7_ISF_EEPS3_NS_3argILi1EEESS_NS_17reference_wrapperISQ_EENSZ_ISU_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf4IS14_T0_T1_T2_T3_T4_EENS12_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMS17_FS14_S18_S19_S1A_S1B_ES1E_S1F_S1G_S1H_S1I_
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)>,boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > &,boost::shared_ptr<std::string > &>,boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)> >,boost::reference_wrapper<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > >,boost::reference_wrapper<boost::shared_ptr<std::string > > > > *__fastcall boost::bind<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const> ()(lua_State *)>,boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>&,boost::shared_ptr<std::string> &,RBX::Scripting::ScriptDebugger*,boost::arg<1>,boost::function<boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const> ()(lua_State *)>,boost::reference_wrapper<boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>>,boost::reference_wrapper<boost::shared_ptr<std::string>>>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)>,boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > &,boost::shared_ptr<std::string > &>,boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)> >,boost::reference_wrapper<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > >,boost::reference_wrapper<boost::shared_ptr<std::string > > > > *__return_ptr retstr,
        void (*f)(RBX::Scripting::ScriptDebugger *, lua_State_0 *, boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)>, boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > *, boost::shared_ptr<std::string > *),
        RBX::Scripting::ScriptDebugger *a1,
        boost::_bi::value<RBX::Scripting::ScriptDebugger *> a2,
        boost::reference_wrapper<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > > a4,
        boost::reference_wrapper<boost::shared_ptr<std::string > > a5,
        boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)> a3)
{
  boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> >::element_type *px; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)> > v15; // [rsp+0h] [rbp-88h] BYREF
  boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > (lua_State *)> >,boost::reference_wrapper<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > >,boost::reference_wrapper<boost::shared_ptr<std::string > > > v16; // [rsp+20h] [rbp-68h] BYREF

  v15.t_.vtable = 0;
  px = a4.t_->px;
  if ( a4.t_->px )
  {
    v15.t_.vtable = (boost::detail::function::vtable_base *)a4.t_->px;
    if ( ((unsigned __int8)px & 1) != 0 )
      v15.t_.functor = *(boost::detail::function::function_buffer *)&a4.t_->pn.pi_;
    else
      (*(void (__fastcall **)(boost::detail::shared_count *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)px & 0xFFFFFFFFFFFFFFFELL))(
        &a4.t_->pn,
        &v15.t_.functor,
        0);
  }
  boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const> ()(lua_State *)>>,boost::reference_wrapper<boost::shared_ptr<std::map<std::string,RBX::Reflection::Variant> const>>,boost::reference_wrapper<boost::shared_ptr<std::string>>>::list5(
    &v16,
    a2,
    (boost::arg<1>)&v15,
    v15,
    (boost::reference_wrapper<boost::shared_ptr<const std::map<std::string,RBX::Reflection::Variant> > >)a5.t_,
    (boost::reference_wrapper<boost::shared_ptr<std::string > >)a3.vtable);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v16.a1_.t_;
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v16.a3_.t_.vtable;
  if ( v16.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v16.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v16.a3_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v16.a3_.t_.functor,
        &retstr->l_.a3_.t_.functor,
        0);
      vtable = v16.a3_.t_.vtable;
    }
  }
  else
  {
    vtable = 0;
  }
  *(_OWORD *)&retstr->l_.a4_.t_ = *(_OWORD *)&v16.a4_.t_;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v16.a3_.t_.functor, &v16.a3_.t_.functor, 2);
    }
    v16.a3_.t_.vtable = 0;
  }
  if ( v15.t_.vtable )
  {
    if ( ((__int64)v15.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v15.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v15.t_.functor, &v15.t_.functor, 2);
    }
    v15.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x112ca40 | Name: _ZN5boost4bindIvN3RBX9Scripting14ScriptDebuggerEP9lua_StateNS_8functionIFbS5_EEERbRNS_10shared_ptrINSt3__112basic_stringIcNSB_11char_traitsIcEENSB_9allocatorIcEEEEEEPS3_NS_3argILi1EEES8_NS_17reference_wrapperIbEENSN_ISI_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf4ISS_T0_T1_T2_T3_T4_EENSQ_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMSV_FSS_SW_SX_SY_SZ_ES12_S13_S14_S15_S16_
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<bool (lua_State *)>,bool &,boost::shared_ptr<std::string > &>,boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<bool (lua_State *)> >,boost::reference_wrapper<bool>,boost::reference_wrapper<boost::shared_ptr<std::string > > > > *__fastcall boost::bind<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<bool ()(lua_State *)>,bool &,boost::shared_ptr<std::string> &,RBX::Scripting::ScriptDebugger*,boost::arg<1>,boost::function<bool ()(lua_State *)>,boost::reference_wrapper<bool>,boost::reference_wrapper<boost::shared_ptr<std::string>>>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::Scripting::ScriptDebugger,lua_State *,boost::function<bool (lua_State *)>,bool &,boost::shared_ptr<std::string > &>,boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<bool (lua_State *)> >,boost::reference_wrapper<bool>,boost::reference_wrapper<boost::shared_ptr<std::string > > > > *__return_ptr retstr,
        void (*f)(RBX::Scripting::ScriptDebugger *, lua_State_0 *, boost::function<bool (lua_State *)>, bool *, boost::shared_ptr<std::string > *),
        RBX::Scripting::ScriptDebugger *a1,
        boost::_bi::value<RBX::Scripting::ScriptDebugger *> a2,
        boost::reference_wrapper<bool> a4,
        boost::reference_wrapper<boost::shared_ptr<std::string > > a5,
        boost::function<bool (lua_State *)> a3)
{
  __int64 v10; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<bool (lua_State *)> > v15; // [rsp+0h] [rbp-88h] BYREF
  boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<bool (lua_State *)> >,boost::reference_wrapper<bool>,boost::reference_wrapper<boost::shared_ptr<std::string > > > v16; // [rsp+20h] [rbp-68h] BYREF

  v15.t_.vtable = 0;
  v10 = *(_QWORD *)a4.t_;
  if ( *(_QWORD *)a4.t_ )
  {
    v15.t_.vtable = *(boost::detail::function::vtable_base **)a4.t_;
    if ( (v10 & 1) != 0 )
      v15.t_.functor = *(boost::detail::function::function_buffer *)(a4.t_ + 8);
    else
      (*(void (__fastcall **)(bool *, boost::detail::function::function_buffer *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(
        a4.t_ + 8,
        &v15.t_.functor,
        0);
  }
  boost::_bi::list5<boost::_bi::value<RBX::Scripting::ScriptDebugger *>,boost::arg<1>,boost::_bi::value<boost::function<bool ()(lua_State *)>>,boost::reference_wrapper<bool>,boost::reference_wrapper<boost::shared_ptr<std::string>>>::list5(
    &v16,
    a2,
    (boost::arg<1>)&v15,
    v15,
    (boost::reference_wrapper<bool>)a5.t_,
    (boost::reference_wrapper<boost::shared_ptr<std::string > >)a3.vtable);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v16.a1_.t_;
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v16.a3_.t_.vtable;
  if ( v16.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v16.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v16.a3_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v16.a3_.t_.functor,
        &retstr->l_.a3_.t_.functor,
        0);
      vtable = v16.a3_.t_.vtable;
    }
  }
  else
  {
    vtable = 0;
  }
  *(_OWORD *)&retstr->l_.a4_.t_ = *(_OWORD *)&v16.a4_.t_;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v16.a3_.t_.functor, &v16.a3_.t_.functor, 2);
    }
    v16.a3_.t_.vtable = 0;
  }
  if ( v15.t_.vtable )
  {
    if ( ((__int64)v15.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v15.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v15.t_.functor, &v15.t_.functor, 2);
    }
    v15.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x1198bb0 | Name: _ZN5boost4bindIv24YieldFunctionStateObjectN3RBX10Reflection7VariantENS_10shared_ptrIS1_EENS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf1ISB_T0_T1_EENS9_9list_av_2IT2_T3_E4typeEEEMSE_FSB_SF_ESI_SJ_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,YieldFunctionStateObject,RBX::Reflection::Variant>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<YieldFunctionStateObject> >,boost::arg<1> > > *__fastcall boost::bind<void,YieldFunctionStateObject,RBX::Reflection::Variant,boost::shared_ptr<YieldFunctionStateObject>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,YieldFunctionStateObject,RBX::Reflection::Variant>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<YieldFunctionStateObject> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(YieldFunctionStateObject *, RBX::Reflection::Variant),
        boost::shared_ptr<YieldFunctionStateObject> a1,
        __int64 a2)
{
  boost::shared_ptr<YieldFunctionStateObject>::element_type *px; // r15
  int (**v5)(void); // r13
  boost::detail::sp_counted_base *v6; // rbx

  px = a1.px;
  v5 = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v6 )
  {
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(YieldFunctionStateObject *, RBX::Reflection::Variant), boost::shared_ptr<YieldFunctionStateObject>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(YieldFunctionStateObject *, RBX::Reflection::Variant), boost::shared_ptr<YieldFunctionStateObject>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<YieldFunctionStateObject>::element_type *)v5;
    retstr->l_.a1_.t_.pn.pi_ = v6;
    _InterlockedAdd(&v6->use_count_, 1u);
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(YieldFunctionStateObject *, RBX::Reflection::Variant), boost::shared_ptr<YieldFunctionStateObject>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(YieldFunctionStateObject *, RBX::Reflection::Variant), boost::shared_ptr<YieldFunctionStateObject>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<YieldFunctionStateObject>::element_type *)v5;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1199040 | Name: _ZN5boost4bindIv24YieldFunctionStateObjectNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_10shared_ptrIS1_EENS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf1ISF_T0_T1_EENSD_9list_av_2IT2_T3_E4typeEEEMSI_FSF_SJ_ESM_SN_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,YieldFunctionStateObject,std::string >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<YieldFunctionStateObject> >,boost::arg<1> > > *__fastcall boost::bind<void,YieldFunctionStateObject,std::string,boost::shared_ptr<YieldFunctionStateObject>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,YieldFunctionStateObject,std::string >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<YieldFunctionStateObject> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(YieldFunctionStateObject *, std::string),
        boost::shared_ptr<YieldFunctionStateObject> a1,
        __int64 a2)
{
  boost::shared_ptr<YieldFunctionStateObject>::element_type *px; // r15
  int (**v5)(void); // r13
  boost::detail::sp_counted_base *v6; // rbx

  px = a1.px;
  v5 = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v6 )
  {
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(YieldFunctionStateObject *, std::string), boost::shared_ptr<YieldFunctionStateObject>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(YieldFunctionStateObject *, std::string), boost::shared_ptr<YieldFunctionStateObject>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<YieldFunctionStateObject>::element_type *)v5;
    retstr->l_.a1_.t_.pn.pi_ = v6;
    _InterlockedAdd(&v6->use_count_, 1u);
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(YieldFunctionStateObject *, std::string), boost::shared_ptr<YieldFunctionStateObject>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(YieldFunctionStateObject *, std::string), boost::shared_ptr<YieldFunctionStateObject>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<YieldFunctionStateObject>::element_type *)v5;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x11caf40 | Name: _ZN5boost4bindIvN3RBX13ScriptContextENS1_3Lua13WeakThreadRefEP9lua_StatePS2_S4_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISC_T0_T1_T2_EENSA_9list_av_3IT3_T4_T5_E4typeEEEMSF_FSC_SG_SH_ESK_SL_SM_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::ScriptContext,RBX::Lua::WeakThreadRef,lua_State *>,boost::_bi::list3<boost::_bi::value<RBX::ScriptContext *>,boost::_bi::value<RBX::Lua::WeakThreadRef>,boost::arg<1> > > *__fastcall boost::bind<void,RBX::ScriptContext,RBX::Lua::WeakThreadRef,lua_State *,RBX::ScriptContext*,RBX::Lua::WeakThreadRef,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::ScriptContext,RBX::Lua::WeakThreadRef,lua_State *>,boost::_bi::list3<boost::_bi::value<RBX::ScriptContext *>,boost::_bi::value<RBX::Lua::WeakThreadRef>,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::ScriptContext *, RBX::Lua::WeakThreadRef, lua_State *),
        RBX::ScriptContext *a1,
        boost::_bi::value<RBX::ScriptContext *> a3,
        const RBX::Lua::WeakThreadRef *a5)
{
  boost::_bi::value<RBX::Lua::WeakThreadRef> v8; // [rsp+0h] [rbp-98h] BYREF
  boost::_bi::list3<boost::_bi::value<RBX::ScriptContext *>,boost::_bi::value<RBX::Lua::WeakThreadRef>,boost::arg<1> > v9; // [rsp+38h] [rbp-60h] BYREF

  RBX::Lua::WeakThreadRef::WeakThreadRef(
    (RBX::Lua::WeakThreadRef *)&v8.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>,
    a5);
  boost::_bi::list3<boost::_bi::value<RBX::ScriptContext *>,boost::_bi::value<RBX::Lua::WeakThreadRef>,boost::arg<1>>::list3(
    &v9,
    a3,
    v8,
    (boost::arg<1>)&v8.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v9.a1_.t_;
  RBX::Lua::WeakThreadRef::WeakThreadRef(&retstr->l_.a2_.t_, &v9.a2_.t_);
  RBX::Lua::WeakThreadRef::~WeakThreadRef(&v9.a2_.t_);
  RBX::Lua::WeakThreadRef::~WeakThreadRef((RBX::Lua::WeakThreadRef *)&v8.t_.rbx::quick_intrusive_ptr_target<RBX::Lua::WeakThreadRef>);
  return retstr;
}


// Address: 0x12e5d10 | Name: _ZN5boost4bindIvN3RBX13StandardPagesENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvvEEENSA_IFvS9_EEENS_10shared_ptrIS2_EENS_3argILi1EEESC_SE_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISL_T0_T1_T2_T3_EENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEEMSO_FSL_SP_SQ_SR_ESU_SV_SW_SX_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::StandardPages,std::string,boost::function<void ()>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::StandardPages> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::StandardPages,std::string,boost::function<void ()(void)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::StandardPages>,boost::arg<1>,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::StandardPages,std::string,boost::function<void ()>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::StandardPages> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::StandardPages *, std::string, boost::function<void ()>, boost::function<void (std::string)>),
        boost::shared_ptr<RBX::StandardPages> a1,
        __int64 a2,
        __int64 a5)
{
  boost::shared_ptr<RBX::StandardPages>::element_type *px; // r14
  boost::detail::sp_counted_base *v7; // rax
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rax
  void (__fastcall *v10)(char *, char *, __int64); // rax
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::_bi::value<boost::function<void ()> >_0 v14; // [rsp+0h] [rbp-C8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v15; // [rsp+20h] [rbp-A8h] BYREF
  __int64 v16; // [rsp+40h] [rbp-88h]
  boost::_bi::value<boost::shared_ptr<RBX::StandardPages> > v17; // [rsp+48h] [rbp-80h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::StandardPages> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > v18; // [rsp+58h] [rbp-70h] BYREF

  px = a1.px;
  v17.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v17.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  v15.t_.functor.obj_ptr = 0;
  v8 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v15.t_.functor.obj_ptr = *(void **)a2;
    if ( (v8 & 1) != 0 )
    {
      v16 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v15.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v8 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v15.t_.functor.type.const_qualified,
        0);
    }
  }
  v14.t_.functor.obj_ptr = 0;
  v9 = *(_QWORD *)a5;
  if ( *(_QWORD *)a5 )
  {
    v14.t_.functor.obj_ptr = *(void **)a5;
    if ( (v9 & 1) != 0 )
    {
      v15.t_.vtable = *(boost::detail::function::vtable_base **)(a5 + 24);
      *(_OWORD *)(&v14.t_.functor.data + 8) = *(_OWORD *)(a5 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(
        a5 + 8,
        &v14.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::StandardPages>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v18,
    (boost::_bi::value<boost::shared_ptr<RBX::StandardPages> >)__PAIR128__(
                                                                 (boost::_bi::value<boost::function<void (std::string)> >_0 *)&v15.t_.functor,
                                                                 &v17),
    (boost::arg<1>)&v14.t_.functor,
    v14,
    v15);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::StandardPages>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage4(
    &retstr->l_,
    &v18);
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::StandardPages>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4(&v18);
  if ( v14.t_.functor.obj_ptr )
  {
    if ( (v14.t_.functor.data & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v14.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(v14.t_.functor.bound_memfunc_ptr.gap8, v14.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v14.t_.functor.obj_ptr = 0;
  }
  if ( v15.t_.functor.obj_ptr )
  {
    if ( (v15.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v15.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v15.t_.functor.bound_memfunc_ptr.gap8, v15.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v15.t_.functor.obj_ptr = 0;
  }
  pi = v17.t_.pn.pi_;
  if ( v17.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x12e60d0 | Name: _ZN5boost4bindIvN3RBX13StandardPagesENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvS9_EEENS_10shared_ptrIS2_EENS_3argILi1EEESC_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISJ_T0_T1_T2_EENSH_9list_av_3IT3_T4_T5_E4typeEEEMSM_FSJ_SN_SO_ESR_SS_ST_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::StandardPages,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::StandardPages> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::StandardPages,std::string,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::StandardPages>,boost::arg<1>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::StandardPages,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::StandardPages> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::StandardPages *, std::string, boost::function<void (std::string)>),
        boost::shared_ptr<RBX::StandardPages> a1,
        __int64 a2)
{
  boost::shared_ptr<RBX::StandardPages>::element_type *px; // r14
  boost::detail::sp_counted_base *v5; // rax
  unsigned __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v10; // rbx
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::_bi::value<boost::function<void (std::string)> >_0 v14; // [rsp+0h] [rbp-88h] BYREF
  __int64 v15; // [rsp+20h] [rbp-68h]
  boost::_bi::value<boost::shared_ptr<RBX::StandardPages> > v16; // [rsp+28h] [rbp-60h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::StandardPages> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > v17; // [rsp+38h] [rbp-50h] BYREF

  px = a1.px;
  v16.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v16.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->use_count_, 1u);
  v14.t_.functor.obj_ptr = 0;
  v6 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v14.t_.functor.obj_ptr = *(void **)a2;
    if ( (v6 & 1) != 0 )
    {
      v15 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v14.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v6 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v14.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::StandardPages>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::list3(
    &v17,
    (boost::_bi::value<boost::shared_ptr<RBX::StandardPages> >)__PAIR128__(
                                                                 (boost::_bi::value<boost::function<void (std::string)> >_0 *)&v14.t_.functor,
                                                                 &v16),
    (boost::arg<1>)a1.pn.pi_,
    v14);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v17.a3_.t_.vtable;
  if ( v17.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v17.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v17.a3_.t_.functor;
LABEL_17:
      v17.a3_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v17.a3_.t_.functor,
      &retstr->l_.a3_.t_.functor,
      0);
    if ( v17.a3_.t_.vtable )
    {
      if ( ((__int64)v17.a3_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v17.a3_.t_.functor, &v17.a3_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  if ( v14.t_.functor.obj_ptr )
  {
    if ( (v14.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v14.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v14.t_.functor.bound_memfunc_ptr.gap8, v14.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v14.t_.functor.obj_ptr = 0;
  }
  v12 = v16.t_.pn.pi_;
  if ( v16.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v16.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  return retstr;
}


// Address: 0x12e6ba0 | Name: _ZN5boost4bindIvN3RBX11FriendPagesENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvvEEENSA_IFvS9_EEENS_10shared_ptrIS2_EENS_3argILi1EEESC_SE_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISL_T0_T1_T2_T3_EENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEEMSO_FSL_SP_SQ_SR_ESU_SV_SW_SX_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::FriendPages,std::string,boost::function<void ()>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::FriendPages> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::FriendPages,std::string,boost::function<void ()(void)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::FriendPages>,boost::arg<1>,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::FriendPages,std::string,boost::function<void ()>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::FriendPages> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::FriendPages *, std::string, boost::function<void ()>, boost::function<void (std::string)>),
        boost::shared_ptr<RBX::FriendPages> a1,
        __int64 a2,
        __int64 a5)
{
  boost::shared_ptr<RBX::FriendPages>::element_type *px; // r14
  boost::detail::sp_counted_base *v7; // rax
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rax
  void (__fastcall *v10)(char *, char *, __int64); // rax
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::_bi::value<boost::function<void ()> >_0 v14; // [rsp+0h] [rbp-C8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v15; // [rsp+20h] [rbp-A8h] BYREF
  __int64 v16; // [rsp+40h] [rbp-88h]
  boost::_bi::value<boost::shared_ptr<RBX::FriendPages> > v17; // [rsp+48h] [rbp-80h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::FriendPages> >,boost::arg<1>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > v18; // [rsp+58h] [rbp-70h] BYREF

  px = a1.px;
  v17.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v17.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  v15.t_.functor.obj_ptr = 0;
  v8 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v15.t_.functor.obj_ptr = *(void **)a2;
    if ( (v8 & 1) != 0 )
    {
      v16 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v15.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v8 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v15.t_.functor.type.const_qualified,
        0);
    }
  }
  v14.t_.functor.obj_ptr = 0;
  v9 = *(_QWORD *)a5;
  if ( *(_QWORD *)a5 )
  {
    v14.t_.functor.obj_ptr = *(void **)a5;
    if ( (v9 & 1) != 0 )
    {
      v15.t_.vtable = *(boost::detail::function::vtable_base **)(a5 + 24);
      *(_OWORD *)(&v14.t_.functor.data + 8) = *(_OWORD *)(a5 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(
        a5 + 8,
        &v14.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::FriendPages>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v18,
    (boost::_bi::value<boost::shared_ptr<RBX::FriendPages> >)__PAIR128__(
                                                               (boost::_bi::value<boost::function<void (std::string)> >_0 *)&v15.t_.functor,
                                                               &v17),
    (boost::arg<1>)&v14.t_.functor,
    v14,
    v15);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::FriendPages>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage4(
    &retstr->l_,
    &v18);
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::FriendPages>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4(&v18);
  if ( v14.t_.functor.obj_ptr )
  {
    if ( (v14.t_.functor.data & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v14.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(v14.t_.functor.bound_memfunc_ptr.gap8, v14.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v14.t_.functor.obj_ptr = 0;
  }
  if ( v15.t_.functor.obj_ptr )
  {
    if ( (v15.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v15.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v15.t_.functor.bound_memfunc_ptr.gap8, v15.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v15.t_.functor.obj_ptr = 0;
  }
  pi = v17.t_.pn.pi_;
  if ( v17.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x12e6ec0 | Name: _ZN5boost4bindIvN3RBX11FriendPagesENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvS9_EEENS_10shared_ptrIS2_EENS_3argILi1EEESC_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISJ_T0_T1_T2_EENSH_9list_av_3IT3_T4_T5_E4typeEEEMSM_FSJ_SN_SO_ESR_SS_ST_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::FriendPages,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::FriendPages> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::FriendPages,std::string,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::FriendPages>,boost::arg<1>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::FriendPages,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::FriendPages> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::FriendPages *, std::string, boost::function<void (std::string)>),
        boost::shared_ptr<RBX::FriendPages> a1,
        __int64 a2)
{
  boost::shared_ptr<RBX::FriendPages>::element_type *px; // r14
  boost::detail::sp_counted_base *v5; // rax
  unsigned __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v10; // rbx
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::_bi::value<boost::function<void (std::string)> >_0 v14; // [rsp+0h] [rbp-88h] BYREF
  __int64 v15; // [rsp+20h] [rbp-68h]
  boost::_bi::value<boost::shared_ptr<RBX::FriendPages> > v16; // [rsp+28h] [rbp-60h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::FriendPages> >,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > v17; // [rsp+38h] [rbp-50h] BYREF

  px = a1.px;
  v16.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v16.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->use_count_, 1u);
  v14.t_.functor.obj_ptr = 0;
  v6 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v14.t_.functor.obj_ptr = *(void **)a2;
    if ( (v6 & 1) != 0 )
    {
      v15 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v14.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v6 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v14.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::FriendPages>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::list3(
    &v17,
    (boost::_bi::value<boost::shared_ptr<RBX::FriendPages> >)__PAIR128__(
                                                               (boost::_bi::value<boost::function<void (std::string)> >_0 *)&v14.t_.functor,
                                                               &v16),
    (boost::arg<1>)a1.pn.pi_,
    v14);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v17.a3_.t_.vtable;
  if ( v17.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v17.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v17.a3_.t_.functor;
LABEL_17:
      v17.a3_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v17.a3_.t_.functor,
      &retstr->l_.a3_.t_.functor,
      0);
    if ( v17.a3_.t_.vtable )
    {
      if ( ((__int64)v17.a3_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v17.a3_.t_.functor, &v17.a3_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  if ( v14.t_.functor.obj_ptr )
  {
    if ( (v14.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v14.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v14.t_.functor.bound_memfunc_ptr.gap8, v14.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v14.t_.functor.obj_ptr = 0;
  }
  v12 = v16.t_.pn.pi_;
  if ( v16.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v16.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  return retstr;
}


// Address: 0x12ea3c0 | Name: _ZN5boost4bindIvN3RBX13LuaWebServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvbEEENSA_IFvS9_EEENS_10shared_ptrIS2_EENS_3argILi1EEESC_SE_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISL_T0_T1_T2_T3_EENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEEMSO_FSL_SP_SQ_SR_ESU_SV_SW_SX_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::LuaWebService,std::string,boost::function<void (bool)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::LuaWebService,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::LuaWebService>,boost::arg<1>,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::LuaWebService,std::string,boost::function<void (bool)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::LuaWebService *, std::string, boost::function<void (bool)>, boost::function<void (std::string)>),
        boost::shared_ptr<RBX::LuaWebService> a1,
        __int64 a2,
        __int64 a5)
{
  boost::shared_ptr<RBX::LuaWebService>::element_type *px; // r14
  boost::detail::sp_counted_base *v7; // rax
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rax
  void (__fastcall *v10)(char *, char *, __int64); // rax
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rbx
  boost::_bi::value<boost::function<void (bool)> > v14; // [rsp+0h] [rbp-C8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v15; // [rsp+20h] [rbp-A8h] BYREF
  __int64 v16; // [rsp+40h] [rbp-88h]
  boost::_bi::value<boost::shared_ptr<RBX::LuaWebService> > v17; // [rsp+48h] [rbp-80h] BYREF
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService> >,boost::arg<1>,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > v18; // [rsp+58h] [rbp-70h] BYREF

  px = a1.px;
  v17.t_.px = (boost::shared_ptr<RBX::LuaWebService>::element_type *)a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v17.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  v15.t_.functor.obj_ptr = 0;
  v8 = *(_QWORD *)a2;
  if ( *(_QWORD *)a2 )
  {
    v15.t_.functor.obj_ptr = *(void **)a2;
    if ( (v8 & 1) != 0 )
    {
      v16 = *(_QWORD *)(a2 + 24);
      *(_OWORD *)(&v15.t_.functor.data + 8) = *(_OWORD *)(a2 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v8 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v15.t_.functor.type.const_qualified,
        0);
    }
  }
  v14.t_.functor.obj_ptr = 0;
  v9 = *(_QWORD *)a5;
  if ( *(_QWORD *)a5 )
  {
    v14.t_.functor.obj_ptr = *(void **)a5;
    if ( (v9 & 1) != 0 )
    {
      v15.t_.vtable = *(boost::detail::function::vtable_base **)(a5 + 24);
      *(_OWORD *)(&v14.t_.functor.data + 8) = *(_OWORD *)(a5 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(
        a5 + 8,
        &v14.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v18,
    (boost::_bi::value<boost::shared_ptr<RBX::LuaWebService> >)__PAIR128__(
                                                                 (boost::_bi::value<boost::function<void (std::string)> >_0 *)&v15.t_.functor,
                                                                 &v17),
    (boost::arg<1>)&v14.t_.functor,
    v14,
    v15);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage4(
    &retstr->l_,
    &v18);
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService>>,boost::arg<1>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4(&v18);
  if ( v14.t_.functor.obj_ptr )
  {
    if ( (v14.t_.functor.data & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v14.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(v14.t_.functor.bound_memfunc_ptr.gap8, v14.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v14.t_.functor.obj_ptr = 0;
  }
  if ( v15.t_.functor.obj_ptr )
  {
    if ( (v15.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v15.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v15.t_.functor.bound_memfunc_ptr.gap8, v15.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v15.t_.functor.obj_ptr = 0;
  }
  pi = v17.t_.pn.pi_;
  if ( v17.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x12ea780 | Name: _ZN5boost4bindIbN3RBX13LuaWebServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvbEEENSA_IFvS9_EEENS_10shared_ptrIS2_EES9_SC_SE_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISJ_T0_T1_T2_T3_EENSH_9list_av_4IT4_T5_T6_T7_E4typeEEEMSM_FSJ_SN_SO_SP_ESS_ST_SU_SV_
__int64 __fastcall boost::bind<bool,RBX::LuaWebService,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::LuaWebService>,std::string,boost::function<void ()(bool)>,boost::function<void ()(std::string)>>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 a5,
        __int64 *a6,
        __int64 *a7)
{
  volatile signed __int32 *v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v15; // rbx
  __int64 v17; // [rsp+8h] [rbp-F0h] BYREF
  __int128 v18; // [rsp+10h] [rbp-E8h] BYREF
  __int64 v19; // [rsp+20h] [rbp-D8h]
  __int64 v20; // [rsp+28h] [rbp-D0h] BYREF
  __int128 v21; // [rsp+30h] [rbp-C8h] BYREF
  __int64 v22; // [rsp+40h] [rbp-B8h]
  __int64 v23; // [rsp+48h] [rbp-B0h] BYREF
  volatile signed __int32 *v24; // [rsp+50h] [rbp-A8h]
  _BYTE v25[16]; // [rsp+58h] [rbp-A0h] BYREF
  void *ptr; // [rsp+68h] [rbp-90h]
  _BYTE v27[72]; // [rsp+70h] [rbp-88h] BYREF
  __int64 v28; // [rsp+B8h] [rbp-40h]
  __int128 v29; // [rsp+C0h] [rbp-38h] BYREF
  __int64 v30; // [rsp+D0h] [rbp-28h]

  v23 = *a4;
  v9 = (volatile signed __int32 *)a4[1];
  v24 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  std::string::basic_string(v25, a5);
  v20 = 0;
  v10 = *a6;
  if ( *a6 )
  {
    v20 = *a6;
    if ( (v10 & 1) != 0 )
    {
      v22 = a6[3];
      v21 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v21, 0);
    }
  }
  v17 = 0;
  v11 = *a7;
  if ( *a7 )
  {
    v17 = *a7;
    if ( (v11 & 1) != 0 )
    {
      v19 = a7[3];
      v18 = *(_OWORD *)(a7 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v18, 0);
    }
  }
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService>>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    v27,
    &v23,
    v25,
    &v20,
    &v17);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a3;
  boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService>>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(bool)>>>::storage3(
    (boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService> >,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (bool)> > > *)(a1 + 16),
    (const boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService> >,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (bool)> > > *)v27);
  *(_QWORD *)(a1 + 88) = 0;
  v12 = v28;
  if ( v28 )
  {
    *(_QWORD *)(a1 + 88) = v28;
    if ( (v12 & 1) != 0 )
    {
      *(_QWORD *)(a1 + 112) = v30;
      *(_OWORD *)(a1 + 96) = v29;
    }
    else
    {
      (*(void (__fastcall **)(__int128 *, __int64, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(&v29, a1 + 96, 0);
    }
  }
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService>>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(bool)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4((boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::LuaWebService> >,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (bool)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v27);
  if ( v17 )
  {
    if ( (v17 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v18, &v18, 2);
    }
    v17 = 0;
  }
  if ( v20 )
  {
    if ( (v20 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v20 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v21, &v21, 2);
    }
    v20 = 0;
  }
  if ( (v25[0] & 1) != 0 )
    operator delete(ptr);
  v15 = v24;
  if ( v24 )
  {
    if ( !_InterlockedSub(v24 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  return a1;
}


// Address: 0x144ff40 | Name: _ZN5boost4bindIvN3RBX12AssetServiceEbNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEElS9_NS_10shared_ptrINS1_8InstanceEEENS_8functionIFvlEEENSD_IFvS9_EEEPS2_NS_3argILi1EEES9_lS9_NSJ_ILi2EEESF_SH_EENS_3_bi6bind_tIT_NS_4_mfi3mf7ISO_T0_T1_T2_T3_T4_T5_T6_T7_EENSM_9list_av_8IT8_T9_T10_T11_T12_T13_T14_T15_E4typeEEEMSR_FSO_SS_ST_SU_SV_SW_SX_SY_ES11_S12_S13_S14_S15_S16_S17_S18_
_QWORD *__fastcall boost::bind<void,RBX::AssetService,bool,std::string,long,std::string,boost::shared_ptr<RBX::Instance>,boost::function<void ()(long)>,boost::function<void ()(std::string)>,RBX::AssetService*,boost::arg<1>,std::string,long,std::string,boost::arg<2>,boost::function<void ()(long)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        int a4,
        __int64 a5,
        int a6,
        __int64 a7,
        __int64 *a8,
        __int64 *a9)
{
  __int64 v12; // rax
  __int64 v13; // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v15)(__int128 *, __int128 *, __int64); // rax
  __int64 v17; // [rsp+8h] [rbp-120h] BYREF
  __int128 v18; // [rsp+10h] [rbp-118h] BYREF
  __int64 v19; // [rsp+20h] [rbp-108h]
  __int64 v20; // [rsp+28h] [rbp-100h] BYREF
  __int128 v21; // [rsp+30h] [rbp-F8h] BYREF
  __int64 v22; // [rsp+40h] [rbp-E8h]
  _BYTE v23[16]; // [rsp+48h] [rbp-E0h] BYREF
  void *ptr; // [rsp+58h] [rbp-D0h]
  _BYTE v25[16]; // [rsp+60h] [rbp-C8h] BYREF
  void *v26; // [rsp+70h] [rbp-B8h]
  _BYTE v27[176]; // [rsp+78h] [rbp-B0h] BYREF

  std::string::basic_string(v25, a5);
  std::string::basic_string(v23, a7);
  v20 = 0;
  v12 = *a8;
  if ( *a8 )
  {
    v20 = *a8;
    if ( (v12 & 1) != 0 )
    {
      v22 = a8[3];
      v21 = *(_OWORD *)(a8 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a8 + 1, &v21, 0);
    }
  }
  v17 = 0;
  v13 = *a9;
  if ( *a9 )
  {
    v17 = *a9;
    if ( (v13 & 1) != 0 )
    {
      v19 = a9[3];
      v18 = *(_OWORD *)(a9 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v13 & 0xFFFFFFFFFFFFFFFELL))(a9 + 1, &v18, 0);
    }
  }
  boost::_bi::list8<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::arg<2>,boost::_bi::value<boost::function<void ()(long)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list8(
    (unsigned int)v27,
    a4,
    (unsigned int)v25,
    a6,
    (unsigned int)v23,
    (unsigned int)&v20,
    (__int64)&v17);
  *a1 = a2;
  a1[1] = a3;
  boost::_bi::storage8<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::arg<2>,boost::_bi::value<boost::function<void ()(long)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage8(
    (boost::_bi::storage8<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::arg<2>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 2),
    (const boost::_bi::storage8<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::arg<2>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v27);
  boost::_bi::storage8<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::arg<2>,boost::_bi::value<boost::function<void ()(long)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage8((boost::_bi::storage8<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::arg<2>,boost::_bi::value<boost::function<void (long)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v27);
  if ( v17 )
  {
    if ( (v17 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v18, &v18, 2);
    }
    v17 = 0;
  }
  if ( v20 )
  {
    if ( (v20 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v20 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v21, &v21, 2);
    }
    v20 = 0;
  }
  if ( (v23[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v25[0] & 1) != 0 )
    operator delete(v26);
  return a1;
}


// Address: 0x14512b0 | Name: _ZN5boost4bindIvN3RBX12AssetServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvS9_EEEPS2_NS_3argILi1EEESC_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISI_T0_T1_T2_EENSG_9list_av_3IT3_T4_T5_E4typeEEEMSL_FSI_SM_SN_ESQ_SR_SS_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::AssetService,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::AssetService,std::string,boost::function<void ()(std::string)>,RBX::AssetService*,boost::arg<1>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::AssetService,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::AssetService *, std::string, boost::function<void (std::string)>),
        RBX::AssetService *a1,
        boost::_bi::value<RBX::AssetService *> a2,
        __int64 a5)
{
  boost::detail::function::vtable_base *v7; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void (std::string)> > v12; // [rsp+0h] [rbp-68h] BYREF
  boost::_bi::list3<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > v13; // [rsp+20h] [rbp-48h] BYREF

  v12.t_.vtable = 0;
  v7 = *(boost::detail::function::vtable_base **)a5;
  if ( *(_QWORD *)a5 )
  {
    v12.t_.vtable = *(boost::detail::function::vtable_base **)a5;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      v12.t_.functor = *(boost::detail::function::function_buffer *)(a5 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a5 + 8,
        &v12.t_.functor,
        0);
  }
  boost::_bi::list3<boost::_bi::value<RBX::AssetService *>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::list3(
    &v13,
    a2,
    (boost::arg<1>)&v12,
    v12);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v13.a1_.t_;
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v13.a3_.t_.vtable;
  if ( v13.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v13.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v13.a3_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v13.a3_.t_.functor,
        &retstr->l_.a3_.t_.functor,
        0);
      if ( !v13.a3_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v13.a3_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v13.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v13.a3_.t_.functor, &v13.a3_.t_.functor, 2);
      }
    }
    v13.a3_.t_.vtable = 0;
  }
LABEL_14:
  if ( v12.t_.vtable )
  {
    if ( ((__int64)v12.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v12.t_.functor, &v12.t_.functor, 2);
    }
    v12.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x1458b60 | Name: _ZN5boost4bindIvN3RBX14InventoryPagesERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEbNS_8functionIFvvEEENSC_IFvS9_EEENS_10shared_ptrIS2_EES9_bSE_SG_EENS_3_bi6bind_tIT_NS_4_mfi3mf4ISL_T0_T1_T2_T3_T4_EENSJ_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMSO_FSL_SP_SQ_SR_SS_ESV_SW_SX_SY_SZ_
__int64 __fastcall boost::bind<void,RBX::InventoryPages,std::string const&,bool,boost::function<void ()(void)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::InventoryPages>,std::string,bool,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 a5,
        unsigned __int8 a6,
        __int64 *a7,
        __int64 *a8)
{
  volatile signed __int32 *v10; // rax
  __int64 v11; // rax
  __int64 v12; // rax
  __int64 v13; // rax
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v15)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v16; // rbp
  __int64 v18; // [rsp+0h] [rbp-F8h] BYREF
  __int128 v19; // [rsp+8h] [rbp-F0h] BYREF
  __int64 v20; // [rsp+18h] [rbp-E0h]
  __int64 v21; // [rsp+20h] [rbp-D8h] BYREF
  __int128 v22; // [rsp+28h] [rbp-D0h] BYREF
  __int64 v23; // [rsp+38h] [rbp-C0h]
  __int64 v24; // [rsp+40h] [rbp-B8h] BYREF
  volatile signed __int32 *v25; // [rsp+48h] [rbp-B0h]
  _BYTE v26[16]; // [rsp+50h] [rbp-A8h] BYREF
  void *ptr; // [rsp+60h] [rbp-98h]
  _BYTE v28[80]; // [rsp+68h] [rbp-90h] BYREF
  __int64 v29; // [rsp+B8h] [rbp-40h]
  __int128 v30; // [rsp+C0h] [rbp-38h] BYREF
  __int64 v31; // [rsp+D0h] [rbp-28h]

  v24 = *a4;
  v10 = (volatile signed __int32 *)a4[1];
  v25 = v10;
  if ( v10 )
    _InterlockedAdd(v10 + 2, 1u);
  std::string::basic_string(v26, a5);
  v21 = 0;
  v11 = *a7;
  if ( *a7 )
  {
    v21 = *a7;
    if ( (v11 & 1) != 0 )
    {
      v23 = a7[3];
      v22 = *(_OWORD *)(a7 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v22, 0);
    }
  }
  v18 = 0;
  v12 = *a8;
  if ( *a8 )
  {
    v18 = *a8;
    if ( (v12 & 1) != 0 )
    {
      v20 = a8[3];
      v19 = *(_OWORD *)(a8 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(a8 + 1, &v19, 0);
    }
  }
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::InventoryPages>>,boost::_bi::value<std::string>,boost::_bi::value<bool>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    v28,
    &v24,
    v26,
    a6,
    &v21,
    &v18);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a3;
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::InventoryPages>>,boost::_bi::value<std::string>,boost::_bi::value<bool>,boost::_bi::value<boost::function<void ()(void)>>>::storage4(
    (boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::InventoryPages> >,boost::_bi::value<std::string >,boost::_bi::value<bool>,boost::_bi::value<boost::function<void ()> > > *)(a1 + 16),
    (const boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::InventoryPages> >,boost::_bi::value<std::string >,boost::_bi::value<bool>,boost::_bi::value<boost::function<void ()> > > *)v28);
  *(_QWORD *)(a1 + 96) = 0;
  v13 = v29;
  if ( v29 )
  {
    *(_QWORD *)(a1 + 96) = v29;
    if ( (v13 & 1) != 0 )
    {
      *(_QWORD *)(a1 + 120) = v31;
      *(_OWORD *)(a1 + 104) = v30;
    }
    else
    {
      (*(void (__fastcall **)(__int128 *, __int64, _QWORD))(v13 & 0xFFFFFFFFFFFFFFFELL))(&v30, a1 + 104, 0);
    }
  }
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::InventoryPages>>,boost::_bi::value<std::string>,boost::_bi::value<bool>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5((boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::InventoryPages> >,boost::_bi::value<std::string >,boost::_bi::value<bool>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > *)v28);
  if ( v18 )
  {
    if ( (v18 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v19, &v19, 2);
    }
    v18 = 0;
  }
  if ( v21 )
  {
    if ( (v21 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v22, &v22, 2);
    }
    v21 = 0;
  }
  if ( (v26[0] & 1) != 0 )
    operator delete(ptr);
  v16 = v25;
  if ( v25 )
  {
    if ( !_InterlockedSub(v25 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  return a1;
}


// Address: 0x14d7640 | Name: _ZN5boost4bindIvN3RBX11ChatServiceEbNS_10shared_ptrINS1_6PlayerEEES5_NSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEERKNS1_13SystemAddressENS3_IS2_EENS_3argILi1EEES5_S5_SC_SD_EENS_3_bi6bind_tIT_NS_4_mfi3mf5ISL_T0_T1_T2_T3_T4_T5_EENSJ_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMSO_FSL_SP_SQ_SR_SS_ST_ESW_SX_SY_SZ_S10_S11_
_QWORD *__fastcall boost::bind<void,RBX::ChatService,bool,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress const&,boost::shared_ptr<RBX::ChatService>,boost::arg<1>,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5,
        __int64 *a6,
        __int64 a7,
        __int64 a8)
{
  volatile signed __int32 *v9; // rax
  volatile signed __int32 *v10; // rax
  volatile signed __int32 *v11; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v13; // rax
  boost::detail::sp_counted_base *v14; // rax
  volatile signed __int32 *v15; // rbx
  volatile signed __int32 *v16; // rbx
  volatile signed __int32 *v17; // rbx
  __int64 v19; // [rsp+0h] [rbp-B8h] BYREF
  volatile signed __int32 *v20; // [rsp+8h] [rbp-B0h]
  __int64 v21; // [rsp+10h] [rbp-A8h] BYREF
  volatile signed __int32 *v22; // [rsp+18h] [rbp-A0h]
  __int64 v23; // [rsp+20h] [rbp-98h] BYREF
  volatile signed __int32 *v24; // [rsp+28h] [rbp-90h]
  _BYTE v25[16]; // [rsp+30h] [rbp-88h] BYREF
  void *v26; // [rsp+40h] [rbp-78h]
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> > > v27; // [rsp+48h] [rbp-70h] BYREF
  char v28[16]; // [rsp+78h] [rbp-40h] BYREF
  void *ptr; // [rsp+88h] [rbp-30h]
  __int64 v30; // [rsp+90h] [rbp-28h]

  v23 = *a4;
  v9 = (volatile signed __int32 *)a4[1];
  v24 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  v21 = *a5;
  v10 = (volatile signed __int32 *)a5[1];
  v22 = v10;
  if ( v10 )
    _InterlockedAdd(v10 + 2, 1u);
  v19 = *a6;
  v11 = (volatile signed __int32 *)a6[1];
  v20 = v11;
  if ( v11 )
    _InterlockedAdd(v11 + 2, 1u);
  std::string::basic_string(v25, a7);
  ((void (__fastcall *)(boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> > > *, __int64 *, __int64 *, __int64 *, _BYTE *, __int64))boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<std::string>,boost::_bi::value<RBX::SystemAddress>>::list6)(
    &v27,
    &v23,
    &v21,
    &v19,
    v25,
    a8);
  *a1 = a2;
  a1[1] = a3;
  a1[2] = v27.a1_.t_.px;
  pi = v27.a1_.t_.pn.pi_;
  a1[3] = v27.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  a1[4] = v27.a3_.t_.px;
  v13 = v27.a3_.t_.pn.pi_;
  a1[5] = v27.a3_.t_.pn.pi_;
  if ( v13 )
    _InterlockedAdd(&v13->use_count_, 1u);
  a1[6] = v27.a4_.t_.px;
  v14 = v27.a4_.t_.pn.pi_;
  a1[7] = v27.a4_.t_.pn.pi_;
  if ( v14 )
    _InterlockedAdd(&v14->use_count_, 1u);
  std::string::basic_string(a1 + 8, v28);
  a1[11] = v30;
  if ( (v28[0] & 1) != 0 )
    operator delete(ptr);
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>>::~storage4(&v27);
  if ( (v25[0] & 1) != 0 )
    operator delete(v26);
  v15 = v20;
  if ( v20 )
  {
    if ( !_InterlockedSub(v20 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  v16 = v22;
  if ( v22 )
  {
    if ( !_InterlockedSub(v22 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  v17 = v24;
  if ( v24 )
  {
    if ( !_InterlockedSub(v24 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
      if ( !_InterlockedSub(v17 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
    }
  }
  return a1;
}


// Address: 0x14d7ac0 | Name: _ZN5boost4bindIvN3RBX11ChatServiceEbNS_10shared_ptrINS1_6PlayerEEES5_NSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEERKNS1_13SystemAddressENS3_IS2_EEbS5_S5_SC_SD_EENS_3_bi6bind_tIT_NS_4_mfi3mf5ISJ_T0_T1_T2_T3_T4_T5_EENSH_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMSM_FSJ_SN_SO_SP_SQ_SR_ESU_SV_SW_SX_SY_SZ_
__int64 __fastcall boost::bind<void,RBX::ChatService,bool,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress const&,boost::shared_ptr<RBX::ChatService>,bool,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        unsigned __int8 a5,
        __int64 *a6,
        __int64 *a7,
        __int64 a8,
        __int64 a9)
{
  volatile signed __int32 *v11; // rax
  volatile signed __int32 *v12; // rcx
  volatile signed __int32 *v13; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v15; // rax
  boost::detail::sp_counted_base *v16; // rax
  volatile signed __int32 *v17; // rbp
  volatile signed __int32 *v18; // rbp
  volatile signed __int32 *v19; // rbp
  __int64 v21; // [rsp+8h] [rbp-C0h] BYREF
  volatile signed __int32 *v22; // [rsp+10h] [rbp-B8h]
  __int64 v23; // [rsp+18h] [rbp-B0h] BYREF
  volatile signed __int32 *v24; // [rsp+20h] [rbp-A8h]
  __int64 v25; // [rsp+28h] [rbp-A0h] BYREF
  volatile signed __int32 *v26; // [rsp+30h] [rbp-98h]
  _BYTE v27[16]; // [rsp+38h] [rbp-90h] BYREF
  void *v28; // [rsp+48h] [rbp-80h]
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::_bi::value<bool>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> > > v29; // [rsp+50h] [rbp-78h] BYREF
  char v30[16]; // [rsp+88h] [rbp-40h] BYREF
  void *ptr; // [rsp+98h] [rbp-30h]
  __int64 v32; // [rsp+A0h] [rbp-28h]

  v25 = *a4;
  v11 = (volatile signed __int32 *)a4[1];
  v26 = v11;
  if ( v11 )
    _InterlockedAdd(v11 + 2, 1u);
  v23 = *a6;
  v12 = (volatile signed __int32 *)a6[1];
  v24 = v12;
  if ( v12 )
    _InterlockedAdd(v12 + 2, 1u);
  v21 = *a7;
  v13 = (volatile signed __int32 *)a7[1];
  v22 = v13;
  if ( v13 )
    _InterlockedAdd(v13 + 2, 1u);
  std::string::basic_string(v27, a8);
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::_bi::value<bool>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<std::string>,boost::_bi::value<RBX::SystemAddress>>::list6(
    (unsigned int)&v29,
    (unsigned int)&v25,
    a5,
    (unsigned int)&v23,
    (unsigned int)&v21,
    (unsigned int)v27,
    a9);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a3;
  *(_QWORD *)(a1 + 16) = v29.a1_.t_.px;
  pi = v29.a1_.t_.pn.pi_;
  *(_QWORD *)(a1 + 24) = v29.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  *(_BYTE *)(a1 + 32) = v29.a2_.t_;
  *(_QWORD *)(a1 + 40) = v29.a3_.t_.px;
  v15 = v29.a3_.t_.pn.pi_;
  *(_QWORD *)(a1 + 48) = v29.a3_.t_.pn.pi_;
  if ( v15 )
    _InterlockedAdd(&v15->use_count_, 1u);
  *(_QWORD *)(a1 + 56) = v29.a4_.t_.px;
  v16 = v29.a4_.t_.pn.pi_;
  *(_QWORD *)(a1 + 64) = v29.a4_.t_.pn.pi_;
  if ( v16 )
    _InterlockedAdd(&v16->use_count_, 1u);
  std::string::basic_string(a1 + 72, v30);
  *(_QWORD *)(a1 + 96) = v32;
  if ( (v30[0] & 1) != 0 )
    operator delete(ptr);
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::_bi::value<bool>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>>::~storage4(&v29);
  if ( (v27[0] & 1) != 0 )
    operator delete(v28);
  v17 = v22;
  if ( v22 )
  {
    if ( !_InterlockedSub(v22 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
      if ( !_InterlockedSub(v17 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
    }
  }
  v18 = v24;
  if ( v24 )
  {
    if ( !_InterlockedSub(v24 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
      if ( !_InterlockedSub(v18 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
    }
  }
  v19 = v26;
  if ( v26 )
  {
    if ( !_InterlockedSub(v26 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 16LL))(v19);
      if ( !_InterlockedSub(v19 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 24LL))(v19);
    }
  }
  return a1;
}


// Address: 0x14d87b0 | Name: _ZN5boost4bindIvN3RBX11ChatServiceERKNS1_16TextFilterResultENS_10shared_ptrINS1_6PlayerEEES8_NSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEERKNS1_13SystemAddressENS6_IS2_EENS_3argILi1EEES8_S8_SF_SG_EENS_3_bi6bind_tIT_NS_4_mfi3mf5ISO_T0_T1_T2_T3_T4_T5_EENSM_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMSR_FSO_SS_ST_SU_SV_SW_ESZ_S10_S11_S12_S13_S14_
_QWORD *__fastcall boost::bind<void,RBX::ChatService,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress const&,boost::shared_ptr<RBX::ChatService>,boost::arg<1>,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,std::string,RBX::SystemAddress>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5,
        __int64 *a6,
        __int64 a7,
        __int64 a8)
{
  volatile signed __int32 *v9; // rax
  volatile signed __int32 *v10; // rax
  volatile signed __int32 *v11; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v13; // rax
  boost::detail::sp_counted_base *v14; // rax
  volatile signed __int32 *v15; // rbx
  volatile signed __int32 *v16; // rbx
  volatile signed __int32 *v17; // rbx
  __int64 v19; // [rsp+0h] [rbp-B8h] BYREF
  volatile signed __int32 *v20; // [rsp+8h] [rbp-B0h]
  __int64 v21; // [rsp+10h] [rbp-A8h] BYREF
  volatile signed __int32 *v22; // [rsp+18h] [rbp-A0h]
  __int64 v23; // [rsp+20h] [rbp-98h] BYREF
  volatile signed __int32 *v24; // [rsp+28h] [rbp-90h]
  _BYTE v25[16]; // [rsp+30h] [rbp-88h] BYREF
  void *v26; // [rsp+40h] [rbp-78h]
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> > > v27; // [rsp+48h] [rbp-70h] BYREF
  char v28[16]; // [rsp+78h] [rbp-40h] BYREF
  void *ptr; // [rsp+88h] [rbp-30h]
  __int64 v30; // [rsp+90h] [rbp-28h]

  v23 = *a4;
  v9 = (volatile signed __int32 *)a4[1];
  v24 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  v21 = *a5;
  v10 = (volatile signed __int32 *)a5[1];
  v22 = v10;
  if ( v10 )
    _InterlockedAdd(v10 + 2, 1u);
  v19 = *a6;
  v11 = (volatile signed __int32 *)a6[1];
  v20 = v11;
  if ( v11 )
    _InterlockedAdd(v11 + 2, 1u);
  std::string::basic_string(v25, a7);
  ((void (__fastcall *)(boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> > > *, __int64 *, __int64 *, __int64 *, _BYTE *, __int64))boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<std::string>,boost::_bi::value<RBX::SystemAddress>>::list6)(
    &v27,
    &v23,
    &v21,
    &v19,
    v25,
    a8);
  *a1 = a2;
  a1[1] = a3;
  a1[2] = v27.a1_.t_.px;
  pi = v27.a1_.t_.pn.pi_;
  a1[3] = v27.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  a1[4] = v27.a3_.t_.px;
  v13 = v27.a3_.t_.pn.pi_;
  a1[5] = v27.a3_.t_.pn.pi_;
  if ( v13 )
    _InterlockedAdd(&v13->use_count_, 1u);
  a1[6] = v27.a4_.t_.px;
  v14 = v27.a4_.t_.pn.pi_;
  a1[7] = v27.a4_.t_.pn.pi_;
  if ( v14 )
    _InterlockedAdd(&v14->use_count_, 1u);
  std::string::basic_string(a1 + 8, v28);
  a1[11] = v30;
  if ( (v28[0] & 1) != 0 )
    operator delete(ptr);
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>>::~storage4(&v27);
  if ( (v25[0] & 1) != 0 )
    operator delete(v26);
  v15 = v20;
  if ( v20 )
  {
    if ( !_InterlockedSub(v20 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  v16 = v22;
  if ( v22 )
  {
    if ( !_InterlockedSub(v22 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  v17 = v24;
  if ( v24 )
  {
    if ( !_InterlockedSub(v24 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
      if ( !_InterlockedSub(v17 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
    }
  }
  return a1;
}


// Address: 0x14d8e90 | Name: _ZN5boost4bindIvN3RBX11ChatServiceEbNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvRKNS1_16TextFilterResultEEEENS_10shared_ptrINS1_6PlayerEEENSG_IS2_EENS_3argILi1EEES9_SF_SI_EENS_3_bi6bind_tIT_NS_4_mfi3mf4ISO_T0_T1_T2_T3_T4_EENSM_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMSR_FSO_SS_ST_SU_SV_ESY_SZ_S10_S11_S12_
_QWORD *__fastcall boost::bind<void,RBX::ChatService,bool,std::string,boost::function<void ()(RBX::TextFilterResult const&)>,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::ChatService>,boost::arg<1>,std::string,boost::function<void ()(RBX::TextFilterResult const&)>,boost::shared_ptr<RBX::Player>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 a5,
        __int64 *a6,
        __int64 *a7)
{
  volatile signed __int32 *v9; // rax
  __int64 v10; // rax
  volatile signed __int32 *v11; // rax
  __int64 v12; // rax
  volatile signed __int32 *v13; // rbx
  void (__fastcall *v14)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v15; // rbx
  __int64 v17; // [rsp+8h] [rbp-D0h] BYREF
  __int128 v18; // [rsp+10h] [rbp-C8h] BYREF
  __int64 v19; // [rsp+20h] [rbp-B8h]
  __int64 v20; // [rsp+28h] [rbp-B0h] BYREF
  volatile signed __int32 *v21; // [rsp+30h] [rbp-A8h]
  __int64 v22; // [rsp+38h] [rbp-A0h] BYREF
  volatile signed __int32 *v23; // [rsp+40h] [rbp-98h]
  _BYTE v24[16]; // [rsp+48h] [rbp-90h] BYREF
  void *ptr; // [rsp+58h] [rbp-80h]
  _BYTE v26[72]; // [rsp+60h] [rbp-78h] BYREF
  __int64 v27; // [rsp+A8h] [rbp-30h]
  __int64 v28; // [rsp+B0h] [rbp-28h]

  v22 = *a4;
  v9 = (volatile signed __int32 *)a4[1];
  v23 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  std::string::basic_string(v24, a5);
  v17 = 0;
  v10 = *a6;
  if ( *a6 )
  {
    v17 = *a6;
    if ( (v10 & 1) != 0 )
    {
      v19 = a6[3];
      v18 = *(_OWORD *)(a6 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a6 + 1, &v18, 0);
    }
  }
  v20 = *a7;
  v11 = (volatile signed __int32 *)a7[1];
  v21 = v11;
  if ( v11 )
    _InterlockedAdd(v11 + 2, 1u);
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(RBX::TextFilterResult const&)>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>>::list5(
    v26,
    &v22,
    v24,
    &v17,
    &v20);
  *a1 = a2;
  a1[1] = a3;
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(RBX::TextFilterResult const&)>>>::storage4(
    (boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (const RBX::TextFilterResult &)> > > *)(a1 + 2),
    (const boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (const RBX::TextFilterResult &)> > > *)v26);
  a1[11] = v27;
  v12 = v28;
  a1[12] = v28;
  if ( v12 )
    _InterlockedAdd((volatile signed __int32 *)(v12 + 8), 1u);
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::function<void ()(RBX::TextFilterResult const&)>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>>::~storage5((boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::function<void (const RBX::TextFilterResult &)> >,boost::_bi::value<boost::shared_ptr<RBX::Player> > > *)v26);
  v13 = v21;
  if ( v21 )
  {
    if ( !_InterlockedSub(v21 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  if ( v17 )
  {
    if ( (v17 & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v17 & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v18, &v18, 2);
    }
    v17 = 0;
  }
  if ( (v24[0] & 1) != 0 )
    operator delete(ptr);
  v15 = v23;
  if ( v23 )
  {
    if ( !_InterlockedSub(v23 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  return a1;
}


// Address: 0x14d9460 | Name: _ZN5boost4bindIvN3RBX11ChatServiceERKNS1_16TextFilterResultENS_10shared_ptrINS1_6PlayerEEES8_NS_8functionIFvNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEEEEESI_NS6_IS2_EENS_3argILi1EEES8_S8_SI_SI_EENS_3_bi6bind_tIT_NS_4_mfi3mf5ISO_T0_T1_T2_T3_T4_T5_EENSM_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMSR_FSO_SS_ST_SU_SV_SW_ESZ_S10_S11_S12_S13_S14_
boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::ChatService,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::ChatService>,boost::arg<1>,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::ChatService *, const RBX::TextFilterResult *, boost::shared_ptr<RBX::Player>, boost::shared_ptr<RBX::Player>, boost::function<void (std::string)>_0, boost::function<void (std::string)>_0),
        boost::shared_ptr<RBX::ChatService> a1,
        __int64 *a2,
        _QWORD *r9_0,
        boost::shared_ptr<RBX::Player> a3)
{
  boost::shared_ptr<RBX::ChatService>::element_type *px; // r15
  boost::detail::sp_counted_base *v7; // rax
  volatile signed __int32 *v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  int (**v11)(void); // rax
  boost::_bi::value<boost::shared_ptr<RBX::Player> > v12; // r8
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v14)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v15)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v16)(_BYTE *, _BYTE *, __int64); // rax
  volatile signed __int32 *v17; // rbx
  volatile signed __int32 *v18; // rbx
  boost::detail::sp_counted_base *pi; // rbx
  _BYTE v21[80]; // [rsp+0h] [rbp-F8h] BYREF
  __int64 a1a; // [rsp+50h] [rbp-A8h] BYREF
  volatile signed __int32 *v23; // [rsp+58h] [rbp-A0h]
  boost::_bi::value<boost::shared_ptr<RBX::ChatService> > v24; // [rsp+60h] [rbp-98h] BYREF
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > v25; // [rsp+70h] [rbp-88h] BYREF

  px = a1.px;
  v24.t_.px = (boost::shared_ptr<RBX::ChatService>::element_type *)a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v24.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  a1a = *a2;
  v8 = (volatile signed __int32 *)a2[1];
  v23 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  *(_QWORD *)&v21[64] = *r9_0;
  v9 = r9_0[1];
  *(_QWORD *)&v21[72] = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 8), 1u);
  *(_QWORD *)&v21[32] = 0;
  v10 = *(_QWORD *)a3.px;
  if ( *(_QWORD *)a3.px )
  {
    *(_QWORD *)&v21[32] = *(_QWORD *)a3.px;
    if ( (v10 & 1) != 0 )
    {
      *(_QWORD *)&v21[56] = *((_QWORD *)a3.px + 3);
      *(_OWORD *)&v21[40] = *(_OWORD *)((char *)a3.px + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, _BYTE *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))((char *)a3.px + 8, &v21[40], 0);
    }
  }
  *(_QWORD *)v21 = 0;
  v11 = a3.pn.pi_->_vptr$sp_counted_base;
  if ( a3.pn.pi_->_vptr$sp_counted_base )
  {
    *(_QWORD *)v21 = a3.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v11 & 1) != 0 )
    {
      *(_QWORD *)&v21[24] = *(_QWORD *)&a3.pn.pi_[1].use_count_;
      *(_OWORD *)&v21[8] = *(_OWORD *)&a3.pn.pi_->use_count_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, _BYTE *, _QWORD))((unsigned __int64)v11
                                                                                     & 0xFFFFFFFFFFFFFFFELL))(
        &a3.pn.pi_->use_count_,
        &v21[8],
        0);
    }
  }
  v12.t_.px = &v21[32];
  v12.t_.pn.pi_ = (boost::detail::sp_counted_base *)v21;
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list6(
    &v25,
    (boost::_bi::value<boost::shared_ptr<RBX::ChatService> >)__PAIR128__(&a1a, &v24),
    (boost::arg<1>)&v21[64],
    v12,
    *(boost::_bi::value<boost::shared_ptr<RBX::Player> > *)v21,
    *(boost::_bi::value<boost::function<void (std::string)> >_0 *)&v21[16],
    *(boost::_bi::value<boost::function<void (std::string)> >_0 *)&v21[48]);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage6(
    &retstr->l_,
    &v25);
  if ( v25.a6_.t_.vtable )
  {
    if ( ((__int64)v25.a6_.t_.vtable & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v25.a6_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v25.a6_.t_.functor, &v25.a6_.t_.functor, 2);
    }
    v25.a6_.t_.vtable = 0;
  }
  if ( v25.a5_.t_.vtable )
  {
    if ( ((__int64)v25.a5_.t_.vtable & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v25.a5_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v25.a5_.t_.functor, &v25.a5_.t_.functor, 2);
    }
    v25.a5_.t_.vtable = 0;
  }
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>>::~storage4(&v25);
  if ( *(_QWORD *)v21 )
  {
    if ( (v21[0] & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)v21 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v21[8], &v21[8], 2);
    }
    *(_QWORD *)v21 = 0;
  }
  if ( *(_QWORD *)&v21[32] )
  {
    if ( (v21[32] & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v21[32] & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v21[40], &v21[40], 2);
    }
    *(_QWORD *)&v21[32] = 0;
  }
  v17 = *(volatile signed __int32 **)&v21[72];
  if ( *(_QWORD *)&v21[72] )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v21[72] + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 16LL))(v17);
      if ( !_InterlockedSub(v17 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
    }
  }
  v18 = v23;
  if ( v23 )
  {
    if ( !_InterlockedSub(v23 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
      if ( !_InterlockedSub(v18 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
    }
  }
  pi = v24.t_.pn.pi_;
  if ( v24.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v24.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x14d9d10 | Name: _ZN5boost4bindIvN3RBX11ChatServiceERKNS1_16TextFilterResultERKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS_10shared_ptrINS1_6PlayerEEESH_NS_8functionIFvSC_EEESK_NSF_IS2_EENS_3argILi1EEESC_SH_SH_SK_SK_EENS_3_bi6bind_tIT_NS_4_mfi3mf6ISQ_T0_T1_T2_T3_T4_T5_T6_EENSO_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEEMST_FSQ_SU_SV_SW_SX_SY_SZ_ES12_S13_S14_S15_S16_S17_S18_
_QWORD *__fastcall boost::bind<void,RBX::ChatService,RBX::TextFilterResult const&,std::string const&,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::ChatService>,boost::arg<1>,std::string,boost::shared_ptr<RBX::Player>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 a5,
        __int64 *a6,
        __int64 *a7,
        __int64 *a8,
        __int64 *a9)
{
  volatile signed __int32 *v11; // rax
  volatile signed __int32 *v12; // rcx
  volatile signed __int32 *v13; // rax
  __int64 v14; // rax
  __int64 v15; // rax
  void (__fastcall *v16)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v17)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v18)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v19)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v20; // rbx
  volatile signed __int32 *v21; // rbx
  volatile signed __int32 *v22; // rbx
  __int64 v24; // [rsp+8h] [rbp-130h] BYREF
  __int128 v25; // [rsp+10h] [rbp-128h] BYREF
  __int64 v26; // [rsp+20h] [rbp-118h]
  __int64 v27; // [rsp+28h] [rbp-110h] BYREF
  __int128 v28; // [rsp+30h] [rbp-108h] BYREF
  __int64 v29; // [rsp+40h] [rbp-F8h]
  __int64 v30; // [rsp+48h] [rbp-F0h] BYREF
  volatile signed __int32 *v31; // [rsp+50h] [rbp-E8h]
  __int64 v32; // [rsp+58h] [rbp-E0h] BYREF
  volatile signed __int32 *v33; // [rsp+60h] [rbp-D8h]
  __int64 v34; // [rsp+68h] [rbp-D0h] BYREF
  volatile signed __int32 *v35; // [rsp+70h] [rbp-C8h]
  _BYTE v36[16]; // [rsp+78h] [rbp-C0h] BYREF
  void *ptr; // [rsp+88h] [rbp-B0h]
  _BYTE v38[72]; // [rsp+90h] [rbp-A8h] BYREF
  __int64 v39; // [rsp+D8h] [rbp-60h]
  _BYTE v40[24]; // [rsp+E0h] [rbp-58h] BYREF
  __int64 v41; // [rsp+F8h] [rbp-40h]
  _BYTE v42[56]; // [rsp+100h] [rbp-38h] BYREF

  v34 = *a4;
  v11 = (volatile signed __int32 *)a4[1];
  v35 = v11;
  if ( v11 )
    _InterlockedAdd(v11 + 2, 1u);
  std::string::basic_string(v36, a5);
  v32 = *a6;
  v12 = (volatile signed __int32 *)a6[1];
  v33 = v12;
  if ( v12 )
    _InterlockedAdd(v12 + 2, 1u);
  v30 = *a7;
  v13 = (volatile signed __int32 *)a7[1];
  v31 = v13;
  if ( v13 )
    _InterlockedAdd(v13 + 2, 1u);
  v27 = 0;
  v14 = *a8;
  if ( *a8 )
  {
    v27 = *a8;
    if ( (v14 & 1) != 0 )
    {
      v29 = a8[3];
      v28 = *(_OWORD *)(a8 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v14 & 0xFFFFFFFFFFFFFFFELL))(a8 + 1, &v28, 0);
    }
  }
  v24 = 0;
  v15 = *a9;
  if ( *a9 )
  {
    v24 = *a9;
    if ( (v15 & 1) != 0 )
    {
      v26 = a9[3];
      v25 = *(_OWORD *)(a9 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v15 & 0xFFFFFFFFFFFFFFFELL))(a9 + 1, &v25, 0);
    }
  }
  boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list7(
    (unsigned int)v38,
    (unsigned int)&v34,
    (unsigned int)v36,
    (unsigned int)&v32,
    (unsigned int)&v30,
    (unsigned int)&v27,
    (__int64)&v24);
  *a1 = a2;
  a1[1] = a3;
  boost::_bi::storage7<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage7(
    (boost::_bi::storage7<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 2),
    (const boost::_bi::storage7<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v38);
  if ( v41 )
  {
    if ( (v41 & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v41 & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(v42, v42, 2);
    }
    v41 = 0;
  }
  if ( v39 )
  {
    if ( (v39 & 1) == 0 )
    {
      v17 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v39 & 0xFFFFFFFFFFFFFFFELL);
      if ( v17 )
        v17(v40, v40, 2);
    }
    v39 = 0;
  }
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::shared_ptr<RBX::Player>>>::~storage5((boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::shared_ptr<RBX::Player> > > *)v38);
  if ( v24 )
  {
    if ( (v24 & 1) == 0 )
    {
      v18 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v24 & 0xFFFFFFFFFFFFFFFELL);
      if ( v18 )
        v18(&v25, &v25, 2);
    }
    v24 = 0;
  }
  if ( v27 )
  {
    if ( (v27 & 1) == 0 )
    {
      v19 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v27 & 0xFFFFFFFFFFFFFFFELL);
      if ( v19 )
        v19(&v28, &v28, 2);
    }
    v27 = 0;
  }
  v20 = v31;
  if ( v31 )
  {
    if ( !_InterlockedSub(v31 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 16LL))(v20);
      if ( !_InterlockedSub(v20 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 24LL))(v20);
    }
  }
  v21 = v33;
  if ( v33 )
  {
    if ( !_InterlockedSub(v33 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 16LL))(v21);
      if ( !_InterlockedSub(v21 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 24LL))(v21);
    }
  }
  if ( (v36[0] & 1) != 0 )
    operator delete(ptr);
  v22 = v35;
  if ( v35 )
  {
    if ( !_InterlockedSub(v35 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 16LL))(v22);
      if ( !_InterlockedSub(v22 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 24LL))(v22);
    }
  }
  return a1;
}


// Address: 0x14da7b0 | Name: _ZN5boost4bindIvN3RBX11ChatServiceERKNS1_16TextFilterResultENS_10shared_ptrINS1_6PlayerEEENS_8functionIFvNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEEEEESI_NS6_IS2_EENS_3argILi1EEES8_SI_SI_EENS_3_bi6bind_tIT_NS_4_mfi3mf4ISO_T0_T1_T2_T3_T4_EENSM_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMSR_FSO_SS_ST_SU_SV_ESY_SZ_S10_S11_S12_
// local variable allocation has failed, the output may be wrong!
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >,boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::ChatService,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::ChatService>,boost::arg<1>,boost::shared_ptr<RBX::Player>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::ChatService,const RBX::TextFilterResult &,boost::shared_ptr<RBX::Player>,boost::function<void (std::string)>,boost::function<void (std::string)> >,boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::ChatService *, const RBX::TextFilterResult *, boost::shared_ptr<RBX::Player>, boost::function<void (std::string)>_0, boost::function<void (std::string)>_0),
        boost::shared_ptr<RBX::ChatService> a1,
        __int64 *a2,
        __int64 r9_0,
        boost::shared_ptr<RBX::Player> a3)
{
  boost::shared_ptr<RBX::ChatService>::element_type *px; // r14
  boost::detail::sp_counted_base *v7; // rax
  volatile signed __int32 *v8; // rax
  unsigned __int64 v9; // rax
  __int64 v10; // rax
  boost::detail::function::function_buffer *p_functor; // r8
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(char *, char *, __int64); // rax
  void (__fastcall *v14)(char *, char *, __int64); // rax
  volatile signed __int32 *v15; // rbx
  boost::detail::sp_counted_base *pi; // rbx
  boost::_bi::value<boost::function<void (std::string)> >_0 v18; // [rsp+0h] [rbp-E8h] BYREF
  boost::_bi::value<boost::function<void (std::string)> >_0 v19; // [rsp+20h] [rbp-C8h] BYREF
  __int64 v20; // [rsp+40h] [rbp-A8h]
  __int64 a1a; // [rsp+48h] [rbp-A0h] BYREF
  volatile signed __int32 *v22; // [rsp+50h] [rbp-98h]
  boost::_bi::value<boost::shared_ptr<RBX::ChatService> > v23; // [rsp+58h] [rbp-90h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > v24; // [rsp+68h] [rbp-80h] BYREF

  px = a1.px;
  v23.t_.px = (boost::shared_ptr<RBX::ChatService>::element_type *)a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v23.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  a1a = *a2;
  v8 = (volatile signed __int32 *)a2[1];
  v22 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v19.t_.functor.obj_ptr = 0;
  v9 = *(_QWORD *)r9_0;
  if ( *(_QWORD *)r9_0 )
  {
    v19.t_.functor.obj_ptr = *(void **)r9_0;
    if ( (v9 & 1) != 0 )
    {
      v20 = *(_QWORD *)(r9_0 + 24);
      *(_OWORD *)(&v19.t_.functor.data + 8) = *(_OWORD *)(r9_0 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(
        r9_0 + 8,
        &v19.t_.functor.type.const_qualified,
        0);
    }
  }
  v18.t_.functor.obj_ptr = 0;
  v10 = *(_QWORD *)a3.px;
  if ( *(_QWORD *)a3.px )
  {
    v18.t_.functor.obj_ptr = *(void **)a3.px;
    if ( (v10 & 1) != 0 )
    {
      v19.t_.vtable = (boost::detail::function::vtable_base *)*((_QWORD *)a3.px + 3);
      *(_OWORD *)(&v18.t_.functor.data + 8) = *(_OWORD *)((char *)a3.px + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, bool *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(
        (char *)a3.px + 8,
        &v18.t_.functor.type.const_qualified,
        0);
    }
  }
  p_functor = &v18.t_.functor;
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    &v24,
    (boost::_bi::value<boost::shared_ptr<RBX::ChatService> >)__PAIR128__(&a1a, &v23),
    (boost::arg<1>)&v19.t_.functor,
    *(boost::_bi::value<boost::shared_ptr<RBX::Player> > *)(&r9_0 - 1),
    v18,
    v19);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage5(
    &retstr->l_,
    &v24);
  if ( v24.a5_.t_.vtable )
  {
    if ( ((__int64)v24.a5_.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v24.a5_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v24.a5_.t_.functor, &v24.a5_.t_.functor, 2);
    }
    v24.a5_.t_.vtable = 0;
  }
  boost::_bi::storage4<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::Player>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4(&v24);
  if ( v18.t_.functor.obj_ptr )
  {
    if ( (v18.t_.functor.data & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v18.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(v18.t_.functor.bound_memfunc_ptr.gap8, v18.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v18.t_.functor.obj_ptr = 0;
  }
  if ( v19.t_.functor.obj_ptr )
  {
    if ( (v19.t_.functor.data & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v19.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(v19.t_.functor.bound_memfunc_ptr.gap8, v19.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v19.t_.functor.obj_ptr = 0;
  }
  v15 = v22;
  if ( v22 )
  {
    if ( !_InterlockedSub(v22 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  pi = v23.t_.pn.pi_;
  if ( v23.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v23.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x14dac10 | Name: _ZN5boost4bindIvN3RBX11ChatServiceENS_10shared_ptrINS1_8InstanceEEENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEbSC_SC_SC_NS3_IS2_EENS_3argILi1EEENSE_ILi2EEENSE_ILi3EEENSE_ILi4EEENSE_ILi5EEENSE_ILi6EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf6ISN_T0_T1_T2_T3_T4_T5_T6_EENSL_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEEMSQ_FSN_SR_SS_ST_SU_SV_SW_ESZ_S10_S11_S12_S13_S14_S15_
boost::_bi::bind_t<void,boost::_mfi::mf6<void,RBX::ChatService,boost::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string >,boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6> > > *__fastcall boost::bind<void,RBX::ChatService,boost::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string,boost::shared_ptr<RBX::ChatService>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6>>(
        boost::_bi::bind_t<void,boost::_mfi::mf6<void,RBX::ChatService,boost::shared_ptr<RBX::Instance>,std::string,bool,std::string,std::string,std::string >,boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6> > > *__return_ptr retstr,
        void (*f)(RBX::ChatService *, boost::shared_ptr<RBX::Instance>, std::string, bool, std::string, std::string, std::string),
        boost::shared_ptr<RBX::ChatService> a1,
        boost::arg<1> a2,
        boost::arg<2> a3)
{
  boost::shared_ptr<RBX::ChatService>::element_type *px; // r14
  __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // r14
  volatile signed __int32 *v9; // rbx
  boost::arg<4> v11[8]; // [rsp+0h] [rbp-38h] BYREF
  boost::arg<5> v12[8]; // [rsp+8h] [rbp-30h]
  boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::ChatService> >,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6> > v13; // [rsp+10h] [rbp-28h] BYREF

  px = a1.px;
  *(_QWORD *)&v11[0].gap0 = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(_QWORD *)&a1.pn.pi_->use_count_;
  *(_QWORD *)&v12[0].gap0 = v6;
  if ( v6 )
    _InterlockedAdd((volatile signed __int32 *)(v6 + 8), 1u);
  boost::_bi::list7<boost::_bi::value<boost::shared_ptr<RBX::ChatService>>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6>>::list7(
    &v13,
    (boost::_bi::value<boost::shared_ptr<RBX::ChatService> >)__PAIR128__((unsigned __int64)a1.px, v11),
    (boost::arg<1>)a1.pn.pi_,
    (boost::arg<2>)a2.gap0,
    (boost::arg<3>)a3.gap0,
    v11[0],
    v12[0],
    (boost::arg<6>)v13.a1_.t_.px);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v13.a1_.t_.px;
  pi = v13.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v13.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v8 = v13.a1_.t_.pn.pi_;
    if ( v13.a1_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v13.a1_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  v9 = *(volatile signed __int32 **)&v12[0].gap0;
  if ( *(_QWORD *)&v12[0].gap0 )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v12[0].gap0 + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  return retstr;
}


// Address: 0x14dade0 | Name: _ZN5boost4bindIvN3RBX11ChatServiceENS_10shared_ptrIS2_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf0IS7_T0_EENS5_9list_av_1IT1_E4typeEEEMSA_FS7_vESD_
boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ChatService>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::ChatService> > > > *__fastcall boost::bind<void,RBX::ChatService,boost::shared_ptr<RBX::ChatService>>(
        boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ChatService>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::ChatService> > > > *__return_ptr retstr,
        void (*f)(RBX::ChatService *),
        boost::shared_ptr<RBX::ChatService> a1)
{
  boost::shared_ptr<RBX::ChatService>::element_type *px; // r15
  int (**v4)(void); // r13
  boost::detail::sp_counted_base *v5; // rbx

  px = a1.px;
  v4 = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<RBX::ChatService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<RBX::ChatService>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1583c50 | Name: _ZN5boost4bindIvN3RBX9DataModelENS_10shared_ptrINS1_6CEventEEEPS2_S5_EENS_3_bi6bind_tIT_NS_4_mfi3mf1IS9_T0_T1_EENS7_9list_av_2IT2_T3_E4typeEEEMSC_FS9_SD_ESG_SH_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::DataModel,boost::shared_ptr<RBX::CEvent> >,boost::_bi::list2<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::shared_ptr<RBX::CEvent> > > > *__fastcall boost::bind<void,RBX::DataModel,boost::shared_ptr<RBX::CEvent>,RBX::DataModel*,boost::shared_ptr<RBX::CEvent>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::DataModel,boost::shared_ptr<RBX::CEvent> >,boost::_bi::list2<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::shared_ptr<RBX::CEvent> > > > *__return_ptr retstr,
        void (*f)(RBX::DataModel *, boost::shared_ptr<RBX::CEvent>),
        RBX::DataModel *a1,
        boost::shared_ptr<RBX::CEvent> a2)
{
  RBX::DataModel *px; // r15
  int (**v6)(void); // rbp
  boost::detail::sp_counted_base *v7; // rbx

  px = (RBX::DataModel *)a2.px;
  v6 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = (boost::shared_ptr<RBX::CEvent>::element_type *)v6;
  retstr->l_.a2_.t_.pn.pi_ = v7;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  return retstr;
}


// Address: 0x1584030 | Name: _ZN5boost4bindIvN3RBX9DataModelENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10shared_ptrINS1_6CEventEEEPS2_NS_3argILi1EEESC_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISI_T0_T1_T2_EENSG_9list_av_3IT3_T4_T5_E4typeEEEMSL_FSI_SM_SN_ESQ_SR_SS_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::DataModel,std::string,boost::shared_ptr<RBX::CEvent> >,boost::_bi::list3<boost::_bi::value<RBX::DataModel *>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::CEvent> > > > *__fastcall boost::bind<void,RBX::DataModel,std::string,boost::shared_ptr<RBX::CEvent>,RBX::DataModel*,boost::arg<1>,boost::shared_ptr<RBX::CEvent>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::DataModel,std::string,boost::shared_ptr<RBX::CEvent> >,boost::_bi::list3<boost::_bi::value<RBX::DataModel *>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<RBX::CEvent> > > > *__return_ptr retstr,
        void (*f)(RBX::DataModel *, std::string, boost::shared_ptr<RBX::CEvent>),
        RBX::DataModel *a1,
        RBX::DataModel *a2,
        boost::shared_ptr<RBX::CEvent> a3)
{
  __int64 v5; // rax
  boost::shared_ptr<RBX::CEvent>::element_type *v8; // rbp
  boost::detail::sp_counted_base *align; // rbx

  v8 = *(boost::shared_ptr<RBX::CEvent>::element_type **)&a3.px->manualReset;
  align = (boost::detail::sp_counted_base *)a3.px->cond.internal_mutex.__align;
  if ( align )
  {
    _InterlockedAdd(&align->use_count_, 1u);
    _InterlockedAdd(&align->use_count_, 1u);
    _InterlockedAdd(&align->use_count_, 1u);
    if ( !_InterlockedSub(&align->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::DataModel *, std::string, boost::shared_ptr<RBX::CEvent>), RBX::DataModel *, RBX::DataModel *, boost::shared_ptr<RBX::CEvent>::element_type *, boost::detail::sp_counted_base *, __int64))align->_vptr$sp_counted_base
       + 2))(
        align,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_,
        v5);
      if ( !_InterlockedSub(&align->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))align->_vptr$sp_counted_base + 3))(align);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = a2;
  retstr->l_.a3_.t_.px = v8;
  retstr->l_.a3_.t_.pn.pi_ = align;
  if ( align )
  {
    _InterlockedAdd(&align->use_count_, 1u);
    if ( !_InterlockedSub(&align->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::DataModel *, std::string, boost::shared_ptr<RBX::CEvent>), RBX::DataModel *, RBX::DataModel *, boost::shared_ptr<RBX::CEvent>::element_type *, boost::detail::sp_counted_base *))align->_vptr$sp_counted_base
       + 2))(
        align,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_);
      if ( !_InterlockedSub(&align->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))align->_vptr$sp_counted_base + 3))(align);
    }
    if ( !_InterlockedSub(&align->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::DataModel *, std::string, boost::shared_ptr<RBX::CEvent>), RBX::DataModel *, RBX::DataModel *, boost::shared_ptr<RBX::CEvent>::element_type *, boost::detail::sp_counted_base *))align->_vptr$sp_counted_base
       + 2))(
        align,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_);
      if ( !_InterlockedSub(&align->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))align->_vptr$sp_counted_base + 3))(align);
    }
  }
  return retstr;
}


// Address: 0x158b5b0 | Name: _ZN5boost4bindIvN3RBX9DataModelENS_8functionIFvbEEEPNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEPSt9exceptionPS2_S5_NS_3argILi1EEENSH_ILi2EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf3ISM_T0_T1_T2_T3_EENSK_9list_av_4IT4_T5_T6_T7_E4typeEEEMSP_FSM_SQ_SR_SS_ESV_SW_SX_SY_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::DataModel,boost::function<void (bool)>,std::string *,std::exception *>,boost::_bi::list4<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::function<void (bool)> >,boost::arg<1>,boost::arg<2> > > *__fastcall boost::bind<void,RBX::DataModel,boost::function<void ()(bool)>,std::string *,std::exception *,RBX::DataModel*,boost::function<void ()(bool)>,boost::arg<1>,boost::arg<2>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::DataModel,boost::function<void (bool)>,std::string *,std::exception *>,boost::_bi::list4<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::function<void (bool)> >,boost::arg<1>,boost::arg<2> > > *__return_ptr retstr,
        void (*f)(RBX::DataModel *, boost::function<void (bool)>, std::string *, std::exception *),
        RBX::DataModel *a1,
        boost::_bi::value<RBX::DataModel *> a3,
        __int64 a4)
{
  boost::detail::function::vtable_base *v7; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void (bool)> > v12; // [rsp+0h] [rbp-68h] BYREF
  boost::_bi::list4<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::function<void (bool)> >,boost::arg<1>,boost::arg<2> > v13; // [rsp+20h] [rbp-48h] BYREF

  v12.t_.vtable = 0;
  v7 = *(boost::detail::function::vtable_base **)a4;
  if ( *(_QWORD *)a4 )
  {
    v12.t_.vtable = *(boost::detail::function::vtable_base **)a4;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      v12.t_.functor = *(boost::detail::function::function_buffer *)(a4 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a4 + 8,
        &v12.t_.functor,
        0);
  }
  boost::_bi::list4<boost::_bi::value<RBX::DataModel *>,boost::_bi::value<boost::function<void ()(bool)>>,boost::arg<1>,boost::arg<2>>::list4(
    &v13,
    a3,
    v12,
    (boost::arg<1>)&v12,
    (boost::arg<2>)a3.t_);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v13.a1_.t_;
  retstr->l_.a2_.t_.vtable = 0;
  vtable = v13.a2_.t_.vtable;
  if ( v13.a2_.t_.vtable )
  {
    retstr->l_.a2_.t_.vtable = v13.a2_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a2_.t_.functor = v13.a2_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v13.a2_.t_.functor,
        &retstr->l_.a2_.t_.functor,
        0);
      if ( !v13.a2_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v13.a2_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v13.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v13.a2_.t_.functor, &v13.a2_.t_.functor, 2);
      }
    }
    v13.a2_.t_.vtable = 0;
  }
LABEL_14:
  if ( v12.t_.vtable )
  {
    if ( ((__int64)v12.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v12.t_.functor, &v12.t_.functor, 2);
    }
    v12.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x16407c0 | Name: _ZN5boost4bindIvN3RBX13FriendServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvS9_EEEPS2_NS_3argILi1EEESC_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISI_T0_T1_T2_EENSG_9list_av_3IT3_T4_T5_E4typeEEEMSL_FSI_SM_SN_ESQ_SR_SS_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::FriendService,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::FriendService,std::string,boost::function<void ()(std::string)>,RBX::FriendService*,boost::arg<1>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::FriendService,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::FriendService *, std::string, boost::function<void (std::string)>),
        RBX::FriendService *a1,
        boost::_bi::value<RBX::FriendService *> a2,
        __int64 a5)
{
  boost::detail::function::vtable_base *v7; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void (std::string)> >_0 v12; // [rsp+0h] [rbp-68h] BYREF
  boost::_bi::list3<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > v13; // [rsp+20h] [rbp-48h] BYREF

  v12.t_.vtable = 0;
  v7 = *(boost::detail::function::vtable_base **)a5;
  if ( *(_QWORD *)a5 )
  {
    v12.t_.vtable = *(boost::detail::function::vtable_base **)a5;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      v12.t_.functor = *(boost::detail::function::function_buffer *)(a5 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a5 + 8,
        &v12.t_.functor,
        0);
  }
  boost::_bi::list3<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::list3(
    &v13,
    a2,
    (boost::arg<1>)&v12,
    v12);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v13.a1_.t_;
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v13.a3_.t_.vtable;
  if ( v13.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v13.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v13.a3_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v13.a3_.t_.functor,
        &retstr->l_.a3_.t_.functor,
        0);
      if ( !v13.a3_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v13.a3_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v13.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v13.a3_.t_.functor, &v13.a3_.t_.functor, 2);
      }
    }
    v13.a3_.t_.vtable = 0;
  }
LABEL_14:
  if ( v12.t_.vtable )
  {
    if ( ((__int64)v12.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v12.t_.functor, &v12.t_.functor, 2);
    }
    v12.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x1640a80 | Name: _ZN5boost4bindIvN3RBX13FriendServiceElNS_10shared_ptrIKNSt3__16vectorINS1_10Reflection7VariantENS4_9allocatorIS7_EEEEEENS_8functionIFvbEEEPS2_lNS_3argILi1EEESF_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISL_T0_T1_T2_T3_EENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEEMSO_FSL_SP_SQ_SR_ESU_SV_SW_SX_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::FriendService,long,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >,boost::function<void (bool)> >,boost::_bi::list4<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::arg<1>,boost::_bi::value<boost::function<void (bool)> > > > *__fastcall boost::bind<void,RBX::FriendService,long,boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>,boost::function<void ()(bool)>,RBX::FriendService*,long,boost::arg<1>,boost::function<void ()(bool)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::FriendService,long,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >,boost::function<void (bool)> >,boost::_bi::list4<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::arg<1>,boost::_bi::value<boost::function<void (bool)> > > > *__return_ptr retstr,
        void (*f)(RBX::FriendService *, __int64, boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >, boost::function<void (bool)>),
        RBX::FriendService *a1,
        boost::_bi::value<RBX::FriendService *> a2,
        boost::_bi::value<long> a3,
        __int64 a6)
{
  boost::detail::function::vtable_base *v9; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void (bool)> > v14; // [rsp+0h] [rbp-78h] BYREF
  boost::_bi::list4<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::arg<1>,boost::_bi::value<boost::function<void (bool)> > > v15; // [rsp+20h] [rbp-58h] BYREF

  v14.t_.vtable = 0;
  v9 = *(boost::detail::function::vtable_base **)a6;
  if ( *(_QWORD *)a6 )
  {
    v14.t_.vtable = *(boost::detail::function::vtable_base **)a6;
    if ( ((unsigned __int8)v9 & 1) != 0 )
      v14.t_.functor = *(boost::detail::function::function_buffer *)(a6 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v9
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a6 + 8,
        &v14.t_.functor,
        0);
  }
  boost::_bi::list4<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::arg<1>,boost::_bi::value<boost::function<void ()(bool)>>>::list4(
    &v15,
    a2,
    a3,
    (boost::arg<1>)&v14,
    v14);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.boost::_bi::storage3<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::arg<1> > = v15.boost::_bi::storage3<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::arg<1> >;
  retstr->l_.a4_.t_.vtable = 0;
  vtable = v15.a4_.t_.vtable;
  if ( v15.a4_.t_.vtable )
  {
    retstr->l_.a4_.t_.vtable = v15.a4_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a4_.t_.functor = v15.a4_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v15.a4_.t_.functor,
        &retstr->l_.a4_.t_.functor,
        0);
      if ( !v15.a4_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v15.a4_.t_.vtable & 1) == 0 )
      {
        v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v15.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v11 )
          v11(&v15.a4_.t_.functor, &v15.a4_.t_.functor, 2);
      }
    }
    v15.a4_.t_.vtable = 0;
  }
LABEL_14:
  if ( v14.t_.vtable )
  {
    if ( ((__int64)v14.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v14.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v14.t_.functor, &v14.t_.functor, 2);
    }
    v14.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x1641c60 | Name: _ZN5boost4bindIvN3RBX13FriendServiceElNS_9unordered13unordered_setIlNS_4hashIlEENSt3__18equal_toIlEENS7_9allocatorIlEEEENS7_12basic_stringIcNS7_11char_traitsIcEENSA_IcEEEEPS2_lSC_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf3ISN_T0_T1_T2_T3_EENSL_9list_av_4IT4_T5_T6_T7_E4typeEEEMSQ_FSN_SR_SS_ST_ESW_SX_SY_SZ_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,std::string >,boost::_bi::list4<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,std::string,RBX::FriendService*,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,std::string >,boost::_bi::list4<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::FriendService *, __int64, boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >, std::string),
        RBX::FriendService *a1,
        boost::_bi::value<RBX::FriendService *> a2,
        boost::_bi::value<long> a4,
        const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *a6)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // rbx
  size_t bucket_count; // rbp
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdi
  _QWORD *v13; // rbx
  __int64 v14; // rbp
  _QWORD *v15; // rdi
  _BYTE v17[56]; // [rsp+0h] [rbp-A8h] BYREF
  boost::_bi::list4<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::arg<1> > v18; // [rsp+38h] [rbp-70h] BYREF

  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    (boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *)&v17[8],
    a6);
  boost::_bi::list4<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>>,boost::arg<1>>::list4(
    &v18,
    a2,
    a4,
    *(boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > > *)v17,
    (boost::arg<1>)&v17[8]);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.boost::_bi::storage2<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long> > = v18.boost::_bi::storage2<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long> >;
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    &retstr->l_.a3_.t_.table_,
    &v18.a3_.t_.table_);
  buckets = v18.a3_.t_.table_.buckets_;
  if ( v18.a3_.t_.table_.buckets_ )
  {
    if ( v18.a3_.t_.table_.size_ )
    {
      bucket_count = v18.a3_.t_.table_.bucket_count_;
      next = v18.a3_.t_.table_.buckets_[v18.a3_.t_.table_.bucket_count_].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --v18.a3_.t_.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = v18.a3_.t_.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&v18.a3_.t_.table_.max_load_ = 0;
  }
  v13 = *(_QWORD **)&v17[48];
  if ( *(_QWORD *)&v17[48] )
  {
    if ( *(_QWORD *)&v17[24] )
    {
      v14 = *(_QWORD *)&v17[16];
      v15 = *(_QWORD **)(*(_QWORD *)&v17[48] + 8LL * *(_QWORD *)&v17[16]);
      do
      {
        v13[v14] = *v15;
        operator delete(v15);
        --*(_QWORD *)&v17[24];
        v15 = (_QWORD *)v13[v14];
      }
      while ( v15 );
      v13 = *(_QWORD **)&v17[48];
    }
    operator delete(v13);
    *(_OWORD *)&v17[40] = 0;
  }
  return retstr;
}


// Address: 0x1641f20 | Name: _ZN5boost4bindIvN3RBX13FriendServiceElNS_9unordered13unordered_setIlNS_4hashIlEENSt3__18equal_toIlEENS7_9allocatorIlEEEENS_8functionIFvNS_10shared_ptrINS3_13unordered_mapIlNS1_26FriendService_FriendStatusES6_S9_NSA_INS7_4pairIKlSG_EEEEEEEEEEENSD_IFvNS7_12basic_stringIcNS7_11char_traitsIcEENSA_IcEEEEEEEPS2_lSC_SO_SV_EENS_3_bi6bind_tIT_NS_4_mfi3mf4ISZ_T0_T1_T2_T3_T4_EENSX_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMS12_FSZ_S13_S14_S15_S16_ES19_S1A_S1B_S1C_S1D_
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>,boost::function<void (std::string)> >,boost::_bi::list5<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>,boost::function<void ()(std::string)>,RBX::FriendService*,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::FriendService,long,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>,boost::function<void (std::string)> >,boost::_bi::list5<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::FriendService *, __int64, boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >, boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>, boost::function<void (std::string)>_0),
        RBX::FriendService *a1,
        boost::_bi::value<RBX::FriendService *> a2,
        boost::_bi::value<long> r8_0,
        const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *a6,
        boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > a3)
{
  __int64 v11; // rax
  __int64 v12; // rax
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v14; // rax
  void (__fastcall *v15)(size_t *, size_t *, __int64); // rax
  void (__fastcall *v16)(boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, __int64); // rax
  _QWORD *v17; // rbx
  __int64 v18; // rbp
  _QWORD *v19; // rdi
  boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > > v21; // [rsp+0h] [rbp-128h] BYREF
  boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > v22; // [rsp+30h] [rbp-F8h] BYREF
  _BYTE v23[40]; // [rsp+50h] [rbp-D8h]
  boost::_bi::list5<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > v24; // [rsp+78h] [rbp-B0h] BYREF

  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    (boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *)(&v22.t_.functor.data + 16),
    a6);
  v21.t_.table_.buckets_ = 0;
  v11 = **(_QWORD **)&a3.table_.current_;
  if ( **(_QWORD **)&a3.table_.current_ )
  {
    v21.t_.table_.buckets_ = **(boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer **)&a3.table_.current_;
    if ( (v11 & 1) != 0 )
    {
      *((_QWORD *)&v22.t_.functor.data + 1) = *(_QWORD *)(*(_QWORD *)&a3.table_.current_ + 24LL);
      *(_OWORD *)&v22.t_.vtable = *(_OWORD *)(*(_QWORD *)&a3.table_.current_ + 8LL);
    }
    else
    {
      (*(void (__fastcall **)(__int64, boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(
        *(_QWORD *)&a3.table_.current_ + 8LL,
        &v22,
        0);
    }
  }
  v21.t_.table_.bucket_count_ = 0;
  v12 = *(_QWORD *)a3.table_.bucket_count_;
  if ( *(_QWORD *)a3.table_.bucket_count_ )
  {
    v21.t_.table_.bucket_count_ = *(_QWORD *)a3.table_.bucket_count_;
    if ( (v12 & 1) != 0 )
    {
      v21.t_.table_.max_load_ = *(_QWORD *)(a3.table_.bucket_count_ + 24);
      *(_OWORD *)&v21.t_.table_.size_ = *(_OWORD *)(a3.table_.bucket_count_ + 8);
    }
    else
    {
      (*(void (__fastcall **)(size_t, size_t *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(
        a3.table_.bucket_count_ + 8,
        &v21.t_.table_.size_,
        0);
    }
  }
  boost::_bi::list5<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    &v24,
    a2,
    r8_0,
    v21,
    v22,
    *(boost::_bi::value<boost::function<void (std::string)> >_0 *)v23);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.boost::_bi::storage2<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long> > = v24.boost::_bi::storage2<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long> >;
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    &retstr->l_.a3_.t_.table_,
    &v24.a3_.t_.table_);
  retstr->l_.a4_.t_.vtable = 0;
  vtable = v24.a4_.t_.vtable;
  if ( v24.a4_.t_.vtable )
  {
    retstr->l_.a4_.t_.vtable = v24.a4_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      retstr->l_.a4_.t_.functor = v24.a4_.t_.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v24.a4_.t_.functor,
        &retstr->l_.a4_.t_.functor,
        0);
  }
  retstr->l_.a5_.t_.vtable = 0;
  v14 = v24.a5_.t_.vtable;
  if ( v24.a5_.t_.vtable )
  {
    retstr->l_.a5_.t_.vtable = v24.a5_.t_.vtable;
    if ( ((unsigned __int8)v14 & 1) != 0 )
      retstr->l_.a5_.t_.functor = v24.a5_.t_.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL))(
        &v24.a5_.t_.functor,
        &retstr->l_.a5_.t_.functor,
        0);
  }
  boost::_bi::storage5<boost::_bi::value<RBX::FriendService *>,boost::_bi::value<long>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5(&v24);
  if ( v21.t_.table_.bucket_count_ )
  {
    if ( (v21.t_.table_.bucket_count_ & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(size_t *, size_t *, __int64))(v21.t_.table_.bucket_count_ & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v21.t_.table_.size_, &v21.t_.table_.size_, 2);
    }
    v21.t_.table_.bucket_count_ = 0;
  }
  if ( v21.t_.table_.buckets_ )
  {
    if ( ((__int64)v21.t_.table_.buckets_ & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, __int64))((unsigned __int64)v21.t_.table_.buckets_ & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v22, &v22, 2);
    }
    v21.t_.table_.buckets_ = 0;
  }
  v17 = *(_QWORD **)&v23[32];
  if ( *(_QWORD *)&v23[32] )
  {
    if ( *(_QWORD *)&v23[8] )
    {
      v18 = *(_QWORD *)v23;
      v19 = *(_QWORD **)(*(_QWORD *)&v23[32] + 8LL * *(_QWORD *)v23);
      do
      {
        v17[v18] = *v19;
        operator delete(v19);
        --*(_QWORD *)&v23[8];
        v19 = (_QWORD *)v17[v18];
      }
      while ( v19 );
      v17 = *(_QWORD **)&v23[32];
    }
    operator delete(v17);
    *(_OWORD *)&v23[24] = 0;
  }
  return retstr;
}


// Address: 0x16423e0 | Name: _ZN5boost4bindIvN3RBX13FriendServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_9unordered13unordered_setIlNS_4hashIlEENS3_8equal_toIlEENS7_IlEEEENS_8functionIFvNS_10shared_ptrINSA_13unordered_mapIlNS1_26FriendService_FriendStatusESD_SF_NS7_INS3_4pairIKlSL_EEEEEEEEEEENSI_IFvS9_EEEPS2_NS_3argILi1EEESH_ST_SV_EENS_3_bi6bind_tIT_NS_4_mfi3mf4IS11_T0_T1_T2_T3_T4_EENSZ_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMS14_FS11_S15_S16_S17_S18_ES1B_S1C_S1D_S1E_S1F_
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::FriendService,std::string,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>,boost::function<void (std::string)> >,boost::_bi::list5<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::FriendService,std::string,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>,boost::function<void ()(std::string)>,RBX::FriendService*,boost::arg<1>,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::FriendService,std::string,boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >,boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>,boost::function<void (std::string)> >,boost::_bi::list5<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::FriendService *, std::string, boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> >, boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)>, boost::function<void (std::string)>),
        RBX::FriendService *a1,
        boost::_bi::value<RBX::FriendService *> a2,
        const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *r8_0,
        __int64 a6,
        boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > a3)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v11; // rax
  __int64 v12; // rax
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v14; // rax
  void (__fastcall *v15)(size_t *, size_t *, __int64); // rax
  void (__fastcall *v16)(boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, __int64); // rax
  _QWORD *v17; // r14
  __int64 v18; // rbx
  _QWORD *v19; // rdi
  boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > > v21; // [rsp+0h] [rbp-118h] BYREF
  boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > v22; // [rsp+30h] [rbp-E8h] BYREF
  _BYTE v23[40]; // [rsp+50h] [rbp-C8h]
  boost::_bi::list5<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > >,boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > v24; // [rsp+78h] [rbp-A0h] BYREF

  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    (boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > > *)(&v22.t_.functor.data + 16),
    r8_0);
  v21.t_.table_.buckets_ = 0;
  v11 = *(boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer *)a6;
  if ( *(_QWORD *)a6 )
  {
    v21.t_.table_.buckets_ = *(boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer *)a6;
    if ( ((unsigned __int8)v11 & 1) != 0 )
    {
      *((_QWORD *)&v22.t_.functor.data + 1) = *(_QWORD *)(a6 + 24);
      *(_OWORD *)&v22.t_.vtable = *(_OWORD *)(a6 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, _QWORD))((unsigned __int64)v11 & 0xFFFFFFFFFFFFFFFELL))(
        a6 + 8,
        &v22,
        0);
    }
  }
  v21.t_.table_.bucket_count_ = 0;
  v12 = **(_QWORD **)&a3.table_.current_;
  if ( **(_QWORD **)&a3.table_.current_ )
  {
    v21.t_.table_.bucket_count_ = **(_QWORD **)&a3.table_.current_;
    if ( (v12 & 1) != 0 )
    {
      v21.t_.table_.max_load_ = *(_QWORD *)(*(_QWORD *)&a3.table_.current_ + 24LL);
      *(_OWORD *)&v21.t_.table_.size_ = *(_OWORD *)(*(_QWORD *)&a3.table_.current_ + 8LL);
    }
    else
    {
      (*(void (__fastcall **)(__int64, size_t *, _QWORD))(v12 & 0xFFFFFFFFFFFFFFFELL))(
        *(_QWORD *)&a3.table_.current_ + 8LL,
        &v21.t_.table_.size_,
        0);
    }
  }
  boost::_bi::list5<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list5(
    &v24,
    a2,
    (boost::arg<1>)(&v22.t_.functor.data + 16),
    v21,
    v22,
    *(boost::_bi::value<boost::function<void (std::string)> >_0 *)v23);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v24.a1_.t_;
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::table_impl(
    &retstr->l_.a3_.t_.table_,
    &v24.a3_.t_.table_);
  retstr->l_.a4_.t_.vtable = 0;
  vtable = v24.a4_.t_.vtable;
  if ( v24.a4_.t_.vtable )
  {
    retstr->l_.a4_.t_.vtable = v24.a4_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
      retstr->l_.a4_.t_.functor = v24.a4_.t_.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v24.a4_.t_.functor,
        &retstr->l_.a4_.t_.functor,
        0);
  }
  retstr->l_.a5_.t_.vtable = 0;
  v14 = v24.a5_.t_.vtable;
  if ( v24.a5_.t_.vtable )
  {
    retstr->l_.a5_.t_.vtable = v24.a5_.t_.vtable;
    if ( ((unsigned __int8)v14 & 1) != 0 )
      retstr->l_.a5_.t_.functor = v24.a5_.t_.functor;
    else
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL))(
        &v24.a5_.t_.functor,
        &retstr->l_.a5_.t_.functor,
        0);
  }
  boost::_bi::storage5<boost::_bi::value<RBX::FriendService *>,boost::arg<1>,boost::_bi::value<boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<long const,RBX::FriendService_FriendStatus>>>>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage5(&v24);
  if ( v21.t_.table_.bucket_count_ )
  {
    if ( (v21.t_.table_.bucket_count_ & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(size_t *, size_t *, __int64))(v21.t_.table_.bucket_count_ & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v21.t_.table_.size_, &v21.t_.table_.size_, 2);
    }
    v21.t_.table_.bucket_count_ = 0;
  }
  if ( v21.t_.table_.buckets_ )
  {
    if ( ((__int64)v21.t_.table_.buckets_ & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, boost::_bi::value<boost::function<void (boost::shared_ptr<boost::unordered::unordered_map<long,RBX::FriendService_FriendStatus,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::FriendService_FriendStatus> > > >)> > *, __int64))((unsigned __int64)v21.t_.table_.buckets_ & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v22, &v22, 2);
    }
    v21.t_.table_.buckets_ = 0;
  }
  v17 = *(_QWORD **)&v23[32];
  if ( *(_QWORD *)&v23[32] )
  {
    if ( *(_QWORD *)&v23[8] )
    {
      v18 = *(_QWORD *)v23;
      v19 = *(_QWORD **)(*(_QWORD *)&v23[32] + 8LL * *(_QWORD *)v23);
      do
      {
        v17[v18] = *v19;
        operator delete(v19);
        --*(_QWORD *)&v23[8];
        v19 = (_QWORD *)v17[v18];
      }
      while ( v19 );
      v17 = *(_QWORD **)&v23[32];
    }
    operator delete(v17);
    *(_OWORD *)&v23[24] = 0;
  }
  return retstr;
}


// Address: 0x16518b0 | Name: _ZN5boost4bindIvN3RBX4GameERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEPS2_S9_EENS_3_bi6bind_tIT_NS_4_mfi3mf1ISF_T0_T1_EENSD_9list_av_2IT2_T3_E4typeEEEMSI_FSF_SJ_ESM_SN_
_QWORD *__fastcall boost::bind<void,RBX::Game,std::string const&,RBX::Game*,std::string>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5)
{
  _BYTE v8[16]; // [rsp+0h] [rbp-78h] BYREF
  void *ptr; // [rsp+10h] [rbp-68h]
  __int64 v10; // [rsp+18h] [rbp-60h]
  _BYTE v11[16]; // [rsp+20h] [rbp-58h] BYREF
  void *v12; // [rsp+30h] [rbp-48h]
  _BYTE v13[16]; // [rsp+38h] [rbp-40h] BYREF
  void *v14; // [rsp+48h] [rbp-30h]

  std::string::basic_string(v13, a5);
  std::string::basic_string(v8, v13);
  v10 = a4;
  std::string::basic_string(v11, v8);
  if ( (v8[0] & 1) != 0 )
    operator delete(ptr);
  *a1 = a2;
  a1[1] = a3;
  a1[2] = v10;
  std::string::basic_string(a1 + 3, v11);
  if ( (v11[0] & 1) != 0 )
    operator delete(v12);
  if ( (v13[0] & 1) != 0 )
    operator delete(v14);
  return a1;
}


// Address: 0x17cb2d0 | Name: _ZN5boost4bindIvN3RBX10GuiServiceENS2_7GuiTypeENS_10shared_ptrIS2_EES3_EENS_3_bi6bind_tIT_NS_4_mfi3mf1IS8_T0_T1_EENS6_9list_av_2IT2_T3_E4typeEEEMSB_FS8_SC_ESF_SG_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,RBX::GuiService::GuiType>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<RBX::GuiService::GuiType> > > *__fastcall boost::bind<void,RBX::GuiService,RBX::GuiService::GuiType,boost::shared_ptr<RBX::GuiService>,RBX::GuiService::GuiType>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,RBX::GuiService::GuiType>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<RBX::GuiService::GuiType> > > *__return_ptr retstr,
        void (*f)(RBX::GuiService *, RBX::GuiService::GuiType),
        boost::shared_ptr<RBX::GuiService> a1,
        RBX::GuiService::GuiType a2)
{
  boost::shared_ptr<RBX::GuiService>::element_type *px; // r12
  int (**v6)(void); // r13
  boost::detail::sp_counted_base *v7; // rbx

  px = a1.px;
  v6 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = v6;
    retstr->l_.a1_.t_.pn.pi_ = v7;
    _InterlockedAdd(&v7->use_count_, 1u);
    retstr->l_.a2_.t_ = a2;
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = v6;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = a2;
  }
  return retstr;
}


// Address: 0x17cb550 | Name: _ZN5boost4bindIvN3RBX10GuiServiceENS_8functionIFvvEEEbNS_10shared_ptrIS2_EES5_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISC_T0_T1_T2_EENSA_9list_av_3IT3_T4_T5_E4typeEEEMSF_FSC_SG_SH_ESK_SL_SM_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,bool>,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::GuiService,boost::function<void ()(void)>,bool,boost::shared_ptr<RBX::GuiService>,boost::function<void ()(void)>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,bool>,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::GuiService *, boost::function<void ()>_0, bool),
        boost::shared_ptr<RBX::GuiService> a1,
        __int64 a3)
{
  boost::shared_ptr<RBX::GuiService>::element_type *px; // r14
  boost::detail::sp_counted_base *v5; // rax
  unsigned __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v10; // rbx
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::_bi::value<boost::function<void ()> >_0 v14; // [rsp+0h] [rbp-88h] BYREF
  __int64 v15; // [rsp+20h] [rbp-68h]
  boost::_bi::value<boost::shared_ptr<RBX::GuiService> > v16; // [rsp+28h] [rbp-60h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> >,boost::arg<1> > v17; // [rsp+38h] [rbp-50h] BYREF

  px = a1.px;
  v16.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v16.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->use_count_, 1u);
  v14.t_.functor.obj_ptr = 0;
  v6 = *(_QWORD *)a3;
  if ( *(_QWORD *)a3 )
  {
    v14.t_.functor.obj_ptr = *(void **)a3;
    if ( (v6 & 1) != 0 )
    {
      v15 = *(_QWORD *)(a3 + 24);
      *(_OWORD *)(&v14.t_.functor.data + 8) = *(_OWORD *)(a3 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v6 & 0xFFFFFFFFFFFFFFFELL))(
        a3 + 8,
        &v14.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::GuiService>>,boost::_bi::value<boost::function<void ()(void)>>,boost::arg<1>>::list3(
    &v17,
    (boost::_bi::value<boost::shared_ptr<RBX::GuiService> >)__PAIR128__(
                                                              (boost::_bi::value<boost::function<void ()> >_0 *)&v14.t_.functor,
                                                              &v16),
    v14,
    (boost::arg<1>)a1.pn.pi_);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a2_.t_.vtable = 0;
  vtable = v17.a2_.t_.vtable;
  if ( v17.a2_.t_.vtable )
  {
    retstr->l_.a2_.t_.vtable = v17.a2_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a2_.t_.functor = v17.a2_.t_.functor;
LABEL_17:
      v17.a2_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v17.a2_.t_.functor,
      &retstr->l_.a2_.t_.functor,
      0);
    if ( v17.a2_.t_.vtable )
    {
      if ( ((__int64)v17.a2_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v17.a2_.t_.functor, &v17.a2_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  if ( v14.t_.functor.obj_ptr )
  {
    if ( (v14.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v14.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v14.t_.functor.bound_memfunc_ptr.gap8, v14.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v14.t_.functor.obj_ptr = 0;
  }
  v12 = v16.t_.pn.pi_;
  if ( v16.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v16.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  return retstr;
}


// Address: 0x17cbba0 | Name: _ZN5boost4bindIvN3RBX10GuiServiceENS_8functionIFvvEEENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEENS_10shared_ptrIS2_EES5_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISJ_T0_T1_T2_EENSH_9list_av_3IT3_T4_T5_E4typeEEEMSM_FSJ_SN_SO_ESR_SS_ST_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,std::string >,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::GuiService,boost::function<void ()(void)>,std::string,boost::shared_ptr<RBX::GuiService>,boost::function<void ()(void)>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::GuiService,boost::function<void ()>,std::string >,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::GuiService *, boost::function<void ()>, std::string),
        boost::shared_ptr<RBX::GuiService> a1,
        __int64 a3)
{
  boost::shared_ptr<RBX::GuiService>::element_type *px; // r14
  boost::detail::sp_counted_base *v5; // rax
  unsigned __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v10; // rbx
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::_bi::value<boost::function<void ()> >_0 v14; // [rsp+0h] [rbp-88h] BYREF
  __int64 v15; // [rsp+20h] [rbp-68h]
  boost::_bi::value<boost::shared_ptr<RBX::GuiService> > v16; // [rsp+28h] [rbp-60h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> >,boost::arg<1> > v17; // [rsp+38h] [rbp-50h] BYREF

  px = a1.px;
  v16.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v16.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->use_count_, 1u);
  v14.t_.functor.obj_ptr = 0;
  v6 = *(_QWORD *)a3;
  if ( *(_QWORD *)a3 )
  {
    v14.t_.functor.obj_ptr = *(void **)a3;
    if ( (v6 & 1) != 0 )
    {
      v15 = *(_QWORD *)(a3 + 24);
      *(_OWORD *)(&v14.t_.functor.data + 8) = *(_OWORD *)(a3 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v6 & 0xFFFFFFFFFFFFFFFELL))(
        a3 + 8,
        &v14.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::GuiService>>,boost::_bi::value<boost::function<void ()(void)>>,boost::arg<1>>::list3(
    &v17,
    (boost::_bi::value<boost::shared_ptr<RBX::GuiService> >)__PAIR128__(
                                                              (boost::_bi::value<boost::function<void ()> >_0 *)&v14.t_.functor,
                                                              &v16),
    v14,
    (boost::arg<1>)a1.pn.pi_);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a2_.t_.vtable = 0;
  vtable = v17.a2_.t_.vtable;
  if ( v17.a2_.t_.vtable )
  {
    retstr->l_.a2_.t_.vtable = v17.a2_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a2_.t_.functor = v17.a2_.t_.functor;
LABEL_17:
      v17.a2_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v17.a2_.t_.functor,
      &retstr->l_.a2_.t_.functor,
      0);
    if ( v17.a2_.t_.vtable )
    {
      if ( ((__int64)v17.a2_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v17.a2_.t_.functor, &v17.a2_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  if ( v14.t_.functor.obj_ptr )
  {
    if ( (v14.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v14.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v14.t_.functor.bound_memfunc_ptr.gap8, v14.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v14.t_.functor.obj_ptr = 0;
  }
  v12 = v16.t_.pn.pi_;
  if ( v16.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v16.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  return retstr;
}


// Address: 0x17cc1f0 | Name: _ZN5boost4bindIvN3RBX10GuiServiceENS_8functionIFvvEEENSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEESC_NS_10shared_ptrIS2_EES5_SC_SC_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISH_T0_T1_T2_T3_EENSF_9list_av_4IT4_T5_T6_T7_E4typeEEEMSK_FSH_SL_SM_SN_ESQ_SR_SS_ST_
_QWORD *__fastcall boost::bind<void,RBX::GuiService,boost::function<void ()(void)>,std::string,std::string,boost::shared_ptr<RBX::GuiService>,boost::function<void ()(void)>,std::string,std::string>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 *a4,
        __int64 *a5,
        __int64 a6,
        __int64 a7)
{
  volatile signed __int32 *v9; // rax
  __int64 v10; // rax
  void (__fastcall *v11)(_BYTE *, _BYTE *, __int64); // rax
  volatile signed __int32 *v12; // rbx
  void (__fastcall *v13)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v14; // rbx
  __int64 v16; // [rsp+8h] [rbp-E0h] BYREF
  __int128 v17; // [rsp+10h] [rbp-D8h] BYREF
  __int64 v18; // [rsp+20h] [rbp-C8h]
  __int64 v19; // [rsp+28h] [rbp-C0h] BYREF
  volatile signed __int32 *v20; // [rsp+30h] [rbp-B8h]
  _BYTE v21[16]; // [rsp+38h] [rbp-B0h] BYREF
  void *v22; // [rsp+48h] [rbp-A0h]
  _BYTE v23[16]; // [rsp+50h] [rbp-98h] BYREF
  void *v24; // [rsp+60h] [rbp-88h]
  char v25[8]; // [rsp+68h] [rbp-80h] BYREF
  volatile signed __int32 *v26; // [rsp+70h] [rbp-78h]
  __int64 v27; // [rsp+78h] [rbp-70h]
  _BYTE v28[40]; // [rsp+80h] [rbp-68h] BYREF
  void *v29; // [rsp+A8h] [rbp-40h]
  char v30[16]; // [rsp+B0h] [rbp-38h] BYREF
  void *ptr; // [rsp+C0h] [rbp-28h]

  v19 = *a4;
  v9 = (volatile signed __int32 *)a4[1];
  v20 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  v16 = 0;
  v10 = *a5;
  if ( *a5 )
  {
    v16 = *a5;
    if ( (v10 & 1) != 0 )
    {
      v18 = a5[3];
      v17 = *(_OWORD *)(a5 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a5 + 1, &v17, 0);
    }
  }
  std::string::basic_string(v23, a6);
  std::string::basic_string(v21, a7);
  boost::_bi::list4<boost::_bi::value<boost::shared_ptr<RBX::GuiService>>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<std::string>,boost::_bi::value<std::string>>::list4(
    v25,
    &v19,
    &v16,
    v23,
    v21);
  *a1 = a2;
  a1[1] = a3;
  boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::GuiService>>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<std::string>>::storage3(
    (boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<std::string > > *)(a1 + 2),
    (const boost::_bi::storage3<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<std::string > > *)v25);
  std::string::basic_string(a1 + 11, v30);
  if ( (v30[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v28[24] & 1) != 0 )
    operator delete(v29);
  if ( v27 )
  {
    if ( (v27 & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v27 & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v28, v28, 2);
    }
    v27 = 0;
  }
  v12 = v26;
  if ( v26 )
  {
    if ( !_InterlockedSub(v26 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
      if ( !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
    }
  }
  if ( (v21[0] & 1) != 0 )
    operator delete(v22);
  if ( (v23[0] & 1) != 0 )
    operator delete(v24);
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v17, &v17, 2);
    }
    v16 = 0;
  }
  v14 = v20;
  if ( v20 )
  {
    if ( !_InterlockedSub(v20 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
      if ( !_InterlockedSub(v14 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
    }
  }
  return a1;
}


// Address: 0x17cca30 | Name: _ZN5boost4bindIvN3RBX10GuiServiceENS_8functionIFvvEEENS_10shared_ptrIS2_EES5_EENS_3_bi6bind_tIT_NS_4_mfi3mf1ISA_T0_T1_EENS8_9list_av_2IT2_T3_E4typeEEEMSD_FSA_SE_ESH_SI_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,boost::function<void ()> >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> > > > *__fastcall boost::bind<void,RBX::GuiService,boost::function<void ()(void)>,boost::shared_ptr<RBX::GuiService>,boost::function<void ()(void)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,boost::function<void ()> >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> > > > *__return_ptr retstr,
        void (*f)(RBX::GuiService *, boost::function<void ()>_0),
        boost::shared_ptr<RBX::GuiService> a1,
        __int64 a4)
{
  boost::shared_ptr<RBX::GuiService>::element_type *px; // r14
  boost::detail::sp_counted_base *v5; // rax
  unsigned __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v10; // rbx
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::_bi::value<boost::function<void ()> >_0 v14; // [rsp+0h] [rbp-88h] BYREF
  __int64 v15; // [rsp+20h] [rbp-68h]
  boost::_bi::value<boost::shared_ptr<RBX::GuiService> > v16; // [rsp+28h] [rbp-60h] BYREF
  boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::_bi::value<boost::function<void ()> > > v17; // [rsp+38h] [rbp-50h] BYREF

  px = a1.px;
  v16.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v16.t_.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->use_count_, 1u);
  v14.t_.functor.obj_ptr = 0;
  v6 = *(_QWORD *)a4;
  if ( *(_QWORD *)a4 )
  {
    v14.t_.functor.obj_ptr = *(void **)a4;
    if ( (v6 & 1) != 0 )
    {
      v15 = *(_QWORD *)(a4 + 24);
      *(_OWORD *)(&v14.t_.functor.data + 8) = *(_OWORD *)(a4 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v6 & 0xFFFFFFFFFFFFFFFELL))(
        a4 + 8,
        &v14.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService>>,boost::_bi::value<boost::function<void ()(void)>>>::list2(
    &v17,
    (boost::_bi::value<boost::shared_ptr<RBX::GuiService> >)__PAIR128__(
                                                              (boost::_bi::value<boost::function<void ()> >_0 *)&v14.t_.functor,
                                                              &v16),
    v14);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v17.a1_.t_.px;
  pi = v17.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v17.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a2_.t_.vtable = 0;
  vtable = v17.a2_.t_.vtable;
  if ( v17.a2_.t_.vtable )
  {
    retstr->l_.a2_.t_.vtable = v17.a2_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a2_.t_.functor = v17.a2_.t_.functor;
LABEL_17:
      v17.a2_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v17.a2_.t_.functor,
      &retstr->l_.a2_.t_.functor,
      0);
    if ( v17.a2_.t_.vtable )
    {
      if ( ((__int64)v17.a2_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17.a2_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v17.a2_.t_.functor, &v17.a2_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v10 = v17.a1_.t_.pn.pi_;
  if ( v17.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v17.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  if ( v14.t_.functor.obj_ptr )
  {
    if ( (v14.t_.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v14.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v14.t_.functor.bound_memfunc_ptr.gap8, v14.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v14.t_.functor.obj_ptr = 0;
  }
  v12 = v16.t_.pn.pi_;
  if ( v16.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v16.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  return retstr;
}


// Address: 0x17cd080 | Name: _ZN5boost4bindIvN3RBX10GuiServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10shared_ptrIS2_EENS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf1ISG_T0_T1_EENSE_9list_av_2IT2_T3_E4typeEEEMSJ_FSG_SK_ESN_SO_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,std::string >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::GuiService,std::string,boost::shared_ptr<RBX::GuiService>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::GuiService,std::string >,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::GuiService> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::GuiService *, std::string),
        boost::shared_ptr<RBX::GuiService> a1,
        __int64 a2)
{
  boost::shared_ptr<RBX::GuiService>::element_type *px; // r15
  int (**v5)(void); // r13
  boost::detail::sp_counted_base *v6; // rbx

  px = a1.px;
  v5 = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v6 )
  {
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    _InterlockedAdd(&v6->use_count_, 1u);
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::GuiService *, std::string), boost::shared_ptr<RBX::GuiService>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::GuiService *, std::string), boost::shared_ptr<RBX::GuiService>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = v5;
    retstr->l_.a1_.t_.pn.pi_ = v6;
    _InterlockedAdd(&v6->use_count_, 1u);
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::GuiService *, std::string), boost::shared_ptr<RBX::GuiService>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
    if ( !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::GuiService *, std::string), boost::shared_ptr<RBX::GuiService>::element_type *, boost::detail::sp_counted_base *, __int64))v6->_vptr$sp_counted_base
       + 2))(
        v6,
        f,
        a1.px,
        a1.pn.pi_,
        a2);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = v5;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x18a2890 | Name: _ZN5boost4bindIvN3RBX18MarketplaceServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8weak_ptrINS1_9DataModelEEENS_8functionIFvS9_EEEPS2_NS_3argILi1EEESC_SF_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISL_T0_T1_T2_T3_EENSJ_9list_av_4IT4_T5_T6_T7_E4typeEEEMSO_FSL_SP_SQ_SR_ESU_SV_SW_SX_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::MarketplaceService,std::string,boost::weak_ptr<RBX::DataModel>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::MarketplaceService *>,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::MarketplaceService,std::string,boost::weak_ptr<RBX::DataModel>,boost::function<void ()(std::string)>,RBX::MarketplaceService*,boost::arg<1>,boost::weak_ptr<RBX::DataModel>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::MarketplaceService,std::string,boost::weak_ptr<RBX::DataModel>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::MarketplaceService *>,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::MarketplaceService *, std::string, boost::weak_ptr<RBX::DataModel>, boost::function<void (std::string)>),
        RBX::MarketplaceService *a1,
        boost::_bi::value<RBX::MarketplaceService *> a2,
        boost::weak_ptr<RBX::DataModel> a3)
{
  __int64 v8; // rax
  int (**v9)(void); // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v13; // rdi
  void (__fastcall *v14)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __int64 v15; // rdi
  boost::_bi::value<boost::function<void (std::string)> >_0 v17; // [rsp+0h] [rbp-88h] BYREF
  boost::arg<1> a2a[8]; // [rsp+20h] [rbp-68h] BYREF
  __int64 v19; // [rsp+28h] [rbp-60h]
  boost::_bi::list4<boost::_bi::value<RBX::MarketplaceService *>,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (std::string)> > > v20; // [rsp+30h] [rbp-58h] BYREF

  *(_QWORD *)&a2a[0].gap0 = *(_QWORD *)a3.px;
  v8 = *((_QWORD *)a3.px + 1);
  v19 = v8;
  if ( v8 )
    _InterlockedAdd((volatile signed __int32 *)(v8 + 12), 1u);
  v17.t_.vtable = 0;
  v9 = a3.pn.pi_->_vptr$sp_counted_base;
  if ( a3.pn.pi_->_vptr$sp_counted_base )
  {
    v17.t_.vtable = (boost::detail::function::vtable_base *)a3.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v9 & 1) != 0 )
      v17.t_.functor = *(boost::detail::function::function_buffer *)&a3.pn.pi_->use_count_;
    else
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v9 & 0xFFFFFFFFFFFFFFFELL))(
        &a3.pn.pi_->use_count_,
        &v17.t_.functor,
        0);
  }
  boost::_bi::list4<boost::_bi::value<RBX::MarketplaceService *>,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v20,
    a2,
    (boost::arg<1>)a2a,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)__PAIR128__((unsigned __int64)a3.px, &v17),
    v17);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v20.a1_.t_;
  pi = v20.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v20.a3_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->weak_count_, 1u);
  retstr->l_.a4_.t_.vtable = 0;
  vtable = v20.a4_.t_.vtable;
  if ( v20.a4_.t_.vtable )
  {
    retstr->l_.a4_.t_.vtable = v20.a4_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a4_.t_.functor = v20.a4_.t_.functor;
LABEL_17:
      v20.a4_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v20.a4_.t_.functor,
      &retstr->l_.a4_.t_.functor,
      0);
    if ( v20.a4_.t_.vtable )
    {
      if ( ((__int64)v20.a4_.t_.vtable & 1) == 0 )
      {
        v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v20.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v12 )
          v12(&v20.a4_.t_.functor, &v20.a4_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v13 = v20.a3_.t_.pn.pi_;
  if ( v20.a3_.t_.pn.pi_ && !_InterlockedSub(&v20.a3_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
  if ( v17.t_.vtable )
  {
    if ( ((__int64)v17.t_.vtable & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v17.t_.functor, &v17.t_.functor, 2);
    }
    v17.t_.vtable = 0;
  }
  v15 = v19;
  if ( v19 && !_InterlockedSub((volatile signed __int32 *)(v19 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v15 + 24LL))(v15);
  return retstr;
}


// Address: 0x18a2e10 | Name: _ZN5boost4bindIvN3RBX18MarketplaceServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEES9_NS_8weak_ptrINS1_9DataModelEEENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapIS9_NS1_10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SI_EEEEEEEEEEENSD_IFvS9_EEEPS2_S9_NS_3argILi1EEESC_SV_SX_EENS_3_bi6bind_tIT_NS_4_mfi3mf5IS13_T0_T1_T2_T3_T4_T5_EENS11_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMS16_FS13_S17_S18_S19_S1A_S1B_ES1E_S1F_S1G_S1H_S1I_S1J_
_QWORD *__fastcall boost::bind<void,RBX::MarketplaceService,std::string,std::string,boost::weak_ptr<RBX::DataModel>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>,RBX::MarketplaceService*,std::string,boost::arg<1>,boost::weak_ptr<RBX::DataModel>,boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 *a6,
        __int64 *a7,
        __int64 *a8)
{
  __int64 v12; // rax
  __int64 v13; // rax
  __int64 v14; // rax
  void (__fastcall *v15)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v16)(__int128 *, __int128 *, __int64); // rax
  __int64 v17; // rdi
  __int64 v19; // [rsp+0h] [rbp-108h] BYREF
  __int128 v20; // [rsp+8h] [rbp-100h] BYREF
  __int64 v21; // [rsp+18h] [rbp-F0h]
  __int64 v22; // [rsp+20h] [rbp-E8h] BYREF
  __int128 v23; // [rsp+28h] [rbp-E0h] BYREF
  __int64 v24; // [rsp+38h] [rbp-D0h]
  __int64 v25; // [rsp+40h] [rbp-C8h] BYREF
  __int64 v26; // [rsp+48h] [rbp-C0h]
  _BYTE v27[16]; // [rsp+50h] [rbp-B8h] BYREF
  void *ptr; // [rsp+60h] [rbp-A8h]
  _BYTE v29[160]; // [rsp+68h] [rbp-A0h] BYREF

  std::string::basic_string(v27, a5);
  v25 = *a6;
  v12 = a6[1];
  v26 = v12;
  if ( v12 )
    _InterlockedAdd((volatile signed __int32 *)(v12 + 12), 1u);
  v22 = 0;
  v13 = *a7;
  if ( *a7 )
  {
    v22 = *a7;
    if ( (v13 & 1) != 0 )
    {
      v24 = a7[3];
      v23 = *(_OWORD *)(a7 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v13 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v23, 0);
    }
  }
  v19 = 0;
  v14 = *a8;
  if ( *a8 )
  {
    v19 = *a8;
    if ( (v14 & 1) != 0 )
    {
      v21 = a8[3];
      v20 = *(_OWORD *)(a8 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v14 & 0xFFFFFFFFFFFFFFFELL))(a8 + 1, &v20, 0);
    }
  }
  boost::_bi::list6<boost::_bi::value<RBX::MarketplaceService *>,boost::_bi::value<std::string>,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list6(
    v29,
    a4,
    v27,
    &v25,
    &v22,
    &v19);
  *a1 = a2;
  a1[1] = a3;
  boost::_bi::list6<boost::_bi::value<RBX::MarketplaceService *>,boost::_bi::value<std::string>,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list6(
    (boost::_bi::list6<boost::_bi::value<RBX::MarketplaceService *>,boost::_bi::value<std::string >,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 2),
    (const boost::_bi::list6<boost::_bi::value<RBX::MarketplaceService *>,boost::_bi::value<std::string >,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v29);
  boost::_bi::storage6<boost::_bi::value<RBX::MarketplaceService *>,boost::_bi::value<std::string>,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage6((boost::_bi::storage6<boost::_bi::value<RBX::MarketplaceService *>,boost::_bi::value<std::string >,boost::arg<1>,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v29);
  if ( v19 )
  {
    if ( (v19 & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v19 & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v20, &v20, 2);
    }
    v19 = 0;
  }
  if ( v22 )
  {
    if ( (v22 & 1) == 0 )
    {
      v16 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v22 & 0xFFFFFFFFFFFFFFFELL);
      if ( v16 )
        v16(&v23, &v23, 2);
    }
    v22 = 0;
  }
  v17 = v26;
  if ( v26 && !_InterlockedSub((volatile signed __int32 *)(v26 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v17 + 24LL))(v17);
  if ( (v27[0] & 1) != 0 )
    operator delete(ptr);
  return a1;
}


// Address: 0x190c680 | Name: _ZN5boost4bindIvN3RBX19NotificationServiceENS_10shared_ptrIKNS1_11RobloxEventEEEPS2_S6_EENS_3_bi6bind_tIT_NS_4_mfi3mf1ISA_T0_T1_EENS8_9list_av_2IT2_T3_E4typeEEEMSD_FSA_SE_ESH_SI_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::NotificationService,boost::shared_ptr<const RBX::RobloxEvent> >,boost::_bi::list2<boost::_bi::value<RBX::NotificationService *>,boost::_bi::value<boost::shared_ptr<const RBX::RobloxEvent> > > > *__fastcall boost::bind<void,RBX::NotificationService,boost::shared_ptr<RBX::RobloxEvent const>,RBX::NotificationService*,boost::shared_ptr<RBX::RobloxEvent const>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::NotificationService,boost::shared_ptr<const RBX::RobloxEvent> >,boost::_bi::list2<boost::_bi::value<RBX::NotificationService *>,boost::_bi::value<boost::shared_ptr<const RBX::RobloxEvent> > > > *__return_ptr retstr,
        void (*f)(RBX::NotificationService *, boost::shared_ptr<const RBX::RobloxEvent>),
        RBX::NotificationService *a1,
        boost::shared_ptr<const RBX::RobloxEvent> a2)
{
  RBX::NotificationService *px; // r15
  int (**v6)(void); // rbp
  boost::detail::sp_counted_base *v7; // rbx

  px = (RBX::NotificationService *)a2.px;
  v6 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v6;
  retstr->l_.a2_.t_.pn.pi_ = v7;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  return retstr;
}


// Address: 0x190cde0 | Name: _ZN5boost4bindIvN3RBX19NotificationServiceERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS2_15ConnectionStateESB_SB_PS2_S9_SC_S9_PKcEENS_3_bi6bind_tIT_NS_4_mfi3mf4ISI_T0_T1_T2_T3_T4_EENSG_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMSL_FSI_SM_SN_SO_SP_ESS_ST_SU_SV_SW_
__int64 __fastcall boost::bind<void,RBX::NotificationService,std::string const&,RBX::NotificationService::ConnectionState,std::string const&,std::string const&,RBX::NotificationService*,std::string,RBX::NotificationService::ConnectionState,std::string,char const*>(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        int a4,
        __int64 a5,
        int a6,
        __int64 a7,
        void *a8)
{
  int v12; // [rsp+0h] [rbp-A8h] BYREF
  void *v13; // [rsp+8h] [rbp-A0h]
  void *v14; // [rsp+10h] [rbp-98h]
  int v15; // [rsp+18h] [rbp-90h] BYREF
  void *v16; // [rsp+20h] [rbp-88h]
  void *ptr; // [rsp+28h] [rbp-80h]
  __int64 v18; // [rsp+30h] [rbp-78h] BYREF
  _BYTE v19[16]; // [rsp+38h] [rbp-70h] BYREF
  void *v20; // [rsp+48h] [rbp-60h]
  int v21; // [rsp+50h] [rbp-58h]
  _BYTE v22[16]; // [rsp+58h] [rbp-50h] BYREF
  void *v23; // [rsp+68h] [rbp-40h]
  __int64 v24; // [rsp+70h] [rbp-38h]

  std::string::basic_string(&v15, a5);
  std::string::basic_string(&v12, a7);
  boost::_bi::list5<boost::_bi::value<RBX::NotificationService *>,boost::_bi::value<std::string>,boost::_bi::value<RBX::NotificationService::ConnectionState>,boost::_bi::value<std::string>,boost::_bi::value<char const*>>::list5(
    (unsigned int)&v18,
    a4,
    (unsigned int)&v15,
    a6,
    (unsigned int)&v12,
    (_DWORD)a8,
    v12,
    v13,
    (char)v14,
    v15,
    v16);
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a3;
  *(_QWORD *)(a1 + 16) = v18;
  std::string::basic_string(a1 + 24, v19);
  *(_DWORD *)(a1 + 48) = v21;
  std::string::basic_string(a1 + 56, v22);
  *(_QWORD *)(a1 + 80) = v24;
  if ( (v22[0] & 1) != 0 )
  {
    operator delete(v23);
    if ( (v19[0] & 1) == 0 )
    {
LABEL_3:
      if ( (v12 & 1) == 0 )
        goto LABEL_4;
LABEL_9:
      operator delete(v14);
      if ( (v15 & 1) == 0 )
        return a1;
      goto LABEL_5;
    }
  }
  else if ( (v19[0] & 1) == 0 )
  {
    goto LABEL_3;
  }
  operator delete(v20);
  if ( (v12 & 1) != 0 )
    goto LABEL_9;
LABEL_4:
  if ( (v15 & 1) != 0 )
LABEL_5:
    operator delete(ptr);
  return a1;
}


// Address: 0x1963ae0 | Name: _ZN5boost4bindIvN3RBX6PlayerENS_10shared_ptrIS2_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf0IS7_T0_EENS5_9list_av_1IT1_E4typeEEEMSA_FS7_vESD_
boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Player>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Player> > > > *__fastcall boost::bind<void,RBX::Player,boost::shared_ptr<RBX::Player>>(
        boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Player>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Player> > > > *__return_ptr retstr,
        void (*f)(RBX::Player *),
        boost::shared_ptr<RBX::Player> a1)
{
  boost::shared_ptr<RBX::Player>::element_type *px; // r15
  int (**v4)(void); // r13
  boost::detail::sp_counted_base *v5; // rbx

  px = a1.px;
  v4 = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x19f5ea0 | Name: _ZN5boost4bindIvN3RBX11AbuseReportENS_10shared_ptrINS1_6PlayerEEERKNS1_11ChatMessageENS_17reference_wrapperIS2_EES5_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISF_T0_T1_T2_EENSD_9list_av_3IT3_T4_T5_E4typeEEEMSI_FSF_SJ_SK_ESN_SO_SP_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::AbuseReport,boost::shared_ptr<RBX::Player>,const RBX::ChatMessage &>,boost::_bi::list3<boost::reference_wrapper<RBX::AbuseReport>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::AbuseReport,boost::shared_ptr<RBX::Player>,RBX::ChatMessage const&,boost::reference_wrapper<RBX::AbuseReport>,boost::shared_ptr<RBX::Player>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::AbuseReport,boost::shared_ptr<RBX::Player>,const RBX::ChatMessage &>,boost::_bi::list3<boost::reference_wrapper<RBX::AbuseReport>,boost::_bi::value<boost::shared_ptr<RBX::Player> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::AbuseReport *, boost::shared_ptr<RBX::Player>, const RBX::ChatMessage *),
        boost::reference_wrapper<RBX::AbuseReport> a1,
        boost::shared_ptr<RBX::Player> a2,
        __int64 a3)
{
  __int64 v5; // rax
  RBX::AbuseReport *px; // r15
  int (**v8)(void); // rbp
  boost::detail::sp_counted_base *v9; // rbx

  px = (RBX::AbuseReport *)a2.px;
  v8 = a2.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::AbuseReport *, boost::shared_ptr<RBX::Player>, const RBX::ChatMessage *), RBX::AbuseReport *, boost::shared_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1.t_,
        a2.px,
        a2.pn.pi_,
        a3,
        v5);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::AbuseReport *, boost::shared_ptr<RBX::Player>, const RBX::ChatMessage *), RBX::AbuseReport *, boost::shared_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1.t_,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  retstr->f_.f_ = f;
  *((boost::reference_wrapper<RBX::AbuseReport> *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v8;
  retstr->l_.a2_.t_.pn.pi_ = v9;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::AbuseReport *, boost::shared_ptr<RBX::Player>, const RBX::ChatMessage *), RBX::AbuseReport *, boost::shared_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1.t_,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::AbuseReport *, boost::shared_ptr<RBX::Player>, const RBX::ChatMessage *), RBX::AbuseReport *, boost::shared_ptr<RBX::Player>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1.t_,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x19f69b0 | Name: _ZN5boost4bindIvN3RBX7PlayersERKN6RakNet13SystemAddressERKNS_10shared_ptrINS1_7Network13NetworkStreamEEENS7_INS1_8InstanceEEENS7_INS1_11ChatMessageEEERKNS1_16TextFilterResultENS7_IS2_EES4_SA_SE_SG_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf5ISP_T0_T1_T2_T3_T4_T5_EENSN_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMSS_FSP_ST_SU_SV_SW_SX_ES10_S11_S12_S13_S14_S15_
boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::Players,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,const RBX::TextFilterResult &>,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::Players> >,boost::_bi::value<RakNet::SystemAddress>,boost::_bi::value<boost::shared_ptr<RBX::Network::NetworkStream> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<RBX::ChatMessage> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::Players,RakNet::SystemAddress const&,boost::shared_ptr<RBX::Network::NetworkStream> const&,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,RBX::TextFilterResult const&,boost::shared_ptr<RBX::Players>,RakNet::SystemAddress,boost::shared_ptr<RBX::Network::NetworkStream>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::Players,const RakNet::SystemAddress &,const boost::shared_ptr<RBX::Network::NetworkStream> &,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::ChatMessage>,const RBX::TextFilterResult &>,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::Players> >,boost::_bi::value<RakNet::SystemAddress>,boost::_bi::value<boost::shared_ptr<RBX::Network::NetworkStream> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<RBX::ChatMessage> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::Players *, const RakNet::SystemAddress *, const boost::shared_ptr<RBX::Network::NetworkStream> *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<RBX::ChatMessage>, const RBX::TextFilterResult *),
        boost::shared_ptr<RBX::Players> a1,
        boost::shared_ptr<RBX::Network::NetworkStream> a3,
        RakNet::SystemAddress a2,
        boost::shared_ptr<RBX::Instance> a4)
{
  boost::shared_ptr<RBX::Players>::element_type *px; // r14
  boost::detail::sp_counted_base *v7; // rcx
  volatile signed __int32 *v8; // rax
  boost::detail::sp_counted_base *v9; // rcx
  boost::detail::sp_counted_base *v10; // rax
  boost::detail::sp_counted_base *pi; // rax
  __int128 v12; // xmm0
  boost::detail::sp_counted_base *v13; // rax
  boost::detail::sp_counted_base *v14; // rax
  boost::detail::sp_counted_base *v15; // rax
  boost::detail::sp_counted_base *v16; // rbx
  boost::detail::sp_counted_base *v17; // rbx
  volatile signed __int32 *v18; // rbx
  boost::detail::sp_counted_base *v19; // rbx
  boost::_bi::value<boost::shared_ptr<RBX::Instance> > a3a; // [rsp+20h] [rbp-E8h] BYREF
  boost::_bi::value<boost::shared_ptr<RBX::Network::NetworkStream> > v22; // [rsp+30h] [rbp-D8h] BYREF
  __int64 a1a; // [rsp+40h] [rbp-C8h] BYREF
  volatile signed __int32 *v24; // [rsp+48h] [rbp-C0h]
  boost::_bi::value<boost::shared_ptr<RBX::Players> > v25; // [rsp+50h] [rbp-B8h] BYREF
  boost::_bi::value<RakNet::SystemAddress> v26; // [rsp+60h] [rbp-A8h]
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::Players> >,boost::_bi::value<RakNet::SystemAddress>,boost::_bi::value<boost::shared_ptr<RBX::Network::NetworkStream> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<RBX::ChatMessage> >,boost::arg<1> > v27; // [rsp+88h] [rbp-80h] BYREF

  px = a1.px;
  v25.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v25.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  v26.t_ = a2;
  a1a = *(_QWORD *)a3.px;
  v8 = (volatile signed __int32 *)*((_QWORD *)a3.px + 1);
  v24 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v22.t_.px = a3.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a3.pn.pi_->use_count_;
  v22.t_.pn.pi_ = v9;
  if ( v9 )
    _InterlockedAdd(&v9->use_count_, 1u);
  a3a.t_.px = (boost::shared_ptr<RBX::Instance>::element_type *)a4.px->_vptr$EventSource;
  v10 = (boost::detail::sp_counted_base *)a4.px->weak_this_.px;
  a3a.t_.pn.pi_ = v10;
  if ( v10 )
    _InterlockedAdd(&v10->use_count_, 1u);
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::Players>>,boost::_bi::value<RakNet::SystemAddress>,boost::_bi::value<boost::shared_ptr<RBX::Network::NetworkStream>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::shared_ptr<RBX::ChatMessage>>,boost::arg<1>>::list6(
    &v27,
    (boost::_bi::value<boost::shared_ptr<RBX::Players> >)__PAIR128__(&a1a, &v25),
    v26,
    (boost::_bi::value<boost::shared_ptr<RBX::Network::NetworkStream> >)__PAIR128__(&a3a, &v22),
    a3a,
    (boost::_bi::value<boost::shared_ptr<RBX::ChatMessage> >)v22,
    (boost::arg<1>)a3.pn.pi_);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v27.a1_.t_.px;
  pi = v27.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v27.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v12 = *(_OWORD *)&v27.a2_.t_.address.addr6.sin6_family;
  *((_OWORD *)&retstr->l_.a2_.t_.address.addr4 + 1) = *((_OWORD *)&v27.a2_.t_.address.addr4 + 1);
  *(_OWORD *)&retstr->l_.a2_.t_.address.addr6.sin6_family = v12;
  retstr->l_.a3_.t_.px = v27.a3_.t_.px;
  v13 = v27.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v27.a3_.t_.pn.pi_;
  if ( v13 )
    _InterlockedAdd(&v13->use_count_, 1u);
  retstr->l_.a4_.t_.px = v27.a4_.t_.px;
  v14 = v27.a4_.t_.pn.pi_;
  retstr->l_.a4_.t_.pn.pi_ = v27.a4_.t_.pn.pi_;
  if ( v14 )
    _InterlockedAdd(&v14->use_count_, 1u);
  retstr->l_.a5_.t_.px = v27.a5_.t_.px;
  v15 = v27.a5_.t_.pn.pi_;
  retstr->l_.a5_.t_.pn.pi_ = v27.a5_.t_.pn.pi_;
  if ( v15 )
    _InterlockedAdd(&v15->use_count_, 1u);
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::Players>>,boost::_bi::value<RakNet::SystemAddress>,boost::_bi::value<boost::shared_ptr<RBX::Network::NetworkStream>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::shared_ptr<RBX::ChatMessage>>>::~storage5(&v27);
  v16 = a3a.t_.pn.pi_;
  if ( a3a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a3a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
      if ( !_InterlockedSub(&v16->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
    }
  }
  v17 = v22.t_.pn.pi_;
  if ( v22.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v22.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
      if ( !_InterlockedSub(&v17->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
    }
  }
  v18 = v24;
  if ( v24 )
  {
    if ( !_InterlockedSub(v24 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
      if ( !_InterlockedSub(v18 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
    }
  }
  v19 = v25.t_.pn.pi_;
  if ( v25.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v25.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 2))(v19);
      if ( !_InterlockedSub(&v19->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 3))(v19);
    }
  }
  return retstr;
}


// Address: 0x19f7d90 | Name: _ZN5boost4bindIvN3RBX7PlayersENS_8weak_ptrINS1_6PlayerEEElNS1_29FriendService_FriendEventTypeEPS2_S5_NS_3argILi1EEENS8_ILi2EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf3ISD_T0_T1_T2_T3_EENSB_9list_av_4IT4_T5_T6_T7_E4typeEEEMSG_FSD_SH_SI_SJ_ESM_SN_SO_SP_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Players,boost::weak_ptr<RBX::Player>,long,RBX::FriendService_FriendEventType>,boost::_bi::list4<boost::_bi::value<RBX::Players *>,boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::arg<1>,boost::arg<2> > > *__fastcall boost::bind<void,RBX::Players,boost::weak_ptr<RBX::Player>,long,RBX::FriendService_FriendEventType,RBX::Players*,boost::weak_ptr<RBX::Player>,boost::arg<1>,boost::arg<2>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Players,boost::weak_ptr<RBX::Player>,long,RBX::FriendService_FriendEventType>,boost::_bi::list4<boost::_bi::value<RBX::Players *>,boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::arg<1>,boost::arg<2> > > *__return_ptr retstr,
        void (*f)(RBX::Players *, boost::weak_ptr<RBX::Player>, __int64, RBX::FriendService_FriendEventType),
        RBX::Players *a1,
        boost::weak_ptr<RBX::Player> a2,
        boost::arg<1> a3)
{
  __int64 v7; // rax
  int (***v8)(void); // rdx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v10; // rdi
  __int64 v11; // rdi
  int (**v13)(void); // [rsp+0h] [rbp-48h] BYREF
  __int64 v14; // [rsp+8h] [rbp-40h]
  boost::_bi::list4<boost::_bi::value<RBX::Players *>,boost::_bi::value<boost::weak_ptr<RBX::Player> >,boost::arg<1>,boost::arg<2> > v15; // [rsp+10h] [rbp-38h] BYREF

  v13 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(_QWORD *)&a2.pn.pi_->use_count_;
  v14 = v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 12), 1u);
  v8 = &v13;
  boost::_bi::list4<boost::_bi::value<RBX::Players *>,boost::_bi::value<boost::weak_ptr<RBX::Player>>,boost::arg<1>,boost::arg<2>>::list4(
    &v15,
    (boost::_bi::value<RBX::Players *>)a2.px,
    (boost::_bi::value<boost::weak_ptr<RBX::Player> >)__PAIR128__((unsigned __int64)a2.px, (unsigned __int64)v8),
    (boost::arg<1>)a2.pn.pi_,
    (boost::arg<2>)a3.gap0);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v15.a1_.t_;
  pi = v15.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v15.a2_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->weak_count_, 1u);
    v10 = v15.a2_.t_.pn.pi_;
    if ( v15.a2_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v15.a2_.t_.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  v11 = v14;
  if ( v14 && !_InterlockedSub((volatile signed __int32 *)(v14 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11);
  return retstr;
}


// Address: 0x1a7e4c0 | Name: _ZN5boost4bindIvN3RBX13LatchedSignalIN3rbx13remote_signalEFvNS_10shared_ptrINS1_8InstanceEEENS5_IKNS1_10Reflection5TupleEEEEEES7_SB_PSD_S7_SB_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISH_T0_T1_T2_EENSF_9list_av_3IT3_T4_T5_E4typeEEEMSK_FSH_SL_SM_ESP_SQ_SR_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple> >,boost::_bi::list3<boost::_bi::value<RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)> *>,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<const RBX::Reflection::Tuple> > > > *__fastcall boost::bind<void,RBX::LatchedSignal<rbx::remote_signal,void ()(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Reflection::Tuple const>,RBX::LatchedSignal<rbx::remote_signal,void ()(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Reflection::Tuple const>)>*,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Reflection::Tuple const>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple> >,boost::_bi::list3<boost::_bi::value<RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)> *>,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<const RBX::Reflection::Tuple> > > > *__return_ptr retstr,
        void (*f)(RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)> *, boost::shared_ptr<RBX::Instance>, boost::shared_ptr<const RBX::Reflection::Tuple>),
        RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)> *a1,
        boost::shared_ptr<RBX::Instance> a2,
        __int64 *a5)
{
  boost::detail::sp_counted_base *v7; // rax
  volatile signed __int32 *v8; // rax
  boost::_bi::value<boost::shared_ptr<RBX::Instance> > v9; // rdx
  boost::shared_ptr<RBX::Instance>::element_type *px; // rsi
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v12; // rax
  boost::detail::sp_counted_base *v13; // rbx
  boost::detail::sp_counted_base *v14; // rbx
  volatile signed __int32 *v15; // rbx
  boost::detail::sp_counted_base *v16; // rbx
  __int64 v18; // [rsp+0h] [rbp-68h] BYREF
  volatile signed __int32 *v19; // [rsp+8h] [rbp-60h]
  boost::_bi::value<boost::shared_ptr<RBX::Instance> > a2a; // [rsp+10h] [rbp-58h] BYREF
  boost::_bi::list3<boost::_bi::value<RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)> *>,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::shared_ptr<const RBX::Reflection::Tuple> > > v21; // [rsp+20h] [rbp-48h] BYREF

  a2a.t_.px = (boost::shared_ptr<RBX::Instance>::element_type *)a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  a2a.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  v18 = *a5;
  v8 = (volatile signed __int32 *)a5[1];
  v19 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v9.t_.px = (boost::shared_ptr<RBX::Instance>::element_type *)&a2a;
  px = a2.px;
  v9.t_.pn.pi_ = (boost::detail::sp_counted_base *)&v18;
  boost::_bi::list3<boost::_bi::value<RBX::LatchedSignal<rbx::remote_signal,void ()(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Reflection::Tuple const>)> *>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::shared_ptr<RBX::Reflection::Tuple const>>>::list3(
    &v21,
    (boost::_bi::value<RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<const RBX::Reflection::Tuple>)> *>)px,
    v9,
    (boost::_bi::value<boost::shared_ptr<const RBX::Reflection::Tuple> >)__PAIR128__(
                                                                           (unsigned __int64)a5,
                                                                           (unsigned __int64)a2.pn.pi_));
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v21.a1_.t_;
  pi = v21.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v21.a2_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_.px = v21.a3_.t_.px;
  v12 = v21.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v21.a3_.t_.pn.pi_;
  if ( v12 )
  {
    _InterlockedAdd(&v12->use_count_, 1u);
    v13 = v21.a3_.t_.pn.pi_;
    if ( v21.a3_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v21.a3_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
        if ( !_InterlockedSub(&v13->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
      }
    }
  }
  v14 = v21.a2_.t_.pn.pi_;
  if ( v21.a2_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v21.a2_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
      if ( !_InterlockedSub(&v14->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
    }
  }
  v15 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  v16 = a2a.t_.pn.pi_;
  if ( a2a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a2a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
      if ( !_InterlockedSub(&v16->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
    }
  }
  return retstr;
}


// Address: 0x1a80330 | Name: _ZN5boost4bindIvN3RBX13LatchedSignalIN3rbx13remote_signalEFvNS_10shared_ptrIKNS1_10Reflection5TupleEEEEEES9_PSB_S9_EENS_3_bi6bind_tIT_NS_4_mfi3mf1ISF_T0_T1_EENSD_9list_av_2IT2_T3_E4typeEEEMSI_FSF_SJ_ESM_SN_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<const RBX::Reflection::Tuple> >,boost::_bi::list2<boost::_bi::value<RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)> *>,boost::_bi::value<boost::shared_ptr<const RBX::Reflection::Tuple> > > > *__fastcall boost::bind<void,RBX::LatchedSignal<rbx::remote_signal,void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>,boost::shared_ptr<RBX::Reflection::Tuple const>,RBX::LatchedSignal<rbx::remote_signal,void ()(boost::shared_ptr<RBX::Reflection::Tuple const>)>*,boost::shared_ptr<RBX::Reflection::Tuple const>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)>,boost::shared_ptr<const RBX::Reflection::Tuple> >,boost::_bi::list2<boost::_bi::value<RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)> *>,boost::_bi::value<boost::shared_ptr<const RBX::Reflection::Tuple> > > > *__return_ptr retstr,
        void (*f)(RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)> *, boost::shared_ptr<const RBX::Reflection::Tuple>),
        RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)> *a1,
        boost::shared_ptr<const RBX::Reflection::Tuple> a2)
{
  RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)> *px; // r15
  int (**v6)(void); // rbp
  boost::detail::sp_counted_base *v7; // rbx

  px = (RBX::LatchedSignal<rbx::remote_signal,void (boost::shared_ptr<const RBX::Reflection::Tuple>)> *)a2.px;
  v6 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v6;
  retstr->l_.a2_.t_.pn.pi_ = v7;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  return retstr;
}


// Address: 0x1a83af0 | Name: _ZN5boost4bindIvN3RBX18RequestDataInQueueEPNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEPSt9exceptionNS_8functionIFvSA_SC_EEENS1_16DataStoreService11HttpRequest11RequestTypeENS_10shared_ptrIS2_EENS_3argILi1EEENSL_ILi2EEESF_SI_EENS_3_bi6bind_tIT_NS_4_mfi3mf4ISQ_T0_T1_T2_T3_T4_EENSO_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMST_FSQ_SU_SV_SW_SX_ES10_S11_S12_S13_S14_
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::RequestDataInQueue,std::string *,std::exception *,boost::function<void (std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType>,boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::RequestDataInQueue> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (std::string *,std::exception *)> >,boost::_bi::value<RBX::DataStoreService::HttpRequest::RequestType> > > *__fastcall boost::bind<void,RBX::RequestDataInQueue,std::string *,std::exception *,boost::function<void ()(std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType,boost::shared_ptr<RBX::RequestDataInQueue>,boost::arg<1>,boost::arg<2>,boost::function<void ()(std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::RequestDataInQueue,std::string *,std::exception *,boost::function<void (std::string *,std::exception *)>,RBX::DataStoreService::HttpRequest::RequestType>,boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::RequestDataInQueue> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (std::string *,std::exception *)> >,boost::_bi::value<RBX::DataStoreService::HttpRequest::RequestType> > > *__return_ptr retstr,
        void (*f)(RBX::RequestDataInQueue *, std::string *, std::exception *, boost::function<void (std::string *,std::exception *)>_0, RBX::DataStoreService::HttpRequest::RequestType),
        boost::shared_ptr<RBX::RequestDataInQueue> a1,
        __int64 a2,
        boost::_bi::value<RBX::DataStoreService::HttpRequest::RequestType> a3)
{
  boost::arg<1> v5; // bp
  boost::shared_ptr<RBX::RequestDataInQueue>::element_type *px; // r14
  boost::detail::sp_counted_base *v7; // rax
  boost::detail::function::vtable_base *v8; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  boost::detail::function::vtable_base *v11; // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v13; // rbp
  void (__fastcall *v14)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v15; // rbp
  boost::_bi::value<boost::function<void (std::string *,std::exception *)> > v17; // [rsp+0h] [rbp-88h] BYREF
  boost::_bi::value<boost::shared_ptr<RBX::RequestDataInQueue> > a1a; // [rsp+20h] [rbp-68h] BYREF
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::RequestDataInQueue> >,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void (std::string *,std::exception *)> >,boost::_bi::value<RBX::DataStoreService::HttpRequest::RequestType> > v19; // [rsp+30h] [rbp-58h] BYREF

  v5.gap0 = a3.t_;
  px = a1.px;
  a1a.t_.px = (boost::shared_ptr<RBX::RequestDataInQueue>::element_type *)a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  a1a.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  v17.t_.vtable = 0;
  v8 = *(boost::detail::function::vtable_base **)a2;
  if ( *(_QWORD *)a2 )
  {
    v17.t_.vtable = *(boost::detail::function::vtable_base **)a2;
    if ( ((unsigned __int8)v8 & 1) != 0 )
      v17.t_.functor = *(boost::detail::function::function_buffer *)(a2 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v8
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &v17.t_.functor,
        0);
  }
  boost::_bi::list5<boost::_bi::value<boost::shared_ptr<RBX::RequestDataInQueue>>,boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::function<void ()(std::string *,std::exception *)>>,boost::_bi::value<RBX::DataStoreService::HttpRequest::RequestType>>::list5(
    &v19,
    (boost::_bi::value<boost::shared_ptr<RBX::RequestDataInQueue> >)__PAIR128__(&v17, &a1a),
    v5,
    (boost::arg<2>)a2,
    v17,
    a3);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v19.a1_.t_.px;
  pi = v19.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v19.a1_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a4_.t_.vtable = 0;
  vtable = v19.a4_.t_.vtable;
  if ( v19.a4_.t_.vtable )
  {
    retstr->l_.a4_.t_.vtable = v19.a4_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a4_.t_.functor = v19.a4_.t_.functor;
      retstr->l_.a5_.t_ = v19.a5_.t_;
LABEL_18:
      v19.a4_.t_.vtable = 0;
      goto LABEL_19;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v19.a4_.t_.functor,
      &retstr->l_.a4_.t_.functor,
      0);
    v11 = v19.a4_.t_.vtable;
    retstr->l_.a5_.t_ = v19.a5_.t_;
    if ( v11 )
    {
      if ( ((unsigned __int8)v11 & 1) == 0 )
      {
        v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v11 & 0xFFFFFFFFFFFFFFFELL);
        if ( v12 )
          v12(&v19.a4_.t_.functor, &v19.a4_.t_.functor, 2);
      }
      goto LABEL_18;
    }
  }
  else
  {
    retstr->l_.a5_.t_ = v19.a5_.t_;
  }
LABEL_19:
  v13 = v19.a1_.t_.pn.pi_;
  if ( v19.a1_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v19.a1_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
      if ( !_InterlockedSub(&v13->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
    }
  }
  if ( v17.t_.vtable )
  {
    if ( ((__int64)v17.t_.vtable & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v17.t_.functor, &v17.t_.functor, 2);
    }
    v17.t_.vtable = 0;
  }
  v15 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v15->_vptr$sp_counted_base + 2))(v15);
      if ( !_InterlockedSub(&v15->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v15->_vptr$sp_counted_base + 3))(v15);
    }
  }
  return retstr;
}


// Address: 0x1aa7d50 | Name: _ZN5boost4bindIvN3RBX4SeatENS_10shared_ptrIS2_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf0IS7_T0_EENS5_9list_av_1IT1_E4typeEEEMSA_FS7_vESD_
boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Seat>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Seat> > > > *__fastcall boost::bind<void,RBX::Seat,boost::shared_ptr<RBX::Seat>>(
        boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Seat>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Seat> > > > *__return_ptr retstr,
        void (*f)(RBX::Seat *),
        boost::shared_ptr<RBX::Seat> a1)
{
  boost::shared_ptr<RBX::Seat>::element_type *px; // r15
  int (**v4)(void); // r13
  boost::detail::sp_counted_base *v5; // rbx

  px = a1.px;
  v4 = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<RBX::Seat>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<RBX::Seat>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1b45710 | Name: _ZN5boost4bindIvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS1_11PackageLinkEEENS3_INS1_8InstanceEEEPS2_S5_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISD_T0_T1_T2_EENSB_9list_av_3IT3_T4_T5_E4typeEEEMSG_FSD_SH_SI_ESL_SM_SN_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,RBX::RCCPackageModificationManager*,boost::shared_ptr<RBX::PackageLink>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance> >,boost::_bi::list3<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, boost::shared_ptr<RBX::Instance>),
        RBX::RCCPackageModificationManager *a1,
        boost::shared_ptr<RBX::PackageLink> a2,
        __int64 a3)
{
  __int64 v5; // rax
  RBX::RCCPackageModificationManager *px; // r15
  int (**v8)(void); // rbp
  boost::detail::sp_counted_base *v9; // rbx

  px = (RBX::RCCPackageModificationManager *)a2.px;
  v8 = a2.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, boost::shared_ptr<RBX::Instance>), RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3,
        v5);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, boost::shared_ptr<RBX::Instance>), RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v8;
  retstr->l_.a2_.t_.pn.pi_ = v9;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, boost::shared_ptr<RBX::Instance>), RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, boost::shared_ptr<RBX::Instance>), RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x1b458f0 | Name: _ZN5boost4bindIvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS1_11PackageLinkEEENS3_INS1_8InstanceEEEPKNS1_10Reflection18PropertyDescriptorEPS2_S5_NS_3argILi1EEENSD_ILi2EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf3ISI_T0_T1_T2_T3_EENSG_9list_av_4IT4_T5_T6_T7_E4typeEEEMSL_FSI_SM_SN_SO_ESR_SS_ST_SU_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>,boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1>,boost::arg<2> > > *__fastcall boost::bind<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*,RBX::RCCPackageModificationManager*,boost::shared_ptr<RBX::PackageLink>,boost::arg<1>,boost::arg<2>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>,boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1>,boost::arg<2> > > *__return_ptr retstr,
        void (*f)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, boost::shared_ptr<RBX::Instance>, const RBX::Reflection::PropertyDescriptor *),
        RBX::RCCPackageModificationManager *a1,
        boost::shared_ptr<RBX::PackageLink> a2,
        boost::arg<1> a3)
{
  volatile signed __int32 *v6; // rax
  int (***v7)(void); // rdx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // r14
  volatile signed __int32 *v10; // rbx
  int (**v12)(void); // [rsp+0h] [rbp-48h] BYREF
  volatile signed __int32 *v13; // [rsp+8h] [rbp-40h]
  boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1>,boost::arg<2> > v14; // [rsp+10h] [rbp-38h] BYREF

  v12 = a2.pn.pi_->_vptr$sp_counted_base;
  v6 = *(volatile signed __int32 **)&a2.pn.pi_->use_count_;
  v13 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  v7 = &v12;
  boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink>>,boost::arg<1>,boost::arg<2>>::list4(
    &v14,
    (boost::_bi::value<RBX::RCCPackageModificationManager *>)a2.px,
    (boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >)__PAIR128__((unsigned __int64)a2.px, (unsigned __int64)v7),
    (boost::arg<1>)a2.pn.pi_,
    (boost::arg<2>)a3.gap0);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v14.a1_.t_;
  pi = v14.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v14.a2_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v9 = v14.a2_.t_.pn.pi_;
    if ( v14.a2_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v14.a2_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
        if ( !_InterlockedSub(&v9->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
      }
    }
  }
  v10 = v13;
  if ( v13 )
  {
    if ( !_InterlockedSub(v13 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
      if ( !_InterlockedSub(v10 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
    }
  }
  return retstr;
}


// Address: 0x1b45af0 | Name: _ZN5boost4bindIvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS1_11PackageLinkEEENS3_INS1_8InstanceEEEPKNS1_10Reflection18PropertyDescriptorEPS2_S5_S7_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf3ISH_T0_T1_T2_T3_EENSF_9list_av_4IT4_T5_T6_T7_E4typeEEEMSK_FSH_SL_SM_SN_ESQ_SR_SS_ST_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>,boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*,RBX::RCCPackageModificationManager*,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>,boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, boost::shared_ptr<RBX::Instance>, const RBX::Reflection::PropertyDescriptor *),
        RBX::RCCPackageModificationManager *a1,
        boost::shared_ptr<RBX::PackageLink> a2,
        _QWORD *a4)
{
  boost::detail::sp_counted_base *v7; // rax
  volatile signed __int32 *v8; // rax
  boost::_bi::value<boost::shared_ptr<RBX::PackageLink> > v9; // rdx
  boost::shared_ptr<RBX::PackageLink>::element_type *px; // rsi
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v12; // rax
  boost::detail::sp_counted_base *v13; // rbx
  boost::detail::sp_counted_base *v14; // rbx
  volatile signed __int32 *v15; // rbx
  boost::detail::sp_counted_base *v16; // rbx
  boost::arg<1> a4a[8]; // [rsp+0h] [rbp-68h] BYREF
  volatile signed __int32 *v19; // [rsp+8h] [rbp-60h]
  boost::_bi::value<boost::shared_ptr<RBX::PackageLink> > a2a; // [rsp+10h] [rbp-58h] BYREF
  boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1> > v21; // [rsp+20h] [rbp-48h] BYREF

  a2a.t_.px = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  a2a.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  *(_QWORD *)&a4a[0].gap0 = *a4;
  v8 = (volatile signed __int32 *)a4[1];
  v19 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v9.t_.px = &a2a;
  px = a2.px;
  v9.t_.pn.pi_ = (boost::detail::sp_counted_base *)a4a;
  boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::arg<1>>::list4(
    &v21,
    (boost::_bi::value<RBX::RCCPackageModificationManager *>)px,
    v9,
    (boost::_bi::value<boost::shared_ptr<RBX::Instance> >)__PAIR128__((unsigned __int64)a4, (unsigned __int64)a2.pn.pi_),
    a4a[0]);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v21.a1_.t_;
  pi = v21.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v21.a2_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_.px = v21.a3_.t_.px;
  v12 = v21.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v21.a3_.t_.pn.pi_;
  if ( v12 )
  {
    _InterlockedAdd(&v12->use_count_, 1u);
    v13 = v21.a3_.t_.pn.pi_;
    if ( v21.a3_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v21.a3_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
        if ( !_InterlockedSub(&v13->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
      }
    }
  }
  v14 = v21.a2_.t_.pn.pi_;
  if ( v21.a2_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v21.a2_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
      if ( !_InterlockedSub(&v14->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
    }
  }
  v15 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  v16 = a2a.t_.pn.pi_;
  if ( a2a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a2a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
      if ( !_InterlockedSub(&v16->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
    }
  }
  return retstr;
}


// Address: 0x1b45dc0 | Name: _ZN5boost4bindIvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS1_11PackageLinkEEENS3_INS1_8InstanceEEEPKNS1_10Reflection18PropertyDescriptorEPS2_S5_NS_3argILi1EEEDnEENS_3_bi6bind_tIT_NS_4_mfi3mf3ISH_T0_T1_T2_T3_EENSF_9list_av_4IT4_T5_T6_T7_E4typeEEEMSK_FSH_SL_SM_SN_ESQ_SR_SS_ST_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>,boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1>,boost::_bi::value<nullptr_t> > > *__fastcall boost::bind<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*,RBX::RCCPackageModificationManager*,boost::shared_ptr<RBX::PackageLink>,boost::arg<1>,decltype(nullptr)>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *>,boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1>,boost::_bi::value<nullptr_t> > > *__return_ptr retstr,
        void (*f)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, boost::shared_ptr<RBX::Instance>, const RBX::Reflection::PropertyDescriptor *),
        RBX::RCCPackageModificationManager *a1,
        boost::shared_ptr<RBX::PackageLink> a2,
        boost::_bi::value<nullptr_t> a3)
{
  boost::detail::sp_counted_base *v6; // rax
  boost::_bi::value<boost::shared_ptr<RBX::PackageLink> > *p_a2a; // rdx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v9; // r14
  boost::detail::sp_counted_base *v10; // rbx
  boost::_bi::value<boost::shared_ptr<RBX::PackageLink> > a2a; // [rsp+8h] [rbp-60h] BYREF
  void *t; // [rsp+18h] [rbp-50h]
  boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1>,boost::_bi::value<nullptr_t> > v14; // [rsp+20h] [rbp-48h] BYREF

  a2a.t_.px = a2.pn.pi_->_vptr$sp_counted_base;
  v6 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  a2a.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->use_count_, 1u);
  t = a3.t_;
  p_a2a = &a2a;
  boost::_bi::list4<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink>>,boost::arg<1>,boost::_bi::value<decltype(nullptr)>>::list4(
    &v14,
    (boost::_bi::value<RBX::RCCPackageModificationManager *>)a2.px,
    (boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >)__PAIR128__(
                                                               (unsigned __int64)a2.px,
                                                               (unsigned __int64)p_a2a),
    (boost::arg<1>)a2.pn.pi_,
    a3);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v14.a1_.t_;
  pi = v14.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v14.a2_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v9 = v14.a2_.t_.pn.pi_;
    retstr->l_.a4_.t_ = v14.a4_.t_;
    if ( v9 )
    {
      if ( !_InterlockedSub(&v9->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
        if ( !_InterlockedSub(&v9->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
      }
    }
  }
  else
  {
    retstr->l_.a4_.t_ = v14.a4_.t_;
  }
  v10 = a2a.t_.pn.pi_;
  if ( a2a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a2a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  return retstr;
}


// Address: 0x1b46170 | Name: _ZN5boost4bindIvN3RBX29RCCPackageModificationManagerENS_10shared_ptrINS1_11PackageLinkEEEPKNS1_10Reflection18PropertyDescriptorEPS2_S5_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISF_T0_T1_T2_EENSD_9list_av_3IT3_T4_T5_E4typeEEEMSI_FSF_SJ_SK_ESN_SO_SP_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,const RBX::Reflection::PropertyDescriptor *>,boost::_bi::list3<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,RBX::Reflection::PropertyDescriptor const*,RBX::RCCPackageModificationManager*,boost::shared_ptr<RBX::PackageLink>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::RCCPackageModificationManager,boost::shared_ptr<RBX::PackageLink>,const RBX::Reflection::PropertyDescriptor *>,boost::_bi::list3<boost::_bi::value<RBX::RCCPackageModificationManager *>,boost::_bi::value<boost::shared_ptr<RBX::PackageLink> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, const RBX::Reflection::PropertyDescriptor *),
        RBX::RCCPackageModificationManager *a1,
        boost::shared_ptr<RBX::PackageLink> a2,
        __int64 a3)
{
  __int64 v5; // rax
  RBX::RCCPackageModificationManager *px; // r15
  int (**v8)(void); // rbp
  boost::detail::sp_counted_base *v9; // rbx

  px = (RBX::RCCPackageModificationManager *)a2.px;
  v8 = a2.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, const RBX::Reflection::PropertyDescriptor *), RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>::element_type *, boost::detail::sp_counted_base *, __int64, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3,
        v5);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, const RBX::Reflection::PropertyDescriptor *), RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v8;
  retstr->l_.a2_.t_.pn.pi_ = v9;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, const RBX::Reflection::PropertyDescriptor *), RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>, const RBX::Reflection::PropertyDescriptor *), RBX::RCCPackageModificationManager *, boost::shared_ptr<RBX::PackageLink>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2.px,
        a2.pn.pi_,
        a3);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x1b6d4d0 | Name: _ZN5boost4bindIvN3RBX15TeleportServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_8functionIFvS9_EEEPS2_NS_3argILi1EEESC_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISI_T0_T1_T2_EENSG_9list_av_3IT3_T4_T5_E4typeEEEMSL_FSI_SM_SN_ESQ_SR_SS_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::TeleportService,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<RBX::TeleportService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::TeleportService,std::string,boost::function<void ()(std::string)>,RBX::TeleportService*,boost::arg<1>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::TeleportService,std::string,boost::function<void (std::string)> >,boost::_bi::list3<boost::_bi::value<RBX::TeleportService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::TeleportService *, std::string, boost::function<void (std::string)>),
        RBX::TeleportService *a1,
        boost::_bi::value<RBX::TeleportService *> a2,
        __int64 a5)
{
  boost::detail::function::vtable_base *v7; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::value<boost::function<void (std::string)> > v12; // [rsp+0h] [rbp-68h] BYREF
  boost::_bi::list3<boost::_bi::value<RBX::TeleportService *>,boost::arg<1>,boost::_bi::value<boost::function<void (std::string)> > > v13; // [rsp+20h] [rbp-48h] BYREF

  v12.t_.vtable = 0;
  v7 = *(boost::detail::function::vtable_base **)a5;
  if ( *(_QWORD *)a5 )
  {
    v12.t_.vtable = *(boost::detail::function::vtable_base **)a5;
    if ( ((unsigned __int8)v7 & 1) != 0 )
      v12.t_.functor = *(boost::detail::function::function_buffer *)(a5 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v7
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a5 + 8,
        &v12.t_.functor,
        0);
  }
  boost::_bi::list3<boost::_bi::value<RBX::TeleportService *>,boost::arg<1>,boost::_bi::value<boost::function<void ()(std::string)>>>::list3(
    &v13,
    a2,
    (boost::arg<1>)&v12,
    v12);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = v13.a1_.t_;
  retstr->l_.a3_.t_.vtable = 0;
  vtable = v13.a3_.t_.vtable;
  if ( v13.a3_.t_.vtable )
  {
    retstr->l_.a3_.t_.vtable = v13.a3_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a3_.t_.functor = v13.a3_.t_.functor;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
        &v13.a3_.t_.functor,
        &retstr->l_.a3_.t_.functor,
        0);
      if ( !v13.a3_.t_.vtable )
        goto LABEL_14;
      if ( ((__int64)v13.a3_.t_.vtable & 1) == 0 )
      {
        v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v13.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v9 )
          v9(&v13.a3_.t_.functor, &v13.a3_.t_.functor, 2);
      }
    }
    v13.a3_.t_.vtable = 0;
  }
LABEL_14:
  if ( v12.t_.vtable )
  {
    if ( ((__int64)v12.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v12.t_.functor, &v12.t_.functor, 2);
    }
    v12.t_.vtable = 0;
  }
  return retstr;
}


// Address: 0x1b6d790 | Name: _ZN5boost4bindIvN3RBX15TeleportServiceENS_10shared_ptrIKNSt3__16vectorINS3_INS1_8InstanceEEENS4_9allocatorIS7_EEEEEENS3_INS_9unordered13unordered_mapINS4_12basic_stringIcNS4_11char_traitsIcEENS8_IcEEEENS1_10Reflection7VariantENS_4hashISJ_EENS4_8equal_toISJ_EENS8_INS4_4pairIKSJ_SL_EEEEEEEES7_SJ_PS2_SC_SV_S7_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf4IS11_T0_T1_T2_T3_T4_EENSZ_9list_av_5IT5_T6_T7_T8_T9_E4typeEEEMS14_FS11_S15_S16_S17_S18_ES1B_S1C_S1D_S1E_S1F_
// local variable allocation has failed, the output may be wrong!
boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::TeleportService,boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::shared_ptr<RBX::Instance>,std::string >,boost::_bi::list5<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::TeleportService,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,std::string,RBX::TeleportService*,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf4<void,RBX::TeleportService,boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,boost::shared_ptr<RBX::Instance>,std::string >,boost::_bi::list5<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::TeleportService *, boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >, boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >, boost::shared_ptr<RBX::Instance>, std::string),
        RBX::TeleportService *a1,
        boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > a2,
        __int64 *a5,
        boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > a3)
{
  boost::detail::sp_counted_base *v8; // rax
  volatile signed __int32 *v9; // rdx
  boost::detail::sp_counted_base *bucket_count; // rax
  boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > > v11; // rdx
  boost::_bi::value<boost::shared_ptr<RBX::Instance> > *v12; // r8
  boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *px; // rsi
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v15; // rax
  boost::detail::sp_counted_base *v16; // rax
  boost::detail::sp_counted_base *v17; // rbx
  volatile signed __int32 *v18; // rbx
  boost::detail::sp_counted_base *v19; // rbx
  boost::_bi::value<boost::shared_ptr<RBX::Instance> > v21; // [rsp+0h] [rbp-88h] BYREF
  __int64 a2a; // [rsp+10h] [rbp-78h] BYREF
  volatile signed __int32 *v23; // [rsp+18h] [rbp-70h]
  boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > > v24; // [rsp+20h] [rbp-68h] BYREF
  boost::_bi::list5<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::arg<1> > v25; // [rsp+30h] [rbp-58h] BYREF

  v24.t_.px = a2.pn.pi_->_vptr$sp_counted_base;
  v8 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  v24.t_.pn.pi_ = v8;
  if ( v8 )
    _InterlockedAdd(&v8->use_count_, 1u);
  a2a = *a5;
  v9 = (volatile signed __int32 *)a5[1];
  v23 = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 2, 1u);
  v21.t_.px = *(boost::shared_ptr<RBX::Instance>::element_type **)&a3.px->table_.current_;
  bucket_count = (boost::detail::sp_counted_base *)a3.px->table_.bucket_count_;
  v21.t_.pn.pi_ = bucket_count;
  if ( bucket_count )
    _InterlockedAdd(&bucket_count->use_count_, 1u);
  v11.t_.px = &v24;
  v12 = &v21;
  px = a2.px;
  v11.t_.pn.pi_ = (boost::detail::sp_counted_base *)&a2a;
  boost::_bi::list5<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::arg<1>>::list5(
    &v25,
    (boost::_bi::value<RBX::TeleportService *>)px,
    v11,
    *(boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > > *)(&a5 - 1),
    v21,
    (boost::arg<1>)a2a);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v25.a1_.t_;
  pi = v25.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v25.a2_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_.px = v25.a3_.t_.px;
  v15 = v25.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v25.a3_.t_.pn.pi_;
  if ( v15 )
    _InterlockedAdd(&v15->use_count_, 1u);
  retstr->l_.a4_.t_.px = v25.a4_.t_.px;
  v16 = v25.a4_.t_.pn.pi_;
  retstr->l_.a4_.t_.pn.pi_ = v25.a4_.t_.pn.pi_;
  if ( v16 )
    _InterlockedAdd(&v16->use_count_, 1u);
  boost::_bi::storage4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>>::~storage4(&v25);
  v17 = v21.t_.pn.pi_;
  if ( v21.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v21.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
      if ( !_InterlockedSub(&v17->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
    }
  }
  v18 = v23;
  if ( v23 )
  {
    if ( !_InterlockedSub(v23 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
      if ( !_InterlockedSub(v18 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
    }
  }
  v19 = v24.t_.pn.pi_;
  if ( v24.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v24.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 2))(v19);
      if ( !_InterlockedSub(&v19->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 3))(v19);
    }
  }
  return retstr;
}


// Address: 0x1b6daf0 | Name: _ZN5boost4bindIvN3RBX15TeleportServiceENS_10shared_ptrIKNSt3__16vectorINS3_INS1_8InstanceEEENS4_9allocatorIS7_EEEEEENS3_INS_9unordered13unordered_mapINS4_12basic_stringIcNS4_11char_traitsIcEENS8_IcEEEENS1_10Reflection7VariantENS_4hashISJ_EENS4_8equal_toISJ_EENS8_INS4_4pairIKSJ_SL_EEEEEEEESJ_PS2_SC_SV_NS_3argILi1EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf3IS11_T0_T1_T2_T3_EENSZ_9list_av_4IT4_T5_T6_T7_E4typeEEEMS14_FS11_S15_S16_S17_ES1A_S1B_S1C_S1D_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::TeleportService,boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::string >,boost::_bi::list4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::arg<1> > > *__fastcall boost::bind<void,RBX::TeleportService,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,std::string,RBX::TeleportService*,boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::arg<1>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::TeleportService,boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >,std::string >,boost::_bi::list4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::arg<1> > > *__return_ptr retstr,
        void (*f)(RBX::TeleportService *, boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >, boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >, std::string),
        RBX::TeleportService *a1,
        boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > a2,
        _QWORD *a4)
{
  boost::detail::sp_counted_base *v7; // rax
  volatile signed __int32 *v8; // rax
  boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > > v9; // rdx
  boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *px; // rsi
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v12; // rax
  boost::detail::sp_counted_base *v13; // rbx
  boost::detail::sp_counted_base *v14; // rbx
  volatile signed __int32 *v15; // rbx
  boost::detail::sp_counted_base *v16; // rbx
  boost::arg<1> a4a[8]; // [rsp+0h] [rbp-68h] BYREF
  volatile signed __int32 *v19; // [rsp+8h] [rbp-60h]
  boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > > a2a; // [rsp+10h] [rbp-58h] BYREF
  boost::_bi::list4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<const std::vector<boost::shared_ptr<RBX::Instance>> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::arg<1> > v21; // [rsp+20h] [rbp-48h] BYREF

  a2a.t_.px = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  a2a.t_.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  *(_QWORD *)&a4a[0].gap0 = *a4;
  v8 = (volatile signed __int32 *)a4[1];
  v19 = v8;
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  v9.t_.px = &a2a;
  px = a2.px;
  v9.t_.pn.pi_ = (boost::detail::sp_counted_base *)a4a;
  boost::_bi::list4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::arg<1>>::list4(
    &v21,
    (boost::_bi::value<RBX::TeleportService *>)px,
    v9,
    (boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >)__PAIR128__((unsigned __int64)a4, (unsigned __int64)a2.pn.pi_),
    a4a[0]);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v21.a1_.t_;
  pi = v21.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v21.a2_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_.px = v21.a3_.t_.px;
  v12 = v21.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v21.a3_.t_.pn.pi_;
  if ( v12 )
  {
    _InterlockedAdd(&v12->use_count_, 1u);
    v13 = v21.a3_.t_.pn.pi_;
    if ( v21.a3_.t_.pn.pi_ )
    {
      if ( !_InterlockedSub(&v21.a3_.t_.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
        if ( !_InterlockedSub(&v13->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
      }
    }
  }
  v14 = v21.a2_.t_.pn.pi_;
  if ( v21.a2_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v21.a2_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
      if ( !_InterlockedSub(&v14->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
    }
  }
  v15 = v19;
  if ( v19 )
  {
    if ( !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  v16 = a2a.t_.pn.pi_;
  if ( a2a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a2a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
      if ( !_InterlockedSub(&v16->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
    }
  }
  return retstr;
}


// Address: 0x1b79d60 | Name: _ZN5boost4bindIvN3RBX15TeleportServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10shared_ptrINS3_6vectorIlNS7_IlEEEEEENSA_INS_9unordered13unordered_mapIS9_NS1_10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SI_EEEEEEEENSA_INS1_8InstanceEEENS_8functionIFvS9_EEESX_PS2_S9_SE_SS_SU_SX_SX_EENS_3_bi6bind_tIT_NS_4_mfi3mf6IS11_T0_T1_T2_T3_T4_T5_T6_EENSZ_9list_av_7IT7_T8_T9_T10_T11_T12_T13_E4typeEEEMS14_FS11_S15_S16_S17_S18_S19_S1A_ES1D_S1E_S1F_S1G_S1H_S1I_S1J_
_QWORD *__fastcall boost::bind<void,RBX::TeleportService,std::string,boost::shared_ptr<std::vector<long>>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,RBX::TeleportService*,std::string,boost::shared_ptr<std::vector<long>>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        int a4,
        __int64 a5,
        __int64 *a6,
        __int64 *a7,
        __int64 *a8,
        __int64 *a9,
        __int64 *a10)
{
  volatile signed __int32 *v13; // rax
  volatile signed __int32 *v14; // rcx
  volatile signed __int32 *v15; // rax
  __int64 v16; // rax
  __int64 v17; // rax
  void (__fastcall *v18)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v19)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v20)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v21)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v22; // rbx
  volatile signed __int32 *v23; // rbx
  volatile signed __int32 *v24; // rbx
  __int64 v26; // [rsp+0h] [rbp-148h] BYREF
  __int128 v27; // [rsp+8h] [rbp-140h] BYREF
  __int64 v28; // [rsp+18h] [rbp-130h]
  __int64 v29; // [rsp+20h] [rbp-128h] BYREF
  __int128 v30; // [rsp+28h] [rbp-120h] BYREF
  __int64 v31; // [rsp+38h] [rbp-110h]
  __int64 v32; // [rsp+40h] [rbp-108h] BYREF
  volatile signed __int32 *v33; // [rsp+48h] [rbp-100h]
  __int64 v34; // [rsp+50h] [rbp-F8h] BYREF
  volatile signed __int32 *v35; // [rsp+58h] [rbp-F0h]
  __int64 v36; // [rsp+60h] [rbp-E8h] BYREF
  volatile signed __int32 *v37; // [rsp+68h] [rbp-E0h]
  _BYTE v38[16]; // [rsp+70h] [rbp-D8h] BYREF
  void *ptr; // [rsp+80h] [rbp-C8h]
  _BYTE v40[80]; // [rsp+88h] [rbp-C0h] BYREF
  __int64 v41; // [rsp+D8h] [rbp-70h]
  _BYTE v42[24]; // [rsp+E0h] [rbp-68h] BYREF
  __int64 v43; // [rsp+F8h] [rbp-50h]
  _BYTE v44[72]; // [rsp+100h] [rbp-48h] BYREF

  std::string::basic_string(v38, a5);
  v36 = *a6;
  v13 = (volatile signed __int32 *)a6[1];
  v37 = v13;
  if ( v13 )
    _InterlockedAdd(v13 + 2, 1u);
  v34 = *a7;
  v14 = (volatile signed __int32 *)a7[1];
  v35 = v14;
  if ( v14 )
    _InterlockedAdd(v14 + 2, 1u);
  v32 = *a8;
  v15 = (volatile signed __int32 *)a8[1];
  v33 = v15;
  if ( v15 )
    _InterlockedAdd(v15 + 2, 1u);
  v29 = 0;
  v16 = *a9;
  if ( *a9 )
  {
    v29 = *a9;
    if ( (v16 & 1) != 0 )
    {
      v31 = a9[3];
      v30 = *(_OWORD *)(a9 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v16 & 0xFFFFFFFFFFFFFFFELL))(a9 + 1, &v30, 0);
    }
  }
  v26 = 0;
  v17 = *a10;
  if ( *a10 )
  {
    v26 = *a10;
    if ( (v17 & 1) != 0 )
    {
      v28 = a10[3];
      v27 = *(_OWORD *)(a10 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v17 & 0xFFFFFFFFFFFFFFFELL))(a10 + 1, &v27, 0);
    }
  }
  boost::_bi::list7<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::vector<long>>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list7(
    (unsigned int)v40,
    a4,
    (unsigned int)v38,
    (unsigned int)&v36,
    (unsigned int)&v34,
    (unsigned int)&v32,
    (__int64)&v29,
    (__int64)&v26);
  *a1 = a2;
  a1[1] = a3;
  boost::_bi::storage7<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::vector<long>>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage7(
    (boost::_bi::storage7<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 2),
    (const boost::_bi::storage7<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v40);
  if ( v43 )
  {
    if ( (v43 & 1) == 0 )
    {
      v18 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v43 & 0xFFFFFFFFFFFFFFFELL);
      if ( v18 )
        v18(v44, v44, 2);
    }
    v43 = 0;
  }
  if ( v41 )
  {
    if ( (v41 & 1) == 0 )
    {
      v19 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v41 & 0xFFFFFFFFFFFFFFFELL);
      if ( v19 )
        v19(v42, v42, 2);
    }
    v41 = 0;
  }
  boost::_bi::storage5<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::vector<long>>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>>::~storage5((boost::_bi::storage5<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> > > *)v40);
  if ( v26 )
  {
    if ( (v26 & 1) == 0 )
    {
      v20 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v26 & 0xFFFFFFFFFFFFFFFELL);
      if ( v20 )
        v20(&v27, &v27, 2);
    }
    v26 = 0;
  }
  if ( v29 )
  {
    if ( (v29 & 1) == 0 )
    {
      v21 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v29 & 0xFFFFFFFFFFFFFFFELL);
      if ( v21 )
        v21(&v30, &v30, 2);
    }
    v29 = 0;
  }
  v22 = v33;
  if ( v33 )
  {
    if ( !_InterlockedSub(v33 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 16LL))(v22);
      if ( !_InterlockedSub(v22 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 24LL))(v22);
    }
  }
  v23 = v35;
  if ( v35 )
  {
    if ( !_InterlockedSub(v35 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 16LL))(v23);
      if ( !_InterlockedSub(v23 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 24LL))(v23);
    }
  }
  v24 = v37;
  if ( v37 )
  {
    if ( !_InterlockedSub(v37 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 16LL))(v24);
      if ( !_InterlockedSub(v24 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 24LL))(v24);
    }
  }
  if ( (v38[0] & 1) != 0 )
    operator delete(ptr);
  return a1;
}


// Address: 0x1b7a510 | Name: _ZN5boost4bindIvN3RBX15TeleportServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10shared_ptrINS3_6vectorIlNS7_IlEEEEEENSA_INS1_5TimerILNS1_4Time12SampleMethodE0EEEEENSA_INS_9unordered13unordered_mapIS9_NS1_10Reflection7VariantENS_4hashIS9_EENS3_8equal_toIS9_EENS7_INS3_4pairIKS9_SN_EEEEEEEENSA_INS1_8InstanceEEENS_8functionIFvS9_EEES12_PS2_S9_SE_SJ_SX_SZ_S12_S12_EENS_3_bi6bind_tIT_NS_4_mfi3mf7IS16_T0_T1_T2_T3_T4_T5_T6_T7_EENS14_9list_av_8IT8_T9_T10_T11_T12_T13_T14_T15_E4typeEEEMS19_FS16_S1A_S1B_S1C_S1D_S1E_S1F_S1G_ES1J_S1K_S1L_S1M_S1N_S1O_S1P_S1Q_
_QWORD *__fastcall boost::bind<void,RBX::TeleportService,std::string,boost::shared_ptr<std::vector<long>>,boost::shared_ptr<RBX::Timer<(RBX::Time::SampleMethod)0>>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>,RBX::TeleportService*,std::string,boost::shared_ptr<std::vector<long>>,boost::shared_ptr<RBX::Timer<(RBX::Time::SampleMethod)0>>,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>,boost::shared_ptr<RBX::Instance>,boost::function<void ()(std::string)>,boost::function<void ()(std::string)>>(
        _QWORD *a1,
        __int64 a2,
        __int64 a3,
        int a4,
        __int64 a5,
        __int64 *a6,
        __int64 *a7,
        __int64 *a8,
        __int64 *a9,
        __int64 *a10,
        __int64 *a11)
{
  volatile signed __int32 *v14; // rax
  volatile signed __int32 *v15; // rcx
  volatile signed __int32 *v16; // rax
  volatile signed __int32 *v17; // rax
  __int64 v18; // rax
  __int64 v19; // rax
  void (__fastcall *v20)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v21)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v22)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v23)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v24; // rbx
  volatile signed __int32 *v25; // rbx
  volatile signed __int32 *v26; // rbx
  volatile signed __int32 *v27; // rbx
  __int64 v29; // [rsp+0h] [rbp-168h] BYREF
  __int128 v30; // [rsp+8h] [rbp-160h] BYREF
  __int64 v31; // [rsp+18h] [rbp-150h]
  __int64 v32; // [rsp+20h] [rbp-148h] BYREF
  __int128 v33; // [rsp+28h] [rbp-140h] BYREF
  __int64 v34; // [rsp+38h] [rbp-130h]
  __int64 v35; // [rsp+40h] [rbp-128h] BYREF
  volatile signed __int32 *v36; // [rsp+48h] [rbp-120h]
  __int64 v37; // [rsp+50h] [rbp-118h] BYREF
  volatile signed __int32 *v38; // [rsp+58h] [rbp-110h]
  __int64 v39; // [rsp+60h] [rbp-108h] BYREF
  volatile signed __int32 *v40; // [rsp+68h] [rbp-100h]
  __int64 v41; // [rsp+70h] [rbp-F8h] BYREF
  volatile signed __int32 *v42; // [rsp+78h] [rbp-F0h]
  _BYTE v43[16]; // [rsp+80h] [rbp-E8h] BYREF
  void *ptr; // [rsp+90h] [rbp-D8h]
  _BYTE v45[96]; // [rsp+98h] [rbp-D0h] BYREF
  __int64 v46; // [rsp+F8h] [rbp-70h]
  _BYTE v47[24]; // [rsp+100h] [rbp-68h] BYREF
  __int64 v48; // [rsp+118h] [rbp-50h]
  _BYTE v49[72]; // [rsp+120h] [rbp-48h] BYREF

  std::string::basic_string(v43, a5);
  v41 = *a6;
  v14 = (volatile signed __int32 *)a6[1];
  v42 = v14;
  if ( v14 )
    _InterlockedAdd(v14 + 2, 1u);
  v39 = *a7;
  v15 = (volatile signed __int32 *)a7[1];
  v40 = v15;
  if ( v15 )
    _InterlockedAdd(v15 + 2, 1u);
  v37 = *a8;
  v16 = (volatile signed __int32 *)a8[1];
  v38 = v16;
  if ( v16 )
    _InterlockedAdd(v16 + 2, 1u);
  v35 = *a9;
  v17 = (volatile signed __int32 *)a9[1];
  v36 = v17;
  if ( v17 )
    _InterlockedAdd(v17 + 2, 1u);
  v32 = 0;
  v18 = *a10;
  if ( *a10 )
  {
    v32 = *a10;
    if ( (v18 & 1) != 0 )
    {
      v34 = a10[3];
      v33 = *(_OWORD *)(a10 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v18 & 0xFFFFFFFFFFFFFFFELL))(a10 + 1, &v33, 0);
    }
  }
  v29 = 0;
  v19 = *a11;
  if ( *a11 )
  {
    v29 = *a11;
    if ( (v19 & 1) != 0 )
    {
      v31 = a11[3];
      v30 = *(_OWORD *)(a11 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v19 & 0xFFFFFFFFFFFFFFFELL))(a11 + 1, &v30, 0);
    }
  }
  boost::_bi::list8<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::vector<long>>>,boost::_bi::value<boost::shared_ptr<RBX::Timer<(RBX::Time::SampleMethod)0>>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list8(
    (unsigned int)v45,
    a4,
    (unsigned int)v43,
    (unsigned int)&v41,
    (unsigned int)&v39,
    (unsigned int)&v37,
    (__int64)&v35,
    (__int64)&v32,
    (__int64)&v29);
  *a1 = a2;
  a1[1] = a3;
  boost::_bi::list8<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::vector<long>>>,boost::_bi::value<boost::shared_ptr<RBX::Timer<(RBX::Time::SampleMethod)0>>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>,boost::_bi::value<boost::function<void ()(std::string)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list8(
    (boost::_bi::list8<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::shared_ptr<RBX::Timer<RBX::Time::Fast> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)(a1 + 2),
    (const boost::_bi::list8<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::shared_ptr<RBX::Timer<RBX::Time::Fast> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> >,boost::_bi::value<boost::function<void (std::string)> >,boost::_bi::value<boost::function<void (std::string)> > > *)v45);
  if ( v48 )
  {
    if ( (v48 & 1) == 0 )
    {
      v20 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v48 & 0xFFFFFFFFFFFFFFFELL);
      if ( v20 )
        v20(v49, v49, 2);
    }
    v48 = 0;
  }
  if ( v46 )
  {
    if ( (v46 & 1) == 0 )
    {
      v21 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v46 & 0xFFFFFFFFFFFFFFFELL);
      if ( v21 )
        v21(v47, v47, 2);
    }
    v46 = 0;
  }
  boost::_bi::storage6<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<std::vector<long>>>,boost::_bi::value<boost::shared_ptr<RBX::Timer<(RBX::Time::SampleMethod)0>>>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>,boost::_bi::value<boost::shared_ptr<RBX::Instance>>>::~storage6((boost::_bi::storage6<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::shared_ptr<RBX::Timer<RBX::Time::Fast> > >,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<boost::shared_ptr<RBX::Instance> > > *)v45);
  if ( v29 )
  {
    if ( (v29 & 1) == 0 )
    {
      v22 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v29 & 0xFFFFFFFFFFFFFFFELL);
      if ( v22 )
        v22(&v30, &v30, 2);
    }
    v29 = 0;
  }
  if ( v32 )
  {
    if ( (v32 & 1) == 0 )
    {
      v23 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v32 & 0xFFFFFFFFFFFFFFFELL);
      if ( v23 )
        v23(&v33, &v33, 2);
    }
    v32 = 0;
  }
  v24 = v36;
  if ( v36 )
  {
    if ( !_InterlockedSub(v36 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 16LL))(v24);
      if ( !_InterlockedSub(v24 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 24LL))(v24);
    }
  }
  v25 = v38;
  if ( v38 )
  {
    if ( !_InterlockedSub(v38 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 16LL))(v25);
      if ( !_InterlockedSub(v25 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 24LL))(v25);
    }
  }
  v26 = v40;
  if ( v40 )
  {
    if ( !_InterlockedSub(v40 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 16LL))(v26);
      if ( !_InterlockedSub(v26 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 24LL))(v26);
    }
  }
  v27 = v42;
  if ( v42 )
  {
    if ( !_InterlockedSub(v42 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 16LL))(v27);
      if ( !_InterlockedSub(v27 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 24LL))(v27);
    }
  }
  if ( (v43[0] & 1) != 0 )
    operator delete(ptr);
  return a1;
}


// Address: 0x1b7b2c0 | Name: _ZN5boost4bindIvN3RBX15TeleportServiceENSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENS_10shared_ptrINS3_6vectorIlNS7_IlEEEEEENS_8functionIFvS9_EEEPS2_PKcSE_SH_EENS_3_bi6bind_tIT_NS_4_mfi3mf3ISN_T0_T1_T2_T3_EENSL_9list_av_4IT4_T5_T6_T7_E4typeEEEMSQ_FSN_SR_SS_ST_ESW_SX_SY_SZ_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::TeleportService,std::string,boost::shared_ptr<std::vector<long> >,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::TeleportService,std::string,boost::shared_ptr<std::vector<long>>,boost::function<void ()(std::string)>,RBX::TeleportService*,char const*,boost::shared_ptr<std::vector<long>>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::TeleportService,std::string,boost::shared_ptr<std::vector<long> >,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::TeleportService *, std::string, boost::shared_ptr<std::vector<long> >, boost::function<void (std::string)>),
        RBX::TeleportService *a1,
        const char *a2,
        boost::shared_ptr<std::vector<long> > a3,
        boost::function<void (std::string)> a4)
{
  boost::shared_ptr<std::vector<long> >::element_type *px; // r12
  boost::detail::sp_counted_base *v9; // rax
  void (*manager)(const boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, boost::detail::function::functor_manager_operation_type); // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v14; // rbx
  void (__fastcall *v15)(char *, char *, __int64); // rax
  boost::detail::sp_counted_base *v16; // rbx
  boost::_bi::value<boost::function<void (std::string)> > v18; // [rsp+0h] [rbp-A8h] BYREF
  void (*v19)(const boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, boost::detail::function::functor_manager_operation_type); // [rsp+20h] [rbp-88h]
  boost::_bi::value<boost::shared_ptr<std::vector<long> > > v20; // [rsp+28h] [rbp-80h] BYREF
  boost::_bi::list4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<std::vector<long> > >,boost::_bi::value<boost::function<void (std::string)> > > v21; // [rsp+38h] [rbp-70h] BYREF

  px = a3.px;
  v20.t_.px = a3.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a3.pn.pi_->use_count_;
  v20.t_.pn.pi_ = v9;
  if ( v9 )
    _InterlockedAdd(&v9->use_count_, 1u);
  v18.t_.functor.obj_ptr = 0;
  manager = a4.vtable->manager;
  if ( a4.vtable->manager )
  {
    v18.t_.functor.obj_ptr = a4.vtable->manager;
    if ( ((unsigned __int8)manager & 1) != 0 )
    {
      v19 = a4.vtable[3].manager;
      *(_OWORD *)(&v18.t_.functor.data + 8) = *(_OWORD *)&a4.vtable[1].manager;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::function::vtable_base *, bool *, _QWORD))((unsigned __int64)manager
                                                                                     & 0xFFFFFFFFFFFFFFFELL))(
        a4.vtable + 1,
        &v18.t_.functor.type.const_qualified,
        0);
    }
  }
  boost::_bi::list4<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<std::vector<long>>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list4(
    &v21,
    (boost::_bi::value<RBX::TeleportService *>)a2,
    (boost::_bi::value<const char *>)px,
    (boost::_bi::value<boost::shared_ptr<std::vector<long> > >)__PAIR128__(
                                                                 (boost::_bi::value<boost::function<void (std::string)> > *)&v18.t_.functor,
                                                                 &v20),
    v18);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.boost::_bi::storage2<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<const char *> > = v21.boost::_bi::storage2<boost::_bi::value<RBX::TeleportService *>,boost::_bi::value<const char *> >;
  retstr->l_.a3_.t_.px = v21.a3_.t_.px;
  pi = v21.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v21.a3_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a4_.t_.vtable = 0;
  vtable = v21.a4_.t_.vtable;
  if ( v21.a4_.t_.vtable )
  {
    retstr->l_.a4_.t_.vtable = v21.a4_.t_.vtable;
    if ( ((unsigned __int8)vtable & 1) != 0 )
    {
      retstr->l_.a4_.t_.functor = v21.a4_.t_.functor;
LABEL_17:
      v21.a4_.t_.vtable = 0;
      goto LABEL_18;
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
      &v21.a4_.t_.functor,
      &retstr->l_.a4_.t_.functor,
      0);
    if ( v21.a4_.t_.vtable )
    {
      if ( ((__int64)v21.a4_.t_.vtable & 1) == 0 )
      {
        v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v21.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v13 )
          v13(&v21.a4_.t_.functor, &v21.a4_.t_.functor, 2);
      }
      goto LABEL_17;
    }
  }
LABEL_18:
  v14 = v21.a3_.t_.pn.pi_;
  if ( v21.a3_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v21.a3_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
      if ( !_InterlockedSub(&v14->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
    }
  }
  if ( v18.t_.functor.obj_ptr )
  {
    if ( (v18.t_.functor.data & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v18.t_.functor.obj_ptr
                                                           & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(v18.t_.functor.bound_memfunc_ptr.gap8, v18.t_.functor.bound_memfunc_ptr.gap8, 2);
    }
    v18.t_.functor.obj_ptr = 0;
  }
  v16 = v20.t_.pn.pi_;
  if ( v20.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v20.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
      if ( !_InterlockedSub(&v16->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
    }
  }
  return retstr;
}


// Address: 0x1b8b140 | Name: _ZN5boost4bindIvN3RBX11TestServiceEidNS_10shared_ptrIS2_EEidEENS_3_bi6bind_tIT_NS_4_mfi3mf2IS7_T0_T1_T2_EENS5_9list_av_3IT3_T4_T5_E4typeEEEMSA_FS7_SB_SC_ESF_SG_SH_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::TestService,int,double>,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::TestService> >,boost::_bi::value<int>,boost::_bi::value<double> > > *__fastcall boost::bind<void,RBX::TestService,int,double,boost::shared_ptr<RBX::TestService>,int,double>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::TestService,int,double>,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::TestService> >,boost::_bi::value<int>,boost::_bi::value<double> > > *__return_ptr retstr,
        void (*f)(RBX::TestService *, int, double),
        boost::shared_ptr<RBX::TestService> a1,
        unsigned int a2,
        double a3)
{
  boost::shared_ptr<RBX::TestService>::element_type *px; // r15
  volatile signed __int32 *v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // rbx
  volatile signed __int32 *v9; // rbx
  int (**v11)(void); // [rsp+0h] [rbp-48h] BYREF
  volatile signed __int32 *v12; // [rsp+8h] [rbp-40h]
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::TestService> >,boost::_bi::value<int>,boost::_bi::value<double> > v13; // [rsp+10h] [rbp-38h] BYREF

  px = a1.px;
  v11 = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(volatile signed __int32 **)&a1.pn.pi_->use_count_;
  v12 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::TestService>>,boost::_bi::value<int>,boost::_bi::value<double>>::list3(
    &v13,
    (boost::_bi::value<boost::shared_ptr<RBX::TestService> >)__PAIR128__(a2, &v11),
    (boost::_bi::value<int>)a1.pn.pi_,
    *(boost::_bi::value<double> *)&a3);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v13.a1_.t_.px;
  pi = v13.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v13.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v8 = v13.a1_.t_.pn.pi_;
  }
  else
  {
    v8 = 0;
  }
  retstr->l_.a2_.t_ = v13.a2_.t_;
  retstr->l_.a3_.t_ = v13.a3_.t_;
  if ( v8 )
  {
    if ( !_InterlockedSub(&v8->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
      if ( !_InterlockedSub(&v8->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
    }
  }
  v9 = v12;
  if ( v12 )
  {
    if ( !_InterlockedSub(v12 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  return retstr;
}


// Address: 0x1b8b3d0 | Name: _ZN5boost4bindIvN3RBX11TestServiceEiNS_10shared_ptrIS2_EEiEENS_3_bi6bind_tIT_NS_4_mfi3mf1IS7_T0_T1_EENS5_9list_av_2IT2_T3_E4typeEEEMSA_FS7_SB_ESE_SF_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::TestService,int>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::TestService> >,boost::_bi::value<int> > > *__fastcall boost::bind<void,RBX::TestService,int,boost::shared_ptr<RBX::TestService>,int>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::TestService,int>,boost::_bi::list2<boost::_bi::value<boost::shared_ptr<RBX::TestService> >,boost::_bi::value<int> > > *__return_ptr retstr,
        void (*f)(RBX::TestService *, int),
        boost::shared_ptr<RBX::TestService> a1,
        int a2)
{
  boost::shared_ptr<RBX::TestService>::element_type *px; // r12
  int (**v6)(void); // r13
  boost::detail::sp_counted_base *v7; // rbx

  px = a1.px;
  v6 = a1.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = v6;
    retstr->l_.a1_.t_.pn.pi_ = v7;
    _InterlockedAdd(&v7->use_count_, 1u);
    retstr->l_.a2_.t_ = a2;
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = v6;
    retstr->l_.a1_.t_.pn.pi_ = 0;
    retstr->l_.a2_.t_ = a2;
  }
  return retstr;
}


// Address: 0x1b8b630 | Name: _ZN5boost4bindIvN3RBX11TestServiceEiPKcS4_NS_10shared_ptrINS1_18LuaSourceContainerEEEiNS5_IS2_EEiNS_3argILi1EEENS9_ILi2EEENS9_ILi3EEENS9_ILi4EEEEENS_3_bi6bind_tIT_NS_4_mfi3mf5ISG_T0_T1_T2_T3_T4_T5_EENSE_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMSJ_FSG_SK_SL_SM_SN_SO_ESR_SS_ST_SU_SV_SW_
boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::TestService,int,const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int>,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::TestService> >,boost::_bi::value<int>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > > *__fastcall boost::bind<void,RBX::TestService,int,char const*,char const*,boost::shared_ptr<RBX::LuaSourceContainer>,int,boost::shared_ptr<RBX::TestService>,int,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>(
        boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::TestService,int,const char *,const char *,boost::shared_ptr<RBX::LuaSourceContainer>,int>,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::TestService> >,boost::_bi::value<int>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > > *__return_ptr retstr,
        void (*f)(RBX::TestService *, int, const char *, const char *, boost::shared_ptr<RBX::LuaSourceContainer>, int),
        boost::shared_ptr<RBX::TestService> a1,
        unsigned int a2,
        boost::arg<1> a3)
{
  boost::shared_ptr<RBX::TestService>::element_type *px; // r14
  boost::detail::sp_counted_base *v6; // rax
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // r14
  boost::detail::sp_counted_base *v9; // rbx
  boost::arg<3> v11; // [rsp+0h] [rbp-48h]
  boost::_bi::value<boost::shared_ptr<RBX::TestService> > a1a; // [rsp+8h] [rbp-40h] BYREF
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::TestService> >,boost::_bi::value<int>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4> > v13; // [rsp+18h] [rbp-30h] BYREF

  px = a1.px;
  a1a.t_.px = a1.pn.pi_->_vptr$sp_counted_base;
  v6 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  a1a.t_.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->use_count_, 1u);
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::TestService>>,boost::_bi::value<int>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>>::list6(
    &v13,
    (boost::_bi::value<boost::shared_ptr<RBX::TestService> >)__PAIR128__(a2, &a1a),
    (boost::_bi::value<int>)a1.pn.pi_,
    (boost::arg<1>)a2,
    (boost::arg<2>)a3.gap0,
    v11,
    (boost::arg<4>)a1a.t_.px);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v13.a1_.t_.px;
  pi = v13.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v13.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v8 = v13.a1_.t_.pn.pi_;
    retstr->l_.a2_.t_ = v13.a2_.t_;
    if ( v8 )
    {
      if ( !_InterlockedSub(&v8->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  else
  {
    retstr->l_.a2_.t_ = v13.a2_.t_;
  }
  v9 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x1b9a040 | Name: _ZN5boost4bindIvN3RBX13RenderingTestENS_10shared_ptrIS2_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf0IS7_T0_EENS5_9list_av_1IT1_E4typeEEEMSA_FS7_vESD_
boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::RenderingTest>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::RenderingTest> > > > *__fastcall boost::bind<void,RBX::RenderingTest,boost::shared_ptr<RBX::RenderingTest>>(
        boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::RenderingTest>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::RenderingTest> > > > *__return_ptr retstr,
        void (*f)(RBX::RenderingTest *),
        boost::shared_ptr<RBX::RenderingTest> a1)
{
  boost::shared_ptr<RBX::RenderingTest>::element_type *px; // r15
  int (**v4)(void); // r13
  boost::detail::sp_counted_base *v5; // rbx

  px = a1.px;
  v4 = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1c25fd0 | Name: _ZN5boost4bindIvN3RBX11VehicleSeatENS_10shared_ptrIS2_EEEENS_3_bi6bind_tIT_NS_4_mfi3mf0IS7_T0_EENS5_9list_av_1IT1_E4typeEEEMSA_FS7_vESD_
boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::VehicleSeat>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::VehicleSeat> > > > *__fastcall boost::bind<void,RBX::VehicleSeat,boost::shared_ptr<RBX::VehicleSeat>>(
        boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::VehicleSeat>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::VehicleSeat> > > > *__return_ptr retstr,
        void (*f)(RBX::VehicleSeat *),
        boost::shared_ptr<RBX::VehicleSeat> a1)
{
  boost::shared_ptr<RBX::VehicleSeat>::element_type *px; // r15
  int (**v4)(void); // r13
  boost::detail::sp_counted_base *v5; // rbx

  px = a1.px;
  v4 = a1.pn.pi_->_vptr$sp_counted_base;
  v5 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  if ( v5 )
  {
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<RBX::VehicleSeat>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = v5;
    _InterlockedAdd(&v5->use_count_, 1u);
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.px;
    retstr->l_.a1_.t_.px = (boost::shared_ptr<RBX::VehicleSeat>::element_type *)v4;
    retstr->l_.a1_.t_.pn.pi_ = 0;
  }
  return retstr;
}


// Address: 0x1c4ea00 | Name: _ZN5boost4bindIvN3RBX5MouseERKNS_10shared_ptrINS1_11InputObjectEEEPNS1_11PluginMouseES5_EENS_3_bi6bind_tIT_NS_4_mfi3mf1ISC_T0_T1_EENSA_9list_av_2IT2_T3_E4typeEEEMSF_FSC_SG_ESJ_SK_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Mouse,const boost::shared_ptr<RBX::InputObject> &>,boost::_bi::list2<boost::_bi::value<RBX::PluginMouse *>,boost::_bi::value<boost::shared_ptr<RBX::InputObject> > > > *__fastcall boost::bind<void,RBX::Mouse,boost::shared_ptr<RBX::InputObject> const&,RBX::PluginMouse *,boost::shared_ptr<RBX::InputObject>>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Mouse,const boost::shared_ptr<RBX::InputObject> &>,boost::_bi::list2<boost::_bi::value<RBX::PluginMouse *>,boost::_bi::value<boost::shared_ptr<RBX::InputObject> > > > *__return_ptr retstr,
        void (*f)(RBX::Mouse *, const boost::shared_ptr<RBX::InputObject> *),
        RBX::PluginMouse *a1,
        boost::shared_ptr<RBX::InputObject> a2)
{
  RBX::PluginMouse *px; // r15
  int (**v6)(void); // rbp
  boost::detail::sp_counted_base *v7; // rbx

  px = (RBX::PluginMouse *)a2.px;
  v6 = a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = px;
  retstr->l_.a2_.t_.px = v6;
  retstr->l_.a2_.t_.pn.pi_ = v7;
  if ( v7 )
  {
    _InterlockedAdd(&v7->use_count_, 1u);
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
    if ( !_InterlockedSub(&v7->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
      if ( !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
    }
  }
  return retstr;
}


// Address: 0x1eb5ff0 | Name: _ZN5boost4bindIvN3RBX14NavigationPathEP9dtNavMeshRKN3G3D7Vector3ES8_NS_8functionIFvvEEENS9_IFvNSt3__112basic_stringIcNSC_11char_traitsIcEENSC_9allocatorIcEEEEEEENS_10shared_ptrIS2_EENS_3argILi1EEES6_S6_SB_SK_EENS_3_bi6bind_tIT_NS_4_mfi3mf5ISR_T0_T1_T2_T3_T4_T5_EENSP_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMSU_FSR_SV_SW_SX_SY_SZ_ES12_S13_S14_S15_S16_S17_
// local variable allocation has failed, the output may be wrong!
boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,const G3D::Vector3 &,const G3D::Vector3 &,boost::function<void ()>,boost::function<void (std::string)> >,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> >,boost::arg<1>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::NavigationPath,dtNavMesh *,G3D::Vector3 const&,G3D::Vector3 const&,boost::function<void ()(void)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::NavigationPath>,boost::arg<1>,G3D::Vector3,G3D::Vector3,boost::function<void ()(void)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,const G3D::Vector3 &,const G3D::Vector3 &,boost::function<void ()>,boost::function<void (std::string)> >,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> >,boost::arg<1>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::NavigationPath *, dtNavMesh *, const G3D::Vector3 *, const G3D::Vector3 *, boost::function<void ()>_0, boost::function<void (std::string)>_0),
        boost::shared_ptr<RBX::NavigationPath> a1,
        __int64 *a2,
        boost::_bi::value<G3D::Vector3> a3,
        boost::_bi::value<G3D::Vector3> a4,
        __int64 *a7)
{
  boost::shared_ptr<RBX::NavigationPath>::element_type *px; // r14
  boost::detail::sp_counted_base *v9; // rax
  __int64 v10; // rax
  __int64 v11; // rax
  void (__fastcall *v12)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v13)(_BYTE *, _BYTE *, __int64); // rax
  boost::detail::sp_counted_base *pi; // rbx
  _BYTE v16[72]; // [rsp+0h] [rbp-108h] BYREF
  __int64 v17; // [rsp+48h] [rbp-C0h]
  boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> > v18; // [rsp+50h] [rbp-B8h] BYREF
  __int128 v19; // [rsp+60h] [rbp-A8h]
  __int128 v20; // [rsp+70h] [rbp-98h]
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> >,boost::arg<1>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<boost::function<void ()> >,boost::_bi::value<boost::function<void (std::string)> > > v21; // [rsp+80h] [rbp-88h] BYREF

  px = a1.px;
  v18.t_.px = (boost::shared_ptr<RBX::NavigationPath>::element_type *)a1.pn.pi_->_vptr$sp_counted_base;
  v9 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  v18.t_.pn.pi_ = v9;
  if ( v9 )
    _InterlockedAdd(&v9->use_count_, 1u);
  *(_QWORD *)&v16[48] = 0;
  v10 = *a2;
  if ( *a2 )
  {
    *(_QWORD *)&v16[48] = *a2;
    if ( (v10 & 1) != 0 )
    {
      v17 = a2[3];
      *(_OWORD *)&v16[56] = *(_OWORD *)(a2 + 1);
    }
    else
    {
      *(float *)&v16[12] = a4.t_.z;
      v20 = *(_OWORD *)&a4.t_.x;
      *(float *)&v16[8] = a3.t_.z;
      v19 = *(_OWORD *)&a3.t_.x;
      (*(void (__fastcall **)(__int64 *, _BYTE *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a2 + 1, &v16[56], 0);
      *(_OWORD *)&a3.t_.x = v19;
      *(_OWORD *)&a4.t_.x = v20;
    }
  }
  *(_QWORD *)&v16[16] = 0;
  v11 = *a7;
  if ( *a7 )
  {
    *(_QWORD *)&v16[16] = *a7;
    if ( (v11 & 1) != 0 )
    {
      *(_QWORD *)&v16[40] = a7[3];
      *(_OWORD *)&v16[24] = *(_OWORD *)(a7 + 1);
    }
    else
    {
      *(float *)&v16[12] = a4.t_.z;
      v20 = *(_OWORD *)&a4.t_.x;
      *(float *)&v16[8] = a3.t_.z;
      v19 = *(_OWORD *)&a3.t_.x;
      (*(void (__fastcall **)(__int64 *, _BYTE *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(a7 + 1, &v16[24], 0);
      *(_QWORD *)&a3.t_.x = v19;
      *(_QWORD *)&a4.t_.x = v20;
    }
  }
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath>>,boost::arg<1>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list6(
    &v21,
    (boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> >)__PAIR128__(&v16[48], &v18),
    (boost::arg<1>)&v16[16],
    a3,
    a4,
    *(boost::_bi::value<boost::function<void ()> >_0 *)v16,
    *(boost::_bi::value<boost::function<void (std::string)> >_0 *)&v16[32]);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath>>,boost::arg<1>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage6(
    &retstr->l_,
    &v21);
  boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath>>,boost::arg<1>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<G3D::Vector3>,boost::_bi::value<boost::function<void ()(void)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage6(&v21);
  if ( *(_QWORD *)&v16[16] )
  {
    if ( (v16[16] & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v16[16] & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v16[24], &v16[24], 2);
    }
    *(_QWORD *)&v16[16] = 0;
  }
  if ( *(_QWORD *)&v16[48] )
  {
    if ( (v16[48] & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v16[48] & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v16[56], &v16[56], 2);
    }
    *(_QWORD *)&v16[48] = 0;
  }
  pi = v18.t_.pn.pi_;
  if ( v18.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v18.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x1eb6880 | Name: _ZN5boost4bindIvN3RBX14NavigationPathEP9dtNavMeshiRKNS_10shared_ptrIKNS1_8PathDataEEENS_8functionIFviEEENSB_IFvNSt3__112basic_stringIcNSE_11char_traitsIcEENSE_9allocatorIcEEEEEEENS5_IS2_EENS_3argILi1EEEiS8_SD_SM_EENS_3_bi6bind_tIT_NS_4_mfi3mf5ISS_T0_T1_T2_T3_T4_T5_EENSQ_9list_av_6IT6_T7_T8_T9_T10_T11_E4typeEEEMSV_FSS_SW_SX_SY_SZ_S10_ES13_S14_S15_S16_S17_S18_
boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,int,const boost::shared_ptr<const RBX::PathData> &,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> >,boost::arg<1>,boost::_bi::value<int>,boost::_bi::value<boost::shared_ptr<const RBX::PathData> >,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__fastcall boost::bind<void,RBX::NavigationPath,dtNavMesh *,int,boost::shared_ptr<RBX::PathData const> const&,boost::function<void ()(int)>,boost::function<void ()(std::string)>,boost::shared_ptr<RBX::NavigationPath>,boost::arg<1>,int,boost::shared_ptr<RBX::PathData const>,boost::function<void ()(int)>,boost::function<void ()(std::string)>>(
        boost::_bi::bind_t<void,boost::_mfi::mf5<void,RBX::NavigationPath,dtNavMesh *,int,const boost::shared_ptr<const RBX::PathData> &,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> >,boost::arg<1>,boost::_bi::value<int>,boost::_bi::value<boost::shared_ptr<const RBX::PathData> >,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > > *__return_ptr retstr,
        void (*f)(RBX::NavigationPath *, dtNavMesh *, int, const boost::shared_ptr<const RBX::PathData> *, boost::function<void (int)>_0, boost::function<void (std::string)>_0),
        boost::shared_ptr<RBX::NavigationPath> a1,
        unsigned int a2,
        _QWORD *a3,
        boost::shared_ptr<const RBX::PathData> a4)
{
  boost::shared_ptr<RBX::NavigationPath>::element_type *px; // r14
  boost::detail::sp_counted_base *v8; // rax
  __int64 v9; // rax
  __int64 v10; // rax
  int (**v11)(void); // rax
  void (__fastcall *v12)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v13)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v14)(_BYTE *, _BYTE *, __int64); // rax
  volatile signed __int32 *v15; // rbp
  boost::detail::sp_counted_base *pi; // rbp
  _BYTE v18[80]; // [rsp+0h] [rbp-E8h] BYREF
  boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> > a1a; // [rsp+50h] [rbp-98h] BYREF
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> >,boost::arg<1>,boost::_bi::value<int>,boost::_bi::value<boost::shared_ptr<const RBX::PathData> >,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > v20; // [rsp+60h] [rbp-88h] BYREF

  px = a1.px;
  a1a.t_.px = (boost::shared_ptr<RBX::NavigationPath>::element_type *)a1.pn.pi_->_vptr$sp_counted_base;
  v8 = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  a1a.t_.pn.pi_ = v8;
  if ( v8 )
    _InterlockedAdd(&v8->use_count_, 1u);
  *(_QWORD *)&v18[64] = *a3;
  v9 = a3[1];
  *(_QWORD *)&v18[72] = v9;
  if ( v9 )
    _InterlockedAdd((volatile signed __int32 *)(v9 + 8), 1u);
  *(_QWORD *)&v18[32] = 0;
  v10 = *(_QWORD *)a4.px;
  if ( *(_QWORD *)a4.px )
  {
    *(_QWORD *)&v18[32] = *(_QWORD *)a4.px;
    if ( (v10 & 1) != 0 )
    {
      *(_QWORD *)&v18[56] = *((_QWORD *)a4.px + 3);
      *(_OWORD *)&v18[40] = *(_OWORD *)((char *)a4.px + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, _BYTE *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))((char *)a4.px + 8, &v18[40], 0);
    }
  }
  *(_QWORD *)v18 = 0;
  v11 = a4.pn.pi_->_vptr$sp_counted_base;
  if ( a4.pn.pi_->_vptr$sp_counted_base )
  {
    *(_QWORD *)v18 = a4.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v11 & 1) != 0 )
    {
      *(_QWORD *)&v18[24] = *(_QWORD *)&a4.pn.pi_[1].use_count_;
      *(_OWORD *)&v18[8] = *(_OWORD *)&a4.pn.pi_->use_count_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, _BYTE *, _QWORD))((unsigned __int64)v11
                                                                                     & 0xFFFFFFFFFFFFFFFELL))(
        &a4.pn.pi_->use_count_,
        &v18[8],
        0);
    }
  }
  boost::_bi::list6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath>>,boost::arg<1>,boost::_bi::value<int>,boost::_bi::value<boost::shared_ptr<RBX::PathData const>>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::list6(
    &v20,
    (boost::_bi::value<boost::shared_ptr<RBX::NavigationPath> >)__PAIR128__(a2, &a1a),
    (boost::arg<1>)&v18[64],
    (boost::_bi::value<int>)&v18[32],
    *(boost::_bi::value<boost::shared_ptr<const RBX::PathData> > *)v18,
    *(boost::_bi::value<boost::function<void (int)> >_0 *)&v18[16],
    *(boost::_bi::value<boost::function<void (std::string)> >_0 *)&v18[48]);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  boost::_bi::storage6<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath>>,boost::arg<1>,boost::_bi::value<int>,boost::_bi::value<boost::shared_ptr<RBX::PathData const>>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::storage6(
    &retstr->l_,
    &v20);
  if ( v20.a6_.t_.vtable )
  {
    if ( ((__int64)v20.a6_.t_.vtable & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v20.a6_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(&v20.a6_.t_.functor, &v20.a6_.t_.functor, 2);
    }
    v20.a6_.t_.vtable = 0;
  }
  boost::_bi::storage5<boost::_bi::value<boost::shared_ptr<RBX::NavigationPath>>,boost::arg<1>,boost::_bi::value<int>,boost::_bi::value<boost::shared_ptr<RBX::PathData const>>,boost::_bi::value<boost::function<void ()(int)>>>::~storage5(&v20);
  if ( *(_QWORD *)v18 )
  {
    if ( (v18[0] & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)v18 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(&v18[8], &v18[8], 2);
    }
    *(_QWORD *)v18 = 0;
  }
  if ( *(_QWORD *)&v18[32] )
  {
    if ( (v18[32] & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v18[32] & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v18[40], &v18[40], 2);
    }
    *(_QWORD *)&v18[32] = 0;
  }
  v15 = *(volatile signed __int32 **)&v18[72];
  if ( *(_QWORD *)&v18[72] )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v18[72] + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  pi = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return retstr;
}


// Address: 0x1eb6ed0 | Name: _ZN5boost4bindIvN3RBX14NavigationPathEP9dtNavMeshRKNS_10shared_ptrIKNS1_8PathDataEEEPS2_NS_3argILi1EEES8_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISG_T0_T1_T2_EENSE_9list_av_3IT3_T4_T5_E4typeEEEMSJ_FSG_SK_SL_ESO_SP_SQ_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::NavigationPath,dtNavMesh *,const boost::shared_ptr<const RBX::PathData> &>,boost::_bi::list3<boost::_bi::value<RBX::NavigationPath *>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<const RBX::PathData> > > > *__fastcall boost::bind<void,RBX::NavigationPath,dtNavMesh *,boost::shared_ptr<RBX::PathData const> const&,RBX::NavigationPath*,boost::arg<1>,boost::shared_ptr<RBX::PathData const>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::NavigationPath,dtNavMesh *,const boost::shared_ptr<const RBX::PathData> &>,boost::_bi::list3<boost::_bi::value<RBX::NavigationPath *>,boost::arg<1>,boost::_bi::value<boost::shared_ptr<const RBX::PathData> > > > *__return_ptr retstr,
        void (*f)(RBX::NavigationPath *, dtNavMesh *, const boost::shared_ptr<const RBX::PathData> *),
        RBX::NavigationPath *a1,
        RBX::NavigationPath *a2,
        boost::shared_ptr<const RBX::PathData> a3)
{
  __int64 v5; // rax
  boost::shared_ptr<const RBX::PathData>::element_type *v8; // rbp
  boost::detail::sp_counted_base *v9; // rbx

  v8 = *(boost::shared_ptr<const RBX::PathData>::element_type **)a3.px;
  v9 = (boost::detail::sp_counted_base *)*((_QWORD *)a3.px + 1);
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::NavigationPath *, dtNavMesh *, const boost::shared_ptr<const RBX::PathData> *), RBX::NavigationPath *, RBX::NavigationPath *, boost::shared_ptr<const RBX::PathData>::element_type *, boost::detail::sp_counted_base *, __int64))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_,
        v5);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = a1;
  retstr->l_.a1_.t_ = a2;
  retstr->l_.a3_.t_.px = v8;
  retstr->l_.a3_.t_.pn.pi_ = v9;
  if ( v9 )
  {
    _InterlockedAdd(&v9->use_count_, 1u);
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::NavigationPath *, dtNavMesh *, const boost::shared_ptr<const RBX::PathData> *), RBX::NavigationPath *, RBX::NavigationPath *, boost::shared_ptr<const RBX::PathData>::element_type *, boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, void (*)(RBX::NavigationPath *, dtNavMesh *, const boost::shared_ptr<const RBX::PathData> *), RBX::NavigationPath *, RBX::NavigationPath *, boost::shared_ptr<const RBX::PathData>::element_type *, boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base
       + 2))(
        v9,
        f,
        a1,
        a2,
        a3.px,
        a3.pn.pi_);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x1ecf7a0 | Name: _ZN5boost4bindIvN3RBX19NavigationDebugDrawEP9dtNavMeshNS1_7ExtentsENS_10shared_ptrIS2_EENS_3argILi1EEES5_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISC_T0_T1_T2_EENSA_9list_av_3IT3_T4_T5_E4typeEEEMSF_FSC_SG_SH_ESK_SL_SM_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::NavigationDebugDraw,dtNavMesh *,RBX::Extents>,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::NavigationDebugDraw> >,boost::arg<1>,boost::_bi::value<RBX::Extents> > > *__fastcall boost::bind<void,RBX::NavigationDebugDraw,dtNavMesh *,RBX::Extents,boost::shared_ptr<RBX::NavigationDebugDraw>,boost::arg<1>,RBX::Extents>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,RBX::NavigationDebugDraw,dtNavMesh *,RBX::Extents>,boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::NavigationDebugDraw> >,boost::arg<1>,boost::_bi::value<RBX::Extents> > > *__return_ptr retstr,
        void (*f)(RBX::NavigationDebugDraw *, dtNavMesh *, RBX::Extents),
        boost::shared_ptr<RBX::NavigationDebugDraw> a1,
        boost::_bi::value<RBX::Extents> a3)
{
  boost::shared_ptr<RBX::NavigationDebugDraw>::element_type *px; // r14
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v8; // r14
  boost::detail::sp_counted_base *v9; // rbx
  boost::_bi::value<boost::shared_ptr<RBX::NavigationDebugDraw> > a1a; // [rsp+20h] [rbp-58h] BYREF
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::NavigationDebugDraw> >,boost::arg<1>,boost::_bi::value<RBX::Extents> > v12; // [rsp+30h] [rbp-48h] BYREF

  px = a1.px;
  a1.px = (boost::shared_ptr<RBX::NavigationDebugDraw>::element_type *)a1.pn.pi_->_vptr$sp_counted_base;
  a1a.t_.px = (boost::shared_ptr<RBX::NavigationDebugDraw>::element_type *)a1.pn.pi_->_vptr$sp_counted_base;
  a1.pn.pi_ = *(boost::detail::sp_counted_base **)&a1.pn.pi_->use_count_;
  a1a.t_.pn.pi_ = a1.pn.pi_;
  if ( a1.pn.pi_ )
    _InterlockedAdd(&a1.pn.pi_->use_count_, 1u);
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::NavigationDebugDraw>>,boost::arg<1>,boost::_bi::value<RBX::Extents>>::list3(
    &v12,
    (boost::_bi::value<boost::shared_ptr<RBX::NavigationDebugDraw> >)__PAIR128__((unsigned __int64)a1.px, &a1a),
    LOBYTE(a3.t_.high.y),
    a3);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = px;
  retstr->l_.a1_.t_.px = v12.a1_.t_.px;
  pi = v12.a1_.t_.pn.pi_;
  retstr->l_.a1_.t_.pn.pi_ = v12.a1_.t_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v8 = v12.a1_.t_.pn.pi_;
    retstr->l_.a3_ = v12.a3_;
    if ( v8 )
    {
      if ( !_InterlockedSub(&v8->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 2))(v8);
        if ( !_InterlockedSub(&v8->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v8->_vptr$sp_counted_base + 3))(v8);
      }
    }
  }
  else
  {
    retstr->l_.a3_ = v12.a3_;
  }
  v9 = a1a.t_.pn.pi_;
  if ( a1a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a1a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return retstr;
}


// Address: 0x269eb70 | Name: _ZN5boost4bindIvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS_4asio2ip23basic_resolver_iteratorINSC_3tcpEEENSt3__110shared_ptrIS6_EEPFNS_3argILi1EEEvEPFNSJ_ILi2EEEvEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISS_T0_T1_T2_EENSQ_9list_av_3IT3_T4_T5_E4typeEEEMSV_FSS_SW_SX_ES10_S11_S12_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *__fastcall boost::bind<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *__return_ptr retstr,
        void (*f)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),
        std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> a1,
        boost::arg<1> (*a2)(void),
        boost::arg<2> (*a3)(void))
{
  __int64 v5; // rax
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *ptr; // r15
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *v7; // r13
  volatile signed __int64 *v8; // rbx

  ptr = a1.__ptr_;
  v7 = *(std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type **)a1.__cntrl_;
  v8 = (volatile signed __int64 *)*((_QWORD *)a1.__cntrl_ + 1);
  if ( v8 )
  {
    _InterlockedAdd64(v8 + 1, 1u);
    _InterlockedAdd64(v8 + 1, 1u);
    _InterlockedAdd64(v8 + 1, 1u);
    _InterlockedAdd64(v8 + 1, 1u);
    _InterlockedAdd64(v8 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void), __int64))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3,
        v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void)))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void)))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = ptr;
    retstr->l_.a1_.t_.__ptr_ = v7;
    retstr->l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)v8;
    _InterlockedAdd64(v8 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void)))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void)))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.__ptr_;
    retstr->l_.a1_.t_.__ptr_ = v7;
    retstr->l_.a1_.t_.__cntrl_ = 0;
  }
  return retstr;
}


// Address: 0x26a03b0 | Name: _ZN5boost4bindIvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS_4asio2ip23basic_resolver_iteratorINSC_3tcpEEENSt3__110shared_ptrIS6_EEPFNS_3argILi1EEEvESF_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISP_T0_T1_T2_EENSN_9list_av_3IT3_T4_T5_E4typeEEEMSS_FSP_ST_SU_ESX_SY_SZ_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *__fastcall boost::bind<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>,boost::arg<1> (*)(void),boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *__return_ptr retstr,
        void (*f)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),
        std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> a1,
        boost::arg<1> (*a2)(void),
        __int64 *a5)
{
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *ptr; // r14
  size_t v6; // rax
  volatile signed __int64 *v7; // rax
  std::__shared_weak_count *cntrl; // rax
  std::__shared_weak_count *v9; // rax
  volatile signed __int64 *v10; // r14
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *index; // rbx
  boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > v15; // [rsp+0h] [rbp-78h] BYREF
  __int64 v16; // [rsp+18h] [rbp-60h] BYREF
  std::__shared_weak_count *v17; // [rsp+20h] [rbp-58h]
  __int64 v18; // [rsp+28h] [rbp-50h]
  boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > v19; // [rsp+30h] [rbp-48h] BYREF

  ptr = a1.__ptr_;
  v15.t_.values_.__cntrl_ = *(std::__shared_weak_count **)a1.__cntrl_;
  v6 = *((_QWORD *)a1.__cntrl_ + 1);
  v15.t_.index_ = v6;
  if ( v6 )
    _InterlockedAdd64((volatile signed __int64 *)(v6 + 8), 1u);
  v16 = *a5;
  v7 = (volatile signed __int64 *)a5[1];
  v17 = (std::__shared_weak_count *)v7;
  if ( v7 )
    _InterlockedAdd64(v7 + 1, 1u);
  v18 = a5[2];
  boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::list3(
    &v19,
    (boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >)__PAIR128__((unsigned __int64)a2, (boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&v15.t_.values_.__cntrl_),
    (boost::arg<1> (*)(void))&v16,
    v15);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = ptr;
  retstr->l_.a1_.t_.__ptr_ = v19.a1_.t_.__ptr_;
  cntrl = v19.a1_.t_.__cntrl_;
  retstr->l_.a1_.t_.__cntrl_ = v19.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  retstr->l_.a3_.t_.values_.__ptr_ = v19.a3_.t_.values_.__ptr_;
  v9 = v19.a3_.t_.values_.__cntrl_;
  retstr->l_.a3_.t_.values_.__cntrl_ = v19.a3_.t_.values_.__cntrl_;
  if ( v9 )
  {
    _InterlockedAdd64((volatile signed __int64 *)v9 + 1, 1u);
    v10 = (volatile signed __int64 *)v19.a3_.t_.values_.__cntrl_;
    retstr->l_.a3_.t_.index_ = v19.a3_.t_.index_;
    if ( v10 && !_InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v10 + 16))(v10);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v10);
    }
  }
  else
  {
    retstr->l_.a3_.t_.index_ = v19.a3_.t_.index_;
  }
  v11 = v19.a1_.t_.__cntrl_;
  if ( v19.a1_.t_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v19.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  v12 = v17;
  if ( v17 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v17 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  index = (std::__shared_weak_count *)v15.t_.index_;
  if ( v15.t_.index_ && !_InterlockedExchangeAdd64((volatile signed __int64 *)(v15.t_.index_ + 8), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)index + 16LL))(index);
    std::__shared_weak_count::__release_weak(index);
  }
  return retstr;
}


// Address: 0x26a1c00 | Name: _ZN5boost4bindIvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENSt3__110shared_ptrIS6_EEPFNS_3argILi1EEEvEEENS_3_bi6bind_tIT_NS_4_mfi3mf1ISK_T0_T1_EENSI_9list_av_2IT2_T3_E4typeEEEMSN_FSK_SO_ESR_SS_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > *__fastcall boost::bind<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>,boost::arg<1> (*)(void)>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > *__return_ptr retstr,
        void (*f)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *),
        std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> a1,
        boost::arg<1> (*a2)(void))
{
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *ptr; // r15
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *v5; // r13
  volatile signed __int64 *v6; // rbx

  ptr = a1.__ptr_;
  v5 = *(std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type **)a1.__cntrl_;
  v6 = (volatile signed __int64 *)*((_QWORD *)a1.__cntrl_ + 1);
  if ( v6 )
  {
    _InterlockedAdd64(v6 + 1, 1u);
    _InterlockedAdd64(v6 + 1, 1u);
    _InterlockedAdd64(v6 + 1, 1u);
    _InterlockedAdd64(v6 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v6 + 16))(
        v6,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v6 + 16))(
        v6,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = ptr;
    retstr->l_.a1_.t_.__ptr_ = v5;
    retstr->l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)v6;
    _InterlockedAdd64(v6 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v6 + 16))(
        v6,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context::ssl_proxy_tunnel *, const boost::system::error_code *), std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v6 + 16))(
        v6,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.__ptr_;
    retstr->l_.a1_.t_.__ptr_ = v5;
    retstr->l_.a1_.t_.__cntrl_ = 0;
  }
  return retstr;
}


// Address: 0x26a7830 | Name: _ZN5boost4bindIvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS_4asio2ip23basic_resolver_iteratorINSB_3tcpEEENSt3__110shared_ptrIS5_EEPFNS_3argILi1EEEvEPFNSI_ILi2EEEvEEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISR_T0_T1_T2_EENSP_9list_av_3IT3_T4_T5_E4typeEEEMSU_FSR_SV_SW_ESZ_S10_S11_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *__fastcall boost::bind<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,std::shared_ptr<web::http::client::details::asio_context>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *__return_ptr retstr,
        void (*f)(web::http::client::details::asio_context *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),
        std::shared_ptr<web::http::client::details::asio_context> a1,
        boost::arg<1> (*a2)(void),
        boost::arg<2> (*a3)(void))
{
  __int64 v5; // rax
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // r15
  std::shared_ptr<web::http::client::details::asio_context>::element_type *v7; // r13
  volatile signed __int64 *v8; // rbx

  ptr = a1.__ptr_;
  v7 = *(std::shared_ptr<web::http::client::details::asio_context>::element_type **)a1.__cntrl_;
  v8 = (volatile signed __int64 *)*((_QWORD *)a1.__cntrl_ + 1);
  if ( v8 )
  {
    _InterlockedAdd64(v8 + 1, 1u);
    _InterlockedAdd64(v8 + 1, 1u);
    _InterlockedAdd64(v8 + 1, 1u);
    _InterlockedAdd64(v8 + 1, 1u);
    _InterlockedAdd64(v8 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void), __int64))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3,
        v5);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void)))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void)))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = ptr;
    retstr->l_.a1_.t_.__ptr_ = v7;
    retstr->l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)v8;
    _InterlockedAdd64(v8 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void)))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
    if ( !_InterlockedExchangeAdd64(v8 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void), boost::arg<2> (*)(void)))(*v8 + 16))(
        v8,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2,
        a3);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v8);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.__ptr_;
    retstr->l_.a1_.t_.__ptr_ = v7;
    retstr->l_.a1_.t_.__cntrl_ = 0;
  }
  return retstr;
}


// Address: 0x26a7f80 | Name: _ZN5boost4bindIvN3web4http6client7details12asio_contextERKNS_6system10error_codeENSt3__110shared_ptrIS5_EEPFNS_3argILi1EEEvEEENS_3_bi6bind_tIT_NS_4_mfi3mf1ISJ_T0_T1_EENSH_9list_av_2IT2_T3_E4typeEEEMSM_FSJ_SN_ESQ_SR_
boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *__fastcall boost::bind<void,web::http::client::details::asio_context,boost::system::error_code const&,std::shared_ptr<web::http::client::details::asio_context>,boost::arg<1> (*)(void)>(
        boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *__return_ptr retstr,
        void (*f)(web::http::client::details::asio_context *, const boost::system::error_code *),
        std::shared_ptr<web::http::client::details::asio_context> a1,
        boost::arg<1> (*a2)(void))
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // r15
  std::shared_ptr<web::http::client::details::asio_context>::element_type *v5; // r13
  volatile signed __int64 *v6; // rbx

  ptr = a1.__ptr_;
  v5 = *(std::shared_ptr<web::http::client::details::asio_context>::element_type **)a1.__cntrl_;
  v6 = (volatile signed __int64 *)*((_QWORD *)a1.__cntrl_ + 1);
  if ( v6 )
  {
    _InterlockedAdd64(v6 + 1, 1u);
    _InterlockedAdd64(v6 + 1, 1u);
    _InterlockedAdd64(v6 + 1, 1u);
    _InterlockedAdd64(v6 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v6 + 16))(
        v6,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v6 + 16))(
        v6,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = ptr;
    retstr->l_.a1_.t_.__ptr_ = v5;
    retstr->l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)v6;
    _InterlockedAdd64(v6 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v6 + 16))(
        v6,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
    if ( !_InterlockedExchangeAdd64(v6 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v6 + 16))(
        v6,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v6);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.__ptr_;
    retstr->l_.a1_.t_.__ptr_ = v5;
    retstr->l_.a1_.t_.__cntrl_ = 0;
  }
  return retstr;
}


// Address: 0x26b4df0 | Name: _ZN5boost4bindIvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiNSt3__110shared_ptrIS5_EEPFNS_3argILi1EEEvEiEENS_3_bi6bind_tIT_NS_4_mfi3mf2ISJ_T0_T1_T2_EENSH_9list_av_3IT3_T4_T5_E4typeEEEMSM_FSJ_SN_SO_ESR_SS_ST_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > *__fastcall boost::bind<void,web::http::client::details::asio_context,boost::system::error_code const&,int,std::shared_ptr<web::http::client::details::asio_context>,boost::arg<1> (*)(void),int>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > *__return_ptr retstr,
        void (*f)(web::http::client::details::asio_context *, const boost::system::error_code *, int),
        std::shared_ptr<web::http::client::details::asio_context> a1,
        boost::arg<1> (*a2)(void),
        int a3)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // r12
  std::shared_ptr<web::http::client::details::asio_context>::element_type *v6; // r13
  volatile signed __int64 *v7; // rbx

  ptr = a1.__ptr_;
  v6 = *(std::shared_ptr<web::http::client::details::asio_context>::element_type **)a1.__cntrl_;
  v7 = (volatile signed __int64 *)*((_QWORD *)a1.__cntrl_ + 1);
  if ( v7 )
  {
    _InterlockedAdd64(v7 + 1, 1u);
    _InterlockedAdd64(v7 + 1, 1u);
    _InterlockedAdd64(v7 + 1, 1u);
    _InterlockedAdd64(v7 + 1, 1u);
    _InterlockedAdd64(v7 + 1, 1u);
    if ( !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, int), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v7 + 16))(
        v7,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
    if ( !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, int), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v7 + 16))(
        v7,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
    if ( !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, int), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v7 + 16))(
        v7,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = ptr;
    retstr->l_.a1_.t_.__ptr_ = v6;
    retstr->l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)v7;
    _InterlockedAdd64(v7 + 1, 1u);
    retstr->l_.a3_.t_ = a3;
    if ( !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, int), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v7 + 16))(
        v7,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
    if ( !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *, void (*)(web::http::client::details::asio_context *, const boost::system::error_code *, int), std::shared_ptr<web::http::client::details::asio_context>::element_type *, std::__shared_weak_count *, boost::arg<1> (*)(void)))(*v7 + 16))(
        v7,
        f,
        a1.__ptr_,
        a1.__cntrl_,
        a2);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
  }
  else
  {
    retstr->f_.f_ = f;
    *((_QWORD *)&retstr->f_.f_ + 1) = a1.__ptr_;
    retstr->l_.a1_.t_.__ptr_ = v6;
    retstr->l_.a1_.t_.__cntrl_ = 0;
    retstr->l_.a3_.t_ = a3;
  }
  return retstr;
}


// Address: 0x26bb610 | Name: _ZN5boost4bindIvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS_4asio2ip23basic_resolver_iteratorINSB_3tcpEEENSt3__110shared_ptrIS5_EEPFNS_3argILi1EEEvESE_EENS_3_bi6bind_tIT_NS_4_mfi3mf2ISO_T0_T1_T2_EENSM_9list_av_3IT3_T4_T5_E4typeEEEMSR_FSO_SS_ST_ESW_SX_SY_
boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *__fastcall boost::bind<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>,std::shared_ptr<web::http::client::details::asio_context>,boost::arg<1> (*)(void),boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>(
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *__return_ptr retstr,
        void (*f)(web::http::client::details::asio_context *, const boost::system::error_code *, boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),
        std::shared_ptr<web::http::client::details::asio_context> a1,
        boost::arg<1> (*a2)(void),
        __int64 *a5)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // r14
  size_t v6; // rax
  volatile signed __int64 *v7; // rax
  std::__shared_weak_count *cntrl; // rax
  std::__shared_weak_count *v9; // rax
  volatile signed __int64 *v10; // r14
  std::__shared_weak_count *v11; // rbx
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *index; // rbx
  boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > v15; // [rsp+0h] [rbp-78h] BYREF
  __int64 v16; // [rsp+18h] [rbp-60h] BYREF
  std::__shared_weak_count *v17; // [rsp+20h] [rbp-58h]
  __int64 v18; // [rsp+28h] [rbp-50h]
  boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > v19; // [rsp+30h] [rbp-48h] BYREF

  ptr = a1.__ptr_;
  v15.t_.values_.__cntrl_ = *(std::__shared_weak_count **)a1.__cntrl_;
  v6 = *((_QWORD *)a1.__cntrl_ + 1);
  v15.t_.index_ = v6;
  if ( v6 )
    _InterlockedAdd64((volatile signed __int64 *)(v6 + 8), 1u);
  v16 = *a5;
  v7 = (volatile signed __int64 *)a5[1];
  v17 = (std::__shared_weak_count *)v7;
  if ( v7 )
    _InterlockedAdd64(v7 + 1, 1u);
  v18 = a5[2];
  boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>::list3(
    &v19,
    (boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >)__PAIR128__(
                                                                                     (unsigned __int64)a2,
                                                                                     (boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&v15.t_.values_.__cntrl_),
    (boost::arg<1> (*)(void))&v16,
    v15);
  retstr->f_.f_ = f;
  *((_QWORD *)&retstr->f_.f_ + 1) = ptr;
  retstr->l_.a1_.t_.__ptr_ = v19.a1_.t_.__ptr_;
  cntrl = v19.a1_.t_.__cntrl_;
  retstr->l_.a1_.t_.__cntrl_ = v19.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64((volatile signed __int64 *)cntrl + 1, 1u);
  retstr->l_.a3_.t_.values_.__ptr_ = v19.a3_.t_.values_.__ptr_;
  v9 = v19.a3_.t_.values_.__cntrl_;
  retstr->l_.a3_.t_.values_.__cntrl_ = v19.a3_.t_.values_.__cntrl_;
  if ( v9 )
  {
    _InterlockedAdd64((volatile signed __int64 *)v9 + 1, 1u);
    v10 = (volatile signed __int64 *)v19.a3_.t_.values_.__cntrl_;
    retstr->l_.a3_.t_.index_ = v19.a3_.t_.index_;
    if ( v10 && !_InterlockedExchangeAdd64(v10 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v10 + 16))(v10);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v10);
    }
  }
  else
  {
    retstr->l_.a3_.t_.index_ = v19.a3_.t_.index_;
  }
  v11 = v19.a1_.t_.__cntrl_;
  if ( v19.a1_.t_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v19.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
    std::__shared_weak_count::__release_weak(v11);
  }
  v12 = v17;
  if ( v17 && !_InterlockedExchangeAdd64((volatile signed __int64 *)v17 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  index = (std::__shared_weak_count *)v15.t_.index_;
  if ( v15.t_.index_ && !_InterlockedExchangeAdd64((volatile signed __int64 *)(v15.t_.index_ + 8), 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)index + 16LL))(index);
    std::__shared_weak_count::__release_weak(index);
  }
  return retstr;
}


