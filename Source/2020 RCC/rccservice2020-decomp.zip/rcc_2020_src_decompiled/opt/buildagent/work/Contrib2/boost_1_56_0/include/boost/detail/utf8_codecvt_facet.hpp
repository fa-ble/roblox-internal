// Address: 0xe636b0 | Name: _ZN5boost15program_options6detail18utf8_codecvt_facetD0Ev
void __fastcall boost::program_options::detail::utf8_codecvt_facet::~utf8_codecvt_facet(
        boost::program_options::detail::utf8_codecvt_facet *this)
{
  std::codecvt<wchar_t,char,__mbstate_t>::~codecvt();
  operator delete(this);
}


// Address: 0xe636d0 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet10do_unshiftER11__mbstate_tPcS5_RS5_
std::codecvt_base::result __fastcall boost::program_options::detail::utf8_codecvt_facet::do_unshift(
        const boost::program_options::detail::utf8_codecvt_facet *this,
        mbstate_t *a2,
        char *from,
        char *a4,
        char **next)
{
  *next = from;
  return std::__1::codecvt_base::result::ok;
}


// Address: 0xe636e0 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet11do_encodingEv
int __fastcall boost::program_options::detail::utf8_codecvt_facet::do_encoding(
        const boost::program_options::detail::utf8_codecvt_facet *this)
{
  return 0;
}


// Address: 0xe636f0 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet16do_always_noconvEv
bool __fastcall boost::program_options::detail::utf8_codecvt_facet::do_always_noconv(
        const boost::program_options::detail::utf8_codecvt_facet *this)
{
  return 0;
}


// Address: 0xe63700 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet9do_lengthER11__mbstate_tPKcS6_m
int __fastcall boost::program_options::detail::utf8_codecvt_facet::do_length(
        const boost::program_options::detail::utf8_codecvt_facet *this,
        mbstate_t *s,
        const char *from,
        const char *from_end,
        size_t max_limit)
{
  return (*(int (__fastcall **)(const boost::program_options::detail::utf8_codecvt_facet *, mbstate_t *, const char *, const char *, size_t))(*(_QWORD *)this + 80LL))(
           this,
           s,
           from,
           from_end,
           max_limit);
}


// Address: 0xe63710 | Name: _ZNK5boost15program_options6detail18utf8_codecvt_facet13do_max_lengthEv
int __fastcall boost::program_options::detail::utf8_codecvt_facet::do_max_length(
        const boost::program_options::detail::utf8_codecvt_facet *this)
{
  return 6;
}


