// Address: 0x1e5c360 | Name: _ZN5boost12shared_arrayIN3RBX19DecompConvexExtentsEE5resetIS2_EEvPT_
void __fastcall boost::shared_array<RBX::DecompConvexExtents>::reset<RBX::DecompConvexExtents>(
        boost::shared_array<RBX::DecompConvexExtents>_0 *this,
        RBX::DecompConvexExtents *p)
{
  boost::detail::sp_counted_base *v2; // rax
  boost::detail::sp_counted_base *pi; // r14

  v2 = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_QWORD *)&v2->use_count_ = 0x100000001LL;
  v2->_vptr$sp_counted_base = (int (**)(void))&off_29A1220;
  v2[1]._vptr$sp_counted_base = (int (**)(void))p;
  this->px = p;
  pi = this->pn.pi_;
  this->pn.pi_ = v2;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1e5c410 | Name: _ZN5boost12shared_arrayIN3RBX19DecompConvexExtentsEED2Ev
void __fastcall boost::shared_array<RBX::DecompConvexExtents>::~shared_array(
        boost::shared_array<RBX::DecompConvexExtents>_0 *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


