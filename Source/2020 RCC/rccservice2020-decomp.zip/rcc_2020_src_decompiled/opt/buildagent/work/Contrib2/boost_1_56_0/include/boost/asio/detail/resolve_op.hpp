// Address: 0x2620260 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSA_6config15asio_tls_client16transport_configEEEFvNS8_10shared_ptrINSC_10connectionISG_EEEENSI_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISO_EENS0_22deadline_timer_serviceISO_SQ_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEJPSH_RSL_RSU_RS10_RKNS8_12placeholders4__phILi1EEERKNS1E_ILi2EEEEEENS1_26is_continuation_if_runningEEEEC2ENS8_8weak_ptrIvEERKNS3_20basic_resolver_queryIS4_EERNS1_15task_io_serviceERS1N_
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::resolve_op(
        boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *this,
        boost::asio::detail::socket_ops::weak_cancel_token_type cancel_token,
        const boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >::query_type *query,
        boost::asio::detail::io_service_impl_0 *ios,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  std::__shared_weak_count *cntrl; // r12
  __int64 v8; // rax
  __int128 v9; // xmm0
  __int128 v10; // xmm1
  boost::asio::detail::io_service_impl_0 *v11; // rax

  cntrl = cancel_token.__cntrl_;
  *(_QWORD *)this = 0;
  *((_QWORD *)this + 1) = boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::do_complete;
  *((_DWORD *)this + 4) = 0;
  *((_QWORD *)this + 3) = *(_QWORD *)cancel_token.__ptr_;
  v8 = *((_QWORD *)cancel_token.__ptr_ + 1);
  *((_QWORD *)this + 4) = v8;
  if ( v8 )
    _InterlockedAdd64((volatile signed __int64 *)(v8 + 16), 1u);
  v9 = *(_OWORD *)cancel_token.__cntrl_;
  v10 = *((_OWORD *)cancel_token.__cntrl_ + 1);
  *(_OWORD *)((char *)this + 72) = *((_OWORD *)cancel_token.__cntrl_ + 2);
  *(_OWORD *)((char *)this + 56) = v10;
  *(_OWORD *)((char *)this + 40) = v9;
  std::string::basic_string((char *)this + 88, (char *)cancel_token.__cntrl_ + 48);
  std::string::basic_string((char *)this + 112, (char *)cntrl + 72);
  *((_QWORD *)this + 17) = query;
  *((_OWORD *)this + 9) = *(_OWORD *)&ios->_vptr$service;
  *((_OWORD *)this + 10) = *(_OWORD *)&ios->key_.id_;
  *((_QWORD *)this + 22) = ios->next_;
  *(_OWORD *)((char *)this + 184) = *(_OWORD *)&ios->one_thread_;
  *(_OWORD *)&ios->one_thread_ = 0;
  *(_OWORD *)((char *)this + 200) = *(_OWORD *)(&ios->mutex_.mutex_.__align + 1);
  *(_OWORD *)(&ios->mutex_.mutex_.__align + 1) = 0;
  v11 = (boost::asio::detail::io_service_impl_0 *)*(&ios->wakeup_event_.cond_.__align + 3);
  if ( v11 )
  {
    if ( &ios->mutex_.mutex_.__align + 4 == (__int64 *)v11 )
    {
      *((_QWORD *)this + 32) = (char *)this + 224;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&ios->wakeup_event_.cond_.__align + 3) + 24LL))(*(&ios->wakeup_event_.cond_.__align + 3));
    }
    else
    {
      *((_QWORD *)this + 32) = v11;
      *(&ios->wakeup_event_.cond_.__align + 3) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 32) = 0;
  }
  *((_DWORD *)this + 68) = 0;
  *((_QWORD *)this + 35) = boost::system::system_category();
  *((_QWORD *)this + 36) = 0;
}


// Address: 0x26203e0 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSA_6config15asio_tls_client16transport_configEEEFvNS8_10shared_ptrINSC_10connectionISG_EEEENSI_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISO_EENS0_22deadline_timer_serviceISO_SQ_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEJPSH_RSL_RSU_RS10_RKNS8_12placeholders4__phILi1EEERKNS1E_ILi2EEEEEENS1_26is_continuation_if_runningEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES14_m
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd f; // rbx
  boost::asio::detail::operation *v6; // rdi
  const char *index; // rax
  boost::asio::detail::task_io_service_operation::func_type func; // rcx
  const char *v9; // r15
  const char *v10; // rbx
  int v11; // eax
  boost::system::error_code v12; // rax
  int m_val; // ebx
  const boost::system::error_category *m_cat; // rax
  boost::asio::detail::task_io_service_operation *next; // rbx
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > values; // xmm0
  volatile signed __int64 *cntrl; // rbx
  std::__shared_weak_count *v18; // rbx
  std::__shared_weak_count *v19; // rbx
  std::__shared_weak_count *v20; // rbx
  std::__shared_weak_count *v21; // rbx
  boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> v22; // [rsp+0h] [rbp-138h] BYREF
  _BYTE v23[16]; // [rsp+20h] [rbp-118h] BYREF
  void *v24; // [rsp+30h] [rbp-108h]
  _BYTE v25[16]; // [rsp+38h] [rbp-100h] BYREF
  void *v26; // [rsp+48h] [rbp-F0h]
  boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > this_handler; // [rsp+50h] [rbp-E8h] BYREF
  unsigned __int64 v28; // [rsp+108h] [rbp-30h]

  v28 = __readfsqword(0x28u);
  if ( !owner || *(boost::asio::detail::io_service_impl_0 **)&base[5].task_result_ == owner )
  {
    this_handler.handler_.dispatcher_ = *(boost::asio::io_service::strand *)&base[6].next_;
    *(_OWORD *)&this_handler.handler_.handler_.__f_ = *(_OWORD *)&base[6].task_result_;
    *(_OWORD *)&this_handler.handler_.handler_.__bound_args_.__base_.__value_ = *(_OWORD *)&base[7].func_;
    this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ = (std::__shared_weak_count *)base[8].next_;
    *(_OWORD *)&base[7].task_result_ = 0;
    this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[8].func_;
    *(_OWORD *)&base[8].func_ = 0;
    v6 = *(boost::asio::detail::operation **)&base[10].task_result_;
    if ( v6 )
    {
      if ( &base[9].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v6 )
      {
        this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
        ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))v6->next_[1].next_)(
          v6,
          &this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
          a3,
          a4);
      }
      else
      {
        this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = *(std::function<void (const std::error_code &)>::__base **)&base[10].task_result_;
        *(_QWORD *)&base[10].task_result_ = 0;
      }
    }
    else
    {
      this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
    this_handler.arg1_ = *(boost::system::error_code *)&base[11].func_;
    memset(&this_handler.arg2_, 0, sizeof(this_handler.arg2_));
    next = base[12].next_;
    if ( next )
    {
      std::string::basic_string(v25, &base[3].task_result_);
      std::string::basic_string(v23, &base[4].task_result_);
      boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>::create(
        &v22,
        (boost::asio::detail::addrinfo_type *)next,
        (const std::string *)v25,
        (const std::string *)v23);
      values = v22.values_;
      v22.values_ = 0;
      cntrl = (volatile signed __int64 *)this_handler.arg2_.values_.__cntrl_;
      this_handler.arg2_.values_ = values;
      if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
        std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
      }
      v18 = v22.values_.__cntrl_;
      this_handler.arg2_.index_ = v22.index_;
      if ( v22.values_.__cntrl_
        && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(v18);
        std::__shared_weak_count::__release_weak(v18);
      }
      if ( (v23[0] & 1) != 0 )
        operator delete(v24);
      if ( (v25[0] & 1) != 0 )
        operator delete(v26);
    }
    boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::~resolve_op((boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)base);
    operator delete(base);
    if ( owner )
    {
      boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>(
        &this_handler,
        &this_handler.handler_);
      _mm_sfence();
    }
    v19 = this_handler.arg2_.values_.__cntrl_;
    if ( this_handler.arg2_.values_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)this_handler.arg2_.values_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(v19);
      std::__shared_weak_count::__release_weak(v19);
    }
    if ( &this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 4))(this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 5))(this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    v20 = this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(v20);
      std::__shared_weak_count::__release_weak(v20);
    }
    v21 = this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(v21);
      std::__shared_weak_count::__release_weak(v21);
    }
  }
  else
  {
    std::string::basic_string(&this_handler, &base[3].task_result_);
    if ( ((__int64)this_handler.handler_.dispatcher_.service_ & 1) != 0 )
      f = this_handler.handler_.handler_.__f_;
    else
      f = (std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd)((char *)&this_handler.handler_.dispatcher_.service_ + 1);
    std::string::basic_string(&v22, &base[4].task_result_);
    if ( ((__int64)v22.values_.__ptr_ & 1) != 0 )
      index = (const char *)v22.index_;
    else
      index = (char *)&v22.values_.__ptr_ + 1;
    func = base[1].func_;
    if ( !func || *((_QWORD *)func + 1) == -1 )
    {
      m_val = 125;
      m_cat = boost::system::system_category();
    }
    else
    {
      v9 = 0;
      if ( f && *(_BYTE *)f )
        v9 = (const char *)f;
      v10 = 0;
      if ( index && *index )
        v10 = index;
      *__errno_location() = 0;
      v11 = getaddrinfo(v9, v10, (const struct addrinfo *)&base[1].task_result_, (struct addrinfo **)&base[12]);
      v12 = boost::asio::detail::socket_ops::translate_addrinfo_error(v11);
      m_val = v12.m_val;
      m_cat = v12.m_cat;
    }
    LODWORD(base[11].func_) = m_val;
    *(_QWORD *)&base[11].task_result_ = m_cat;
    if ( ((__int64)v22.values_.__ptr_ & 1) != 0 )
      operator delete((void *)v22.index_);
    if ( ((__int64)this_handler.handler_.dispatcher_.service_ & 1) != 0 )
      operator delete(this_handler.handler_.handler_.__f_);
    boost::asio::detail::task_io_service::post_deferred_completion(
      *(boost::asio::detail::task_io_service_0 **)&base[5].task_result_,
      base);
  }
}


// Address: 0x2621310 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSA_6config15asio_tls_client16transport_configEEEFvNS8_10shared_ptrINSC_10connectionISG_EEEENSI_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISO_EENS0_22deadline_timer_serviceISO_SQ_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEJPSH_RSL_RSU_RS10_RKNS8_12placeholders4__phILi1EEERKNS1E_ILi2EEEEEENS1_26is_continuation_if_runningEEEED2Ev
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::~resolve_op(
        boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *this)
{
  struct addrinfo *v2; // rdi
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v3; // rdi
  volatile signed __int64 *v4; // r14
  volatile signed __int64 *v5; // r14
  std::__shared_weak_count *v6; // rdi

  v2 = (struct addrinfo *)*((_QWORD *)this + 36);
  if ( v2 )
    freeaddrinfo(v2);
  v3 = (boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)this + 32);
  if ( (boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)this + 224) == v3 )
  {
    (*(void (__fastcall **)(boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *))(*(_QWORD *)v3 + 32LL))(v3);
  }
  else if ( v3 )
  {
    (*(void (__fastcall **)(boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *))(*(_QWORD *)v3 + 40LL))(v3);
  }
  v4 = (volatile signed __int64 *)*((_QWORD *)this + 26);
  if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
  }
  v5 = (volatile signed __int64 *)*((_QWORD *)this + 24);
  if ( !v5 || _InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    if ( (*((_BYTE *)this + 112) & 1) == 0 )
      goto LABEL_14;
    goto LABEL_13;
  }
  (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
  std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
  if ( (*((_BYTE *)this + 112) & 1) != 0 )
LABEL_13:
    operator delete(*((void **)this + 16));
LABEL_14:
  if ( (*((_BYTE *)this + 88) & 1) != 0 )
    operator delete(*((void **)this + 13));
  v6 = (std::__shared_weak_count *)*((_QWORD *)this + 4);
  if ( v6 )
    std::__shared_weak_count::__release_weak(v6);
}


// Address: 0x26630c0 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSA_6config11asio_client16transport_configEEEFvNS8_10shared_ptrINSC_10connectionISG_EEEENSI_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISO_EENS0_22deadline_timer_serviceISO_SQ_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEJPSH_RSL_RSU_RS10_RKNS8_12placeholders4__phILi1EEERKNS1E_ILi2EEEEEENS1_26is_continuation_if_runningEEEEC2ENS8_8weak_ptrIvEERKNS3_20basic_resolver_queryIS4_EERNS1_15task_io_serviceERS1N_
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::resolve_op(
        boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *this,
        boost::asio::detail::socket_ops::weak_cancel_token_type cancel_token,
        const boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> >::query_type *query,
        boost::asio::detail::io_service_impl_0 *ios,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  std::__shared_weak_count *cntrl; // r12
  __int64 v8; // rax
  __int128 v9; // xmm0
  __int128 v10; // xmm1
  boost::asio::detail::io_service_impl_0 *v11; // rax

  cntrl = cancel_token.__cntrl_;
  *(_QWORD *)this = 0;
  *((_QWORD *)this + 1) = boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::do_complete;
  *((_DWORD *)this + 4) = 0;
  *((_QWORD *)this + 3) = *(_QWORD *)cancel_token.__ptr_;
  v8 = *((_QWORD *)cancel_token.__ptr_ + 1);
  *((_QWORD *)this + 4) = v8;
  if ( v8 )
    _InterlockedAdd64((volatile signed __int64 *)(v8 + 16), 1u);
  v9 = *(_OWORD *)cancel_token.__cntrl_;
  v10 = *((_OWORD *)cancel_token.__cntrl_ + 1);
  *(_OWORD *)((char *)this + 72) = *((_OWORD *)cancel_token.__cntrl_ + 2);
  *(_OWORD *)((char *)this + 56) = v10;
  *(_OWORD *)((char *)this + 40) = v9;
  std::string::basic_string((char *)this + 88, (char *)cancel_token.__cntrl_ + 48);
  std::string::basic_string((char *)this + 112, (char *)cntrl + 72);
  *((_QWORD *)this + 17) = query;
  *((_OWORD *)this + 9) = *(_OWORD *)&ios->_vptr$service;
  *((_OWORD *)this + 10) = *(_OWORD *)&ios->key_.id_;
  *((_QWORD *)this + 22) = ios->next_;
  *(_OWORD *)((char *)this + 184) = *(_OWORD *)&ios->one_thread_;
  *(_OWORD *)&ios->one_thread_ = 0;
  *(_OWORD *)((char *)this + 200) = *(_OWORD *)(&ios->mutex_.mutex_.__align + 1);
  *(_OWORD *)(&ios->mutex_.mutex_.__align + 1) = 0;
  v11 = (boost::asio::detail::io_service_impl_0 *)*(&ios->wakeup_event_.cond_.__align + 3);
  if ( v11 )
  {
    if ( &ios->mutex_.mutex_.__align + 4 == (__int64 *)v11 )
    {
      *((_QWORD *)this + 32) = (char *)this + 224;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&ios->wakeup_event_.cond_.__align + 3) + 24LL))(*(&ios->wakeup_event_.cond_.__align + 3));
    }
    else
    {
      *((_QWORD *)this + 32) = v11;
      *(&ios->wakeup_event_.cond_.__align + 3) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 32) = 0;
  }
  *((_DWORD *)this + 68) = 0;
  *((_QWORD *)this + 35) = boost::system::system_category();
  *((_QWORD *)this + 36) = 0;
}


// Address: 0x2663240 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSA_6config11asio_client16transport_configEEEFvNS8_10shared_ptrINSC_10connectionISG_EEEENSI_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISO_EENS0_22deadline_timer_serviceISO_SQ_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEJPSH_RSL_RSU_RS10_RKNS8_12placeholders4__phILi1EEERKNS1E_ILi2EEEEEENS1_26is_continuation_if_runningEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationES14_m
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd f; // rbx
  boost::asio::detail::operation *v6; // rdi
  const char *index; // rax
  boost::asio::detail::task_io_service_operation::func_type func; // rcx
  const char *v9; // r15
  const char *v10; // rbx
  int v11; // eax
  boost::system::error_code v12; // rax
  int m_val; // ebx
  const boost::system::error_category *m_cat; // rax
  boost::asio::detail::task_io_service_operation *next; // rbx
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > values; // xmm0
  volatile signed __int64 *cntrl; // rbx
  std::__shared_weak_count *v18; // rbx
  std::__shared_weak_count *v19; // rbx
  std::__shared_weak_count *v20; // rbx
  std::__shared_weak_count *v21; // rbx
  boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> v22; // [rsp+0h] [rbp-138h] BYREF
  _BYTE v23[16]; // [rsp+20h] [rbp-118h] BYREF
  void *v24; // [rsp+30h] [rbp-108h]
  _BYTE v25[16]; // [rsp+38h] [rbp-100h] BYREF
  void *v26; // [rsp+48h] [rbp-F0h]
  boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > this_handler; // [rsp+50h] [rbp-E8h] BYREF
  unsigned __int64 v28; // [rsp+108h] [rbp-30h]

  v28 = __readfsqword(0x28u);
  if ( !owner || *(boost::asio::detail::io_service_impl_0 **)&base[5].task_result_ == owner )
  {
    this_handler.handler_.dispatcher_ = *(boost::asio::io_service::strand *)&base[6].next_;
    *(_OWORD *)&this_handler.handler_.handler_.__f_ = *(_OWORD *)&base[6].task_result_;
    *(_OWORD *)&this_handler.handler_.handler_.__bound_args_.__base_.__value_ = *(_OWORD *)&base[7].func_;
    this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ = (std::__shared_weak_count *)base[8].next_;
    *(_OWORD *)&base[7].task_result_ = 0;
    this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = *(std::__tuple_leaf<2,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> *)&base[8].func_;
    *(_OWORD *)&base[8].func_ = 0;
    v6 = *(boost::asio::detail::operation **)&base[10].task_result_;
    if ( v6 )
    {
      if ( &base[9].func_ == (boost::asio::detail::task_io_service_operation::func_type *)v6 )
      {
        this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>;
        ((void (__fastcall *)(boost::asio::detail::operation *, std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *, const boost::system::error_code *, size_t))v6->next_[1].next_)(
          v6,
          &this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false>,
          a3,
          a4);
      }
      else
      {
        this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = *(std::function<void (const std::error_code &)>::__base **)&base[10].task_result_;
        *(_QWORD *)&base[10].task_result_ = 0;
      }
    }
    else
    {
      this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
    this_handler.arg1_ = *(boost::system::error_code *)&base[11].func_;
    memset(&this_handler.arg2_, 0, sizeof(this_handler.arg2_));
    next = base[12].next_;
    if ( next )
    {
      std::string::basic_string(v25, &base[3].task_result_);
      std::string::basic_string(v23, &base[4].task_result_);
      boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>::create(
        &v22,
        (boost::asio::detail::addrinfo_type *)next,
        (const std::string *)v25,
        (const std::string *)v23);
      values = v22.values_;
      v22.values_ = 0;
      cntrl = (volatile signed __int64 *)this_handler.arg2_.values_.__cntrl_;
      this_handler.arg2_.values_ = values;
      if ( cntrl && !_InterlockedExchangeAdd64(cntrl + 1, 0xFFFFFFFFFFFFFFFFLL) )
      {
        (*(void (__fastcall **)(volatile signed __int64 *))(*cntrl + 16))(cntrl);
        std::__shared_weak_count::__release_weak((std::__shared_weak_count *)cntrl);
      }
      v18 = v22.values_.__cntrl_;
      this_handler.arg2_.index_ = v22.index_;
      if ( v22.values_.__cntrl_
        && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
      {
        (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(v18);
        std::__shared_weak_count::__release_weak(v18);
      }
      if ( (v23[0] & 1) != 0 )
        operator delete(v24);
      if ( (v25[0] & 1) != 0 )
        operator delete(v26);
    }
    boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::~resolve_op((boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)base);
    operator delete(base);
    if ( owner )
    {
      boost::asio::detail::asio_handler_invoke<boost::asio::detail::binder2<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>,boost::system::error_code,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>(
        &this_handler,
        &this_handler.handler_);
      _mm_sfence();
    }
    v19 = this_handler.arg2_.values_.__cntrl_;
    if ( this_handler.arg2_.values_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)this_handler.arg2_.values_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v19 + 16LL))(v19);
      std::__shared_weak_count::__release_weak(v19);
    }
    if ( &this_handler.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<3,std::function<void (const std::error_code &)>,false> *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 4))(this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    else if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 5))(this_handler.handler_.handler_.__bound_args_.__base_.__value_.__f_);
    }
    v20 = this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v20 + 16LL))(v20);
      std::__shared_weak_count::__release_weak(v20);
    }
    v21 = this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
    if ( this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
      && !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)this_handler.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v21 + 16LL))(v21);
      std::__shared_weak_count::__release_weak(v21);
    }
  }
  else
  {
    std::string::basic_string(&this_handler, &base[3].task_result_);
    if ( ((__int64)this_handler.handler_.dispatcher_.service_ & 1) != 0 )
      f = this_handler.handler_.handler_.__f_;
    else
      f = (std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>::_Fd)((char *)&this_handler.handler_.dispatcher_.service_ + 1);
    std::string::basic_string(&v22, &base[4].task_result_);
    if ( ((__int64)v22.values_.__ptr_ & 1) != 0 )
      index = (const char *)v22.index_;
    else
      index = (char *)&v22.values_.__ptr_ + 1;
    func = base[1].func_;
    if ( !func || *((_QWORD *)func + 1) == -1 )
    {
      m_val = 125;
      m_cat = boost::system::system_category();
    }
    else
    {
      v9 = 0;
      if ( f && *(_BYTE *)f )
        v9 = (const char *)f;
      v10 = 0;
      if ( index && *index )
        v10 = index;
      *__errno_location() = 0;
      v11 = getaddrinfo(v9, v10, (const struct addrinfo *)&base[1].task_result_, (struct addrinfo **)&base[12]);
      v12 = boost::asio::detail::socket_ops::translate_addrinfo_error(v11);
      m_val = v12.m_val;
      m_cat = v12.m_cat;
    }
    LODWORD(base[11].func_) = m_val;
    *(_QWORD *)&base[11].task_result_ = m_cat;
    if ( ((__int64)v22.values_.__ptr_ & 1) != 0 )
      operator delete((void *)v22.index_);
    if ( ((__int64)this_handler.handler_.dispatcher_.service_ & 1) != 0 )
      operator delete(this_handler.handler_.handler_.__f_);
    boost::asio::detail::task_io_service::post_deferred_completion(
      *(boost::asio::detail::task_io_service_0 **)&base[5].task_result_,
      base);
  }
}


// Address: 0x26637c0 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSA_6config11asio_client16transport_configEEEFvNS8_10shared_ptrINSC_10connectionISG_EEEENSI_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISO_EENS0_22deadline_timer_serviceISO_SQ_EEEEEENS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEJPSH_RSL_RSU_RS10_RKNS8_12placeholders4__phILi1EEERKNS1E_ILi2EEEEEENS1_26is_continuation_if_runningEEEED2Ev
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::~resolve_op(
        boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *this)
{
  struct addrinfo *v2; // rdi
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v3; // rdi
  volatile signed __int64 *v4; // r14
  volatile signed __int64 *v5; // r14
  std::__shared_weak_count *v6; // rdi

  v2 = (struct addrinfo *)*((_QWORD *)this + 36);
  if ( v2 )
    freeaddrinfo(v2);
  v3 = (boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)*((_QWORD *)this + 32);
  if ( (boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)this + 224) == v3 )
  {
    (*(void (__fastcall **)(boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *))(*(_QWORD *)v3 + 32LL))(v3);
  }
  else if ( v3 )
  {
    (*(void (__fastcall **)(boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *))(*(_QWORD *)v3 + 40LL))(v3);
  }
  v4 = (volatile signed __int64 *)*((_QWORD *)this + 26);
  if ( v4 && !_InterlockedExchangeAdd64(v4 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(volatile signed __int64 *))(*v4 + 16))(v4);
    std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v4);
  }
  v5 = (volatile signed __int64 *)*((_QWORD *)this + 24);
  if ( !v5 || _InterlockedExchangeAdd64(v5 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    if ( (*((_BYTE *)this + 112) & 1) == 0 )
      goto LABEL_14;
    goto LABEL_13;
  }
  (*(void (__fastcall **)(volatile signed __int64 *))(*v5 + 16))(v5);
  std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v5);
  if ( (*((_BYTE *)this + 112) & 1) != 0 )
LABEL_13:
    operator delete(*((void **)this + 16));
LABEL_14:
  if ( (*((_BYTE *)this + 88) & 1) != 0 )
    operator delete(*((void **)this + 13));
  v6 = (std::__shared_weak_count *)*((_QWORD *)this + 4);
  if ( v6 )
    std::__shared_weak_count::__release_weak(v6);
}


// Address: 0x269fa30 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS5_5list3INS5_5valueINSt3__110shared_ptrISE_EEEEPFNS_3argILi1EEEvEPFNSS_ILi2EEEvEEEEEEC2ENSO_8weak_ptrIvEERKNS3_20basic_resolver_queryIS4_EERNS1_15task_io_serviceERS10_
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::resolve_op(
        boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > > *this,
        boost::asio::detail::socket_ops::weak_cancel_token_type cancel_token,
        const boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > >::query_type *query,
        boost::asio::detail::io_service_impl_0 *ios,
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *handler)
{
  std::__shared_weak_count *cntrl; // r12
  __int64 v8; // rax
  __int128 v9; // xmm0
  __int128 v10; // xmm1

  cntrl = cancel_token.__cntrl_;
  *(_QWORD *)this = 0;
  *((_QWORD *)this + 1) = boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::do_complete;
  *((_DWORD *)this + 4) = 0;
  *((_QWORD *)this + 3) = *(_QWORD *)cancel_token.__ptr_;
  v8 = *((_QWORD *)cancel_token.__ptr_ + 1);
  *((_QWORD *)this + 4) = v8;
  if ( v8 )
    _InterlockedAdd64((volatile signed __int64 *)(v8 + 16), 1u);
  v9 = *(_OWORD *)cancel_token.__cntrl_;
  v10 = *((_OWORD *)cancel_token.__cntrl_ + 1);
  *(_OWORD *)((char *)this + 72) = *((_OWORD *)cancel_token.__cntrl_ + 2);
  *(_OWORD *)((char *)this + 56) = v10;
  *(_OWORD *)((char *)this + 40) = v9;
  std::string::basic_string((char *)this + 88, (char *)cancel_token.__cntrl_ + 48);
  std::string::basic_string((char *)this + 112, (char *)cntrl + 72);
  *((_QWORD *)this + 17) = query;
  *((_OWORD *)this + 9) = *(_OWORD *)&ios->_vptr$service;
  *((_OWORD *)this + 10) = *(_OWORD *)&ios->key_.id_;
  *(_OWORD *)&ios->key_.id_ = 0;
  *((_DWORD *)this + 44) = 0;
  *((_QWORD *)this + 23) = boost::system::system_category();
  *((_QWORD *)this + 24) = 0;
}


// Address: 0x269fb40 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS5_5list3INS5_5valueINSt3__110shared_ptrISE_EEEEPFNS_3argILi1EEEvEPFNSS_ILi2EEEvEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESI_m
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::_bi::type<void> *v4; // rbx
  boost::asio::detail::task_io_service_operation *next; // rbx
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > values; // xmm0
  volatile signed __int64 *v7; // rbx
  std::__shared_weak_count *cntrl; // rbx
  int v9; // r8d
  unsigned __int64 v10; // rax
  boost::asio::detail::operation **v11; // rax
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  const char *index; // rax
  boost::asio::detail::task_io_service_operation::func_type func; // rcx
  const char *v16; // r15
  const char *v17; // rbx
  int v18; // eax
  boost::system::error_code v19; // rax
  int m_val; // ebx
  const boost::system::error_category *m_cat; // rax
  boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> v22; // [rsp+0h] [rbp-C8h] BYREF
  boost::_bi::type<void> v23[16]; // [rsp+20h] [rbp-A8h] BYREF
  boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> v24; // [rsp+30h] [rbp-98h] BYREF
  __int128 v25; // [rsp+40h] [rbp-88h] BYREF
  std::__shared_weak_count *v26[2]; // [rsp+50h] [rbp-78h] BYREF
  size_t v27; // [rsp+60h] [rbp-68h]
  _BYTE v28[16]; // [rsp+70h] [rbp-58h] BYREF
  void *ptr; // [rsp+80h] [rbp-48h]
  _BYTE v30[16]; // [rsp+88h] [rbp-40h] BYREF
  void *v31; // [rsp+98h] [rbp-30h]

  if ( owner && *(boost::asio::detail::io_service_impl_0 **)&base[5].task_result_ != owner )
  {
    std::string::basic_string(v23, &base[3].task_result_);
    if ( (v23[0].gap0 & 1) != 0 )
      v4 = (boost::_bi::type<void> *)v24.a1_.t_.__ptr_;
    else
      v4 = &v23[1];
    std::string::basic_string(&v22, &base[4].task_result_);
    if ( ((__int64)v22.values_.__ptr_ & 1) != 0 )
      index = (const char *)v22.index_;
    else
      index = (char *)&v22.values_.__ptr_ + 1;
    func = base[1].func_;
    if ( !func || *((_QWORD *)func + 1) == -1 )
    {
      m_val = 125;
      m_cat = boost::system::system_category();
    }
    else
    {
      v16 = 0;
      if ( v4 && v4->gap0 )
        v16 = &v4->gap0;
      v17 = 0;
      if ( index && *index )
        v17 = index;
      *__errno_location() = 0;
      v18 = getaddrinfo(v16, v17, (const struct addrinfo *)&base[1].task_result_, (struct addrinfo **)&base[8]);
      v19 = boost::asio::detail::socket_ops::translate_addrinfo_error(v18);
      m_val = v19.m_val;
      m_cat = v19.m_cat;
    }
    LODWORD(base[7].func_) = m_val;
    *(_QWORD *)&base[7].task_result_ = m_cat;
    if ( ((__int64)v22.values_.__ptr_ & 1) != 0 )
      operator delete((void *)v22.index_);
    if ( (v23[0].gap0 & 1) != 0 )
      operator delete(v24.a1_.t_.__ptr_);
    boost::asio::detail::task_io_service::post_deferred_completion(
      *(boost::asio::detail::task_io_service_0 **)&base[5].task_result_,
      base);
    return;
  }
  *(_OWORD *)&v23[0].gap0 = *(_OWORD *)&base[6].next_;
  v24 = *(boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> *)&base[6].task_result_;
  *(_OWORD *)&base[6].task_result_ = 0;
  v25 = *(_OWORD *)&base[7].func_;
  *(_OWORD *)v26 = 0;
  v27 = 0;
  next = base[8].next_;
  if ( next )
  {
    std::string::basic_string(v30, &base[3].task_result_);
    std::string::basic_string(v28, &base[4].task_result_);
    boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>::create(
      &v22,
      (boost::asio::detail::addrinfo_type *)next,
      (const std::string *)v30,
      (const std::string *)v28);
    values = v22.values_;
    v22.values_ = 0;
    v7 = (volatile signed __int64 *)v26[1];
    *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)v26 = values;
    if ( v7 && !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(v7);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
    cntrl = v22.values_.__cntrl_;
    v27 = v22.index_;
    if ( v22.values_.__cntrl_
      && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
    if ( (v28[0] & 1) != 0 )
      operator delete(ptr);
    if ( (v30[0] & 1) != 0 )
      operator delete(v31);
  }
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::~resolve_op((boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > > *)base);
  v10 = __readfsqword(0xFFFFFFD8);
  if ( !v10 || (v11 = *(boost::asio::detail::operation ***)(v10 + 8)) == 0 || *v11 )
  {
    operator delete(base);
    if ( !owner )
      goto LABEL_21;
    goto LABEL_20;
  }
  LOBYTE(base->next_) = base[8].func_;
  *v11 = base;
  if ( owner )
  {
LABEL_20:
    v22.values_.__ptr_ = &v25;
    v22.values_.__cntrl_ = (std::__shared_weak_count *)v26;
    boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>::operator()<boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list2<boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> const&>>(
      &v24,
      (boost::_bi::type<void>)v23,
      (boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&v22,
      0,
      v9);
    _mm_sfence();
  }
LABEL_21:
  v12 = v26[1];
  if ( v26[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v26[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  v13 = v24.a1_.t_.__cntrl_;
  if ( v24.a1_.t_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v24.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
    std::__shared_weak_count::__release_weak(v13);
  }
}


// Address: 0x269ffd0 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS5_5list3INS5_5valueINSt3__110shared_ptrISE_EEEEPFNS_3argILi1EEEvEPFNSS_ILi2EEEvEEEEEED2Ev
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::~resolve_op(
        boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > > *this)
{
  struct addrinfo *v2; // rdi
  volatile signed __int64 *v3; // r14
  std::__shared_weak_count *v4; // rdi

  v2 = (struct addrinfo *)*((_QWORD *)this + 24);
  if ( v2 )
    freeaddrinfo(v2);
  v3 = (volatile signed __int64 *)*((_QWORD *)this + 21);
  if ( !v3 || _InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    if ( (*((_BYTE *)this + 112) & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
  (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(v3);
  std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
  if ( (*((_BYTE *)this + 112) & 1) != 0 )
LABEL_6:
    operator delete(*((void **)this + 16));
LABEL_7:
  if ( (*((_BYTE *)this + 88) & 1) != 0 )
    operator delete(*((void **)this + 13));
  v4 = (std::__shared_weak_count *)*((_QWORD *)this + 4);
  if ( v4 )
    std::__shared_weak_count::__release_weak(v4);
}


// Address: 0x26bae60 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS5_5list3INS5_5valueINSt3__110shared_ptrISD_EEEEPFNS_3argILi1EEEvEPFNSR_ILi2EEEvEEEEEEC2ENSN_8weak_ptrIvEERKNS3_20basic_resolver_queryIS4_EERNS1_15task_io_serviceERSZ_
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::resolve_op(
        boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > > *this,
        boost::asio::detail::socket_ops::weak_cancel_token_type cancel_token,
        const boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > >::query_type *query,
        boost::asio::detail::io_service_impl_0 *ios,
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *handler)
{
  std::__shared_weak_count *cntrl; // r12
  __int64 v8; // rax
  __int128 v9; // xmm0
  __int128 v10; // xmm1

  cntrl = cancel_token.__cntrl_;
  *(_QWORD *)this = 0;
  *((_QWORD *)this + 1) = boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::do_complete;
  *((_DWORD *)this + 4) = 0;
  *((_QWORD *)this + 3) = *(_QWORD *)cancel_token.__ptr_;
  v8 = *((_QWORD *)cancel_token.__ptr_ + 1);
  *((_QWORD *)this + 4) = v8;
  if ( v8 )
    _InterlockedAdd64((volatile signed __int64 *)(v8 + 16), 1u);
  v9 = *(_OWORD *)cancel_token.__cntrl_;
  v10 = *((_OWORD *)cancel_token.__cntrl_ + 1);
  *(_OWORD *)((char *)this + 72) = *((_OWORD *)cancel_token.__cntrl_ + 2);
  *(_OWORD *)((char *)this + 56) = v10;
  *(_OWORD *)((char *)this + 40) = v9;
  std::string::basic_string((char *)this + 88, (char *)cancel_token.__cntrl_ + 48);
  std::string::basic_string((char *)this + 112, (char *)cntrl + 72);
  *((_QWORD *)this + 17) = query;
  *((_OWORD *)this + 9) = *(_OWORD *)&ios->_vptr$service;
  *((_OWORD *)this + 10) = *(_OWORD *)&ios->key_.id_;
  *(_OWORD *)&ios->key_.id_ = 0;
  *((_DWORD *)this + 44) = 0;
  *((_QWORD *)this + 23) = boost::system::system_category();
  *((_QWORD *)this + 24) = 0;
}


// Address: 0x26baf70 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS5_5list3INS5_5valueINSt3__110shared_ptrISD_EEEEPFNS_3argILi1EEEvEPFNSR_ILi2EEEvEEEEEE11do_completeEPNS1_15task_io_serviceEPNS1_25task_io_service_operationESH_m
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::do_complete(
        boost::asio::detail::io_service_impl_0 *owner,
        boost::asio::detail::operation *base,
        const boost::system::error_code *a3,
        size_t a4)
{
  boost::_bi::type<void> *v4; // rbx
  boost::asio::detail::task_io_service_operation *next; // rbx
  std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > values; // xmm0
  volatile signed __int64 *v7; // rbx
  std::__shared_weak_count *cntrl; // rbx
  int v9; // r8d
  unsigned __int64 v10; // rax
  boost::asio::detail::operation **v11; // rax
  std::__shared_weak_count *v12; // rbx
  std::__shared_weak_count *v13; // rbx
  const char *index; // rax
  boost::asio::detail::task_io_service_operation::func_type func; // rcx
  const char *v16; // r15
  const char *v17; // rbx
  int v18; // eax
  boost::system::error_code v19; // rax
  int m_val; // ebx
  const boost::system::error_category *m_cat; // rax
  boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> v22; // [rsp+0h] [rbp-C8h] BYREF
  boost::_bi::type<void> v23[16]; // [rsp+20h] [rbp-A8h] BYREF
  boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> v24; // [rsp+30h] [rbp-98h] BYREF
  __int128 v25; // [rsp+40h] [rbp-88h] BYREF
  std::__shared_weak_count *v26[2]; // [rsp+50h] [rbp-78h] BYREF
  size_t v27; // [rsp+60h] [rbp-68h]
  _BYTE v28[16]; // [rsp+70h] [rbp-58h] BYREF
  void *ptr; // [rsp+80h] [rbp-48h]
  _BYTE v30[16]; // [rsp+88h] [rbp-40h] BYREF
  void *v31; // [rsp+98h] [rbp-30h]

  if ( owner && *(boost::asio::detail::io_service_impl_0 **)&base[5].task_result_ != owner )
  {
    std::string::basic_string(v23, &base[3].task_result_);
    if ( (v23[0].gap0 & 1) != 0 )
      v4 = (boost::_bi::type<void> *)v24.a1_.t_.__ptr_;
    else
      v4 = &v23[1];
    std::string::basic_string(&v22, &base[4].task_result_);
    if ( ((__int64)v22.values_.__ptr_ & 1) != 0 )
      index = (const char *)v22.index_;
    else
      index = (char *)&v22.values_.__ptr_ + 1;
    func = base[1].func_;
    if ( !func || *((_QWORD *)func + 1) == -1 )
    {
      m_val = 125;
      m_cat = boost::system::system_category();
    }
    else
    {
      v16 = 0;
      if ( v4 && v4->gap0 )
        v16 = &v4->gap0;
      v17 = 0;
      if ( index && *index )
        v17 = index;
      *__errno_location() = 0;
      v18 = getaddrinfo(v16, v17, (const struct addrinfo *)&base[1].task_result_, (struct addrinfo **)&base[8]);
      v19 = boost::asio::detail::socket_ops::translate_addrinfo_error(v18);
      m_val = v19.m_val;
      m_cat = v19.m_cat;
    }
    LODWORD(base[7].func_) = m_val;
    *(_QWORD *)&base[7].task_result_ = m_cat;
    if ( ((__int64)v22.values_.__ptr_ & 1) != 0 )
      operator delete((void *)v22.index_);
    if ( (v23[0].gap0 & 1) != 0 )
      operator delete(v24.a1_.t_.__ptr_);
    boost::asio::detail::task_io_service::post_deferred_completion(
      *(boost::asio::detail::task_io_service_0 **)&base[5].task_result_,
      base);
    return;
  }
  *(_OWORD *)&v23[0].gap0 = *(_OWORD *)&base[6].next_;
  v24 = *(boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> *)&base[6].task_result_;
  *(_OWORD *)&base[6].task_result_ = 0;
  v25 = *(_OWORD *)&base[7].func_;
  *(_OWORD *)v26 = 0;
  v27 = 0;
  next = base[8].next_;
  if ( next )
  {
    std::string::basic_string(v30, &base[3].task_result_);
    std::string::basic_string(v28, &base[4].task_result_);
    boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>::create(
      &v22,
      (boost::asio::detail::addrinfo_type *)next,
      (const std::string *)v30,
      (const std::string *)v28);
    values = v22.values_;
    v22.values_ = 0;
    v7 = (volatile signed __int64 *)v26[1];
    *(std::shared_ptr<std::vector<boost::asio::ip::basic_resolver_entry<boost::asio::ip::tcp>> > *)v26 = values;
    if ( v7 && !_InterlockedExchangeAdd64(v7 + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(volatile signed __int64 *))(*v7 + 16))(v7);
      std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v7);
    }
    cntrl = v22.values_.__cntrl_;
    v27 = v22.index_;
    if ( v22.values_.__cntrl_
      && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
    if ( (v28[0] & 1) != 0 )
      operator delete(ptr);
    if ( (v30[0] & 1) != 0 )
      operator delete(v31);
  }
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::~resolve_op((boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > > *)base);
  v10 = __readfsqword(0xFFFFFFD8);
  if ( !v10 || (v11 = *(boost::asio::detail::operation ***)(v10 + 8)) == 0 || *v11 )
  {
    operator delete(base);
    if ( !owner )
      goto LABEL_21;
    goto LABEL_20;
  }
  LOBYTE(base->next_) = base[8].func_;
  *v11 = base;
  if ( owner )
  {
LABEL_20:
    v22.values_.__ptr_ = &v25;
    v22.values_.__cntrl_ = (std::__shared_weak_count *)v26;
    boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>::operator()<boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list2<boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> const&>>(
      &v24,
      (boost::_bi::type<void>)v23,
      (boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > *)&v22,
      0,
      v9);
    _mm_sfence();
  }
LABEL_21:
  v12 = v26[1];
  if ( v26[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v26[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v12 + 16LL))(v12);
    std::__shared_weak_count::__release_weak(v12);
  }
  v13 = v24.a1_.t_.__cntrl_;
  if ( v24.a1_.t_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v24.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v13 + 16LL))(v13);
    std::__shared_weak_count::__release_weak(v13);
  }
}


// Address: 0x26bb400 | Name: _ZN5boost4asio6detail10resolve_opINS0_2ip3tcpENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS5_5list3INS5_5valueINSt3__110shared_ptrISD_EEEEPFNS_3argILi1EEEvEPFNSR_ILi2EEEvEEEEEED2Ev
void __fastcall boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::~resolve_op(
        boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > > *this)
{
  struct addrinfo *v2; // rdi
  volatile signed __int64 *v3; // r14
  std::__shared_weak_count *v4; // rdi

  v2 = (struct addrinfo *)*((_QWORD *)this + 24);
  if ( v2 )
    freeaddrinfo(v2);
  v3 = (volatile signed __int64 *)*((_QWORD *)this + 21);
  if ( !v3 || _InterlockedExchangeAdd64(v3 + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    if ( (*((_BYTE *)this + 112) & 1) == 0 )
      goto LABEL_7;
    goto LABEL_6;
  }
  (*(void (__fastcall **)(volatile signed __int64 *))(*v3 + 16))(v3);
  std::__shared_weak_count::__release_weak((std::__shared_weak_count *)v3);
  if ( (*((_BYTE *)this + 112) & 1) != 0 )
LABEL_6:
    operator delete(*((void **)this + 16));
LABEL_7:
  if ( (*((_BYTE *)this + 88) & 1) != 0 )
    operator delete(*((void **)this + 13));
  v4 = (std::__shared_weak_count *)*((_QWORD *)this + 4);
  if ( v4 )
    std::__shared_weak_count::__release_weak(v4);
}


