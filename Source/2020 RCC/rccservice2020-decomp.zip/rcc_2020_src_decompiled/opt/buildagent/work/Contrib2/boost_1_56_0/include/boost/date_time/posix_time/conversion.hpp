// Address: 0x11dfca0 | Name: _ZN5boost10posix_time13ptime_from_tmERK2tm
boost::posix_time::ptime __fastcall boost::posix_time::ptime_from_tm(const tm *timetm)
{
  int v2; // eax
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,12,boost::gregorian::bad_month> >::value_type v3; // ax
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,31,boost::gregorian::bad_day_of_month> >::value_type tm_mday; // si
  __int64 days; // rcx
  __int64 tm_hour; // rdx
  __int64 tm_min; // rsi
  __int64 tm_sec; // rdi
  __int64 v9; // rax
  __int64 v10; // rdx
  __int64 v11; // rax
  __int64 v12; // rdi
  __int64 v13; // rsi
  __int64 v14; // rdx
  boost::posix_time::ptime result; // rax
  boost::gregorian::date::day_type d[2]; // [rsp+0h] [rbp-28h] BYREF
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,12,boost::gregorian::bad_month> > v17[2]; // [rsp+8h] [rbp-20h] BYREF
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1400,10000,boost::gregorian::bad_year> > v18[2]; // [rsp+10h] [rbp-18h] BYREF
  boost::gregorian::date v19; // [rsp+18h] [rbp-10h] BYREF

  v2 = timetm->tm_year + 1900;
  v18[0].value_ = 1400;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1400,(unsigned short)10000,boost::gregorian::bad_year>>::assign(
    v18,
    v2);
  v3 = timetm->tm_mon + 1;
  v17[0].value_ = 1;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)12,boost::gregorian::bad_month>>::assign(
    v17,
    v3);
  tm_mday = timetm->tm_mday;
  d[0].value_ = 1;
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,(unsigned short)1,(unsigned short)31,boost::gregorian::bad_day_of_month>>::assign(
    &d[0],
    tm_mday);
  boost::gregorian::date::date(
    &v19,
    (boost::gregorian::date::year_type_0)v18[0].value_,
    (boost::gregorian::date::month_type_0)v17[0].value_,
    d[0]);
  days = v19.days_;
  tm_hour = timetm->tm_hour;
  tm_min = timetm->tm_min;
  tm_sec = timetm->tm_sec;
  if ( (int)(tm_sec | tm_hour | timetm->tm_min) < 0 )
  {
    v11 = (unsigned int)-(int)tm_sec;
    if ( -(int)tm_sec < 1 )
      v11 = (unsigned int)tm_sec;
    v12 = (unsigned int)-(int)tm_min;
    if ( -(int)tm_min < 1 )
      v12 = (unsigned int)tm_min;
    v13 = (unsigned int)-(int)tm_hour;
    if ( -(int)tm_hour < 1 )
      v13 = (unsigned int)tm_hour;
    v9 = 3600 * v13 + 60 * v12 + v11;
    v10 = -1000000;
  }
  else
  {
    v9 = tm_sec + 3600 * tm_hour + 60 * tm_min;
    v10 = 1000000;
  }
  v14 = v9 * v10;
  result.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFELL;
  if ( v19.days_ + 2 < 3 )
  {
    if ( v14 == 0x8000000000000000LL )
    {
      if ( v19.days_ == -2 )
        return result;
      goto LABEL_17;
    }
    if ( v19.days_ + 2 < 3 )
      return (boost::posix_time::ptime)(v19.days_ + 2 + 0x7FFFFFFFFFFFFFFELL);
    return (boost::posix_time::ptime)(days + v14);
  }
  if ( v14 != 0x8000000000000000LL )
  {
    days = 86400000000LL * v19.days_;
    return (boost::posix_time::ptime)(days + v14);
  }
LABEL_17:
  if ( v19.days_ != -1 )
    return (boost::posix_time::ptime)0x8000000000000000LL;
  return result;
}


