// Address: 0xecc250 | Name: _ZN3RBX7Network16ClientReplicator21requireGarbageCollectEv
void __fastcall RBX::Network::ClientReplicator::requireGarbageCollect(RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *v1; // rdi

  v1 = (RBX::Network::ClientReplicator::GCJob *)*((_QWORD *)this + 3860);
  if ( v1 )
    RBX::Network::ClientReplicator::GCJob::triggerEmergencyGC(v1);
}


// Address: 0xecdcc0 | Name: _ZNK3RBX7Network16ClientReplicator17getNumRegionsToGCEv
int __fastcall RBX::Network::ClientReplicator::getNumRegionsToGC(const RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 3860);
  if ( v1 )
    return *(_DWORD *)(v1 + 644);
  else
    return 0;
}


// Address: 0xecdce0 | Name: _ZNK3RBX7Network16ClientReplicator13getGCDistanceEv
short __fastcall RBX::Network::ClientReplicator::getGCDistance(const RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 3860);
  if ( v1 )
    return *(_WORD *)(v1 + 668);
  else
    return 0;
}


// Address: 0xecdd00 | Name: _ZN3RBX7Network16ClientReplicator21renderStreamedRegionsEPNS_5AdornE
void __fastcall RBX::Network::ClientReplicator::renderStreamedRegions(
        RBX::Network::ClientReplicator *this,
        RBX::Adorn *adorn)
{
  RBX::Network::ClientReplicator::GCJob *v2; // rdi

  v2 = (RBX::Network::ClientReplicator::GCJob *)*((_QWORD *)this + 3860);
  if ( v2 )
    RBX::Network::ClientReplicator::GCJob::render3dAdorn(v2, adorn);
}


// Address: 0xecdd20 | Name: _ZNK3RBX7Network16ClientReplicator21getNumStreamedRegionsEv
int __fastcall RBX::Network::ClientReplicator::getNumStreamedRegions(const RBX::Network::ClientReplicator *this)
{
  RBX::Network::ClientReplicator::GCJob *v1; // rdi

  v1 = (RBX::Network::ClientReplicator::GCJob *)*((_QWORD *)this + 3860);
  if ( v1 )
    return RBX::Network::ClientReplicator::GCJob::getNumRegions(v1);
  else
    return 0;
}


// Address: 0xecdd40 | Name: _ZNK3RBX7Network16ClientReplicator22getOutsideStreamedAreaEv
bool __fastcall RBX::Network::ClientReplicator::getOutsideStreamedArea(const RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 3860);
  return v1 && *(_BYTE *)(v1 + 624) != 0;
}


// Address: 0xecdd60 | Name: _ZNK3RBX7Network16ClientReplicator35getCurrentStreamedInDistanceInStudsEv
int __fastcall RBX::Network::ClientReplicator::getCurrentStreamedInDistanceInStuds(
        const RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 3860);
  if ( v1 )
    return *(_DWORD *)(v1 + 652);
  else
    return 0;
}


// Address: 0xecdd80 | Name: _ZNK3RBX7Network16ClientReplicator19getGCTargetDistanceERKNS_12StreamRegion2IdE
int __fastcall RBX::Network::ClientReplicator::getGCTargetDistance(
        const RBX::Network::ClientReplicator *this,
        const RBX::StreamRegion::Id *characterRegion)
{
  const RBX::Network::ClientReplicator::GCJob *v2; // rdi

  v2 = (const RBX::Network::ClientReplicator::GCJob *)*((_QWORD *)this + 3860);
  if ( v2 )
    return RBX::Network::ClientReplicator::GCJob::getGCTargetDistance(v2, characterRegion);
  else
    return 0;
}


// Address: 0xecdda0 | Name: _ZNK3RBX7Network16ClientReplicator27getServerStreamCenterRegionEv
RBX::StreamRegion::Id __fastcall RBX::Network::ClientReplicator::getServerStreamCenterRegion(
        const RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax
  RBX::StreamRegion::Id result; // 0:rax.12

  v1 = *((_QWORD *)this + 3860);
  if ( v1 )
  {
    result.internalValue.z = *(_DWORD *)(v1 + 740);
    *(_QWORD *)&result.internalValue.x = *(_QWORD *)(v1 + 732);
  }
  else
  {
    result.internalValue.z = 0;
    *(_QWORD *)&result.internalValue.x = 0;
  }
  return result;
}


// Address: 0xecdde0 | Name: _ZNK3RBX7Network16ClientReplicator24getStreamingPauseEnabledEv
bool __fastcall RBX::Network::ClientReplicator::getStreamingPauseEnabled(const RBX::Network::ClientReplicator *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 3860);
  return v1 && *(_BYTE *)(v1 + 627) != 0;
}


// Address: 0xf24910 | Name: _ZNK3RBX7Network19StrictNetworkFilter22findPropertyDescriptorERKNS_10Reflection18PropertyDescriptorE
RBX::Network::StrictNetworkFilter::WhiteListItem __fastcall RBX::Network::StrictNetworkFilter::findPropertyDescriptor(
        const RBX::Network::StrictNetworkFilter *this,
        const RBX::Reflection::PropertyDescriptor *desc)
{
  boost::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList>::element_type *px; // rdx
  unsigned __int64 v3; // rdi
  __int64 v4; // rcx
  RBX::Network::StrictNetworkFilter::WhiteListItem result; // eax
  __int64 v6; // r8
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer v8; // rdi
  size_t v9; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v10; // rdi

  px = this->propertyWhitelist.px;
  v3 = (21
      * ((265
        * ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
          + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21))
         ^ ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
           + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21)) >> 24)))
       ^ ((265
         * ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
           + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21))
          ^ ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
            + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21)) >> 24))) >> 14)))
     ^ ((21
       * ((265
         * ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
           + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21))
          ^ ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
            + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21)) >> 24)))
        ^ ((265
          * ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
            + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21))
           ^ ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
             + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21)) >> 24))) >> 14))) >> 28);
  v4 = 2147483649u * v3;
  result = RBX::Network::StrictNetworkFilter::WhiteListItem::kNotInList;
  if ( px )
  {
    if ( px->whitelist.table_.size_ )
    {
      v6 = px->whitelist.table_.bucket_count_ - 1;
      next = px->whitelist.table_.buckets_[v4 & v6].next_;
      if ( next )
      {
        while ( 1 )
        {
          next = next->next_;
          if ( !next )
            break;
          v8 = next[1].next_;
          if ( v8 == (boost::unordered::detail::ptr_bucket::link_pointer)v4 )
          {
            if ( (const RBX::Reflection::PropertyDescriptor *)next[2].next_ == desc )
              return (RBX::Network::StrictNetworkFilter::WhiteListItem)next[3].next_;
          }
          else if ( (v6 & (unsigned __int64)v8) != (v4 & v6) )
          {
            return result;
          }
        }
      }
    }
  }
  else if ( propertyWhiteListV2.whitelist.table_.size_ )
  {
    v9 = v4 & (propertyWhiteListV2.whitelist.table_.bucket_count_ - 1);
    next = propertyWhiteListV2.whitelist.table_.buckets_[v9].next_;
    if ( next )
    {
      while ( 1 )
      {
        next = next->next_;
        if ( !next )
          break;
        v10 = next[1].next_;
        if ( v10 == (boost::unordered::detail::ptr_bucket::link_pointer)v4 )
        {
          if ( (const RBX::Reflection::PropertyDescriptor *)next[2].next_ == desc )
            return (RBX::Network::StrictNetworkFilter::WhiteListItem)next[3].next_;
        }
        else if ( ((propertyWhiteListV2.whitelist.table_.bucket_count_ - 1) & (unsigned __int64)v10) != v9 )
        {
          return result;
        }
      }
    }
  }
  return result;
}


// Address: 0xf24a30 | Name: _ZNK3RBX7Network19StrictNetworkFilter19findEventDescriptorERKNS_10Reflection15EventDescriptorE
RBX::Network::StrictNetworkFilter::WhiteListItem __fastcall RBX::Network::StrictNetworkFilter::findEventDescriptor(
        const RBX::Network::StrictNetworkFilter *this,
        const RBX::Reflection::EventDescriptor *desc)
{
  boost::shared_ptr<RBX::Network::StrictNetworkFilter::WhiteList>::element_type *px; // rdx
  unsigned __int64 v3; // rdi
  __int64 v4; // rcx
  RBX::Network::StrictNetworkFilter::WhiteListItem result; // eax
  __int64 v6; // r8
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer v8; // rdi
  size_t v9; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v10; // rdi

  px = this->eventWhitelist.px;
  v3 = (21
      * ((265
        * ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
          + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21))
         ^ ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
           + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21)) >> 24)))
       ^ ((265
         * ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
           + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21))
          ^ ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
            + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21)) >> 24))) >> 14)))
     ^ ((21
       * ((265
         * ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
           + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21))
          ^ ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
            + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21)) >> 24)))
        ^ ((265
          * ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
            + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21))
           ^ ((~((unsigned __int64)desc + ((unsigned __int64)desc >> 3))
             + (((_QWORD)desc + ((unsigned __int64)desc >> 3)) << 21)) >> 24))) >> 14))) >> 28);
  v4 = 2147483649u * v3;
  result = RBX::Network::StrictNetworkFilter::WhiteListItem::kNotInList;
  if ( px )
  {
    if ( px->whitelist.table_.size_ )
    {
      v6 = px->whitelist.table_.bucket_count_ - 1;
      next = px->whitelist.table_.buckets_[v4 & v6].next_;
      if ( next )
      {
        while ( 1 )
        {
          next = next->next_;
          if ( !next )
            break;
          v8 = next[1].next_;
          if ( v8 == (boost::unordered::detail::ptr_bucket::link_pointer)v4 )
          {
            if ( (const RBX::Reflection::EventDescriptor *)next[2].next_ == desc )
              return (RBX::Network::StrictNetworkFilter::WhiteListItem)next[3].next_;
          }
          else if ( (v6 & (unsigned __int64)v8) != (v4 & v6) )
          {
            return result;
          }
        }
      }
    }
  }
  else if ( eventWhiteListV2.whitelist.table_.size_ )
  {
    v9 = v4 & (eventWhiteListV2.whitelist.table_.bucket_count_ - 1);
    next = eventWhiteListV2.whitelist.table_.buckets_[v9].next_;
    if ( next )
    {
      while ( 1 )
      {
        next = next->next_;
        if ( !next )
          break;
        v10 = next[1].next_;
        if ( v10 == (boost::unordered::detail::ptr_bucket::link_pointer)v4 )
        {
          if ( (const RBX::Reflection::EventDescriptor *)next[2].next_ == desc )
            return (RBX::Network::StrictNetworkFilter::WhiteListItem)next[3].next_;
        }
        else if ( ((eventWhiteListV2.whitelist.table_.bucket_count_ - 1) & (unsigned __int64)v10) != v9 )
        {
          return result;
        }
      }
    }
  }
  return result;
}


// Address: 0xf27850 | Name: _ZN3RBX7Network19StrictNetworkFilter10validateP0ERN5boost10shared_ptrINS_12PartInstanceEEEPNS_13ModelInstanceE
bool __fastcall RBX::Network::StrictNetworkFilter::validateP0(
        RBX::Network::StrictNetworkFilter *this,
        boost::shared_ptr<RBX::PartInstance> *p0,
        RBX::ModelInstance *playerRoot)
{
  boost::shared_ptr<RBX::PartInstance>::element_type *px; // rax

  px = p0->px;
  while ( px )
  {
    px = (boost::shared_ptr<RBX::PartInstance>::element_type *)px->parent;
    if ( px == (boost::shared_ptr<RBX::PartInstance>::element_type *)playerRoot )
      return 1;
  }
  return 0;
}


// Address: 0xf4ab40 | Name: _ZN3RBX7Network13ReplicatorJob13canSendPacketERN5boost10shared_ptrINS0_10ReplicatorEEE14PacketPriority
bool __fastcall RBX::Network::ReplicatorJob::canSendPacket(
        boost::shared_ptr<RBX::Network::Replicator> *safeReplicator,
        PacketPriority packetPriority)
{
  _DWORD *px; // rax

  px = safeReplicator->px;
  if ( !safeReplicator->px )
    return 0;
  if ( *((_QWORD *)px + 23) )
    return 1 - px[packetPriority + 1266] > 0;
  return 0;
}


// Address: 0xf4ab70 | Name: _ZN3RBX7Network10Replicator23getBufferCountAvailableEi14PacketPriority
int __fastcall RBX::Network::Replicator::getBufferCountAvailable(
        RBX::Network::Replicator *this,
        int bufferLimit,
        PacketPriority priority)
{
  int v3; // esi

  if ( !*((_QWORD *)this + 23) )
    return 0;
  v3 = bufferLimit - *((_DWORD *)this + (unsigned int)priority + 1266);
  if ( v3 < 0 )
    return 0;
  return v3;
}


// Address: 0xf4ab90 | Name: _ZNK3RBX7Network10Replicator14getRakNetStatsEv
const RakNet::RakNetStatistics *__fastcall RBX::Network::Replicator::getRakNetStats(
        const RBX::Network::Replicator *this)
{
  const RakNet::RakNetStatistics *result; // rax

  result = (const RakNet::RakNetStatistics *)((char *)this + 4912);
  if ( !*((_QWORD *)this + 23) )
    return 0;
  return result;
}


// Address: 0xf51e80 | Name: _ZN3RBX7Network10Replicator35incomingPacketsCountHeadWaitTimeSecERKNS_4TimeE
double __fastcall RBX::Network::Replicator::incomingPacketsCountHeadWaitTimeSec(
        RBX::Network::Replicator *this,
        const RBX::Time *timeNow)
{
  double *v2; // rdi
  __m128d v3; // xmm1
  double result; // xmm0_8

  if ( *((_QWORD *)this + 3740) || *((_QWORD *)this + 3742) )
    v2 = (double *)((char *)this + 29912);
  else
    v2 = (double *)((char *)this + 8536);
  v3.m128d_f64[0] = *v2;
  *(_QWORD *)&result = *(_OWORD *)&_mm_cmplt_sd((__m128d)0LL, v3) & COERCE_UNSIGNED_INT64(timeNow->sec - *v2);
  return result;
}


// Address: 0xf51ec0 | Name: _ZNK3RBX7Network10Replicator20incomingPacketsCountEv
size_t __fastcall RBX::Network::Replicator::incomingPacketsCount(const RBX::Network::Replicator *this)
{
  if ( *((_QWORD *)this + 3740) || *((_QWORD *)this + 3742) )
    return *((_QWORD *)this + 3737);
  else
    return *((_QWORD *)this + 1065);
}


// Address: 0xf9d130 | Name: _ZNK3RBX7Network10Replicator10ItemSender20getNumberOfBytesUsedEv
int __fastcall RBX::Network::Replicator::ItemSender::getNumberOfBytesUsed(
        const RBX::Network::Replicator::ItemSender *this)
{
  boost::shared_ptr<RBX::Network::NetworkStream>::element_type *px; // rdi

  px = this->bitStream.px;
  if ( px )
    return (*(int (__fastcall **)(boost::shared_ptr<RBX::Network::NetworkStream>::element_type *))(*(_QWORD *)px + 24LL))(px);
  else
    return 0;
}


// Address: 0xfd09a0 | Name: _ZN3RBX7Network6Server18getNetworkOwnerJobEv
RBX::Network::NetworkOwnerJob *__fastcall RBX::Network::Server::getNetworkOwnerJob(RBX::Network::Server *this)
{
  return (RBX::Network::NetworkOwnerJob *)*((_QWORD *)this + 363);
}


// Address: 0x10cefa0 | Name: _ZNK3RBX12GuiDrawImage28hasLoadedTextureProxyBaseRefEv
bool __fastcall RBX::GuiDrawImage::hasLoadedTextureProxyBaseRef(const RBX::GuiDrawImage *this)
{
  __int64 v1; // rdi

  v1 = *((_QWORD *)this + 6);
  return v1 && (*(bool (__fastcall **)(__int64))(*(_QWORD *)v1 + 24LL))(v1);
}


// Address: 0x11198d0 | Name: _ZNK3RBX9Scripting14ScriptDebugger8hasErrorEv
bool __fastcall RBX::Scripting::ScriptDebugger::hasError(const RBX::Scripting::ScriptDebugger *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 52);
  return v1 && *(_QWORD *)(v1 + 8) != 0;
}


// Address: 0x1121a10 | Name: _ZNK3RBX9Scripting14ScriptDebugger11isDebuggingEv
bool __fastcall RBX::Scripting::ScriptDebugger::isDebugging(const RBX::Scripting::ScriptDebugger *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 36);
  return v1 && *(_QWORD *)(v1 + 8) != 0;
}


// Address: 0x11e5530 | Name: _ZNK3RBX3Lua13WeakThreadRefeqERKS1_
bool __fastcall RBX::Lua::WeakThreadRef::operator==(
        const RBX::Lua::WeakThreadRef *this,
        const RBX::Lua::WeakThreadRef *other)
{
  RBX::Lua::detail::LiveThreadRef *px; // rax
  lua_State *L; // rax
  RBX::Lua::detail::LiveThreadRef *v4; // rcx
  lua_State *v5; // rcx

  px = this->liveThreadRef.px;
  if ( px )
    L = px->L;
  else
    L = 0;
  v4 = other->liveThreadRef.px;
  if ( v4 )
    v5 = v4->L;
  else
    v5 = 0;
  return L == v5;
}


// Address: 0x1283700 | Name: _ZNK3RBX14InstanceHandle5emptyEv
bool __fastcall RBX::InstanceHandle::empty(const RBX::InstanceHandle *this)
{
  return this->target.px == 0;
}


// Address: 0x130c1f0 | Name: _ZNK3RBX10RunService9smoothFpsEv
double __fastcall RBX::RunService::smoothFps(const RBX::RunService *this)
{
  boost::shared_ptr<RBX::PhysicsJob>::element_type *px; // rdi

  px = this->physicsJob.px;
  if ( px )
    return (*(double (__fastcall **)(boost::shared_ptr<RBX::PhysicsJob>::element_type *))(*(_QWORD *)px + 48LL))(px);
  else
    return 0.0;
}


// Address: 0x130c210 | Name: _ZNK3RBX10RunService12heartbeatFpsEv
double __fastcall RBX::RunService::heartbeatFps(const RBX::RunService *this)
{
  const RBX::TaskScheduler::Job *px; // rdi

  px = (const RBX::TaskScheduler::Job *)this->heartbeatTask.px;
  if ( px )
    return RBX::TaskScheduler::Job::averageStepsPerSecond(px);
  else
    return 0.0;
}


// Address: 0x130c230 | Name: _ZNK3RBX10RunService18smoothHeartbeatFpsEv
double __fastcall RBX::RunService::smoothHeartbeatFps(const RBX::RunService *this)
{
  const RBX::TaskScheduler::Job *px; // rdi

  px = (const RBX::TaskScheduler::Job *)this->heartbeatTask.px;
  if ( px )
    return RBX::TaskScheduler::Job::smoothAverageStepsPerSecond(px);
  else
    return 0.0;
}


// Address: 0x130c250 | Name: _ZNK3RBX10RunService18physicsAverageStepEv
double __fastcall RBX::RunService::physicsAverageStep(const RBX::RunService *this)
{
  const RBX::TaskScheduler::Job *px; // rdi

  px = (const RBX::TaskScheduler::Job *)this->physicsJob.px;
  if ( px )
    return RBX::TaskScheduler::Job::averageStepTime(px);
  else
    return 0.0;
}


// Address: 0x130c270 | Name: _ZNK3RBX10RunService20heartbeatAverageStepEv
double __fastcall RBX::RunService::heartbeatAverageStep(const RBX::RunService *this)
{
  const RBX::TaskScheduler::Job *px; // rdi

  px = (const RBX::TaskScheduler::Job *)this->heartbeatTask.px;
  if ( px )
    return RBX::TaskScheduler::Job::averageStepTime(px);
  else
    return 0.0;
}


// Address: 0x130c290 | Name: _ZNK3RBX10RunService18physicsCpuFractionEv
double __fastcall RBX::RunService::physicsCpuFraction(const RBX::RunService *this)
{
  const RBX::TaskScheduler::Job *px; // rdi

  px = (const RBX::TaskScheduler::Job *)this->physicsJob.px;
  if ( px )
    return RBX::TaskScheduler::Job::averageDutyCycle(px);
  else
    return 0.0;
}


// Address: 0x130c2b0 | Name: _ZNK3RBX10RunService20heartbeatCpuFractionEv
double __fastcall RBX::RunService::heartbeatCpuFraction(const RBX::RunService *this)
{
  const RBX::TaskScheduler::Job *px; // rdi

  px = (const RBX::TaskScheduler::Job *)this->heartbeatTask.px;
  if ( px )
    return RBX::TaskScheduler::Job::averageDutyCycle(px);
  else
    return 0.0;
}


// Address: 0x13136f0 | Name: _ZN3RBX11SimpleTimer7isValidEv
bool __fastcall RBX::SimpleTimer::isValid(RBX::SimpleTimer *this)
{
  return this->timerData.px != 0;
}


// Address: 0x14b2c80 | Name: _ZN3RBX20ChangeHistoryService20checkSettingWaypointEv
void __fastcall RBX::ChangeHistoryService::checkSettingWaypoint(RBX::ChangeHistoryService *this)
{
  ;
}


// Address: 0x1560f50 | Name: _ZNK3RBX9DataModel17getGameAvatarTypeEv
RBX::GameAvatarType __fastcall RBX::DataModel::getGameAvatarType(const RBX::DataModel *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 93);
  if ( v1 )
    return *(_DWORD *)(v1 + 156);
  else
    return RBX::GameAvatarType::PlayerChoice;
}


// Address: 0x1560f70 | Name: _ZN3RBX9DataModel17setGameAvatarTypeENS_14GameAvatarTypeE
void __fastcall RBX::DataModel::setGameAvatarType(RBX::DataModel *this, RBX::GameAvatarType value)
{
  RBX::StarterPlayerService *v2; // rdi

  v2 = (RBX::StarterPlayerService *)*((_QWORD *)this + 93);
  if ( v2 )
    RBX::StarterPlayerService::setGameSettingsAvatarType(v2, value);
}


// Address: 0x1560f90 | Name: _ZNK3RBX9DataModel19getR15CollisionTypeEv
RBX::R15CollisionType __fastcall RBX::DataModel::getR15CollisionType(const RBX::DataModel *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 93);
  if ( v1 )
    return *(_DWORD *)(v1 + 160);
  else
    return RBX::R15CollisionType::OuterBox;
}


// Address: 0x1560fb0 | Name: _ZN3RBX9DataModel19setR15CollisionTypeENS_16R15CollisionTypeE
void __fastcall RBX::DataModel::setR15CollisionType(RBX::DataModel *this, RBX::R15CollisionType value)
{
  RBX::StarterPlayerService *v2; // rdi

  v2 = (RBX::StarterPlayerService *)*((_QWORD *)this + 93);
  if ( v2 )
    RBX::StarterPlayerService::setGameSettingsR15CollisionType(v2, value);
}


// Address: 0x1576400 | Name: _ZN3RBX9DataModel20morpherTemplateApplyERKN5boost10shared_ptrINS_19HumanoidDescriptionEEE
void __fastcall RBX::DataModel::morpherTemplateApply(
        RBX::DataModel *this,
        const boost::shared_ptr<RBX::HumanoidDescription> *playerChoiceDescription)
{
  RBX::StarterPlayerService *v2; // rdi

  v2 = (RBX::StarterPlayerService *)*((_QWORD *)this + 93);
  if ( v2 )
    RBX::StarterPlayerService::gameSettingsMorpherTemplateApply(v2, playerChoiceDescription);
}


// Address: 0x1576420 | Name: _ZN3RBX9DataModel37setUpMorpherTemplateFromGameStartInfoERKN5boost10shared_ptrIKNS1_9unordered13unordered_mapINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_10Reflection7VariantENS1_4hashISB_EENS5_8equal_toISB_EENS9_INS5_4pairIKSB_SD_EEEEEEEE
void __fastcall RBX::DataModel::setUpMorpherTemplateFromGameStartInfo(
        RBX::DataModel *this,
        const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *tbl)
{
  RBX::StarterPlayerService *v2; // rdi

  v2 = (RBX::StarterPlayerService *)*((_QWORD *)this + 93);
  if ( v2 )
    RBX::StarterPlayerService::gameSettingsMorpherTemplateSetUpFromGameStartInfo(v2, tbl);
}


// Address: 0x1651240 | Name: _ZN3RBX4Game18getSuppressNavKeysEv
bool __fastcall RBX::Game::getSuppressNavKeys(RBX::Game *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 4);
  return v1 && *(_BYTE *)(v1 + 1472) != 0;
}


// Address: 0x16553c0 | Name: _ZN3RBX11hasChildrenEPNS_8InstanceE
bool __fastcall RBX::hasChildren(RBX::Instance *wInstance)
{
  _QWORD *px; // rax

  px = wInstance->children.object.px;
  return px && px[1] != *px;
}


// Address: 0x1706c40 | Name: _ZN3RBX10HammerTool13render3dAdornEPNS_5AdornE
void __fastcall RBX::HammerTool::render3dAdorn(RBX::HammerTool *this, RBX::Adorn *adorn)
{
  boost::shared_ptr<RBX::PartInstance>::element_type *px; // rdi

  px = this->hammerPart.px;
  if ( px )
    (*((void (__fastcall **)(boost::shared_ptr<RBX::PartInstance>::element_type *, RBX::Adorn *, __int64))px->_vptr$EventSource
     + 96))(
      px,
      adorn,
      1);
}


// Address: 0x1719c20 | Name: _ZNK3RBX9CloneTool13getCursorNameEv
RBX::CloneTool *__fastcall RBX::CloneTool::getCursorName(RBX::CloneTool *this, __int64 a2)
{
  bool v2; // zf

  v2 = *(_QWORD *)(a2 + 120) == 0;
  *(_OWORD *)&this->_vptr$Selectable = 0;
  *(_QWORD *)&this->indexAll = 0;
  if ( v2 )
  {
    LOBYTE(this->_vptr$Selectable) = 22;
    *(int (***)(void))((char *)&this->_vptr$Selectable + 1) = (int (**)(void))0x727543656E6F6C43LL;
    *(int *)((char *)&this->index2d + 1) = (int)&unk_726F73;
  }
  else
  {
    LOBYTE(this->_vptr$Selectable) = 30;
    strcpy((char *)&this->_vptr$Selectable + 1, "CloneOverCursor");
  }
  return this;
}


// Address: 0x192ee60 | Name: _ZNK3RBX13PartOperation16getTriangleCountEv
int __fastcall RBX::PartOperation::getTriangleCount(const RBX::PartOperation *this)
{
  __int64 v1; // rcx
  __int64 v2; // rax

  v1 = *((_QWORD *)this + 60);
  if ( v1 )
    return ((__int64)(*(_QWORD *)(v1 + 56) - *(_QWORD *)(v1 + 48)) >> 2) / 3uLL;
  else
    LODWORD(v2) = 0;
  return v2;
}


// Address: 0x1948b00 | Name: _ZNK3RBX6Player17getDataComplexityEv
int __fastcall RBX::Player::getDataComplexity(const RBX::Player *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 127);
  if ( v1 )
    return *(_DWORD *)(v1 + 24);
  else
    return 0;
}


// Address: 0x19e1260 | Name: _ZNK3RBX7Players11superSafeOnEv
bool __fastcall RBX::Players::superSafeOn(const RBX::Players *this)
{
  return *((_QWORD *)this + 44)
      && (*((bool (__fastcall **)(RBX::Reflection::TypedPropertyDescriptor<bool>::GetSet *))RBX::Player::prop_SuperSafeChat.getset.__ptr_.__value_->_vptr$GetSet
          + 4))(RBX::Player::prop_SuperSafeChat.getset.__ptr_.__value_);
}


// Address: 0x1b26220 | Name: _ZN3RBX14PackageService20packageHasPermissionEllNS_21PackagePermissionTypeE
bool __fastcall RBX::PackageService::packageHasPermission(
        RBX::PackageService *this,
        int64_t packageAssetId,
        int64_t packageVersionId,
        RBX::PackagePermissionType permissionType)
{
  RBX::PackagePermissionsManager *px; // rdi

  px = this->packagePermissionsManager.px;
  return px
      && RBX::PackagePermissionsManager::packageHasPermission(px, packageAssetId, packageVersionId, permissionType);
}


// Address: 0x1b83e40 | Name: _ZNK3RBX13TerrainRegion8isSmoothEv
bool __fastcall RBX::TerrainRegion::isSmooth(const RBX::TerrainRegion *this)
{
  return this->smoothGrid.px != 0;
}


// Address: 0x1be30b0 | Name: _ZN3RBX8PartTool13render3dAdornEPNS_5AdornE
void __fastcall RBX::PartTool::render3dAdorn(RBX::PartTool *this, RBX::Adorn *adorn)
{
  boost::shared_ptr<RBX::PartInstance>::element_type *px; // rdi

  px = this->partInstance.px;
  if ( px )
    (*((void (__fastcall **)(boost::shared_ptr<RBX::PartInstance>::element_type *, RBX::Adorn *, _QWORD))px->_vptr$EventSource
     + 96))(
      px,
      adorn,
      0);
}


// Address: 0x1c2b870 | Name: _ZNK3RBX10VideoFrame15getTimePositionEv
double __fastcall RBX::VideoFrame::getTimePosition(const RBX::VideoFrame *this)
{
  const RBX::VideoStream *v1; // rdi

  v1 = (const RBX::VideoStream *)*((_QWORD *)this + 184);
  if ( v1 && stru_2A1B9A0.value )
    return RBX::VideoStream::getTimePosition(v1);
  else
    return 0.0;
}


// Address: 0x1c2b960 | Name: _ZNK3RBX10VideoFrame13getTimeLengthEv
double __fastcall RBX::VideoFrame::getTimeLength(const RBX::VideoFrame *this)
{
  const RBX::VideoStream *v1; // rdi

  v1 = (const RBX::VideoStream *)*((_QWORD *)this + 184);
  if ( v1 && stru_2A1B9A0.value )
    return RBX::VideoStream::getTimeLength(v1);
  else
    return 0.0;
}


// Address: 0x1c3bcd0 | Name: _ZN3RBX18HttpRequestWrapper6cancelEv
void __fastcall RBX::HttpRequestWrapper::cancel(RBX::HttpRequestWrapper *this)
{
  RBX::HttpRequest *px; // rdi

  px = (RBX::HttpRequest *)this->httpRequest.px;
  if ( px )
    RBX::HttpRequest::abort(px);
}


// Address: 0x1c45b60 | Name: _ZNK3RBX9Workspace14getConstCameraEv
const RBX::Camera *__fastcall RBX::Workspace::getConstCamera(const RBX::Workspace *this)
{
  const RBX::Camera *result; // rax

  result = (const RBX::Camera *)*((_QWORD *)this + 111);
  if ( !result )
  {
    result = (const RBX::Camera *)*((_QWORD *)this + 113);
    if ( !result )
      return (const RBX::Camera *)*((_QWORD *)this + 115);
  }
  return result;
}


// Address: 0x1c45b90 | Name: _ZThn344_NK3RBX9Workspace14getConstCameraEv
void __fastcall `non-virtual thunk to'RBX::Workspace::getConstCamera(const RBX::Workspace *this)
{
  ;
}


// Address: 0x1cbf7f0 | Name: _ZNK3RBX18PathfindingService21getShowNavigationMeshEv
bool __fastcall RBX::PathfindingService::getShowNavigationMesh(const RBX::PathfindingService *this)
{
  _QWORD *px; // rax

  px = this->navigationService.px;
  return px && px[50] != 0;
}


// Address: 0x1cbf810 | Name: _ZN3RBX18PathfindingService21setShowNavigationMeshEbb
void __fastcall RBX::PathfindingService::setShowNavigationMesh(
        RBX::PathfindingService *this,
        bool state,
        bool forceGenerate)
{
  RBX::NavigationService *px; // rdi

  px = (RBX::NavigationService *)this->navigationService.px;
  if ( px )
    RBX::NavigationService::setShowNavigationMesh(px, state, forceGenerate);
}


// Address: 0x1cbf830 | Name: _ZN3RBX18PathfindingService18renderDebugNavMeshEPNS_5AdornERKNS_6CameraE
void __fastcall RBX::PathfindingService::renderDebugNavMesh(
        RBX::PathfindingService *this,
        RBX::Adorn *adorn,
        const RBX::Camera *camera)
{
  RBX::NavigationService *px; // rdi

  px = (RBX::NavigationService *)this->navigationService.px;
  if ( px )
    RBX::NavigationService::renderDebugNavMesh(px, adorn, camera);
}


// Address: 0x1d0f8c0 | Name: _ZN3RBX12MouseService16getMouseLocationEv
G3D::Vector2 __fastcall RBX::MouseService::getMouseLocation(RBX::MouseService *this)
{
  const RBX::InputObject *v1; // rdi

  v1 = (const RBX::InputObject *)*((_QWORD *)this + 19);
  if ( v1 )
    return RBX::InputObject::get2DPosition(v1);
  else
    return (G3D::Vector2)0x7F8000007F800000LL;
}


// Address: 0x1d0f8e0 | Name: _ZN3RBX12MouseService13getMouseDeltaEv
G3D::Vector2 __fastcall RBX::MouseService::getMouseDelta(RBX::MouseService *this)
{
  G3D::Vector2 *v1; // rax

  v1 = (G3D::Vector2 *)*((_QWORD *)this + 19);
  if ( v1 )
    return v1[19];
  else
    return 0;
}


// Address: 0x1d3f810 | Name: _ZNK3RBX8Instance19findFirstAncestorOfEPKS0_
const RBX::Instance **__fastcall RBX::Instance::findFirstAncestorOf(
        const RBX::Instance **a1,
        const RBX::Instance *this,
        const RBX::Instance *descendant)
{
  __int64 *px; // rax
  __int64 v4; // r8
  __int64 v5; // r9
  unsigned __int64 v7; // r9
  __int64 v8; // r10
  const RBX::Instance *v9; // rcx
  const RBX::Instance *v10; // rax
  __int64 v11; // rax

  px = (__int64 *)this->children.object.px;
  if ( px )
  {
    v4 = *px;
    v5 = px[1] - *px;
    if ( v5 )
    {
      v7 = v5 >> 4;
      v8 = 0;
      while ( 2 )
      {
        v9 = *(const RBX::Instance **)(v4 + 16 * v8);
        v10 = descendant;
        while ( v10 )
        {
          v10 = v10->parent;
          if ( v10 == v9 )
          {
            *a1 = v9;
            v11 = *(_QWORD *)(v4 + 16 * v8 + 8);
            a1[1] = (const RBX::Instance *)v11;
            if ( v11 )
              _InterlockedAdd((volatile signed __int32 *)(v11 + 8), 1u);
            return a1;
          }
        }
        if ( ++v8 < v7 )
          continue;
        break;
      }
    }
  }
  *(_OWORD *)a1 = 0;
  return a1;
}


// Address: 0x1f77790 | Name: _ZN3RBX5Adorn10setTextureEiRKN5boost10shared_ptrINS_16TextureProxyBaseEEEb
void __fastcall RBX::Adorn::setTexture(
        RBX::Adorn *this,
        int id,
        const RBX::TextureProxyBaseRef *texture,
        bool wrapTexture)
{
  if ( *((_QWORD *)this + 4) )
    RBX::GfxGui::setTexture(*((RBX::GfxGui **)this + 4), id, texture, wrapTexture);
  else
    (*(void (__fastcall **)(RBX::Adorn *, int, const RBX::TextureProxyBaseRef *, bool))(*(_QWORD *)this + 112LL))(
      this,
      id,
      texture,
      wrapTexture);
}


// Address: 0x1f777b0 | Name: _ZN3RBX5Adorn24addTextureLoadDependencyEv
void __fastcall RBX::Adorn::addTextureLoadDependency(RBX::Adorn *this)
{
  RBX::GfxGui *v1; // rdi

  v1 = (RBX::GfxGui *)*((_QWORD *)this + 4);
  if ( v1 )
    RBX::GfxGui::markDirty(v1);
}


// Address: 0x1f77a00 | Name: _ZN3RBX5Adorn11setGradientERKNSt3__110unique_ptrINS_8GradientENS1_14default_deleteIS3_EEEE
void __fastcall RBX::Adorn::setGradient(RBX::Adorn *this, const std::unique_ptr<RBX::Gradient> *gradient)
{
  RBX::GfxGui *v2; // rdi

  v2 = (RBX::GfxGui *)*((_QWORD *)this + 4);
  if ( v2 )
    RBX::GfxGui::setGradient(v2, gradient);
}


// Address: 0x1fa2d30 | Name: _ZNK3RBX8Graphics12TextureProxy15getOriginalSizeEv
G3D::Vector2 __fastcall RBX::Graphics::TextureProxy::getOriginalSize(const RBX::Graphics::TextureProxy *this)
{
  boost::shared_ptr<RBX::Graphics::TextureRef::Data>::element_type *px; // rax
  const __m128i *p_info; // rax
  __m128i v3; // xmm0

  px = this->texture.data.px;
  if ( px )
    p_info = (const __m128i *)&px->info;
  else
    p_info = (const __m128i *)&qword_2AB8338;
  v3 = _mm_loadl_epi64(p_info);
  return (G3D::Vector2)_mm_add_ps(
                         _mm_add_ps(
                           (__m128)_mm_or_si128(_mm_srli_epi32(v3, 0x10u), (__m128i)xmmword_3E4E70),
                           (__m128)xmmword_3E6000),
                         (__m128)_mm_or_si128(
                                   _mm_and_si128(_mm_load_si128((const __m128i *)&xmmword_3EB300), v3),
                                   (__m128i)xmmword_3E6F30)).m128_u64[0];
}


// Address: 0x1fa2d80 | Name: _ZNK3RBX8Graphics12TextureProxy8isLoadedEv
bool __fastcall RBX::Graphics::TextureProxy::isLoaded(const RBX::Graphics::TextureProxy *this)
{
  boost::shared_ptr<RBX::Graphics::TextureRef::Data>::element_type *px; // rax

  px = this->texture.data.px;
  return px && px->status == RBX::Graphics::TextureRef::Status::Status_Loaded;
}


// Address: 0x1fcc2c0 | Name: _ZN3RBX5Voxel9Voxelizer30occupancyFillTerrainSmoothSIMDERNS0_14OccupancyChunkERKNS_6Voxel23BoxE
void __fastcall RBX::Voxel::Voxelizer::occupancyFillTerrainSmoothSIMD(
        RBX::Voxel::Voxelizer *this,
        RBX::Voxel::OccupancyChunk *chunk,
        const RBX::Voxel2::Box *box)
{
  unsigned __int8 *v3; // rsi
  __int64 v4; // r8
  __m128i si128; // xmm0
  __m128i v6; // xmm8
  __m128i *v7; // rcx
  __int64 i; // r9
  __int64 v9; // rax
  boost::shared_ptr<RBX::Voxel2::Cell []>::element_type *px; // rdi
  __m128i v11; // xmm2
  __m128i v12; // xmm3
  __m128i v13; // xmm6
  __m128i v14; // xmm2
  __m128i v15; // xmm3
  __m128i v16; // xmm4
  __m128i v17; // xmm6
  __m128i v18; // xmm3
  __m128i v19; // xmm1
  __m128i v20; // xmm7
  __m128i v21; // xmm2
  __m128i v22; // xmm5
  __m128i v23; // xmm7

  if ( box->data.px )
  {
    v3 = &chunk->occupancy[2][0][0][16];
    v4 = 0;
    si128 = _mm_load_si128((const __m128i *)&xmmword_3E7F90);
    v6 = _mm_load_si128((const __m128i *)&xmmword_3E5B60);
    do
    {
      v7 = (__m128i *)v3;
      for ( i = 0; i != 32; ++i )
      {
        v9 = (int)i * box->sizeX + (int)v4 * box->sliceXZ;
        px = box->data.px;
        v11 = _mm_loadu_si128((const __m128i *)&px[v9]);
        v12 = _mm_loadu_si128((const __m128i *)&px[v9 + 8]);
        v13 = _mm_and_si128(
                _mm_cmpgt_epi8(_mm_packus_epi16(_mm_and_si128(v11, si128), _mm_and_si128(v12, si128)), v6),
                _mm_packus_epi16(_mm_srli_epi16(v11, 8u), _mm_srli_epi16(v12, 8u)));
        v14 = _mm_loadu_si128(v7 - 2048);
        v15 = _mm_adds_epu8(_mm_loadu_si128(v7 - 2049), v13);
        v16 = _mm_adds_epu8(_mm_loadu_si128(v7 - 1025), v13);
        v17 = _mm_adds_epu8(v13, _mm_loadu_si128(v7 - 1));
        v7[-2049] = v15;
        v7[-1025] = v16;
        v7[-1] = v17;
        v18 = _mm_loadu_si128((const __m128i *)&px[v9 + 16]);
        v19 = _mm_loadu_si128((const __m128i *)&px[v9 + 24]);
        v20 = _mm_and_si128(
                _mm_cmpgt_epi8(_mm_packus_epi16(_mm_and_si128(v18, si128), _mm_and_si128(v19, si128)), v6),
                _mm_packus_epi16(_mm_srli_epi16(v18, 8u), _mm_srli_epi16(v19, 8u)));
        v21 = _mm_adds_epu8(v14, v20);
        v22 = _mm_adds_epu8(_mm_loadu_si128(v7 - 1024), v20);
        v23 = _mm_adds_epu8(v20, _mm_loadu_si128(v7));
        v7[-2048] = v21;
        v7[-1024] = v22;
        *v7 = v23;
        v7 += 2;
      }
      ++v4;
      v3 += 1024;
    }
    while ( v4 != 16 );
  }
}


// Address: 0x20c6f00 | Name: _ZNK3RBX8Graphics12LightGridCPU17getWrapSafeOffsetEv
RBX::Vector3 __fastcall RBX::Graphics::LightGridCPU::getWrapSafeOffset(const RBX::Graphics::LightGridCPU *this)
{
  __m128 v1; // xmm0
  __m128 v2; // xmm2
  __int64 v3; // rax
  int v4; // r8d
  int v5; // r9d
  int v6; // r10d
  int v7; // edx
  unsigned __int64 v8; // rcx
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  v3 = *((_QWORD *)this + 21);
  if ( v3 && !*(_DWORD *)(v3 + 56) )
  {
    v4 = *((_DWORD *)this + 37);
    v5 = *((_DWORD *)this + 38);
    v6 = *((_DWORD *)this + 39);
    v8 = 0;
    v7 = 0;
  }
  else
  {
    v4 = *((_DWORD *)this + 37);
    v5 = *((_DWORD *)this + 38);
    v6 = *((_DWORD *)this + 39);
    v7 = (v6 % *((_DWORD *)this + 36) + *((_DWORD *)this + 36)) % *((_DWORD *)this + 36);
    v8 = ((unsigned __int64)(unsigned int)((v5 % *((_DWORD *)this + 35) + *((_DWORD *)this + 35))
                                         % *((_DWORD *)this + 35)) << 32)
       | (unsigned int)((v4 % *((_DWORD *)this + 34) + *((_DWORD *)this + 34)) % *((_DWORD *)this + 34));
  }
  v1.m128_f32[0] = (float)((float)((int)v8 - v4) * 32.0) * 4.0;
  v2.m128_f32[0] = (float)((float)(HIDWORD(v8) - v5) * 16.0) * 4.0;
  v1.m128_u64[0] = _mm_unpacklo_ps(v1, v2).m128_u64[0];
  result.z = (float)((float)(v7 - v6) * 32.0) * 4.0;
  result.x = v1.m128_f32[0];
  result.y = v1.m128_f32[1];
  return result;
}


// Address: 0x20c6fe0 | Name: _ZNK3RBX8Graphics12LightGridCPU20getWrappedChunkIndexERKNS_12Vector3int32E
RBX::Vector3int32 __fastcall RBX::Graphics::LightGridCPU::getWrappedChunkIndex(
        const RBX::Graphics::LightGridCPU *this,
        const RBX::Vector3int32 *index)
{
  __int64 v2; // rax
  unsigned int v3; // r8d
  __int64 v4; // rcx
  RBX::Vector3int32 result; // 0:rax.12

  v2 = *((_QWORD *)this + 21);
  if ( v2 && !*(_DWORD *)(v2 + 56) )
  {
    v3 = index->x - *((_DWORD *)this + 37);
    v4 = (unsigned int)(index->y - *((_DWORD *)this + 38));
    result.z = index->z - *((_DWORD *)this + 39);
  }
  else
  {
    v3 = (index->x % *((_DWORD *)this + 34) + *((_DWORD *)this + 34)) % *((_DWORD *)this + 34);
    v4 = (unsigned int)((index->y % *((_DWORD *)this + 35) + *((_DWORD *)this + 35)) % *((_DWORD *)this + 35));
    result.z = (index->z % *((_DWORD *)this + 36) + *((_DWORD *)this + 36)) % *((_DWORD *)this + 36);
  }
  *(_QWORD *)&result.x = (v4 << 32) | v3;
  return result;
}


// Address: 0x275d5b0 | Name: _ZN3RBX8Graphics8DeviceGL5getVREv
RBX::Graphics::DeviceVR *__fastcall RBX::Graphics::DeviceGL::getVR(RBX::Graphics::DeviceGL *this)
{
  RBX::Graphics::DeviceVR *result; // rax

  result = (RBX::Graphics::DeviceVR *)*((_QWORD *)this + 44);
  if ( !result )
    return 0;
  if ( !*((_BYTE *)this + 360) )
    return 0;
  return result;
}


