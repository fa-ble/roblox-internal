// Address: 0x260a1c0 | Name: _ZN5boost4asio6detail28reactive_socket_service_base8start_opERNS2_24base_implementation_typeEiPNS1_10reactor_opEbbb
void __fastcall boost::asio::detail::reactive_socket_service_base::start_op(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        int op_type,
        boost::asio::detail::reactor_op *op,
        bool is_continuation,
        bool is_non_blocking,
        char a7)
{
  const boost::system::error_category *v10; // rax
  const boost::system::error_category *v11; // rax
  const boost::system::error_category *v12; // rax
  boost::asio::detail::socket_type fd; // [rsp+14h] [rbp-44h]
  int fda; // [rsp+14h] [rbp-44h]
  int *v15; // [rsp+18h] [rbp-40h]
  int v16[13]; // [rsp+24h] [rbp-34h] BYREF

  if ( a7 )
    goto LABEL_2;
  if ( (impl->state_ & 3) == 0 )
  {
    if ( impl->socket_ == -1 )
    {
      v12 = boost::system::system_category();
      op->ec_.m_val = 9;
      op->ec_.m_cat = v12;
    }
    else
    {
      fd = impl->socket_;
      v15 = __errno_location();
      *v15 = 0;
      v16[0] = 1;
      fda = ioctl(fd, 0x5421u, v16);
      LODWORD(v15) = *v15;
      v10 = boost::system::system_category();
      op->ec_.m_val = (int)v15;
      op->ec_.m_cat = v10;
      if ( fda >= 0 )
      {
        v11 = boost::system::system_category();
        op->ec_.m_val = 0;
        op->ec_.m_cat = v11;
        impl->state_ |= 2u;
        goto LABEL_4;
      }
    }
LABEL_2:
    boost::asio::detail::task_io_service::post_immediate_completion(this->reactor_->io_service_, op, is_continuation);
    return;
  }
LABEL_4:
  boost::asio::detail::epoll_reactor::start_op(
    this->reactor_,
    op_type,
    impl->socket_,
    &impl->reactor_data_,
    op,
    is_continuation,
    (_BYTE)impl + 8);
}


// Address: 0x2624e30 | Name: _ZN5boost4asio6detail28reactive_socket_service_base7do_openERNS2_24base_implementation_typeEiiiRNS_6system10error_codeE
boost::system::error_code __fastcall boost::asio::detail::reactive_socket_service_base::do_open(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        int af_0,
        int type,
        int protocol,
        boost::system::error_code *ec)
{
  const boost::system::error_category *v7; // r12
  int v8; // ebx
  int *v12; // r14
  int v13; // ebp
  const boost::system::error_category *v14; // rax
  const boost::system::error_category *v15; // rax
  boost::asio::detail::epoll_reactor *reactor; // r14
  boost::asio::detail::epoll_reactor::descriptor_state *descriptor_state; // rax
  pthread_mutex_t *p_mutex; // rbx
  boost::asio::detail::epoll_reactor::per_descriptor_data reactor_data; // rax
  boost::asio::detail::epoll_reactor::per_descriptor_data v20; // rax
  int v21; // eax
  int v22; // edx
  boost::asio::detail::socket_ops::state_type v23; // cl
  boost::asio::detail::socket_ops::state_type state; // [rsp+Fh] [rbp-59h] BYREF
  boost::system::error_code event; // [rsp+10h] [rbp-58h] BYREF
  int v27; // [rsp+24h] [rbp-44h]
  int *v28; // [rsp+28h] [rbp-40h]
  boost::asio::detail::reactive_socket_service_base *v29; // [rsp+30h] [rbp-38h]
  boost::system::error_code result; // 0:eax.4,8:rdx.8

  if ( impl->socket_ == -1 )
  {
    v29 = this;
    v12 = __errno_location();
    *v12 = 0;
    v27 = type;
    v13 = socket(af_0, type, protocol);
    v28 = v12;
    v8 = *v12;
    v14 = boost::system::system_category();
    ec->m_val = v8;
    ec->m_cat = v14;
    if ( v13 < 0 )
    {
      if ( v13 == -1 )
      {
        v7 = v14;
        goto LABEL_14;
      }
    }
    else
    {
      v15 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v15;
    }
    reactor = v29->reactor_;
    descriptor_state = boost::asio::detail::epoll_reactor::allocate_descriptor_state(v29->reactor_);
    impl->reactor_data_ = descriptor_state;
    p_mutex = &descriptor_state->mutex_.mutex_;
    pthread_mutex_lock(&descriptor_state->mutex_.mutex_);
    impl->reactor_data_->reactor_ = reactor;
    reactor_data = impl->reactor_data_;
    reactor_data->descriptor_ = v13;
    reactor_data->shutdown_ = 0;
    pthread_mutex_unlock(p_mutex);
    event.m_val = -2147483621;
    v20 = impl->reactor_data_;
    v20->registered_events_ = -2147483621;
    *(_QWORD *)(&event.m_val + 1) = v20;
    v21 = epoll_ctl(reactor->epoll_fd_, 1, v13, (struct epoll_event *)&event);
    v22 = v27;
    if ( v21 && (v8 = *v28) != 0 )
    {
      v7 = boost::system::system_category();
      ec->m_val = v8;
      ec->m_cat = v7;
      event.m_val = 0;
      event.m_cat = boost::system::system_category();
      state = 0;
      boost::asio::detail::socket_ops::close(v13, &state, 1, &event);
    }
    else
    {
      impl->socket_ = v13;
      v23 = 16;
      if ( v22 != 1 )
        v23 = 32 * (v22 == 2);
      impl->state_ = v23;
      v7 = boost::system::system_category();
      ec->m_val = 0;
      ec->m_cat = v7;
      v8 = 0;
    }
  }
  else
  {
    if ( !(_BYTE)byte_2B114E0 && __cxa_guard_acquire(&byte_2B114E0) )
      __cxa_guard_release(&byte_2B114E0);
    ec->m_val = 1;
    v7 = (const boost::system::error_category *)off_2870A08;
    ec->m_cat = (const boost::system::error_category *)off_2870A08;
    v8 = 1;
  }
LABEL_14:
  result.m_val = v8;
  result.m_cat = v7;
  return result;
}


// Address: 0x2625650 | Name: _ZN5boost4asio6detail28reactive_socket_service_base16start_connect_opERNS2_24base_implementation_typeEPNS1_10reactor_opEbPK8sockaddrm
void __fastcall boost::asio::detail::reactive_socket_service_base::start_connect_op(
        boost::asio::detail::reactive_socket_service_base *this,
        boost::asio::detail::reactive_socket_service_base::base_implementation_type *impl,
        boost::asio::detail::reactor_op *op,
        bool is_continuation,
        const boost::asio::detail::socket_addr_type *addr,
        size_t addrlen)
{
  bool v6; // bl
  boost::asio::detail::socket_type v8; // ebp
  socklen_t v9; // r13d
  const struct sockaddr *v10; // r14
  int *v11; // rbx
  int v12; // ebp
  const boost::system::error_category *v13; // rax
  const boost::system::error_category *v14; // rax
  const boost::system::error_category **p_m_cat; // r14
  const boost::system::error_category *v16; // rax
  boost::asio::detail::reactive_socket_service_base *v17; // rbp
  boost::asio::detail::socket_type socket; // r14d
  int v19; // r13d
  int *v20; // rbp
  int v21; // r14d
  int v22; // ebx
  const boost::system::error_category *v23; // rax
  const boost::system::error_category *v24; // rax
  const boost::system::error_category *v25; // rax
  const boost::system::error_category *v26; // rax
  const boost::system::error_category *v27; // rax
  bool v28; // [rsp+Ch] [rbp-4Ch]
  int v30; // [rsp+1Ch] [rbp-3Ch] BYREF
  const boost::asio::detail::socket_addr_type *v31; // [rsp+20h] [rbp-38h]

  v6 = is_continuation;
  if ( (impl->state_ & 3) == 0 )
  {
    socket = impl->socket_;
    if ( impl->socket_ == -1 )
    {
      v27 = boost::system::system_category();
      op->ec_.m_val = 9;
      op->ec_.m_cat = v27;
    }
    else
    {
      v31 = addr;
      v19 = addrlen;
      v20 = __errno_location();
      *v20 = 0;
      v30 = 1;
      v21 = ioctl(socket, 0x5421u, &v30);
      v22 = *v20;
      v23 = boost::system::system_category();
      op->ec_.m_val = v22;
      op->ec_.m_cat = v23;
      if ( v21 >= 0 )
      {
        v24 = boost::system::system_category();
        op->ec_.m_val = 0;
        op->ec_.m_cat = v24;
        impl->state_ |= 2u;
        v6 = is_continuation;
        LODWORD(addrlen) = v19;
        addr = v31;
        goto LABEL_2;
      }
    }
    v6 = is_continuation;
    v17 = this;
    goto LABEL_20;
  }
LABEL_2:
  v8 = impl->socket_;
  if ( impl->socket_ == -1 )
  {
    v25 = boost::system::system_category();
    op->ec_.m_val = 9;
    p_m_cat = &op->ec_.m_cat;
    op->ec_.m_cat = v25;
    v17 = this;
  }
  else
  {
    v28 = v6;
    v9 = addrlen;
    v10 = addr;
    v11 = __errno_location();
    *v11 = 0;
    v12 = connect(v8, v10, v9);
    LODWORD(v11) = *v11;
    v13 = boost::system::system_category();
    op->ec_.m_val = (int)v11;
    op->ec_.m_cat = v13;
    v14 = boost::system::system_category();
    if ( !v12 )
    {
      op->ec_.m_val = 0;
      op->ec_.m_cat = v14;
      v17 = this;
      v6 = v28;
      goto LABEL_20;
    }
    p_m_cat = &op->ec_.m_cat;
    if ( op->ec_.m_cat == v14 && op->ec_.m_val == 11 )
    {
      v16 = boost::system::system_category();
      op->ec_.m_val = 105;
      op->ec_.m_cat = v16;
    }
    v17 = this;
    v6 = v28;
  }
  if ( *p_m_cat == boost::system::system_category() && op->ec_.m_val == 115
    || *p_m_cat == boost::system::system_category() && op->ec_.m_val == 11 )
  {
    v26 = boost::system::system_category();
    op->ec_.m_val = 0;
    op->ec_.m_cat = v26;
    boost::asio::detail::epoll_reactor::start_op(v17->reactor_, 1, impl->socket_, &impl->reactor_data_, op, v6, 0);
    return;
  }
LABEL_20:
  boost::asio::detail::task_io_service::post_immediate_completion(v17->reactor_->io_service_, op, v6);
}


