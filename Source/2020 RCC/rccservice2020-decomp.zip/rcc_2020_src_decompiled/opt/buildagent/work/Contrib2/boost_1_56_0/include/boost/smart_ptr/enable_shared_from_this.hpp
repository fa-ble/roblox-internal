// Address: 0xdaf760 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerI18ThumbnailGeneratorS6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<ThumbnailGenerator,ThumbnailGenerator>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<ThumbnailGenerator> *ppx,
        ThumbnailGenerator *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdb41d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20CSGDictionaryServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CSGDictionaryService,RBX::CSGDictionaryService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CSGDictionaryService> *ppx,
        RBX::CSGDictionaryService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdb46c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_33NonReplicatedCSGDictionaryServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::NonReplicatedCSGDictionaryService,RBX::NonReplicatedCSGDictionaryService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::NonReplicatedCSGDictionaryService> *ppx,
        RBX::NonReplicatedCSGDictionaryService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdccaf0 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail17shared_state_baseEE22_internal_accept_ownerINS1_12shared_stateINSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEEEESD_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::shared_state_base>::_internal_accept_owner<boost::detail::shared_state<std::string>,boost::detail::shared_state<std::string>>(
        const boost::enable_shared_from_this<boost::detail::shared_state_base> *this,
        const boost::shared_ptr<boost::detail::shared_state<std::string > > *ppx,
        boost::detail::shared_state<std::string > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdcf5e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13RCCMonitoringEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::RCCMonitoring>::_internal_accept_owner<RBX::RCCMonitoring,RBX::RCCMonitoring>(
        const boost::enable_shared_from_this<RBX::RCCMonitoring> *this,
        const boost::shared_ptr<RBX::RCCMonitoring> *ppx,
        RBX::RCCMonitoring *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdcfc00 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvPFvRKNSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEERKNS_10shared_ptrIN3RBX9DataModelEEElSG_RKNSH_IKNS_9unordered13unordered_mapISE_NSI_10Reflection7VariantENS_4hashISE_EENS8_8equal_toISE_EENSC_INS8_4pairISF_SQ_EEEEEEEENSI_5TimerILNSI_4Time12SampleMethodE0EEEENS6_5list6INS6_5valueISE_EENS1A_ISK_EENS1A_IlEES1B_NS1A_IS10_EENS1A_IS16_EEEEEEEEEEvPKNSH_IT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(std::string const&,boost::shared_ptr<RBX::DataModel> const&,long,std::string const&,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const> const&,RBX::Timer<(RBX::Time::SampleMethod)0>),boost::_bi::list6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const std::string &,const boost::shared_ptr<RBX::DataModel> &,long,const std::string &,const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > &,RBX::Timer<RBX::Time::Fast>),boost::_bi::list6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdd1a20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13ScriptContextES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ScriptContext,RBX::ScriptContext>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ScriptContext> *ppx,
        RBX::ScriptContext *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdd3d50 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_9function0IvEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::function0<void>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::function0<void> > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdd3f80 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_21TaskSchedulerSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TaskSchedulerSettings,RBX::TaskSchedulerSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TaskSchedulerSettings> *ppx,
        RBX::TaskSchedulerSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xdd41b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12GameSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GameSettings,RBX::GameSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GameSettings> *ppx,
        RBX::GameSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xde5d10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12TimerServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TimerService,RBX::TimerService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TimerService> *ppx,
        RBX::TimerService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe4e580 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15ContentProviderES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ContentProvider,RBX::ContentProvider>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ContentProvider> *ppx,
        RBX::ContentProvider *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe4ea70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19MeshContentProviderES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MeshContentProvider,RBX::MeshContentProvider>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MeshContentProvider> *ppx,
        RBX::MeshContentProvider *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe4ef60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_25SolidModelContentProviderES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SolidModelContentProvider,RBX::SolidModelContentProvider>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SolidModelContentProvider> *ppx,
        RBX::SolidModelContentProvider *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe50e10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12ModuleScriptES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ModuleScript,RBX::ModuleScript>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ModuleScript> *ppx,
        RBX::ModuleScript *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe51300 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11HttpServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::HttpService,RBX::HttpService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::HttpService> *ppx,
        RBX::HttpService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe517f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9SelectionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Selection,RBX::Selection>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Selection> *ppx,
        RBX::Selection *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe529e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8LightingES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Lighting,RBX::Lighting>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Lighting> *ppx,
        RBX::Lighting *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe52c10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_21ColorCorrectionEffectES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ColorCorrectionEffect,RBX::ColorCorrectionEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ColorCorrectionEffect> *ppx,
        RBX::ColorCorrectionEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xe52dc0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11BloomEffectES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BloomEffect,RBX::BloomEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BloomEffect> *ppx,
        RBX::BloomEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xeb6000 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network6ClientES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::Client,RBX::Network::Client>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::Client> *ppx,
        RBX::Network::Client *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xeb6240 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network6ServerES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::Server,RBX::Network::Server>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::Server> *ppx,
        RBX::Network::Server *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xeb6480 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_6PlayerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Player,RBX::Player>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Player> *ppx,
        RBX::Player *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xeb6780 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network29CheatHandlingServerReplicatorES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::CheatHandlingServerReplicator,RBX::Network::CheatHandlingServerReplicator>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::CheatHandlingServerReplicator> *ppx,
        RBX::Network::CheatHandlingServerReplicator *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xeb90b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15NetworkSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::NetworkSettings,RBX::NetworkSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::NetworkSettings> *ppx,
        RBX::NetworkSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xec2d40 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX8Security22ReplicatorCryptoSystemEE22_internal_accept_ownerIS3_NS2_29ReplicatorCryptoSystemOpenSSLEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Security::ReplicatorCryptoSystem>::_internal_accept_owner<RBX::Security::ReplicatorCryptoSystem,RBX::Security::ReplicatorCryptoSystemOpenSSL>(
        const boost::enable_shared_from_this<RBX::Security::ReplicatorCryptoSystem> *this,
        const boost::shared_ptr<RBX::Security::ReplicatorCryptoSystem> *ppx,
        RBX::Security::ReplicatorCryptoSystemOpenSSL *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xec3360 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7PlayersES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Players,RBX::Players>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Players> *ppx,
        RBX::Players *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xec36f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network16ClientReplicatorES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::ClientReplicator,RBX::Network::ClientReplicator>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::ClientReplicator> *ppx,
        RBX::Network::ClientReplicator *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xec3a40 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10RunServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RunService,RBX::RunService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RunService> *ppx,
        RBX::RunService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xed5ff0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats14TypedStatsItemIjEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::TypedStatsItem<unsigned int>,RBX::Stats::TypedStatsItem<unsigned int>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::TypedStatsItem<unsigned int> > *ppx,
        RBX::Stats::TypedStatsItem<unsigned int> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xed6170 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network16ClientReplicator15ClientStatsItemES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::ClientReplicator::ClientStatsItem,RBX::Network::ClientReplicator::ClientStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::ClientReplicator::ClientStatsItem> *ppx,
        RBX::Network::ClientReplicator::ClientStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xed6af0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network16ClientReplicator5GCJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::ClientReplicator::GCJob,RBX::Network::ClientReplicator::GCJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::ClientReplicator::GCJob> *ppx,
        RBX::Network::ClientReplicator::GCJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xede520 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network17ConcurrentRakPeer9PacketJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::ConcurrentRakPeer::PacketJob,RBX::Network::ConcurrentRakPeer::PacketJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::ConcurrentRakPeer::PacketJob> *ppx,
        RBX::Network::ConcurrentRakPeer::PacketJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xede6d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network17ConcurrentRakPeer14StatsUpdateJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::ConcurrentRakPeer::StatsUpdateJob,RBX::Network::ConcurrentRakPeer::StatsUpdateJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::ConcurrentRakPeer::StatsUpdateJob> *ppx,
        RBX::Network::ConcurrentRakPeer::StatsUpdateJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xefb700 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14CookiesServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CookiesService,RBX::CookiesService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CookiesService> *ppx,
        RBX::CookiesService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xefb930 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10GuiServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GuiService,RBX::GuiService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GuiService> *ppx,
        RBX::GuiService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xefbd00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5VisitES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Visit,RBX::Visit>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Visit> *ppx,
        RBX::Visit *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf02750 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16UserInputServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UserInputService,RBX::UserInputService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UserInputService> *ppx,
        RBX::UserInputService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf02e10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20ChangeHistoryServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ChangeHistoryService,RBX::ChangeHistoryService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ChangeHistoryService> *ppx,
        RBX::ChangeHistoryService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf031e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13InsertServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::InsertService,RBX::InsertService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::InsertService> *ppx,
        RBX::InsertService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf06050 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_6FolderES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Folder,RBX::Folder>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Folder> *ppx,
        RBX::Folder *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf06420 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_21CoreScriptSyncServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CoreScriptSyncService,RBX::CoreScriptSyncService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CoreScriptSyncService> *ppx,
        RBX::CoreScriptSyncService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf06c20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12CorePackagesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CorePackages,RBX::CorePackages>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CorePackages> *ppx,
        RBX::CorePackages *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf11e10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats12StatsServiceES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::StatsService,RBX::Stats::StatsService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::StatsService> *ppx,
        RBX::Stats::StatsService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf1e5c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network21NetworkPhysicsMegaJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::NetworkPhysicsMegaJob,RBX::Network::NetworkPhysicsMegaJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::NetworkPhysicsMegaJob> *ppx,
        RBX::Network::NetworkPhysicsMegaJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf1e770 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerIS3_NS1_7Network22NetworkSendDataMegaJobEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TaskScheduler::Job,RBX::Network::NetworkSendDataMegaJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::TaskScheduler::Job> *ppx,
        RBX::Network::NetworkSendDataMegaJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf1e920 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerIS3_NS1_7Network20ModelCompletenessJobEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TaskScheduler::Job,RBX::Network::ModelCompletenessJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::TaskScheduler::Job> *ppx,
        RBX::Network::ModelCompletenessJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf22750 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX7Network20PhysicsAssemblyCacheEE22_internal_accept_ownerIS3_S3_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Network::PhysicsAssemblyCache>::_internal_accept_owner<RBX::Network::PhysicsAssemblyCache,RBX::Network::PhysicsAssemblyCache>(
        const boost::enable_shared_from_this<RBX::Network::PhysicsAssemblyCache> *this,
        const boost::shared_ptr<RBX::Network::PhysicsAssemblyCache> *ppx,
        RBX::Network::PhysicsAssemblyCache *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf3c0e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network16PacketReceiveJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::PacketReceiveJob,RBX::Network::PacketReceiveJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::PacketReceiveJob> *ppx,
        RBX::Network::PacketReceiveJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf3cb70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network13PeerStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::PeerStatsItem,RBX::Network::PeerStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::PeerStatsItem> *ppx,
        RBX::Network::PeerStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf44ac0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network15PhysicsSenderS210TouchJobS2ES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::PhysicsSenderS2::TouchJobS2,RBX::Network::PhysicsSenderS2::TouchJobS2>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::PhysicsSenderS2::TouchJobS2> *ppx,
        RBX::Network::PhysicsSenderS2::TouchJobS2 *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf7cc30 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network10Replicator11SendDataJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::SendDataJob,RBX::Network::Replicator::SendDataJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::Replicator::SendDataJob> *ppx,
        RBX::Network::Replicator::SendDataJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf7cde0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network10Replicator14SendClusterJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::SendClusterJob,RBX::Network::Replicator::SendClusterJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::Replicator::SendClusterJob> *ppx,
        RBX::Network::Replicator::SendClusterJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf7cf90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network10Replicator17ProcessPacketsJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::ProcessPacketsJob,RBX::Network::Replicator::ProcessPacketsJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::Replicator::ProcessPacketsJob> *ppx,
        RBX::Network::Replicator::ProcessPacketsJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf7d140 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network10Replicator7PingJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::PingJob,RBX::Network::Replicator::PingJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::Replicator::PingJob> *ppx,
        RBX::Network::Replicator::PingJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf84e40 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network21DeserializePacketsJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::DeserializePacketsJob,RBX::Network::DeserializePacketsJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::DeserializePacketsJob> *ppx,
        RBX::Network::DeserializePacketsJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xf87530 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network6MarkerES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::Marker,RBX::Network::Marker>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::Marker> *ppx,
        RBX::Network::Marker *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfb6ac0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats14TypedStatsItemImEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::TypedStatsItem<unsigned long>,RBX::Stats::TypedStatsItem<unsigned long>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::TypedStatsItem<unsigned long> > *ppx,
        RBX::Stats::TypedStatsItem<unsigned long> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfb6f70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats14TypedStatsItemIbEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::TypedStatsItem<bool>,RBX::Stats::TypedStatsItem<bool>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::TypedStatsItem<bool> > *ppx,
        RBX::Stats::TypedStatsItem<bool> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfb7420 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats14TypedStatsItemIfEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::TypedStatsItem<float>,RBX::Stats::TypedStatsItem<float>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::TypedStatsItem<float> > *ppx,
        RBX::Stats::TypedStatsItem<float> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfb75a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network12RakStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::RakStatsItem,RBX::Network::RakStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::RakStatsItem> *ppx,
        RBX::Network::RakStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfb7a50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats14TypedStatsItemIdEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::TypedStatsItem<double>,RBX::Stats::TypedStatsItem<double>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::TypedStatsItem<double> > *ppx,
        RBX::Stats::TypedStatsItem<double> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfb7f00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats14TypedStatsItemIiEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::TypedStatsItem<int>,RBX::Stats::TypedStatsItem<int>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::TypedStatsItem<int> > *ppx,
        RBX::Stats::TypedStatsItem<int> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfd2b70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network16ServerReplicatorES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::ServerReplicator,RBX::Network::ServerReplicator>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::ServerReplicator> *ppx,
        RBX::Network::ServerReplicator *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfd5a90 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX8Security19AslrPmcSharedHasherEEEENS6_5list1INS6_5valueISC_EEEEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> > > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfd5de0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network18ClusterPacketCacheES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::ClusterPacketCache,RBX::Network::ClusterPacketCache>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::ClusterPacketCache> *ppx,
        RBX::Network::ClusterPacketCache *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfd5f90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network15NetworkOwnerJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::NetworkOwnerJob,RBX::Network::NetworkOwnerJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::NetworkOwnerJob> *ppx,
        RBX::Network::NetworkOwnerJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfd6140 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network22RomarkPhaseTrackingJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::RomarkPhaseTrackingJob,RBX::Network::RomarkPhaseTrackingJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::RomarkPhaseTrackingJob> *ppx,
        RBX::Network::RomarkPhaseTrackingJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfd67e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX8Security19AslrPmcSharedHasherEE22_internal_accept_ownerIS3_S3_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Security::AslrPmcSharedHasher>::_internal_accept_owner<RBX::Security::AslrPmcSharedHasher,RBX::Security::AslrPmcSharedHasher>(
        const boost::enable_shared_from_this<RBX::Security::AslrPmcSharedHasher> *this,
        const boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> *ppx,
        RBX::Security::AslrPmcSharedHasher *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfd6cd0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20StarterPlayerServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StarterPlayerService,RBX::StarterPlayerService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StarterPlayerService> *ppx,
        RBX::StarterPlayerService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfeb3a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network16ServerReplicator15ServerStatsItemES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::ServerReplicator::ServerStatsItem,RBX::Network::ServerReplicator::ServerStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::ServerReplicator::ServerStatsItem> *ppx,
        RBX::Network::ServerReplicator::ServerStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfed2a0 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX9DataModelEEENS8_INS9_7Network16ServerReplicatorEEEi14PacketPriorityiENS6_5list5INS6_5valueISB_EENSJ_ISE_EENSJ_IiEENSJ_ISF_EESM_EEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfee020 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15ReplicatedFirstES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ReplicatedFirst,RBX::ReplicatedFirst>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ReplicatedFirst> *ppx,
        RBX::ReplicatedFirst *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfee370 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape12SoundServiceES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::SoundService,RBX::Soundscape::SoundService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::SoundService> *ppx,
        RBX::Soundscape::SoundService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfee6c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15TeleportServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TeleportService,RBX::TeleportService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TeleportService> *ppx,
        RBX::TeleportService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfeebb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18StarterPackServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StarterPackService,RBX::StarterPackService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StarterPackService> *ppx,
        RBX::StarterPackService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfef0a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17StarterGuiServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StarterGuiService,RBX::StarterGuiService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StarterGuiService> *ppx,
        RBX::StarterGuiService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfef3f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13JointsServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::JointsService,RBX::JointsService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::JointsService> *ppx,
        RBX::JointsService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfef8e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5TeamsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Teams,RBX::Teams>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Teams> *ppx,
        RBX::Teams *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xfefdd0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11ChatServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ChatService,RBX::ChatService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ChatService> *ppx,
        RBX::ChatService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff0120 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19LocalizationServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LocalizationService,RBX::LocalizationService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LocalizationService> *ppx,
        RBX::LocalizationService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff0610 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13FriendServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FriendService,RBX::FriendService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FriendService> *ppx,
        RBX::FriendService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff0b00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18MarketplaceServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MarketplaceService,RBX::MarketplaceService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MarketplaceService> *ppx,
        RBX::MarketplaceService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff0ff0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12BadgeServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BadgeService,RBX::BadgeService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BadgeService> *ppx,
        RBX::BadgeService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff14e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17ReplicatedStorageES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ReplicatedStorage,RBX::ReplicatedStorage>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ReplicatedStorage> *ppx,
        RBX::ReplicatedStorage *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff19d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_23RobloxReplicatedStorageES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RobloxReplicatedStorage,RBX::RobloxReplicatedStorage>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RobloxReplicatedStorage> *ppx,
        RBX::RobloxReplicatedStorage *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff1ec0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11TestServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TestService,RBX::TestService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TestService> *ppx,
        RBX::TestService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff23b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13PointsServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PointsService,RBX::PointsService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PointsService> *ppx,
        RBX::PointsService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff28a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9AdServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::AdService,RBX::AdService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::AdService> *ppx,
        RBX::AdService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff2d90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13SocialServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SocialService,RBX::SocialService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SocialService> *ppx,
        RBX::SocialService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff3280 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19ServerScriptServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ServerScriptService,RBX::ServerScriptService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ServerScriptService> *ppx,
        RBX::ServerScriptService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff3770 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13ServerStorageES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ServerStorage,RBX::ServerStorage>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ServerStorage> *ppx,
        RBX::ServerStorage *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff3c60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16AnalyticsServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::AnalyticsService,RBX::AnalyticsService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::AnalyticsService> *ppx,
        RBX::AnalyticsService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff4150 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_21VersionControlServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::VersionControlService,RBX::VersionControlService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::VersionControlService> *ppx,
        RBX::VersionControlService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff4640 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10StudioDataES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StudioData,RBX::StudioData>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StudioData> *ppx,
        RBX::StudioData *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff4f50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10LogServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LogService,RBX::LogService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LogService> *ppx,
        RBX::LogService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff56c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network10Replicator12SendStatsJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::SendStatsJob,RBX::Network::Replicator::SendStatsJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::Replicator::SendStatsJob> *ppx,
        RBX::Network::Replicator::SendStatsJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xff6200 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network10Replicator9StreamJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::Replicator::StreamJob,RBX::Network::Replicator::StreamJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::Replicator::StreamJob> *ppx,
        RBX::Network::Replicator::StreamJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0xffa360 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_7Network17StreamingObserver9ResizeJobES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Network::StreamingObserver::ResizeJob,RBX::Network::StreamingObserver::ResizeJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Network::StreamingObserver::ResizeJob> *ppx,
        RBX::Network::StreamingObserver::ResizeJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1019f90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX8Security13AslrPmcServerEE22_internal_accept_ownerIS3_S3_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Security::AslrPmcServer>::_internal_accept_owner<RBX::Security::AslrPmcServer,RBX::Security::AslrPmcServer>(
        const boost::enable_shared_from_this<RBX::Security::AslrPmcServer> *this,
        const boost::shared_ptr<RBX::Security::AslrPmcServer> *ppx,
        RBX::Security::AslrPmcServer *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10295e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Network19GuidRegistryServiceES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Network::GuidRegistryService,RBX::Network::GuidRegistryService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Network::GuidRegistryService> *ppx,
        RBX::Network::GuidRegistryService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1032920 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvPFvNS_10shared_ptrIN3RBX8Security19AslrPmcSharedHasherEEENSt3__112basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEEmENS6_5list3INS6_5valueISC_EENSN_ISJ_EENSN_ImEEEEEEEEEEvPKNS8_IT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>>,boost::_bi::value<std::string>,boost::_bi::value<unsigned long>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> >,boost::_bi::value<std::string >,boost::_bi::value<unsigned long> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1036b20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14PackageServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PackageService,RBX::PackageService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PackageService> *ppx,
        RBX::PackageService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x103e3d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8AnimatorES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Animator,RBX::Animator>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Animator> *ppx,
        RBX::Animator *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1040bb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14AnimationTrackES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::AnimationTrack,RBX::AnimationTrack>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::AnimationTrack> *ppx,
        RBX::AnimationTrack *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1041980 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9AnimationES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Animation,RBX::Animation>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Animation> *ppx,
        RBX::Animation *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x104a8b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_24KeyframeSequenceProviderES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::KeyframeSequenceProvider,RBX::KeyframeSequenceProvider>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::KeyframeSequenceProvider> *ppx,
        RBX::KeyframeSequenceProvider *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x104b840 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19AnimationControllerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::AnimationController,RBX::AnimationController>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::AnimationController> *ppx,
        RBX::AnimationController *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x104d020 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8KeyframeES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Keyframe,RBX::Keyframe>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Keyframe> *ppx,
        RBX::Keyframe *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1051d70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16KeyframeSequenceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::KeyframeSequence,RBX::KeyframeSequence>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::KeyframeSequence> *ppx,
        RBX::KeyframeSequence *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10692b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14InventoryPagesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::InventoryPages,RBX::InventoryPages>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::InventoryPages> *ppx,
        RBX::InventoryPages *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x106c830 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4PoseES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Pose,RBX::Pose>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Pose> *ppx,
        RBX::Pose *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x106ddb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14KeyframeMarkerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::KeyframeMarker,RBX::KeyframeMarker>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::KeyframeMarker> *ppx,
        RBX::KeyframeMarker *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10b95b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7Motor6DES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Motor6D,RBX::Motor6D>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Motor6D> *ppx,
        RBX::Motor6D *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10baaa0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12NumericValueIdEES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::NumericValue<double>,RBX::NumericValue<double>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::NumericValue<double> > *ppx,
        RBX::NumericValue<double> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10bace0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8HumanoidES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Humanoid,RBX::Humanoid>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Humanoid> *ppx,
        RBX::Humanoid *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10c5550 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5ValueIbEES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Value<bool>,RBX::Value<bool>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Value<bool> > *ppx,
        RBX::Value<bool> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10c6360 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17FilteredSelectionINS1_12PartInstanceEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FilteredSelection<RBX::PartInstance>,RBX::FilteredSelection<RBX::PartInstance>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FilteredSelection<RBX::PartInstance> > *ppx,
        RBX::FilteredSelection<RBX::PartInstance> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10c67e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14StatusInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StatusInstance,RBX::StatusInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StatusInstance> *ppx,
        RBX::StatusInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10c6a10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17GameBasicSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GameBasicSettings,RBX::GameBasicSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GameBasicSettings> *ppx,
        RBX::GameBasicSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10c9e60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19HumanoidDescriptionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::HumanoidDescription,RBX::HumanoidDescription>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::HumanoidDescription> *ppx,
        RBX::HumanoidDescription *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10cc140 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5ValueIN3G3D7Vector3EEES9_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Value<G3D::Vector3>,RBX::Value<G3D::Vector3>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Value<G3D::Vector3> > *ppx,
        RBX::Value<G3D::Vector3> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10cc9d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11StringValueES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StringValue,RBX::StringValue>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StringValue> *ppx,
        RBX::StringValue *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x10fcfe0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17CollectionServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CollectionService,RBX::CollectionService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CollectionService> *ppx,
        RBX::CollectionService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1111fe0 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataIPFvvEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<void (*)(void)>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<void (*)()> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1125c50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9Scripting14ScriptDebuggerES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Scripting::ScriptDebugger,RBX::Scripting::ScriptDebugger>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Scripting::ScriptDebugger> *ppx,
        RBX::Scripting::ScriptDebugger *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1128350 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9Scripting13DebuggerWatchES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Scripting::DebuggerWatch,RBX::Scripting::DebuggerWatch>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Scripting::DebuggerWatch> *ppx,
        RBX::Scripting::DebuggerWatch *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x112acb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9Scripting18DebuggerBreakpointES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Scripting::DebuggerBreakpoint,RBX::Scripting::DebuggerBreakpoint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Scripting::DebuggerBreakpoint> *ppx,
        RBX::Scripting::DebuggerBreakpoint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1134a00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9Scripting15DebuggerManagerES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Scripting::DebuggerManager,RBX::Scripting::DebuggerManager>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Scripting::DebuggerManager> *ppx,
        RBX::Scripting::DebuggerManager *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x119ae00 | Name: _ZNK5boost23enable_shared_from_thisI24YieldFunctionStateObjectE22_internal_accept_ownerIS1_S1_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<YieldFunctionStateObject>::_internal_accept_owner<YieldFunctionStateObject,YieldFunctionStateObject>(
        const boost::enable_shared_from_this<YieldFunctionStateObject> *this,
        const boost::shared_ptr<YieldFunctionStateObject> *ppx,
        YieldFunctionStateObject *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11b13c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11LocalScriptES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LocalScript,RBX::LocalScript>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LocalScript> *ppx,
        RBX::LocalScript *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11b1600 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_6ScriptES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Script,RBX::Script>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Script> *ppx,
        RBX::Script *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11b2140 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20RuntimeScriptServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RuntimeScriptService,RBX::RuntimeScriptService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RuntimeScriptService> *ppx,
        RBX::RuntimeScriptService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11d24f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11LuaSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LuaSettings,RBX::LuaSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LuaSettings> *ppx,
        RBX::LuaSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11d2a50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_5GcJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::GcJob,RBX::GcJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::GcJob> *ppx,
        RBX::GcJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11d2fa0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_17WaitingScriptsJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::WaitingScriptsJob,RBX::WaitingScriptsJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::WaitingScriptsJob> *ppx,
        RBX::WaitingScriptsJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11d33e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_21ClearUnusedLuaRefsJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::ClearUnusedLuaRefsJob,RBX::ClearUnusedLuaRefsJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::ClearUnusedLuaRefsJob> *ppx,
        RBX::ClearUnusedLuaRefsJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11d79c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13ModelInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ModelInstance,RBX::ModelInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ModelInstance> *ppx,
        RBX::ModelInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11d8b80 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13ScriptContextEEENS6_5list1INS6_5valueIPSB_EEEEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext*>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext *> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11d8d00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10CoreScriptES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CoreScript,RBX::CoreScript>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CoreScript> *ppx,
        RBX::CoreScript *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11d9280 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13DebugSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DebugSettings,RBX::DebugSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DebugSettings> *ppx,
        RBX::DebugSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x11e4200 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12LuaStatsItemES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LuaStatsItem,RBX::LuaStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LuaStatsItem> *ppx,
        RBX::LuaStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1204f80 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail17shared_state_baseEE22_internal_accept_ownerINS1_12shared_stateIvEES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::shared_state_base>::_internal_accept_owner<boost::detail::shared_state<void>,boost::detail::shared_state<void>>(
        const boost::enable_shared_from_this<boost::detail::shared_state_base> *this,
        const boost::shared_ptr<boost::detail::shared_state<void> > *ppx,
        boost::detail::shared_state<void>_0 *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1213920 | Name: _ZN5boost23enable_shared_from_thisIN3RBX14AsyncHttpQueueEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::AsyncHttpQueue>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::AsyncHttpQueue> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x122af10 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX24CacheableContentProviderEEENS6_5list1INS6_5valueIPSB_EEEEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider*>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider *> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1259aa0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX21BatchThumbnailFetcherEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::BatchThumbnailFetcher>::_internal_accept_owner<RBX::BatchThumbnailFetcher,RBX::BatchThumbnailFetcher>(
        const boost::enable_shared_from_this<RBX::BatchThumbnailFetcher> *this,
        const boost::shared_ptr<RBX::BatchThumbnailFetcher> *ppx,
        RBX::BatchThumbnailFetcher *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x125c6e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX14AsyncHttpQueueEE22_internal_accept_ownerINS1_14AsyncHttpCacheINS1_13CachedContentEEES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::AsyncHttpQueue>::_internal_accept_owner<RBX::AsyncHttpCache<RBX::CachedContent>,RBX::AsyncHttpCache<RBX::CachedContent>>(
        const boost::enable_shared_from_this<RBX::AsyncHttpQueue> *this,
        const boost::shared_ptr<RBX::AsyncHttpCache<RBX::CachedContent> > *ppx,
        RBX::AsyncHttpCache<RBX::CachedContent> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1267350 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_21BatchThumbnailFetcher17ThumbnailFetchJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::BatchThumbnailFetcher::ThumbnailFetchJob,RBX::BatchThumbnailFetcher::ThumbnailFetchJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::BatchThumbnailFetcher::ThumbnailFetchJob> *ppx,
        RBX::BatchThumbnailFetcher::ThumbnailFetchJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x127f6a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9Analytics28GoogleAnalyticsConfigurationES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Analytics::GoogleAnalyticsConfiguration,RBX::Analytics::GoogleAnalyticsConfiguration>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Analytics::GoogleAnalyticsConfiguration> *ppx,
        RBX::Analytics::GoogleAnalyticsConfiguration *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1280840 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9Analytics8SettingsES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Analytics::Settings,RBX::Analytics::Settings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Analytics::Settings> *ppx,
        RBX::Analytics::Settings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x12947b0 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX17HttpClientHandlerEEENS6_5list1INS6_5valueIPSB_EEEEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler*>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler *> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1294ec0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12HttpResponseEE22_internal_accept_ownerINS1_16HttpResponseImplES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::HttpResponse>::_internal_accept_owner<RBX::HttpResponseImpl,RBX::HttpResponseImpl>(
        const boost::enable_shared_from_this<RBX::HttpResponse> *this,
        const boost::shared_ptr<RBX::HttpResponseImpl> *ppx,
        RBX::HttpResponseImpl *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1295450 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX10HttpClientEEENS6_5list1INS6_5valueIPSB_EEEEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient*>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient *> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x129f120 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX11HttpRequestEE22_internal_accept_ownerINS1_16HttpRequestMsxmlES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::HttpRequest>::_internal_accept_owner<RBX::HttpRequestMsxml,RBX::HttpRequestMsxml>(
        const boost::enable_shared_from_this<RBX::HttpRequest> *this,
        const boost::shared_ptr<RBX::HttpRequestMsxml> *ppx,
        RBX::HttpRequestMsxml *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x129f270 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX11HttpRequestEE22_internal_accept_ownerINS1_15HttpRequestCurlES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::HttpRequest>::_internal_accept_owner<RBX::HttpRequestCurl,RBX::HttpRequestCurl>(
        const boost::enable_shared_from_this<RBX::HttpRequest> *this,
        const boost::shared_ptr<RBX::HttpRequestCurl> *ppx,
        RBX::HttpRequestCurl *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x129ffa0 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail17shared_state_baseEE22_internal_accept_ownerINS1_12shared_stateINS_10shared_ptrIN3RBX12HttpResponseEEEEESA_EEvPKNS6_IT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::shared_state_base>::_internal_accept_owner<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>,boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>>(
        const boost::enable_shared_from_this<boost::detail::shared_state_base> *this,
        const boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > > *ppx,
        boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x12f2d00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX14AsyncHttpQueueEE22_internal_accept_ownerINS1_14AsyncHttpCacheINS1_13LuaWebService23CachedLuaWebServiceInfoEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::AsyncHttpQueue>::_internal_accept_owner<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>,RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo>>(
        const boost::enable_shared_from_this<RBX::AsyncHttpQueue> *this,
        const boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo> > *ppx,
        RBX::AsyncHttpCache<RBX::LuaWebService::CachedLuaWebServiceInfo> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x12f5f90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX14AsyncHttpQueueEE22_internal_accept_ownerINS1_14AsyncHttpCacheINS1_13LuaWebService26CachedRawLuaWebServiceInfoEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::AsyncHttpQueue>::_internal_accept_owner<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>,RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo>>(
        const boost::enable_shared_from_this<RBX::AsyncHttpQueue> *this,
        const boost::shared_ptr<RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo> > *ppx,
        RBX::AsyncHttpCache<RBX::LuaWebService::CachedRawLuaWebServiceInfo> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13107b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_10PhysicsJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::PhysicsJob,RBX::PhysicsJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::PhysicsJob> *ppx,
        RBX::PhysicsJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1310960 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_13HeartbeatTaskES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::HeartbeatTask,RBX::HeartbeatTask>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::HeartbeatTask> *ppx,
        RBX::HeartbeatTask *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1313d00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_14TimerTickerJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TimerTickerJob,RBX::TimerTickerJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::TimerTickerJob> *ppx,
        RBX::TimerTickerJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x131acf0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape12SoundChannelES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::SoundChannel,RBX::Soundscape::SoundChannel>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::SoundChannel> *ppx,
        RBX::Soundscape::SoundChannel *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x131d9e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Soundscape19FMODPlaybackChannelEE22_internal_accept_ownerIS3_S3_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannel>::_internal_accept_owner<RBX::Soundscape::FMODPlaybackChannel,RBX::Soundscape::FMODPlaybackChannel>(
        const boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannel> *this,
        const boost::shared_ptr<RBX::Soundscape::FMODPlaybackChannel> *ppx,
        RBX::Soundscape::FMODPlaybackChannel *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1321b80 | Name: _ZN5boost23enable_shared_from_thisIN3RBX10Soundscape19FMODPlaybackChannelEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannel>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannel> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1322d50 | Name: _ZN5boost23enable_shared_from_thisIN3RBX10Soundscape24FMODPlaybackChannelGroupEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannelGroup>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannelGroup> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x132da00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape15EchoSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::EchoSoundEffect,RBX::Soundscape::EchoSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::EchoSoundEffect> *ppx,
        RBX::Soundscape::EchoSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x132dcb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape17FlangeSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::FlangeSoundEffect,RBX::Soundscape::FlangeSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::FlangeSoundEffect> *ppx,
        RBX::Soundscape::FlangeSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x132df50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape21DistortionSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::DistortionSoundEffect,RBX::Soundscape::DistortionSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::DistortionSoundEffect> *ppx,
        RBX::Soundscape::DistortionSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x132e1f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape21PitchShiftSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::PitchShiftSoundEffect,RBX::Soundscape::PitchShiftSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::PitchShiftSoundEffect> *ppx,
        RBX::Soundscape::PitchShiftSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x132e4a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape17ChorusSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::ChorusSoundEffect,RBX::Soundscape::ChorusSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::ChorusSoundEffect> *ppx,
        RBX::Soundscape::ChorusSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x132e750 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape18TremoloSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::TremoloSoundEffect,RBX::Soundscape::TremoloSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::TremoloSoundEffect> *ppx,
        RBX::Soundscape::TremoloSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x132ea00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape17ReverbSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::ReverbSoundEffect,RBX::Soundscape::ReverbSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::ReverbSoundEffect> *ppx,
        RBX::Soundscape::ReverbSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x132ecb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape20EqualizerSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::EqualizerSoundEffect,RBX::Soundscape::EqualizerSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::EqualizerSoundEffect> *ppx,
        RBX::Soundscape::EqualizerSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x132ef80 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape21CompressorSoundEffectES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::CompressorSoundEffect,RBX::Soundscape::CompressorSoundEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::CompressorSoundEffect> *ppx,
        RBX::Soundscape::CompressorSoundEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1331550 | Name: _ZN5boost23enable_shared_from_thisIN3RBX10Soundscape15FMODPlaybackDSPEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackDSP>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackDSP> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x13322a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape10SoundGroupES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::SoundGroup,RBX::Soundscape::SoundGroup>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::SoundGroup> *ppx,
        RBX::Soundscape::SoundGroup *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13447a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10Soundscape21SoundServiceStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Soundscape::SoundServiceStatsItem,RBX::Soundscape::SoundServiceStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Soundscape::SoundServiceStatsItem> *ppx,
        RBX::Soundscape::SoundServiceStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1344d60 | Name: _ZN5boost23enable_shared_from_thisIN3RBX10Soundscape26NonBlockingFmodSoundLoaderEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::NonBlockingFmodSoundLoader>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::Soundscape::NonBlockingFmodSoundLoader> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1344fb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Soundscape26NonBlockingFmodSoundLoaderEE22_internal_accept_ownerIS3_S3_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::NonBlockingFmodSoundLoader>::_internal_accept_owner<RBX::Soundscape::NonBlockingFmodSoundLoader,RBX::Soundscape::NonBlockingFmodSoundLoader>(
        const boost::enable_shared_from_this<RBX::Soundscape::NonBlockingFmodSoundLoader> *this,
        const boost::shared_ptr<RBX::Soundscape::NonBlockingFmodSoundLoader> *ppx,
        RBX::Soundscape::NonBlockingFmodSoundLoader *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1347cf0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Soundscape24FMODPlaybackChannelGroupEE22_internal_accept_ownerIS3_S3_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannelGroup>::_internal_accept_owner<RBX::Soundscape::FMODPlaybackChannelGroup,RBX::Soundscape::FMODPlaybackChannelGroup>(
        const boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackChannelGroup> *this,
        const boost::shared_ptr<RBX::Soundscape::FMODPlaybackChannelGroup> *ppx,
        RBX::Soundscape::FMODPlaybackChannelGroup *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13482e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_10Soundscape8SoundJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::Soundscape::SoundJob,RBX::Soundscape::SoundJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::Soundscape::SoundJob> *ppx,
        RBX::Soundscape::SoundJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x134a270 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Soundscape15FMODPlaybackDSPEE22_internal_accept_ownerIS3_S3_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackDSP>::_internal_accept_owner<RBX::Soundscape::FMODPlaybackDSP,RBX::Soundscape::FMODPlaybackDSP>(
        const boost::enable_shared_from_this<RBX::Soundscape::FMODPlaybackDSP> *this,
        const boost::shared_ptr<RBX::Soundscape::FMODPlaybackDSP> *ppx,
        RBX::Soundscape::FMODPlaybackDSP *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x134bf30 | Name: _ZN5boost23enable_shared_from_thisIN3RBX10Soundscape5SoundEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::Sound>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::Soundscape::Sound> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x134bf60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Soundscape5SoundEE22_internal_accept_ownerIS3_S3_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Soundscape::Sound>::_internal_accept_owner<RBX::Soundscape::Sound,RBX::Soundscape::Sound>(
        const boost::enable_shared_from_this<RBX::Soundscape::Sound> *this,
        const boost::shared_ptr<RBX::Soundscape::Sound> *ppx,
        RBX::Soundscape::Sound *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1352f20 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvPFvPKcNS_10shared_ptrIN3RBX14BaseThreadPool8PoolDataEEENSC_14ShutdownPolicyEENS6_5list3INS6_5valueIS9_EENSJ_ISE_EENSJ_ISF_EEEEEEEEEEvPKNSA_IT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData>>,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const char *,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> >,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x135c690 | Name: _ZN5boost23enable_shared_from_thisIN3RBX11VideoStreamEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::VideoStream>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::VideoStream> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x135d2d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX9WebSocketEE22_internal_accept_ownerINS1_13WebSocketNullES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::WebSocket>::_internal_accept_owner<RBX::WebSocketNull,RBX::WebSocketNull>(
        const boost::enable_shared_from_this<RBX::WebSocket> *this,
        const boost::shared_ptr<RBX::WebSocketNull> *ppx,
        RBX::WebSocketNull *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1361400 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX8WsClientEEENS6_5list1INS6_5valueIPSB_EEEEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient*>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient *> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1370b30 | Name: _ZN5boost23enable_shared_from_thisIN3RBX18BatchAssetApiStateEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::BatchAssetApiState>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::BatchAssetApiState> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1371de0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX18BatchAssetApiStateEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::BatchAssetApiState>::_internal_accept_owner<RBX::BatchAssetApiState,RBX::BatchAssetApiState>(
        const boost::enable_shared_from_this<RBX::BatchAssetApiState> *this,
        const boost::shared_ptr<RBX::BatchAssetApiState> *ppx,
        RBX::BatchAssetApiState *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13ce5d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10AttachmentES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Attachment,RBX::Attachment>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Attachment> *ppx,
        RBX::Attachment *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13d6ad0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints14WeldConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::WeldConstraint,RBX::Constraints::WeldConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::WeldConstraint> *ppx,
        RBX::Constraints::WeldConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13e8460 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12AccoutrementES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Accoutrement,RBX::Accoutrement>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Accoutrement> *ppx,
        RBX::Accoutrement *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13e86a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_3HatES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Hat,RBX::Hat>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Hat> *ppx,
        RBX::Hat *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13e88e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9AccessoryES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Accessory,RBX::Accessory>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Accessory> *ppx,
        RBX::Accessory *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13f2a70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_12AdvArrowToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::AdvArrowTool,RBX::AdvArrowTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::AdvArrowTool> *ppx,
        RBX::AdvArrowTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13f3760 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17FilteredSelectionINS1_10PVInstanceEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FilteredSelection<RBX::PVInstance>,RBX::FilteredSelection<RBX::PVInstance>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FilteredSelection<RBX::PVInstance> > *ppx,
        RBX::FilteredSelection<RBX::PVInstance> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13f39a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_21AttachmentDraggerToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::AttachmentDraggerTool,RBX::AttachmentDraggerTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::AttachmentDraggerTool> *ppx,
        RBX::AttachmentDraggerTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13f46e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17FilteredSelectionINS1_8InstanceEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FilteredSelection<RBX::Instance>,RBX::FilteredSelection<RBX::Instance>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FilteredSelection<RBX::Instance> > *ppx,
        RBX::FilteredSelection<RBX::Instance> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13f47e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_16BoxSelectCommandES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::BoxSelectCommand,RBX::BoxSelectCommand>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::BoxSelectCommand> *ppx,
        RBX::BoxSelectCommand *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13f5810 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_14AdvLuaDragToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::AdvLuaDragTool,RBX::AdvLuaDragTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::AdvLuaDragTool> *ppx,
        RBX::AdvLuaDragTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x13f6a70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13AdvLuaDraggerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::AdvLuaDragger,RBX::AdvLuaDragger>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::AdvLuaDragger> *ppx,
        RBX::AdvLuaDragger *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1400960 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12PartInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PartInstance,RBX::PartInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PartInstance> *ppx,
        RBX::PartInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x140f620 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints21NoCollisionConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::NoCollisionConstraint,RBX::Constraints::NoCollisionConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::NoCollisionConstraint> *ppx,
        RBX::Constraints::NoCollisionConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14138e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_14AttachmentToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::AttachmentTool,RBX::AttachmentTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::AttachmentTool> *ppx,
        RBX::AttachmentTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1416770 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_19AnalyticsServiceJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::AnalyticsServiceJob,RBX::AnalyticsServiceJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::AnalyticsServiceJob> *ppx,
        RBX::AnalyticsServiceJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1417080 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX21AnalyticsProviderBaseEE22_internal_accept_ownerINS1_24AnalyticsProviderPlayFabES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::AnalyticsProviderBase>::_internal_accept_owner<RBX::AnalyticsProviderPlayFab,RBX::AnalyticsProviderPlayFab>(
        const boost::enable_shared_from_this<RBX::AnalyticsProviderBase> *this,
        const boost::shared_ptr<RBX::AnalyticsProviderPlayFab> *ppx,
        RBX::AnalyticsProviderPlayFab *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::AnalyticsProviderBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1436e10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10ArcHandlesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ArcHandles,RBX::ArcHandles>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ArcHandles> *ppx,
        RBX::ArcHandles *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x145a3d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13LuaWebServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LuaWebService,RBX::LuaWebService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LuaWebService> *ppx,
        RBX::LuaWebService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x145e7f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13StandardPagesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StandardPages,RBX::StandardPages>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StandardPages> *ppx,
        RBX::StandardPages *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1482540 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8BackpackES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Backpack,RBX::Backpack>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Backpack> *ppx,
        RBX::Backpack *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1499500 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13BindableEventES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BindableEvent,RBX::BindableEvent>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BindableEvent> *ppx,
        RBX::BindableEvent *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14998e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16BindableFunctionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BindableFunction,RBX::BindableFunction>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BindableFunction> *ppx,
        RBX::BindableFunction *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14ab0f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_6CameraES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Camera,RBX::Camera>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Camera> *ppx,
        RBX::Camera *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14ad8e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17ControllerServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ControllerService,RBX::ControllerService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ControllerService> *ppx,
        RBX::ControllerService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14adc30 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12MouseServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MouseService,RBX::MouseService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MouseService> *ppx,
        RBX::MouseService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14b96d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerI22ChangeHistoryStatsItemS6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<ChangeHistoryStatsItem,ChangeHistoryStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<ChangeHistoryStatsItem> *ppx,
        ChangeHistoryStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14c2ff0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10BodyColorsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BodyColors,RBX::BodyColors>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BodyColors> *ppx,
        RBX::BodyColors *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14c3230 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12ShirtGraphicES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ShirtGraphic,RBX::ShirtGraphic>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ShirtGraphic> *ppx,
        RBX::ShirtGraphic *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14c3490 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5ShirtES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Shirt,RBX::Shirt>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Shirt> *ppx,
        RBX::Shirt *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14c36f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5PantsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Pants,RBX::Pants>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Pants> *ppx,
        RBX::Pants *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x14c3930 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4SkinES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Skin,RBX::Skin>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Skin> *ppx,
        RBX::Skin *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1510c60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX11TextScraperEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TextScraper>::_internal_accept_owner<RBX::TextScraper,RBX::TextScraper>(
        const boost::enable_shared_from_this<RBX::TextScraper> *this,
        const boost::shared_ptr<RBX::TextScraper> *ppx,
        RBX::TextScraper *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1511bb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17LocalizationTableES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LocalizationTable,RBX::LocalizationTable>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LocalizationTable> *ppx,
        RBX::LocalizationTable *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1511f00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14CoreGuiServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CoreGuiService,RBX::CoreGuiService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CoreGuiService> *ppx,
        RBX::CoreGuiService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15135c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_49PlayerLocaleLocalizationServiceTranslatorInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PlayerLocaleLocalizationServiceTranslatorInstance,RBX::PlayerLocaleLocalizationServiceTranslatorInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PlayerLocaleLocalizationServiceTranslatorInstance> *ppx,
        RBX::PlayerLocaleLocalizationServiceTranslatorInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1535080 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_35SingleLocaleTableTranslatorInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SingleLocaleTableTranslatorInstance,RBX::SingleLocaleTableTranslatorInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SingleLocaleTableTranslatorInstance> *ppx,
        RBX::SingleLocaleTableTranslatorInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x153a880 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13ClickDetectorES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ClickDetector,RBX::ClickDetector>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ClickDetector> *ppx,
        RBX::ClickDetector *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1552840 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19CustomEventReceiverES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CustomEventReceiver,RBX::CustomEventReceiver>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CustomEventReceiver> *ppx,
        RBX::CustomEventReceiver *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15544d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11CustomEventES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CustomEvent,RBX::CustomEvent>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CustomEvent> *ppx,
        RBX::CustomEvent *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1557790 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_21CustomParticleEmitterES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CustomParticleEmitter,RBX::CustomParticleEmitter>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CustomParticleEmitter> *ppx,
        RBX::CustomParticleEmitter *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x159d1f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_9DataModel10GenericJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::DataModel::GenericJob,RBX::DataModel::GenericJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::DataModel::GenericJob> *ppx,
        RBX::DataModel::GenericJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x159d540 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9DataModelES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DataModel,RBX::DataModel>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DataModel> *ppx,
        RBX::DataModel *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *v5; // rax
  boost::detail::sp_counted_base *v6; // rbx
  boost::detail::sp_counted_base *v7; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)((char *)py + 136);
    if ( !py )
      v5 = 0;
    v6 = ppx->pn.pi_;
    if ( v6 )
      _InterlockedAdd(&v6->use_count_, 1u);
    this->weak_this_.px = v5;
    v7 = this->weak_this_.pn.pi_;
    if ( v6 != v7 )
    {
      if ( v6 )
      {
        _InterlockedAdd(&v6->weak_count_, 1u);
        v7 = this->weak_this_.pn.pi_;
      }
      if ( v7 && !_InterlockedSub(&v7->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      this->weak_this_.pn.pi_ = v6;
    }
    if ( v6 && !_InterlockedSub(&v6->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 2))(v6);
      if ( !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    }
  }
}


// Address: 0x159e7f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9WorkspaceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Workspace,RBX::Workspace>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Workspace> *ppx,
        RBX::Workspace *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x159e940 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX7GuiItemEE22_internal_accept_ownerINS1_7GuiRootES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::GuiRoot,RBX::GuiRoot>(
        const boost::enable_shared_from_this<RBX::GuiItem> *this,
        const boost::shared_ptr<RBX::GuiRoot> *ppx,
        RBX::GuiRoot *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x159ef90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19NotificationServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::NotificationService,RBX::NotificationService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::NotificationService> *ppx,
        RBX::NotificationService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x159f1c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17HttpRbxApiServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::HttpRbxApiService,RBX::HttpRbxApiService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::HttpRbxApiService> *ppx,
        RBX::HttpRbxApiService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x159f590 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12TweenServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TweenService,RBX::TweenService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TweenService> *ppx,
        RBX::TweenService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x159f7c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11TextServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TextService,RBX::TextService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TextService> *ppx,
        RBX::TextService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x159fe80 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14PhysicsServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PhysicsService,RBX::PhysicsService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PhysicsService> *ppx,
        RBX::PhysicsService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a0250 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15GeometryServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GeometryService,RBX::GeometryService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GeometryService> *ppx,
        RBX::GeometryService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a0620 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15GamePassServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GamePassService,RBX::GamePassService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GamePassService> *ppx,
        RBX::GamePassService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a09f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13DebrisServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DebrisService,RBX::DebrisService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DebrisService> *ppx,
        RBX::DebrisService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a0c20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9VRServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::VRService,RBX::VRService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::VRService> *ppx,
        RBX::VRService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a0ff0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20ContextActionServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ContextActionService,RBX::ContextActionService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ContextActionService> *ppx,
        RBX::ContextActionService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a1470 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13ScriptServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ScriptService,RBX::ScriptService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ScriptService> *ppx,
        RBX::ScriptService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a1840 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12AssetServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::AssetService,RBX::AssetService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::AssetService> *ppx,
        RBX::AssetService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a1c10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17TouchInputServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TouchInputService,RBX::TouchInputService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TouchInputService> *ppx,
        RBX::TouchInputService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a1fe0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14BrowserServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BrowserService,RBX::BrowserService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BrowserService> *ppx,
        RBX::BrowserService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a23b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17AppStorageServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::AppStorageService,RBX::AppStorageService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::AppStorageService> *ppx,
        RBX::AppStorageService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a2500 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX14GameConfigurerEE22_internal_accept_ownerINS1_20CorescriptConfigurerES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::GameConfigurer>::_internal_accept_owner<RBX::CorescriptConfigurer,RBX::CorescriptConfigurer>(
        const boost::enable_shared_from_this<RBX::GameConfigurer> *this,
        const boost::shared_ptr<RBX::CorescriptConfigurer> *ppx,
        RBX::CorescriptConfigurer *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::GameConfigurer>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a4c00 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail17shared_state_baseEE22_internal_accept_ownerINS1_12shared_stateINS_10shared_ptrINSt3__16vectorINS6_INS8_INS6_IN3RBX8InstanceEEENS7_9allocatorISB_EEEEEENSC_ISF_EEEEEEEESJ_EEvPKNS6_IT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::shared_state_base>::_internal_accept_owner<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>,boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>>(
        const boost::enable_shared_from_this<boost::detail::shared_state_base> *this,
        const boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > > *ppx,
        boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15a58e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14GamepadServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GamepadService,RBX::GamepadService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GamepadService> *ppx,
        RBX::GamepadService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15cbc80 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11InputObjectES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::InputObject,RBX::InputObject>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::InputObject> *ppx,
        RBX::InputObject *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15cf450 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12LocalStorageEE22_internal_accept_ownerINS1_10AppStorageES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::LocalStorage>::_internal_accept_owner<RBX::AppStorage,RBX::AppStorage>(
        const boost::enable_shared_from_this<RBX::LocalStorage> *this,
        const boost::shared_ptr<RBX::AppStorage> *ppx,
        RBX::AppStorage *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15d21f0 | Name: _ZN5boost23enable_shared_from_thisIN3RBX7GuiItemEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::GuiItem>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::GuiItem> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x15dd520 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16DataStoreServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DataStoreService,RBX::DataStoreService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DataStoreService> *ppx,
        RBX::DataStoreService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15ddd40 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_12DataStoreJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::DataStoreJob,RBX::DataStoreJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::DataStoreJob> *ppx,
        RBX::DataStoreJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15ddee0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX18RequestDataInQueueEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::RequestDataInQueue>::_internal_accept_owner<RBX::RequestDataInQueue,RBX::RequestDataInQueue>(
        const boost::enable_shared_from_this<RBX::RequestDataInQueue> *this,
        const boost::shared_ptr<RBX::RequestDataInQueue> *ppx,
        RBX::RequestDataInQueue *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15de060 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9DataStoreES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DataStore,RBX::DataStore>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DataStore> *ppx,
        RBX::DataStore *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x15de570 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16OrderedDataStoreES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::OrderedDataStore,RBX::OrderedDataStore>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::OrderedDataStore> *ppx,
        RBX::OrderedDataStore *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1613700 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14DataStorePagesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DataStorePages,RBX::DataStorePages>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DataStorePages> *ppx,
        RBX::DataStorePages *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x161bf60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5DecalES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Decal,RBX::Decal>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Decal> *ppx,
        RBX::Decal *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x161c1a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12DecalTextureES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DecalTexture,RBX::DecalTexture>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DecalTexture> *ppx,
        RBX::DecalTexture *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x161ff50 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX27DynamicFastVariableReloaderEEENS6_5list1INS6_5valueIPSB_EEEEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader*>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader *> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1623940 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8FileMeshES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FileMesh,RBX::FileMesh>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FileMesh> *ppx,
        RBX::FileMesh *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16280c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9FloorWireES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FloorWire,RBX::FloorWire>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FloorWire> *ppx,
        RBX::FloorWire *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x162ccb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16FlyweightServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FlyweightService,RBX::FlyweightService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FlyweightService> *ppx,
        RBX::FlyweightService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x162f9b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5ValueINS1_12BinaryStringEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Value<RBX::BinaryString>,RBX::Value<RBX::BinaryString>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Value<RBX::BinaryString> > *ppx,
        RBX::Value<RBX::BinaryString> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1630800 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10ForceFieldES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ForceField,RBX::ForceField>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ForceField> *ppx,
        RBX::ForceField *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1651f10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15PhysicsSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PhysicsSettings,RBX::PhysicsSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PhysicsSettings> *ppx,
        RBX::PhysicsSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1652920 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX14GameConfigurerEE22_internal_accept_ownerINS1_16PlayerConfigurerES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::GameConfigurer>::_internal_accept_owner<RBX::PlayerConfigurer,RBX::PlayerConfigurer>(
        const boost::enable_shared_from_this<RBX::GameConfigurer> *this,
        const boost::shared_ptr<RBX::PlayerConfigurer> *ppx,
        RBX::PlayerConfigurer *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::GameConfigurer>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x165af10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17FilteredSelectionINS1_10AttachmentEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FilteredSelection<RBX::Attachment>,RBX::FilteredSelection<RBX::Attachment>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FilteredSelection<RBX::Attachment> > *ppx,
        RBX::FilteredSelection<RBX::Attachment> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x165ba50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17FilteredSelectionINS1_11Constraints10ConstraintEEES9_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FilteredSelection<RBX::Constraints::Constraint>,RBX::FilteredSelection<RBX::Constraints::Constraint>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FilteredSelection<RBX::Constraints::Constraint> > *ppx,
        RBX::FilteredSelection<RBX::Constraints::Constraint> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x165c590 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17FilteredSelectionINS1_11Constraints14WeldConstraintEEES9_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FilteredSelection<RBX::Constraints::WeldConstraint>,RBX::FilteredSelection<RBX::Constraints::WeldConstraint>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FilteredSelection<RBX::Constraints::WeldConstraint> > *ppx,
        RBX::FilteredSelection<RBX::Constraints::WeldConstraint> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16655b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4WeldES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Weld,RBX::Weld>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Weld> *ppx,
        RBX::Weld *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16ef350 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_12AdvScaleToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::AdvScaleTool,RBX::AdvScaleTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::AdvScaleTool> *ppx,
        RBX::AdvScaleTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16f1460 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints13RodConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::RodConstraint,RBX::Constraints::RodConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::RodConstraint> *ppx,
        RBX::Constraints::RodConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16f4260 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints14RopeConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::RopeConstraint,RBX::Constraints::RopeConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::RopeConstraint> *ppx,
        RBX::Constraints::RopeConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16f8720 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints16SpringConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::SpringConstraint,RBX::Constraints::SpringConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::SpringConstraint> *ppx,
        RBX::Constraints::SpringConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16fe430 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4HoleES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Hole,RBX::Hole>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Hole> *ppx,
        RBX::Hole *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16fe670 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12MotorFeatureES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MotorFeature,RBX::MotorFeature>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MotorFeature> *ppx,
        RBX::MotorFeature *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x16fee30 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13VelocityMotorES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::VelocityMotor,RBX::VelocityMotor>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::VelocityMotor> *ppx,
        RBX::VelocityMotor *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1701a50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_18MoveResizeJoinToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::MoveResizeJoinTool,RBX::MoveResizeJoinTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::MoveResizeJoinTool> *ppx,
        RBX::MoveResizeJoinTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17020a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_16AdvTranslateToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::AdvTranslateTool,RBX::AdvTranslateTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::AdvTranslateTool> *ppx,
        RBX::AdvTranslateTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17023f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_13AdvRotateToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::AdvRotateTool,RBX::AdvRotateTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::AdvRotateTool> *ppx,
        RBX::AdvRotateTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17029e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_8FlatToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::FlatTool,RBX::FlatTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::FlatTool> *ppx,
        RBX::FlatTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1702d20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_8GlueToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::GlueTool,RBX::GlueTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::GlueTool> *ppx,
        RBX::GlueTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1703060 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_8WeldToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::WeldTool,RBX::WeldTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::WeldTool> *ppx,
        RBX::WeldTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17033a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_9StudsToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::StudsTool,RBX::StudsTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::StudsTool> *ppx,
        RBX::StudsTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17036e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_9InletToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::InletTool,RBX::InletTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::InletTool> *ppx,
        RBX::InletTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1703a20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_13UniversalToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::UniversalTool,RBX::UniversalTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::UniversalTool> *ppx,
        RBX::UniversalTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1703d60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_9HingeToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::HingeTool,RBX::HingeTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::HingeTool> *ppx,
        RBX::HingeTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17040a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_14RightMotorToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::RightMotorTool,RBX::RightMotorTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::RightMotorTool> *ppx,
        RBX::RightMotorTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17043e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_13LeftMotorToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::LeftMotorTool,RBX::LeftMotorTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::LeftMotorTool> *ppx,
        RBX::LeftMotorTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1704720 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_18OscillateMotorToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::OscillateMotorTool,RBX::OscillateMotorTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::OscillateMotorTool> *ppx,
        RBX::OscillateMotorTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1704a60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_20SmoothNoOutlinesToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::SmoothNoOutlinesTool,RBX::SmoothNoOutlinesTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::SmoothNoOutlinesTool> *ppx,
        RBX::SmoothNoOutlinesTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1704db0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_10AnchorToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::AnchorTool,RBX::AnchorTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::AnchorTool> *ppx,
        RBX::AnchorTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17050f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_8LockToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::LockTool,RBX::LockTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::LockTool> *ppx,
        RBX::LockTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1705430 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_8FillToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::FillTool,RBX::FillTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::FillTool> *ppx,
        RBX::FillTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1705770 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_12MaterialToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::MaterialTool,RBX::MaterialTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::MaterialTool> *ppx,
        RBX::MaterialTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1705ab0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_11DropperToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::DropperTool,RBX::DropperTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::DropperTool> *ppx,
        RBX::DropperTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1705de0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_8GameToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::GameTool,RBX::GameTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::GameTool> *ppx,
        RBX::GameTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1706110 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_8GrabToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::GrabTool,RBX::GrabTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::GrabTool> *ppx,
        RBX::GrabTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1706440 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_9CloneToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::CloneTool,RBX::CloneTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::CloneTool> *ppx,
        RBX::CloneTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1706770 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_10HammerToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::HammerTool,RBX::HammerTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::HammerTool> *ppx,
        RBX::HammerTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1706ec0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9ExplosionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Explosion,RBX::Explosion>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Explosion> *ppx,
        RBX::Explosion *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1710b90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_12PartDragToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::PartDragTool,RBX::PartDragTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::PartDragTool> *ppx,
        RBX::PartDragTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1715b50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_11LuaDragToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::LuaDragTool,RBX::LuaDragTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::LuaDragTool> *ppx,
        RBX::LuaDragTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1716770 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10LuaDraggerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LuaDragger,RBX::LuaDragger>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LuaDragger> *ppx,
        RBX::LuaDragger *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1736c30 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_22GlobalAdvancedSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GlobalAdvancedSettings,RBX::GlobalAdvancedSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GlobalAdvancedSettings> *ppx,
        RBX::GlobalAdvancedSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1736e50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19GlobalBasicSettingsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GlobalBasicSettings,RBX::GlobalBasicSettings>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GlobalBasicSettings> *ppx,
        RBX::GlobalBasicSettings *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x174b630 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12GroupServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GroupService,RBX::GroupService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GroupService> *ppx,
        RBX::GroupService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1786c60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5FrameES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Frame,RBX::Frame>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Frame> *ppx,
        RBX::Frame *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1786db0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX7GuiItemEE22_internal_accept_ownerINS1_13RelativePanelES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::RelativePanel,RBX::RelativePanel>(
        const boost::enable_shared_from_this<RBX::GuiItem> *this,
        const boost::shared_ptr<RBX::RelativePanel> *ppx,
        RBX::RelativePanel *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1786f00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX7GuiItemEE22_internal_accept_ownerINS1_11TextDisplayES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::TextDisplay,RBX::TextDisplay>(
        const boost::enable_shared_from_this<RBX::GuiItem> *this,
        const boost::shared_ptr<RBX::TextDisplay> *ppx,
        RBX::TextDisplay *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1787050 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX7GuiItemEE22_internal_accept_ownerINS1_15EquationDisplayES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::GuiItem>::_internal_accept_owner<RBX::EquationDisplay,RBX::EquationDisplay>(
        const boost::enable_shared_from_this<RBX::GuiItem> *this,
        const boost::shared_ptr<RBX::EquationDisplay> *ppx,
        RBX::EquationDisplay *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17bd600 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20ExtrudedPartInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ExtrudedPartInstance,RBX::ExtrudedPartInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ExtrudedPartInstance> *ppx,
        RBX::ExtrudedPartInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17da640 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10ImageLabelES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ImageLabel,RBX::ImageLabel>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ImageLabel> *ppx,
        RBX::ImageLabel *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17e6b80 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10DialogRootES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DialogRoot,RBX::DialogRoot>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DialogRoot> *ppx,
        RBX::DialogRoot *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17ea0e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12DialogChoiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DialogChoice,RBX::DialogChoice>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DialogChoice> *ppx,
        RBX::DialogChoice *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17fd6e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8BodyGyroES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BodyGyro,RBX::BodyGyro>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BodyGyro> *ppx,
        RBX::BodyGyro *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17fd9c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9BodyForceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BodyForce,RBX::BodyForce>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BodyForce> *ppx,
        RBX::BodyForce *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17fdca0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10BodyThrustES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BodyThrust,RBX::BodyThrust>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BodyThrust> *ppx,
        RBX::BodyThrust *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17fdfd0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12BodyPositionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BodyPosition,RBX::BodyPosition>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BodyPosition> *ppx,
        RBX::BodyPosition *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17fe2d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12BodyVelocityES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BodyVelocity,RBX::BodyVelocity>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BodyVelocity> *ppx,
        RBX::BodyVelocity *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17fe5d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19BodyAngularVelocityES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BodyAngularVelocity,RBX::BodyAngularVelocity>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BodyAngularVelocity> *ppx,
        RBX::BodyAngularVelocity *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x17fe810 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_6RocketES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Rocket,RBX::Rocket>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Rocket> *ppx,
        RBX::Rocket *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1806c70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18BoxHandleAdornmentES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BoxHandleAdornment,RBX::BoxHandleAdornment>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BoxHandleAdornment> *ppx,
        RBX::BoxHandleAdornment *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1806f10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19ConeHandleAdornmentES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ConeHandleAdornment,RBX::ConeHandleAdornment>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ConeHandleAdornment> *ppx,
        RBX::ConeHandleAdornment *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18071b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_23CylinderHandleAdornmentES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CylinderHandleAdornment,RBX::CylinderHandleAdornment>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CylinderHandleAdornment> *ppx,
        RBX::CylinderHandleAdornment *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1807450 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_21SphereHandleAdornmentES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SphereHandleAdornment,RBX::SphereHandleAdornment>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SphereHandleAdornment> *ppx,
        RBX::SphereHandleAdornment *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18076f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19LineHandleAdornmentES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::LineHandleAdornment,RBX::LineHandleAdornment>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::LineHandleAdornment> *ppx,
        RBX::LineHandleAdornment *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1807930 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20ImageHandleAdornmentES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ImageHandleAdornment,RBX::ImageHandleAdornment>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ImageHandleAdornment> *ppx,
        RBX::ImageHandleAdornment *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x180bc10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7HandlesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Handles,RBX::Handles>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Handles> *ppx,
        RBX::Handles *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1812540 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11StarterGearES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StarterGear,RBX::StarterGear>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StarterGear> *ppx,
        RBX::StarterGear *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1812780 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9HopperBinES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::HopperBin,RBX::HopperBin>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::HopperBin> *ppx,
        RBX::HopperBin *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1813730 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_18ScriptMouseCommandES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::ScriptMouseCommand,RBX::ScriptMouseCommand>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::ScriptMouseCommand> *ppx,
        RBX::ScriptMouseCommand *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1828570 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18HttpRequestWrapperES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::HttpRequestWrapper,RBX::HttpRequestWrapper>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::HttpRequestWrapper> *ppx,
        RBX::HttpRequestWrapper *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x183e7d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_13HttpRbxApiJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::HttpRbxApiJob,RBX::HttpRbxApiJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::HttpRbxApiJob> *ppx,
        RBX::HttpRbxApiJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1843c70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14GuiImageButtonES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GuiImageButton,RBX::GuiImageButton>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GuiImageButton> *ppx,
        RBX::GuiImageButton *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18494f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13ViewportFrameES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ViewportFrame,RBX::ViewportFrame>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ViewportFrame> *ppx,
        RBX::ViewportFrame *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18638f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4GlueES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Glue,RBX::Glue>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Glue> *ppx,
        RBX::Glue *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1863b30 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5MotorES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Motor,RBX::Motor>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Motor> *ppx,
        RBX::Motor *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1863d90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_6RotateES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Rotate,RBX::Rotate>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Rotate> *ppx,
        RBX::Rotate *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1863fd0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7RotatePES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RotateP,RBX::RotateP>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RotateP> *ppx,
        RBX::RotateP *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1864210 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7RotateVES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RotateV,RBX::RotateV>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RotateV> *ppx,
        RBX::RotateV *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1864450 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4SnapES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Snap,RBX::Snap>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Snap> *ppx,
        RBX::Snap *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18646b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10ManualWeldES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ManualWeld,RBX::ManualWeld>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ManualWeld> *ppx,
        RBX::ManualWeld *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18648f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10ManualGlueES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ManualGlue,RBX::ManualGlue>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ManualGlue> *ppx,
        RBX::ManualGlue *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18e7f80 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19MegaClusterInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MegaClusterInstance,RBX::MegaClusterInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MegaClusterInstance> *ppx,
        RBX::MegaClusterInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18eeeb0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13TerrainRegionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TerrainRegion,RBX::TerrainRegion>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TerrainRegion> *ppx,
        RBX::TerrainRegion *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18f6330 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8MeshPartES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MeshPart,RBX::MeshPart>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MeshPart> *ppx,
        RBX::MeshPart *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18f8540 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4HintES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Hint,RBX::Hint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Hint> *ppx,
        RBX::Hint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x18f87f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7MessageES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Message,RBX::Message>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Message> *ppx,
        RBX::Message *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x192a740 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16TouchTransmitterES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TouchTransmitter,RBX::TouchTransmitter>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TouchTransmitter> *ppx,
        RBX::TouchTransmitter *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1934de0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13PartOperationES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PartOperation,RBX::PartOperation>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PartOperation> *ppx,
        RBX::PartOperation *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1935020 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14UnionOperationES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UnionOperation,RBX::UnionOperation>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UnionOperation> *ppx,
        RBX::UnionOperation *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1935260 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15NegateOperationES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::NegateOperation,RBX::NegateOperation>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::NegateOperation> *ppx,
        RBX::NegateOperation *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x19387f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats25PerformanceStatsChildItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::PerformanceStatsChildItem,RBX::Stats::PerformanceStatsChildItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::PerformanceStatsChildItem> *ppx,
        RBX::Stats::PerformanceStatsChildItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1938970 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats24UntrackedMemoryStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::UntrackedMemoryStatsItem,RBX::Stats::UntrackedMemoryStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::UntrackedMemoryStatsItem> *ppx,
        RBX::Stats::UntrackedMemoryStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1938af0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats30MemoryTrackerCategoryStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::MemoryTrackerCategoryStatsItem,RBX::Stats::MemoryTrackerCategoryStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::MemoryTrackerCategoryStatsItem> *ppx,
        RBX::Stats::MemoryTrackerCategoryStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1938c70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats19CoreMemoryStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::CoreMemoryStatsItem,RBX::Stats::CoreMemoryStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::CoreMemoryStatsItem> *ppx,
        RBX::Stats::CoreMemoryStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1938df0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats20PlaceMemoryStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::PlaceMemoryStatsItem,RBX::Stats::PlaceMemoryStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::PlaceMemoryStatsItem> *ppx,
        RBX::Stats::PlaceMemoryStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1938f70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats21DeveloperTagStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::DeveloperTagStatsItem,RBX::Stats::DeveloperTagStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::DeveloperTagStatsItem> *ppx,
        RBX::Stats::DeveloperTagStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1947d80 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17BasicPartInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BasicPartInstance,RBX::BasicPartInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BasicPartInstance> *ppx,
        RBX::BasicPartInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x197e410 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14SpawnerServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SpawnerService,RBX::SpawnerService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SpawnerService> *ppx,
        RBX::SpawnerService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x197e730 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9PlayerGuiES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PlayerGui,RBX::PlayerGui>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PlayerGui> *ppx,
        RBX::PlayerGui *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x197e8b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13PlayerScriptsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PlayerScripts,RBX::PlayerScripts>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PlayerScripts> *ppx,
        RBX::PlayerScripts *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x197ede0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11PlayerMouseES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PlayerMouse,RBX::PlayerMouse>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PlayerMouse> *ppx,
        RBX::PlayerMouse *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x19a46c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11EmotesPagesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::EmotesPages,RBX::EmotesPages>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::EmotesPages> *ppx,
        RBX::EmotesPages *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x19bcc90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9ScreenGuiES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ScreenGui,RBX::ScreenGui>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ScreenGui> *ppx,
        RBX::ScreenGui *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x19bce10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9TextLabelES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TextLabel,RBX::TextLabel>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TextLabel> *ppx,
        RBX::TextLabel *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x19c1c60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12BillboardGuiES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BillboardGui,RBX::BillboardGui>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BillboardGui> *ppx,
        RBX::BillboardGui *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a08c70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11FriendPagesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FriendPages,RBX::FriendPages>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FriendPages> *ppx,
        RBX::FriendPages *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a21410 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20StarterPlayerScriptsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StarterPlayerScripts,RBX::StarterPlayerScripts>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StarterPlayerScripts> *ppx,
        RBX::StarterPlayerScripts *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a21590 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_23StarterCharacterScriptsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StarterCharacterScripts,RBX::StarterCharacterScripts>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StarterCharacterScripts> *ppx,
        RBX::StarterCharacterScripts *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a2e4b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13PluginManagerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PluginManager,RBX::PluginManager>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PluginManager> *ppx,
        RBX::PluginManager *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a2ecf0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_6PluginES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Plugin,RBX::Plugin>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Plugin> *ppx,
        RBX::Plugin *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a2f830 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_23StandalonePluginScriptsES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StandalonePluginScripts,RBX::StandalonePluginScripts>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StandalonePluginScripts> *ppx,
        RBX::StandalonePluginScripts *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a41730 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11PluginMouseES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PluginMouse,RBX::PluginMouse>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PluginMouse> *ppx,
        RBX::PluginMouse *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a41c20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17MemStorageServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MemStorageService,RBX::MemStorageService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MemStorageService> *ppx,
        RBX::MemStorageService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a41da0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_33MultipleDocumentInterfaceInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MultipleDocumentInterfaceInstance,RBX::MultipleDocumentInterfaceInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MultipleDocumentInterfaceInstance> *ppx,
        RBX::MultipleDocumentInterfaceInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a41f20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13PluginToolbarES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PluginToolbar,RBX::PluginToolbar>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PluginToolbar> *ppx,
        RBX::PluginToolbar *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a420a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19DockWidgetPluginGuiES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DockWidgetPluginGui,RBX::DockWidgetPluginGui>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DockWidgetPluginGui> *ppx,
        RBX::DockWidgetPluginGui *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a42220 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16QWidgetPluginGuiES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::QWidgetPluginGui,RBX::QWidgetPluginGui>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::QWidgetPluginGui> *ppx,
        RBX::QWidgetPluginGui *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a423a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12PluginActionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PluginAction,RBX::PluginAction>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PluginAction> *ppx,
        RBX::PluginAction *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a42520 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10PluginMenuES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PluginMenu,RBX::PluginMenu>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PluginMenu> *ppx,
        RBX::PluginMenu *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a4a900 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20MemStorageConnectionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MemStorageConnection,RBX::MemStorageConnection>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MemStorageConnection> *ppx,
        RBX::MemStorageConnection *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a54a00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16DataModelSessionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::DataModelSession,RBX::DataModelSession>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::DataModelSession> *ppx,
        RBX::DataModelSession *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a56890 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19PluginToolbarButtonES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PluginToolbarButton,RBX::PluginToolbarButton>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PluginToolbarButton> *ppx,
        RBX::PluginToolbarButton *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a75df0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14RemoteFunctionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RemoteFunction,RBX::RemoteFunction>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RemoteFunction> *ppx,
        RBX::RemoteFunction *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a76110 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11RemoteEventES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RemoteEvent,RBX::RemoteEvent>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RemoteEvent> *ppx,
        RBX::RemoteEvent *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a93770 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4TeamES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Team,RBX::Team>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Team> *ppx,
        RBX::Team *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a97a20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7GuiMainES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GuiMain,RBX::GuiMain>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GuiMain> *ppx,
        RBX::GuiMain *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1a98890 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5MouseES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Mouse,RBX::Mouse>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Mouse> *ppx,
        RBX::Mouse *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1aa1c10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14ScrollingFrameES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ScrollingFrame,RBX::ScrollingFrame>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ScrollingFrame> *ppx,
        RBX::ScrollingFrame *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1aa8e50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4SeatES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Seat,RBX::Seat>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Seat> *ppx,
        RBX::Seat *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ab1520 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20SkateboardControllerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SkateboardController,RBX::SkateboardController>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SkateboardController> *ppx,
        RBX::SkateboardController *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ab77e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18SkateboardPlatformES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SkateboardPlatform,RBX::SkateboardPlatform>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SkateboardPlatform> *ppx,
        RBX::SkateboardPlatform *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1abc530 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_3SkyES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Sky,RBX::Sky>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Sky> *ppx,
        RBX::Sky *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1abf540 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5TrailES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Trail,RBX::Trail>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Trail> *ppx,
        RBX::Trail *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ac2d00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4BeamES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Beam,RBX::Beam>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Beam> *ppx,
        RBX::Beam *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ace1c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18PartOperationAssetES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PartOperationAsset,RBX::PartOperationAsset>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PartOperationAsset> *ppx,
        RBX::PartOperationAsset *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ad0c90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13SpawnLocationES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SpawnLocation,RBX::SpawnLocation>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SpawnLocation> *ppx,
        RBX::SpawnLocation *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ad2750 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12SpecialShapeES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SpecialShape,RBX::SpecialShape>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SpecialShape> *ppx,
        RBX::SpecialShape *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1adb3c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats20PerformanceStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::PerformanceStatsItem,RBX::Stats::PerformanceStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::PerformanceStatsItem> *ppx,
        RBX::Stats::PerformanceStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1adc7f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats4ItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::Item,RBX::Stats::Item>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::Item> *ppx,
        RBX::Stats::Item *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1adcb70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerI26TotalCountTimeIntervalItemS6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<TotalCountTimeIntervalItem,TotalCountTimeIntervalItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<TotalCountTimeIntervalItem> *ppx,
        TotalCountTimeIntervalItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1adcee0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerI21RunningAverageItemIntS6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RunningAverageItemInt,RunningAverageItemInt>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RunningAverageItemInt> *ppx,
        RunningAverageItemInt *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1add250 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerI24RunningAverageItemDoubleS6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RunningAverageItemDouble,RunningAverageItemDouble>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RunningAverageItemDouble> *ppx,
        RunningAverageItemDouble *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1add630 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerI43RunningAverageTimeIntervalItemTimeBenchmarkS6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RunningAverageTimeIntervalItemTimeBenchmark,RunningAverageTimeIntervalItemTimeBenchmark>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RunningAverageTimeIntervalItemTimeBenchmark> *ppx,
        RunningAverageTimeIntervalItemTimeBenchmark *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1add920 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats12TypedMemItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::TypedMemItem,RBX::Stats::TypedMemItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::TypedMemItem> *ppx,
        RBX::Stats::TypedMemItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1addba0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5Stats16TypedPercentItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Stats::TypedPercentItem,RBX::Stats::TypedPercentItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Stats::TypedPercentItem> *ppx,
        RBX::Stats::TypedPercentItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1aefa90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13StudioServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::StudioService,RBX::StudioService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::StudioService> *ppx,
        RBX::StudioService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1afb7a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_21PlayerEmulatorServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PlayerEmulatorService,RBX::PlayerEmulatorService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PlayerEmulatorService> *ppx,
        RBX::PlayerEmulatorService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1b08c70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10SurfaceGuiES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SurfaceGui,RBX::SurfaceGui>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SurfaceGui> *ppx,
        RBX::SurfaceGui *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1b0a920 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16SurfaceSelectionES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SurfaceSelection,RBX::SurfaceSelection>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SurfaceSelection> *ppx,
        RBX::SurfaceSelection *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1b0b590 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11PackageLinkES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PackageLink,RBX::PackageLink>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PackageLink> *ppx,
        RBX::PackageLink *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1b14ff0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16PackageLinkDummyES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PackageLinkDummy,RBX::PackageLinkDummy>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PackageLinkDummy> *ppx,
        RBX::PackageLinkDummy *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1b8ef10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14FunctionalTestES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FunctionalTest,RBX::FunctionalTest>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FunctionalTest> *ppx,
        RBX::FunctionalTest *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1b9ac20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13RenderingTestES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RenderingTest,RBX::RenderingTest>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RenderingTest> *ppx,
        RBX::RenderingTest *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ba7d10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7TextBoxES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TextBox,RBX::TextBox>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TextBox> *ppx,
        RBX::TextBox *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1baf3f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13GuiTextButtonES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::GuiTextButton,RBX::GuiTextButton>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::GuiTextButton> *ppx,
        RBX::GuiTextButton *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bbcb00 | Name: _ZN5boost23enable_shared_from_thisIN3RBX11TextScraperEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::TextScraper>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::TextScraper> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1bc3a00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_11TextScraper16ClientScraperJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TextScraper::ClientScraperJob,RBX::TextScraper::ClientScraperJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::TextScraper::ClientScraperJob> *ppx,
        RBX::TextScraper::ClientScraperJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bc3b50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_11TextScraper16ServerScraperJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TextScraper::ServerScraperJob,RBX::TextScraper::ServerScraperJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::TextScraper::ServerScraperJob> *ppx,
        RBX::TextScraper::ServerScraperJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bc3ca0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_11TextScraper10ScraperJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TextScraper::ScraperJob,RBX::TextScraper::ScraperJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::TextScraper::ScraperJob> *ppx,
        RBX::TextScraper::ScraperJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bd69e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10TypesetterEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Typesetter>::_internal_accept_owner<RBX::Typesetter,RBX::Typesetter>(
        const boost::enable_shared_from_this<RBX::Typesetter> *this,
        const boost::shared_ptr<RBX::Typesetter> *ppx,
        RBX::Typesetter *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bd7430 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_24TextFilterResultInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::TextFilterResultInstance,RBX::TextFilterResultInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::TextFilterResultInstance> *ppx,
        RBX::TextFilterResultInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bdf230 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4ToolES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Tool,RBX::Tool>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Tool> *ppx,
        RBX::Tool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1be0f70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_16ToolMouseCommandES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::ToolMouseCommand,RBX::ToolMouseCommand>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::ToolMouseCommand> *ppx,
        RBX::ToolMouseCommand *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bf1830 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5TweenES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Tween,RBX::Tween>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Tween> *ppx,
        RBX::Tween *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bf8310 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17VehicleControllerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::VehicleController,RBX::VehicleController>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::VehicleController> *ppx,
        RBX::VehicleController *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1bf97d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18HumanoidControllerES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::HumanoidController,RBX::HumanoidController>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::HumanoidController> *ppx,
        RBX::HumanoidController *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c122f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15KeyboardServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::KeyboardService,RBX::KeyboardService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::KeyboardService> *ppx,
        RBX::KeyboardService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c20250 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12NumericValueIlEES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::NumericValue<long>,RBX::NumericValue<long>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::NumericValue<int64_t> > *ppx,
        RBX::NumericValue<long> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c203d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5ValueIN3G3D15CoordinateFrameEEES9_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Value<G3D::CoordinateFrame>,RBX::Value<G3D::CoordinateFrame>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Value<G3D::CoordinateFrame> > *ppx,
        RBX::Value<G3D::CoordinateFrame> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c20550 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5ValueIN3G3D6Color3EEES9_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Value<G3D::Color3>,RBX::Value<G3D::Color3>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Value<G3D::Color3> > *ppx,
        RBX::Value<G3D::Color3> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c206d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5ValueINS1_10BrickColorEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Value<RBX::BrickColor>,RBX::Value<RBX::BrickColor>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Value<RBX::BrickColor> > *ppx,
        RBX::Value<RBX::BrickColor> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c20850 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11ObjectValueES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ObjectValue,RBX::ObjectValue>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ObjectValue> *ppx,
        RBX::ObjectValue *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c209d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5ValueINS1_6RbxRayEEES8_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Value<RBX::RbxRay>,RBX::Value<RBX::RbxRay>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Value<RBX::RbxRay> > *ppx,
        RBX::Value<RBX::RbxRay> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c20b50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16ConstrainedValueIlEES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ConstrainedValue<long>,RBX::ConstrainedValue<long>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ConstrainedValue<int64_t> > *ppx,
        RBX::ConstrainedValue<long> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c20cd0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16ConstrainedValueIdEES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ConstrainedValue<double>,RBX::ConstrainedValue<double>>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ConstrainedValue<double> > *ppx,
        RBX::ConstrainedValue<double> *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c26fe0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11VehicleSeatES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::VehicleSeat,RBX::VehicleSeat>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::VehicleSeat> *ppx,
        RBX::VehicleSeat *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c315b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10VideoFrameES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::VideoFrame,RBX::VideoFrame>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::VideoFrame> *ppx,
        RBX::VideoFrame *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c32e10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_8VideoJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::VideoJob,RBX::VideoJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::VideoJob> *ppx,
        RBX::VideoJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c32f60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX11VideoStreamEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::VideoStream>::_internal_accept_owner<RBX::VideoStream,RBX::VideoStream>(
        const boost::enable_shared_from_this<RBX::VideoStream> *this,
        const boost::shared_ptr<RBX::VideoStream> *ppx,
        RBX::VideoStream *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c53200 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18WorkspaceStatsItemES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::WorkspaceStatsItem,RBX::WorkspaceStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::WorkspaceStatsItem> *ppx,
        RBX::WorkspaceStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c55160 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_9DecalToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::DecalTool,RBX::DecalTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::DecalTool> *ppx,
        RBX::DecalTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c55930 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_11NewNullToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::NewNullTool,RBX::NewNullTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::NewNullTool> *ppx,
        RBX::NewNullTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::MouseCommand>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c59290 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_12PartDropToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::PartDropTool,RBX::PartDropTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::PartDropTool> *ppx,
        RBX::PartDropTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c59390 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX12MouseCommandEE22_internal_accept_ownerINS1_13GroupDropToolES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::MouseCommand>::_internal_accept_owner<RBX::GroupDropTool,RBX::GroupDropTool>(
        const boost::enable_shared_from_this<RBX::MouseCommand> *this,
        const boost::shared_ptr<RBX::GroupDropTool> *ppx,
        RBX::GroupDropTool *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c5b0b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10WorldModelES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::WorldModel,RBX::WorldModel>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::WorldModel> *ppx,
        RBX::WorldModel *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c60490 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10PointLightES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PointLight,RBX::PointLight>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PointLight> *ppx,
        RBX::PointLight *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c60760 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9SpotLightES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SpotLight,RBX::SpotLight>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SpotLight> *ppx,
        RBX::SpotLight *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c60a30 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12SurfaceLightES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SurfaceLight,RBX::SurfaceLight>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SurfaceLight> *ppx,
        RBX::SurfaceLight *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c642a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints11VectorForceES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::VectorForce,RBX::Constraints::VectorForce>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::VectorForce> *ppx,
        RBX::Constraints::VectorForce *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c644e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints9LineForceES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::LineForce,RBX::Constraints::LineForce>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::LineForce> *ppx,
        RBX::Constraints::LineForce *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c66840 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints14TorqueActuatorES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::TorqueActuator,RBX::Constraints::TorqueActuator>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::TorqueActuator> *ppx,
        RBX::Constraints::TorqueActuator *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c6b430 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints15HingeConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::HingeConstraint,RBX::Constraints::HingeConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::HingeConstraint> *ppx,
        RBX::Constraints::HingeConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c6d840 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints16MoveToConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::MoveToConstraint,RBX::Constraints::MoveToConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::MoveToConstraint> *ppx,
        RBX::Constraints::MoveToConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c6f770 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints19PrismaticConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::PrismaticConstraint,RBX::Constraints::PrismaticConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::PrismaticConstraint> *ppx,
        RBX::Constraints::PrismaticConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c76450 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints20BallSocketConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::BallSocketConstraint,RBX::Constraints::BallSocketConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::BallSocketConstraint> *ppx,
        RBX::Constraints::BallSocketConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c7c170 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints21CylindricalConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::CylindricalConstraint,RBX::Constraints::CylindricalConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::CylindricalConstraint> *ppx,
        RBX::Constraints::CylindricalConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c80700 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints21OrientationConstraintES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::OrientationConstraint,RBX::Constraints::OrientationConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::OrientationConstraint> *ppx,
        RBX::Constraints::OrientationConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c82990 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11Constraints23AngularVelocityActuatorES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Constraints::AngularVelocityActuator,RBX::Constraints::AngularVelocityActuator>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Constraints::AngularVelocityActuator> *ppx,
        RBX::Constraints::AngularVelocityActuator *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c85600 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_11VirtualUserES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::VirtualUser,RBX::VirtualUser>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::VirtualUser> *ppx,
        RBX::VirtualUser *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c86710 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12CylinderMeshES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CylinderMesh,RBX::CylinderMesh>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CylinderMesh> *ppx,
        RBX::CylinderMesh *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c884c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12SelectionBoxES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SelectionBox,RBX::SelectionBox>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SelectionBox> *ppx,
        RBX::SelectionBox *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c8b0e0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13ABTestServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ABTestService,RBX::ABTestService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ABTestService> *ppx,
        RBX::ABTestService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c90f40 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13CharacterMeshES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CharacterMesh,RBX::CharacterMesh>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CharacterMesh> *ppx,
        RBX::CharacterMesh *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c91b60 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13ConfigurationES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Configuration,RBX::Configuration>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Configuration> *ppx,
        RBX::Configuration *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c9a6d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13PolicyServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PolicyService,RBX::PolicyService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PolicyService> *ppx,
        RBX::PolicyService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1c9ff90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18SelectionPartLassoES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SelectionPartLasso,RBX::SelectionPartLasso>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SelectionPartLasso> *ppx,
        RBX::SelectionPartLasso *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ca01d0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19SelectionPointLassoES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SelectionPointLasso,RBX::SelectionPointLasso>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SelectionPointLasso> *ppx,
        RBX::SelectionPointLasso *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ca1310 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_15SelectionSphereES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SelectionSphere,RBX::SelectionSphere>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SelectionSphere> *ppx,
        RBX::SelectionSphere *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ca3b80 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9FlagStandES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FlagStand,RBX::FlagStand>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FlagStand> *ppx,
        RBX::FlagStand *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ca4760 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16FlagStandServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::FlagStandService,RBX::FlagStandService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::FlagStandService> *ppx,
        RBX::FlagStandService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ca5740 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4FlagES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Flag,RBX::Flag>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Flag> *ppx,
        RBX::Flag *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cb87b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16MessagingServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::MessagingService,RBX::MessagingService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::MessagingService> *ppx,
        RBX::MessagingService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cb9e00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_27MessagingServiceAnalysisJobES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::MessagingServiceAnalysisJob,RBX::MessagingServiceAnalysisJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::MessagingServiceAnalysisJob> *ppx,
        RBX::MessagingServiceAnalysisJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cb9f50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX17SignalRConnectionEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::SignalRConnection>::_internal_accept_owner<RBX::SignalRConnection,RBX::SignalRConnection>(
        const boost::enable_shared_from_this<RBX::SignalRConnection>_0 *this,
        const boost::shared_ptr<RBX::SignalRConnection> *ppx,
        RBX::SignalRConnection *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cbe250 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_17ParabolaAdornmentES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::ParabolaAdornment,RBX::ParabolaAdornment>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::ParabolaAdornment> *ppx,
        RBX::ParabolaAdornment *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cc36a0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_18PathfindingServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PathfindingService,RBX::PathfindingService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PathfindingService> *ppx,
        RBX::PathfindingService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cc4df0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4PathES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Path,RBX::Path>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Path> *ppx,
        RBX::Path *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cc4f40 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX17NavigationServiceEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::NavigationService>::_internal_accept_owner<RBX::NavigationService,RBX::NavigationService>(
        const boost::enable_shared_from_this<RBX::NavigationService> *this,
        const boost::shared_ptr<RBX::NavigationService> *ppx,
        RBX::NavigationService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cc6480 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19CornerWedgeInstanceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::CornerWedgeInstance,RBX::CornerWedgeInstance>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::CornerWedgeInstance> *ppx,
        RBX::CornerWedgeInstance *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ccaa20 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_19RbxAnalyticsServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::RbxAnalyticsService,RBX::RbxAnalyticsService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::RbxAnalyticsService> *ppx,
        RBX::RbxAnalyticsService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cd14c0 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvNS7_IvNS_4_mfi3mf3IvN3RBX21ThirdPartyUserServiceENSA_11InputObject13UserInputTypeENS_8functionIFviEEENSE_IFvNSt3__112basic_stringIcNSH_11char_traitsIcEENSH_9allocatorIcEEEEEEEEENS6_5list4INS6_5valueIPSB_EENSS_ISD_EENSS_ISG_EENSS_ISP_EEEEEENS6_5list1INSS_INSA_12DataModelJob8TaskTypeEEEEEEEEEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > >,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cd26b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4FireES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Fire,RBX::Fire>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Fire> *ppx,
        RBX::Fire *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cd3630 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_4PART5WedgeES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::PART::Wedge,RBX::PART::Wedge>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::PART::Wedge> *ppx,
        RBX::PART::Wedge *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cd4190 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_5SmokeES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Smoke,RBX::Smoke>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Smoke> *ppx,
        RBX::Smoke *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cd5360 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8SparklesES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Sparkles,RBX::Sparkles>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Sparkles> *ppx,
        RBX::Sparkles *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cd5c00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9BlockMeshES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BlockMesh,RBX::BlockMesh>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BlockMesh> *ppx,
        RBX::BlockMesh *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cdc030 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13HapticServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::HapticService,RBX::HapticService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::HapticService> *ppx,
        RBX::HapticService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ce5e10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20UGCValidationServiceES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UGCValidationService,RBX::UGCValidationService>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UGCValidationService> *ppx,
        RBX::UGCValidationService *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ce8fe0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_23UIAspectRatioConstraintES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UIAspectRatioConstraint,RBX::UIAspectRatioConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UIAspectRatioConstraint> *ppx,
        RBX::UIAspectRatioConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cec000 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12UIGridLayoutES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UIGridLayout,RBX::UIGridLayout>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UIGridLayout> *ppx,
        RBX::UIGridLayout *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ced0f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12UIListLayoutES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UIListLayout,RBX::UIListLayout>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UIListLayout> *ppx,
        RBX::UIListLayout *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cf3100 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_12UIPageLayoutES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UIPageLayout,RBX::UIPageLayout>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UIPageLayout> *ppx,
        RBX::UIPageLayout *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cf6ae0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13UITableLayoutES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UITableLayout,RBX::UITableLayout>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UITableLayout> *ppx,
        RBX::UITableLayout *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cf8a00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_14UIInlineLayoutES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UIInlineLayout,RBX::UIInlineLayout>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UIInlineLayout> *ppx,
        RBX::UIInlineLayout *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1cfa0f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10UIGradientES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UIGradient,RBX::UIGradient>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UIGradient> *ppx,
        RBX::UIGradient *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1d04c70 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_16UISizeConstraintES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UISizeConstraint,RBX::UISizeConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UISizeConstraint> *ppx,
        RBX::UISizeConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1d05710 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_20UITextSizeConstraintES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UITextSizeConstraint,RBX::UITextSizeConstraint>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UITextSizeConstraint> *ppx,
        RBX::UITextSizeConstraint *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1d0d280 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_7UIScaleES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UIScale,RBX::UIScale>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UIScale> *ppx,
        RBX::UIScale *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1d0e120 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_9UIPaddingES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::UIPadding,RBX::UIPadding>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::UIPadding> *ppx,
        RBX::UIPadding *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1eadb10 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_13SunRaysEffectES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::SunRaysEffect,RBX::SunRaysEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::SunRaysEffect> *ppx,
        RBX::SunRaysEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1eae2f0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_10BlurEffectES6_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::BlurEffect,RBX::BlurEffect>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::BlurEffect> *ppx,
        RBX::BlurEffect *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ec1d90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX19NavigationDebugDrawEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::NavigationDebugDraw>::_internal_accept_owner<RBX::NavigationDebugDraw,RBX::NavigationDebugDraw>(
        const boost::enable_shared_from_this<RBX::NavigationDebugDraw> *this,
        const boost::shared_ptr<RBX::NavigationDebugDraw> *ppx,
        RBX::NavigationDebugDraw *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ec1f90 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX14NavigationPathEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::NavigationPath>::_internal_accept_owner<RBX::NavigationPath,RBX::NavigationPath>(
        const boost::enable_shared_from_this<RBX::NavigationPath> *this,
        const boost::shared_ptr<RBX::NavigationPath> *ppx,
        RBX::NavigationPath *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ec2630 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_17NavigationService13PathUpdateJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::NavigationService::PathUpdateJob,RBX::NavigationService::PathUpdateJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::NavigationService::PathUpdateJob> *ppx,
        RBX::NavigationService::PathUpdateJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1ec51c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerINS1_17NavigationService13NavigationJobES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::NavigationService::NavigationJob,RBX::NavigationService::NavigationJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::NavigationService::NavigationJob> *ppx,
        RBX::NavigationService::NavigationJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f155a0 | Name: _ZN5boost23enable_shared_from_thisIN3RBX10LayoutNodeEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::LayoutNode>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::LayoutNode> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1f18270 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10LayoutNodeEE22_internal_accept_ownerINS1_13LayoutDefaultES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutDefault,RBX::LayoutDefault>(
        const boost::enable_shared_from_this<RBX::LayoutNode> *this,
        const boost::shared_ptr<RBX::LayoutDefault> *ppx,
        RBX::LayoutDefault *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f183c0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10LayoutNodeEE22_internal_accept_ownerINS1_10LayoutListES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutList,RBX::LayoutList>(
        const boost::enable_shared_from_this<RBX::LayoutNode> *this,
        const boost::shared_ptr<RBX::LayoutList> *ppx,
        RBX::LayoutList *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f18510 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10LayoutNodeEE22_internal_accept_ownerINS1_10LayoutGridES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutGrid,RBX::LayoutGrid>(
        const boost::enable_shared_from_this<RBX::LayoutNode> *this,
        const boost::shared_ptr<RBX::LayoutGrid> *ppx,
        RBX::LayoutGrid *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f18660 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10LayoutNodeEE22_internal_accept_ownerINS1_10LayoutPageES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutPage,RBX::LayoutPage>(
        const boost::enable_shared_from_this<RBX::LayoutNode> *this,
        const boost::shared_ptr<RBX::LayoutPage> *ppx,
        RBX::LayoutPage *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f187b0 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10LayoutNodeEE22_internal_accept_ownerINS1_11LayoutTableES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutTable,RBX::LayoutTable>(
        const boost::enable_shared_from_this<RBX::LayoutNode> *this,
        const boost::shared_ptr<RBX::LayoutTable> *ppx,
        RBX::LayoutTable *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f18900 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10LayoutNodeEE22_internal_accept_ownerINS1_16LayoutTableMajorES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutTableMajor,RBX::LayoutTableMajor>(
        const boost::enable_shared_from_this<RBX::LayoutNode> *this,
        const boost::shared_ptr<RBX::LayoutTableMajor> *ppx,
        RBX::LayoutTableMajor *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f18a50 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10LayoutNodeEE22_internal_accept_ownerINS1_12LayoutInlineES5_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::LayoutNode>::_internal_accept_owner<RBX::LayoutInline,RBX::LayoutInline>(
        const boost::enable_shared_from_this<RBX::LayoutNode> *this,
        const boost::shared_ptr<RBX::LayoutInline> *ppx,
        RBX::LayoutInline *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f621e0 | Name: _ZNK5boost23enable_shared_from_thisI24CSGAssetFetchContinuatorE22_internal_accept_ownerIS1_S1_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<CSGAssetFetchContinuator>::_internal_accept_owner<CSGAssetFetchContinuator,CSGAssetFetchContinuator>(
        const boost::enable_shared_from_this<CSGAssetFetchContinuator> *this,
        const boost::shared_ptr<CSGAssetFetchContinuator> *ppx,
        CSGAssetFetchContinuator *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f8c200 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX10Reflection13DescribedBaseEE22_internal_accept_ownerINS1_8Graphics25FrameRateManagerStatsItemES7_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::Reflection::DescribedBase>::_internal_accept_owner<RBX::Graphics::FrameRateManagerStatsItem,RBX::Graphics::FrameRateManagerStatsItem>(
        const boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *this,
        const boost::shared_ptr<RBX::Graphics::FrameRateManagerStatsItem> *ppx,
        RBX::Graphics::FrameRateManagerStatsItem *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x1f8d880 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_NS1_11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf3IvN3RBX8Graphics10RenderViewENS_10shared_ptrIN3G3D6GImageEEENS_8weak_ptrINSA_9DataModelEEElEENS6_5list4INS6_5valueIPSC_EENSM_ISG_EENSM_ISJ_EENSM_IlEEEEEEEEEEvPKNSD_IT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView*>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>>>>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > > > *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x2546a70 | Name: _ZN5boost23enable_shared_from_thisIN3RBX17SignalRConnectionEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::SignalRConnection>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::SignalRConnection> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x27bef00 | Name: _ZNK5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEE22_internal_accept_ownerIS3_NS1_12TaskQueueJobEEEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::_internal_accept_owner<RBX::TaskScheduler::Job,RBX::TaskQueueJob>(
        const boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this,
        const boost::shared_ptr<RBX::TaskScheduler::Job> *ppx,
        RBX::TaskQueueJob *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


// Address: 0x27bff50 | Name: _ZN5boost23enable_shared_from_thisIN3RBX13TaskScheduler3JobEED2Ev
void __fastcall boost::enable_shared_from_this<RBX::TaskScheduler::Job>::~enable_shared_from_this(
        boost::enable_shared_from_this<RBX::TaskScheduler::Job> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x28456f0 | Name: _ZN5boost23enable_shared_from_thisINS_6detail16thread_data_baseEED2Ev
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::~enable_shared_from_this(
        boost::enable_shared_from_this<boost::detail::thread_data_base> *this)
{
  boost::detail::sp_counted_base *pi; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x2845e90 | Name: _ZNK5boost23enable_shared_from_thisINS_6detail16thread_data_baseEE22_internal_accept_ownerIS2_S2_EEvPKNS_10shared_ptrIT_EEPT0_
void __fastcall boost::enable_shared_from_this<boost::detail::thread_data_base>::_internal_accept_owner<boost::detail::thread_data_base,boost::detail::thread_data_base>(
        const boost::enable_shared_from_this<boost::detail::thread_data_base> *this,
        const boost::shared_ptr<boost::detail::thread_data_base> *ppx,
        boost::detail::thread_data_base *py)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v5; // rbx
  boost::detail::sp_counted_base *v6; // rdi

  pi = this->weak_this_.pn.pi_;
  if ( !pi || !pi->use_count_ )
  {
    v5 = ppx->pn.pi_;
    if ( v5 )
      _InterlockedAdd(&v5->use_count_, 1u);
    this->weak_this_.px = py;
    v6 = this->weak_this_.pn.pi_;
    if ( v5 != v6 )
    {
      if ( v5 )
      {
        _InterlockedAdd(&v5->weak_count_, 1u);
        v6 = this->weak_this_.pn.pi_;
      }
      if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      this->weak_this_.pn.pi_ = v5;
    }
    if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
}


