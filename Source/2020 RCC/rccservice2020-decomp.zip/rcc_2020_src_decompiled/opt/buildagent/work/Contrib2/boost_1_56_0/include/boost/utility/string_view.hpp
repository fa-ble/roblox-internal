// Address: 0x21a4d60 | Name: _ZN5boost6detail20sv_insert_fill_charsIcNSt3__111char_traitsIcEEEEvRNS2_13basic_ostreamIT_T0_EEm
void __fastcall boost::detail::sv_insert_fill_chars<char,std::char_traits<char>>(std::ostream *os, size_t n)
{
  size_t v2; // rbx
  __int64 v3; // r15
  int v4; // eax
  __int64 v5; // rax
  char v6; // bp
  __int64 v7; // rax
  std::locale v8; // [rsp+8h] [rbp-30h] BYREF
  unsigned __int64 v9; // [rsp+10h] [rbp-28h]

  v2 = n;
  v9 = __readfsqword(0x28u);
  v3 = *(_QWORD *)(*(_QWORD *)os - 24LL);
  v4 = *(_DWORD *)((char *)os + v3 + 144);
  if ( v4 == -1 )
  {
    std::ios_base::getloc((std::ios_base *)&v8);
    v5 = std::locale::use_facet(&v8, &std::ctype<char>::id);
    v6 = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v5 + 56LL))(v5, 32);
    std::locale::~locale(&v8);
    LOBYTE(v4) = v6;
    *(_DWORD *)((char *)os + v3 + 144) = v6;
  }
  v8.__locale_ = (std::locale::__imp *)(0x101010101010101LL * (unsigned __int8)v4);
  if ( n < 8 )
  {
LABEL_6:
    if ( !v2 )
      return;
    v7 = *(_QWORD *)(*(_QWORD *)os - 24LL);
  }
  else
  {
    while ( 1 )
    {
      v7 = *(_QWORD *)(*(_QWORD *)os - 24LL);
      if ( *(_DWORD *)((char *)os + v7 + 32) )
        break;
      std::ostream::write(os, &v8, 8);
      v2 -= 8LL;
      if ( v2 <= 7 )
        goto LABEL_6;
    }
  }
  if ( !*(_DWORD *)((char *)os + v7 + 32) )
    std::ostream::write(os, &v8, v2);
}


