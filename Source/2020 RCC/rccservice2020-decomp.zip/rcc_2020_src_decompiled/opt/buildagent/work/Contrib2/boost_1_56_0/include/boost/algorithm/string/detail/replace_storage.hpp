// Address: 0xefd740 | Name: _ZN5boost9algorithm6detail22process_segment_helperILb0EEclINSt3__15dequeIcNS5_9allocatorIcEEEENS5_12basic_stringIcNS5_11char_traitsIcEES8_EENS5_11__wrap_iterIPcEEEET1_RT_RT0_SH_SH_SH_
std::__wrap_iter<char *> __fastcall boost::algorithm::detail::process_segment_helper<false>::operator()<std::deque<char>,std::string,std::__wrap_iter<char *>>(
        boost::algorithm::detail::process_segment_helper<false> *this,
        std::deque<char> *Storage,
        std::string *a3,
        std::__wrap_iter<char *> InsertIt,
        std::__wrap_iter<char *> SegmentBegin,
        std::__wrap_iter<char *> SegmentEnd)
{
  std::__wrap_iter<char *>::iterator_type i; // r15
  unsigned __int64 value; // rax
  std::__split_buffer<char *>::pointer begin; // rcx
  std::__deque_base<char>::size_type start; // rdx
  std::__wrap_iter<char *>::iterator_type v12; // r13
  __m128i si128; // xmm1
  __m128i v14; // xmm0
  bool v15; // zf
  char **v16; // rcx
  std::__deque_base<char>::size_type v17; // rdx
  char *j; // r15
  char *v19; // rdi
  unsigned __int64 v20; // rax
  std::__deque_base<char>::size_type v21; // rdx
  size_t v22; // r14

  i = InsertIt.__i;
  value = Storage->__size_.__value_;
  if ( InsertIt.__i != SegmentBegin.__i && value )
  {
    begin = Storage->__map_.__begin_;
    start = Storage->__start_;
    v12 = SegmentBegin.__i - 1;
    si128 = _mm_load_si128((const __m128i *)&xmmword_3E67C0);
    do
    {
      *i = begin[start >> 12][start & 0xFFF];
      begin = Storage->__map_.__begin_;
      v14 = _mm_add_epi64(_mm_loadu_si128((const __m128i *)&Storage->__start_), si128);
      *(__m128i *)&Storage->__start_ = v14;
      start = v14.m128i_i64[0];
      if ( v14.m128i_i64[0] < 0x2000uLL )
      {
        value = _mm_shuffle_epi32(v14, 78).m128i_u64[0];
      }
      else
      {
        operator delete(*begin);
        si128 = _mm_load_si128((const __m128i *)&xmmword_3E67C0);
        value = Storage->__size_.__value_;
        begin = Storage->__map_.__begin_ + 1;
        Storage->__map_.__begin_ = begin;
        start = Storage->__start_ - 4096;
        Storage->__start_ = start;
      }
      v15 = v12 == i++;
    }
    while ( !v15 && value );
  }
  if ( value )
  {
    if ( i != SegmentEnd.__i )
    {
      v16 = Storage->__map_.__begin_;
      v17 = Storage->__start_;
      for ( j = i + 1; ; ++j )
      {
        v19 = (char *)((((char *)Storage->__map_.__end_ - (char *)v16) << 9) - 1);
        if ( Storage->__map_.__end_ == v16 )
          v19 = (char *)((char *)Storage->__map_.__end_ - (char *)v16);
        v20 = v17 + value;
        if ( v19 == (char *)v20 )
        {
          std::deque<char>::__add_back_capacity(Storage);
          v16 = Storage->__map_.__begin_;
          v20 = Storage->__size_.__value_ + Storage->__start_;
        }
        v16[v20 >> 12][v20 & 0xFFF] = *(j - 1);
        ++Storage->__size_.__value_;
        *(j - 1) = Storage->__map_.__begin_[Storage->__start_ >> 12][Storage->__start_ & 0xFFF];
        v16 = Storage->__map_.__begin_;
        v21 = Storage->__start_;
        --Storage->__size_.__value_;
        v17 = v21 + 1;
        Storage->__start_ = v17;
        if ( v17 >= 0x2000 )
        {
          operator delete(*v16);
          v16 = Storage->__map_.__begin_ + 1;
          Storage->__map_.__begin_ = v16;
          v17 = Storage->__start_ - 4096;
          Storage->__start_ = v17;
        }
        if ( SegmentEnd.__i == j )
          break;
        value = Storage->__size_.__value_;
      }
    }
  }
  else if ( i != SegmentBegin.__i )
  {
    v22 = SegmentEnd.__i - SegmentBegin.__i;
    if ( v22 )
      memmove(i, SegmentBegin.__i, v22);
    return (std::__wrap_iter<char *>)&i[v22];
  }
  return SegmentEnd;
}


