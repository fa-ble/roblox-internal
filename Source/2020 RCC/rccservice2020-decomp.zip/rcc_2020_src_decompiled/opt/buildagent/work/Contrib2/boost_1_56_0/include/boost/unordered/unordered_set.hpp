// Address: 0xf74bf0 | Name: _ZN5boost9unordered13unordered_setINSt3__14pairIKNS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEPKN3RBX8InstanceEEENS_4hashISF_EENS2_8equal_toISF_EENS_19fast_pool_allocatorISF_NS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEED2Ev
void __fastcall boost::unordered::unordered_set<std::pair<std::string const,RBX::Instance const*>,boost::hash<std::pair<std::string const,RBX::Instance const*>>,std::equal_to<std::pair<std::string const,RBX::Instance const*>>,boost::fast_pool_allocator<std::pair<std::string const,RBX::Instance const*>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~unordered_set(
        boost::unordered::unordered_set<std::pair<const std::string,const RBX::Instance *>,boost::hash<std::pair<const std::string,const RBX::Instance *> >,std::equal_to<std::pair<const std::string,const RBX::Instance *> >,boost::fast_pool_allocator<std::pair<const std::string,const RBX::Instance *>,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::set<boost::fast_pool_allocator<std::pair<const std::string,const RBX::Instance *>,boost::default_user_allocator_new_delete,boost::mutex,32,0>,std::pair<const std::string,const RBX::Instance *>,boost::hash<std::pair<const std::string,const RBX::Instance *> >,std::equal_to<std::pair<const std::string,const RBX::Instance *> > > >::bucket_pointer buckets; // r14
  bucket *v2; // rbx
  size_t bucket_count; // rsi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      v2 = &buckets[this->table_.bucket_count_];
      do
        boost::unordered::detail::table<boost::unordered::detail::set<boost::fast_pool_allocator<std::pair<std::string const,RBX::Instance const*>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>,std::pair<std::string const,RBX::Instance const*>,boost::hash<std::pair<std::string const,RBX::Instance const*>>,std::equal_to<std::pair<std::string const,RBX::Instance const*>>>>::delete_node(
          &this->table_,
          v2);
      while ( v2->next_ );
      buckets = this->table_.buckets_;
    }
    bucket_count = this->table_.bucket_count_;
    if ( bucket_count )
    {
      boost::singleton_pool<boost::fast_pool_allocator_tag,8u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::free(
        buckets,
        bucket_count + 1);
    }
    else
    {
      if ( !byte_29FE162 )
      {
        byte_29FE162 = 1;
        boost::mutex::mutex(&stru_29FE068);
        *(_OWORD *)&stru_29FE090.first = 0;
        stru_29FE090.list.sz = 0;
        *(_OWORD *)&stru_29FE090.requested_size = xmmword_3EA460;
        *(_OWORD *)&stru_29FE090.start_size = 0x20u;
      }
      boost::mutex::lock(&stru_29FE068);
      buckets->next_ = (boost::unordered::detail::ptr_bucket::link_pointer)stru_29FE090.first;
      stru_29FE090.first = buckets;
      boost::mutex::unlock(&stru_29FE068);
    }
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xf75e20 | Name: _ZN5boost9unordered13unordered_setINSt3__14pairIKNS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEPKN3RBX8InstanceEEENS_4hashISF_EENS2_8equal_toISF_EENS_19fast_pool_allocatorISF_NS_33default_user_allocator_new_deleteENS_5mutexELj32ELj0EEEE7emplaceIJRSA_RPSC_EEENS3_INS0_15iterator_detail10c_iteratorINS0_6detail8ptr_nodeISF_EEEEbEEDpOT_
std::pair<boost::unordered::iterator_detail::c_iterator<boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> > >,bool> __fastcall boost::unordered::unordered_set<std::pair<std::string const,RBX::Instance const*>,boost::hash<std::pair<std::string const,RBX::Instance const*>>,std::equal_to<std::pair<std::string const,RBX::Instance const*>>,boost::fast_pool_allocator<std::pair<std::string const,RBX::Instance const*>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::emplace<std::string const&,RBX::Instance*&>(
        boost::unordered::unordered_set<std::pair<const std::string,const RBX::Instance *>,boost::hash<std::pair<const std::string,const RBX::Instance *> >,std::equal_to<std::pair<const std::string,const RBX::Instance *> >,boost::fast_pool_allocator<std::pair<const std::string,const RBX::Instance *>,boost::default_user_allocator_new_delete,boost::mutex,32,0> > *this,
        const std::string *args,
        RBX::Instance **a3)
{
  boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> >,boost::default_user_allocator_new_delete,boost::mutex,32,0>::value_type *v4; // rax
  boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> >,boost::default_user_allocator_new_delete,boost::mutex,32,0>::value_type *v5; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::set<boost::fast_pool_allocator<std::pair<const std::string,const RBX::Instance *>,boost::default_user_allocator_new_delete,boost::mutex,32,0>,std::pair<const std::string,const RBX::Instance *>,boost::hash<std::pair<const std::string,const RBX::Instance *> >,std::equal_to<std::pair<const std::string,const RBX::Instance *> > > >::emplace_return v6; // rax
  boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> > *node; // rbx
  bool second; // bp
  boost::unordered::detail::table_impl<boost::unordered::detail::set<boost::fast_pool_allocator<std::pair<const std::string,const RBX::Instance *>,boost::default_user_allocator_new_delete,boost::mutex,32,0>,std::pair<const std::string,const RBX::Instance *>,boost::hash<std::pair<const std::string,const RBX::Instance *> >,std::equal_to<std::pair<const std::string,const RBX::Instance *> > > >::node_constructor v9; // [rsp+0h] [rbp-48h] BYREF
  _BYTE v10[48]; // [rsp+18h] [rbp-30h] BYREF
  std::pair<boost::unordered::iterator_detail::c_iterator<boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> > >,bool> result; // 0:rax.9

  v9.alloc_ = (boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> >,boost::default_user_allocator_new_delete,boost::mutex,32,0> >::node_allocator *)&this->table_.allocators_;
  *(_WORD *)&v9.node_constructed_ = 0;
  v9.node_ = 0;
  v4 = (boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<const std::string,const RBX::Instance *> >,boost::default_user_allocator_new_delete,boost::mutex,32,0>::value_type *)boost::singleton_pool<boost::fast_pool_allocator_tag,48u,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>::malloc();
  v5 = v4;
  if ( !v4 )
  {
    std::bad_alloc::bad_alloc((std::bad_alloc *)v10);
    boost::throw_exception<std::bad_alloc>((const std::bad_alloc *)v10);
  }
  v9.node_ = v4;
  *((_OWORD *)&v4->value_base_.data_.data_.align_ + 1) = 0;
  *(_OWORD *)v4->value_base_.data_.data_.buf = 0;
  *(_OWORD *)&v4->next_ = 0;
  v9.node_constructed_ = 1;
  std::string::basic_string(&v4->value_base_, args);
  *((_QWORD *)&v5->value_base_.data_.data_.align_ + 3) = *a3;
  v9.value_constructed_ = 1;
  v6 = boost::unordered::detail::table_impl<boost::unordered::detail::set<boost::fast_pool_allocator<std::pair<std::string const,RBX::Instance const*>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>,std::pair<std::string const,RBX::Instance const*>,boost::hash<std::pair<std::string const,RBX::Instance const*>>,std::equal_to<std::pair<std::string const,RBX::Instance const*>>>>::emplace_impl_with_node(
         &this->table_,
         &v9);
  node = v6.first.node_;
  second = v6.second;
  boost::unordered::detail::node_constructor<boost::fast_pool_allocator<boost::unordered::detail::ptr_node<std::pair<std::string const,RBX::Instance const*>>,boost::default_user_allocator_new_delete,boost::mutex,32u,0u>>::~node_constructor(&v9);
  result.first.node_ = node;
  result.second = second;
  return result;
}


// Address: 0xfbeb50 | Name: _ZN5boost9unordered13unordered_setIPKN3RBX8InstanceENS_4hashIS5_EENSt3__18equal_toIS5_EENS8_9allocatorIS5_EEED2Ev
void __fastcall boost::unordered::unordered_set<RBX::Instance const*,boost::hash<RBX::Instance const*>,std::equal_to<RBX::Instance const*>,std::allocator<RBX::Instance const*>>::~unordered_set(
        boost::unordered::unordered_set<const RBX::Instance *,boost::hash<const RBX::Instance *>,std::equal_to<const RBX::Instance *>,std::allocator<const RBX::Instance *> > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<const RBX::Instance *>,const RBX::Instance *,boost::hash<const RBX::Instance *>,std::equal_to<const RBX::Instance *> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0xfbebb0 | Name: _ZN5boost9unordered13unordered_setIN3RBX12StreamRegion2IdENS_4hashIS4_EENSt3__18equal_toIS4_EENS7_9allocatorIS4_EEED2Ev
void __fastcall boost::unordered::unordered_set<RBX::StreamRegion::Id,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id>,std::allocator<RBX::StreamRegion::Id>>::~unordered_set(
        boost::unordered::unordered_set<RBX::StreamRegion::Id,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id>,std::allocator<RBX::StreamRegion::Id> > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<RBX::StreamRegion::Id>,RBX::StreamRegion::Id,boost::hash<RBX::StreamRegion::Id>,std::equal_to<RBX::StreamRegion::Id> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x1013e00 | Name: _ZN5boost9unordered13unordered_setINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS_4hashIS8_EENS2_8equal_toIS8_EENS6_IS8_EEED2Ev
void __fastcall boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::string>>::~unordered_set(
        boost::unordered::unordered_set<std::string,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::string > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<std::string >,std::string,boost::hash<std::string>,std::equal_to<std::string > > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        if ( ((__int64)next[2].next_ & 1) != 0 )
          operator delete(next[4].next_);
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x10d17d0 | Name: _ZN5boost9unordered13unordered_setIiNS_4hashIiEENSt3__18equal_toIiEENS4_9allocatorIiEEEC2IPKiEET_SD_
void __fastcall boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::unordered_set<int const*>(
        boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int> > *this,
        const int *f,
        const int *l)
{
  unsigned __int64 v3; // r8
  const boost::unordered::detail::false_type *v5; // rcx
  __int64 v6; // rdi
  const boost::unordered::detail::false_type *v7; // rbx
  __int64 v8; // rax
  size_t *v9; // rdi

  v3 = 11;
  if ( (unsigned __int64)(l - f + 1) > 0xB )
    v3 = l - f + 1;
  this->table_.current_ = 0;
  v5 = &stru_495510;
  v6 = 38;
  do
  {
    v7 = v5;
    v8 = v6 + ~(v6 / 2);
    if ( *(_QWORD *)&v5[8 * (v6 / 2)].gap0 >= v3 )
      v8 = v6 / 2;
    v5 += 8 * (v6 / 2) + 8;
    if ( *(_QWORD *)&v7[8 * (v6 / 2)].gap0 >= v3 )
      v5 = v7;
    v6 = v8;
  }
  while ( v8 );
  v9 = (size_t *)&v5[-8];
  if ( v5 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v9 = (size_t *)v5;
  this->table_.bucket_count_ = *v9;
  this->table_.size_ = 0;
  this->table_.mlf_ = 1.0;
  *(_OWORD *)&this->table_.max_load_ = 0;
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<int>,int,boost::hash<int>,std::equal_to<int>>>::insert_range<int const*>(
    &this->table_,
    f,
    l);
}


// Address: 0x10d18f0 | Name: _ZN5boost9unordered13unordered_setIiNS_4hashIiEENSt3__18equal_toIiEENS4_9allocatorIiEEED2Ev
void __fastcall boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::~unordered_set(
        boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int> > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<int>,int,boost::hash<int>,std::equal_to<int> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x14001a0 | Name: _ZN5boost9unordered13unordered_setIPKN3RBX9PrimitiveENS_4hashIS5_EENSt3__18equal_toIS5_EENS8_9allocatorIS5_EEEC2IPPS3_EET_SH_
void __fastcall boost::unordered::unordered_set<RBX::Primitive const*,boost::hash<RBX::Primitive const*>,std::equal_to<RBX::Primitive const*>,std::allocator<RBX::Primitive const*>>::unordered_set<RBX::Primitive**>(
        boost::unordered::unordered_set<const RBX::Primitive *,boost::hash<const RBX::Primitive *>,std::equal_to<const RBX::Primitive *>,std::allocator<const RBX::Primitive *> > *this,
        RBX::Primitive **f,
        RBX::Primitive **l)
{
  unsigned __int64 v3; // rcx
  unsigned __int64 v4; // rax
  size_t v5; // rax
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax

  v3 = l - f + 1;
  v4 = 11;
  if ( v3 > 0xB )
    v4 = l - f + 1;
  this->table_.current_ = 0;
  if ( v4 >= 5 )
  {
    v6 = (v4 - 1) | ((v4 - 1) >> 1) | (((v4 - 1) | ((v4 - 1) >> 1)) >> 2);
    v7 = v6 | (v6 >> 4) | ((v6 | (v6 >> 4)) >> 8);
    v3 = v7 | (v7 >> 16);
    v5 = (v3 | HIDWORD(v3)) + 1;
  }
  else
  {
    v5 = 4;
  }
  this->table_.bucket_count_ = v5;
  this->table_.size_ = 0;
  this->table_.mlf_ = 1.0;
  *(_OWORD *)&this->table_.max_load_ = 0;
  if ( f != l )
    boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive const*>,RBX::Primitive const*,boost::hash<RBX::Primitive const*>,std::equal_to<RBX::Primitive const*>>>::insert_range_impl<RBX::Primitive**>(
      &this->table_,
      (boost::unordered::detail::no_key)f,
      l,
      (RBX::Primitive **)v3);
}


// Address: 0x1663830 | Name: _ZN5boost9unordered13unordered_setIPN3RBX9PrimitiveENS_4hashIS4_EENSt3__18equal_toIS4_EENS7_9allocatorIS4_EEEC2INS7_11__wrap_iterIPS4_EEEET_SH_
void __fastcall boost::unordered::unordered_set<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>,std::allocator<RBX::Primitive *>>::unordered_set<std::__wrap_iter<RBX::Primitive **>>(
        boost::unordered::unordered_set<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>,std::allocator<RBX::Primitive *> > *this,
        std::__wrap_iter<RBX::Primitive **> f,
        std::__wrap_iter<RBX::Primitive **> l)
{
  unsigned __int64 v4; // rax
  size_t v5; // rax
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  RBX::Primitive **i; // r15
  const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive *>,RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > >::key_type *v9; // rdx
  std::__wrap_iter<RBX::Primitive **> v10; // rcx
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive *>,RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > >::node_constructor a; // [rsp+8h] [rbp-40h] BYREF

  v4 = 11;
  if ( (unsigned __int64)(l.__i - f.__i + 1) > 0xB )
    v4 = l.__i - f.__i + 1;
  this->table_.current_ = 0;
  if ( v4 >= 5 )
  {
    v6 = (v4 - 1) | ((v4 - 1) >> 1) | (((v4 - 1) | ((v4 - 1) >> 1)) >> 2);
    v7 = v6 | (v6 >> 4) | ((v6 | (v6 >> 4)) >> 8);
    v5 = (v7 | (v7 >> 16) | ((v7 | (v7 >> 16)) >> 32)) + 1;
  }
  else
  {
    v5 = 4;
  }
  this->table_.bucket_count_ = v5;
  this->table_.size_ = 0;
  this->table_.mlf_ = 1.0;
  *(_OWORD *)&this->table_.max_load_ = 0;
  if ( f.__i != l.__i )
  {
    a.alloc_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<RBX::Primitive *> > >::node_allocator *)&this->table_.allocators_;
    a.node_ = 0;
    *(_WORD *)&a.node_constructed_ = 0;
    boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive *>,RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>>::insert_range_impl2<std::__wrap_iter<RBX::Primitive **>>(
      &this->table_,
      &a,
      f.__i,
      f,
      l);
    for ( i = f.__i + 1; l.__i != i; ++i )
    {
      v9 = i;
      v10.__i = i;
      boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive *>,RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>>::insert_range_impl2<std::__wrap_iter<RBX::Primitive **>>(
        &this->table_,
        &a,
        v9,
        v10,
        l);
    }
    if ( a.node_ )
      operator delete(a.node_);
  }
}


// Address: 0x184bee0 | Name: _ZN5boost9unordered13unordered_setIN3RBX7KeyCodeENS_4hashIS3_EENSt3__18equal_toIS3_EENS6_9allocatorIS3_EEEC2IPKS3_EET_SF_
void __fastcall boost::unordered::unordered_set<RBX::KeyCode,boost::hash<RBX::KeyCode>,std::equal_to<RBX::KeyCode>,std::allocator<RBX::KeyCode>>::unordered_set<RBX::KeyCode const*>(
        boost::unordered::unordered_set<RBX::KeyCode,boost::hash<RBX::KeyCode>,std::equal_to<RBX::KeyCode>,std::allocator<RBX::KeyCode> > *this,
        const RBX::KeyCode *f,
        const RBX::KeyCode *l)
{
  unsigned __int64 v3; // rax
  size_t v4; // rax
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rax

  v3 = 11;
  if ( (unsigned __int64)(l - f + 1) > 0xB )
    v3 = l - f + 1;
  this->table_.current_ = 0;
  if ( v3 >= 5 )
  {
    v5 = (v3 - 1) | ((v3 - 1) >> 1) | (((v3 - 1) | ((v3 - 1) >> 1)) >> 2);
    v6 = v5 | (v5 >> 4) | ((v5 | (v5 >> 4)) >> 8);
    v4 = (v6 | (v6 >> 16) | ((v6 | (v6 >> 16)) >> 32)) + 1;
  }
  else
  {
    v4 = 4;
  }
  this->table_.bucket_count_ = v4;
  this->table_.size_ = 0;
  this->table_.mlf_ = 1.0;
  *(_OWORD *)&this->table_.max_load_ = 0;
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::KeyCode>,RBX::KeyCode,boost::hash<RBX::KeyCode>,std::equal_to<RBX::KeyCode>>>::insert_range<RBX::KeyCode const*>(
    &this->table_,
    f,
    l);
}


// Address: 0x184bff0 | Name: _ZN5boost9unordered13unordered_setIN3RBX7KeyCodeENS_4hashIS3_EENSt3__18equal_toIS3_EENS6_9allocatorIS3_EEED2Ev
void __fastcall boost::unordered::unordered_set<RBX::KeyCode,boost::hash<RBX::KeyCode>,std::equal_to<RBX::KeyCode>,std::allocator<RBX::KeyCode>>::~unordered_set(
        boost::unordered::unordered_set<RBX::KeyCode,boost::hash<RBX::KeyCode>,std::equal_to<RBX::KeyCode>,std::allocator<RBX::KeyCode> > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<RBX::KeyCode>,RBX::KeyCode,boost::hash<RBX::KeyCode>,std::equal_to<RBX::KeyCode> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  buckets = this->table_.buckets_;
  if ( buckets )
  {
    if ( this->table_.size_ )
    {
      bucket_count = this->table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->table_.max_load_ = 0;
  }
}


// Address: 0x193bac0 | Name: _ZN3RBX14PhysicsService11onTouchStepERKNS_9TouchPairE
void __fastcall RBX::PhysicsService::onTouchStep(RBX::PhysicsService *this, const RBX::TouchPair *tp)
{
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::TouchPair>,RBX::TouchPair,boost::hash<RBX::TouchPair>,std::equal_to<RBX::TouchPair>>>::emplace_impl<RBX::TouchPair const&>(
    (boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::TouchPair>,RBX::TouchPair,boost::hash<RBX::TouchPair>,std::equal_to<RBX::TouchPair> > > *)((char *)this + 216),
    tp,
    tp);
}


// Address: 0x1b300f0 | Name: _ZN5boost9unordered13unordered_setINS_10shared_ptrIN3RBX11PackageLinkEEENS_4hashIS5_EENSt3__18equal_toIS5_EENS8_9allocatorIS5_EEE5clearEv
void __fastcall boost::unordered::unordered_set<boost::shared_ptr<RBX::PackageLink>,boost::hash<boost::shared_ptr<RBX::PackageLink>>,std::equal_to<boost::shared_ptr<RBX::PackageLink>>,std::allocator<boost::shared_ptr<RBX::PackageLink>>>::clear(
        boost::unordered::unordered_set<boost::shared_ptr<RBX::PackageLink>,boost::hash<boost::shared_ptr<RBX::PackageLink> >,std::equal_to<boost::shared_ptr<RBX::PackageLink> >,std::allocator<boost::shared_ptr<RBX::PackageLink> > > *this)
{
  size_t bucket_count; // r12
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<boost::shared_ptr<RBX::PackageLink> >,boost::shared_ptr<RBX::PackageLink>,boost::hash<boost::shared_ptr<RBX::PackageLink> >,std::equal_to<boost::shared_ptr<RBX::PackageLink> > > >::bucket_pointer buckets; // r13
  boost::unordered::detail::ptr_bucket *next; // rbx
  volatile signed __int32 *v4; // r15
  size_t v5; // rdx

  if ( this->table_.size_ )
  {
    bucket_count = this->table_.bucket_count_;
    buckets = this->table_.buckets_;
    next = buckets[bucket_count].next_;
    do
    {
      buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
      v4 = (volatile signed __int32 *)next[3].next_;
      if ( v4 )
      {
        if ( !_InterlockedSub(v4 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
          if ( !_InterlockedSub(v4 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        }
      }
      operator delete(next);
      --this->table_.size_;
      next = buckets[bucket_count].next_;
    }
    while ( next );
    v5 = this->table_.bucket_count_;
    if ( v5 )
      memset(this->table_.buckets_, 0, 8 * v5);
  }
}


// Address: 0x1b6df10 | Name: _ZN5boost9unordered13unordered_setIlNS_4hashIlEENSt3__18equal_toIlEENS4_9allocatorIlEEE6insertINS4_11__wrap_iterIPlEEEEvT_SE_
void __fastcall boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long>>::insert<std::__wrap_iter<long *>>(
        boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *this,
        std::__wrap_iter<long *> first,
        std::__wrap_iter<long *> last)
{
  __int64 *i; // rbx
  const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::key_type *v5; // rdx
  std::__wrap_iter<long *> v6; // rcx
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::node_constructor v7[2]; // [rsp+0h] [rbp-38h] BYREF

  if ( first.__i != last.__i )
  {
    v7[0].alloc_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<long> > >::node_allocator *)&this->table_.allocators_;
    v7[0].node_ = 0;
    *(_WORD *)&v7[0].node_constructed_ = 0;
    boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::insert_range_impl2<std::__wrap_iter<long *>>(
      &this->table_,
      v7,
      first.__i,
      first,
      last);
    for ( i = first.__i + 1; last.__i != i; ++i )
    {
      v5 = i;
      v6.__i = i;
      boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::insert_range_impl2<std::__wrap_iter<long *>>(
        &this->table_,
        v7,
        v5,
        v6,
        last);
    }
    if ( v7[0].node_ )
      operator delete(v7[0].node_);
  }
}


// Address: 0x1b840e0 | Name: _ZN5boost9unordered13unordered_setIN3RBX6Voxel26RegionENS2_12RegionHasherENSt3__18equal_toIS4_EENS6_9allocatorIS4_EEEC2INS6_11__wrap_iterIPS4_EEEET_SG_
void __fastcall boost::unordered::unordered_set<RBX::Voxel2::Region,RBX::RegionHasher,std::equal_to<RBX::Voxel2::Region>,std::allocator<RBX::Voxel2::Region>>::unordered_set<std::__wrap_iter<RBX::Voxel2::Region*>>(
        boost::unordered::unordered_set<RBX::Voxel2::Region,RBX::RegionHasher,std::equal_to<RBX::Voxel2::Region>,std::allocator<RBX::Voxel2::Region> > *this,
        std::__wrap_iter<RBX::Voxel2::Region *>_0 f,
        std::__wrap_iter<RBX::Voxel2::Region *>_0 l)
{
  unsigned __int64 v4; // rax
  size_t v5; // rax
  unsigned __int64 v6; // rax
  unsigned __int64 v7; // rax
  RBX::Voxel2::Region *i; // r15
  const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Voxel2::Region>,RBX::Voxel2::Region,RBX::RegionHasher,std::equal_to<RBX::Voxel2::Region> > >::key_type *v9; // rdx
  std::__wrap_iter<RBX::Voxel2::Region *>_0 v10; // rcx
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Voxel2::Region>,RBX::Voxel2::Region,RBX::RegionHasher,std::equal_to<RBX::Voxel2::Region> > >::node_constructor a; // [rsp+8h] [rbp-40h] BYREF

  v4 = 11;
  if ( 0xAAAAAAAAAAAAAAABLL * (((char *)l.__i - (char *)f.__i) >> 3) + 1 > 0xB )
    v4 = 0xAAAAAAAAAAAAAAABLL * (((char *)l.__i - (char *)f.__i) >> 3) + 1;
  this->table_.current_ = 0;
  if ( v4 >= 5 )
  {
    v6 = (v4 - 1) | ((v4 - 1) >> 1) | (((v4 - 1) | ((v4 - 1) >> 1)) >> 2);
    v7 = v6 | (v6 >> 4) | ((v6 | (v6 >> 4)) >> 8);
    v5 = (v7 | (v7 >> 16) | ((v7 | (v7 >> 16)) >> 32)) + 1;
  }
  else
  {
    v5 = 4;
  }
  this->table_.bucket_count_ = v5;
  this->table_.size_ = 0;
  this->table_.mlf_ = 1.0;
  *(_OWORD *)&this->table_.max_load_ = 0;
  if ( f.__i != l.__i )
  {
    a.alloc_ = (boost::unordered::detail::node_constructor<std::allocator<boost::unordered::detail::ptr_node<RBX::Voxel2::Region> > >::node_allocator *)&this->table_.allocators_;
    a.node_ = 0;
    *(_WORD *)&a.node_constructed_ = 0;
    boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Voxel2::Region>,RBX::Voxel2::Region,RBX::RegionHasher,std::equal_to<RBX::Voxel2::Region>>>::insert_range_impl2<std::__wrap_iter<RBX::Voxel2::Region*>>(
      &this->table_,
      &a,
      f.__i,
      f,
      l);
    for ( i = f.__i + 1; l.__i != i; ++i )
    {
      v9 = i;
      v10.__i = i;
      boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Voxel2::Region>,RBX::Voxel2::Region,RBX::RegionHasher,std::equal_to<RBX::Voxel2::Region>>>::insert_range_impl2<std::__wrap_iter<RBX::Voxel2::Region*>>(
        &this->table_,
        &a,
        v9,
        v10,
        l);
    }
    if ( a.node_ )
      operator delete(a.node_);
  }
}


// Address: 0x1c4d2d0 | Name: _ZN3RBX9Workspace40queueTriangleMeshPartForPhysicsMigrationEN5boost10shared_ptrINS_16TriangleMeshPartEEE
void __fastcall RBX::Workspace::queueTriangleMeshPartForPhysicsMigration(
        RBX::Workspace *this,
        boost::shared_ptr<RBX::TriangleMeshPart> tMeshPart)
{
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<boost::shared_ptr<RBX::TriangleMeshPart>>,boost::shared_ptr<RBX::TriangleMeshPart>,boost::hash<boost::shared_ptr<RBX::TriangleMeshPart>>,std::equal_to<boost::shared_ptr<RBX::TriangleMeshPart>>>>::emplace_impl<boost::shared_ptr<RBX::TriangleMeshPart> const&>(
    (boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<boost::shared_ptr<RBX::TriangleMeshPart> >,boost::shared_ptr<RBX::TriangleMeshPart>,boost::hash<boost::shared_ptr<RBX::TriangleMeshPart> >,std::equal_to<boost::shared_ptr<RBX::TriangleMeshPart> > > > *)((char *)this + 984),
    (const boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<boost::shared_ptr<RBX::TriangleMeshPart> >,boost::shared_ptr<RBX::TriangleMeshPart>,boost::hash<boost::shared_ptr<RBX::TriangleMeshPart> >,std::equal_to<boost::shared_ptr<RBX::TriangleMeshPart> > > >::key_type *)tMeshPart.px,
    (const boost::shared_ptr<RBX::TriangleMeshPart> *)tMeshPart.px);
}


// Address: 0x1c4e0a0 | Name: _ZN5boost9unordered13unordered_setINS_10shared_ptrIN3RBX16TriangleMeshPartEEENS_4hashIS5_EENSt3__18equal_toIS5_EENS8_9allocatorIS5_EEED2Ev
// attributes: thunk
void __fastcall boost::unordered::unordered_set<boost::shared_ptr<RBX::TriangleMeshPart>,boost::hash<boost::shared_ptr<RBX::TriangleMeshPart>>,std::equal_to<boost::shared_ptr<RBX::TriangleMeshPart>>,std::allocator<boost::shared_ptr<RBX::TriangleMeshPart>>>::~unordered_set(
        boost::unordered::unordered_set<boost::shared_ptr<RBX::TriangleMeshPart>,boost::hash<boost::shared_ptr<RBX::TriangleMeshPart> >,std::equal_to<boost::shared_ptr<RBX::TriangleMeshPart> >,std::allocator<boost::shared_ptr<RBX::TriangleMeshPart> > > *this)
{
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<boost::shared_ptr<RBX::TriangleMeshPart>>,boost::shared_ptr<RBX::TriangleMeshPart>,boost::hash<boost::shared_ptr<RBX::TriangleMeshPart>>,std::equal_to<boost::shared_ptr<RBX::TriangleMeshPart>>>>::~table(&this->table_);
}


// Address: 0x1dd79e0 | Name: _ZN3RBX14ContactManager20countAssemblyIslandsEv
int __fastcall RBX::ContactManager::countAssemblyIslands(RBX::ContactManager *this)
{
  return *((_DWORD *)this + 178);
}


