// Address: 0x261ebd0 | Name: boost::asio::detail::boost_asio_detail_posix_thread_function
void *__fastcall boost::asio::detail::boost_asio_detail_posix_thread_function(void *arg)
{
  (*(void (__fastcall **)(void *))(*(_QWORD *)arg + 16LL))(arg);
  (*(void (__fastcall **)(void *))(*(_QWORD *)arg + 8LL))(arg);
  return 0;
}


