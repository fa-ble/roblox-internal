// Address: 0xdb03a0 | Name: _ZN5boost11unique_lockINS_5mutexEE4lockEv
void __fastcall boost::unique_lock<boost::mutex>::lock(boost::unique_lock<boost::mutex> *this)
{
  boost::mutex *m; // rdi
  const boost::system::error_category *v3; // rbx
  const boost::system::error_category *v4; // rbx
  _QWORD v5[2]; // [rsp+0h] [rbp-48h] BYREF
  int v6; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v7; // [rsp+18h] [rbp-30h]
  __int128 v8; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  m = this->m;
  if ( !m )
  {
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost unique_lock has no mutex");
    v6 = 1;
    v7 = v3;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  if ( this->is_locked )
  {
    v4 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost unique_lock owns already the mutex");
    v6 = 35;
    v7 = v4;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  boost::mutex::lock(m);
  this->is_locked = 1;
}


// Address: 0xdcbdb0 | Name: _ZN5boost11unique_lockINS_5mutexEE6unlockEv
void __fastcall boost::unique_lock<boost::mutex>::unlock(boost::unique_lock<boost::mutex> *this)
{
  boost::mutex *m; // rdi
  const boost::system::error_category *v3; // rbx
  const boost::system::error_category *v4; // rbx
  _QWORD v5[2]; // [rsp+0h] [rbp-48h] BYREF
  int v6; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v7; // [rsp+18h] [rbp-30h]
  __int128 v8; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  m = this->m;
  if ( !m )
  {
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost unique_lock has no mutex");
    v6 = 1;
    v7 = v3;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  if ( !this->is_locked )
  {
    v4 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost unique_lock doesn't own the mutex");
    v6 = 1;
    v7 = v4;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  boost::mutex::unlock(m);
  this->is_locked = 0;
}


// Address: 0xf1cdc0 | Name: _ZN5boost22upgrade_to_unique_lockINS_12shared_mutexEED2Ev
void __fastcall boost::upgrade_to_unique_lock<boost::shared_mutex>::~upgrade_to_unique_lock(
        boost::upgrade_to_unique_lock<boost::shared_mutex> *this)
{
  boost::upgrade_lock<boost::shared_mutex> *source; // rax
  boost::unique_lock<boost::shared_mutex> *p_exclusive; // r14
  boost::shared_mutex *m; // r15
  bool is_locked; // bp
  boost::shared_mutex *v5; // rdi
  bool v6; // zf

  source = this->source;
  p_exclusive = &this->exclusive;
  if ( this->source )
  {
    m = this->exclusive.m;
    is_locked = this->exclusive.is_locked;
    if ( is_locked )
    {
      boost::shared_mutex::unlock_and_lock_upgrade(this->exclusive.m);
      source = this->source;
    }
    this->exclusive.is_locked = 0;
    this->exclusive.m = 0;
    v5 = source->m;
    source->m = m;
    v6 = !source->is_locked;
    source->is_locked = is_locked;
    if ( !v6 )
      boost::shared_mutex::unlock_upgrade(v5);
  }
  boost::unique_lock<boost::shared_mutex>::~unique_lock(p_exclusive);
}


// Address: 0xf1d570 | Name: _ZN5boost11unique_lockINS_12shared_mutexEED2Ev
void __fastcall boost::unique_lock<boost::shared_mutex>::~unique_lock(boost::unique_lock<boost::shared_mutex> *this)
{
  boost::shared_mutex *m; // rbx
  boost::unique_lock<boost::mutex> v2; // [rsp+8h] [rbp-20h] BYREF

  if ( this->is_locked )
  {
    m = this->m;
    v2.m = &this->m->state_change;
    v2.is_locked = 0;
    boost::unique_lock<boost::mutex>::lock(&v2);
    m->state.exclusive = 0;
    m->state.exclusive_waiting_blocked = 0;
    pthread_mutex_lock(&m->exclusive_cond.internal_mutex);
    pthread_cond_signal(&m->exclusive_cond.cond);
    pthread_mutex_unlock(&m->exclusive_cond.internal_mutex);
    pthread_mutex_lock(&m->shared_cond.internal_mutex);
    pthread_cond_broadcast(&m->shared_cond.cond);
    pthread_mutex_unlock(&m->shared_cond.internal_mutex);
    if ( v2.is_locked )
      boost::mutex::unlock(v2.m);
  }
}


// Address: 0xf1df10 | Name: _ZN5boost11shared_lockINS_12shared_mutexEE4lockEv
void __fastcall boost::shared_lock<boost::shared_mutex>::lock(boost::shared_lock<boost::shared_mutex> *this)
{
  boost::shared_mutex *m; // rdi
  const boost::system::error_category *v3; // rbx
  const boost::system::error_category *v4; // rbx
  _QWORD v5[2]; // [rsp+0h] [rbp-48h] BYREF
  int v6; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v7; // [rsp+18h] [rbp-30h]
  __int128 v8; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  m = this->m;
  if ( !m )
  {
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost shared_lock has no mutex");
    v6 = 1;
    v7 = v3;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  if ( this->is_locked )
  {
    v4 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost shared_lock owns already the mutex");
    v6 = 35;
    v7 = v4;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  boost::shared_mutex::lock_shared(m);
  this->is_locked = 1;
}


// Address: 0xf20290 | Name: _ZN5boost12upgrade_lockINS_12shared_mutexEE4lockEv
void __fastcall boost::upgrade_lock<boost::shared_mutex>::lock(boost::upgrade_lock<boost::shared_mutex> *this)
{
  boost::shared_mutex *m; // rdi
  const boost::system::error_category *v3; // rbx
  const boost::system::error_category *v4; // rbx
  _QWORD v5[2]; // [rsp+0h] [rbp-48h] BYREF
  int v6; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v7; // [rsp+18h] [rbp-30h]
  __int128 v8; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  m = this->m;
  if ( !m )
  {
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost shared_lock has no mutex");
    v6 = 1;
    v7 = v3;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  if ( this->is_locked )
  {
    v4 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost upgrade_lock owns already the mutex");
    v6 = 35;
    v7 = v4;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  boost::shared_mutex::lock_upgrade(m);
  this->is_locked = 1;
}


// Address: 0xf22d90 | Name: _ZN5boost11unique_lockINS_12shared_mutexEE4lockEv
void __fastcall boost::unique_lock<boost::shared_mutex>::lock(boost::unique_lock<boost::shared_mutex> *this)
{
  boost::shared_mutex *m; // rdi
  const boost::system::error_category *v3; // rbx
  const boost::system::error_category *v4; // rbx
  _QWORD v5[2]; // [rsp+0h] [rbp-48h] BYREF
  int v6; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v7; // [rsp+18h] [rbp-30h]
  __int128 v8; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  m = this->m;
  if ( !m )
  {
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost unique_lock has no mutex");
    v6 = 1;
    v7 = v3;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  if ( this->is_locked )
  {
    v4 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost unique_lock owns already the mutex");
    v6 = 35;
    v7 = v4;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  boost::shared_mutex::lock(m);
  this->is_locked = 1;
}


// Address: 0x12144d0 | Name: _ZN5boost11unique_lockINS_15recursive_mutexEE4lockEv
void __fastcall boost::unique_lock<boost::recursive_mutex>::lock(boost::unique_lock<boost::recursive_mutex> *this)
{
  boost::recursive_mutex *m; // rdi
  const boost::system::error_category *v3; // rbx
  const boost::system::error_category *v4; // rbx
  _QWORD v5[2]; // [rsp+0h] [rbp-48h] BYREF
  int v6; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v7; // [rsp+18h] [rbp-30h]
  __int128 v8; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  m = this->m;
  if ( !m )
  {
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost unique_lock has no mutex");
    v6 = 1;
    v7 = v3;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  if ( this->is_locked )
  {
    v4 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v5, "boost unique_lock owns already the mutex");
    v6 = 35;
    v7 = v4;
    v8 = 0;
    ptr = 0;
    v5[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v5);
  }
  pthread_mutex_lock(&m->m);
  this->is_locked = 1;
}


// Address: 0x1eb7660 | Name: _ZN5boost11unique_lockIN3rbx10spin_mutexEE4lockEv
void __fastcall boost::unique_lock<rbx::spin_mutex>::lock(boost::unique_lock<rbx::spin_mutex> *this)
{
  rbx::spin_mutex *m; // rcx
  const boost::system::error_category *v2; // rbx
  const boost::system::error_category *v3; // rbx
  _QWORD v4[2]; // [rsp+0h] [rbp-48h] BYREF
  int v5; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v6; // [rsp+18h] [rbp-30h]
  __int128 v7; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  m = this->m;
  if ( !this->m )
  {
    v2 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v4, "boost unique_lock has no mutex");
    v5 = 1;
    v6 = v2;
    v7 = 0;
    ptr = 0;
    v4[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v4);
  }
  if ( this->is_locked )
  {
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v4, "boost unique_lock owns already the mutex");
    v5 = 35;
    v6 = v3;
    v7 = 0;
    ptr = 0;
    v4[0] = off_28763C8;
    boost::throw_exception<boost::lock_error>((const boost::lock_error *)v4);
  }
  while ( _InterlockedCompareExchange(&m->sl.v, 1, 0) )
    ;
  this->is_locked = 1;
}


