// Address: 0x261b250 | Name: _ZN5boost4asio15basic_streambufINSt3__19allocatorIcEEED2Ev
void __fastcall boost::asio::basic_streambuf<std::allocator<char>>::~basic_streambuf(
        boost::asio::basic_streambuf<std::allocator<char> > *this)
{
  void *v2; // rdi

  *(_QWORD *)this = &off_29C3BB8;
  v2 = (void *)*((_QWORD *)this + 9);
  if ( v2 )
  {
    *((_QWORD *)this + 10) = v2;
    operator delete(v2);
  }
  std::streambuf::~streambuf();
}


// Address: 0x261b280 | Name: _ZN5boost4asio15basic_streambufINSt3__19allocatorIcEEED0Ev
void __fastcall boost::asio::basic_streambuf<std::allocator<char>>::~basic_streambuf(
        boost::asio::basic_streambuf<std::allocator<char> > *this)
{
  void *v2; // rdi

  *(_QWORD *)this = &off_29C3BB8;
  v2 = (void *)*((_QWORD *)this + 9);
  if ( v2 )
  {
    *((_QWORD *)this + 10) = v2;
    operator delete(v2);
  }
  std::streambuf::~streambuf();
  operator delete(this);
}


// Address: 0x261b2f0 | Name: _ZN5boost4asio15basic_streambufINSt3__19allocatorIcEEE8overflowEi
std::streambuf::int_type __fastcall boost::asio::basic_streambuf<std::allocator<char>>::overflow(
        boost::asio::basic_streambuf<std::allocator<char> > *this,
        std::streambuf::int_type c)
{
  std::streambuf::int_type v2; // ebp
  __int64 v3; // rax
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rsi
  bool v6; // cc
  size_t v7; // rsi

  if ( c == -1 )
    return 0;
  v2 = c;
  v3 = *((_QWORD *)this + 6);
  if ( v3 == *((_QWORD *)this + 7) )
  {
    v4 = v3 - *((_QWORD *)this + 3);
    v5 = *((_QWORD *)this + 8);
    v6 = v5 <= v4;
    v7 = v5 - v4;
    if ( v6 || v7 > 0x7F )
      v7 = 128;
    boost::asio::basic_streambuf<std::allocator<char>>::reserve(this, v7);
  }
  *(_BYTE *)(*((_QWORD *)this + 6))++ = v2;
  return v2;
}


// Address: 0x261b340 | Name: _ZN5boost4asio15basic_streambufINSt3__19allocatorIcEEE7reserveEm
void __fastcall boost::asio::basic_streambuf<std::allocator<char>>::reserve(
        boost::asio::basic_streambuf<std::allocator<char> > *this,
        size_t n)
{
  __int64 v3; // r14
  void *v4; // rdi
  size_t v5; // r14
  size_t v6; // rbx
  size_t v7; // rax
  __int64 v8; // rcx
  size_t v9; // rax
  bool v10; // cf
  size_t v11; // rax
  unsigned __int64 v12; // rax
  __int64 v13; // rcx
  unsigned __int64 v14; // rdx
  __int64 v15; // rax
  size_t v16; // r14
  _QWORD v17[6]; // [rsp+8h] [rbp-30h] BYREF

  v3 = *((_QWORD *)this + 6);
  v4 = (void *)*((_QWORD *)this + 9);
  v5 = v3 - (_QWORD)v4;
  v6 = *((_QWORD *)this + 7) - (_QWORD)v4;
  v7 = v6 - v5;
  if ( v6 - v5 < n )
  {
    v8 = *((_QWORD *)this + 3) - (_QWORD)v4;
    if ( v8 )
    {
      v5 -= v8;
      memmove(v4, *((const void **)this + 3), v5);
      v7 = v6 - v5;
    }
    if ( v7 < n )
    {
      v9 = *((_QWORD *)this + 8);
      v10 = v9 < n;
      v11 = v9 - n;
      if ( v10 || v5 > v11 )
      {
        std::logic_error::logic_error((std::logic_error *)v17, "boost::asio::streambuf too long");
        v17[0] = (char *)&`vtable for'std::length_error + 16;
        boost::throw_exception<std::length_error>((const std::length_error *)v17);
      }
      v12 = 1;
      if ( v5 + n )
        v12 = v5 + n;
      v13 = *((_QWORD *)this + 9);
      v14 = *((_QWORD *)this + 10) - v13;
      if ( v12 <= v14 )
      {
        if ( v12 < v14 )
          *((_QWORD *)this + 10) = v12 + v13;
      }
      else
      {
        std::vector<char>::__append(
          (boost::asio::basic_streambuf<std::allocator<char> > *)((char *)this + 72),
          v12 - v14);
      }
      v6 = v5 + n;
    }
    v15 = *((_QWORD *)this + 9);
    v16 = v15 + v5;
    *((_QWORD *)this + 2) = v15;
    *((_QWORD *)this + 3) = v15;
    *((_QWORD *)this + 4) = v16;
    *((_QWORD *)this + 6) = v16;
    *((_QWORD *)this + 5) = v16;
    *((_QWORD *)this + 7) = v15 + v6;
  }
}


