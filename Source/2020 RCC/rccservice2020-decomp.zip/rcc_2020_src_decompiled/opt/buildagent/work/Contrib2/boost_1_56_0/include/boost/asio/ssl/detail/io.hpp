// Address: 0x2609450 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::shutdown_op *op,
        std::function<void (const boost::system::error_code &)> *handler)
{
  std::function<void (const boost::system::error_code &)> *f; // rdi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > v6; // [rsp+0h] [rbp-88h] BYREF
  unsigned __int64 v7; // [rsp+70h] [rbp-18h]
  boost::system::error_code v8; // 0:esi.4,8:rdx.8

  v7 = __readfsqword(0x28u);
  v6.next_layer_ = next_layer;
  v6.core_ = core;
  *(_QWORD *)&v6.start_ = 0;
  v6.ec_.m_val = 0;
  v6.ec_.m_cat = boost::system::system_category();
  v6.bytes_transferred_ = 0;
  f = (std::function<void (const boost::system::error_code &)> *)handler->__f_;
  if ( f )
  {
    if ( handler == f )
    {
      v6.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&v6.handler_;
      (*(void (__fastcall **)(std::function<void (const boost::system::error_code &)> *, std::function<void (const boost::system::error_code &)> *))(*(_QWORD *)f->__buf_.__lx + 24LL))(
        f,
        &v6.handler_);
    }
    else
    {
      v6.handler_.__f_ = handler->__f_;
      handler->__f_ = 0;
    }
  }
  else
  {
    v6.handler_.__f_ = 0;
  }
  v8.m_val = 0;
  v8.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>::operator()(
    &v6,
    v8,
    0,
    1);
  if ( &v6.handler_ == (std::function<void (const boost::system::error_code &)> *)v6.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v6.handler_.__f_->_vptr$__base
     + 4))(v6.handler_.__f_);
  }
  else if ( v6.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *, _QWORD))v6.handler_.__f_->_vptr$__base
     + 5))(
      v6.handler_.__f_,
      0);
  }
}


// Address: 0x2609560 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEclESE_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  size_t *p_ec; // r9
  boost::asio::ssl::detail::stream_core *core; // rdi
  boost::asio::ssl::detail::engine::want v9; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v11; // rbp
  boost::asio::ssl::detail::stream_core *v12; // rbp
  unsigned __int64 v13; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rdx
  boost::asio::ssl::detail::stream_core *v17; // rax
  boost::asio::ssl::detail::stream_core *v18; // rax
  size_t v19; // rdx
  boost::asio::ssl::detail::stream_core *v20; // rbp
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rdx
  boost::asio::ssl::detail::stream_core *v25; // rax
  boost::asio::ssl::detail::stream_core *v26; // rbp
  boost::asio::ssl::detail::stream_core *v27; // rdi
  boost::system::error_code *v28; // rsi
  boost::asio::ssl::detail::stream_core *v29; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v30; // r14
  boost::asio::ssl::detail::stream_core *v31; // rbp
  int v32; // eax
  size_t v33; // rcx
  boost::asio::ssl::detail::stream_core *v34; // rbp
  const boost::system::error_code *v35; // rax
  std::function<void (const boost::system::error_code &)>::__base *f; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v37; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v38; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rsi
  _QWORD *exception; // rax
  boost::asio::mutable_buffers_1 buffers; // [rsp+10h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+20h] [rbp-38h]

  m_cat = ec.m_cat;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_7;
  p_ec = (size_t *)&this->ec_;
  while ( 1 )
  {
    core = this->core_;
    this->bytes_transferred_ = 0;
    v9 = boost::asio::ssl::detail::engine::perform(
           (boost::asio::ssl::detail::engine *)core,
           boost::asio::ssl::detail::engine::do_shutdown,
           0,
           0,
           0,
           p_ec);
    this->want_ = v9;
    if ( v9 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v12 = this->core_;
      if ( *((_QWORD *)v12 + 29) )
      {
        v13 = BIO_write(*((_QWORD *)v12 + 1), *((_QWORD *)v12 + 28));
        v14 = 0;
        if ( (v13 & 0x80000000) != 0LL )
          v13 = 0;
        v15 = *((_QWORD *)v12 + 29);
        if ( v15 >= v13 )
          v14 = v13 + *((_QWORD *)v12 + 28);
        else
          v15 = v13;
        v16 = v15 - v13;
        v17 = this->core_;
        *((_QWORD *)v17 + 28) = v14;
        *((_QWORD *)v17 + 29) = v16;
        goto LABEL_33;
      }
      if ( *((_QWORD *)v12 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v12 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v12 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v12 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v12
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v12 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v12 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        buffers = (boost::asio::mutable_buffers_1)*((_OWORD *)this->core_ + 13);
        goto LABEL_56;
      }
      v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v12 + 2);
      v38 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v12 + 24);
LABEL_58:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
        v37,
        v38,
        this);
      return;
    }
    if ( v9 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v9 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      buffers.data_ = (void *)*((_QWORD *)this->core_ + 26);
      buffers.size_ = 0;
LABEL_56:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
        next_layer->service_,
        &next_layer->implementation,
        &buffers,
        0,
        this);
      return;
    }
LABEL_7:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = ec.m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v18 = this->core_;
      v19 = *((_QWORD *)v18 + 27);
      if ( v19 >= bytes_transferred )
        v19 = bytes_transferred;
      *((_QWORD *)v18 + 28) = *((_QWORD *)v18 + 26);
      *((_QWORD *)v18 + 29) = v19;
      v20 = this->core_;
      v21 = BIO_write(*((_QWORD *)v20 + 1), *((_QWORD *)v20 + 28));
      v22 = 0;
      if ( (v21 & 0x80000000) != 0LL )
        v21 = 0;
      v23 = *((_QWORD *)v20 + 29);
      if ( v23 >= v21 )
        v22 = v21 + *((_QWORD *)v20 + 28);
      else
        v23 = v21;
      v24 = v23 - v21;
      v25 = this->core_;
      *((_QWORD *)v25 + 28) = v22;
      *((_QWORD *)v25 + 29) = v24;
      v26 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v26 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v26 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v26 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v26
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v26 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v26 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v34 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v34 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v34 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v34 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v34 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v34 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v34 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v27 = this->core_;
        v28 = &this->ec_;
        goto LABEL_48;
      }
      v11 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v11 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v11 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v11 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v11 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v11 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v11 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_33:
    p_ec = (size_t *)&this->ec_;
    if ( this->ec_.m_val )
    {
      v27 = this->core_;
      v28 = &this->ec_;
LABEL_48:
      v35 = boost::asio::ssl::detail::engine::map_error_code((const boost::asio::ssl::detail::engine *)v27, v28);
      f = this->handler_.__f_;
      if ( !f )
      {
        exception = __cxa_allocate_exception(8u);
        *exception = off_28852C8;
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'std::bad_function_call,
          (void (*)(void *))&std::exception::~exception);
      }
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *, const boost::system::error_code *))f->_vptr$__base
       + 6))(
        f,
        v35);
      return;
    }
  }
  v29 = this->core_;
  if ( *((_QWORD *)v29 + 11) != 0x8000000000000000LL )
  {
    v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v29 + 10);
    v38 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v29 + 88);
    goto LABEL_58;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v29 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v29 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v29 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v29 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v29 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v29 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v30 = this->next_layer_;
  v31 = this->core_;
  v32 = BIO_read(*((_QWORD *)v31 + 1), *((_QWORD *)v31 + 21), *((unsigned int *)v31 + 44));
  v33 = 0;
  if ( v32 >= 0 )
    v33 = (unsigned int)v32;
  if ( *((_QWORD *)v31 + 22) < v33 )
    v33 = *((_QWORD *)v31 + 22);
  buffers.data_ = (void *)*((_QWORD *)v31 + 21);
  buffers.size_ = v33;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
    v30,
    &buffers,
    this);
}


// Address: 0x2611fa0 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_8write_opINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISD_NSE_9allocatorISD_EEEEEEEENSB_8write_opINS1_6streamIS9_EESI_NSB_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSE_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > > *op,
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *v5; // rdi
  _QWORD v6[2]; // [rsp+0h] [rbp-138h] BYREF
  void *v7[9]; // [rsp+10h] [rbp-128h] BYREF
  int v8; // [rsp+58h] [rbp-E0h]
  const boost::system::error_category *v9; // [rsp+60h] [rbp-D8h]
  __int64 v10; // [rsp+68h] [rbp-D0h]
  __int64 v11; // [rsp+70h] [rbp-C8h]
  void *ptr[8]; // [rsp+78h] [rbp-C0h] BYREF
  int v13; // [rsp+B8h] [rbp-80h]
  __int64 v14; // [rsp+C0h] [rbp-78h]
  __int64 v15; // [rsp+D0h] [rbp-68h]
  _BYTE v16[32]; // [rsp+E0h] [rbp-58h] BYREF
  _BYTE *v17; // [rsp+100h] [rbp-38h]
  unsigned __int64 v18; // [rsp+118h] [rbp-20h]
  boost::system::error_code v19; // 0:esi.4,8:rdx.8

  v18 = __readfsqword(0x28u);
  v6[0] = next_layer;
  v6[1] = core;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)v7,
    op);
  v7[8] = 0;
  v8 = 0;
  v9 = boost::system::system_category();
  v10 = 0;
  v11 = *(_QWORD *)handler;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)handler + 8));
  v13 = *((_DWORD *)handler + 18);
  v14 = *((_QWORD *)handler + 10);
  v15 = *((_QWORD *)handler + 12);
  v5 = (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)*((_QWORD *)handler + 18);
  if ( v5 )
  {
    if ( (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)handler + 112) == v5 )
    {
      v17 = v16;
      (*(void (__fastcall **)(boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *, _BYTE *))(*(_QWORD *)v5 + 24LL))(
        v5,
        v16);
    }
    else
    {
      v17 = (_BYTE *)*((_QWORD *)handler + 18);
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    v17 = 0;
  }
  v19.m_val = 0;
  v19.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v6,
    v19,
    0,
    1);
  if ( v16 == v17 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v17 + 32LL))(v17);
  }
  else if ( v17 )
  {
    (*(void (__fastcall **)(_BYTE *, _QWORD))(*(_QWORD *)v17 + 40LL))(v17, 0);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  if ( v7[0] )
  {
    v7[1] = v7[0];
    operator delete(v7[0]);
  }
}


// Address: 0x2612250 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_8write_opINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISD_NSE_9allocatorISD_EEEEEEEENSB_8write_opINS1_6streamIS9_EESI_NSB_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSE_8functionIFvRKNS_6system10error_codeEmEEEEEEEEclESV_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  boost::system::error_code *v7; // rdx
  boost::asio::ssl::detail::engine *v8; // rdi
  size_t v9; // rbp
  void *v10; // r8
  size_t v11; // rsi
  __int64 v12; // rax
  const void **v13; // rbx
  boost::asio::ssl::detail::engine::want v14; // eax
  int v15; // eax
  __int64 v16; // rbp
  __int64 v17; // rbp
  unsigned __int64 v18; // rax
  unsigned __int64 v19; // rcx
  unsigned __int64 v20; // rdx
  unsigned __int64 v21; // rdx
  __int64 v22; // rax
  _QWORD *v23; // rax
  size_t v24; // rdx
  _QWORD *v25; // rbx
  unsigned __int64 v26; // rax
  unsigned __int64 v27; // rcx
  unsigned __int64 v28; // rdx
  unsigned __int64 v29; // rdx
  __int64 v30; // rax
  __int64 v31; // rbp
  const boost::system::error_code *v32; // rax
  size_t v33; // rdx
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *v34; // rdi
  __int64 v35; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v36; // rbp
  _QWORD *v37; // rbx
  int v38; // eax
  size_t v39; // rcx
  __int64 v40; // rbp
  boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *v41; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v42; // rdi
  boost::asio::mutable_buffers_1 v43; // [rsp+0h] [rbp-58h] BYREF
  int m_val; // [rsp+1Ch] [rbp-3Ch]
  const boost::system::error_category *m_cat; // [rsp+20h] [rbp-38h]

  m_cat = ec.m_cat;
  m_val = ec.m_val;
  *((_DWORD *)this + 20) = start;
  if ( start != 1 )
    goto LABEL_21;
  v7 = (boost::system::error_code *)((char *)this + 88);
  while ( 1 )
  {
    v8 = (boost::asio::ssl::detail::engine *)*((_QWORD *)this + 1);
    v9 = *((_QWORD *)this + 9);
    if ( *((_BYTE *)this + 40) | (v9 == 0) )
    {
      v10 = 0;
LABEL_5:
      v11 = 0;
      goto LABEL_17;
    }
    v11 = *((_QWORD *)this + 7);
    if ( v11 >= v9 )
      v11 = *((_QWORD *)this + 9);
    if ( !v11 )
    {
      v12 = *((_QWORD *)this + 8);
      v10 = 0;
      while ( v9 )
      {
        v13 = (const void **)v12;
        v11 = 0;
        if ( *((_QWORD *)this + 3) == v12 )
          goto LABEL_17;
        v11 = *(_QWORD *)(v12 + 8);
        if ( v11 >= v9 )
          v11 = *((_QWORD *)this + 9);
        v12 += 16;
        if ( v11 )
        {
          v10 = (void *)*v13;
          goto LABEL_17;
        }
      }
      goto LABEL_5;
    }
    v10 = (void *)*((_QWORD *)this + 6);
LABEL_17:
    v43.data_ = v10;
    v43.size_ = v11;
    v14 = boost::asio::ssl::detail::engine::write(v8, (const boost::asio::const_buffer *)&v43, v7, (size_t *)this + 13);
    *((_DWORD *)this + 21) = v14;
    if ( v14 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v17 = *((_QWORD *)this + 1);
      if ( *(_QWORD *)(v17 + 232) )
      {
        v18 = BIO_write(*(_QWORD *)(v17 + 8), *(_QWORD *)(v17 + 224));
        v19 = 0;
        if ( (v18 & 0x80000000) != 0LL )
          v18 = 0;
        v20 = *(_QWORD *)(v17 + 232);
        if ( v20 >= v18 )
          v19 = v18 + *(_QWORD *)(v17 + 224);
        else
          v20 = v18;
        v21 = v20 - v18;
        v22 = *((_QWORD *)this + 1);
        *(_QWORD *)(v22 + 224) = v19;
        *(_QWORD *)(v22 + 232) = v21;
        goto LABEL_47;
      }
      if ( *(_QWORD *)(v17 + 24) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *(_BYTE *)(v17 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v17 + 16) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v17 + 16) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v17 + 40),
            0xFFFFFFFFFFFFFFFFLL);
          *(_BYTE *)(v17 + 32) = 0;
        }
        boost::system::system_category();
        *(_QWORD *)(v17 + 24) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        v42 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
        v43 = *(boost::asio::mutable_buffers_1 *)(*((_QWORD *)this + 1) + 208LL);
        goto LABEL_69;
      }
      v41 = (boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *)(v17 + 16);
LABEL_74:
      boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        v41,
        this);
      return;
    }
    if ( v14 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v14 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      v42 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
      v43 = (boost::asio::mutable_buffers_1)*(unsigned __int64 *)(*((_QWORD *)this + 1) + 208LL);
LABEL_69:
      boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        v42,
        &v43,
        this);
      return;
    }
LABEL_21:
    if ( bytes_transferred != -1 && !*((_DWORD *)this + 22) )
    {
      *((_DWORD *)this + 22) = m_val;
      *((_QWORD *)this + 12) = m_cat;
    }
    v15 = *((_DWORD *)this + 21);
    if ( v15 == -2 )
    {
      v23 = (_QWORD *)*((_QWORD *)this + 1);
      v24 = v23[27];
      if ( v24 >= bytes_transferred )
        v24 = bytes_transferred;
      v23[28] = v23[26];
      v23[29] = v24;
      v25 = (_QWORD *)*((_QWORD *)this + 1);
      v26 = BIO_write(v25[1], v25[28]);
      v27 = 0;
      if ( (v26 & 0x80000000) != 0LL )
        v26 = 0;
      v28 = v25[29];
      if ( v28 >= v26 )
        v27 = v26 + v25[28];
      else
        v28 = v26;
      v29 = v28 - v26;
      v30 = *((_QWORD *)this + 1);
      *(_QWORD *)(v30 + 224) = v27;
      *(_QWORD *)(v30 + 232) = v29;
      v31 = *((_QWORD *)this + 1);
      boost::system::system_category();
      if ( *(_BYTE *)(v31 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v31 + 16) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v31 + 16)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v31 + 40),
          0xFFFFFFFFFFFFFFFFLL);
        *(_BYTE *)(v31 + 32) = 0;
      }
      boost::system::system_category();
      *(_QWORD *)(v31 + 24) = 0x8000000000000000LL;
    }
    else
    {
      if ( v15 != -1 )
      {
        if ( v15 == 1 )
        {
          v40 = *((_QWORD *)this + 1);
          boost::system::system_category();
          if ( *(_BYTE *)(v40 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v40 + 80) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v40 + 80) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v40 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *(_BYTE *)(v40 + 96) = 0;
          }
          boost::system::system_category();
          *(_QWORD *)(v40 + 88) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v32 = boost::asio::ssl::detail::engine::map_error_code(
                *((const boost::asio::ssl::detail::engine **)this + 1),
                (boost::system::error_code *)((char *)this + 88));
        if ( *((_DWORD *)this + 22) )
          v33 = 0;
        else
          v33 = *((_QWORD *)this + 13);
        v34 = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)this + 112);
        goto LABEL_72;
      }
      v16 = *((_QWORD *)this + 1);
      boost::system::system_category();
      if ( *(_BYTE *)(v16 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v16 + 80) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v16 + 80)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v16 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *(_BYTE *)(v16 + 96) = 0;
      }
      boost::system::system_category();
      *(_QWORD *)(v16 + 88) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_47:
    v7 = (boost::system::error_code *)((char *)this + 88);
    if ( *((_DWORD *)this + 22) )
    {
      v32 = boost::asio::ssl::detail::engine::map_error_code(*((const boost::asio::ssl::detail::engine **)this + 1), v7);
      v33 = 0;
      v34 = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)this + 112);
LABEL_72:
      boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>::operator()(
        v34,
        v32,
        v33,
        0);
      return;
    }
  }
  v35 = *((_QWORD *)this + 1);
  if ( *(_QWORD *)(v35 + 88) != 0x8000000000000000LL )
  {
    v41 = (boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *)(v35 + 80);
    goto LABEL_74;
  }
  boost::system::system_category();
  if ( *(_BYTE *)(v35 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v35 + 80) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v35 + 80)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v35 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *(_BYTE *)(v35 + 96) = 0;
  }
  boost::system::system_category();
  *(_QWORD *)(v35 + 88) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v36 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  v37 = (_QWORD *)*((_QWORD *)this + 1);
  v38 = BIO_read(v37[1], v37[21], *((unsigned int *)v37 + 44));
  v39 = 0;
  if ( v38 >= 0 )
    v39 = (unsigned int)v38;
  if ( v37[22] < v39 )
    v39 = v37[22];
  v43.data_ = (void *)v37[21];
  v43.size_ = v39;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
    v36,
    &v43,
    this);
}


// Address: 0x2612ee0 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_8write_opINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISD_NSE_9allocatorISD_EEEEEEEENSB_8write_opINS1_6streamIS9_EESI_NSB_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSE_8functionIFvRKNS_6system10error_codeEmEEEEEEEEC2EOS12_
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *this,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *other)
{
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *v2; // rax

  *(_QWORD *)this = *(_QWORD *)other;
  *((_QWORD *)this + 1) = *((_QWORD *)other + 1);
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)this + 16),
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)other + 16));
  *((_DWORD *)this + 20) = *((_DWORD *)other + 20);
  *((_DWORD *)this + 21) = *((_DWORD *)other + 21);
  *(_OWORD *)((char *)this + 88) = *(_OWORD *)((char *)other + 88);
  *(_OWORD *)((char *)this + 104) = *(_OWORD *)((char *)other + 104);
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)this + 120),
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)other + 120));
  *((_DWORD *)this + 46) = *((_DWORD *)other + 46);
  *((_QWORD *)this + 24) = *((_QWORD *)other + 24);
  *((_QWORD *)this + 26) = *((_QWORD *)other + 26);
  v2 = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)*((_QWORD *)other + 32);
  if ( v2 )
  {
    if ( (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)((char *)other + 224) == v2 )
    {
      *((_QWORD *)this + 32) = (char *)this + 224;
      (*(void (__fastcall **)(_QWORD))(**((_QWORD **)other + 32) + 24LL))(*((_QWORD *)other + 32));
    }
    else
    {
      *((_QWORD *)this + 32) = v2;
      *((_QWORD *)other + 32) = 0;
    }
  }
  else
  {
    *((_QWORD *)this + 32) = 0;
  }
}


// Address: 0x2615b80 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail7read_opINS1_6streamIS9_EESB_NSD_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *op,
        boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *f; // rdi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > v10; // [rsp+0h] [rbp-C8h] BYREF
  unsigned __int64 v11; // [rsp+B0h] [rbp-18h]
  boost::system::error_code v12; // 0:esi.4,8:rdx.8

  v11 = __readfsqword(0x28u);
  v10.next_layer_ = next_layer;
  v10.core_ = core;
  v10.op_ = *op;
  *(_QWORD *)&v10.start_ = 0;
  v10.ec_.m_val = 0;
  v10.ec_.m_cat = boost::system::system_category();
  v10.bytes_transferred_ = 0;
  *(_OWORD *)&v10.handler_.completion_condition_.minimum_ = *(_OWORD *)&handler->completion_condition_.minimum_;
  v10.handler_.buffer_ = handler->buffer_;
  v10.handler_.start_ = handler->start_;
  *(_OWORD *)&v10.handler_.total_transferred_ = *(_OWORD *)&handler->total_transferred_;
  f = (boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)handler->handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v10.handler_.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v10.handler_.handler_.handler_;
      (*(void (__fastcall **)(boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *, std::function<void (const boost::system::error_code &,unsigned long)> *, __int64, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, int, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *, void *, size_t, int, size_t, websocketpp::transport::asio::handler_allocator *))(f->completion_condition_.minimum_ + 24))(
        f,
        &v10.handler_.handler_.handler_,
        v5,
        v6,
        v7,
        v8,
        v10.next_layer_,
        v10.core_,
        v10.op_.buffers_.data_,
        v10.op_.buffers_.size_,
        *(_QWORD *)&v10.start_,
        v10.ec_.m_val,
        v10.ec_.m_cat,
        v10.bytes_transferred_,
        v10.handler_.completion_condition_.minimum_,
        v10.handler_.stream_,
        v10.handler_.buffer_.data_,
        v10.handler_.buffer_.size_,
        v10.handler_.start_,
        v10.handler_.total_transferred_,
        v10.handler_.handler_.allocator_);
    }
    else
    {
      v10.handler_.handler_.handler_.__f_ = handler->handler_.handler_.__f_;
      handler->handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    v10.handler_.handler_.handler_.__f_ = 0;
  }
  v12.m_val = 0;
  v12.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
    &v10,
    v12,
    0,
    1);
  if ( &v10.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v10.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v10.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(v10.handler_.handler_.handler_.__f_);
  }
  else if ( v10.handler_.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v10.handler_.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x2615ce0 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail7read_opINS1_6streamIS9_EESB_NSD_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEclESP_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  boost::system::error_code *p_ec; // rdx
  boost::asio::ssl::detail::stream_core *core; // rdi
  boost::asio::ssl::detail::engine::want v9; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v11; // rbp
  boost::asio::ssl::detail::stream_core *v12; // rbp
  unsigned __int64 v13; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rdx
  boost::asio::ssl::detail::stream_core *v17; // rax
  boost::asio::ssl::detail::stream_core *v18; // rax
  size_t v19; // rdx
  boost::asio::ssl::detail::stream_core *v20; // rbp
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rdx
  boost::asio::ssl::detail::stream_core *v25; // rax
  boost::asio::ssl::detail::stream_core *v26; // rbp
  const boost::system::error_code *v27; // rax
  size_t v28; // rdx
  boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *p_handler; // rdi
  boost::asio::ssl::detail::stream_core *v30; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v31; // r14
  boost::asio::ssl::detail::stream_core *v32; // rbp
  int v33; // eax
  size_t v34; // rcx
  boost::asio::ssl::detail::stream_core *v35; // rbp
  boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *v36; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rdi
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> op; // [rsp+0h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+10h] [rbp-38h]

  m_cat = ec.m_cat;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_7;
  p_ec = &this->ec_;
  while ( 1 )
  {
    core = this->core_;
    op = this->op_;
    v9 = boost::asio::ssl::detail::engine::read(
           (boost::asio::ssl::detail::engine *)core,
           &op.buffers_,
           p_ec,
           &this->bytes_transferred_);
    this->want_ = v9;
    if ( v9 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v12 = this->core_;
      if ( *((_QWORD *)v12 + 29) )
      {
        v13 = BIO_write(*((_QWORD *)v12 + 1), *((_QWORD *)v12 + 28));
        v14 = 0;
        if ( (v13 & 0x80000000) != 0LL )
          v13 = 0;
        v15 = *((_QWORD *)v12 + 29);
        if ( v15 >= v13 )
          v14 = v13 + *((_QWORD *)v12 + 28);
        else
          v15 = v13;
        v16 = v15 - v13;
        v17 = this->core_;
        *((_QWORD *)v17 + 28) = v14;
        *((_QWORD *)v17 + 29) = v16;
        goto LABEL_33;
      }
      if ( *((_QWORD *)v12 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v12 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v12 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v12 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v12
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v12 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v12 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        op = (boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>)*((_OWORD *)this->core_ + 13);
        goto LABEL_55;
      }
      v36 = (boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *)((char *)v12 + 16);
LABEL_60:
      boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        v36,
        this);
      return;
    }
    if ( v9 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v9 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      op = (boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>)*((unsigned __int64 *)this->core_ + 26);
LABEL_55:
      boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_read_some<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        next_layer,
        &op.buffers_,
        this);
      return;
    }
LABEL_7:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = ec.m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v18 = this->core_;
      v19 = *((_QWORD *)v18 + 27);
      if ( v19 >= bytes_transferred )
        v19 = bytes_transferred;
      *((_QWORD *)v18 + 28) = *((_QWORD *)v18 + 26);
      *((_QWORD *)v18 + 29) = v19;
      v20 = this->core_;
      v21 = BIO_write(*((_QWORD *)v20 + 1), *((_QWORD *)v20 + 28));
      v22 = 0;
      if ( (v21 & 0x80000000) != 0LL )
        v21 = 0;
      v23 = *((_QWORD *)v20 + 29);
      if ( v23 >= v21 )
        v22 = v21 + *((_QWORD *)v20 + 28);
      else
        v23 = v21;
      v24 = v23 - v21;
      v25 = this->core_;
      *((_QWORD *)v25 + 28) = v22;
      *((_QWORD *)v25 + 29) = v24;
      v26 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v26 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v26 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v26 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v26
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v26 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v26 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v35 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v35 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v35 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v35 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v35 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v35 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v35 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v27 = boost::asio::ssl::detail::engine::map_error_code(
                (const boost::asio::ssl::detail::engine *)this->core_,
                &this->ec_);
        if ( this->ec_.m_val )
          v28 = 0;
        else
          v28 = this->bytes_transferred_;
        p_handler = &this->handler_;
        goto LABEL_58;
      }
      v11 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v11 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v11 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v11 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v11 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v11 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v11 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_33:
    p_ec = &this->ec_;
    if ( this->ec_.m_val )
    {
      v27 = boost::asio::ssl::detail::engine::map_error_code(
              (const boost::asio::ssl::detail::engine *)this->core_,
              p_ec);
      v28 = 0;
      p_handler = &this->handler_;
LABEL_58:
      boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>::operator()(
        p_handler,
        v27,
        v28,
        0);
      return;
    }
  }
  v30 = this->core_;
  if ( *((_QWORD *)v30 + 11) != 0x8000000000000000LL )
  {
    v36 = (boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *)((char *)v30 + 80);
    goto LABEL_60;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v30 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v30 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v30 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v30 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v30 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v30 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v31 = this->next_layer_;
  v32 = this->core_;
  v33 = BIO_read(*((_QWORD *)v32 + 1), *((_QWORD *)v32 + 21), *((unsigned int *)v32 + 44));
  v34 = 0;
  if ( v33 >= 0 )
    v34 = (unsigned int)v33;
  if ( *((_QWORD *)v32 + 22) < v34 )
    v34 = *((_QWORD *)v32 + 22);
  op.buffers_.data_ = (void *)*((_QWORD *)v32 + 21);
  op.buffers_.size_ = v34;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
    v31,
    &op.buffers_,
    this);
}


// Address: 0x2631c50 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_12handshake_opENS0_6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJNSF_10shared_ptrISL_EERSR_RKNSF_12placeholders4__phILi1EEEEEENSB_26is_continuation_if_runningEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::handshake_op *op,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > v11; // [rsp+0h] [rbp-C8h] BYREF
  unsigned __int64 v12; // [rsp+A8h] [rbp-20h]
  boost::system::error_code v13; // 0:esi.4,8:rdx.8

  v12 = __readfsqword(0x28u);
  v11.next_layer_ = next_layer;
  v11.core_ = core;
  v11.op_ = (boost::asio::ssl::detail::handshake_op)op->type_;
  *(_QWORD *)&v11.start_ = 0;
  v11.ec_.m_val = 0;
  v11.ec_.m_cat = boost::system::system_category();
  v11.bytes_transferred_ = 0;
  v11.handler_.dispatcher_ = handler->dispatcher_;
  *(_OWORD *)&v11.handler_.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v11.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v11.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, int, const boost::system::error_category *, size_t))f->dispatcher_.service_->owner_)(
        f,
        &v11.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v5,
        v6,
        v7,
        v8,
        v11.next_layer_,
        v11.core_,
        *(_QWORD *)&v11.op_.type_,
        v11.want_,
        v11.ec_.m_val,
        v11.ec_.m_cat,
        v11.bytes_transferred_);
    }
    else
    {
      v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v13.m_val = 0;
  v13.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
    &v11,
    v13,
    0,
    1);
  if ( &v11.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v11.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v11.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v11.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v11.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v11.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v11.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x2631e00 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_12handshake_opENS0_6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJNSF_10shared_ptrISL_EERSR_RKNSF_12placeholders4__phILi1EEEEEENSB_26is_continuation_if_runningEEEEclEST_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  int m_val; // r12d
  size_t *p_ec; // r9
  boost::asio::ssl::detail::stream_core *core; // rdi
  int (*v10)(boost::asio::ssl::detail::engine *, void *, size_t); // rsi
  boost::asio::ssl::detail::engine::want v11; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v13; // rbp
  boost::asio::ssl::detail::stream_core *v14; // rbp
  unsigned __int64 v15; // rax
  unsigned __int64 v16; // rcx
  unsigned __int64 v17; // rdx
  unsigned __int64 v18; // rdx
  boost::asio::ssl::detail::stream_core *v19; // rax
  boost::asio::ssl::detail::stream_core *v20; // rax
  size_t v21; // rdx
  boost::asio::ssl::detail::stream_core *v22; // rbp
  unsigned __int64 v23; // rax
  unsigned __int64 v24; // rcx
  unsigned __int64 v25; // rdx
  unsigned __int64 v26; // rdx
  boost::asio::ssl::detail::stream_core *v27; // rax
  boost::asio::ssl::detail::stream_core *v28; // rbp
  const boost::system::error_code *v29; // rax
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *p_handler; // rdi
  boost::asio::ssl::detail::stream_core *v31; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v32; // r14
  boost::asio::ssl::detail::stream_core *v33; // rbp
  int v34; // eax
  size_t v35; // rcx
  boost::asio::ssl::detail::stream_core *v36; // rbp
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v37; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v38; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rsi
  boost::asio::mutable_buffers_1 buffers; // [rsp+10h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+20h] [rbp-38h]

  m_cat = ec.m_cat;
  m_val = ec.m_val;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_9;
  p_ec = (size_t *)&this->ec_;
  while ( 1 )
  {
    core = this->core_;
    this->bytes_transferred_ = 0;
    v10 = boost::asio::ssl::detail::engine::do_accept;
    if ( this->op_.type_ == boost::asio::ssl::stream_base::handshake_type::client )
      v10 = boost::asio::ssl::detail::engine::do_connect;
    v11 = (unsigned int)boost::asio::ssl::detail::engine::perform(
                          (boost::asio::ssl::detail::engine *)core,
                          v10,
                          0,
                          0,
                          0,
                          p_ec,
                          0);
    this->want_ = v11;
    if ( v11 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v14 = this->core_;
      if ( *((_QWORD *)v14 + 29) )
      {
        v15 = BIO_write(*((_QWORD *)v14 + 1), *((_QWORD *)v14 + 28));
        v16 = 0;
        if ( (v15 & 0x80000000) != 0LL )
          v15 = 0;
        v17 = *((_QWORD *)v14 + 29);
        if ( v17 >= v15 )
          v16 = v15 + *((_QWORD *)v14 + 28);
        else
          v17 = v15;
        v18 = v17 - v15;
        v19 = this->core_;
        *((_QWORD *)v19 + 28) = v16;
        *((_QWORD *)v19 + 29) = v18;
        goto LABEL_35;
      }
      if ( *((_QWORD *)v14 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v14 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v14 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v14 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v14
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v14 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v14 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        buffers = (boost::asio::mutable_buffers_1)*((_OWORD *)this->core_ + 13);
        goto LABEL_57;
      }
      v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v14 + 2);
      v38 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v14 + 24);
LABEL_59:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        v37,
        v38,
        this);
      return;
    }
    if ( v11 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v11 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      buffers.data_ = (void *)*((_QWORD *)this->core_ + 26);
      buffers.size_ = 0;
LABEL_57:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        next_layer->service_,
        &next_layer->implementation,
        &buffers,
        0,
        this);
      return;
    }
LABEL_9:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v20 = this->core_;
      v21 = *((_QWORD *)v20 + 27);
      if ( v21 >= bytes_transferred )
        v21 = bytes_transferred;
      *((_QWORD *)v20 + 28) = *((_QWORD *)v20 + 26);
      *((_QWORD *)v20 + 29) = v21;
      v22 = this->core_;
      v23 = BIO_write(*((_QWORD *)v22 + 1), *((_QWORD *)v22 + 28));
      v24 = 0;
      if ( (v23 & 0x80000000) != 0LL )
        v23 = 0;
      v25 = *((_QWORD *)v22 + 29);
      if ( v25 >= v23 )
        v24 = v23 + *((_QWORD *)v22 + 28);
      else
        v25 = v23;
      v26 = v25 - v23;
      v27 = this->core_;
      *((_QWORD *)v27 + 28) = v24;
      *((_QWORD *)v27 + 29) = v26;
      v28 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v28 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v28 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v28 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v28
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v28 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v28 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v36 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v36 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v36 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v36 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v36 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v36 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v36 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v29 = boost::asio::ssl::detail::engine::map_error_code(
                (const boost::asio::ssl::detail::engine *)this->core_,
                &this->ec_);
        p_handler = &this->handler_;
        goto LABEL_50;
      }
      v13 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v13 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v13 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v13 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v13 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v13 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v13 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_35:
    p_ec = (size_t *)&this->ec_;
    if ( this->ec_.m_val )
    {
      v29 = boost::asio::ssl::detail::engine::map_error_code(
              (const boost::asio::ssl::detail::engine *)this->core_,
              (boost::system::error_code *)p_ec);
      p_handler = &this->handler_;
LABEL_50:
      boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code>(
        p_handler,
        v29);
      return;
    }
  }
  v31 = this->core_;
  if ( *((_QWORD *)v31 + 11) != 0x8000000000000000LL )
  {
    v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v31 + 10);
    v38 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v31 + 88);
    goto LABEL_59;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v31 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v31 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v31 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v31 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v31 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v31 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v32 = this->next_layer_;
  v33 = this->core_;
  v34 = BIO_read(*((_QWORD *)v33 + 1), *((_QWORD *)v33 + 21), *((unsigned int *)v33 + 44));
  v35 = 0;
  if ( v34 >= 0 )
    v35 = (unsigned int)v34;
  if ( *((_QWORD *)v33 + 22) < v35 )
    v35 = *((_QWORD *)v33 + 22);
  buffers.data_ = (void *)*((_QWORD *)v33 + 21);
  buffers.size_ = v35;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
    v32,
    &buffers,
    this);
}


// Address: 0x2636850 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrISH_EERSN_RKNSB_12placeholders4__phILi1EEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::handshake_op *op,
        std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *handler)
{
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v11; // [rsp+0h] [rbp-B8h] BYREF
  unsigned __int64 v12; // [rsp+98h] [rbp-20h]
  boost::system::error_code v13; // 0:esi.4,8:rdx.8

  v12 = __readfsqword(0x28u);
  v11.next_layer_ = next_layer;
  v11.core_ = core;
  v11.op_ = (boost::asio::ssl::detail::handshake_op)op->type_;
  *(_QWORD *)&v11.start_ = 0;
  v11.ec_.m_val = 0;
  v11.ec_.m_cat = boost::system::system_category();
  v11.bytes_transferred_ = 0;
  *(_OWORD *)&v11.handler_.__f_ = *(_OWORD *)&handler->__f_;
  v11.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *)handler->__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v11.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v11.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, int, const boost::system::error_category *, size_t))f->__f_
       + 3))(
        f,
        &v11.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v5,
        v6,
        v7,
        v8,
        v11.next_layer_,
        v11.core_,
        *(_QWORD *)&v11.op_.type_,
        v11.want_,
        v11.ec_.m_val,
        v11.ec_.m_cat,
        v11.bytes_transferred_);
    }
    else
    {
      v11.handler_.__bound_args_.__base_.__value_.__f_ = handler->__bound_args_.__base_.__value_.__f_;
      handler->__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v11.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  v13.m_val = 0;
  v13.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::operator()(
    &v11,
    v13,
    0,
    1);
  if ( &v11.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v11.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v11.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v11.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v11.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v11.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v11.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v11.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v11.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26369f0 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSB_8functionIFvRKNSB_10error_codeEEEERKNS_6system10error_codeEEJNSB_10shared_ptrISH_EERSN_RKNSB_12placeholders4__phILi1EEEEEEEclESP_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  int m_val; // r12d
  size_t *p_ec; // r9
  boost::asio::ssl::detail::stream_core *core; // rdi
  int (*v10)(boost::asio::ssl::detail::engine *, void *, size_t); // rsi
  boost::asio::ssl::detail::engine::want v11; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v13; // rbp
  boost::asio::ssl::detail::stream_core *v14; // rbp
  unsigned __int64 v15; // rax
  unsigned __int64 v16; // rcx
  unsigned __int64 v17; // rdx
  unsigned __int64 v18; // rdx
  boost::asio::ssl::detail::stream_core *v19; // rax
  boost::asio::ssl::detail::stream_core *v20; // rax
  size_t v21; // rdx
  boost::asio::ssl::detail::stream_core *v22; // rbp
  unsigned __int64 v23; // rax
  unsigned __int64 v24; // rcx
  unsigned __int64 v25; // rdx
  unsigned __int64 v26; // rdx
  boost::asio::ssl::detail::stream_core *v27; // rax
  boost::asio::ssl::detail::stream_core *v28; // rbp
  const boost::system::error_code *v29; // rax
  boost::asio::ssl::detail::handshake_op *p_op; // rdi
  std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> *p_handler; // rsi
  boost::asio::ssl::detail::stream_core *v32; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v33; // r14
  boost::asio::ssl::detail::stream_core *v34; // rbp
  int v35; // eax
  size_t v36; // rcx
  boost::asio::ssl::detail::stream_core *v37; // rbp
  void *v38; // rcx
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v39; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v40; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rsi
  boost::asio::mutable_buffers_1 buffers; // [rsp+10h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+20h] [rbp-38h]

  m_cat = ec.m_cat;
  m_val = ec.m_val;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_9;
  p_ec = (size_t *)&this->ec_;
  while ( 1 )
  {
    core = this->core_;
    this->bytes_transferred_ = 0;
    v10 = boost::asio::ssl::detail::engine::do_accept;
    if ( this->op_.type_ == boost::asio::ssl::stream_base::handshake_type::client )
      v10 = boost::asio::ssl::detail::engine::do_connect;
    v11 = (unsigned int)boost::asio::ssl::detail::engine::perform(
                          (boost::asio::ssl::detail::engine *)core,
                          v10,
                          0,
                          0,
                          0,
                          p_ec,
                          0);
    this->want_ = v11;
    if ( v11 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v14 = this->core_;
      if ( *((_QWORD *)v14 + 29) )
      {
        v15 = BIO_write(*((_QWORD *)v14 + 1), *((_QWORD *)v14 + 28));
        v16 = 0;
        if ( (v15 & 0x80000000) != 0LL )
          v15 = 0;
        v17 = *((_QWORD *)v14 + 29);
        if ( v17 >= v15 )
          v16 = v15 + *((_QWORD *)v14 + 28);
        else
          v17 = v15;
        v18 = v17 - v15;
        v19 = this->core_;
        *((_QWORD *)v19 + 28) = v16;
        *((_QWORD *)v19 + 29) = v18;
        goto LABEL_35;
      }
      if ( *((_QWORD *)v14 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v14 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v14 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v14 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v14
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v14 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v14 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        buffers = (boost::asio::mutable_buffers_1)*((_OWORD *)this->core_ + 13);
        goto LABEL_57;
      }
      v39 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v14 + 2);
      v40 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v14 + 24);
LABEL_62:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        v39,
        v40,
        this);
      return;
    }
    if ( v11 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v11 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      buffers.data_ = (void *)*((_QWORD *)this->core_ + 26);
      buffers.size_ = 0;
LABEL_57:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        next_layer->service_,
        &next_layer->implementation,
        &buffers,
        0,
        this);
      return;
    }
LABEL_9:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v20 = this->core_;
      v21 = *((_QWORD *)v20 + 27);
      if ( v21 >= bytes_transferred )
        v21 = bytes_transferred;
      *((_QWORD *)v20 + 28) = *((_QWORD *)v20 + 26);
      *((_QWORD *)v20 + 29) = v21;
      v22 = this->core_;
      v23 = BIO_write(*((_QWORD *)v22 + 1), *((_QWORD *)v22 + 28));
      v24 = 0;
      if ( (v23 & 0x80000000) != 0LL )
        v23 = 0;
      v25 = *((_QWORD *)v22 + 29);
      if ( v25 >= v23 )
        v24 = v23 + *((_QWORD *)v22 + 28);
      else
        v25 = v23;
      v26 = v25 - v23;
      v27 = this->core_;
      *((_QWORD *)v27 + 28) = v24;
      *((_QWORD *)v27 + 29) = v26;
      v28 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v28 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v28 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v28 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v28
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v28 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v28 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v37 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v37 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v37 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v37 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v37 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v37 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v37 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v29 = boost::asio::ssl::detail::engine::map_error_code(
                (const boost::asio::ssl::detail::engine *)this->core_,
                &this->ec_);
        if ( this->ec_.m_val )
          v38 = 0;
        else
          v38 = (void *)this->bytes_transferred_;
        buffers.data_ = v38;
        p_op = &this->op_;
        p_handler = &this->handler_;
        goto LABEL_60;
      }
      v13 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v13 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v13 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v13 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v13 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v13 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v13 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_35:
    p_ec = (size_t *)&this->ec_;
    if ( this->ec_.m_val )
    {
      v29 = boost::asio::ssl::detail::engine::map_error_code(
              (const boost::asio::ssl::detail::engine *)this->core_,
              (boost::system::error_code *)p_ec);
      buffers.data_ = 0;
      p_op = &this->op_;
      p_handler = &this->handler_;
LABEL_60:
      boost::asio::ssl::detail::handshake_op::call_handler<std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>(
        p_op,
        p_handler,
        v29,
        (const size_t *)&buffers);
      return;
    }
  }
  v32 = this->core_;
  if ( *((_QWORD *)v32 + 11) != 0x8000000000000000LL )
  {
    v39 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v32 + 10);
    v40 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v32 + 88);
    goto LABEL_62;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v32 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v32 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v32 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v32 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v32 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v32 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v33 = this->next_layer_;
  v34 = this->core_;
  v35 = BIO_read(*((_QWORD *)v34 + 1), *((_QWORD *)v34 + 21), *((unsigned int *)v34 + 44));
  v36 = 0;
  if ( v35 >= 0 )
    v36 = (unsigned int)v35;
  if ( *((_QWORD *)v34 + 22) < v36 )
    v36 = *((_QWORD *)v34 + 22);
  buffers.data_ = (void *)*((_QWORD *)v34 + 21);
  buffers.size_ = v36;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    v33,
    &buffers,
    this);
}


// Address: 0x26a2400 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS1_6streamIRS9_EESB_NSD_14transfer_all_tENSD_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSK_10shared_ptrISW_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *op,
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > v6; // [rsp+8h] [rbp-A0h] BYREF
  boost::system::error_code v7; // 0:esi.4,8:rdx.8

  v6.next_layer_ = next_layer;
  v6.core_ = core;
  v6.op_ = *op;
  *(_QWORD *)&v6.start_ = 0;
  v6.ec_.m_val = 0;
  v6.ec_.m_cat = boost::system::system_category();
  v6.bytes_transferred_ = 0;
  v6.handler_ = *handler;
  handler->handler_.handler_.l_ = 0;
  v7.m_val = 0;
  v7.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::operator()(
    &v6,
    v7,
    0,
    1);
  cntrl = v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a2520 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS1_6streamIRS9_EESB_NSD_14transfer_all_tENSD_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSK_10shared_ptrISW_EEEEPFNS_3argILi1EEEvEEEEEEEEEEclESY_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  boost::system::error_code *p_ec; // rdx
  boost::asio::ssl::detail::stream_core *core; // rdi
  boost::asio::ssl::detail::engine::want v9; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v11; // rbp
  boost::asio::ssl::detail::stream_core *v12; // rbp
  unsigned __int64 v13; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rdx
  boost::asio::ssl::detail::stream_core *v17; // rax
  boost::asio::ssl::detail::stream_core *v18; // rax
  size_t v19; // rdx
  boost::asio::ssl::detail::stream_core *v20; // rbp
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rdx
  boost::asio::ssl::detail::stream_core *v25; // rax
  boost::asio::ssl::detail::stream_core *v26; // rbp
  const boost::system::error_code *v27; // rax
  size_t v28; // rdx
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *p_handler; // rdi
  boost::asio::ssl::detail::stream_core *v30; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v31; // r14
  boost::asio::ssl::detail::stream_core *v32; // rbp
  int v33; // eax
  size_t v34; // rcx
  boost::asio::ssl::detail::stream_core *v35; // rbp
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v36; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v37; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rsi
  boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> op; // [rsp+0h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+10h] [rbp-38h]

  m_cat = ec.m_cat;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_7;
  p_ec = &this->ec_;
  while ( 1 )
  {
    core = this->core_;
    op = this->op_;
    v9 = boost::asio::ssl::detail::engine::write(
           (boost::asio::ssl::detail::engine *)core,
           &op.buffers_,
           p_ec,
           &this->bytes_transferred_);
    this->want_ = v9;
    if ( v9 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v12 = this->core_;
      if ( *((_QWORD *)v12 + 29) )
      {
        v13 = BIO_write(*((_QWORD *)v12 + 1), *((_QWORD *)v12 + 28));
        v14 = 0;
        if ( (v13 & 0x80000000) != 0LL )
          v13 = 0;
        v15 = *((_QWORD *)v12 + 29);
        if ( v15 >= v13 )
          v14 = v13 + *((_QWORD *)v12 + 28);
        else
          v15 = v13;
        v16 = v15 - v13;
        v17 = this->core_;
        *((_QWORD *)v17 + 28) = v14;
        *((_QWORD *)v17 + 29) = v16;
        goto LABEL_33;
      }
      if ( *((_QWORD *)v12 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v12 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v12 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v12 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v12
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v12 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v12 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        op = (boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>)*((_OWORD *)this->core_ + 13);
        goto LABEL_55;
      }
      v36 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v12 + 2);
      v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v12 + 24);
LABEL_60:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        v36,
        v37,
        this);
      return;
    }
    if ( v9 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v9 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      op = (boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>)*((unsigned __int64 *)this->core_ + 26);
LABEL_55:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        next_layer->service_,
        &next_layer->implementation,
        (const boost::asio::mutable_buffers_1 *)&op,
        0,
        this);
      return;
    }
LABEL_7:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = ec.m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v18 = this->core_;
      v19 = *((_QWORD *)v18 + 27);
      if ( v19 >= bytes_transferred )
        v19 = bytes_transferred;
      *((_QWORD *)v18 + 28) = *((_QWORD *)v18 + 26);
      *((_QWORD *)v18 + 29) = v19;
      v20 = this->core_;
      v21 = BIO_write(*((_QWORD *)v20 + 1), *((_QWORD *)v20 + 28));
      v22 = 0;
      if ( (v21 & 0x80000000) != 0LL )
        v21 = 0;
      v23 = *((_QWORD *)v20 + 29);
      if ( v23 >= v21 )
        v22 = v21 + *((_QWORD *)v20 + 28);
      else
        v23 = v21;
      v24 = v23 - v21;
      v25 = this->core_;
      *((_QWORD *)v25 + 28) = v22;
      *((_QWORD *)v25 + 29) = v24;
      v26 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v26 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v26 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v26 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v26
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v26 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v26 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v35 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v35 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v35 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v35 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v35 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v35 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v35 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v27 = boost::asio::ssl::detail::engine::map_error_code(
                (const boost::asio::ssl::detail::engine *)this->core_,
                &this->ec_);
        if ( this->ec_.m_val )
          v28 = 0;
        else
          v28 = this->bytes_transferred_;
        p_handler = &this->handler_;
        goto LABEL_58;
      }
      v11 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v11 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v11 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v11 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v11 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v11 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v11 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_33:
    p_ec = &this->ec_;
    if ( this->ec_.m_val )
    {
      v27 = boost::asio::ssl::detail::engine::map_error_code(
              (const boost::asio::ssl::detail::engine *)this->core_,
              p_ec);
      v28 = 0;
      p_handler = &this->handler_;
LABEL_58:
      boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
        p_handler,
        v27,
        v28,
        0);
      return;
    }
  }
  v30 = this->core_;
  if ( *((_QWORD *)v30 + 11) != 0x8000000000000000LL )
  {
    v36 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v30 + 10);
    v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v30 + 88);
    goto LABEL_60;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v30 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v30 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v30 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v30 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v30 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v30 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v31 = this->next_layer_;
  v32 = this->core_;
  v33 = BIO_read(*((_QWORD *)v32 + 1), *((_QWORD *)v32 + 21), *((unsigned int *)v32 + 44));
  v34 = 0;
  if ( v33 >= 0 )
    v34 = (unsigned int)v33;
  if ( *((_QWORD *)v32 + 22) < v34 )
    v34 = *((_QWORD *)v32 + 22);
  op.buffers_.data_ = (const void *)*((_QWORD *)v32 + 21);
  op.buffers_.size_ = v34;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
    v31,
    (const boost::asio::mutable_buffers_1 *)&op,
    this);
}


// Address: 0x26a4fe0 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail26read_until_delim_string_opINS1_6streamIRS9_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSL_5list2INSL_5valueINSI_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *op,
        boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *handler)
{
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  std::__shared_weak_count *v9; // rbx
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v10; // [rsp+0h] [rbp-A8h] BYREF
  boost::asio::ssl::detail::stream_core *v11; // [rsp+8h] [rbp-A0h]
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> v12; // [rsp+10h] [rbp-98h]
  __int64 v13; // [rsp+20h] [rbp-88h]
  int v14; // [rsp+28h] [rbp-80h]
  const boost::system::error_category *v15; // [rsp+30h] [rbp-78h]
  __int64 v16; // [rsp+38h] [rbp-70h]
  __int128 v17; // [rsp+40h] [rbp-68h]
  __int128 v18; // [rsp+50h] [rbp-58h]
  void *ptr; // [rsp+60h] [rbp-48h]
  int v20; // [rsp+68h] [rbp-40h]
  __int64 v21; // [rsp+70h] [rbp-38h]
  __int128 v22; // [rsp+78h] [rbp-30h]
  std::__shared_weak_count *v23[2]; // [rsp+88h] [rbp-20h]
  boost::system::error_code v24; // 0:esi.4,8:rdx.8

  v10 = next_layer;
  v11 = core;
  v12 = *op;
  v13 = 0;
  v14 = 0;
  v15 = boost::system::system_category();
  v16 = 0;
  v17 = *(_OWORD *)handler;
  ptr = (void *)*((_QWORD *)handler + 4);
  v18 = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  v20 = *((_DWORD *)handler + 10);
  v21 = *((_QWORD *)handler + 6);
  v22 = *(_OWORD *)((char *)handler + 56);
  *(_OWORD *)v23 = *(_OWORD *)((char *)handler + 72);
  *(_OWORD *)((char *)handler + 72) = 0;
  v24.m_val = 0;
  v24.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)&v10,
    v24,
    0,
    1);
  v9 = v23[1];
  if ( v23[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v23[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, _QWORD, __int64, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, __int64, int, const boost::system::error_category *, __int64, _QWORD, _QWORD))(*(_QWORD *)v9 + 16LL))(
      v9,
      0,
      v5,
      v6,
      v7,
      v8,
      v10,
      v11,
      v12.buffers_.data_,
      v12.buffers_.size_,
      v13,
      v14,
      v15,
      v16,
      v17,
      *((_QWORD *)&v17 + 1));
    std::__shared_weak_count::__release_weak(v9);
    if ( (v18 & 1) == 0 )
      return;
  }
  else if ( (v18 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a5130 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail26read_until_delim_string_opINS1_6streamIRS9_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSL_5list2INSL_5valueINSI_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEclESW_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  boost::system::error_code *v7; // rdx
  boost::asio::ssl::detail::engine *v8; // rdi
  boost::asio::ssl::detail::engine::want v9; // eax
  int v10; // eax
  __int64 v11; // rbp
  __int64 v12; // rbp
  unsigned __int64 v13; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rdx
  __int64 v17; // rax
  _QWORD *v18; // rax
  size_t v19; // rdx
  _QWORD *v20; // rbp
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rdx
  __int64 v25; // rax
  __int64 v26; // rbp
  const boost::system::error_code *v27; // rax
  size_t v28; // rdx
  boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *v29; // rdi
  __int64 v30; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v31; // r14
  _QWORD *v32; // rbp
  int v33; // eax
  size_t v34; // rcx
  __int64 v35; // rbp
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v36; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v37; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v38; // rsi
  unsigned __int128 v39; // [rsp+0h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+10h] [rbp-38h]

  m_cat = ec.m_cat;
  *((_DWORD *)this + 8) = start;
  if ( start != 1 )
    goto LABEL_7;
  v7 = (boost::system::error_code *)((char *)this + 40);
  while ( 1 )
  {
    v8 = (boost::asio::ssl::detail::engine *)*((_QWORD *)this + 1);
    v39 = *((_OWORD *)this + 1);
    v9 = boost::asio::ssl::detail::engine::read(v8, (const boost::asio::mutable_buffer *)&v39, v7, (size_t *)this + 7);
    *((_DWORD *)this + 9) = v9;
    if ( v9 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v12 = *((_QWORD *)this + 1);
      if ( *(_QWORD *)(v12 + 232) )
      {
        v13 = BIO_write(*(_QWORD *)(v12 + 8), *(_QWORD *)(v12 + 224));
        v14 = 0;
        if ( (v13 & 0x80000000) != 0LL )
          v13 = 0;
        v15 = *(_QWORD *)(v12 + 232);
        if ( v15 >= v13 )
          v14 = v13 + *(_QWORD *)(v12 + 224);
        else
          v15 = v13;
        v16 = v15 - v13;
        v17 = *((_QWORD *)this + 1);
        *(_QWORD *)(v17 + 224) = v14;
        *(_QWORD *)(v17 + 232) = v16;
        goto LABEL_33;
      }
      if ( *(_QWORD *)(v12 + 24) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *(_BYTE *)(v12 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v12 + 16) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v12 + 16) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v12 + 40),
            0xFFFFFFFFFFFFFFFFLL);
          *(_BYTE *)(v12 + 32) = 0;
        }
        boost::system::system_category();
        *(_QWORD *)(v12 + 24) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        v38 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
        v39 = *(_OWORD *)(*((_QWORD *)this + 1) + 208LL);
        goto LABEL_55;
      }
      v36 = *(boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > **)(v12 + 16);
      v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)(v12 + 24);
LABEL_60:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        v36,
        v37,
        this);
      return;
    }
    if ( v9 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v9 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      v38 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
      v39 = *(unsigned __int64 *)(*((_QWORD *)this + 1) + 208LL);
LABEL_55:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        v38->service_,
        &v38->implementation,
        (const boost::asio::mutable_buffers_1 *)&v39,
        0,
        this);
      return;
    }
LABEL_7:
    if ( bytes_transferred != -1 && !*((_DWORD *)this + 10) )
    {
      *((_DWORD *)this + 10) = ec.m_val;
      *((_QWORD *)this + 6) = m_cat;
    }
    v10 = *((_DWORD *)this + 9);
    if ( v10 == -2 )
    {
      v18 = (_QWORD *)*((_QWORD *)this + 1);
      v19 = v18[27];
      if ( v19 >= bytes_transferred )
        v19 = bytes_transferred;
      v18[28] = v18[26];
      v18[29] = v19;
      v20 = (_QWORD *)*((_QWORD *)this + 1);
      v21 = BIO_write(v20[1], v20[28]);
      v22 = 0;
      if ( (v21 & 0x80000000) != 0LL )
        v21 = 0;
      v23 = v20[29];
      if ( v23 >= v21 )
        v22 = v21 + v20[28];
      else
        v23 = v21;
      v24 = v23 - v21;
      v25 = *((_QWORD *)this + 1);
      *(_QWORD *)(v25 + 224) = v22;
      *(_QWORD *)(v25 + 232) = v24;
      v26 = *((_QWORD *)this + 1);
      boost::system::system_category();
      if ( *(_BYTE *)(v26 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v26 + 16) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v26 + 16)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v26 + 40),
          0xFFFFFFFFFFFFFFFFLL);
        *(_BYTE *)(v26 + 32) = 0;
      }
      boost::system::system_category();
      *(_QWORD *)(v26 + 24) = 0x8000000000000000LL;
    }
    else
    {
      if ( v10 != -1 )
      {
        if ( v10 == 1 )
        {
          v35 = *((_QWORD *)this + 1);
          boost::system::system_category();
          if ( *(_BYTE *)(v35 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v35 + 80) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v35 + 80) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v35 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *(_BYTE *)(v35 + 96) = 0;
          }
          boost::system::system_category();
          *(_QWORD *)(v35 + 88) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v27 = boost::asio::ssl::detail::engine::map_error_code(
                *((const boost::asio::ssl::detail::engine **)this + 1),
                (boost::system::error_code *)((char *)this + 40));
        if ( *((_DWORD *)this + 10) )
          v28 = 0;
        else
          v28 = *((_QWORD *)this + 7);
        v29 = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)((char *)this + 64);
        goto LABEL_58;
      }
      v11 = *((_QWORD *)this + 1);
      boost::system::system_category();
      if ( *(_BYTE *)(v11 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v11 + 80) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v11 + 80)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v11 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *(_BYTE *)(v11 + 96) = 0;
      }
      boost::system::system_category();
      *(_QWORD *)(v11 + 88) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_33:
    v7 = (boost::system::error_code *)((char *)this + 40);
    if ( *((_DWORD *)this + 10) )
    {
      v27 = boost::asio::ssl::detail::engine::map_error_code(*((const boost::asio::ssl::detail::engine **)this + 1), v7);
      v28 = 0;
      v29 = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)((char *)this + 64);
LABEL_58:
      boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>::operator()(
        v29,
        v27,
        v28,
        0);
      return;
    }
  }
  v30 = *((_QWORD *)this + 1);
  if ( *(_QWORD *)(v30 + 88) != 0x8000000000000000LL )
  {
    v36 = *(boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > **)(v30 + 80);
    v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)(v30 + 88);
    goto LABEL_60;
  }
  boost::system::system_category();
  if ( *(_BYTE *)(v30 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v30 + 80) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v30 + 80)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v30 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *(_BYTE *)(v30 + 96) = 0;
  }
  boost::system::system_category();
  *(_QWORD *)(v30 + 88) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v31 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  v32 = (_QWORD *)*((_QWORD *)this + 1);
  v33 = BIO_read(v32[1], v32[21], *((unsigned int *)v32 + 44));
  v34 = 0;
  if ( v33 >= 0 )
    v34 = (unsigned int)v33;
  if ( v32[22] < v34 )
    v34 = v32[22];
  *(_QWORD *)&v39 = v32[21];
  *((_QWORD *)&v39 + 1) = v34;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
    v31,
    (const boost::asio::mutable_buffers_1 *)&v39,
    this);
}


// Address: 0x26a87c0 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSB_5list2INSB_5valueINSt3__110shared_ptrISJ_EEEEPFNS_3argILi1EEEvEEEEEEclESL_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  int m_val; // r12d
  size_t *p_ec; // r9
  boost::asio::ssl::detail::stream_core *core; // rdi
  int (*v10)(boost::asio::ssl::detail::engine *, void *, size_t); // rsi
  boost::asio::ssl::detail::engine::want v11; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v13; // rbp
  boost::asio::ssl::detail::stream_core *v14; // rbp
  unsigned __int64 v15; // rax
  unsigned __int64 v16; // rcx
  unsigned __int64 v17; // rdx
  unsigned __int64 v18; // rdx
  boost::asio::ssl::detail::stream_core *v19; // rax
  boost::asio::ssl::detail::stream_core *v20; // rax
  size_t v21; // rdx
  boost::asio::ssl::detail::stream_core *v22; // rbp
  unsigned __int64 v23; // rax
  unsigned __int64 v24; // rcx
  unsigned __int64 v25; // rdx
  unsigned __int64 v26; // rdx
  boost::asio::ssl::detail::stream_core *v27; // rax
  boost::asio::ssl::detail::stream_core *v28; // rbp
  boost::asio::ssl::detail::stream_core *v29; // rdi
  boost::system::error_code *v30; // rsi
  boost::asio::ssl::detail::stream_core *v31; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v32; // r14
  boost::asio::ssl::detail::stream_core *v33; // rbp
  int v34; // eax
  size_t v35; // rcx
  boost::asio::ssl::detail::stream_core *v36; // rbp
  const boost::system::error_code *v37; // rax
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F f; // rcx
  web::http::client::details::asio_context *v39; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v40; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v41; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rsi
  boost::asio::mutable_buffers_1 buffers; // [rsp+10h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+20h] [rbp-38h]

  m_cat = ec.m_cat;
  m_val = ec.m_val;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_9;
  p_ec = (size_t *)&this->ec_;
  while ( 1 )
  {
    core = this->core_;
    this->bytes_transferred_ = 0;
    v10 = boost::asio::ssl::detail::engine::do_accept;
    if ( this->op_.type_ == boost::asio::ssl::stream_base::handshake_type::client )
      v10 = boost::asio::ssl::detail::engine::do_connect;
    v11 = (unsigned int)boost::asio::ssl::detail::engine::perform(
                          (boost::asio::ssl::detail::engine *)core,
                          v10,
                          0,
                          0,
                          0,
                          p_ec,
                          0);
    this->want_ = v11;
    if ( v11 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v14 = this->core_;
      if ( *((_QWORD *)v14 + 29) )
      {
        v15 = BIO_write(*((_QWORD *)v14 + 1), *((_QWORD *)v14 + 28));
        v16 = 0;
        if ( (v15 & 0x80000000) != 0LL )
          v15 = 0;
        v17 = *((_QWORD *)v14 + 29);
        if ( v17 >= v15 )
          v16 = v15 + *((_QWORD *)v14 + 28);
        else
          v17 = v15;
        v18 = v17 - v15;
        v19 = this->core_;
        *((_QWORD *)v19 + 28) = v16;
        *((_QWORD *)v19 + 29) = v18;
        goto LABEL_35;
      }
      if ( *((_QWORD *)v14 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v14 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v14 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v14 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v14
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v14 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v14 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        buffers = (boost::asio::mutable_buffers_1)*((_OWORD *)this->core_ + 13);
        goto LABEL_59;
      }
      v40 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v14 + 2);
      v41 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v14 + 24);
LABEL_61:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        v40,
        v41,
        this);
      return;
    }
    if ( v11 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v11 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      buffers.data_ = (void *)*((_QWORD *)this->core_ + 26);
      buffers.size_ = 0;
LABEL_59:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        next_layer->service_,
        &next_layer->implementation,
        &buffers,
        0,
        this);
      return;
    }
LABEL_9:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v20 = this->core_;
      v21 = *((_QWORD *)v20 + 27);
      if ( v21 >= bytes_transferred )
        v21 = bytes_transferred;
      *((_QWORD *)v20 + 28) = *((_QWORD *)v20 + 26);
      *((_QWORD *)v20 + 29) = v21;
      v22 = this->core_;
      v23 = BIO_write(*((_QWORD *)v22 + 1), *((_QWORD *)v22 + 28));
      v24 = 0;
      if ( (v23 & 0x80000000) != 0LL )
        v23 = 0;
      v25 = *((_QWORD *)v22 + 29);
      if ( v25 >= v23 )
        v24 = v23 + *((_QWORD *)v22 + 28);
      else
        v25 = v23;
      v26 = v25 - v23;
      v27 = this->core_;
      *((_QWORD *)v27 + 28) = v24;
      *((_QWORD *)v27 + 29) = v26;
      v28 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v28 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v28 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v28 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v28
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v28 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v28 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v36 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v36 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v36 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v36 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v36 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v36 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v36 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v29 = this->core_;
        v30 = &this->ec_;
        goto LABEL_50;
      }
      v13 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v13 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v13 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v13 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v13 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v13 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v13 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_35:
    p_ec = (size_t *)&this->ec_;
    if ( this->ec_.m_val )
    {
      v29 = this->core_;
      v30 = &this->ec_;
LABEL_50:
      v37 = boost::asio::ssl::detail::engine::map_error_code((const boost::asio::ssl::detail::engine *)v29, v30);
      f = this->handler_.f_.f_;
      v39 = (web::http::client::details::asio_context *)((char *)this->handler_.l_.a1_.t_.__ptr_
                                                       + *((_QWORD *)&this->handler_.f_.f_ + 1));
      if ( ((unsigned __int8)f & 1) != 0 )
        f = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F *)((char *)f + *(_QWORD *)v39 - 1);
      f(v39, v37);
      return;
    }
  }
  v31 = this->core_;
  if ( *((_QWORD *)v31 + 11) != 0x8000000000000000LL )
  {
    v40 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v31 + 10);
    v41 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v31 + 88);
    goto LABEL_61;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v31 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v31 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v31 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v31 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v31 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v31 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v32 = this->next_layer_;
  v33 = this->core_;
  v34 = BIO_read(*((_QWORD *)v33 + 1), *((_QWORD *)v33 + 21), *((unsigned int *)v33 + 44));
  v35 = 0;
  if ( v34 >= 0 )
    v35 = (unsigned int)v34;
  if ( *((_QWORD *)v33 + 22) < v35 )
    v35 = *((_QWORD *)v33 + 22);
  buffers.data_ = (void *)*((_QWORD *)v33 + 21);
  buffers.size_ = v35;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    v32,
    &buffers,
    this);
}


// Address: 0x26a9e50 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS1_6streamIRS9_EESB_NSD_14transfer_all_tENSD_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSK_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *op,
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > v6; // [rsp+8h] [rbp-A0h] BYREF
  boost::system::error_code v7; // 0:esi.4,8:rdx.8

  v6.next_layer_ = next_layer;
  v6.core_ = core;
  v6.op_ = *op;
  *(_QWORD *)&v6.start_ = 0;
  v6.ec_.m_val = 0;
  v6.ec_.m_cat = boost::system::system_category();
  v6.bytes_transferred_ = 0;
  v6.handler_ = *handler;
  handler->handler_.handler_.l_ = 0;
  v7.m_val = 0;
  v7.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::operator()(
    &v6,
    v7,
    0,
    1);
  cntrl = v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a9f70 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS1_6streamIRS9_EESB_NSD_14transfer_all_tENSD_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSK_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEEclESX_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  boost::system::error_code *p_ec; // rdx
  boost::asio::ssl::detail::stream_core *core; // rdi
  boost::asio::ssl::detail::engine::want v9; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v11; // rbp
  boost::asio::ssl::detail::stream_core *v12; // rbp
  unsigned __int64 v13; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rdx
  boost::asio::ssl::detail::stream_core *v17; // rax
  boost::asio::ssl::detail::stream_core *v18; // rax
  size_t v19; // rdx
  boost::asio::ssl::detail::stream_core *v20; // rbp
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rdx
  boost::asio::ssl::detail::stream_core *v25; // rax
  boost::asio::ssl::detail::stream_core *v26; // rbp
  const boost::system::error_code *v27; // rax
  size_t v28; // rdx
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *p_handler; // rdi
  boost::asio::ssl::detail::stream_core *v30; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v31; // r14
  boost::asio::ssl::detail::stream_core *v32; // rbp
  int v33; // eax
  size_t v34; // rcx
  boost::asio::ssl::detail::stream_core *v35; // rbp
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v36; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v37; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rsi
  boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> op; // [rsp+0h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+10h] [rbp-38h]

  m_cat = ec.m_cat;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_7;
  p_ec = &this->ec_;
  while ( 1 )
  {
    core = this->core_;
    op = this->op_;
    v9 = boost::asio::ssl::detail::engine::write(
           (boost::asio::ssl::detail::engine *)core,
           &op.buffers_,
           p_ec,
           &this->bytes_transferred_);
    this->want_ = v9;
    if ( v9 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v12 = this->core_;
      if ( *((_QWORD *)v12 + 29) )
      {
        v13 = BIO_write(*((_QWORD *)v12 + 1), *((_QWORD *)v12 + 28));
        v14 = 0;
        if ( (v13 & 0x80000000) != 0LL )
          v13 = 0;
        v15 = *((_QWORD *)v12 + 29);
        if ( v15 >= v13 )
          v14 = v13 + *((_QWORD *)v12 + 28);
        else
          v15 = v13;
        v16 = v15 - v13;
        v17 = this->core_;
        *((_QWORD *)v17 + 28) = v14;
        *((_QWORD *)v17 + 29) = v16;
        goto LABEL_33;
      }
      if ( *((_QWORD *)v12 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v12 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v12 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v12 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v12
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v12 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v12 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        op = (boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>)*((_OWORD *)this->core_ + 13);
        goto LABEL_55;
      }
      v36 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v12 + 2);
      v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v12 + 24);
LABEL_60:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        v36,
        v37,
        this);
      return;
    }
    if ( v9 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v9 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      op = (boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>)*((unsigned __int64 *)this->core_ + 26);
LABEL_55:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        next_layer->service_,
        &next_layer->implementation,
        (const boost::asio::mutable_buffers_1 *)&op,
        0,
        this);
      return;
    }
LABEL_7:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = ec.m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v18 = this->core_;
      v19 = *((_QWORD *)v18 + 27);
      if ( v19 >= bytes_transferred )
        v19 = bytes_transferred;
      *((_QWORD *)v18 + 28) = *((_QWORD *)v18 + 26);
      *((_QWORD *)v18 + 29) = v19;
      v20 = this->core_;
      v21 = BIO_write(*((_QWORD *)v20 + 1), *((_QWORD *)v20 + 28));
      v22 = 0;
      if ( (v21 & 0x80000000) != 0LL )
        v21 = 0;
      v23 = *((_QWORD *)v20 + 29);
      if ( v23 >= v21 )
        v22 = v21 + *((_QWORD *)v20 + 28);
      else
        v23 = v21;
      v24 = v23 - v21;
      v25 = this->core_;
      *((_QWORD *)v25 + 28) = v22;
      *((_QWORD *)v25 + 29) = v24;
      v26 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v26 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v26 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v26 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v26
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v26 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v26 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v35 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v35 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v35 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v35 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v35 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v35 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v35 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v27 = boost::asio::ssl::detail::engine::map_error_code(
                (const boost::asio::ssl::detail::engine *)this->core_,
                &this->ec_);
        if ( this->ec_.m_val )
          v28 = 0;
        else
          v28 = this->bytes_transferred_;
        p_handler = &this->handler_;
        goto LABEL_58;
      }
      v11 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v11 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v11 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v11 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v11 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v11 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v11 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_33:
    p_ec = &this->ec_;
    if ( this->ec_.m_val )
    {
      v27 = boost::asio::ssl::detail::engine::map_error_code(
              (const boost::asio::ssl::detail::engine *)this->core_,
              p_ec);
      v28 = 0;
      p_handler = &this->handler_;
LABEL_58:
      boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
        p_handler,
        v27,
        v28,
        0);
      return;
    }
  }
  v30 = this->core_;
  if ( *((_QWORD *)v30 + 11) != 0x8000000000000000LL )
  {
    v36 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v30 + 10);
    v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v30 + 88);
    goto LABEL_60;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v30 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v30 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v30 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v30 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v30 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v30 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v31 = this->next_layer_;
  v32 = this->core_;
  v33 = BIO_read(*((_QWORD *)v32 + 1), *((_QWORD *)v32 + 21), *((unsigned int *)v32 + 44));
  v34 = 0;
  if ( v33 >= 0 )
    v34 = (unsigned int)v33;
  if ( *((_QWORD *)v32 + 22) < v34 )
    v34 = *((_QWORD *)v32 + 22);
  op.buffers_.data_ = (const void *)*((_QWORD *)v32 + 21);
  op.buffers_.size_ = v34;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
    v31,
    (const boost::asio::mutable_buffers_1 *)&op,
    this);
}


// Address: 0x26ad460 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail26read_until_delim_string_opINS1_6streamIRS9_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSL_5list2INSL_5valueINSI_10shared_ptrIST_EEEEPFNS_3argILi1EEEvEEEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *op,
        boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  std::__shared_weak_count *v9; // rbx
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v10; // [rsp+0h] [rbp-A8h] BYREF
  boost::asio::ssl::detail::stream_core *v11; // [rsp+8h] [rbp-A0h]
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> v12; // [rsp+10h] [rbp-98h]
  __int64 v13; // [rsp+20h] [rbp-88h]
  int v14; // [rsp+28h] [rbp-80h]
  const boost::system::error_category *v15; // [rsp+30h] [rbp-78h]
  __int64 v16; // [rsp+38h] [rbp-70h]
  __int128 v17; // [rsp+40h] [rbp-68h]
  __int128 v18; // [rsp+50h] [rbp-58h]
  void *ptr; // [rsp+60h] [rbp-48h]
  int v20; // [rsp+68h] [rbp-40h]
  __int64 v21; // [rsp+70h] [rbp-38h]
  __int128 v22; // [rsp+78h] [rbp-30h]
  std::__shared_weak_count *v23[2]; // [rsp+88h] [rbp-20h]
  boost::system::error_code v24; // 0:esi.4,8:rdx.8

  v10 = next_layer;
  v11 = core;
  v12 = *op;
  v13 = 0;
  v14 = 0;
  v15 = boost::system::system_category();
  v16 = 0;
  v17 = *(_OWORD *)handler;
  ptr = (void *)*((_QWORD *)handler + 4);
  v18 = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  v20 = *((_DWORD *)handler + 10);
  v21 = *((_QWORD *)handler + 6);
  v22 = *(_OWORD *)((char *)handler + 56);
  *(_OWORD *)v23 = *(_OWORD *)((char *)handler + 72);
  *(_OWORD *)((char *)handler + 72) = 0;
  v24.m_val = 0;
  v24.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)&v10,
    v24,
    0,
    1);
  v9 = v23[1];
  if ( v23[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v23[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, _QWORD, __int64, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, __int64, int, const boost::system::error_category *, __int64, _QWORD, _QWORD))(*(_QWORD *)v9 + 16LL))(
      v9,
      0,
      v5,
      v6,
      v7,
      v8,
      v10,
      v11,
      v12.buffers_.data_,
      v12.buffers_.size_,
      v13,
      v14,
      v15,
      v16,
      v17,
      *((_QWORD *)&v17 + 1));
    std::__shared_weak_count::__release_weak(v9);
    if ( (v18 & 1) == 0 )
      return;
  }
  else if ( (v18 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26ad5b0 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail26read_until_delim_string_opINS1_6streamIRS9_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSL_5list2INSL_5valueINSI_10shared_ptrIST_EEEEPFNS_3argILi1EEEvEEEEEEEEclESV_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  boost::system::error_code *v7; // rdx
  boost::asio::ssl::detail::engine *v8; // rdi
  boost::asio::ssl::detail::engine::want v9; // eax
  int v10; // eax
  __int64 v11; // rbp
  __int64 v12; // rbp
  unsigned __int64 v13; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rdx
  __int64 v17; // rax
  _QWORD *v18; // rax
  size_t v19; // rdx
  _QWORD *v20; // rbp
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rdx
  __int64 v25; // rax
  __int64 v26; // rbp
  const boost::system::error_code *v27; // rax
  size_t v28; // rdx
  boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *v29; // rdi
  __int64 v30; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v31; // r14
  _QWORD *v32; // rbp
  int v33; // eax
  size_t v34; // rcx
  __int64 v35; // rbp
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v36; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v37; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v38; // rsi
  unsigned __int128 v39; // [rsp+0h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+10h] [rbp-38h]

  m_cat = ec.m_cat;
  *((_DWORD *)this + 8) = start;
  if ( start != 1 )
    goto LABEL_7;
  v7 = (boost::system::error_code *)((char *)this + 40);
  while ( 1 )
  {
    v8 = (boost::asio::ssl::detail::engine *)*((_QWORD *)this + 1);
    v39 = *((_OWORD *)this + 1);
    v9 = boost::asio::ssl::detail::engine::read(v8, (const boost::asio::mutable_buffer *)&v39, v7, (size_t *)this + 7);
    *((_DWORD *)this + 9) = v9;
    if ( v9 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v12 = *((_QWORD *)this + 1);
      if ( *(_QWORD *)(v12 + 232) )
      {
        v13 = BIO_write(*(_QWORD *)(v12 + 8), *(_QWORD *)(v12 + 224));
        v14 = 0;
        if ( (v13 & 0x80000000) != 0LL )
          v13 = 0;
        v15 = *(_QWORD *)(v12 + 232);
        if ( v15 >= v13 )
          v14 = v13 + *(_QWORD *)(v12 + 224);
        else
          v15 = v13;
        v16 = v15 - v13;
        v17 = *((_QWORD *)this + 1);
        *(_QWORD *)(v17 + 224) = v14;
        *(_QWORD *)(v17 + 232) = v16;
        goto LABEL_33;
      }
      if ( *(_QWORD *)(v12 + 24) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *(_BYTE *)(v12 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v12 + 16) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v12 + 16) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v12 + 40),
            0xFFFFFFFFFFFFFFFFLL);
          *(_BYTE *)(v12 + 32) = 0;
        }
        boost::system::system_category();
        *(_QWORD *)(v12 + 24) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        v38 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
        v39 = *(_OWORD *)(*((_QWORD *)this + 1) + 208LL);
        goto LABEL_55;
      }
      v36 = *(boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > **)(v12 + 16);
      v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)(v12 + 24);
LABEL_60:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        v36,
        v37,
        this);
      return;
    }
    if ( v9 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v9 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      v38 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
      v39 = *(unsigned __int64 *)(*((_QWORD *)this + 1) + 208LL);
LABEL_55:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        v38->service_,
        &v38->implementation,
        (const boost::asio::mutable_buffers_1 *)&v39,
        0,
        this);
      return;
    }
LABEL_7:
    if ( bytes_transferred != -1 && !*((_DWORD *)this + 10) )
    {
      *((_DWORD *)this + 10) = ec.m_val;
      *((_QWORD *)this + 6) = m_cat;
    }
    v10 = *((_DWORD *)this + 9);
    if ( v10 == -2 )
    {
      v18 = (_QWORD *)*((_QWORD *)this + 1);
      v19 = v18[27];
      if ( v19 >= bytes_transferred )
        v19 = bytes_transferred;
      v18[28] = v18[26];
      v18[29] = v19;
      v20 = (_QWORD *)*((_QWORD *)this + 1);
      v21 = BIO_write(v20[1], v20[28]);
      v22 = 0;
      if ( (v21 & 0x80000000) != 0LL )
        v21 = 0;
      v23 = v20[29];
      if ( v23 >= v21 )
        v22 = v21 + v20[28];
      else
        v23 = v21;
      v24 = v23 - v21;
      v25 = *((_QWORD *)this + 1);
      *(_QWORD *)(v25 + 224) = v22;
      *(_QWORD *)(v25 + 232) = v24;
      v26 = *((_QWORD *)this + 1);
      boost::system::system_category();
      if ( *(_BYTE *)(v26 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v26 + 16) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v26 + 16)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v26 + 40),
          0xFFFFFFFFFFFFFFFFLL);
        *(_BYTE *)(v26 + 32) = 0;
      }
      boost::system::system_category();
      *(_QWORD *)(v26 + 24) = 0x8000000000000000LL;
    }
    else
    {
      if ( v10 != -1 )
      {
        if ( v10 == 1 )
        {
          v35 = *((_QWORD *)this + 1);
          boost::system::system_category();
          if ( *(_BYTE *)(v35 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v35 + 80) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v35 + 80) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v35 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *(_BYTE *)(v35 + 96) = 0;
          }
          boost::system::system_category();
          *(_QWORD *)(v35 + 88) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v27 = boost::asio::ssl::detail::engine::map_error_code(
                *((const boost::asio::ssl::detail::engine **)this + 1),
                (boost::system::error_code *)((char *)this + 40));
        if ( *((_DWORD *)this + 10) )
          v28 = 0;
        else
          v28 = *((_QWORD *)this + 7);
        v29 = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)((char *)this + 64);
        goto LABEL_58;
      }
      v11 = *((_QWORD *)this + 1);
      boost::system::system_category();
      if ( *(_BYTE *)(v11 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v11 + 80) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v11 + 80)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v11 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *(_BYTE *)(v11 + 96) = 0;
      }
      boost::system::system_category();
      *(_QWORD *)(v11 + 88) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_33:
    v7 = (boost::system::error_code *)((char *)this + 40);
    if ( *((_DWORD *)this + 10) )
    {
      v27 = boost::asio::ssl::detail::engine::map_error_code(*((const boost::asio::ssl::detail::engine **)this + 1), v7);
      v28 = 0;
      v29 = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)((char *)this + 64);
LABEL_58:
      boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
        v29,
        v27,
        v28,
        0);
      return;
    }
  }
  v30 = *((_QWORD *)this + 1);
  if ( *(_QWORD *)(v30 + 88) != 0x8000000000000000LL )
  {
    v36 = *(boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > **)(v30 + 80);
    v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)(v30 + 88);
    goto LABEL_60;
  }
  boost::system::system_category();
  if ( *(_BYTE *)(v30 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*(_QWORD *)(v30 + 80) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*(_QWORD *)(v30 + 80)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)(v30 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *(_BYTE *)(v30 + 96) = 0;
  }
  boost::system::system_category();
  *(_QWORD *)(v30 + 88) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v31 = *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this;
  v32 = (_QWORD *)*((_QWORD *)this + 1);
  v33 = BIO_read(v32[1], v32[21], *((unsigned int *)v32 + 44));
  v34 = 0;
  if ( v33 >= 0 )
    v34 = (unsigned int)v33;
  if ( v32[22] < v34 )
    v34 = v32[22];
  *(_QWORD *)&v39 = v32[21];
  *((_QWORD *)&v39 + 1) = v34;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    v31,
    (const boost::asio::mutable_buffers_1 *)&v39,
    this);
}


// Address: 0x26b1f10 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail17read_streambuf_opINS1_6streamIRS9_EENSt3__19allocatorIcEENSD_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSI_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *op,
        boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v10; // [rsp+0h] [rbp-98h] BYREF
  boost::system::error_code v11; // 0:esi.4,8:rdx.8

  v10.next_layer_ = next_layer;
  v10.core_ = core;
  v10.op_ = *op;
  *(_QWORD *)&v10.start_ = 0;
  v10.ec_.m_val = 0;
  v10.ec_.m_cat = boost::system::system_category();
  v10.bytes_transferred_ = 0;
  v10.handler_ = *handler;
  handler->handler_.l_ = 0;
  v11.m_val = 0;
  v11.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
    &v10,
    v11,
    0,
    1);
  cntrl = v10.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v10.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *, _QWORD, __int64, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, int, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *, boost::asio::basic_streambuf<std::allocator<char> > *, int, size_t, boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*(_QWORD *)cntrl + 16LL))(
        cntrl,
        0,
        v5,
        v6,
        v7,
        v8,
        v10.next_layer_,
        v10.core_,
        v10.op_.buffers_.data_,
        v10.op_.buffers_.size_,
        *(_QWORD *)&v10.start_,
        v10.ec_.m_val,
        v10.ec_.m_cat,
        v10.bytes_transferred_,
        v10.handler_.completion_condition_.size_,
        v10.handler_.stream_,
        v10.handler_.streambuf_,
        v10.handler_.start_,
        v10.handler_.total_transferred_,
        v10.handler_.handler_.f_.f_,
        *((_QWORD *)&v10.handler_.handler_.f_.f_ + 1),
        v10.handler_.handler_.l_.a1_.t_.__ptr_);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b2020 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail17read_streambuf_opINS1_6streamIRS9_EENSt3__19allocatorIcEENSD_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSI_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEclESW_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  boost::system::error_code *p_ec; // rdx
  boost::asio::ssl::detail::stream_core *core; // rdi
  boost::asio::ssl::detail::engine::want v9; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v11; // rbp
  boost::asio::ssl::detail::stream_core *v12; // rbp
  unsigned __int64 v13; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rdx
  boost::asio::ssl::detail::stream_core *v17; // rax
  boost::asio::ssl::detail::stream_core *v18; // rax
  size_t v19; // rdx
  boost::asio::ssl::detail::stream_core *v20; // rbp
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rdx
  boost::asio::ssl::detail::stream_core *v25; // rax
  boost::asio::ssl::detail::stream_core *v26; // rbp
  const boost::system::error_code *v27; // rax
  size_t v28; // rdx
  boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *p_handler; // rdi
  boost::asio::ssl::detail::stream_core *v30; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v31; // r14
  boost::asio::ssl::detail::stream_core *v32; // rbp
  int v33; // eax
  size_t v34; // rcx
  boost::asio::ssl::detail::stream_core *v35; // rbp
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v36; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v37; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rsi
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> op; // [rsp+0h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+10h] [rbp-38h]

  m_cat = ec.m_cat;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_7;
  p_ec = &this->ec_;
  while ( 1 )
  {
    core = this->core_;
    op = this->op_;
    v9 = boost::asio::ssl::detail::engine::read(
           (boost::asio::ssl::detail::engine *)core,
           &op.buffers_,
           p_ec,
           &this->bytes_transferred_);
    this->want_ = v9;
    if ( v9 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v12 = this->core_;
      if ( *((_QWORD *)v12 + 29) )
      {
        v13 = BIO_write(*((_QWORD *)v12 + 1), *((_QWORD *)v12 + 28));
        v14 = 0;
        if ( (v13 & 0x80000000) != 0LL )
          v13 = 0;
        v15 = *((_QWORD *)v12 + 29);
        if ( v15 >= v13 )
          v14 = v13 + *((_QWORD *)v12 + 28);
        else
          v15 = v13;
        v16 = v15 - v13;
        v17 = this->core_;
        *((_QWORD *)v17 + 28) = v14;
        *((_QWORD *)v17 + 29) = v16;
        goto LABEL_33;
      }
      if ( *((_QWORD *)v12 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v12 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v12 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v12 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v12
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v12 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v12 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        op = (boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>)*((_OWORD *)this->core_ + 13);
        goto LABEL_55;
      }
      v36 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v12 + 2);
      v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v12 + 24);
LABEL_60:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        v36,
        v37,
        this);
      return;
    }
    if ( v9 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v9 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      op = (boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>)*((unsigned __int64 *)this->core_ + 26);
LABEL_55:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        next_layer->service_,
        &next_layer->implementation,
        &op.buffers_,
        0,
        this);
      return;
    }
LABEL_7:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = ec.m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v18 = this->core_;
      v19 = *((_QWORD *)v18 + 27);
      if ( v19 >= bytes_transferred )
        v19 = bytes_transferred;
      *((_QWORD *)v18 + 28) = *((_QWORD *)v18 + 26);
      *((_QWORD *)v18 + 29) = v19;
      v20 = this->core_;
      v21 = BIO_write(*((_QWORD *)v20 + 1), *((_QWORD *)v20 + 28));
      v22 = 0;
      if ( (v21 & 0x80000000) != 0LL )
        v21 = 0;
      v23 = *((_QWORD *)v20 + 29);
      if ( v23 >= v21 )
        v22 = v21 + *((_QWORD *)v20 + 28);
      else
        v23 = v21;
      v24 = v23 - v21;
      v25 = this->core_;
      *((_QWORD *)v25 + 28) = v22;
      *((_QWORD *)v25 + 29) = v24;
      v26 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v26 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v26 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v26 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v26
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v26 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v26 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v35 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v35 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v35 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v35 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v35 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v35 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v35 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v27 = boost::asio::ssl::detail::engine::map_error_code(
                (const boost::asio::ssl::detail::engine *)this->core_,
                &this->ec_);
        if ( this->ec_.m_val )
          v28 = 0;
        else
          v28 = this->bytes_transferred_;
        p_handler = &this->handler_;
        goto LABEL_58;
      }
      v11 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v11 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v11 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v11 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v11 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v11 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v11 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_33:
    p_ec = &this->ec_;
    if ( this->ec_.m_val )
    {
      v27 = boost::asio::ssl::detail::engine::map_error_code(
              (const boost::asio::ssl::detail::engine *)this->core_,
              p_ec);
      v28 = 0;
      p_handler = &this->handler_;
LABEL_58:
      boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>::operator()(
        p_handler,
        v27,
        v28,
        0);
      return;
    }
  }
  v30 = this->core_;
  if ( *((_QWORD *)v30 + 11) != 0x8000000000000000LL )
  {
    v36 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v30 + 10);
    v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v30 + 88);
    goto LABEL_60;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v30 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v30 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v30 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v30 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v30 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v30 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v31 = this->next_layer_;
  v32 = this->core_;
  v33 = BIO_read(*((_QWORD *)v32 + 1), *((_QWORD *)v32 + 21), *((unsigned int *)v32 + 44));
  v34 = 0;
  if ( v33 >= 0 )
    v34 = (unsigned int)v33;
  if ( *((_QWORD *)v32 + 22) < v34 )
    v34 = *((_QWORD *)v32 + 22);
  op.buffers_.data_ = (void *)*((_QWORD *)v32 + 21);
  op.buffers_.size_ = v34;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    v31,
    &op.buffers_,
    this);
}


// Address: 0x26b5960 | Name: _ZN5boost4asio3ssl6detail8async_ioINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail17read_streambuf_opINS1_6streamIRS9_EENSt3__19allocatorIcEENSD_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSM_5list3INSM_5valueINSI_10shared_ptrISU_EEEEPFNS_3argILi1EEEvENS11_IiEEEEEEEEEEvRT_RNS2_11stream_coreERKT0_RT1_
void __fastcall boost::asio::ssl::detail::async_io<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer,
        boost::asio::ssl::detail::stream_core *core,
        const boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *op,
        boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > v6; // [rsp+8h] [rbp-A0h] BYREF
  boost::system::error_code v7; // 0:esi.4,8:rdx.8

  v6.next_layer_ = next_layer;
  v6.core_ = core;
  v6.op_ = *op;
  *(_QWORD *)&v6.start_ = 0;
  v6.ec_.m_val = 0;
  v6.ec_.m_cat = boost::system::system_category();
  v6.bytes_transferred_ = 0;
  *(_OWORD *)&v6.handler_.completion_condition_.size_ = *(_OWORD *)&handler->completion_condition_.size_;
  v6.handler_.streambuf_ = handler->streambuf_;
  v6.handler_.start_ = handler->start_;
  v6.handler_.total_transferred_ = handler->total_transferred_;
  v6.handler_.handler_.f_ = handler->handler_.f_;
  v6.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  v6.handler_.handler_.l_.a3_.t_ = handler->handler_.l_.a3_.t_;
  v7.m_val = 0;
  v7.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>::operator()(
    &v6,
    v7,
    0,
    1);
  cntrl = v6.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b5a80 | Name: _ZN5boost4asio3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEENS2_7read_opINS0_17mutable_buffers_1EEENS0_6detail17read_streambuf_opINS1_6streamIRS9_EENSt3__19allocatorIcEENSD_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSM_5list3INSM_5valueINSI_10shared_ptrISU_EEEEPFNS_3argILi1EEEvENS11_IiEEEEEEEEEclESW_mi
void __fastcall boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>::operator()(
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > *this,
        boost::system::error_code ec,
        size_t bytes_transferred,
        int start)
{
  boost::system::error_code *p_ec; // rdx
  boost::asio::ssl::detail::stream_core *core; // rdi
  boost::asio::ssl::detail::engine::want v9; // eax
  boost::asio::ssl::detail::engine::want want; // eax
  boost::asio::ssl::detail::stream_core *v11; // rbp
  boost::asio::ssl::detail::stream_core *v12; // rbp
  unsigned __int64 v13; // rax
  unsigned __int64 v14; // rcx
  unsigned __int64 v15; // rdx
  unsigned __int64 v16; // rdx
  boost::asio::ssl::detail::stream_core *v17; // rax
  boost::asio::ssl::detail::stream_core *v18; // rax
  size_t v19; // rdx
  boost::asio::ssl::detail::stream_core *v20; // rbp
  unsigned __int64 v21; // rax
  unsigned __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rdx
  boost::asio::ssl::detail::stream_core *v25; // rax
  boost::asio::ssl::detail::stream_core *v26; // rbp
  const boost::system::error_code *v27; // rax
  size_t v28; // rdx
  boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > *p_handler; // rdi
  boost::asio::ssl::detail::stream_core *v30; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v31; // r14
  boost::asio::ssl::detail::stream_core *v32; // rbp
  int v33; // eax
  size_t v34; // rcx
  boost::asio::ssl::detail::stream_core *v35; // rbp
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *v36; // rdi
  boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *v37; // rbp
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *next_layer; // rsi
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> op; // [rsp+0h] [rbp-48h] BYREF
  const boost::system::error_category *m_cat; // [rsp+10h] [rbp-38h]

  m_cat = ec.m_cat;
  this->start_ = start;
  if ( start != 1 )
    goto LABEL_7;
  p_ec = &this->ec_;
  while ( 1 )
  {
    core = this->core_;
    op = this->op_;
    v9 = boost::asio::ssl::detail::engine::read(
           (boost::asio::ssl::detail::engine *)core,
           &op.buffers_,
           p_ec,
           &this->bytes_transferred_);
    this->want_ = v9;
    if ( v9 == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v12 = this->core_;
      if ( *((_QWORD *)v12 + 29) )
      {
        v13 = BIO_write(*((_QWORD *)v12 + 1), *((_QWORD *)v12 + 28));
        v14 = 0;
        if ( (v13 & 0x80000000) != 0LL )
          v13 = 0;
        v15 = *((_QWORD *)v12 + 29);
        if ( v15 >= v13 )
          v14 = v13 + *((_QWORD *)v12 + 28);
        else
          v15 = v13;
        v16 = v15 - v13;
        v17 = this->core_;
        *((_QWORD *)v17 + 28) = v14;
        *((_QWORD *)v17 + 29) = v16;
        goto LABEL_33;
      }
      if ( *((_QWORD *)v12 + 3) == 0x8000000000000000LL )
      {
        boost::system::system_category();
        if ( *((_BYTE *)v12 + 32) )
        {
          boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
            *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v12 + 2) + 104LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v12 + 2) + 40LL),
            (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v12
          + 1,
            0xFFFFFFFFFFFFFFFFLL);
          *((_BYTE *)v12 + 32) = 0;
        }
        boost::system::system_category();
        *((_QWORD *)v12 + 3) = 0x7FFFFFFFFFFFFFFFLL;
        boost::system::system_category();
        next_layer = this->next_layer_;
        op = (boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>)*((_OWORD *)this->core_ + 13);
        goto LABEL_55;
      }
      v36 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v12 + 2);
      v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v12 + 24);
LABEL_60:
      boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
        v36,
        v37,
        this);
      return;
    }
    if ( v9 == boost::asio::ssl::detail::engine::want::want_output_and_retry
      || v9 == boost::asio::ssl::detail::engine::want::want_output )
    {
      break;
    }
    if ( start )
    {
      next_layer = this->next_layer_;
      op = (boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>)*((unsigned __int64 *)this->core_ + 26);
LABEL_55:
      boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
        next_layer->service_,
        &next_layer->implementation,
        &op.buffers_,
        0,
        this);
      return;
    }
LABEL_7:
    if ( bytes_transferred != -1 && !this->ec_.m_val )
    {
      this->ec_.m_val = ec.m_val;
      this->ec_.m_cat = m_cat;
    }
    want = this->want_;
    if ( want == boost::asio::ssl::detail::engine::want::want_input_and_retry )
    {
      v18 = this->core_;
      v19 = *((_QWORD *)v18 + 27);
      if ( v19 >= bytes_transferred )
        v19 = bytes_transferred;
      *((_QWORD *)v18 + 28) = *((_QWORD *)v18 + 26);
      *((_QWORD *)v18 + 29) = v19;
      v20 = this->core_;
      v21 = BIO_write(*((_QWORD *)v20 + 1), *((_QWORD *)v20 + 28));
      v22 = 0;
      if ( (v21 & 0x80000000) != 0LL )
        v21 = 0;
      v23 = *((_QWORD *)v20 + 29);
      if ( v23 >= v21 )
        v22 = v21 + *((_QWORD *)v20 + 28);
      else
        v23 = v21;
      v24 = v23 - v21;
      v25 = this->core_;
      *((_QWORD *)v25 + 28) = v22;
      *((_QWORD *)v25 + 29) = v24;
      v26 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v26 + 32) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v26 + 2) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v26 + 2)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)v26
        + 1,
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v26 + 32) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v26 + 3) = 0x8000000000000000LL;
    }
    else
    {
      if ( want != boost::asio::ssl::detail::engine::want::want_output_and_retry )
      {
        if ( want == boost::asio::ssl::detail::engine::want::want_output )
        {
          v35 = this->core_;
          boost::system::system_category();
          if ( *((_BYTE *)v35 + 96) )
          {
            boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
              *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v35 + 10) + 104LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v35 + 10) + 40LL),
              (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v35 + 104),
              0xFFFFFFFFFFFFFFFFLL);
            *((_BYTE *)v35 + 96) = 0;
          }
          boost::system::system_category();
          *((_QWORD *)v35 + 11) = 0x8000000000000000LL;
          boost::system::system_category();
        }
        v27 = boost::asio::ssl::detail::engine::map_error_code(
                (const boost::asio::ssl::detail::engine *)this->core_,
                &this->ec_);
        if ( this->ec_.m_val )
          v28 = 0;
        else
          v28 = this->bytes_transferred_;
        p_handler = &this->handler_;
        goto LABEL_58;
      }
      v11 = this->core_;
      boost::system::system_category();
      if ( *((_BYTE *)v11 + 96) )
      {
        boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v11 + 10) + 104LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v11 + 10)
                                                                                                  + 40LL),
          (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v11 + 104),
          0xFFFFFFFFFFFFFFFFLL);
        *((_BYTE *)v11 + 96) = 0;
      }
      boost::system::system_category();
      *((_QWORD *)v11 + 11) = 0x8000000000000000LL;
    }
    boost::system::system_category();
LABEL_33:
    p_ec = &this->ec_;
    if ( this->ec_.m_val )
    {
      v27 = boost::asio::ssl::detail::engine::map_error_code(
              (const boost::asio::ssl::detail::engine *)this->core_,
              p_ec);
      v28 = 0;
      p_handler = &this->handler_;
LABEL_58:
      boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>::operator()(
        p_handler,
        v27,
        v28,
        0);
      return;
    }
  }
  v30 = this->core_;
  if ( *((_QWORD *)v30 + 11) != 0x8000000000000000LL )
  {
    v36 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)*((_QWORD *)v30 + 10);
    v37 = (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *)((char *)v30 + 88);
    goto LABEL_60;
  }
  boost::system::system_category();
  if ( *((_BYTE *)v30 + 96) )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *(boost::asio::detail::epoll_reactor **)(*((_QWORD *)v30 + 10) + 104LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)(*((_QWORD *)v30 + 10)
                                                                                              + 40LL),
      (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> >::per_timer_data *)((char *)v30 + 104),
      0xFFFFFFFFFFFFFFFFLL);
    *((_BYTE *)v30 + 96) = 0;
  }
  boost::system::system_category();
  *((_QWORD *)v30 + 11) = 0x7FFFFFFFFFFFFFFFLL;
  boost::system::system_category();
  v31 = this->next_layer_;
  v32 = this->core_;
  v33 = BIO_read(*((_QWORD *)v32 + 1), *((_QWORD *)v32 + 21), *((unsigned int *)v32 + 44));
  v34 = 0;
  if ( v33 >= 0 )
    v34 = (unsigned int)v33;
  if ( *((_QWORD *)v32 + 22) < v34 )
    v34 = *((_QWORD *)v32 + 22);
  op.buffers_.data_ = (void *)*((_QWORD *)v32 + 21);
  op.buffers_.size_ = v34;
  boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
    v31,
    &op.buffers_,
    this);
}


