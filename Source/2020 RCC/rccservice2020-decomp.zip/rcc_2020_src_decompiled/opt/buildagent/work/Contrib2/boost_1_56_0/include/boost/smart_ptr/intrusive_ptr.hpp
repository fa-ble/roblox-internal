// Address: 0xd9feb0 | Name: _ZN5boost13intrusive_ptrIN3rbx7signals9slot_baseEED2Ev
void __fastcall boost::intrusive_ptr<rbx::signals::slot_base>::~intrusive_ptr(
        boost::intrusive_ptr<rbx::signals::slot_base> *this)
{
  rbx::signals::slot_base *px; // rbx
  void (__fastcall *dtor)(rbx::signals::slot_base *); // rax

  px = this->px;
  if ( this->px
    && !_InterlockedSub((volatile signed __int32 *)&px->rbx::intrusive_ptr_target<rbx::signals::slot_base>, 1u) )
  {
    dtor = px->dtor;
    if ( dtor )
      dtor(px);
    boost::intrusive_ptr<rbx::signals::slot_base>::~intrusive_ptr(&px->next);
    if ( !_InterlockedSub(&px->weak.v, 1u) )
      operator delete(px);
  }
}


// Address: 0x11aea50 | Name: _ZN5boost13intrusive_ptrIN3RBX3Lua13WeakThreadRef4NodeEED2Ev
void __fastcall boost::intrusive_ptr<RBX::Lua::WeakThreadRef::Node>::~intrusive_ptr(
        boost::intrusive_ptr<RBX::Lua::WeakThreadRef::Node> *this)
{
  RBX::Lua::WeakThreadRef::Node *px; // rbx

  px = this->px;
  if ( this->px )
  {
    if ( !_InterlockedSub(&px->refs.v, 1u) )
    {
      RBX::Lua::WeakThreadRef::Node::~Node(px);
      operator delete(px);
    }
  }
}


// Address: 0x11e5ba0 | Name: _ZN5boost13intrusive_ptrIN3RBX3Lua6detail13LiveThreadRefEED2Ev
void __fastcall boost::intrusive_ptr<RBX::Lua::detail::LiveThreadRef>::~intrusive_ptr(
        boost::intrusive_ptr<RBX::Lua::detail::LiveThreadRef> *this)
{
  RBX::Lua::detail::LiveThreadRef *px; // rbx

  px = this->px;
  if ( this->px )
  {
    if ( !_InterlockedSub(&px->refs.v, 1u) )
    {
      RBX::Lua::detail::LiveThreadRef::~LiveThreadRef(px);
      operator delete(px);
    }
  }
}


// Address: 0x1d4cfa0 | Name: _ZN5boost13intrusive_ptrIN3RBX8GuidItemINS1_8InstanceEE8RegistryEED2Ev
void __fastcall boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry>::~intrusive_ptr(
        boost::intrusive_ptr<RBX::GuidItem<RBX::Instance>::Registry> *this)
{
  RBX::GuidItem<RBX::Instance>::Registry *px; // rbx

  px = this->px;
  if ( this->px )
  {
    if ( !_InterlockedSub(&px->refs.v, 1u) )
    {
      RBX::GuidItem<RBX::Instance>::Registry::~Registry(px);
      operator delete(px);
    }
  }
}


