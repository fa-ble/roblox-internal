// Address: 0xe3f950 | Name: _ZN5boost15program_options18parse_command_lineIcEENS0_20basic_parsed_optionsIT_EEiPKPKS3_RKNS0_19options_descriptionEiNS_9function1INSt3__14pairINSD_12basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEESK_EERKSK_EE
std::__vector_base<boost::program_options::basic_option<char>> *__fastcall boost::program_options::parse_command_line<char>(
        std::__vector_base<boost::program_options::basic_option<char>> *this,
        int a2,
        const char *const *a3,
        const boost::program_options::options_description *a4,
        int a5,
        __int64 a6)
{
  unsigned __int64 v9; // rax
  boost::program_options::detail::cmdline *v10; // rax
  void (__fastcall *v11)(char *, char *, __int64); // rax
  boost::program_options::ext_parser v13; // [rsp+0h] [rbp-C8h] BYREF
  __int64 v14; // [rsp+20h] [rbp-A8h]
  _BYTE v15[112]; // [rsp+28h] [rbp-A0h] BYREF
  const boost::program_options::options_description *v16; // [rsp+98h] [rbp-30h]

  boost::program_options::basic_command_line_parser<char>::basic_command_line_parser(
    (boost::program_options::basic_command_line_parser<char> *)v15,
    a2,
    a3);
  boost::program_options::detail::cmdline::set_options_description((boost::program_options::detail::cmdline *)v15, a4);
  v16 = a4;
  boost::program_options::detail::cmdline::style((boost::program_options::detail::cmdline *)v15, a5);
  v13.functor.obj_ptr = 0;
  v9 = *(_QWORD *)a6;
  if ( *(_QWORD *)a6 )
  {
    v13.functor.obj_ptr = *(void **)a6;
    if ( (v9 & 1) != 0 )
    {
      v14 = *(_QWORD *)(a6 + 24);
      *(_OWORD *)(&v13.functor.data + 8) = *(_OWORD *)(a6 + 8);
    }
    else
    {
      (*(void (__fastcall **)(__int64, bool *, _QWORD))(v9 & 0xFFFFFFFFFFFFFFFELL))(
        a6 + 8,
        &v13.functor.type.const_qualified,
        0);
    }
  }
  v10 = boost::program_options::basic_command_line_parser<char>::extra_parser(
          (boost::program_options::basic_command_line_parser<char> *)v15,
          v13);
  boost::program_options::basic_command_line_parser<char>::run(this, v10);
  if ( v13.functor.obj_ptr )
  {
    if ( (v13.functor.data & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(char *, char *, __int64))((unsigned __int64)v13.functor.obj_ptr & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(v13.functor.bound_memfunc_ptr.gap8, v13.functor.bound_memfunc_ptr.gap8, 2);
    }
    v13.functor.obj_ptr = 0;
  }
  boost::program_options::detail::cmdline::~cmdline((boost::program_options::detail::cmdline *)v15);
  return this;
}


// Address: 0xe442f0 | Name: _ZN5boost15program_options25basic_command_line_parserIcEC2EiPKPKc
void __fastcall boost::program_options::basic_command_line_parser<char>::basic_command_line_parser(
        boost::program_options::basic_command_line_parser<char> *this,
        int argc,
        const char *const *argv)
{
  void **v3; // r14
  void **v4; // rax
  void **v5; // rbx
  void *v6; // rdi
  void **v7; // r14
  void **v8; // rax
  void **v9; // rbx
  void *v10; // rdi
  void *ptr; // [rsp+0h] [rbp-48h] BYREF
  void **v12; // [rsp+8h] [rbp-40h]
  void *v13; // [rsp+18h] [rbp-30h] BYREF
  void **v14; // [rsp+20h] [rbp-28h]

  boost::program_options::detail::make_vector<char,char const* const*>((std::vector<std::string> *)&v13);
  boost::program_options::to_internal<std::string>((std::vector<std::string> *)&ptr, (int)ptr, v12);
  boost::program_options::detail::cmdline::cmdline(this, (const std::vector<std::string> *)&ptr);
  v3 = (void **)ptr;
  if ( ptr )
  {
    v4 = v12;
    if ( v12 == ptr )
    {
      v6 = ptr;
    }
    else
    {
      do
      {
        v5 = v4 - 3;
        if ( (*(_BYTE *)(v4 - 3) & 1) != 0 )
          operator delete(*(v4 - 1));
        v4 = v5;
      }
      while ( v3 != v5 );
      v6 = ptr;
    }
    v12 = v3;
    operator delete(v6);
  }
  v7 = (void **)v13;
  if ( v13 )
  {
    v8 = v14;
    if ( v14 == v13 )
    {
      v10 = v13;
    }
    else
    {
      do
      {
        v9 = v8 - 3;
        if ( (*(_BYTE *)(v8 - 3) & 1) != 0 )
          operator delete(*(v8 - 1));
        v8 = v9;
      }
      while ( v7 != v9 );
      v10 = v13;
    }
    v14 = v7;
    operator delete(v10);
  }
}


// Address: 0xe44480 | Name: _ZN5boost15program_options25basic_command_line_parserIcE12extra_parserENS_9function1INSt3__14pairINS4_12basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEESB_EERKSB_EE
boost::program_options::basic_command_line_parser<char> *__fastcall boost::program_options::basic_command_line_parser<char>::extra_parser(
        boost::program_options::basic_command_line_parser<char> *this,
        __int64 a2)
{
  boost::detail::function::vtable_base *v2; // rcx
  void (__fastcall *v3)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::program_options::detail::cmdline::additional_parser p; // [rsp+0h] [rbp-28h] BYREF

  p.vtable = 0;
  v2 = *(boost::detail::function::vtable_base **)a2;
  if ( *(_QWORD *)a2 )
  {
    p.vtable = *(boost::detail::function::vtable_base **)a2;
    if ( ((unsigned __int8)v2 & 1) != 0 )
      p.functor = *(boost::detail::function::function_buffer *)(a2 + 8);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v2
                                                                                          & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 8,
        &p.functor,
        0);
  }
  boost::program_options::detail::cmdline::set_additional_parser(this, p);
  if ( p.vtable )
  {
    if ( ((__int64)p.vtable & 1) == 0 )
    {
      v3 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)p.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v3 )
        v3(&p.functor, &p.functor, 2);
    }
    p.vtable = 0;
  }
  return this;
}


// Address: 0xe44560 | Name: _ZN5boost15program_options25basic_command_line_parserIcE3runEv
std::__vector_base<boost::program_options::basic_option<char>> *__fastcall boost::program_options::basic_command_line_parser<char>::run(
        std::__vector_base<boost::program_options::basic_option<char>> *this,
        boost::program_options::detail::cmdline *a2)
{
  __int64 v3; // r15
  const boost::program_options::basic_option<char> *v4; // rbx
  boost::program_options::basic_option<char> *v5; // r15
  signed __int64 v6; // rdi
  unsigned __int64 v7; // r12
  boost::program_options::basic_option<char> *v8; // rdi
  struct _Unwind_Exception *v10; // rbx
  boost::program_options::basic_option<char> *v11[2]; // [rsp+0h] [rbp-68h] BYREF
  __int64 v12; // [rsp+10h] [rbp-58h]
  __int64 v13; // [rsp+18h] [rbp-50h]
  int canonical_option_prefix; // [rsp+20h] [rbp-48h]
  __int128 v15; // [rsp+30h] [rbp-38h] BYREF
  __int64 v16; // [rsp+40h] [rbp-28h]

  v3 = *((_QWORD *)a2 + 14);
  *(_OWORD *)v11 = 0;
  v12 = 0;
  v13 = v3;
  canonical_option_prefix = boost::program_options::detail::cmdline::get_canonical_option_prefix(a2);
  boost::program_options::detail::cmdline::run((boost::program_options::detail::cmdline *)&v15);
  std::vector<boost::program_options::basic_option<char>>::deallocate((std::vector<boost::program_options::basic_option<char>> *)v11);
  *(_OWORD *)v11 = v15;
  v12 = v16;
  v15 = 0;
  v16 = 0;
  std::__vector_base<boost::program_options::basic_option<char>>::~__vector_base((std::__vector_base<boost::program_options::basic_option<char>> *)&v15);
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  v4 = v11[0];
  v5 = v11[1];
  v6 = v11[1] - v11[0];
  if ( v11[1] != v11[0] )
  {
    v7 = 0x2E8BA2E8BA2E8BA3LL * (v6 >> 3);
    if ( v7 >= 0x2E8BA2E8BA2E8BBLL )
    {
      v10 = (struct _Unwind_Exception *)std::__vector_base_common<true>::__throw_length_error(this);
      std::__vector_base<boost::program_options::basic_option<char>>::~__vector_base(this);
      std::__vector_base<boost::program_options::basic_option<char>>::~__vector_base((std::__vector_base<boost::program_options::basic_option<char>> *)v11);
      _Unwind_Resume(v10);
    }
    v8 = (boost::program_options::basic_option<char> *)operator new(v6);
    *((_QWORD *)this + 1) = v8;
    *(_QWORD *)this = v8;
    for ( *((_QWORD *)this + 2) = (char *)v8 + 88 * v7; v5 != v4; *((_QWORD *)this + 1) = v8 )
    {
      boost::program_options::basic_option<char>::basic_option(v8, v4);
      v4 = (const boost::program_options::basic_option<char> *)((char *)v4 + 88);
      v8 = (boost::program_options::basic_option<char> *)(*((_QWORD *)this + 1) + 88LL);
    }
  }
  *((_DWORD *)this + 8) = canonical_option_prefix;
  *((_QWORD *)this + 3) = v13;
  std::__vector_base<boost::program_options::basic_option<char>>::~__vector_base((std::__vector_base<boost::program_options::basic_option<char>> *)v11);
  return this;
}


// Address: 0xe448f0 | Name: _ZN5boost15program_options6detail11make_vectorIcPKPKcEENSt3__16vectorINS7_12basic_stringIT_NS7_11char_traitsISA_EENS7_9allocatorISA_EEEENSD_ISF_EEEET0_SI_
std::vector<std::string> *__fastcall boost::program_options::detail::make_vector<char,char const* const*>(
        std::vector<std::string> *this,
        const char **a2,
        const char **a3)
{
  std::vector<std::string> *v3; // r15
  const char **v4; // r14
  const char **i; // r13
  const char *v6; // rbx
  size_t v7; // rax
  size_t v8; // rbp
  char *v9; // r12
  const char **v10; // r15
  size_t v11; // r14
  unsigned __int64 v12; // rax
  struct _Unwind_Exception *v14; // r14
  __int64 v15; // rbp
  __int64 v16; // rax
  __int64 v17; // rbx
  void *v18; // rdi
  __int128 dest; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]

  v3 = this;
  *(_OWORD *)this = 0;
  *((_QWORD *)this + 2) = 0;
  if ( a2 != a3 )
  {
    v4 = a3;
    for ( i = a2; v4 != i; ++i )
    {
      v6 = *i;
      dest = 0;
      ptr = 0;
      v7 = strlen(v6);
      if ( v7 >= 0xFFFFFFFFFFFFFFF0LL )
      {
        v14 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(&dest);
        v15 = *(_QWORD *)this;
        if ( *(_QWORD *)this )
        {
          v16 = *((_QWORD *)this + 1);
          if ( v16 == v15 )
          {
            v18 = *(void **)this;
          }
          else
          {
            do
            {
              v17 = v16 - 24;
              if ( (*(_BYTE *)(v16 - 24) & 1) != 0 )
                operator delete(*(void **)(v16 - 8));
              v16 = v17;
            }
            while ( v15 != v17 );
            v18 = *(void **)this;
          }
          *((_QWORD *)this + 1) = v15;
          operator delete(v18);
        }
        _Unwind_Resume(v14);
      }
      v8 = v7;
      if ( v7 >= 0x17 )
      {
        v10 = v4;
        v11 = (v7 + 16) & 0xFFFFFFFFFFFFFFF0LL;
        v9 = (char *)operator new(v11);
        ptr = v9;
        *(_QWORD *)&dest = v11 | 1;
        *((_QWORD *)&dest + 1) = v8;
        v4 = v10;
        v3 = this;
      }
      else
      {
        LOBYTE(dest) = 2 * v7;
        v9 = (char *)&dest + 1;
        if ( !v7 )
          goto LABEL_9;
      }
      memcpy(v9, v6, v8);
LABEL_9:
      v9[v8] = 0;
      v12 = *((_QWORD *)v3 + 1);
      if ( v12 >= *((_QWORD *)v3 + 2) )
      {
        std::vector<std::string>::__push_back_slow_path<std::string>(v3, (std::string *)&dest);
        if ( (dest & 1) != 0 )
          operator delete(ptr);
      }
      else
      {
        *(_QWORD *)(v12 + 16) = ptr;
        *(_OWORD *)v12 = dest;
        dest = 0;
        ptr = 0;
        *((_QWORD *)v3 + 1) += 24LL;
      }
    }
  }
  return v3;
}


