// Address: 0xdac0b0 | Name: _ZN5boost5mutexC2Ev
void __fastcall boost::mutex::mutex(boost::mutex *this)
{
  int v1; // eax
  int v2; // ebx
  const boost::system::error_category *v3; // r14
  _QWORD v4[2]; // [rsp+8h] [rbp-50h] BYREF
  int v5; // [rsp+18h] [rbp-40h]
  const boost::system::error_category *v6; // [rsp+20h] [rbp-38h]
  __int128 v7; // [rsp+28h] [rbp-30h]
  void *ptr; // [rsp+38h] [rbp-20h]

  v1 = pthread_mutex_init(&this->m, 0);
  if ( v1 )
  {
    v2 = v1;
    v3 = boost::system::system_category();
    std::runtime_error::runtime_error(
      (std::runtime_error *)v4,
      "boost:: mutex constructor failed in pthread_mutex_init");
    v5 = v2;
    v6 = v3;
    v7 = 0;
    ptr = 0;
    v4[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v4);
  }
}


// Address: 0xdac780 | Name: _ZN5boost5mutexD2Ev
void __fastcall boost::mutex::~mutex(boost::mutex *this)
{
  while ( pthread_mutex_destroy(&this->m) == 4 )
    ;
}


// Address: 0xdb05b0 | Name: _ZN5boost5mutex4lockEv
void __fastcall boost::mutex::lock(boost::mutex *this)
{
  int v1; // eax
  int v2; // ebx
  const boost::system::error_category *v3; // r14
  _QWORD v4[2]; // [rsp+8h] [rbp-50h] BYREF
  int v5; // [rsp+18h] [rbp-40h]
  const boost::system::error_category *v6; // [rsp+20h] [rbp-38h]
  __int128 v7; // [rsp+28h] [rbp-30h]
  __int64 v8; // [rsp+38h] [rbp-20h]

  while ( 1 )
  {
    v1 = pthread_mutex_lock(&this->m);
    if ( !v1 )
      break;
    v2 = v1;
    if ( v1 != 4 )
    {
      v3 = boost::system::system_category();
      std::runtime_error::runtime_error((std::runtime_error *)v4, "boost: mutex lock failed in pthread_mutex_lock");
      v5 = v2;
      v6 = v3;
      v7 = 0;
      v8 = 0;
      v4[0] = off_28763C8;
      boost::throw_exception<boost::lock_error>((const boost::lock_error *)v4);
    }
  }
}


// Address: 0xdb11c0 | Name: _ZN5boost5mutex6unlockEv
void __fastcall boost::mutex::unlock(boost::mutex *this)
{
  int v1; // eax
  int v2; // ebx
  const boost::system::error_category *v3; // r14
  _QWORD v4[2]; // [rsp+8h] [rbp-50h] BYREF
  int v5; // [rsp+18h] [rbp-40h]
  const boost::system::error_category *v6; // [rsp+20h] [rbp-38h]
  __int128 v7; // [rsp+28h] [rbp-30h]
  __int64 v8; // [rsp+38h] [rbp-20h]

  while ( 1 )
  {
    v1 = pthread_mutex_unlock(&this->m);
    if ( !v1 )
      break;
    v2 = v1;
    if ( v1 != 4 )
    {
      v3 = boost::system::system_category();
      std::runtime_error::runtime_error((std::runtime_error *)v4, "boost: mutex unlock failed in pthread_mutex_unlock");
      v5 = v2;
      v6 = v3;
      v7 = 0;
      v8 = 0;
      v4[0] = off_28763C8;
      boost::throw_exception<boost::lock_error>((const boost::lock_error *)v4);
    }
  }
}


