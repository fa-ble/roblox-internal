// Address: 0x26056c0 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE19implementation_typeD2Ev
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::implementation_type::~implementation_type(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *this)
{
  boost::asio::detail::wait_op *i; // rbx
  boost::asio::detail::wait_op *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v4; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v5; // [rsp+10h] [rbp-28h]

  for ( i = this->timer_data.op_queue_.front_; i; i = this->timer_data.op_queue_.front_ )
  {
    next = (boost::asio::detail::wait_op *)i->next_;
    this->timer_data.op_queue_.front_ = (boost::asio::detail::wait_op *)i->next_;
    if ( !next )
      this->timer_data.op_queue_.back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v4 = 0;
    v5 = boost::system::system_category();
    func(0, i, &v4, 0);
  }
}


// Address: 0x26057a0 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEEC2ERNS0_10io_serviceE
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::deadline_timer_service(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::io_service *io_service)
{
  boost::asio::detail::service_registry *service_registry; // rdi
  boost::asio::io_service::service *v4; // rax
  __int64 v5; // r15
  boost::asio::io_service::service::key_0 key; // [rsp+8h] [rbp-30h] BYREF

  *((_QWORD *)this + 1) = 0;
  *(_QWORD *)this = &off_29C3188;
  *((_QWORD *)this + 3) = 0;
  *((_QWORD *)this + 2) = &off_29C3218;
  *((_OWORD *)this + 3) = 0;
  *((_OWORD *)this + 2) = 0;
  service_registry = io_service->service_registry_;
  key.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::detail::epoll_reactor>;
  key.id_ = 0;
  v4 = boost::asio::detail::service_registry::do_use_service(
         service_registry,
         &key,
         boost::asio::detail::service_registry::create<boost::asio::detail::epoll_reactor>);
  *((_QWORD *)this + 8) = v4;
  boost::asio::detail::task_io_service::init_task((boost::asio::detail::task_io_service_0 *)v4[1]._vptr$service);
  v5 = *((_QWORD *)this + 8);
  pthread_mutex_lock((pthread_mutex_t *)(v5 + 48));
  *((_QWORD *)this + 1) = *(_QWORD *)(v5 + 104);
  *(_QWORD *)(v5 + 104) = this;
  pthread_mutex_unlock((pthread_mutex_t *)(v5 + 48));
}


// Address: 0x2606150 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE16expires_from_nowERNS7_19implementation_typeERKNS4_13time_durationERNS_6system10error_codeE
size_t __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::expires_from_now(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        const boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::duration_type *expiry_time,
        boost::system::error_code *ec)
{
  boost::posix_time::ptime v8; // rax
  boost::date_time::int_adapter<long>::int_type value; // rcx
  unsigned __int64 v10; // rsi
  boost::date_time::int_adapter<long>::int_type v11; // rbp
  unsigned __int64 v12; // rsi
  unsigned __int64 v13; // rdi
  size_t v14; // rbx
  const boost::system::error_category *v15; // rax
  const boost::system::error_category *v16; // rax

  v8.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
  value = expiry_time->ticks_.value_;
  v10 = expiry_time->ticks_.value_ - 0x7FFFFFFFFFFFFFFELL;
  if ( (unsigned __int64)(v8.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) >= 3 && v10 > 2 )
    goto LABEL_3;
  if ( v8.time_.time_count_.value_ != 0x8000000000000000LL )
  {
    if ( v8.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFELL )
    {
      v11 = 0x7FFFFFFFFFFFFFFELL;
      if ( !impl->might_have_pending_waits )
        goto LABEL_30;
      goto LABEL_29;
    }
    if ( v8.time_.time_count_.value_ != 0x7FFFFFFFFFFFFFFFLL && v10 > 2 )
      goto LABEL_3;
  }
  if ( value == 0x7FFFFFFFFFFFFFFELL )
  {
    v11 = 0x7FFFFFFFFFFFFFFELL;
    if ( !impl->might_have_pending_waits )
      goto LABEL_30;
    goto LABEL_29;
  }
  v12 = v8.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFFLL;
  if ( v8.time_.time_count_.value_ == 0x8000000000000000LL )
  {
    v13 = 0x7FFFFFFFFFFFFFFFLL;
    v11 = 0x8000000000000000LL;
LABEL_19:
    if ( value == v13 )
    {
      v11 = 0x7FFFFFFFFFFFFFFELL;
      goto LABEL_28;
    }
    if ( v12 < 2 )
      goto LABEL_28;
    goto LABEL_22;
  }
  if ( v8.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
  {
    v13 = 0x8000000000000000LL;
    v11 = 0x7FFFFFFFFFFFFFFFLL;
    goto LABEL_19;
  }
  v11 = v8.time_.time_count_.value_;
  if ( v12 < 2 )
    goto LABEL_28;
LABEL_22:
  if ( value != 0x8000000000000000LL )
  {
    if ( value == 0x7FFFFFFFFFFFFFFFLL )
    {
LABEL_4:
      v11 = value;
      if ( !impl->might_have_pending_waits )
        goto LABEL_30;
      goto LABEL_29;
    }
LABEL_3:
    value += v8.time_.time_count_.value_;
    goto LABEL_4;
  }
  v11 = 0x8000000000000000LL;
LABEL_28:
  if ( !impl->might_have_pending_waits )
  {
LABEL_30:
    v14 = 0;
    goto LABEL_31;
  }
LABEL_29:
  v14 = boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
          *((boost::asio::detail::epoll_reactor **)this + 8),
          this,
          &impl->timer_data,
          0xFFFFFFFFFFFFFFFFLL);
  impl->might_have_pending_waits = 0;
LABEL_31:
  v15 = boost::system::system_category();
  ec->m_val = 0;
  ec->m_cat = v15;
  impl->expiry.time_.time_count_.value_ = v11;
  v16 = boost::system::system_category();
  ec->m_val = 0;
  ec->m_cat = v16;
  return v14;
}


// Address: 0x2606580 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINSE_6config15asio_tls_client16transport_configEEEFvNSC_10shared_ptrINS0_20basic_deadline_timerIS5_S6_NS0_22deadline_timer_serviceIS5_S6_EEEEEENSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEEJNSM_ISL_EERSR_RSX_RKNSC_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  unsigned __int64 v4; // rax
  char **v5; // rax
  char *v6; // rbx
  char v7; // al
  __int64 v8; // rdx
  __int64 v9; // r8
  __int64 v10; // r9
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rax
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::ptr v12; // [rsp+0h] [rbp-38h] BYREF

  v12.h = handler;
  v4 = __readfsqword(0xFFFFFFD8);
  if ( v4 )
  {
    v5 = *(char ***)(v4 + 8);
    if ( v5 )
    {
      v6 = *v5;
      if ( *v5 )
      {
        *v5 = 0;
        v7 = *v6;
        if ( (unsigned __int8)*v6 > 0x9Fu )
          goto LABEL_7;
        operator delete(v6);
      }
    }
  }
  v6 = (char *)operator new(0xA1u);
  v7 = -96;
LABEL_7:
  v6[160] = v7;
  v12.v = v6;
  v12.p = 0;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_OWORD *)v6 + 3) = handler->dispatcher_;
  *((_OWORD *)v6 + 4) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v6 + 5) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  *((_OWORD *)v6 + 6) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v6 + 18) = v6 + 112;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, __int64, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, void *, boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v6 + 112,
        v8,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        v9,
        v10,
        v12.h,
        v12.v,
        v12.p);
    }
    else
    {
      *((_QWORD *)v6 + 18) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v6 + 18) = 0;
  }
  v12.p = (boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)v6;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
  *(_OWORD *)&v12.v = 0;
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::ptr::reset(&v12);
}


// Address: 0x260a970 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *handler)
{
  unsigned __int64 v4; // rax
  char **v5; // rax
  char *v6; // rbx
  char v7; // al
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *f; // rax

  v4 = __readfsqword(0xFFFFFFD8);
  if ( v4 )
  {
    v5 = *(char ***)(v4 + 8);
    if ( v5 )
    {
      v6 = *v5;
      if ( *v5 )
      {
        *v5 = 0;
        v7 = *v6;
        if ( (unsigned __int8)*v6 > 0x9Fu )
          goto LABEL_7;
        operator delete(v6);
      }
    }
  }
  v6 = (char *)operator new(0xA1u);
  v7 = -96;
LABEL_7:
  v6[160] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 6) = handler->next_layer_;
  *((_QWORD *)v6 + 7) = handler->core_;
  *((_DWORD *)v6 + 17) = handler->start_;
  *((_DWORD *)v6 + 18) = handler->want_;
  *((_OWORD *)v6 + 5) = handler->ec_;
  *((_QWORD *)v6 + 12) = handler->bytes_transferred_;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &)> *)f )
    {
      *((_QWORD *)v6 + 18) = v6 + 112;
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *, char *))handler->handler_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__f_,
        v6 + 112);
    }
    else
    {
      *((_QWORD *)v6 + 18) = f;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v6 + 18) = 0;
  }
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


// Address: 0x2613220 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_8write_opINS1_17consuming_buffersINS0_12const_bufferENSt3__16vectorISK_NSL_9allocatorISK_EEEEEEEENS1_8write_opINS9_6streamISH_EESP_NS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSL_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  boost::asio::detail::wait_op *v4; // rbx

  v4 = (boost::asio::detail::wait_op *)*((_QWORD *)handler + 26);
  if ( LOBYTE(v4[25].ec_.m_val) )
    v4 = (boost::asio::detail::wait_op *)operator new(0x140u);
  else
    LOBYTE(v4[25].ec_.m_val) = 1;
  v4->next_ = 0;
  v4->func_ = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::do_complete;
  v4->task_result_ = 0;
  v4->ec_.m_val = 0;
  v4->ec_.m_cat = boost::system::system_category();
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)&v4[1].func_,
    handler);
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    v4);
}


// Address: 0x2616ce0 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_7read_opINS0_17mutable_buffers_1EEENS1_7read_opINS9_6streamISH_EESJ_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  char *buf; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *f; // rax

  buf = handler->handler_.handler_.allocator_->storage_.data_.buf;
  if ( buf[1024] )
    buf = (char *)operator new(0xE0u);
  else
    buf[1024] = 1;
  *(_QWORD *)buf = 0;
  *((_QWORD *)buf + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::do_complete;
  *((_DWORD *)buf + 4) = 0;
  *((_DWORD *)buf + 6) = 0;
  *((_QWORD *)buf + 4) = boost::system::system_category();
  *((_QWORD *)buf + 6) = handler->next_layer_;
  *((_QWORD *)buf + 7) = handler->core_;
  *((_OWORD *)buf + 4) = handler->op_;
  *((_DWORD *)buf + 20) = handler->start_;
  *((_DWORD *)buf + 21) = handler->want_;
  *(boost::system::error_code *)(buf + 88) = handler->ec_;
  *((_QWORD *)buf + 13) = handler->bytes_transferred_;
  *((_OWORD *)buf + 7) = *(_OWORD *)&handler->handler_.completion_condition_.minimum_;
  *((_OWORD *)buf + 8) = handler->handler_.buffer_;
  *((_DWORD *)buf + 36) = handler->handler_.start_;
  *(_OWORD *)(buf + 152) = *(_OWORD *)&handler->handler_.total_transferred_;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)handler->handler_.handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      *((_QWORD *)buf + 26) = buf + 176;
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, char *))handler->handler_.handler_.handler_.__f_->_vptr$__base
       + 3))(
        handler->handler_.handler_.handler_.__f_,
        buf + 176);
    }
    else
    {
      *((_QWORD *)buf + 26) = f;
      handler->handler_.handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)buf + 26) = 0;
  }
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)buf);
}


// Address: 0x2633ac0 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSM_8functionIFvRKNSM_10error_codeEEEERKNS_6system10error_codeEEJNSM_10shared_ptrISS_EERSY_RKNSM_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  unsigned __int64 v4; // rax
  char **v5; // rax
  char *v6; // rbx
  char v7; // al
  __int64 v8; // rdx
  __int64 v9; // r8
  __int64 v10; // r9
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *f; // rax
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >::ptr v12; // [rsp+0h] [rbp-38h] BYREF

  v12.h = handler;
  v4 = __readfsqword(0xFFFFFFD8);
  if ( v4 )
  {
    v5 = *(char ***)(v4 + 8);
    if ( v5 )
    {
      v6 = *v5;
      if ( *v5 )
      {
        *v5 = 0;
        v7 = *v6;
        if ( (unsigned __int8)*v6 > 0xCFu )
          goto LABEL_7;
        operator delete(v6);
      }
    }
  }
  v6 = (char *)operator new(0xD1u);
  v7 = -48;
LABEL_7:
  v6[208] = v7;
  v12.v = v6;
  v12.p = 0;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 6) = handler->next_layer_;
  *((_QWORD *)v6 + 7) = handler->core_;
  *((_DWORD *)v6 + 16) = handler->op_.type_;
  *((_DWORD *)v6 + 17) = handler->start_;
  *((_DWORD *)v6 + 18) = handler->want_;
  *((_OWORD *)v6 + 5) = handler->ec_;
  *((_QWORD *)v6 + 12) = handler->bytes_transferred_;
  *((_OWORD *)v6 + 7) = handler->handler_.dispatcher_;
  *((_OWORD *)v6 + 8) = *(_OWORD *)&handler->handler_.handler_.__f_;
  *((_OWORD *)v6 + 9) = handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)handler->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v6 + 24) = v6 + 160;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, __int64, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, void *, boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *))handler->handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.handler_.__bound_args_.__base_.__value_.__f_,
        v6 + 160,
        v8,
        &handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        v9,
        v10,
        v12.h,
        v12.v,
        v12.p);
    }
    else
    {
      *((_QWORD *)v6 + 24) = f;
      handler->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v6 + 24) = 0;
  }
  v12.p = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *)v6;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
  *(_OWORD *)&v12.v = 0;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::ptr::reset(&v12);
}


// Address: 0x2637b90 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSJ_8functionIFvRKNSJ_10error_codeEEEERKNS_6system10error_codeEEJNSJ_10shared_ptrISP_EERSV_RKNSJ_12placeholders4__phILi1EEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  unsigned __int64 v4; // rax
  char **v5; // rax
  char *v6; // rbx
  char v7; // al
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::ptr v8; // [rsp+0h] [rbp-38h] BYREF

  v8.h = handler;
  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(char ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( (unsigned __int8)*v6 <= 0xBFu )
  {
    operator delete(v6);
LABEL_6:
    v6 = (char *)operator new(0xC1u);
    v7 = -64;
  }
  v6[192] = v7;
  v8.v = v6;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::wait_handler(
    (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)v6,
    handler);
  v8.p = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *)v6;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
  *(_OWORD *)&v8.v = 0;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::ptr::reset(&v8);
}


// Address: 0x2656a80 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINSE_6config11asio_client16transport_configEEEFvNSC_10shared_ptrINS0_20basic_deadline_timerIS5_S6_NS0_22deadline_timer_serviceIS5_S6_EEEEEENSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEEJNSM_ISL_EERSR_RSX_RKNSC_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  unsigned __int64 v4; // rax
  char **v5; // rax
  char *v6; // rbx
  char v7; // al
  __int64 v8; // rdx
  __int64 v9; // r8
  __int64 v10; // r9
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rax
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::ptr v12; // [rsp+0h] [rbp-38h] BYREF

  v12.h = handler;
  v4 = __readfsqword(0xFFFFFFD8);
  if ( v4 )
  {
    v5 = *(char ***)(v4 + 8);
    if ( v5 )
    {
      v6 = *v5;
      if ( *v5 )
      {
        *v5 = 0;
        v7 = *v6;
        if ( (unsigned __int8)*v6 > 0x9Fu )
          goto LABEL_7;
        operator delete(v6);
      }
    }
  }
  v6 = (char *)operator new(0xA1u);
  v7 = -96;
LABEL_7:
  v6[160] = v7;
  v12.v = v6;
  v12.p = 0;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_OWORD *)v6 + 3) = handler->dispatcher_;
  *((_OWORD *)v6 + 4) = *(_OWORD *)&handler->handler_.__f_;
  *((_OWORD *)v6 + 5) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  *((_OWORD *)v6 + 6) = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      *((_QWORD *)v6 + 18) = v6 + 112;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, char *, __int64, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, __int64, __int64, boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, void *, boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *))handler->handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        handler->handler_.__bound_args_.__base_.__value_.__f_,
        v6 + 112,
        v8,
        &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        v9,
        v10,
        v12.h,
        v12.v,
        v12.p);
    }
    else
    {
      *((_QWORD *)v6 + 18) = f;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    *((_QWORD *)v6 + 18) = 0;
  }
  v12.p = (boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)v6;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
  *(_OWORD *)&v12.v = 0;
  boost::asio::detail::wait_handler<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::ptr::reset(&v12);
}


// Address: 0x2697020 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE19implementation_typeD2Ev
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::implementation_type::~implementation_type(
        boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::implementation_type *this)
{
  boost::asio::detail::wait_op *i; // rbx
  boost::asio::detail::wait_op *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v4; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v5; // [rsp+10h] [rbp-28h]

  for ( i = this->timer_data.op_queue_.front_; i; i = this->timer_data.op_queue_.front_ )
  {
    next = (boost::asio::detail::wait_op *)i->next_;
    this->timer_data.op_queue_.front_ = (boost::asio::detail::wait_op *)i->next_;
    if ( !next )
      this->timer_data.op_queue_.back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v4 = 0;
    v5 = boost::system::system_category();
    func(0, i, &v4, 0);
  }
}


// Address: 0x2697100 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEEC2ERNS0_10io_serviceE
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::deadline_timer_service(
        boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        boost::asio::io_service *io_service)
{
  boost::asio::detail::service_registry *service_registry; // rdi
  boost::asio::io_service::service *v4; // rax
  __int64 v5; // rbx
  boost::asio::io_service::service::key_0 key; // [rsp+8h] [rbp-30h] BYREF

  *((_QWORD *)this + 1) = 0;
  *(_QWORD *)this = &off_29C7118;
  *((_OWORD *)this + 2) = 0;
  *((_OWORD *)this + 1) = 0;
  service_registry = io_service->service_registry_;
  key.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::detail::epoll_reactor>;
  key.id_ = 0;
  v4 = boost::asio::detail::service_registry::do_use_service(
         service_registry,
         &key,
         boost::asio::detail::service_registry::create<boost::asio::detail::epoll_reactor>);
  *((_QWORD *)this + 6) = v4;
  boost::asio::detail::task_io_service::init_task((boost::asio::detail::task_io_service_0 *)v4[1]._vptr$service);
  v5 = *((_QWORD *)this + 6);
  pthread_mutex_lock((pthread_mutex_t *)(v5 + 48));
  *((_QWORD *)this + 1) = *(_QWORD *)(v5 + 104);
  *(_QWORD *)(v5 + 104) = this;
  pthread_mutex_unlock((pthread_mutex_t *)(v5 + 48));
}


// Address: 0x26980e0 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details20asio_connection_poolERKNS_6system10error_codeERKNSt3__18weak_ptrINSG_15asio_connectionEEEEENS9_5list3INS9_5valueIPSH_EEPFNS_3argILi1EEEvENSU_INSM_10shared_ptrISO_EEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_connection_pool,boost::system::error_code const&,std::weak_ptr<web::http::client::details::asio_connection> const&>,boost::_bi::list3<boost::_bi::value<web::http::client::details::asio_connection_pool*>,boost::arg<1> (*)(void),boost::_bi::value<std::shared_ptr<web::http::client::details::asio_connection>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_connection_pool,const boost::system::error_code &,const std::weak_ptr<web::http::client::details::asio_connection> &>,boost::_bi::list3<boost::_bi::value<web::http::client::details::asio_connection_pool *>,boost::arg<1> (*)(),boost::_bi::value<std::shared_ptr<web::http::client::details::asio_connection> > > > *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0x4Fu )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0x51u);
    v7 = 80;
  }
  v6[80] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_connection_pool,boost::system::error_code const&,std::weak_ptr<web::http::client::details::asio_connection> const&>,boost::_bi::list3<boost::_bi::value<web::http::client::details::asio_connection_pool*>,boost::arg<1> (*)(void),boost::_bi::value<std::shared_ptr<web::http::client::details::asio_connection>>>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *(boost::_mfi::mf2<void,web::http::client::details::asio_connection_pool,const boost::system::error_code &,const std::weak_ptr<web::http::client::details::asio_connection> &> *)(v6 + 40) = handler->f_;
  *((_QWORD *)v6 + 7) = handler->l_.a1_.t_;
  *((_OWORD *)v6 + 4) = handler->l_.a3_;
  handler->l_.a3_ = 0;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


// Address: 0x269f240 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE10async_waitIZN3web4http6client7details12asio_context13timeout_timer5startEvEUlRKNS_6system10error_codeEE_EEvRNSA_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::async_wait<web::http::client::details::asio_context::timeout_timer::start(void)::{lambda(boost::system::error_code const&)#1}>(
        boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::implementation_type *impl,
        struct __cppobj {std::weak_ptr<web::http::client::details::asio_context> ctx;} *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0x37u )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0x39u);
    v7 = 56;
  }
  v6[56] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<web::http::client::details::asio_context::timeout_timer::start(void)::{lambda(boost::system::error_code const&)#1}>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *(struct __cppobj {std::weak_ptr<web::http::client::details::asio_context> ctx;} *)(v6 + 40) = *handler;
  *handler = 0;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>(
    *((boost::asio::detail::epoll_reactor **)this + 6),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


// Address: 0x26a0d40 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE10async_waitIZN3web4http6client7details12asio_context13timeout_timer5resetEvEUlRKNS_6system10error_codeEE_EEvRNSA_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::async_wait<web::http::client::details::asio_context::timeout_timer::reset(void)::{lambda(boost::system::error_code const&)#1}>(
        boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::implementation_type *impl,
        struct __cppobj {std::weak_ptr<web::http::client::details::asio_context> ctx;} *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0x37u )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0x39u);
    v7 = 56;
  }
  v6[56] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<web::http::client::details::asio_context::timeout_timer::reset(void)::{lambda(boost::system::error_code const&)#1}>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *(struct __cppobj {std::weak_ptr<web::http::client::details::asio_context> ctx;} *)(v6 + 40) = *handler;
  *handler = 0;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>(
    *((boost::asio::detail::epoll_reactor **)this + 6),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


// Address: 0x26a3080 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_8write_opINS0_15const_buffers_1EEENS1_8write_opINS9_6streamIRSH_EESJ_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSU_5list2INSU_5valueINSR_10shared_ptrIS13_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0xB7u )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0xB9u);
    v7 = -72;
  }
  v6[184] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 5) = handler->next_layer_;
  *((_QWORD *)v6 + 6) = handler->core_;
  *(boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)(v6 + 56) = handler->op_;
  *((_DWORD *)v6 + 18) = handler->start_;
  *((_DWORD *)v6 + 19) = handler->want_;
  *((_OWORD *)v6 + 5) = handler->ec_;
  *((_OWORD *)v6 + 6) = *(_OWORD *)&handler->bytes_transferred_;
  *((_OWORD *)v6 + 7) = handler->handler_.buffer_;
  *((_DWORD *)v6 + 32) = handler->handler_.start_;
  *(_OWORD *)(v6 + 136) = *(_OWORD *)&handler->handler_.total_transferred_;
  *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> *)(v6 + 152) = handler->handler_.handler_.handler_.f_;
  *((_QWORD *)v6 + 21) = handler->handler_.handler_.handler_.l_.a1_.t_.__ptr_;
  *((_QWORD *)v6 + 22) = handler->handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  handler->handler_.handler_.handler_.l_ = 0;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


// Address: 0x26a5ef0 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_7read_opINS0_17mutable_buffers_1EEENS1_26read_until_delim_string_opINS9_6streamIRSH_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSS_5list2INSS_5valueINSP_10shared_ptrIS11_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::ptr v8; // [rsp+0h] [rbp-38h] BYREF

  v8.h = handler;
  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0xBFu )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0xC1u);
    v7 = -64;
  }
  v6[192] = v7;
  v8.v = v6;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 5) = *(_QWORD *)handler;
  *((_QWORD *)v6 + 6) = *((_QWORD *)handler + 1);
  *(_OWORD *)(v6 + 56) = *((_OWORD *)handler + 1);
  *((_DWORD *)v6 + 18) = *((_DWORD *)handler + 8);
  *((_DWORD *)v6 + 19) = *((_DWORD *)handler + 9);
  *((_OWORD *)v6 + 5) = *(_OWORD *)((char *)handler + 40);
  *((_OWORD *)v6 + 6) = *(_OWORD *)((char *)handler + 56);
  *((_QWORD *)v6 + 14) = *((_QWORD *)handler + 9);
  *((_QWORD *)v6 + 17) = *((_QWORD *)handler + 12);
  *(_OWORD *)(v6 + 120) = *((_OWORD *)handler + 5);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  *((_DWORD *)v6 + 36) = *((_DWORD *)handler + 26);
  *((_QWORD *)v6 + 19) = *((_QWORD *)handler + 14);
  *((_OWORD *)v6 + 10) = *(_OWORD *)((char *)handler + 120);
  *((_QWORD *)v6 + 22) = *((_QWORD *)handler + 17);
  *((_QWORD *)v6 + 23) = *((_QWORD *)handler + 18);
  *(_OWORD *)((char *)handler + 136) = 0;
  v8.p = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *)v6;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
  *(_OWORD *)&v8.v = 0;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v8);
}


// Address: 0x26a9240 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSJ_5list2INSJ_5valueINSt3__110shared_ptrISR_EEEEPFNS_3argILi1EEEvEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( (char)*v6 >= 0 )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0x81u);
    v7 = 0x80;
  }
  v6[128] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 5) = handler->next_layer_;
  *((_QWORD *)v6 + 6) = handler->core_;
  *((_DWORD *)v6 + 14) = handler->op_.type_;
  *((_DWORD *)v6 + 15) = handler->start_;
  *((_DWORD *)v6 + 16) = handler->want_;
  *(boost::system::error_code *)(v6 + 72) = handler->ec_;
  *((_QWORD *)v6 + 11) = handler->bytes_transferred_;
  *((_OWORD *)v6 + 6) = handler->handler_.f_;
  *((_OWORD *)v6 + 7) = handler->handler_.l_;
  handler->handler_.l_ = 0;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


// Address: 0x26aaad0 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_8write_opINS0_15const_buffers_1EEENS1_8write_opINS9_6streamIRSH_EESJ_NS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSU_5list2INSU_5valueINSR_10shared_ptrIS12_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0xB7u )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0xB9u);
    v7 = -72;
  }
  v6[184] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 5) = handler->next_layer_;
  *((_QWORD *)v6 + 6) = handler->core_;
  *(boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> *)(v6 + 56) = handler->op_;
  *((_DWORD *)v6 + 18) = handler->start_;
  *((_DWORD *)v6 + 19) = handler->want_;
  *((_OWORD *)v6 + 5) = handler->ec_;
  *((_OWORD *)v6 + 6) = *(_OWORD *)&handler->bytes_transferred_;
  *((_OWORD *)v6 + 7) = handler->handler_.buffer_;
  *((_DWORD *)v6 + 32) = handler->handler_.start_;
  *(_OWORD *)(v6 + 136) = *(_OWORD *)&handler->handler_.total_transferred_;
  *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> *)(v6 + 152) = handler->handler_.handler_.handler_.f_;
  *((_QWORD *)v6 + 21) = handler->handler_.handler_.handler_.l_.a1_.t_.__ptr_;
  *((_QWORD *)v6 + 22) = handler->handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  handler->handler_.handler_.handler_.l_ = 0;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


// Address: 0x26ae370 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_7read_opINS0_17mutable_buffers_1EEENS1_26read_until_delim_string_opINS9_6streamIRSH_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSS_5list2INSS_5valueINSP_10shared_ptrIS10_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::ptr v8; // [rsp+0h] [rbp-38h] BYREF

  v8.h = handler;
  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0xBFu )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0xC1u);
    v7 = -64;
  }
  v6[192] = v7;
  v8.v = v6;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 5) = *(_QWORD *)handler;
  *((_QWORD *)v6 + 6) = *((_QWORD *)handler + 1);
  *(_OWORD *)(v6 + 56) = *((_OWORD *)handler + 1);
  *((_DWORD *)v6 + 18) = *((_DWORD *)handler + 8);
  *((_DWORD *)v6 + 19) = *((_DWORD *)handler + 9);
  *((_OWORD *)v6 + 5) = *(_OWORD *)((char *)handler + 40);
  *((_OWORD *)v6 + 6) = *(_OWORD *)((char *)handler + 56);
  *((_QWORD *)v6 + 14) = *((_QWORD *)handler + 9);
  *((_QWORD *)v6 + 17) = *((_QWORD *)handler + 12);
  *(_OWORD *)(v6 + 120) = *((_OWORD *)handler + 5);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  *((_DWORD *)v6 + 36) = *((_DWORD *)handler + 26);
  *((_QWORD *)v6 + 19) = *((_QWORD *)handler + 14);
  *((_OWORD *)v6 + 10) = *(_OWORD *)((char *)handler + 120);
  *((_QWORD *)v6 + 22) = *((_QWORD *)handler + 17);
  *((_QWORD *)v6 + 23) = *((_QWORD *)handler + 18);
  *(_OWORD *)((char *)handler + 136) = 0;
  v8.p = (boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *)v6;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
  *(_OWORD *)&v8.v = 0;
  boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::ptr::reset(&v8);
}


// Address: 0x26b2b40 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_7read_opINS0_17mutable_buffers_1EEENS1_17read_streambuf_opINS9_6streamIRSH_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENST_5list2INST_5valueINSP_10shared_ptrIS11_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0xAFu )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0xB1u);
    v7 = -80;
  }
  v6[176] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 5) = handler->next_layer_;
  *((_QWORD *)v6 + 6) = handler->core_;
  *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)(v6 + 56) = handler->op_;
  *((_DWORD *)v6 + 18) = handler->start_;
  *((_DWORD *)v6 + 19) = handler->want_;
  *((_OWORD *)v6 + 5) = handler->ec_;
  *((_QWORD *)v6 + 12) = handler->bytes_transferred_;
  *(_OWORD *)(v6 + 104) = *(_OWORD *)&handler->handler_.completion_condition_.size_;
  *((_QWORD *)v6 + 15) = handler->handler_.streambuf_;
  *((_DWORD *)v6 + 32) = handler->handler_.start_;
  *((_QWORD *)v6 + 17) = handler->handler_.total_transferred_;
  *((_OWORD *)v6 + 9) = handler->handler_.handler_.f_;
  *((_OWORD *)v6 + 10) = handler->handler_.handler_.l_;
  handler->handler_.handler_.l_ = 0;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


// Address: 0x26b65e0 | Name: _ZN5boost4asio6detail22deadline_timer_serviceINS0_11time_traitsINS_10posix_time5ptimeEEEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISE_EEEENSA_7read_opINS0_17mutable_buffers_1EEENS1_17read_streambuf_opINS9_6streamIRSH_EENSt3__19allocatorIcEENS1_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENST_5list3INST_5valueINSP_10shared_ptrIS11_EEEEPFNS_3argILi1EEEvENS18_IiEEEEEEEEEEEEvRNS7_19implementation_typeERT_
void __fastcall boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > *handler)
{
  unsigned __int64 v4; // rax
  _BYTE **v5; // rax
  _BYTE *v6; // rbx
  char v7; // al

  v4 = __readfsqword(0xFFFFFFD8);
  if ( !v4 )
    goto LABEL_6;
  v5 = *(_BYTE ***)(v4 + 8);
  if ( !v5 )
    goto LABEL_6;
  v6 = *v5;
  if ( !*v5 )
    goto LABEL_6;
  *v5 = 0;
  v7 = *v6;
  if ( *v6 <= 0xB7u )
  {
    operator delete(v6);
LABEL_6:
    v6 = operator new(0xB9u);
    v7 = -72;
  }
  v6[184] = v7;
  *(_QWORD *)v6 = 0;
  *((_QWORD *)v6 + 1) = boost::asio::detail::wait_handler<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>::do_complete;
  *((_DWORD *)v6 + 4) = 0;
  *((_DWORD *)v6 + 6) = 0;
  *((_QWORD *)v6 + 4) = boost::system::system_category();
  *((_QWORD *)v6 + 5) = handler->next_layer_;
  *((_QWORD *)v6 + 6) = handler->core_;
  *(boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> *)(v6 + 56) = handler->op_;
  *((_DWORD *)v6 + 18) = handler->start_;
  *((_DWORD *)v6 + 19) = handler->want_;
  *((_OWORD *)v6 + 5) = handler->ec_;
  *((_QWORD *)v6 + 12) = handler->bytes_transferred_;
  *(_OWORD *)(v6 + 104) = *(_OWORD *)&handler->handler_.completion_condition_.size_;
  *((_QWORD *)v6 + 15) = handler->handler_.streambuf_;
  *((_DWORD *)v6 + 32) = handler->handler_.start_;
  *((_QWORD *)v6 + 17) = handler->handler_.total_transferred_;
  *((_OWORD *)v6 + 9) = handler->handler_.handler_.f_;
  *((_OWORD *)v6 + 10) = handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  *((_DWORD *)v6 + 44) = handler->handler_.handler_.l_.a3_.t_;
  impl->might_have_pending_waits = 1;
  boost::asio::detail::epoll_reactor::schedule_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
    *((boost::asio::detail::epoll_reactor **)this + 8),
    this,
    &impl->expiry,
    &impl->timer_data,
    (boost::asio::detail::wait_op *)v6);
}


