// Address: 0xfec2d0 | Name: _ZN5boost9algorithm6detail18find_iterator_baseINSt3__111__wrap_iterIPKcEEEC2INS1_13token_finderFINS1_10is_any_ofFIcEEEEEET_i
void __fastcall boost::algorithm::detail::find_iterator_base<std::__wrap_iter<char const*>>::find_iterator_base<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        boost::algorithm::detail::find_iterator_base<std::__wrap_iter<const char *> >_0 *this,
        _QWORD *a2)
{
  _QWORD *v2; // r15
  size_t v4; // rbx
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *p_src; // rdi
  boost::algorithm::token_compress_mode_type v6; // ebp
  size_t m_Size; // rbx
  void *p_ptr; // rdi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > src; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+20h] [rbp-48h] BYREF
  size_t v12; // [rsp+30h] [rbp-38h]
  boost::algorithm::token_compress_mode_type v13; // [rsp+38h] [rbp-30h]
  unsigned __int64 v14; // [rsp+40h] [rbp-28h]

  v2 = a2;
  v14 = __readfsqword(0x28u);
  v4 = a2[2];
  src.m_Pred.m_Size = v4;
  src.m_Pred.m_Storage.m_dynSet = 0;
  if ( v4 > 0x10 )
  {
    p_src = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)operator new[](v4);
    src.m_Pred.m_Storage.m_dynSet = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)p_src;
    a2 = (_QWORD *)*a2;
  }
  else
  {
    p_src = &src;
  }
  memcpy(p_src, a2, v4);
  v6 = *((_DWORD *)v2 + 6);
  src.m_eCompress = v6;
  this->m_Finder.vtable = 0;
  m_Size = src.m_Pred.m_Size;
  v12 = src.m_Pred.m_Size;
  ptr = 0;
  if ( src.m_Pred.m_Size > 0x10 )
  {
    p_ptr = operator new[](src.m_Pred.m_Size);
    ptr = p_ptr;
    m_dynSet = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)src.m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    p_ptr = &ptr;
    m_dynSet = &src;
  }
  memcpy(p_ptr, m_dynSet, m_Size);
  v13 = v6;
  boost::function2<boost::iterator_range<std::__wrap_iter<char const*>>,std::__wrap_iter<char const*>,std::__wrap_iter<char const*>>::assign_to<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    &this->m_Finder,
    src);
  if ( v12 >= 0x11 && ptr )
    operator delete[](ptr);
  if ( m_Size >= 0x11 )
  {
    if ( src.m_Pred.m_Storage.m_dynSet )
      operator delete[](src.m_Pred.m_Storage.m_dynSet);
  }
}


// Address: 0x10195a0 | Name: _ZN5boost9algorithm6detail18find_iterator_baseINSt3__111__wrap_iterIPcEEEC2INS1_13token_finderFINS1_10is_any_ofFIcEEEEEET_i
void __fastcall boost::algorithm::detail::find_iterator_base<std::__wrap_iter<char *>>::find_iterator_base<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        boost::algorithm::detail::find_iterator_base<std::__wrap_iter<char *> > *this,
        _QWORD *a2)
{
  _QWORD *v2; // r15
  size_t v4; // rbx
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *p_src; // rdi
  boost::algorithm::token_compress_mode_type v6; // ebp
  size_t m_Size; // rbx
  void *p_ptr; // rdi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > src; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+20h] [rbp-48h] BYREF
  size_t v12; // [rsp+30h] [rbp-38h]
  boost::algorithm::token_compress_mode_type v13; // [rsp+38h] [rbp-30h]
  unsigned __int64 v14; // [rsp+40h] [rbp-28h]

  v2 = a2;
  v14 = __readfsqword(0x28u);
  v4 = a2[2];
  src.m_Pred.m_Size = v4;
  src.m_Pred.m_Storage.m_dynSet = 0;
  if ( v4 > 0x10 )
  {
    p_src = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)operator new[](v4);
    src.m_Pred.m_Storage.m_dynSet = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)p_src;
    a2 = (_QWORD *)*a2;
  }
  else
  {
    p_src = &src;
  }
  memcpy(p_src, a2, v4);
  v6 = *((_DWORD *)v2 + 6);
  src.m_eCompress = v6;
  this->m_Finder.vtable = 0;
  m_Size = src.m_Pred.m_Size;
  v12 = src.m_Pred.m_Size;
  ptr = 0;
  if ( src.m_Pred.m_Size > 0x10 )
  {
    p_ptr = operator new[](src.m_Pred.m_Size);
    ptr = p_ptr;
    m_dynSet = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)src.m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    p_ptr = &ptr;
    m_dynSet = &src;
  }
  memcpy(p_ptr, m_dynSet, m_Size);
  v13 = v6;
  boost::function2<boost::iterator_range<std::__wrap_iter<char *>>,std::__wrap_iter<char *>,std::__wrap_iter<char *>>::assign_to<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    &this->m_Finder,
    src);
  if ( v12 >= 0x11 && ptr )
    operator delete[](ptr);
  if ( m_Size >= 0x11 )
  {
    if ( src.m_Pred.m_Storage.m_dynSet )
      operator delete[](src.m_Pred.m_Storage.m_dynSet);
  }
}


// Address: 0x11105a0 | Name: _ZN5boost9algorithm6detail18find_iterator_baseIPKcEC2INS1_13token_finderFINS1_10is_any_ofFIcEEEEEET_i
void __fastcall boost::algorithm::detail::find_iterator_base<char const*>::find_iterator_base<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
        boost::algorithm::detail::find_iterator_base<const char *> *this,
        _QWORD *a2)
{
  _QWORD *v2; // r15
  size_t v4; // rbx
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *p_src; // rdi
  boost::algorithm::token_compress_mode_type v6; // ebp
  size_t m_Size; // rbx
  void *p_ptr; // rdi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *m_dynSet; // rsi
  boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > src; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+20h] [rbp-48h] BYREF
  size_t v12; // [rsp+30h] [rbp-38h]
  boost::algorithm::token_compress_mode_type v13; // [rsp+38h] [rbp-30h]
  unsigned __int64 v14; // [rsp+40h] [rbp-28h]

  v2 = a2;
  v14 = __readfsqword(0x28u);
  v4 = a2[2];
  src.m_Pred.m_Size = v4;
  src.m_Pred.m_Storage.m_dynSet = 0;
  if ( v4 > 0x10 )
  {
    p_src = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)operator new[](v4);
    src.m_Pred.m_Storage.m_dynSet = (boost::algorithm::detail::is_any_ofF<char>::set_value_type *)p_src;
    a2 = (_QWORD *)*a2;
  }
  else
  {
    p_src = &src;
  }
  memcpy(p_src, a2, v4);
  v6 = *((_DWORD *)v2 + 6);
  src.m_eCompress = v6;
  this->m_Finder.vtable = 0;
  m_Size = src.m_Pred.m_Size;
  v12 = src.m_Pred.m_Size;
  ptr = 0;
  if ( src.m_Pred.m_Size > 0x10 )
  {
    p_ptr = operator new[](src.m_Pred.m_Size);
    ptr = p_ptr;
    m_dynSet = (boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char> > *)src.m_Pred.m_Storage.m_dynSet;
  }
  else
  {
    p_ptr = &ptr;
    m_dynSet = &src;
  }
  memcpy(p_ptr, m_dynSet, m_Size);
  v13 = v6;
  boost::function2<boost::iterator_range<char const*>,char const*,char const*>::assign_to<boost::algorithm::detail::token_finderF<boost::algorithm::detail::is_any_ofF<char>>>(
    &this->m_Finder,
    src);
  if ( v12 >= 0x11 && ptr )
    operator delete[](ptr);
  if ( m_Size >= 0x11 )
  {
    if ( src.m_Pred.m_Storage.m_dynSet )
      operator delete[](src.m_Pred.m_Storage.m_dynSet);
  }
}


