// Address: 0xed0760 | Name: _ZN5boost4poolIN3RBX16TrackedAllocatorEE18malloc_need_resizeEv
void *__fastcall boost::pool<RBX::TrackedAllocator>::malloc_need_resize(boost::pool<RBX::TrackedAllocator> *this)
{
  boost::pool<RBX::TrackedAllocator>::size_type requested_size; // rax
  __int64 v3; // rbx
  boost::pool<RBX::TrackedAllocator>::size_type v4; // rbx
  size_t v5; // r15
  char *v6; // rcx
  boost::pool<RBX::TrackedAllocator>::size_type v7; // rdi
  boost::pool<RBX::TrackedAllocator>::size_type max_size; // rsi
  boost::pool<RBX::TrackedAllocator>::size_type v9; // r8
  boost::pool<RBX::TrackedAllocator>::size_type v10; // rdi
  boost::pool<RBX::TrackedAllocator>::size_type v11; // r8
  boost::pool<RBX::TrackedAllocator>::size_type next_size; // r15
  boost::pool<RBX::TrackedAllocator>::size_type v13; // r15
  boost::pool<RBX::TrackedAllocator>::size_type v14; // rax
  __int64 v15; // rbx
  void *result; // rax
  unsigned __int64 v17; // rsi
  __int64 v18; // rbx
  char *v19; // rsi
  char *v20; // rax
  char *v21; // rdx

  requested_size = this->requested_size;
  if ( requested_size <= 8 )
    requested_size = 8;
  v3 = 8 - (requested_size & 7);
  if ( (requested_size & 7) == 0 )
    v3 = requested_size & 7;
  v4 = requested_size + v3;
  v5 = v4 * this->next_size + 16;
  v6 = (char *)RBX::Memory::allocate(v5);
  if ( !v6 )
  {
    next_size = this->next_size;
    if ( next_size < 5 )
      return 0;
    v13 = next_size >> 1;
    this->next_size = v13;
    v14 = this->requested_size;
    if ( v14 <= 8 )
      v14 = 8;
    v15 = 8 - (v14 & 7);
    if ( (v14 & 7) == 0 )
      v15 = v14 & 7;
    v4 = v14 + v15;
    v5 = v4 * v13 + 16;
    v6 = (char *)RBX::Memory::allocate(v5);
    if ( !v6 )
      return 0;
  }
  v7 = this->next_size;
  max_size = this->max_size;
  if ( !max_size )
  {
    v10 = 2 * v7;
LABEL_19:
    this->next_size = v10;
    goto LABEL_20;
  }
  v9 = this->requested_size;
  if ( v4 * v7 / v9 < max_size )
  {
    v10 = 2 * v7;
    v11 = max_size * v9;
    if ( v11 / v4 < v10 )
      v10 = v11 / v4;
    goto LABEL_19;
  }
LABEL_20:
  v17 = v5 + -16LL - v4 - (v5 + -16LL - v4) % v4;
  *(_QWORD *)&v6[v17] = this->first;
  if ( v17 )
  {
    v18 = -(__int64)v4;
    v19 = &v6[v17];
    v20 = &v19[v18];
    if ( &v19[v18] == v6 )
    {
      v21 = v19;
    }
    else
    {
      do
      {
        v21 = v20;
        *(_QWORD *)v20 = v19;
        v20 += v18;
        v19 = v21;
      }
      while ( v20 != v6 );
    }
    *(_QWORD *)v6 = v21;
  }
  this->first = v6;
  *(boost::details::PODptr<unsigned long> *)&v6[v5 - 16] = this->list;
  this->list.ptr = v6;
  this->list.sz = v5;
  result = this->first;
  this->first = *(void **)this->first;
  return result;
}


// Address: 0xf80230 | Name: _ZN5boost4poolINS_33default_user_allocator_new_deleteEE18malloc_need_resizeEv
void *__fastcall boost::pool<boost::default_user_allocator_new_delete>::malloc_need_resize(
        boost::pool<boost::default_user_allocator_new_delete> *this)
{
  boost::pool<boost::default_user_allocator_new_delete>::size_type requested_size; // r13
  boost::pool<boost::default_user_allocator_new_delete>::size_type v2; // rax
  __int64 v3; // rbx
  boost::pool<boost::default_user_allocator_new_delete>::size_type next_size; // r12
  boost::pool<boost::default_user_allocator_new_delete>::size_type v5; // rbx
  size_t v6; // r15
  char *v7; // rax
  char *v8; // rcx
  boost::pool<boost::default_user_allocator_new_delete>::size_type max_size; // rsi
  boost::pool<boost::default_user_allocator_new_delete>::size_type v10; // r12
  boost::pool<boost::default_user_allocator_new_delete>::size_type v11; // rsi
  unsigned __int64 v12; // rsi
  __int64 v13; // rbx
  char *v14; // rsi
  char **v15; // rax
  char *v16; // rdx

  requested_size = this->requested_size;
  v2 = 8;
  if ( requested_size > 8 )
    v2 = this->requested_size;
  v3 = 8 - (v2 & 7);
  if ( (v2 & 7) == 0 )
    v3 = v2 & 7;
  next_size = this->next_size;
  v5 = v2 + v3;
  v6 = next_size * v5 + 16;
  v7 = (char *)operator new[](v6, (const std::nothrow_t *)&std::nothrow);
  if ( v7 )
  {
    v8 = v7;
  }
  else
  {
    if ( next_size < 5 )
      return 0;
    next_size >>= 1;
    this->next_size = next_size;
    v6 = next_size * v5 + 16;
    v8 = (char *)operator new[](v6, (const std::nothrow_t *)&std::nothrow);
    if ( !v8 )
      return 0;
  }
  max_size = this->max_size;
  if ( !max_size )
  {
    v10 = 2 * next_size;
LABEL_16:
    this->next_size = v10;
    goto LABEL_17;
  }
  if ( v5 * next_size / requested_size < max_size )
  {
    v10 = 2 * next_size;
    v11 = requested_size * max_size;
    if ( v11 / v5 < v10 )
      v10 = v11 / v5;
    goto LABEL_16;
  }
LABEL_17:
  v12 = v6 + -16LL - v5 - (v6 + -16LL - v5) % v5;
  *(_QWORD *)&v8[v12] = this->first;
  if ( v12 )
  {
    v13 = -(__int64)v5;
    v14 = &v8[v12];
    v15 = (char **)&v14[v13];
    if ( &v14[v13] == v8 )
    {
      v16 = v14;
    }
    else
    {
      do
      {
        v16 = (char *)v15;
        *v15 = v14;
        v15 = (char **)((char *)v15 + v13);
        v14 = v16;
      }
      while ( v15 != (char **)v8 );
    }
    *(_QWORD *)v8 = v16;
  }
  *(boost::details::PODptr<unsigned long> *)&v8[v6 - 16] = this->list;
  this->list.ptr = v8;
  this->list.sz = v6;
  this->first = *(void **)v8;
  return v8;
}


// Address: 0xf80370 | Name: _ZN5boost4poolINS_33default_user_allocator_new_deleteEE14ordered_mallocEm
void *__fastcall boost::pool<boost::default_user_allocator_new_delete>::ordered_malloc(
        boost::pool<boost::default_user_allocator_new_delete> *this,
        boost::pool<boost::default_user_allocator_new_delete>::size_type n)
{
  boost::pool<boost::default_user_allocator_new_delete>::size_type requested_size; // r10
  boost::pool<boost::default_user_allocator_new_delete>::size_type v3; // rax
  __int64 v4; // rbx
  boost::pool<boost::default_user_allocator_new_delete>::size_type v5; // rbx
  char *v6; // r8
  boost::pool<boost::default_user_allocator_new_delete>::size_type v7; // r14
  boost::pool<boost::default_user_allocator_new_delete> *v8; // r9
  boost::pool<boost::default_user_allocator_new_delete> *first; // rcx
  boost::pool<boost::default_user_allocator_new_delete>::size_type v10; // rdx
  boost::pool<boost::default_user_allocator_new_delete> *v11; // rax
  boost::pool<boost::default_user_allocator_new_delete>::size_type next_size; // r13
  boost::pool<boost::default_user_allocator_new_delete>::size_type v13; // r15
  size_t v15; // r12
  char *v16; // rax
  boost::pool<boost::default_user_allocator_new_delete>::size_type v18; // r14
  char *v19; // rdi
  size_t v20; // rsi
  boost::pool<boost::default_user_allocator_new_delete> *v21; // rbp
  boost::pool<boost::default_user_allocator_new_delete> *v22; // rcx
  size_t v23; // rsi
  char *v24; // rsi
  char *v25; // rbp
  char *v26; // rax
  size_t v27; // rsi
  char *v28; // rsi
  char *v29; // rax
  char *v30; // rdx
  boost::pool<boost::default_user_allocator_new_delete>::size_type max_size; // rsi
  boost::pool<boost::default_user_allocator_new_delete>::size_type v32; // r15
  boost::pool<boost::default_user_allocator_new_delete>::size_type v33; // rsi
  char *ptr; // rcx
  boost::details::PODptr<unsigned long>::size_type sz; // rdx
  size_t *v36; // rax
  char **v37; // rsi
  unsigned __int64 v38; // rdx
  size_t v39; // rcx
  size_t v40; // rcx
  boost::pool<boost::default_user_allocator_new_delete>::size_type v42; // [rsp+0h] [rbp-38h]

  requested_size = this->requested_size;
  v3 = 8;
  if ( requested_size > 8 )
    v3 = this->requested_size;
  v4 = 8 - (v3 & 7);
  if ( (v3 & 7) == 0 )
    v4 = v3 & 7;
  v5 = v3 + v4;
  v6 = 0;
  v7 = n * requested_size / v5 + (n * requested_size % v5 != 0);
  if ( v7 )
  {
    v8 = this;
    while ( 1 )
    {
      first = (boost::pool<boost::default_user_allocator_new_delete> *)v8->first;
      if ( !v8->first )
        break;
      v10 = n * requested_size / v5 + (n * requested_size % v5 != 0);
      while ( 1 )
      {
        v11 = first;
        if ( !--v10 )
          break;
        first = (boost::pool<boost::default_user_allocator_new_delete> *)first->first;
        if ( v11->first != (char *)v11 + v5 )
        {
          v8 = v11;
          v11 = 0;
          break;
        }
      }
      if ( v11 )
      {
        v6 = (char *)v8->first;
        v8->first = v11->first;
        break;
      }
    }
  }
  if ( n && !v6 )
  {
    v42 = requested_size;
    next_size = this->next_size;
    v13 = next_size;
    if ( next_size < v7 )
      v13 = n * requested_size / v5 + (n * requested_size % v5 != 0);
    this->next_size = v13;
    v15 = v5 * v13 + 16;
    v16 = (char *)operator new[](v15, (const std::nothrow_t *)&std::nothrow);
    if ( v16 )
    {
      v6 = v16;
    }
    else
    {
      if ( v7 >= next_size )
        return 0;
      v13 >>= 1;
      if ( v13 < v7 )
        v13 = v7;
      this->next_size = v13;
      v15 = v5 * v13 + 16;
      v6 = (char *)operator new[](v15, (const std::nothrow_t *)&std::nothrow);
      if ( !v6 )
        return 0;
    }
    if ( v13 > v7 )
    {
      v18 = v5 * v7;
      v19 = &v6[v18];
      v20 = v15 + -16LL - v18;
      v21 = (boost::pool<boost::default_user_allocator_new_delete> *)this->first;
      if ( this->first && v21 <= (boost::pool<boost::default_user_allocator_new_delete> *)v19 )
      {
        do
        {
          v22 = v21;
          v21 = (boost::pool<boost::default_user_allocator_new_delete> *)v21->first;
        }
        while ( v21 && v21 <= (boost::pool<boost::default_user_allocator_new_delete> *)v19 );
        v23 = v20 - v5 - (v20 - v5) % v5;
        *(_QWORD *)&v19[v23] = v21;
        if ( v23 )
        {
          v24 = &v19[v23];
          v25 = &v24[-v5];
          if ( &v24[-v5] == v19 )
          {
            v26 = v24;
          }
          else
          {
            do
            {
              v26 = v25;
              *(_QWORD *)v25 = v24;
              v25 -= v5;
              v24 = v26;
            }
            while ( v25 != v19 );
          }
          *(_QWORD *)v19 = v26;
        }
      }
      else
      {
        v27 = v20 - v5 - (v20 - v5) % v5;
        *(_QWORD *)&v19[v27] = v21;
        if ( v27 )
        {
          v28 = &v19[v27];
          v29 = &v28[-v5];
          if ( &v28[-v5] == v19 )
          {
            v30 = v28;
          }
          else
          {
            do
            {
              v30 = v29;
              *(_QWORD *)v29 = v28;
              v29 -= v5;
              v28 = v30;
            }
            while ( v29 != v19 );
          }
          *(_QWORD *)v19 = v30;
        }
        v22 = this;
      }
      v22->first = v19;
    }
    max_size = this->max_size;
    if ( max_size )
    {
      if ( v5 * v13 / v42 >= max_size )
      {
LABEL_51:
        ptr = this->list.ptr;
        if ( ptr && ptr <= v6 )
        {
          sz = this->list.sz;
          v36 = (size_t *)&ptr[sz - 8];
          v37 = (char **)&ptr[sz - 16];
          v38 = (unsigned __int64)*v37;
          if ( *v37 )
          {
            while ( v38 <= (unsigned __int64)v6 )
            {
              v39 = *v36;
              v36 = (size_t *)(v38 + *v36 - 8);
              v37 = (char **)(v38 + v39 - 16);
              v38 = (unsigned __int64)*v37;
              if ( !*v37 )
                goto LABEL_56;
            }
          }
          else
          {
LABEL_56:
            v38 = 0;
          }
          v40 = *v36;
          *(_QWORD *)&v6[v15 - 16] = v38;
          *(_QWORD *)&v6[v15 - 8] = v40;
          *v37 = v6;
          *v36 = v15;
        }
        else
        {
          *(_QWORD *)&v6[v15 - 16] = ptr;
          *(_QWORD *)&v6[v15 - 8] = this->list.sz;
          this->list.ptr = v6;
          this->list.sz = v15;
        }
        return v6;
      }
      v32 = 2 * v13;
      v33 = v42 * max_size;
      if ( v33 / v5 < v32 )
        v32 = v33 / v5;
    }
    else
    {
      v32 = 2 * v13;
    }
    this->next_size = v32;
    goto LABEL_51;
  }
  return v6;
}


// Address: 0x1edd300 | Name: _ZN5boost4poolINS_33default_user_allocator_new_deleteEE26ordered_malloc_need_resizeEv
void *__fastcall boost::pool<boost::default_user_allocator_new_delete>::ordered_malloc_need_resize(
        boost::pool<boost::default_user_allocator_new_delete> *this)
{
  boost::pool<boost::default_user_allocator_new_delete>::size_type requested_size; // r13
  boost::pool<boost::default_user_allocator_new_delete>::size_type v3; // rax
  __int64 v4; // rbp
  boost::pool<boost::default_user_allocator_new_delete>::size_type next_size; // r12
  boost::pool<boost::default_user_allocator_new_delete>::size_type v6; // rbp
  size_t v7; // r15
  char *v8; // rax
  char *v9; // rcx
  boost::pool<boost::default_user_allocator_new_delete>::size_type max_size; // rsi
  boost::pool<boost::default_user_allocator_new_delete>::size_type v11; // r12
  boost::pool<boost::default_user_allocator_new_delete>::size_type v12; // rsi
  void *result; // rax
  size_t v14; // rsi
  boost::pool<boost::default_user_allocator_new_delete> *first; // rdi
  boost::pool<boost::default_user_allocator_new_delete> *v16; // rbx
  size_t v17; // rsi
  char *v18; // rsi
  char *v19; // rax
  __int64 v20; // rbp
  char *v21; // rdx
  size_t v22; // rsi
  char *v23; // rsi
  char *v24; // rax
  __int64 v25; // rbp
  char *v26; // rdx
  char *ptr; // rsi
  boost::details::PODptr<unsigned long>::size_type i; // rdi
  boost::details::PODptr<unsigned long>::size_type *p_sz; // rax
  boost::details::PODptr<unsigned long> *p_list; // rdx
  boost::details::PODptr<unsigned long>::size_type v31; // rdi

  requested_size = this->requested_size;
  v3 = 8;
  if ( requested_size > 8 )
    v3 = this->requested_size;
  v4 = 8 - (v3 & 7);
  if ( (v3 & 7) == 0 )
    v4 = v3 & 7;
  next_size = this->next_size;
  v6 = v3 + v4;
  v7 = next_size * v6 + 16;
  v8 = (char *)operator new[](v7, (const std::nothrow_t *)&std::nothrow);
  if ( v8 )
  {
    v9 = v8;
  }
  else
  {
    if ( next_size < 5 )
      return 0;
    next_size >>= 1;
    this->next_size = next_size;
    v7 = next_size * v6 + 16;
    v9 = (char *)operator new[](v7, (const std::nothrow_t *)&std::nothrow);
    if ( !v9 )
      return 0;
  }
  max_size = this->max_size;
  if ( max_size )
  {
    if ( v6 * next_size / requested_size >= max_size )
      goto LABEL_17;
    v11 = 2 * next_size;
    v12 = requested_size * max_size;
    if ( v12 / v6 < v11 )
      v11 = v12 / v6;
  }
  else
  {
    v11 = 2 * next_size;
  }
  this->next_size = v11;
LABEL_17:
  v14 = v7 - 16;
  first = (boost::pool<boost::default_user_allocator_new_delete> *)this->first;
  if ( this->first && first <= (boost::pool<boost::default_user_allocator_new_delete> *)v9 )
  {
    do
    {
      v16 = first;
      first = (boost::pool<boost::default_user_allocator_new_delete> *)first->first;
    }
    while ( first && first <= (boost::pool<boost::default_user_allocator_new_delete> *)v9 );
    v17 = v14 - v6 - (v14 - v6) % v6;
    *(_QWORD *)&v9[v17] = first;
    if ( v17 )
    {
      v18 = &v9[v17];
      v19 = &v18[-v6];
      if ( &v18[-v6] == v9 )
      {
        v21 = v18;
      }
      else
      {
        v20 = -(__int64)v6;
        do
        {
          v21 = v19;
          *(_QWORD *)v19 = v18;
          v19 += v20;
          v18 = v21;
        }
        while ( v19 != v9 );
      }
      *(_QWORD *)v9 = v21;
    }
  }
  else
  {
    v22 = v14 - v6 - (v14 - v6) % v6;
    *(_QWORD *)&v9[v22] = first;
    if ( v22 )
    {
      v23 = &v9[v22];
      v24 = &v23[-v6];
      if ( &v23[-v6] == v9 )
      {
        v26 = v23;
      }
      else
      {
        v25 = -(__int64)v6;
        do
        {
          v26 = v24;
          *(_QWORD *)v24 = v23;
          v24 += v25;
          v23 = v26;
        }
        while ( v24 != v9 );
      }
      *(_QWORD *)v9 = v26;
    }
    v16 = this;
  }
  v16->first = v9;
  ptr = this->list.ptr;
  if ( ptr && ptr <= v9 )
  {
    for ( i = this->list.sz; ; i = *p_sz )
    {
      p_sz = (boost::details::PODptr<unsigned long>::size_type *)&ptr[i - 8];
      p_list = (boost::details::PODptr<unsigned long> *)&ptr[i - 16];
      ptr = p_list->ptr;
      if ( !p_list->ptr )
        break;
      if ( ptr > v9 )
        goto LABEL_45;
    }
    ptr = 0;
LABEL_45:
    v31 = *p_sz;
    *(_QWORD *)&v9[v7 - 16] = ptr;
    *(_QWORD *)&v9[v7 - 8] = v31;
  }
  else
  {
    p_list = &this->list;
    *(_QWORD *)&v9[v7 - 16] = ptr;
    p_sz = &this->list.sz;
    *(_QWORD *)&v9[v7 - 8] = this->list.sz;
  }
  p_list->ptr = v9;
  *p_sz = v7;
  result = this->first;
  this->first = *(void **)this->first;
  return result;
}


// Address: 0x1edd510 | Name: _ZN5boost4poolI19dtMeshTileAllocatorED2Ev
void __fastcall boost::pool<dtMeshTileAllocator>::~pool(boost::pool<dtMeshTileAllocator> *this)
{
  char *ptr; // r15
  boost::details::PODptr<unsigned long>::size_type sz; // rbx
  char *v4; // rdi

  ptr = this->list.ptr;
  if ( ptr )
  {
    sz = this->list.sz;
    do
    {
      v4 = ptr;
      ptr = *(char **)&ptr[sz - 16];
      sz = *(_QWORD *)&v4[sz - 8];
      dtFree(v4);
    }
    while ( ptr );
    *(_OWORD *)&this->first = 0;
    this->next_size = this->start_size;
  }
}


// Address: 0x1eddac0 | Name: _ZN5boost4poolI19dtMeshTileAllocatorE26ordered_malloc_need_resizeEv
void *__fastcall boost::pool<dtMeshTileAllocator>::ordered_malloc_need_resize(boost::pool<dtMeshTileAllocator> *this)
{
  boost::pool<dtMeshTileAllocator>::size_type requested_size; // rax
  __int64 v3; // r13
  boost::pool<dtMeshTileAllocator>::size_type v4; // r13
  size_t v5; // r15
  char *v6; // rax
  char *v7; // rbx
  boost::pool<dtMeshTileAllocator>::size_type v8; // rsi
  boost::pool<dtMeshTileAllocator>::size_type max_size; // rdi
  boost::pool<dtMeshTileAllocator>::size_type v10; // rcx
  boost::pool<dtMeshTileAllocator>::size_type v11; // rsi
  boost::pool<dtMeshTileAllocator>::size_type v12; // rcx
  boost::pool<dtMeshTileAllocator>::size_type next_size; // r15
  boost::pool<dtMeshTileAllocator>::size_type v14; // r15
  boost::pool<dtMeshTileAllocator>::size_type v15; // rax
  __int64 v16; // r13
  void *v17; // r12
  size_t v18; // rcx
  boost::pool<dtMeshTileAllocator> *first; // rdi
  boost::pool<dtMeshTileAllocator> *v20; // rsi
  size_t v21; // rcx
  char *v22; // rcx
  char *v23; // rax
  __int64 v24; // r13
  char *v25; // rdx
  size_t v26; // rcx
  char *v27; // rcx
  char *v28; // rax
  __int64 v29; // r13
  char *v30; // rdx
  char *ptr; // rdx
  boost::details::PODptr<unsigned long>::size_type i; // rsi
  boost::details::PODptr<unsigned long>::size_type *p_sz; // rax
  boost::details::PODptr<unsigned long> *p_list; // rcx
  boost::details::PODptr<unsigned long>::size_type v35; // rsi

  requested_size = this->requested_size;
  if ( requested_size <= 8 )
    requested_size = 8;
  v3 = 8 - (requested_size & 7);
  if ( (requested_size & 7) == 0 )
    v3 = requested_size & 7;
  v4 = requested_size + v3;
  v5 = v4 * this->next_size + 16;
  v6 = (char *)dtAlloc(v5, dtAllocHint::DT_ALLOC_PERM);
  if ( v6 )
    goto LABEL_6;
  next_size = this->next_size;
  if ( next_size < 5 )
    return 0;
  v14 = next_size >> 1;
  this->next_size = v14;
  v15 = this->requested_size;
  if ( v15 <= 8 )
    v15 = 8;
  v16 = 8 - (v15 & 7);
  if ( (v15 & 7) == 0 )
    v16 = v15 & 7;
  v4 = v15 + v16;
  v5 = v4 * v14 + 16;
  v17 = 0;
  v6 = (char *)dtAlloc(v5, dtAllocHint::DT_ALLOC_PERM);
  if ( v6 )
  {
LABEL_6:
    v7 = v6;
    memset(v6, 0, v5);
    v8 = this->next_size;
    max_size = this->max_size;
    if ( max_size )
    {
      v10 = this->requested_size;
      if ( v4 * v8 / v10 >= max_size )
        goto LABEL_20;
      v11 = 2 * v8;
      v12 = max_size * v10;
      if ( v12 / v4 < v11 )
        v11 = v12 / v4;
    }
    else
    {
      v11 = 2 * v8;
    }
    this->next_size = v11;
LABEL_20:
    v18 = v5 - 16;
    first = (boost::pool<dtMeshTileAllocator> *)this->first;
    if ( this->first && first <= (boost::pool<dtMeshTileAllocator> *)v7 )
    {
      do
      {
        v20 = first;
        first = (boost::pool<dtMeshTileAllocator> *)first->first;
      }
      while ( first && first <= (boost::pool<dtMeshTileAllocator> *)v7 );
      v21 = v18 - v4 - (v18 - v4) % v4;
      *(_QWORD *)&v7[v21] = first;
      if ( v21 )
      {
        v22 = &v7[v21];
        v23 = &v22[-v4];
        if ( &v22[-v4] == v7 )
        {
          v25 = v22;
        }
        else
        {
          v24 = -(__int64)v4;
          do
          {
            v25 = v23;
            *(_QWORD *)v23 = v22;
            v23 += v24;
            v22 = v25;
          }
          while ( v23 != v7 );
        }
        *(_QWORD *)v7 = v25;
      }
    }
    else
    {
      v26 = v18 - v4 - (v18 - v4) % v4;
      *(_QWORD *)&v7[v26] = first;
      if ( v26 )
      {
        v27 = &v7[v26];
        v28 = &v27[-v4];
        if ( &v27[-v4] == v7 )
        {
          v30 = v27;
        }
        else
        {
          v29 = -(__int64)v4;
          do
          {
            v30 = v28;
            *(_QWORD *)v28 = v27;
            v28 += v29;
            v27 = v30;
          }
          while ( v28 != v7 );
        }
        *(_QWORD *)v7 = v30;
      }
      v20 = this;
    }
    v20->first = v7;
    ptr = this->list.ptr;
    if ( ptr && ptr <= v7 )
    {
      for ( i = this->list.sz; ; i = *p_sz )
      {
        p_sz = (boost::details::PODptr<unsigned long>::size_type *)&ptr[i - 8];
        p_list = (boost::details::PODptr<unsigned long> *)&ptr[i - 16];
        ptr = p_list->ptr;
        if ( !p_list->ptr )
          break;
        if ( ptr > v7 )
          goto LABEL_49;
      }
      ptr = 0;
LABEL_49:
      v35 = *p_sz;
      *(_QWORD *)&v7[v5 - 16] = ptr;
      *(_QWORD *)&v7[v5 - 8] = v35;
    }
    else
    {
      p_list = &this->list;
      *(_QWORD *)&v7[v5 - 16] = ptr;
      p_sz = &this->list.sz;
      *(_QWORD *)&v7[v5 - 8] = this->list.sz;
    }
    p_list->ptr = v7;
    *p_sz = v5;
    v17 = this->first;
    this->first = *(void **)this->first;
  }
  return v17;
}


// Address: 0x1eec730 | Name: _ZN10dtNodePoolC2Ev
void __fastcall dtNodePool::dtNodePool(dtNodePool *this)
{
  *(_OWORD *)&this->m_pool.first = 0;
  this->m_pool.list.sz = 0;
  *(_OWORD *)&this->m_pool.requested_size = xmmword_3E7D40;
  *(_OWORD *)&this->m_pool.start_size = 0x20u;
  this->m_map.table_.current_ = 0;
  *(_OWORD *)&this->m_map.table_.bucket_count_ = 0x10u;
  this->m_map.table_.mlf_ = 1.0;
  *(_OWORD *)&this->m_map.table_.max_load_ = 0;
}


