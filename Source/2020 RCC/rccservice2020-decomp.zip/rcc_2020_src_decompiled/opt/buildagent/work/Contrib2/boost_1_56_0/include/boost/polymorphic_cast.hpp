// Address: 0x1596250 | Name: _ZNK3RBX10Reflection9EventDescINS_9DataModelEFvN5boost10shared_ptrINS_8InstanceEEEPKNS0_18PropertyDescriptorEEN3rbx6signalISA_EEMS2_SD_E16fireEventGenericEPNS0_11EventSourceERKNSt3__16vectorINS0_7VariantENSI_9allocatorISK_EEEE
void __fastcall RBX::Reflection::EventDesc<RBX::DataModel,void ()(boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*),rbx::signal<void ()(boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*)>,rbx::signal<void ()(boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*)> RBX::DataModel::*>::fireEventGeneric(
        const RBX::Reflection::EventDesc<RBX::DataModel,void (boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *),rbx::signal<void (boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *)>,rbx::signal<void (boost::shared_ptr<RBX::Instance>,const RBX::Reflection::PropertyDescriptor *)> RBX::DataModel::*> *this,
        RBX::Reflection::EventSource *source,
        const RBX::Reflection::EventArguments *args)
{
  RBX::index_sequence<0UL,1UL> v3; // cl

  if ( source )
    source -= 17;
  RBX::Reflection::EventDesc<RBX::DataModel,void ()(boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*),rbx::signal<void ()(boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*)>,rbx::signal<void ()(boost::shared_ptr<RBX::Instance>,RBX::Reflection::PropertyDescriptor const*)> RBX::DataModel::*>::unpackGenericEventArgs<0ul,1ul>(
    this,
    (RBX::DataModel *)source,
    args,
    v3);
}


// Address: 0x15978b0 | Name: _ZNK3RBX10Reflection13BoundFuncDescINS_9DataModelEFN5boost10shared_ptrIKNSt3__16vectorINS0_7VariantENS5_9allocatorIS7_EEEEEEvELi0EE10executeLuaEPNS0_13DescribedBaseEP9lua_Statei
int __fastcall RBX::Reflection::BoundFuncDesc<RBX::DataModel,boost::shared_ptr<std::vector<RBX::Reflection::Variant> const> ()(void),0>::executeLua(
        const RBX::Reflection::BoundFuncDesc<RBX::DataModel,boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > (),0> *this,
        RBX::Reflection::DescribedBase *instance,
        lua_State *L,
        int offset)
{
  RBX::DataModel *p_descriptor; // rax

  p_descriptor = (RBX::DataModel *)&instance[-4].descriptor;
  if ( !instance )
    p_descriptor = 0;
  return RBX::Reflection::call0<RBX::DataModel,boost::shared_ptr<std::vector<RBX::Reflection::Variant> const> (RBX::DataModel::*)(void),boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>(
           p_descriptor,
           *((boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > (**)(RBX::DataModel *))this + 13),
           *((lua_State **)this + 14),
           L);
}


// Address: 0x1599300 | Name: _ZNK3RBX10Reflection9EventDescINS_9DataModelEFvvEN3rbx6signalIS3_EEMS2_S6_E16fireEventGenericEPNS0_11EventSourceERKNSt3__16vectorINS0_7VariantENSB_9allocatorISD_EEEE
void __fastcall RBX::Reflection::EventDesc<RBX::DataModel,void ()(void),rbx::signal<void ()(void)>,rbx::signal<void ()(void)> RBX::DataModel::*>::fireEventGeneric(
        const RBX::Reflection::EventDesc<RBX::DataModel,void (),rbx::signal<void ()>,rbx::signal<void ()> RBX::DataModel::*> *this,
        RBX::Reflection::EventSource *source,
        const RBX::Reflection::EventArguments *args)
{
  RBX::Reflection::EventSource *v3; // rax

  v3 = source - 17;
  if ( !source )
    v3 = 0;
  rbx::signal<void ()(void)>::operator()((rbx::signal<void ()> *)((char *)v3 + *((_QWORD *)this + 12)));
}


// Address: 0x1599ba0 | Name: _ZNK3RBX10Reflection9EventDescINS_9DataModelEFvNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEEEN3rbx6signalISA_EEMS2_SD_E16fireEventGenericEPNS0_11EventSourceERKNS3_6vectorINS0_7VariantENS7_ISJ_EEEE
void __fastcall RBX::Reflection::EventDesc<RBX::DataModel,void ()(std::string),rbx::signal<void ()(std::string)>,rbx::signal<void ()(std::string)> RBX::DataModel::*>::fireEventGeneric(
        const RBX::Reflection::EventDesc<RBX::DataModel,void (std::string),rbx::signal<void (std::string)>,rbx::signal<void (std::string)> RBX::DataModel::*> *this,
        RBX::Reflection::EventSource *source,
        const RBX::Reflection::EventArguments *args)
{
  RBX::index_sequence<0UL> v3; // cl

  if ( source )
    source -= 17;
  RBX::Reflection::EventDesc<RBX::DataModel,void ()(std::string),rbx::signal<void ()(std::string)>,rbx::signal<void ()(std::string)> RBX::DataModel::*>::unpackGenericEventArgs<0ul>(
    this,
    (RBX::DataModel *)source,
    args,
    v3);
}


