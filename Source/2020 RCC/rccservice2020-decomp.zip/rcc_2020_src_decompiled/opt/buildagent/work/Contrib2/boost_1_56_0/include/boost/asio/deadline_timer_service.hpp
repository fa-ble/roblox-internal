// Address: 0x2605870 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEED2Ev
void __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::~deadline_timer_service(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this)
{
  __int64 v2; // r15
  _QWORD *v3; // rax
  _QWORD *v4; // rdx
  void *v5; // rdi

  *(_QWORD *)this = &off_29C3118;
  v2 = *((_QWORD *)this + 13);
  pthread_mutex_lock((pthread_mutex_t *)(v2 + 48));
  v3 = *(_QWORD **)(v2 + 104);
  if ( v3 )
  {
    if ( v3 == (_QWORD *)((char *)this + 40) )
    {
      *(_QWORD *)(v2 + 104) = *((_QWORD *)this + 6);
LABEL_7:
      *((_QWORD *)this + 6) = 0;
    }
    else
    {
      while ( 1 )
      {
        v4 = v3;
        v3 = (_QWORD *)v3[1];
        if ( !v3 )
          break;
        if ( v3 == (_QWORD *)((char *)this + 40) )
        {
          v4[1] = *((_QWORD *)this + 6);
          goto LABEL_7;
        }
      }
    }
  }
  pthread_mutex_unlock((pthread_mutex_t *)(v2 + 48));
  *((_QWORD *)this + 5) = &off_29C3188;
  *((_QWORD *)this + 7) = &off_29C3218;
  v5 = (void *)*((_QWORD *)this + 10);
  if ( v5 )
  {
    *((_QWORD *)this + 11) = v5;
    operator delete(v5);
  }
}


// Address: 0x2605920 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEED0Ev
void __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::~deadline_timer_service(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this)
{
  __int64 v2; // r15
  _QWORD *v3; // rax
  _QWORD *v4; // rdx
  void *v5; // rdi

  *(_QWORD *)this = &off_29C3118;
  v2 = *((_QWORD *)this + 13);
  pthread_mutex_lock((pthread_mutex_t *)(v2 + 48));
  v3 = *(_QWORD **)(v2 + 104);
  if ( v3 )
  {
    if ( v3 == (_QWORD *)((char *)this + 40) )
    {
      *(_QWORD *)(v2 + 104) = *((_QWORD *)this + 6);
LABEL_7:
      *((_QWORD *)this + 6) = 0;
    }
    else
    {
      while ( 1 )
      {
        v4 = v3;
        v3 = (_QWORD *)v3[1];
        if ( !v3 )
          break;
        if ( v3 == (_QWORD *)((char *)this + 40) )
        {
          v4[1] = *((_QWORD *)this + 6);
          goto LABEL_7;
        }
      }
    }
  }
  pthread_mutex_unlock((pthread_mutex_t *)(v2 + 48));
  *((_QWORD *)this + 5) = &off_29C3188;
  *((_QWORD *)this + 7) = &off_29C3218;
  v5 = (void *)*((_QWORD *)this + 10);
  if ( v5 )
  {
    *((_QWORD *)this + 11) = v5;
    operator delete(v5);
  }
  operator delete(this);
}


// Address: 0x26059d0 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE16shutdown_serviceEv
void __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::shutdown_service(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this)
{
  ;
}


// Address: 0x26063b0 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINSE_6config15asio_tls_client16transport_configEEEFvNSC_10shared_ptrINS0_20basic_deadline_timerIS3_S5_S6_EEEENSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEEJNSM_ISL_EERSP_RSV_RKNSC_12placeholders4__phILi1EEEEEENS8_26is_continuation_if_runningEEEEENS0_12async_resultINS0_12handler_typeIT_FvSX_EE4typeEE4typeERNS8_22deadline_timer_serviceIS5_E19implementation_typeEOS1F_
boost::asio::async_result<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v9; // rbx
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> v10; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v11; // [rsp+88h] [rbp-20h]

  v11 = __readfsqword(0x28u);
  v10.dispatcher_ = handler->dispatcher_;
  *(_OWORD *)&v10.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v10.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  v10.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      v10.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, __int64, __int64, __int64, boost::asio::detail::strand_service *, boost::asio::detail::strand_service::implementation_type, std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >::element_type *))f->dispatcher_.service_->owner_)(
        f,
        &v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        handler,
        v3,
        v4,
        v5,
        v10.dispatcher_.service_,
        v10.dispatcher_.impl_,
        v10.handler_.__f_,
        *((_QWORD *)&v10.handler_.__f_ + 1),
        v10.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v10.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v10.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v10);
  if ( &v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v10.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v10.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v10.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v10.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v10.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v10.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v10.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v9 = v10.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
      std::__shared_weak_count::__release_weak(v9);
    }
  }
}


// Address: 0x260a850 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSL_EE4typeEE4typeERNS0_6detail22deadline_timer_serviceIS5_E19implementation_typeEOST_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *handler)
{
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *f; // rdi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > v5; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v6; // [rsp+88h] [rbp-20h]

  v6 = __readfsqword(0x28u);
  *(_OWORD *)&v5.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v5.start_ = handler->start_;
  v5.want_ = handler->want_;
  v5.ec_ = handler->ec_;
  v5.bytes_transferred_ = handler->bytes_transferred_;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &)> *)f )
    {
      v5.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&v5.handler_;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *, std::function<void (const boost::system::error_code &)> *))f->next_layer_->service_)(
        f,
        &v5.handler_);
    }
    else
    {
      v5.handler_.__f_ = handler->handler_.__f_;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    v5.handler_.__f_ = 0;
  }
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v5);
  if ( &v5.handler_ == (std::function<void (const boost::system::error_code &)> *)v5.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v5.handler_.__f_->_vptr$__base
     + 4))(v5.handler_.__f_);
  }
  else if ( v5.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *, boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *))v5.handler_.__f_->_vptr$__base
     + 5))(
      v5.handler_.__f_,
      impl);
  }
}


// Address: 0x2633910 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_12handshake_opENS0_6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSM_8functionIFvRKNSM_10error_codeEEEERKNS_6system10error_codeEEJNSM_10shared_ptrISS_EERSY_RKNSM_12placeholders4__phILi1EEEEEENSI_26is_continuation_if_runningEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvS10_EE4typeEE4typeERNSI_22deadline_timer_serviceIS5_E19implementation_typeEOS1J_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > v9; // [rsp+0h] [rbp-D8h] BYREF
  unsigned __int64 v10; // [rsp+B8h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v9.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v9.op_.type_ = handler->op_.type_;
  v9.start_ = handler->start_;
  v9.want_ = handler->want_;
  v9.ec_ = handler->ec_;
  v9.bytes_transferred_ = handler->bytes_transferred_;
  v9.handler_.dispatcher_ = handler->handler_.dispatcher_;
  *(_OWORD *)&v9.handler_.handler_.__f_ = *(_OWORD *)&handler->handler_.handler_.__f_;
  v9.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)handler->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v9.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, _QWORD, const boost::system::error_category *, size_t))f->next_layer_->service_)(
        f,
        &v9.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        handler,
        v3,
        v4,
        v5,
        v9.next_layer_,
        v9.core_,
        *(_QWORD *)&v9.op_.type_,
        v9.want_,
        *(_QWORD *)&v9.ec_.m_val,
        v9.ec_.m_cat,
        v9.bytes_transferred_);
    }
    else
    {
      v9.handler_.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v9);
  if ( &v9.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v9.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26379f0 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSI_8functionIFvRKNSI_10error_codeEEEERKNS_6system10error_codeEEJNSI_10shared_ptrISO_EERSU_RKNSI_12placeholders4__phILi1EEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSW_EE4typeEE4typeERNS0_6detail22deadline_timer_serviceIS5_E19implementation_typeEOS1D_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v9; // [rsp+0h] [rbp-C8h] BYREF
  unsigned __int64 v10; // [rsp+A8h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v9.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v9.op_.type_ = handler->op_.type_;
  v9.start_ = handler->start_;
  v9.want_ = handler->want_;
  v9.ec_ = handler->ec_;
  v9.bytes_transferred_ = handler->bytes_transferred_;
  *(_OWORD *)&v9.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v9.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, _QWORD, const boost::system::error_category *, size_t))f->next_layer_->service_)(
        f,
        &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        handler,
        v3,
        v4,
        v5,
        v9.next_layer_,
        v9.core_,
        *(_QWORD *)&v9.op_.type_,
        v9.want_,
        *(_QWORD *)&v9.ec_.m_val,
        v9.ec_.m_cat,
        v9.bytes_transferred_);
    }
    else
    {
      v9.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v9);
  if ( &v9.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v9.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v9.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v9.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v9.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v9.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v9.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26568b0 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10connectionINSE_6config11asio_client16transport_configEEEFvNSC_10shared_ptrINS0_20basic_deadline_timerIS3_S5_S6_EEEENSC_8functionIFvRKNSC_10error_codeEEEERKNS_6system10error_codeEEJNSM_ISL_EERSP_RSV_RKNSC_12placeholders4__phILi1EEEEEENS8_26is_continuation_if_runningEEEEENS0_12async_resultINS0_12handler_typeIT_FvSX_EE4typeEE4typeERNS8_22deadline_timer_serviceIS5_E19implementation_typeEOS1F_
boost::asio::async_result<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v9; // rbx
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> v10; // [rsp+0h] [rbp-A8h] BYREF
  unsigned __int64 v11; // [rsp+88h] [rbp-20h]

  v11 = __readfsqword(0x28u);
  v10.dispatcher_ = handler->dispatcher_;
  *(_OWORD *)&v10.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v10.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  v10.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)f )
    {
      v10.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *, boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, __int64, __int64, __int64, boost::asio::detail::strand_service *, boost::asio::detail::strand_service::implementation_type, std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>::_Fd, _QWORD, std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >::element_type *))f->dispatcher_.service_->owner_)(
        f,
        &v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false>,
        handler,
        v3,
        v4,
        v5,
        v10.dispatcher_.service_,
        v10.dispatcher_.impl_,
        v10.handler_.__f_,
        *((_QWORD *)&v10.handler_.__f_ + 1),
        v10.handler_.__bound_args_.__base_.__value_.__ptr_);
    }
    else
    {
      v10.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v10.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v10);
  if ( &v10.handler_.__bound_args_.__base_.std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<2,std::function<void (const std::error_code &)>,false> *)v10.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v10.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v10.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v10.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v10.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v10.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v10.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  v9 = v10.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v10.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v9 + 16LL))(v9);
      std::__shared_weak_count::__release_weak(v9);
    }
  }
}


// Address: 0x26a2f80 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS8_6streamIRSG_EESI_NSK_14transfer_all_tENSK_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSU_5list2INSU_5valueINSR_10shared_ptrIS13_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvS15_EE4typeEE4typeERNSK_22deadline_timer_serviceIS5_E19implementation_typeEOS1P_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > v4; // [rsp+0h] [rbp-A8h] BYREF

  v4 = *handler;
  handler->handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v4);
  cntrl = v4.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v4.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v4.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a5db0 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_7read_opINS0_17mutable_buffers_1EEENS0_6detail26read_until_delim_string_opINS8_6streamIRSG_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSS_5list2INSS_5valueINSP_10shared_ptrIS11_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvS13_EE4typeEE4typeERNSK_22deadline_timer_serviceIS5_E19implementation_typeEOS1M_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *v3; // rbx
  _OWORD v4[2]; // [rsp+0h] [rbp-B8h] BYREF
  int v5; // [rsp+20h] [rbp-98h]
  int v6; // [rsp+24h] [rbp-94h]
  __int128 v7; // [rsp+28h] [rbp-90h]
  __int128 v8; // [rsp+38h] [rbp-80h]
  __int64 v9; // [rsp+48h] [rbp-70h]
  __int128 v10; // [rsp+50h] [rbp-68h]
  void *ptr; // [rsp+60h] [rbp-58h]
  int v12; // [rsp+68h] [rbp-50h]
  __int64 v13; // [rsp+70h] [rbp-48h]
  __int128 v14; // [rsp+78h] [rbp-40h]
  std::__shared_weak_count *v15[2]; // [rsp+88h] [rbp-30h]

  v4[0] = *(_OWORD *)handler;
  v4[1] = *((_OWORD *)handler + 1);
  v5 = *((_DWORD *)handler + 8);
  v6 = *((_DWORD *)handler + 9);
  v7 = *(_OWORD *)((char *)handler + 40);
  v8 = *(_OWORD *)((char *)handler + 56);
  v9 = *((_QWORD *)handler + 9);
  ptr = (void *)*((_QWORD *)handler + 12);
  v10 = *((_OWORD *)handler + 5);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  v12 = *((_DWORD *)handler + 26);
  v13 = *((_QWORD *)handler + 14);
  v14 = *(_OWORD *)((char *)handler + 120);
  *(_OWORD *)v15 = *(_OWORD *)((char *)handler + 136);
  *(_OWORD *)((char *)handler + 136) = 0;
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)v4);
  v3 = v15[1];
  if ( v15[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v15[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(v3);
    std::__shared_weak_count::__release_weak(v3);
    if ( (v10 & 1) == 0 )
      return;
  }
  else if ( (v10 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a9170 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSI_5list2INSI_5valueINSt3__110shared_ptrISQ_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSS_EE4typeEE4typeERNS0_6detail22deadline_timer_serviceIS5_E19implementation_typeEOS1B_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v4; // [rsp+0h] [rbp-78h] BYREF

  v4 = *handler;
  handler->handler_.l_ = 0;
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v4);
  cntrl = v4.handler_.l_.a1_.t_.__cntrl_;
  if ( v4.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v4.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26aa9d0 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS8_6streamIRSG_EESI_NSK_14transfer_all_tENSK_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSU_5list2INSU_5valueINSR_10shared_ptrIS12_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvS14_EE4typeEE4typeERNSK_22deadline_timer_serviceIS5_E19implementation_typeEOS1O_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > v4; // [rsp+0h] [rbp-A8h] BYREF

  v4 = *handler;
  handler->handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v4);
  cntrl = v4.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v4.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v4.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26ae230 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_7read_opINS0_17mutable_buffers_1EEENS0_6detail26read_until_delim_string_opINS8_6streamIRSG_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSS_5list2INSS_5valueINSP_10shared_ptrIS10_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvS12_EE4typeEE4typeERNSK_22deadline_timer_serviceIS5_E19implementation_typeEOS1L_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *v3; // rbx
  _OWORD v4[2]; // [rsp+0h] [rbp-B8h] BYREF
  int v5; // [rsp+20h] [rbp-98h]
  int v6; // [rsp+24h] [rbp-94h]
  __int128 v7; // [rsp+28h] [rbp-90h]
  __int128 v8; // [rsp+38h] [rbp-80h]
  __int64 v9; // [rsp+48h] [rbp-70h]
  __int128 v10; // [rsp+50h] [rbp-68h]
  void *ptr; // [rsp+60h] [rbp-58h]
  int v12; // [rsp+68h] [rbp-50h]
  __int64 v13; // [rsp+70h] [rbp-48h]
  __int128 v14; // [rsp+78h] [rbp-40h]
  std::__shared_weak_count *v15[2]; // [rsp+88h] [rbp-30h]

  v4[0] = *(_OWORD *)handler;
  v4[1] = *((_OWORD *)handler + 1);
  v5 = *((_DWORD *)handler + 8);
  v6 = *((_DWORD *)handler + 9);
  v7 = *(_OWORD *)((char *)handler + 40);
  v8 = *(_OWORD *)((char *)handler + 56);
  v9 = *((_QWORD *)handler + 9);
  ptr = (void *)*((_QWORD *)handler + 12);
  v10 = *((_OWORD *)handler + 5);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  v12 = *((_DWORD *)handler + 26);
  v13 = *((_QWORD *)handler + 14);
  v14 = *(_OWORD *)((char *)handler + 120);
  *(_OWORD *)v15 = *(_OWORD *)((char *)handler + 136);
  *(_OWORD *)((char *)handler + 136) = 0;
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)v4);
  v3 = v15[1];
  if ( v15[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v15[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v3 + 16LL))(v3);
    std::__shared_weak_count::__release_weak(v3);
    if ( (v10 & 1) == 0 )
      return;
  }
  else if ( (v10 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26b2a50 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_7read_opINS0_17mutable_buffers_1EEENS0_6detail17read_streambuf_opINS8_6streamIRSG_EENSt3__19allocatorIcEENSK_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENST_5list2INST_5valueINSP_10shared_ptrIS11_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvS13_EE4typeEE4typeERNSK_22deadline_timer_serviceIS5_E19implementation_typeEOS1M_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v4; // [rsp+0h] [rbp-A8h] BYREF

  v4 = *handler;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v4);
  cntrl = v4.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v4.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v4.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b64e0 | Name: _ZN5boost4asio22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS3_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISD_EEEENS9_7read_opINS0_17mutable_buffers_1EEENS0_6detail17read_streambuf_opINS8_6streamIRSG_EENSt3__19allocatorIcEENSK_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENST_5list3INST_5valueINSP_10shared_ptrIS11_EEEEPFNS_3argILi1EEEvENS18_IiEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvS13_EE4typeEE4typeERNSK_22deadline_timer_serviceIS5_E19implementation_typeEOS1N_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > >::type __fastcall boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >::implementation_type *impl,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > v4; // [rsp+0h] [rbp-A8h] BYREF

  *(_OWORD *)&v4.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v4.op_ = handler->op_;
  v4.start_ = handler->start_;
  v4.want_ = handler->want_;
  v4.ec_ = handler->ec_;
  *(_OWORD *)&v4.bytes_transferred_ = *(_OWORD *)&handler->bytes_transferred_;
  *(_OWORD *)&v4.handler_.stream_ = *(_OWORD *)&handler->handler_.stream_;
  v4.handler_.start_ = handler->handler_.start_;
  v4.handler_.total_transferred_ = handler->handler_.total_transferred_;
  v4.handler_.handler_.f_ = handler->handler_.handler_.f_;
  v4.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  v4.handler_.handler_.l_.a3_.t_ = handler->handler_.handler_.l_.a3_.t_;
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
    (boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 40),
    impl,
    &v4);
  cntrl = v4.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v4.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v4.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


