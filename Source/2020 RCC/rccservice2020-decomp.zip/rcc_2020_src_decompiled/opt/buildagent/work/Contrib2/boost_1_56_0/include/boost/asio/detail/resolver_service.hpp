// Address: 0x2620160 | Name: _ZN5boost4asio6detail16resolver_serviceINS0_2ip3tcpEE13async_resolveINS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSC_6config15asio_tls_client16transport_configEEEFvNSA_10shared_ptrINSE_10connectionISI_EEEENSK_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISQ_EENS0_22deadline_timer_serviceISQ_SS_EEEEEENSA_8functionIFvRKNSA_10error_codeEEEERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEJPSJ_RSN_RSW_RS12_RKNSA_12placeholders4__phILi1EEERKNS1G_ILi2EEEEEENS1_26is_continuation_if_runningEEEEEvRNSK_IvEERKNS3_20basic_resolver_queryIS4_EERT_
void __fastcall boost::asio::detail::resolver_service<boost::asio::ip::tcp>::async_resolve<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::detail::resolver_service<boost::asio::ip::tcp> *this,
        implementation_type *impl,
        const boost::asio::detail::resolver_service<boost::asio::ip::tcp>::query_type *query,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  unsigned __int64 v7; // rax
  void **v8; // rax
  void *v9; // rdi
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *v10; // r9
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v11; // r14
  volatile signed __int64 *cntrl; // rax
  std::shared_ptr<void>::element_type *ptr; // [rsp+0h] [rbp-38h] BYREF
  std::__shared_weak_count *v14; // [rsp+8h] [rbp-30h]

  v7 = __readfsqword(0xFFFFFFD8);
  if ( v7 )
  {
    v8 = *(void ***)(v7 + 8);
    if ( v8 )
    {
      v9 = *v8;
      if ( *v8 )
      {
        *v8 = 0;
        operator delete(v9);
      }
    }
  }
  v11 = (boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)operator new(0x131u);
  *((_BYTE *)v11 + 304) = 0;
  ptr = impl->__ptr_;
  cntrl = (volatile signed __int64 *)impl->__cntrl_;
  v14 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 2, 1u);
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_tls_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::resolve_op(
    v11,
    (boost::asio::detail::socket_ops::weak_cancel_token_type)__PAIR128__((unsigned __int64)query, &ptr),
    this->io_service_impl_,
    (boost::asio::detail::io_service_impl_0 *)handler,
    v10);
  if ( v14 )
    std::__shared_weak_count::__release_weak(v14);
  boost::asio::detail::resolver_service_base::start_work_thread(this);
  _InterlockedAdd64(&this->io_service_impl_->outstanding_work_.__a_, 1u);
  boost::asio::detail::task_io_service::post_immediate_completion(
    this->work_io_service_impl_,
    (boost::asio::detail::task_io_service::operation *)v11,
    0);
}


// Address: 0x2662fc0 | Name: _ZN5boost4asio6detail16resolver_serviceINS0_2ip3tcpEE13async_resolveINS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio8endpointINSC_6config11asio_client16transport_configEEEFvNSA_10shared_ptrINSE_10connectionISI_EEEENSK_INS0_20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsISQ_EENS0_22deadline_timer_serviceISQ_SS_EEEEEENSA_8functionIFvRKNSA_10error_codeEEEERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEJPSJ_RSN_RSW_RS12_RKNSA_12placeholders4__phILi1EEERKNS1G_ILi2EEEEEENS1_26is_continuation_if_runningEEEEEvRNSK_IvEERKNS3_20basic_resolver_queryIS4_EERT_
void __fastcall boost::asio::detail::resolver_service<boost::asio::ip::tcp>::async_resolve<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::detail::resolver_service<boost::asio::ip::tcp> *this,
        implementation_type *impl,
        const boost::asio::detail::resolver_service<boost::asio::ip::tcp>::query_type *query,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  unsigned __int64 v7; // rax
  void **v8; // rax
  void *v9; // rdi
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> *v10; // r9
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *v11; // r14
  volatile signed __int64 *cntrl; // rax
  std::shared_ptr<void>::element_type *ptr; // [rsp+0h] [rbp-38h] BYREF
  std::__shared_weak_count *v14; // [rsp+8h] [rbp-30h]

  v7 = __readfsqword(0xFFFFFFD8);
  if ( v7 )
  {
    v8 = *(void ***)(v7 + 8);
    if ( v8 )
    {
      v9 = *v8;
      if ( *v8 )
      {
        *v8 = 0;
        operator delete(v9);
      }
    }
  }
  v11 = (boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > >,std::function<void (const std::error_code &)>,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config> *,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> > &,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > > &,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &,const std::placeholders::__ph<2> &>,boost::asio::detail::is_continuation_if_running> > *)operator new(0x131u);
  *((_BYTE *)v11 + 304) = 0;
  ptr = impl->__ptr_;
  cntrl = (volatile signed __int64 *)impl->__cntrl_;
  v14 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 2, 1u);
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>::*)(std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>,std::function<void ()(std::error_code const&)>,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>),websocketpp::transport::asio::endpoint<websocketpp::config::asio_client::transport_config>*,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>&,std::shared_ptr<boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>>&,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&,std::placeholders::__ph<2> const&>,boost::asio::detail::is_continuation_if_running>>::resolve_op(
    v11,
    (boost::asio::detail::socket_ops::weak_cancel_token_type)__PAIR128__((unsigned __int64)query, &ptr),
    this->io_service_impl_,
    (boost::asio::detail::io_service_impl_0 *)handler,
    v10);
  if ( v14 )
    std::__shared_weak_count::__release_weak(v14);
  boost::asio::detail::resolver_service_base::start_work_thread(this);
  _InterlockedAdd64(&this->io_service_impl_->outstanding_work_.__a_, 1u);
  boost::asio::detail::task_io_service::post_immediate_completion(
    this->work_io_service_impl_,
    (boost::asio::detail::task_io_service::operation *)v11,
    0);
}


// Address: 0x269f8f0 | Name: _ZN5boost4asio6detail16resolver_serviceINS0_2ip3tcpEE13async_resolveINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS7_5list3INS7_5valueINSt3__110shared_ptrISG_EEEEPFNS_3argILi1EEEvEPFNSU_ILi2EEEvEEEEEEEvRNSR_IvEERKNS3_20basic_resolver_queryIS4_EERT_
void __fastcall boost::asio::detail::resolver_service<boost::asio::ip::tcp>::async_resolve<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>(
        boost::asio::detail::resolver_service<boost::asio::ip::tcp> *this,
        implementation_type *impl,
        const boost::asio::detail::resolver_service<boost::asio::ip::tcp>::query_type *query,
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *handler)
{
  boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *v4; // r9
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // r14
  char v10; // al
  volatile signed __int64 *cntrl; // rax
  std::shared_ptr<void>::element_type *ptr; // [rsp+0h] [rbp-38h] BYREF
  std::__shared_weak_count *v13; // [rsp+8h] [rbp-30h]

  v7 = __readfsqword(0xFFFFFFD8);
  if ( v7 )
  {
    v8 = *(char ***)(v7 + 8);
    if ( v8 )
    {
      v9 = *v8;
      if ( *v8 )
      {
        *v8 = 0;
        v10 = *v9;
        if ( (unsigned __int8)*v9 > 0xC7u )
          goto LABEL_7;
        operator delete(v9);
      }
    }
  }
  v9 = (char *)operator new(0xC9u);
  v10 = -56;
LABEL_7:
  v9[200] = v10;
  ptr = impl->__ptr_;
  cntrl = (volatile signed __int64 *)impl->__cntrl_;
  v13 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 2, 1u);
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::resolve_op(
    (boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > > *)v9,
    (boost::asio::detail::socket_ops::weak_cancel_token_type)__PAIR128__((unsigned __int64)query, &ptr),
    this->io_service_impl_,
    (boost::asio::detail::io_service_impl_0 *)handler,
    v4);
  if ( v13 )
    std::__shared_weak_count::__release_weak(v13);
  boost::asio::detail::resolver_service_base::start_work_thread(this);
  _InterlockedAdd64(&this->io_service_impl_->outstanding_work_.__a_, 1u);
  boost::asio::detail::task_io_service::post_immediate_completion(
    this->work_io_service_impl_,
    (boost::asio::detail::task_io_service::operation *)v9,
    0);
}


// Address: 0x26bad20 | Name: _ZN5boost4asio6detail16resolver_serviceINS0_2ip3tcpEE13async_resolveINS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS3_23basic_resolver_iteratorIS4_EEEENS7_5list3INS7_5valueINSt3__110shared_ptrISF_EEEEPFNS_3argILi1EEEvEPFNST_ILi2EEEvEEEEEEEvRNSQ_IvEERKNS3_20basic_resolver_queryIS4_EERT_
void __fastcall boost::asio::detail::resolver_service<boost::asio::ip::tcp>::async_resolve<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>(
        boost::asio::detail::resolver_service<boost::asio::ip::tcp> *this,
        implementation_type *impl,
        const boost::asio::detail::resolver_service<boost::asio::ip::tcp>::query_type *query,
        boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *handler)
{
  boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > *v4; // r9
  unsigned __int64 v7; // rax
  char **v8; // rax
  char *v9; // r14
  char v10; // al
  volatile signed __int64 *cntrl; // rax
  std::shared_ptr<void>::element_type *ptr; // [rsp+0h] [rbp-38h] BYREF
  std::__shared_weak_count *v13; // [rsp+8h] [rbp-30h]

  v7 = __readfsqword(0xFFFFFFD8);
  if ( v7 )
  {
    v8 = *(char ***)(v7 + 8);
    if ( v8 )
    {
      v9 = *v8;
      if ( *v8 )
      {
        *v8 = 0;
        v10 = *v9;
        if ( (unsigned __int8)*v9 > 0xC7u )
          goto LABEL_7;
        operator delete(v9);
      }
    }
  }
  v9 = (char *)operator new(0xC9u);
  v10 = -56;
LABEL_7:
  v9[200] = v10;
  ptr = impl->__ptr_;
  cntrl = (volatile signed __int64 *)impl->__cntrl_;
  v13 = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 2, 1u);
  boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::arg<2> (*)(void)>>>::resolve_op(
    (boost::asio::detail::resolve_op<boost::asio::ip::tcp,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::arg<2> (*)()> > > *)v9,
    (boost::asio::detail::socket_ops::weak_cancel_token_type)__PAIR128__((unsigned __int64)query, &ptr),
    this->io_service_impl_,
    (boost::asio::detail::io_service_impl_0 *)handler,
    v4);
  if ( v13 )
    std::__shared_weak_count::__release_weak(v13);
  boost::asio::detail::resolver_service_base::start_work_thread(this);
  _InterlockedAdd64(&this->io_service_impl_->outstanding_work_.__a_, 1u);
  boost::asio::detail::task_io_service::post_immediate_completion(
    this->work_io_service_impl_,
    (boost::asio::detail::task_io_service::operation *)v9,
    0);
}


