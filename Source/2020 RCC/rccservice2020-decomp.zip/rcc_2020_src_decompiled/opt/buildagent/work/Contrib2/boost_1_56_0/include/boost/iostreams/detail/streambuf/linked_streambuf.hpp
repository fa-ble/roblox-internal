// Address: 0x2029b20 | Name: _ZN5boost9iostreams6detail16linked_streambufIcNSt3__111char_traitsIcEEE8set_nextEPS6_
void __fastcall boost::iostreams::detail::linked_streambuf<char,std::char_traits<char>>::set_next(
        boost::iostreams::detail::linked_streambuf<char,std::char_traits<char> > *this,
        boost::iostreams::detail::linked_streambuf<char,std::char_traits<char> > *a2)
{
  ;
}


