// Address: 0x25f7ad0 | Name: _ZN5boost4asio6detail16service_registry14do_use_serviceERKNS0_10io_service7service3keyEPFPS4_RS3_E
boost::asio::io_service::service *__fastcall boost::asio::detail::service_registry::do_use_service(
        boost::asio::detail::service_registry *this,
        const boost::asio::io_service::service::key_0 *key,
        boost::asio::detail::service_registry::factory_type factory)
{
  boost::asio::detail::mutex *p_mutex; // r14
  boost::asio::io_service::service *first_service; // rbp
  const std::type_info *type_info; // rax
  const boost::asio::io_service::id *id; // rcx
  const boost::asio::io_service::id *v8; // rdx
  const std::type_info *v9; // rdx
  boost::asio::io_service::service *v10; // rax
  const std::type_info *v11; // rcx
  const boost::asio::io_service::id *v12; // rdx
  boost::asio::io_service::service *v13; // rbx
  const boost::asio::io_service::id *v14; // rsi
  const std::type_info *v15; // rsi

  p_mutex = &this->mutex_;
  pthread_mutex_lock(&this->mutex_.mutex_);
  first_service = this->first_service_;
  if ( first_service )
  {
    type_info = key->type_info_;
    id = key->id_;
    while ( 1 )
    {
      v8 = first_service->key_.id_;
      if ( v8 )
      {
        if ( id && v8 == id )
          break;
      }
      v9 = first_service->key_.type_info_;
      if ( v9 )
      {
        if ( type_info && *((_QWORD *)v9 + 1) == *((_QWORD *)type_info + 1) )
          break;
      }
      first_service = first_service->next_;
      if ( !first_service )
        goto LABEL_10;
    }
  }
  else
  {
LABEL_10:
    pthread_mutex_unlock(&p_mutex->mutex_);
    first_service = factory(this->owner_);
    first_service->key_ = *key;
    pthread_mutex_lock(&p_mutex->mutex_);
    v10 = this->first_service_;
    if ( v10 )
    {
      v11 = key->type_info_;
      v12 = key->id_;
      v13 = this->first_service_;
      while ( 1 )
      {
        v14 = v13->key_.id_;
        if ( v14 )
        {
          if ( v12 && v14 == v12 )
            break;
        }
        v15 = v13->key_.type_info_;
        if ( v15 )
        {
          if ( v11 )
          {
            v14 = (const boost::asio::io_service::id *)*((_QWORD *)v15 + 1);
            if ( v14 == *((const boost::asio::io_service::id **)v11 + 1) )
              break;
          }
        }
        v13 = v13->next_;
        if ( !v13 )
          goto LABEL_19;
      }
      if ( first_service )
        (*((void (__fastcall **)(boost::asio::io_service::service *, const boost::asio::io_service::id *, const boost::asio::io_service::id *, const std::type_info *))first_service->_vptr$service
         + 1))(
          first_service,
          v14,
          v12,
          v11);
      first_service = v13;
    }
    else
    {
LABEL_19:
      first_service->next_ = v10;
      this->first_service_ = first_service;
    }
  }
  pthread_mutex_unlock(&p_mutex->mutex_);
  return first_service;
}


