// Address: 0x25f7c00 | Name: _ZN5boost4asio23socket_acceptor_serviceINS0_2ip3tcpEED0Ev
// Alternative name is 'j__ZdlPv_1978'
// attributes: thunk
void __fastcall boost::asio::socket_acceptor_service<boost::asio::ip::tcp>::~socket_acceptor_service(
        boost::asio::socket_acceptor_service<boost::asio::ip::tcp> *this)
{
  operator delete(this);
}


// Address: 0x25f7c10 | Name: _ZN5boost4asio23socket_acceptor_serviceINS0_2ip3tcpEE16shutdown_serviceEv
void __fastcall boost::asio::socket_acceptor_service<boost::asio::ip::tcp>::shutdown_service(
        boost::asio::socket_acceptor_service<boost::asio::ip::tcp> *this)
{
  ;
}


