// Address: 0x1edd180 | Name: _ZN5boost11object_poolI6dtLinkNS_33default_user_allocator_new_deleteEED2Ev
void __fastcall boost::object_pool<dtLink,boost::default_user_allocator_new_delete>::~object_pool(
        boost::object_pool<dtLink,boost::default_user_allocator_new_delete> *this)
{
  char *ptr; // rdi
  boost::pool<boost::default_user_allocator_new_delete>::size_type requested_size; // rcx
  boost::details::PODptr<unsigned long>::size_type sz; // rax
  __int64 v5; // rbx
  boost::pool<boost::default_user_allocator_new_delete>::size_type v6; // rbx
  char *v7; // r15
  boost::details::PODptr<unsigned long>::size_type v8; // r12
  boost::details::PODptr<unsigned long>::size_type v9; // rax

  ptr = this->list.ptr;
  if ( ptr )
  {
    requested_size = this->requested_size;
    if ( requested_size <= 8 )
      requested_size = 8;
    sz = this->list.sz;
    v5 = 8 - (requested_size & 7);
    if ( (requested_size & 7) == 0 )
      v5 = requested_size & 7;
    v6 = requested_size + v5;
    do
    {
      v7 = *(char **)&ptr[sz - 16];
      v8 = *(_QWORD *)&ptr[sz - 8];
      if ( ptr == &ptr[sz - 16] )
        goto LABEL_11;
      v9 = sz - 16;
      do
        v9 -= v6;
      while ( v9 );
      if ( ptr )
LABEL_11:
        operator delete[](ptr);
      sz = v8;
      ptr = v7;
    }
    while ( v7 );
    this->list.ptr = 0;
  }
}


// Address: 0x1edd210 | Name: _ZN5boost11object_poolI10dtMeshTile19dtMeshTileAllocatorED2Ev
void __fastcall boost::object_pool<dtMeshTile,dtMeshTileAllocator>::~object_pool(
        boost::object_pool<dtMeshTile,dtMeshTileAllocator> *this)
{
  char *ptr; // rbx
  boost::pool<dtMeshTileAllocator>::size_type requested_size; // rax
  char *first; // r12
  boost::details::PODptr<unsigned long>::size_type sz; // r13
  __int64 v5; // r15
  boost::pool<dtMeshTileAllocator>::size_type v6; // r15
  char *v7; // rbp
  boost::details::PODptr<unsigned long>::size_type v8; // r13
  __int64 v9; // r14
  boost::details::PODptr<unsigned long>::size_type v10; // [rsp+10h] [rbp-38h]

  ptr = this->list.ptr;
  if ( ptr )
  {
    requested_size = this->requested_size;
    if ( requested_size <= 8 )
      requested_size = 8;
    first = (char *)this->first;
    sz = this->list.sz;
    v5 = 8 - (requested_size & 7);
    if ( (requested_size & 7) == 0 )
      v5 = requested_size & 7;
    v6 = requested_size + v5;
    do
    {
      v7 = *(char **)&ptr[sz - 16];
      v10 = *(_QWORD *)&ptr[sz - 8];
      if ( ptr != &ptr[sz - 16] )
      {
        v8 = sz - 16;
        v9 = 0;
        do
        {
          if ( &ptr[v9] == first )
            first = *(char **)&ptr[v9];
          else
            dtMeshTile::~dtMeshTile((dtMeshTile_0 *)&ptr[v9]);
          v9 += v6;
        }
        while ( v8 != v9 );
      }
      dtFree(ptr);
      sz = v10;
      ptr = v7;
    }
    while ( v7 );
    this->list.ptr = 0;
  }
}


// Address: 0x1eeca00 | Name: _ZN5boost11object_poolI6dtNodeNS_33default_user_allocator_new_deleteEE9constructEv
boost::object_pool<dtNode,boost::default_user_allocator_new_delete>::element_type *__fastcall boost::object_pool<dtNode,boost::default_user_allocator_new_delete>::construct(
        boost::object_pool<dtNode,boost::default_user_allocator_new_delete> *this)
{
  boost::object_pool<dtNode,boost::default_user_allocator_new_delete>::element_type *first; // r14

  first = (boost::object_pool<dtNode,boost::default_user_allocator_new_delete>::element_type *)this->first;
  if ( this->first )
  {
    this->first = first->parent;
LABEL_4:
    *(dtTilePolyRef *)((char *)&first->id + 8) = 0;
    *(_OWORD *)&first->total = 0;
    *(_OWORD *)first->pos = 0;
    *(_OWORD *)&first->parent = 0;
    dtTilePolyRef::dtTilePolyRef(&first->id);
    return first;
  }
  first = (boost::object_pool<dtNode,boost::default_user_allocator_new_delete>::element_type *)boost::pool<boost::default_user_allocator_new_delete>::ordered_malloc_need_resize(this);
  if ( first )
    goto LABEL_4;
  return first;
}


