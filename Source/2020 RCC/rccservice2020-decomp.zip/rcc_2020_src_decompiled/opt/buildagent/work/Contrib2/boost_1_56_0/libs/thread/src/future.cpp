// Address: 0x28425d0 | Name: _ZNK5boost13thread_detail21future_error_category4nameEv
const char *__fastcall boost::thread_detail::future_error_category::name(
        const boost::thread_detail::future_error_category *this)
{
  return "future";
}


// Address: 0x28425e0 | Name: _ZNK5boost13thread_detail21future_error_category7messageEi
boost::thread_detail::future_error_category *__fastcall boost::thread_detail::future_error_category::message(
        boost::thread_detail::future_error_category *this,
        int a2,
        int a3)
{
  char *v3; // rax
  _BYTE *v4; // rax
  char *v5; // rax
  char *v6; // rax
  char *v7; // rax
  char *v8; // rax

  switch ( a3 )
  {
    case 1:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v3 = (char *)operator new(0x60u);
      *((_QWORD *)this + 2) = v3;
      *(_OWORD *)&this->_vptr$error_category = *(_OWORD *)&xmmword_3E67A0;
      qmemcpy(v3, "The associated promise has been destructed prior to the associated state becoming ready.", 88);
      v4 = v3 + 88;
      break;
    case 2:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v6 = (char *)operator new(0x50u);
      *((_QWORD *)this + 2) = v6;
      *(_OWORD *)&this->_vptr$error_category = xmmword_3E82A0;
      qmemcpy(v6, "The future has already been retrieved from the promise or packaged_task.", 72);
      v4 = v6 + 72;
      break;
    case 3:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v7 = (char *)operator new(0x30u);
      *((_QWORD *)this + 2) = v7;
      *(_OWORD *)&this->_vptr$error_category = xmmword_3E4D30;
      qmemcpy(v7, "The state of the promise has already been set.", 46);
      v4 = v7 + 46;
      break;
    case 4:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v8 = (char *)operator new(0x50u);
      *((_QWORD *)this + 2) = v8;
      *(_OWORD *)&this->_vptr$error_category = xmmword_3EA4A0;
      qmemcpy(v8, "Operation not permitted on an object without an associated state.", 65);
      v4 = v8 + 65;
      break;
    default:
      *(_OWORD *)&this->_vptr$error_category = 0;
      *((_QWORD *)this + 2) = 0;
      v5 = (char *)operator new(0x20u);
      *((_QWORD *)this + 2) = v5;
      *(_OWORD *)&this->_vptr$error_category = *(_OWORD *)&stru_3E8880.vtable;
      qmemcpy(v5, "unspecified future_errc value\n", 30);
      v4 = v5 + 30;
      break;
  }
  *v4 = 0;
  return this;
}


// Address: 0x28427d0 | Name: _ZN5boost15future_categoryEv
const boost::system::error_category *__cdecl boost::future_category()
{
  return (const boost::system::error_category *)&off_2870F38;
}


// Address: 0x28427e0 | Name: _ZN5boost13thread_detail21future_error_categoryD0Ev
// Alternative name is 'j__ZdlPv_2072'
// attributes: thunk
void __fastcall boost::thread_detail::future_error_category::~future_error_category(
        boost::thread_detail::future_error_category *this)
{
  operator delete(this);
}


// Address: 0x28427f0 | Name: _GLOBAL__sub_I_future.cpp
void __cdecl GLOBAL__sub_I_future_cpp()
{
  qword_2CE5658 = (__int64)boost::system::generic_category();
  qword_2CE5660 = (__int64)boost::system::generic_category();
  qword_2CE5668 = (__int64)boost::system::system_category();
}


