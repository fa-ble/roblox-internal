// Address: 0x261e420 | Name: _ZN5boost4asio6detail21resolver_service_baseC2ERNS0_10io_serviceE
void __fastcall boost::asio::detail::resolver_service_base::resolver_service_base(
        boost::asio::detail::resolver_service_base *this,
        boost::asio::io_service *io_service)
{
  int v2; // ebx
  const boost::system::error_category *v3; // rax
  boost::asio::io_service *v4; // r12
  boost::asio::detail::service_registry *v5; // rbp
  boost::asio::detail::io_service_impl *first_service; // r13
  boost::asio::io_service::work *v7; // rax
  const boost::system::error_category *v8; // r12
  _QWORD v9[2]; // [rsp+0h] [rbp-68h] BYREF
  int v10; // [rsp+10h] [rbp-58h]
  const boost::system::error_category *v11; // [rsp+18h] [rbp-50h]
  __int128 v12; // [rsp+20h] [rbp-48h]
  void *ptr; // [rsp+30h] [rbp-38h]

  this->io_service_impl_ = io_service->impl_;
  v2 = pthread_mutex_init(&this->mutex_.mutex_, 0);
  v3 = boost::system::system_category();
  if ( v2 )
  {
    v8 = v3;
    std::runtime_error::runtime_error((std::runtime_error *)v9, "mutex");
    v9[0] = off_2875F00;
    v10 = v2;
    v11 = v8;
    v12 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v9);
  }
  v4 = (boost::asio::io_service *)operator new(0x10u);
  v5 = (boost::asio::detail::service_registry *)operator new(0x40u);
  boost::asio::detail::service_registry::service_registry<boost::asio::detail::task_io_service,unsigned long>(
    v5,
    v4,
    0,
    0xFFFFFFFFFFFFFFFFLL);
  v4->service_registry_ = v5;
  first_service = (boost::asio::detail::io_service_impl *)v5->first_service_;
  v4->impl_ = first_service;
  this->work_io_service_.p_ = v4;
  this->work_io_service_impl_ = first_service;
  v7 = (boost::asio::io_service::work *)operator new(8u);
  v7->io_service_impl_ = first_service;
  _InterlockedAdd64(&first_service->outstanding_work_.__a_, 1u);
  this->work_.p_ = v7;
  this->work_thread_.p_ = 0;
}


// Address: 0x261e610 | Name: _ZN5boost4asio6detail21resolver_service_baseD2Ev
void __fastcall boost::asio::detail::resolver_service_base::~resolver_service_base(
        boost::asio::detail::resolver_service_base *this)
{
  boost::asio::detail::posix_thread *p; // rbx
  boost::asio::io_service::work *v3; // r12
  boost::asio::detail::io_service_impl *io_service_impl; // rbx
  boost::asio::detail::reactor *task; // rax
  boost::asio::io_service *v6; // r14
  boost::asio::detail::service_registry *service_registry; // r12
  boost::asio::io_service::service *first_service; // rbx
  boost::asio::io_service::service *v9; // rdi
  boost::asio::io_service::service *next; // rbx
  struct epoll_event event; // [rsp+8h] [rbp-30h] BYREF

  boost::asio::detail::resolver_service_base::shutdown_service(this);
  p = this->work_thread_.p_;
  if ( p )
  {
    if ( !p->joined_ )
      pthread_detach(p->thread_);
    operator delete(p);
  }
  v3 = this->work_.p_;
  if ( v3 )
  {
    io_service_impl = v3->io_service_impl_;
    if ( !_InterlockedSub64(&v3->io_service_impl_->outstanding_work_.__a_, 1u) )
    {
      pthread_mutex_lock(&io_service_impl->mutex_.mutex_);
      io_service_impl->stopped_ = 1;
      LOBYTE(io_service_impl->wakeup_event_.state_) |= 1u;
      pthread_cond_broadcast(&io_service_impl->wakeup_event_.cond_);
      if ( !io_service_impl->task_interrupted_ )
      {
        task = io_service_impl->task_;
        if ( task )
        {
          io_service_impl->task_interrupted_ = 1;
          event.events = -2147483639;
          event.data.u64 = (uint64_t)&task->interrupter_;
          epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, &event);
        }
      }
      pthread_mutex_unlock(&io_service_impl->mutex_.mutex_);
    }
    operator delete(v3);
  }
  v6 = this->work_io_service_.p_;
  if ( v6 )
  {
    service_registry = v6->service_registry_;
    if ( v6->service_registry_ )
    {
      first_service = service_registry->first_service_;
      if ( first_service )
      {
        do
        {
          (*((void (__fastcall **)(boost::asio::io_service::service *))first_service->_vptr$service + 2))(first_service);
          first_service = first_service->next_;
        }
        while ( first_service );
        v9 = service_registry->first_service_;
        if ( v9 )
        {
          do
          {
            next = v9->next_;
            (*((void (__fastcall **)(boost::asio::io_service::service *))v9->_vptr$service + 1))(v9);
            service_registry->first_service_ = next;
            v9 = next;
          }
          while ( next );
        }
      }
      pthread_mutex_destroy(&service_registry->mutex_.mutex_);
      operator delete(service_registry);
    }
    operator delete(v6);
  }
  pthread_mutex_destroy(&this->mutex_.mutex_);
}


// Address: 0x261e7b0 | Name: _ZN5boost4asio6detail21resolver_service_base16shutdown_serviceEv
void __fastcall boost::asio::detail::resolver_service_base::shutdown_service(
        boost::asio::detail::resolver_service_base *this)
{
  boost::asio::io_service::work *p; // r12
  boost::asio::detail::io_service_impl *io_service_impl; // rbx
  boost::asio::detail::reactor *task; // rax
  boost::asio::io_service *v5; // rax
  boost::asio::io_service::impl_type *impl; // rbx
  boost::asio::detail::reactor *v7; // rax
  boost::asio::detail::posix_thread *v8; // rbx
  boost::asio::io_service *v9; // r14
  boost::asio::detail::service_registry *service_registry; // r12
  boost::asio::io_service::service *first_service; // rbx
  boost::asio::io_service::service *v12; // rdi
  boost::asio::io_service::service *next; // rbx
  struct epoll_event event; // [rsp+8h] [rbp-30h] BYREF

  p = this->work_.p_;
  if ( p )
  {
    io_service_impl = p->io_service_impl_;
    if ( !_InterlockedSub64(&p->io_service_impl_->outstanding_work_.__a_, 1u) )
    {
      pthread_mutex_lock(&io_service_impl->mutex_.mutex_);
      io_service_impl->stopped_ = 1;
      LOBYTE(io_service_impl->wakeup_event_.state_) |= 1u;
      pthread_cond_broadcast(&io_service_impl->wakeup_event_.cond_);
      if ( !io_service_impl->task_interrupted_ )
      {
        task = io_service_impl->task_;
        if ( task )
        {
          io_service_impl->task_interrupted_ = 1;
          event.events = -2147483639;
          event.data.u64 = (uint64_t)&task->interrupter_;
          epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, &event);
        }
      }
      pthread_mutex_unlock(&io_service_impl->mutex_.mutex_);
    }
    operator delete(p);
  }
  this->work_.p_ = 0;
  v5 = this->work_io_service_.p_;
  if ( v5 )
  {
    impl = v5->impl_;
    pthread_mutex_lock(&impl->mutex_.mutex_);
    impl->stopped_ = 1;
    LOBYTE(impl->wakeup_event_.state_) |= 1u;
    pthread_cond_broadcast(&impl->wakeup_event_.cond_);
    if ( !impl->task_interrupted_ )
    {
      v7 = impl->task_;
      if ( v7 )
      {
        impl->task_interrupted_ = 1;
        event.events = -2147483639;
        event.data.u64 = (uint64_t)&v7->interrupter_;
        epoll_ctl(v7->epoll_fd_, 3, v7->interrupter_.read_descriptor_, &event);
      }
    }
    pthread_mutex_unlock(&impl->mutex_.mutex_);
    v8 = this->work_thread_.p_;
    if ( v8 )
    {
      if ( v8->joined_ || (pthread_join(v8->thread_, 0), v8->joined_ = 1, (v8 = this->work_thread_.p_) != 0) )
      {
        if ( !v8->joined_ )
          pthread_detach(v8->thread_);
        operator delete(v8);
      }
      this->work_thread_.p_ = 0;
    }
    v9 = this->work_io_service_.p_;
    if ( v9 )
    {
      service_registry = v9->service_registry_;
      if ( v9->service_registry_ )
      {
        first_service = service_registry->first_service_;
        if ( first_service )
        {
          do
          {
            (*((void (__fastcall **)(boost::asio::io_service::service *))first_service->_vptr$service + 2))(first_service);
            first_service = first_service->next_;
          }
          while ( first_service );
          v12 = service_registry->first_service_;
          if ( v12 )
          {
            do
            {
              next = v12->next_;
              (*((void (__fastcall **)(boost::asio::io_service::service *))v12->_vptr$service + 1))(v12);
              service_registry->first_service_ = next;
              v12 = next;
            }
            while ( next );
          }
        }
        pthread_mutex_destroy(&service_registry->mutex_.mutex_);
        operator delete(service_registry);
      }
      operator delete(v9);
    }
    this->work_io_service_.p_ = 0;
  }
}


// Address: 0x261e9f0 | Name: _ZN5boost4asio6detail21resolver_service_base12fork_serviceENS0_10io_service10fork_eventE
void __fastcall boost::asio::detail::resolver_service_base::fork_service(
        boost::asio::detail::resolver_service_base *this,
        boost::asio::io_service::fork_event fork_ev)
{
  boost::asio::io_service::impl_type *impl; // rbx
  boost::asio::detail::posix_thread *v3; // r14
  boost::asio::io_service *p; // rbx
  _QWORD *v5; // rbp
  int v6; // eax
  boost::asio::detail::posix_thread *v7; // rbp
  boost::asio::detail::reactor *task; // rax
  boost::asio::detail::posix_thread *v9; // rbx
  int v10; // r15d
  const boost::system::error_category *v11; // rbx
  struct epoll_event event; // [rsp+8h] [rbp-60h] BYREF
  int v13; // [rsp+18h] [rbp-50h]
  const boost::system::error_category *v14; // [rsp+20h] [rbp-48h]
  __int128 v15; // [rsp+28h] [rbp-40h]
  void *ptr; // [rsp+38h] [rbp-30h]

  if ( this->work_thread_.p_ )
  {
    impl = this->work_io_service_.p_->impl_;
    pthread_mutex_lock(&impl->mutex_.mutex_);
    if ( fork_ev )
    {
      impl->stopped_ = 0;
      pthread_mutex_unlock(&impl->mutex_.mutex_);
      v3 = (boost::asio::detail::posix_thread *)operator new(0x10u);
      p = this->work_io_service_.p_;
      v3->joined_ = 0;
      v5 = operator new(0x10u);
      *v5 = &off_29C3D48;
      v5[1] = p;
      v6 = pthread_create(&v3->thread_, 0, boost::asio::detail::boost_asio_detail_posix_thread_function, v5);
      if ( v6 )
      {
        v10 = v6;
        (*(void (__fastcall **)(_QWORD *))(*v5 + 8LL))(v5);
        v11 = boost::system::system_category();
        std::runtime_error::runtime_error((std::runtime_error *)&event, "thread");
        *(_QWORD *)&event.events = off_2875F00;
        v13 = v10;
        v14 = v11;
        v15 = 0;
        ptr = 0;
        boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)&event);
      }
      v7 = this->work_thread_.p_;
      if ( v7 )
      {
        if ( !v7->joined_ )
          pthread_detach(v7->thread_);
        operator delete(v7);
      }
      this->work_thread_.p_ = v3;
    }
    else
    {
      impl->stopped_ = 1;
      LOBYTE(impl->wakeup_event_.state_) |= 1u;
      pthread_cond_broadcast(&impl->wakeup_event_.cond_);
      if ( !impl->task_interrupted_ )
      {
        task = impl->task_;
        if ( task )
        {
          impl->task_interrupted_ = 1;
          event.events = -2147483639;
          event.data.u64 = (uint64_t)&task->interrupter_;
          epoll_ctl(task->epoll_fd_, 3, task->interrupter_.read_descriptor_, &event);
        }
      }
      pthread_mutex_unlock(&impl->mutex_.mutex_);
      v9 = this->work_thread_.p_;
      if ( !v9->joined_ )
      {
        pthread_join(v9->thread_, 0);
        v9->joined_ = 1;
      }
    }
  }
}


// Address: 0x261ec40 | Name: _ZN5boost4asio6detail21resolver_service_base22work_io_service_runnerclEv
void __fastcall boost::asio::detail::resolver_service_base::work_io_service_runner::operator()(
        boost::asio::detail::resolver_service_base::work_io_service_runner *this)
{
  boost::asio::io_service *io_service; // rbx
  int m_val; // ebp
  const boost::system::error_category *m_cat; // rbx
  boost::system::error_code v4; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v5[2]; // [rsp+10h] [rbp-58h] BYREF
  int v6; // [rsp+20h] [rbp-48h]
  const boost::system::error_category *v7; // [rsp+28h] [rbp-40h]
  __int128 v8; // [rsp+30h] [rbp-38h]
  void *ptr; // [rsp+40h] [rbp-28h]

  io_service = this->io_service_;
  v4.m_val = 0;
  v4.m_cat = boost::system::system_category();
  boost::asio::detail::task_io_service::run(io_service->impl_, &v4);
  m_val = v4.m_val;
  if ( v4.m_val )
  {
    m_cat = v4.m_cat;
    std::runtime_error::runtime_error((std::runtime_error *)v5, (const char *)&uri_string);
    v5[0] = off_2875F00;
    v6 = m_val;
    v7 = m_cat;
    v8 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v5);
  }
}


// Address: 0x2622d00 | Name: _ZN5boost4asio6detail21resolver_service_base17start_work_threadEv
void __fastcall boost::asio::detail::resolver_service_base::start_work_thread(
        boost::asio::detail::resolver_service_base *this)
{
  boost::asio::detail::posix_thread *v1; // r14
  boost::asio::io_service *p; // r12
  _QWORD *v3; // rbp
  int v4; // eax
  boost::asio::detail::posix_thread *v5; // rbp
  int v6; // r12d
  const boost::system::error_category *v7; // rbx
  _QWORD v8[2]; // [rsp+8h] [rbp-60h] BYREF
  int v9; // [rsp+18h] [rbp-50h]
  const boost::system::error_category *v10; // [rsp+20h] [rbp-48h]
  __int128 v11; // [rsp+28h] [rbp-40h]
  void *ptr; // [rsp+38h] [rbp-30h]

  pthread_mutex_lock(&this->mutex_.mutex_);
  if ( !this->work_thread_.p_ )
  {
    v1 = (boost::asio::detail::posix_thread *)operator new(0x10u);
    p = this->work_io_service_.p_;
    v1->joined_ = 0;
    v3 = operator new(0x10u);
    *v3 = &off_29C3D48;
    v3[1] = p;
    v4 = pthread_create(&v1->thread_, 0, boost::asio::detail::boost_asio_detail_posix_thread_function, v3);
    if ( v4 )
    {
      v6 = v4;
      (*(void (__fastcall **)(_QWORD *))(*v3 + 8LL))(v3);
      v7 = boost::system::system_category();
      std::runtime_error::runtime_error((std::runtime_error *)v8, "thread");
      v8[0] = off_2875F00;
      v9 = v6;
      v10 = v7;
      v11 = 0;
      ptr = 0;
      boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v8);
    }
    v5 = this->work_thread_.p_;
    if ( v5 )
    {
      if ( !v5->joined_ )
        pthread_detach(v5->thread_);
      operator delete(v5);
    }
    this->work_thread_.p_ = v1;
  }
  pthread_mutex_unlock(&this->mutex_.mutex_);
}


