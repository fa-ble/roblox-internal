// Address: 0x2609990 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSG_mEE4typeEE4typeERT_RKT0_OSO_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *handler)
{
  __int128 v5; // xmm0
  int start; // eax
  boost::asio::ssl::detail::engine::want want; // ecx
  size_t bytes_transferred; // rsi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *f; // rdi
  size_t size; // rax
  char *v11; // rdi
  unsigned __int64 v12; // rax
  size_t v13; // rcx
  boost::asio::mutable_buffers_1 v14; // [rsp+0h] [rbp-158h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > v15; // [rsp+10h] [rbp-148h] BYREF
  __int128 v16; // [rsp+B0h] [rbp-A8h]
  int v17; // [rsp+C4h] [rbp-94h]
  boost::asio::ssl::detail::engine::want v18; // [rsp+C8h] [rbp-90h]
  boost::system::error_code ec; // [rsp+D0h] [rbp-88h]
  size_t v20; // [rsp+E0h] [rbp-78h]
  _BYTE v21[32]; // [rsp+F0h] [rbp-68h] BYREF
  std::function<void (const boost::system::error_code &)>::__base *v22; // [rsp+110h] [rbp-48h]
  unsigned __int64 v23; // [rsp+130h] [rbp-28h]

  v23 = __readfsqword(0x28u);
  v5 = *(_OWORD *)&handler->next_layer_;
  v16 = *(_OWORD *)&handler->next_layer_;
  start = handler->start_;
  v17 = start;
  want = handler->want_;
  v18 = want;
  ec = handler->ec_;
  bytes_transferred = handler->bytes_transferred_;
  v20 = bytes_transferred;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &)> *)f )
    {
      v22 = (std::function<void (const boost::system::error_code &)>::__base *)v21;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *, _BYTE *))f->next_layer_->service_)(
        f,
        v21);
      v5 = v16;
      start = v17;
      want = v18;
      bytes_transferred = v20;
      f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *)v22;
    }
    else
    {
      v22 = handler->handler_.__f_;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    v22 = 0;
    f = 0;
  }
  v15.stream_ = s;
  v15.buffer_ = buffers->boost::asio::mutable_buffer;
  v15.start_ = 0;
  v15.total_transferred_ = 0;
  *(_OWORD *)&v15.handler_.next_layer_ = v5;
  v15.handler_.start_ = start;
  v15.handler_.want_ = want;
  v15.handler_.ec_ = ec;
  v15.handler_.bytes_transferred_ = bytes_transferred;
  if ( f )
  {
    if ( v21 == (_BYTE *)f )
    {
      v15.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&v15.handler_.handler_;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *, std::function<void (const boost::system::error_code &)> *))f->next_layer_->service_)(
        f,
        &v15.handler_.handler_);
    }
    else
    {
      v15.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)f;
      v22 = 0;
    }
  }
  else
  {
    v15.handler_.handler_.__f_ = 0;
  }
  boost::system::system_category();
  v15.start_ = 1;
  size = v15.buffer_.size_;
  v11 = 0;
  if ( v15.buffer_.size_ >= v15.total_transferred_ )
    v11 = (char *)v15.buffer_.data_ + v15.total_transferred_;
  else
    size = v15.total_transferred_;
  v12 = size - v15.total_transferred_;
  v13 = 0x10000;
  if ( v12 < 0x10000 )
    v13 = v12;
  v14.data_ = v11;
  v14.size_ = v13;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>>(
    v15.stream_->service_,
    &v15.stream_->implementation,
    &v14,
    0,
    &v15);
  if ( &v15.handler_.handler_ == (std::function<void (const boost::system::error_code &)> *)v15.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v15.handler_.handler_.__f_->_vptr$__base
     + 4))(v15.handler_.handler_.__f_);
  }
  else if ( v15.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v15.handler_.handler_.__f_->_vptr$__base + 5))();
  }
  if ( v21 == (_BYTE *)v22 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v22->_vptr$__base + 4))(v22);
  }
  else if ( v22 )
  {
    (*((void (**)(void))v22->_vptr$__base + 5))();
  }
}


// Address: 0x26116d0 | Name: _ZN5boost4asio11async_writeINS0_3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEEEENSt3__16vectorINS0_12const_bufferENSB_9allocatorISD_EEEEN11websocketpp9transport4asio20custom_alloc_handlerINSB_8functionIFvRKNS_6system10error_codeEmEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSN_mEE4typeEE4typeERT_RKT0_OSV_
boost::asio::async_result<websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > >::type __fastcall boost::asio::async_write<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *s,
        const std::vector<boost::asio::const_buffer> *buffers,
        websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *handler)
{
  websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *f; // rdi
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *v5; // [rsp+0h] [rbp-118h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-110h] BYREF
  int v7; // [rsp+48h] [rbp-D0h]
  __int64 v8; // [rsp+50h] [rbp-C8h]
  websocketpp::transport::asio::handler_allocator *v9; // [rsp+60h] [rbp-B8h]
  _BYTE v10[32]; // [rsp+70h] [rbp-A8h] BYREF
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *v11; // [rsp+90h] [rbp-88h]
  websocketpp::transport::asio::handler_allocator *allocator; // [rsp+A0h] [rbp-78h]
  _BYTE v13[32]; // [rsp+B0h] [rbp-68h] BYREF
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *v14; // [rsp+D0h] [rbp-48h]
  unsigned __int64 v15; // [rsp+F0h] [rbp-28h]

  v15 = __readfsqword(0x28u);
  allocator = handler->allocator_;
  f = (websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v14 = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)v13;
      (*((void (__fastcall **)(websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *, _BYTE *))&f->allocator_->storage_.data_.align_
       + 3))(
        f,
        v13);
    }
    else
    {
      v14 = handler->handler_.__f_;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    v14 = 0;
  }
  v5 = s;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    buffers);
  v7 = 0;
  v8 = 0;
  v9 = allocator;
  if ( v14 )
  {
    if ( v13 == (_BYTE *)v14 )
    {
      v11 = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)v10;
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, _BYTE *))v14->_vptr$__base
       + 3))(
        v14,
        v10);
    }
    else
    {
      v11 = v14;
      v14 = 0;
    }
  }
  else
  {
    v11 = 0;
  }
  boost::system::system_category();
  v7 = 1;
  ptr[7] = &stru_FFF0 + 16;
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
    v5,
    (const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)&v5);
  if ( v10 == (_BYTE *)v11 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v11->_vptr$__base
     + 4))(v11);
  }
  else if ( v11 )
  {
    (*((void (**)(void))v11->_vptr$__base + 5))();
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  if ( v13 == (_BYTE *)v14 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v14->_vptr$__base
     + 4))(v14);
  }
  else if ( v14 )
  {
    (*((void (**)(void))v14->_vptr$__base + 5))();
  }
}


// Address: 0x2611b60 | Name: _ZN5boost4asio6detail8write_opINS0_3ssl6streamINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEEEENSt3__16vectorINS0_12const_bufferENSC_9allocatorISE_EEEENS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSC_8functionIFvRKNS_6system10error_codeEmEEEEEEclESR_mi
void __fastcall boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>::operator()(
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  _OWORD *v4; // r9
  size_t v6; // r8
  _OWORD *v7; // r10
  char v8; // cl
  size_t v9; // rax
  unsigned __int64 v10; // rcx
  size_t v11; // rdi
  _OWORD *v12; // rax
  _OWORD *v13; // rax
  __int64 v14; // rdi
  int m_val; // eax
  const boost::system::error_category *m_cat; // rcx
  __int64 v17; // rdi
  _QWORD *exception; // rax
  size_t v19; // [rsp+0h] [rbp-18h] BYREF
  int v20; // [rsp+8h] [rbp-10h] BYREF
  const boost::system::error_category *v21; // [rsp+10h] [rbp-8h]

  *((_DWORD *)this + 18) = start;
  if ( start == 1 )
  {
    *((_QWORD *)this + 8) = (unsigned __int64)(ec->m_val == 0) << 16;
LABEL_3:
    boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
      *(boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > **)this,
      (boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)this + 8),
      this);
    return;
  }
  v6 = bytes_transferred + *((_QWORD *)this + 10);
  *((_QWORD *)this + 10) = v6;
  if ( bytes_transferred )
  {
    v7 = (_OWORD *)((char *)this + 40);
    LOBYTE(v4) = *((_BYTE *)this + 32);
    v8 = (char)v4;
    v9 = bytes_transferred;
    while ( 1 )
    {
      if ( v8 )
      {
LABEL_12:
        if ( (_BYTE)v4 )
          goto LABEL_23;
        goto LABEL_13;
      }
      v10 = *((_QWORD *)this + 6);
      v11 = v9 - v10;
      if ( v9 < v10 )
        break;
      v12 = (_OWORD *)*((_QWORD *)this + 7);
      if ( v12 == *((_OWORD **)this + 2) )
      {
        *((_BYTE *)this + 32) = 1;
        LOBYTE(v4) = 1;
        v8 = 1;
      }
      else
      {
        *((_QWORD *)this + 7) = v12 + 1;
        *v7 = *v12;
        v8 = 0;
      }
      v9 = v11;
      if ( !v11 )
        goto LABEL_12;
    }
    *((_QWORD *)this + 5) += v9;
    *((_QWORD *)this + 6) = v10 - v9;
    if ( (_BYTE)v4 )
      goto LABEL_23;
  }
  else
  {
    LOBYTE(v4) = *((_BYTE *)this + 32);
    if ( (_BYTE)v4 )
      goto LABEL_23;
  }
LABEL_13:
  if ( *((_QWORD *)this + 6) )
  {
LABEL_17:
    v4 = 0;
  }
  else
  {
    v4 = (_OWORD *)((char *)this + 40);
    v13 = (_OWORD *)*((_QWORD *)this + 7);
    v14 = *((_QWORD *)this + 2) - (_QWORD)v13;
    while ( v14 )
    {
      *((_QWORD *)this + 7) = v13 + 1;
      *v4 = *v13;
      v14 -= 16;
      ++v13;
      if ( *((_QWORD *)this + 6) )
        goto LABEL_17;
    }
    *((_BYTE *)this + 32) = 1;
    LOBYTE(v4) = 1;
  }
LABEL_23:
  m_val = ec->m_val;
  *((_QWORD *)this + 8) = (unsigned __int64)(ec->m_val == 0) << 16;
  if ( bytes_transferred || m_val )
  {
    LOBYTE(v4) = (m_val != 0) | (unsigned __int8)v4;
    if ( !(_BYTE)v4 )
      goto LABEL_3;
  }
  m_cat = ec->m_cat;
  v20 = ec->m_val;
  v21 = m_cat;
  v19 = v6;
  v17 = *((_QWORD *)this + 18);
  if ( !v17 )
  {
    exception = __cxa_allocate_exception(8u);
    *exception = off_28852C8;
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::bad_function_call,
      (void (*)(void *))&std::exception::~exception);
  }
  (*(void (__fastcall **)(__int64, int *, size_t *, const boost::system::error_category *, size_t, _OWORD *))(*(_QWORD *)v17 + 48LL))(
    v17,
    &v20,
    &v19,
    m_cat,
    v6,
    v4);
}


// Address: 0x2612920 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_8write_opINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISF_NSG_9allocatorISF_EEEEEEEENSD_8write_opINS9_6streamIS7_EESK_NSD_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSG_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSX_mEE4typeEE4typeERT_RKT0_OS17_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  size_t size; // rcx
  boost::asio::mutable_buffers_1 v4; // [rsp+0h] [rbp-298h] BYREF
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl; // [rsp+10h] [rbp-288h] BYREF
  boost::asio::mutable_buffers_1 v6; // [rsp+18h] [rbp-280h]
  int v7; // [rsp+28h] [rbp-270h]
  __int64 v8; // [rsp+30h] [rbp-268h]
  _BYTE v9[16]; // [rsp+40h] [rbp-258h] BYREF
  void *v10; // [rsp+50h] [rbp-248h]
  void *v11; // [rsp+58h] [rbp-240h]
  void *ptr; // [rsp+B8h] [rbp-1E0h]
  void *v13; // [rsp+C0h] [rbp-1D8h]
  char v14; // [rsp+120h] [rbp-178h] BYREF
  char *v15; // [rsp+140h] [rbp-158h]
  _BYTE v16[16]; // [rsp+150h] [rbp-148h] BYREF
  void *v17; // [rsp+160h] [rbp-138h]
  void *v18; // [rsp+168h] [rbp-130h]
  void *v19; // [rsp+1C8h] [rbp-D0h]
  void *v20; // [rsp+1D0h] [rbp-C8h]
  char v21; // [rsp+230h] [rbp-68h] BYREF
  char *v22; // [rsp+250h] [rbp-48h]
  unsigned __int64 v23; // [rsp+278h] [rbp-20h]

  v23 = __readfsqword(0x28u);
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v16,
    handler);
  impl = &s->implementation;
  v6 = *buffers;
  v8 = 0;
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v9,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v16);
  boost::system::system_category();
  v7 = 1;
  size = 0x10000;
  if ( v6.size_ < 0x10000 )
    size = v6.size_;
  v4.data_ = (char *)v6.data_ + v8;
  v4.size_ = size;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>(
    *(boost::asio::stream_socket_service<boost::asio::ip::tcp> **)&impl[1].socket_,
    impl,
    &v4,
    0,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *)&impl);
  if ( &v14 == v15 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v15 + 32LL))(v15);
  }
  else if ( v15 )
  {
    (*(void (**)(void))(*(_QWORD *)v15 + 40LL))();
  }
  if ( ptr )
  {
    v13 = ptr;
    operator delete(ptr);
  }
  if ( v10 )
  {
    v11 = v10;
    operator delete(v10);
  }
  if ( &v21 == v22 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v22 + 32LL))(v22);
  }
  else if ( v22 )
  {
    (*(void (**)(void))(*(_QWORD *)v22 + 40LL))();
  }
  if ( v19 )
  {
    v20 = v19;
    operator delete(v19);
  }
  if ( v17 )
  {
    v18 = v17;
    operator delete(v17);
  }
}


// Address: 0x2616390 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_7read_opIS8_EENS0_6detail7read_opINS9_6streamIS7_EES8_NSE_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSQ_mEE4typeEE4typeERT_RKT0_OS10_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  __int128 v5; // xmm0
  int start; // r8d
  boost::asio::ssl::detail::engine::want want; // ecx
  __int128 v8; // xmm1
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *stream; // rsi
  int v10; // ebx
  __int128 v11; // xmm2
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *f; // rdi
  size_t size; // rax
  char *v14; // rsi
  unsigned __int64 v15; // rax
  size_t v16; // rcx
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v17; // r15
  boost::asio::stream_socket_service<boost::asio::ip::tcp> *service; // rbx
  boost::asio::mutable_buffers_1 v19; // [rsp+0h] [rbp-2C8h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > other; // [rsp+10h] [rbp-2B8h] BYREF
  __int128 v21; // [rsp+F0h] [rbp-1D8h]
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> op; // [rsp+100h] [rbp-1C8h]
  int v23; // [rsp+110h] [rbp-1B8h]
  boost::asio::ssl::detail::engine::want v24; // [rsp+114h] [rbp-1B4h]
  boost::system::error_code ec; // [rsp+118h] [rbp-1B0h]
  __int128 v26; // [rsp+128h] [rbp-1A0h]
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *v27; // [rsp+138h] [rbp-190h]
  boost::asio::mutable_buffer buffer; // [rsp+140h] [rbp-188h]
  int v29; // [rsp+150h] [rbp-178h]
  __int128 v30; // [rsp+158h] [rbp-170h]
  _BYTE v31[32]; // [rsp+170h] [rbp-158h] BYREF
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *v32; // [rsp+190h] [rbp-138h]
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > v33; // [rsp+1B0h] [rbp-118h] BYREF
  unsigned __int64 v34; // [rsp+2A0h] [rbp-28h]

  v34 = __readfsqword(0x28u);
  v5 = *(_OWORD *)&handler->next_layer_;
  v21 = *(_OWORD *)&handler->next_layer_;
  op = handler->op_;
  start = handler->start_;
  v23 = start;
  want = handler->want_;
  v24 = want;
  ec = handler->ec_;
  v8 = *(_OWORD *)&handler->bytes_transferred_;
  v26 = v8;
  stream = handler->handler_.stream_;
  v27 = stream;
  buffer = handler->handler_.buffer_;
  v10 = handler->handler_.start_;
  v29 = v10;
  v11 = *(_OWORD *)&handler->handler_.total_transferred_;
  v30 = v11;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)handler->handler_.handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v32 = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)v31;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *, _BYTE *))f->next_layer_->service_)(
        f,
        v31);
      v5 = v21;
      start = v23;
      want = v24;
      v8 = v26;
      stream = v27;
      v10 = v29;
      v11 = v30;
      f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v32;
    }
    else
    {
      v32 = handler->handler_.handler_.handler_.__f_;
      handler->handler_.handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    v32 = 0;
    f = 0;
  }
  other.stream_ = s;
  other.buffer_ = buffers->boost::asio::mutable_buffer;
  other.start_ = 0;
  other.total_transferred_ = 0;
  *(_OWORD *)&other.handler_.next_layer_ = v5;
  other.handler_.op_ = op;
  other.handler_.start_ = start;
  other.handler_.want_ = want;
  other.handler_.ec_ = ec;
  *(_OWORD *)&other.handler_.bytes_transferred_ = v8;
  other.handler_.handler_.stream_ = stream;
  other.handler_.handler_.buffer_ = buffer;
  other.handler_.handler_.start_ = v10;
  *(_OWORD *)&other.handler_.handler_.total_transferred_ = v11;
  if ( f )
  {
    if ( v31 == (_BYTE *)f )
    {
      other.handler_.handler_.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&other.handler_.handler_.handler_.handler_;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *, std::function<void (const boost::system::error_code &,unsigned long)> *))f->next_layer_->service_)(
        f,
        &other.handler_.handler_.handler_.handler_);
    }
    else
    {
      other.handler_.handler_.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)f;
      v32 = 0;
    }
  }
  else
  {
    other.handler_.handler_.handler_.handler_.__f_ = 0;
  }
  boost::system::system_category();
  other.start_ = 1;
  size = other.buffer_.size_;
  v14 = 0;
  if ( other.buffer_.size_ >= other.total_transferred_ )
    v14 = (char *)other.buffer_.data_ + other.total_transferred_;
  else
    size = other.total_transferred_;
  v15 = size - other.total_transferred_;
  v16 = 0x10000;
  if ( v15 < 0x10000 )
    v16 = v15;
  v17 = other.stream_;
  v19.data_ = v14;
  v19.size_ = v16;
  service = other.stream_->service_;
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::write_op(
    &v33,
    &other);
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>(
    &service->service_impl_,
    &v17->implementation,
    &v19,
    0,
    &v33);
  if ( &v33.handler_.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v33.handler_.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v33.handler_.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(v33.handler_.handler_.handler_.handler_.__f_);
  }
  else if ( v33.handler_.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *))v33.handler_.handler_.handler_.handler_.__f_->_vptr$__base
     + 5))(
      v33.handler_.handler_.handler_.handler_.__f_,
      v17);
  }
  if ( &other.handler_.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)other.handler_.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))other.handler_.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(other.handler_.handler_.handler_.handler_.__f_);
  }
  else if ( other.handler_.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *))other.handler_.handler_.handler_.handler_.__f_->_vptr$__base
     + 5))(
      other.handler_.handler_.handler_.handler_.__f_,
      v17);
  }
  if ( v31 == (_BYTE *)v32 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v32->_vptr$__base
     + 4))(v32);
  }
  else if ( v32 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *))v32->_vptr$__base
     + 5))(
      v32,
      v17);
  }
}


// Address: 0x2617060 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENS0_17mutable_buffers_1ENS1_14transfer_all_tENS0_3ssl6detail5io_opIS8_NSC_7read_opIS9_EENS1_7read_opINSB_6streamIS8_EES9_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEclEST_mi
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::operator()(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  unsigned __int64 v5; // rdx
  size_t size; // rdi
  size_t total_transferred; // rcx
  char *v8; // rbx
  size_t v9; // rdi
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *stream; // r14
  boost::asio::detail::reactive_socket_service_base *service; // rbx
  boost::asio::mutable_buffers_1 v12; // [rsp+0h] [rbp-128h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > handler; // [rsp+10h] [rbp-118h] BYREF
  unsigned __int64 v14; // [rsp+108h] [rbp-20h]

  v14 = __readfsqword(0x28u);
  this->start_ = start;
  if ( start == 1 )
  {
    v5 = (unsigned __int64)(ec->m_val == 0) << 16;
    size = this->buffer_.size_;
    total_transferred = this->total_transferred_;
  }
  else
  {
    total_transferred = bytes_transferred + this->total_transferred_;
    this->total_transferred_ = total_transferred;
    if ( !bytes_transferred || ec->m_val || (size = this->buffer_.size_, total_transferred == size) )
    {
      boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::operator()(
        &this->handler_,
        *ec,
        total_transferred,
        0);
      return;
    }
    v5 = 0x10000;
  }
  v8 = 0;
  if ( size >= total_transferred )
    v8 = (char *)this->buffer_.data_ + total_transferred;
  else
    size = total_transferred;
  v9 = size - total_transferred;
  if ( v9 >= v5 )
    v9 = v5;
  stream = this->stream_;
  v12.data_ = v8;
  v12.size_ = v9;
  service = (boost::asio::detail::reactive_socket_service_base *)stream->service_;
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::write_op(
    &handler,
    this);
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>(
    service + 5,
    &stream->implementation,
    &v12,
    0,
    &handler);
  if ( &handler.handler_.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)handler.handler_.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))handler.handler_.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(handler.handler_.handler_.handler_.handler_.__f_);
  }
  else if ( handler.handler_.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *))handler.handler_.handler_.handler_.handler_.__f_->_vptr$__base
     + 5))(
      handler.handler_.handler_.handler_.handler_.__f_,
      stream);
  }
}


// Address: 0x2617330 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENS0_17mutable_buffers_1ENS1_14transfer_all_tENS0_3ssl6detail5io_opIS8_NSC_7read_opIS9_EENS1_7read_opINSB_6streamIS8_EES9_NS1_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEC2EOSZ_
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>::write_op(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *this,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *other)
{
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *f; // rax

  this->stream_ = other->stream_;
  this->buffer_ = other->buffer_;
  this->start_ = other->start_;
  this->total_transferred_ = other->total_transferred_;
  this->handler_.next_layer_ = other->handler_.next_layer_;
  this->handler_.core_ = other->handler_.core_;
  this->handler_.op_ = other->handler_.op_;
  this->handler_.start_ = other->handler_.start_;
  this->handler_.want_ = other->handler_.want_;
  this->handler_.ec_ = other->handler_.ec_;
  this->handler_.bytes_transferred_ = other->handler_.bytes_transferred_;
  *(_OWORD *)&this->handler_.handler_.completion_condition_.minimum_ = *(_OWORD *)&other->handler_.handler_.completion_condition_.minimum_;
  this->handler_.handler_.buffer_ = other->handler_.handler_.buffer_;
  this->handler_.handler_.start_ = other->handler_.handler_.start_;
  *(_OWORD *)&this->handler_.handler_.total_transferred_ = *(_OWORD *)&other->handler_.handler_.total_transferred_;
  f = other->handler_.handler_.handler_.handler_.__f_;
  if ( f )
  {
    if ( &other->handler_.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      this->handler_.handler_.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&this->handler_.handler_.handler_.handler_;
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, std::function<void (const boost::system::error_code &,unsigned long)> *))other->handler_.handler_.handler_.handler_.__f_->_vptr$__base
       + 3))(
        other->handler_.handler_.handler_.handler_.__f_,
        &this->handler_.handler_.handler_.handler_);
    }
    else
    {
      this->handler_.handler_.handler_.handler_.__f_ = f;
      other->handler_.handler_.handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.handler_.handler_.__f_ = 0;
  }
}


// Address: 0x2628e90 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__16vectorINS0_12const_bufferENS8_9allocatorISA_EEEENS0_6detail15wrapped_handlerINS0_10io_service6strandENS8_6__bindIMN11websocketpp9transport4asio10connectionINSJ_6config15asio_tls_client16transport_configEEEFvNS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeEEJNS8_10shared_ptrISQ_EERSW_RKNS8_12placeholders4__phILi1EEEEEENSE_26is_continuation_if_runningEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSY_mEE4typeEE4typeERT_RKT0_OS1G_
boost::asio::async_result<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const std::vector<boost::asio::const_buffer> *buffers,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v6; // rbx
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v7; // [rsp+0h] [rbp-158h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-150h] BYREF
  int v9; // [rsp+48h] [rbp-110h]
  __int64 v10; // [rsp+50h] [rbp-108h]
  boost::asio::io_service::strand v11; // [rsp+60h] [rbp-F8h]
  __int128 v12; // [rsp+70h] [rbp-E8h]
  std::__shared_weak_count *v13[2]; // [rsp+80h] [rbp-D8h]
  _BYTE v14[32]; // [rsp+90h] [rbp-C8h] BYREF
  std::function<void (const std::error_code &)>::__base *v15; // [rsp+B0h] [rbp-A8h]
  boost::asio::io_service::strand dispatcher; // [rsp+C0h] [rbp-98h]
  __int128 v17; // [rsp+D0h] [rbp-88h]
  std::__shared_weak_count *v18[2]; // [rsp+E0h] [rbp-78h]
  _BYTE v19[32]; // [rsp+F0h] [rbp-68h] BYREF
  std::function<void (const std::error_code &)>::__base *v20; // [rsp+110h] [rbp-48h]
  unsigned __int64 v21; // [rsp+130h] [rbp-28h]

  v21 = __readfsqword(0x28u);
  dispatcher = handler->dispatcher_;
  v17 = *(_OWORD *)&handler->handler_.__f_;
  *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> *)v18 = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v20 = (std::function<void (const std::error_code &)>::__base *)v19;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v19);
    }
    else
    {
      v20 = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v20 = 0;
  }
  v7 = s;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    buffers);
  v9 = 0;
  v10 = 0;
  v11 = dispatcher;
  v12 = v17;
  *(_OWORD *)v13 = *(_OWORD *)v18;
  *(_OWORD *)v18 = 0;
  if ( v20 )
  {
    if ( v19 == (_BYTE *)v20 )
    {
      v15 = (std::function<void (const std::error_code &)>::__base *)v14;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *))v20->_vptr$__base + 3))(
        v20,
        v14);
    }
    else
    {
      v15 = v20;
      v20 = 0;
    }
  }
  else
  {
    v15 = 0;
  }
  boost::system::system_category();
  v9 = 1;
  ptr[7] = &stru_FFF0 + 16;
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
    v7,
    (const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&v7);
  if ( v14 == (_BYTE *)v15 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v15->_vptr$__base + 4))(v15);
  }
  else if ( v15 )
  {
    (*((void (**)(void))v15->_vptr$__base + 5))();
  }
  v5 = v13[1];
  if ( v13[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v13[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  if ( v19 == (_BYTE *)v20 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v20->_vptr$__base + 4))(v20);
  }
  else if ( v20 )
  {
    (*((void (**)(void))v20->_vptr$__base + 5))();
  }
  v6 = v18[1];
  if ( v18[1] )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
      std::__shared_weak_count::__release_weak(v6);
    }
  }
}


// Address: 0x2629c40 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__16vectorINS0_12const_bufferENS9_9allocatorISB_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENS9_6__bindIMN11websocketpp9transport4asio10connectionINSK_6config15asio_tls_client16transport_configEEEFvNS9_8functionIFvRKNS9_10error_codeEEEERKNS_6system10error_codeEEJNS9_10shared_ptrISR_EERSX_RKNS9_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEclES11_mi
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  _OWORD *v5; // r9
  char v6; // r8
  char v7; // di
  size_t v8; // rax
  unsigned __int64 v9; // rdi
  size_t v10; // rcx
  _OWORD *v11; // rax
  _OWORD *v12; // rax
  __int64 v13; // rdi
  int m_val; // eax

  *((_DWORD *)this + 18) = start;
  if ( start == 1 )
  {
    *((_QWORD *)this + 8) = (unsigned __int64)(ec->m_val == 0) << 16;
LABEL_3:
    boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
      *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this,
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)this + 8),
      this);
    return;
  }
  *((_QWORD *)this + 10) += bytes_transferred;
  if ( bytes_transferred )
  {
    v5 = (_OWORD *)((char *)this + 40);
    v6 = *((_BYTE *)this + 32);
    v7 = v6;
    v8 = bytes_transferred;
    while ( 1 )
    {
      if ( v7 )
      {
LABEL_12:
        if ( v6 )
          goto LABEL_23;
        goto LABEL_13;
      }
      v9 = *((_QWORD *)this + 6);
      v10 = v8 - v9;
      if ( v8 < v9 )
        break;
      v11 = (_OWORD *)*((_QWORD *)this + 7);
      if ( v11 == *((_OWORD **)this + 2) )
      {
        *((_BYTE *)this + 32) = 1;
        v6 = 1;
        v7 = 1;
      }
      else
      {
        *((_QWORD *)this + 7) = v11 + 1;
        *v5 = *v11;
        v7 = 0;
      }
      v8 = v10;
      if ( !v10 )
        goto LABEL_12;
    }
    *((_QWORD *)this + 5) += v8;
    *((_QWORD *)this + 6) = v9 - v8;
    if ( v6 )
      goto LABEL_23;
  }
  else
  {
    v6 = *((_BYTE *)this + 32);
    if ( v6 )
      goto LABEL_23;
  }
LABEL_13:
  if ( *((_QWORD *)this + 6) )
  {
LABEL_17:
    v6 = 0;
  }
  else
  {
    v12 = (_OWORD *)*((_QWORD *)this + 7);
    v13 = *((_QWORD *)this + 2) - (_QWORD)v12;
    while ( v13 )
    {
      *((_QWORD *)this + 7) = v12 + 1;
      *(_OWORD *)((char *)this + 40) = *v12;
      v13 -= 16;
      ++v12;
      if ( *((_QWORD *)this + 6) )
        goto LABEL_17;
    }
    *((_BYTE *)this + 32) = 1;
    v6 = 1;
  }
LABEL_23:
  m_val = ec->m_val;
  *((_QWORD *)this + 8) = (unsigned __int64)(ec->m_val == 0) << 16;
  if ( (bytes_transferred || m_val) && !((m_val != 0) | (unsigned __int8)v6) )
    goto LABEL_3;
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
    (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_tls_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this
  + 1,
    ec,
    (const unsigned __int64 *)this + 10);
}


// Address: 0x2632220 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_12handshake_opENS0_6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJNSH_10shared_ptrISN_EERST_RKNSH_12placeholders4__phILi1EEEEEENSD_26is_continuation_if_runningEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSV_mEE4typeEE4typeERT_RKT0_OS1E_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  __int128 v5; // xmm0
  boost::asio::ssl::stream_base::handshake_type type; // r8d
  int start; // ecx
  boost::asio::ssl::detail::engine::want want; // esi
  size_t bytes_transferred; // rbx
  __int128 v10; // xmm1
  std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> v11; // xmm2
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *f; // rdi
  size_t size; // rax
  char *v14; // rdi
  unsigned __int64 v15; // rax
  size_t v16; // rcx
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v18; // rbx
  boost::asio::mutable_buffers_1 v19; // [rsp+0h] [rbp-1B8h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > v20; // [rsp+10h] [rbp-1A8h] BYREF
  __int128 v21; // [rsp+E0h] [rbp-D8h]
  boost::asio::ssl::stream_base::handshake_type v22; // [rsp+F0h] [rbp-C8h]
  int v23; // [rsp+F4h] [rbp-C4h]
  boost::asio::ssl::detail::engine::want v24; // [rsp+F8h] [rbp-C0h]
  boost::system::error_code ec; // [rsp+100h] [rbp-B8h]
  size_t v26; // [rsp+110h] [rbp-A8h]
  boost::asio::io_service::strand dispatcher; // [rsp+120h] [rbp-98h]
  __int128 v28; // [rsp+130h] [rbp-88h]
  std::__shared_weak_count *v29[2]; // [rsp+140h] [rbp-78h]
  _BYTE v30[32]; // [rsp+150h] [rbp-68h] BYREF
  std::function<void (const std::error_code &)>::__base *v31; // [rsp+170h] [rbp-48h]
  unsigned __int64 v32; // [rsp+190h] [rbp-28h]

  v32 = __readfsqword(0x28u);
  v5 = *(_OWORD *)&handler->next_layer_;
  v21 = *(_OWORD *)&handler->next_layer_;
  type = handler->op_.type_;
  v22 = type;
  start = handler->start_;
  v23 = start;
  want = handler->want_;
  v24 = want;
  ec = handler->ec_;
  bytes_transferred = handler->bytes_transferred_;
  v26 = bytes_transferred;
  dispatcher = handler->handler_.dispatcher_;
  v10 = *(_OWORD *)&handler->handler_.handler_.__f_;
  v28 = v10;
  v11 = handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)v29 = v11;
  handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)handler->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v31 = (std::function<void (const std::error_code &)>::__base *)v30;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, _BYTE *))f->next_layer_->service_)(
        f,
        v30);
      v5 = v21;
      type = v22;
      start = v23;
      want = v24;
      bytes_transferred = v26;
      v10 = v28;
      v11 = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)v29;
      f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)v31;
    }
    else
    {
      v31 = handler->handler_.handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v31 = 0;
    f = 0;
  }
  v20.stream_ = s;
  v20.buffer_ = buffers->boost::asio::mutable_buffer;
  v20.start_ = 0;
  v20.total_transferred_ = 0;
  *(_OWORD *)&v20.handler_.next_layer_ = v5;
  v20.handler_.op_.type_ = type;
  v20.handler_.start_ = start;
  v20.handler_.want_ = want;
  v20.handler_.ec_ = ec;
  v20.handler_.bytes_transferred_ = bytes_transferred;
  v20.handler_.handler_.dispatcher_ = dispatcher;
  *(_OWORD *)&v20.handler_.handler_.handler_.__f_ = v10;
  v20.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = v11;
  *(_OWORD *)v29 = 0;
  if ( f )
  {
    if ( v30 == (_BYTE *)f )
    {
      v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v20.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))f->next_layer_->service_)(
        f,
        &v20.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)f;
      v31 = 0;
    }
  }
  else
  {
    v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::system::system_category();
  v20.start_ = 1;
  size = v20.buffer_.size_;
  v14 = 0;
  if ( v20.buffer_.size_ >= v20.total_transferred_ )
    v14 = (char *)v20.buffer_.data_ + v20.total_transferred_;
  else
    size = v20.total_transferred_;
  v15 = size - v20.total_transferred_;
  v16 = 0x10000;
  if ( v15 < 0x10000 )
    v16 = v15;
  v19.data_ = v14;
  v19.size_ = v16;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>>(
    v20.stream_->service_,
    &v20.stream_->implementation,
    &v19,
    0,
    &v20);
  if ( &v20.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v20.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  if ( v30 == (_BYTE *)v31 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v31->_vptr$__base + 4))(v31);
  }
  else if ( v31 )
  {
    (*((void (**)(void))v31->_vptr$__base + 5))();
  }
  v18 = v29[1];
  if ( v29[1] )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v29[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(v18);
      std::__shared_weak_count::__release_weak(v18);
    }
  }
}


// Address: 0x2634ea0 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENS0_17mutable_buffers_1ENS1_14transfer_all_tENS0_3ssl6detail5io_opIS8_NSC_12handshake_opENS1_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSI_8functionIFvRKNSI_10error_codeEEEERKNS_6system10error_codeEEJNSI_10shared_ptrISO_EERSU_RKNSI_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEEEC2EOS1D_
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::write_op(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *this,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *other)
{
  std::function<void (const std::error_code &)>::__base *f; // rax

  this->stream_ = other->stream_;
  this->buffer_ = other->buffer_;
  this->start_ = other->start_;
  this->total_transferred_ = other->total_transferred_;
  this->handler_.next_layer_ = other->handler_.next_layer_;
  this->handler_.core_ = other->handler_.core_;
  this->handler_.op_.type_ = other->handler_.op_.type_;
  this->handler_.start_ = other->handler_.start_;
  this->handler_.want_ = other->handler_.want_;
  this->handler_.ec_ = other->handler_.ec_;
  this->handler_.bytes_transferred_ = other->handler_.bytes_transferred_;
  this->handler_.handler_.dispatcher_ = other->handler_.handler_.dispatcher_;
  *(_OWORD *)&this->handler_.handler_.handler_.__f_ = *(_OWORD *)&other->handler_.handler_.handler_.__f_;
  this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_,
        &this->handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = f;
      other->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
}


// Address: 0x2636e40 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEEJNSD_10shared_ptrISJ_EERSP_RKNSD_12placeholders4__phILi1EEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSR_mEE4typeEE4typeERT_RKT0_OS18_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  __int128 v5; // xmm0
  boost::asio::ssl::stream_base::handshake_type type; // r8d
  int start; // ecx
  boost::asio::ssl::detail::engine::want want; // esi
  size_t bytes_transferred; // rbx
  __int128 v10; // xmm1
  std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> v11; // xmm2
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *f; // rdi
  size_t size; // rax
  char *v14; // rdi
  unsigned __int64 v15; // rax
  size_t v16; // rcx
  std::__shared_weak_count *cntrl; // rbx
  std::__shared_weak_count *v18; // rbx
  boost::asio::mutable_buffers_1 v19; // [rsp+0h] [rbp-198h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > v20; // [rsp+10h] [rbp-188h] BYREF
  __int128 v21; // [rsp+D0h] [rbp-C8h]
  boost::asio::ssl::stream_base::handshake_type v22; // [rsp+E0h] [rbp-B8h]
  int v23; // [rsp+E4h] [rbp-B4h]
  boost::asio::ssl::detail::engine::want v24; // [rsp+E8h] [rbp-B0h]
  boost::system::error_code ec; // [rsp+F0h] [rbp-A8h]
  size_t v26; // [rsp+100h] [rbp-98h]
  __int128 v27; // [rsp+110h] [rbp-88h]
  std::__shared_weak_count *v28[2]; // [rsp+120h] [rbp-78h]
  _BYTE v29[32]; // [rsp+130h] [rbp-68h] BYREF
  std::function<void (const std::error_code &)>::__base *v30; // [rsp+150h] [rbp-48h]
  unsigned __int64 v31; // [rsp+170h] [rbp-28h]

  v31 = __readfsqword(0x28u);
  v5 = *(_OWORD *)&handler->next_layer_;
  v21 = *(_OWORD *)&handler->next_layer_;
  type = handler->op_.type_;
  v22 = type;
  start = handler->start_;
  v23 = start;
  want = handler->want_;
  v24 = want;
  ec = handler->ec_;
  bytes_transferred = handler->bytes_transferred_;
  v26 = bytes_transferred;
  v10 = *(_OWORD *)&handler->handler_.__f_;
  v27 = v10;
  v11 = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)v28 = v11;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v30 = (std::function<void (const std::error_code &)>::__base *)v29;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *, _BYTE *))f->next_layer_->service_)(
        f,
        v29);
      v5 = v21;
      type = v22;
      start = v23;
      want = v24;
      bytes_transferred = v26;
      v10 = v27;
      v11 = *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> *)v28;
      f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)v30;
    }
    else
    {
      v30 = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v30 = 0;
    f = 0;
  }
  v20.stream_ = s;
  v20.buffer_ = buffers->boost::asio::mutable_buffer;
  v20.start_ = 0;
  v20.total_transferred_ = 0;
  *(_OWORD *)&v20.handler_.next_layer_ = v5;
  v20.handler_.op_.type_ = type;
  v20.handler_.start_ = start;
  v20.handler_.want_ = want;
  v20.handler_.ec_ = ec;
  v20.handler_.bytes_transferred_ = bytes_transferred;
  *(_OWORD *)&v20.handler_.handler_.__f_ = v10;
  v20.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = v11;
  *(_OWORD *)v28 = 0;
  if ( f )
  {
    if ( v29 == (_BYTE *)f )
    {
      v20.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v20.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))f->next_layer_->service_)(
        f,
        &v20.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      v20.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)f;
      v30 = 0;
    }
  }
  else
  {
    v20.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::system::system_category();
  v20.start_ = 1;
  size = v20.buffer_.size_;
  v14 = 0;
  if ( v20.buffer_.size_ >= v20.total_transferred_ )
    v14 = (char *)v20.buffer_.data_ + v20.total_transferred_;
  else
    size = v20.total_transferred_;
  v15 = size - v20.total_transferred_;
  v16 = 0x10000;
  if ( v15 < 0x10000 )
    v16 = v15;
  v19.data_ = v14;
  v19.size_ = v16;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>>(
    v20.stream_->service_,
    &v20.stream_->implementation,
    &v19,
    0,
    &v20);
  if ( &v20.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v20.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v20.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v20.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v20.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v20.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v20.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v20.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_
    && !_InterlockedExchangeAdd64(
          (volatile signed __int64 *)v20.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
          0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
    std::__shared_weak_count::__release_weak(cntrl);
  }
  if ( v29 == (_BYTE *)v30 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v30->_vptr$__base + 4))(v30);
  }
  else if ( v30 )
  {
    (*((void (**)(void))v30->_vptr$__base + 5))();
  }
  v18 = v28[1];
  if ( v28[1] )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v28[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v18 + 16LL))(v18);
      std::__shared_weak_count::__release_weak(v18);
    }
  }
}


// Address: 0x2638320 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENS0_17mutable_buffers_1ENS1_14transfer_all_tENS0_3ssl6detail5io_opIS8_NSC_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSF_8functionIFvRKNSF_10error_codeEEEERKNS_6system10error_codeEEJNSF_10shared_ptrISL_EERSR_RKNSF_12placeholders4__phILi1EEEEEEEEEC2EOS18_
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::write_op(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *this,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *other)
{
  std::function<void (const std::error_code &)>::__base *f; // rax

  this->stream_ = other->stream_;
  this->buffer_ = other->buffer_;
  this->start_ = other->start_;
  this->total_transferred_ = other->total_transferred_;
  this->handler_.next_layer_ = other->handler_.next_layer_;
  this->handler_.core_ = other->handler_.core_;
  this->handler_.op_.type_ = other->handler_.op_.type_;
  this->handler_.start_ = other->handler_.start_;
  this->handler_.want_ = other->handler_.want_;
  this->handler_.ec_ = other->handler_.ec_;
  this->handler_.bytes_transferred_ = other->handler_.bytes_transferred_;
  *(_OWORD *)&this->handler_.handler_.__f_ = *(_OWORD *)&other->handler_.handler_.__f_;
  this->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = other->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  other->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = other->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &other->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&this->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *))other->handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
       + 3))(
        other->handler_.handler_.__bound_args_.__base_.__value_.__f_,
        &this->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>);
    }
    else
    {
      this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = f;
      other->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    this->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
}


// Address: 0x265c120 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__16vectorINS0_12const_bufferENS8_9allocatorISA_EEEEN11websocketpp9transport4asio20custom_alloc_handlerINS8_8functionIFvRKNS_6system10error_codeEmEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSK_mEE4typeEE4typeERT_RKT0_OSS_
boost::asio::async_result<websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const std::vector<boost::asio::const_buffer> *buffers,
        websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *handler)
{
  websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *f; // rdi
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl; // [rsp+0h] [rbp-118h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-110h] BYREF
  int v7; // [rsp+48h] [rbp-D0h]
  __int64 v8; // [rsp+50h] [rbp-C8h]
  websocketpp::transport::asio::handler_allocator *v9; // [rsp+60h] [rbp-B8h]
  _BYTE v10[32]; // [rsp+70h] [rbp-A8h] BYREF
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *v11; // [rsp+90h] [rbp-88h]
  websocketpp::transport::asio::handler_allocator *allocator; // [rsp+A0h] [rbp-78h]
  _BYTE v13[32]; // [rsp+B0h] [rbp-68h] BYREF
  std::function<void (const boost::system::error_code &,unsigned long)>::__base *v14; // [rsp+D0h] [rbp-48h]
  unsigned __int64 v15; // [rsp+F0h] [rbp-28h]

  v15 = __readfsqword(0x28u);
  allocator = handler->allocator_;
  f = (websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v14 = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)v13;
      (*((void (__fastcall **)(websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > *, _BYTE *))&f->allocator_->storage_.data_.align_
       + 3))(
        f,
        v13);
    }
    else
    {
      v14 = handler->handler_.__f_;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    v14 = 0;
  }
  impl = &s->implementation;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    buffers);
  v7 = 0;
  v8 = 0;
  v9 = allocator;
  if ( v14 )
  {
    if ( v13 == (_BYTE *)v14 )
    {
      v11 = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)v10;
      (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *, _BYTE *))v14->_vptr$__base
       + 3))(
        v14,
        v10);
    }
    else
    {
      v11 = v14;
      v14 = 0;
    }
  }
  else
  {
    v11 = 0;
  }
  boost::system::system_category();
  v7 = 1;
  ptr[7] = &stru_FFF0 + 16;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
    *(boost::asio::stream_socket_service<boost::asio::ip::tcp> **)&impl[1].socket_,
    impl,
    (const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    0,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)&impl);
  if ( v10 == (_BYTE *)v11 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v11->_vptr$__base
     + 4))(v11);
  }
  else if ( v11 )
  {
    (*((void (**)(void))v11->_vptr$__base + 5))();
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  if ( v13 == (_BYTE *)v14 )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v14->_vptr$__base
     + 4))(v14);
  }
  else if ( v14 )
  {
    (*((void (**)(void))v14->_vptr$__base + 5))();
  }
}


// Address: 0x265c340 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__16vectorINS0_12const_bufferENS9_9allocatorISB_EEEENS1_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINS9_8functionIFvRKNS_6system10error_codeEmEEEEEEclESO_mi
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>::operator()(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  _OWORD *v4; // r9
  size_t v6; // r8
  _OWORD *v7; // r10
  char v8; // cl
  size_t v9; // rax
  unsigned __int64 v10; // rcx
  size_t v11; // rdi
  _OWORD *v12; // rax
  _OWORD *v13; // rax
  __int64 v14; // rdi
  int m_val; // eax
  const boost::system::error_category *m_cat; // rcx
  __int64 v17; // rdi
  _QWORD *exception; // rax
  size_t v19; // [rsp+0h] [rbp-18h] BYREF
  int v20; // [rsp+8h] [rbp-10h] BYREF
  const boost::system::error_category *v21; // [rsp+10h] [rbp-8h]

  *((_DWORD *)this + 18) = start;
  if ( start == 1 )
  {
    *((_QWORD *)this + 8) = (unsigned __int64)(ec->m_val == 0) << 16;
LABEL_3:
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
      *(boost::asio::stream_socket_service<boost::asio::ip::tcp> **)(*(_QWORD *)this + 24LL),
      *(boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type **)this,
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)this + 8),
      0,
      this);
    return;
  }
  v6 = bytes_transferred + *((_QWORD *)this + 10);
  *((_QWORD *)this + 10) = v6;
  if ( bytes_transferred )
  {
    v7 = (_OWORD *)((char *)this + 40);
    LOBYTE(v4) = *((_BYTE *)this + 32);
    v8 = (char)v4;
    v9 = bytes_transferred;
    while ( 1 )
    {
      if ( v8 )
      {
LABEL_12:
        if ( (_BYTE)v4 )
          goto LABEL_23;
        goto LABEL_13;
      }
      v10 = *((_QWORD *)this + 6);
      v11 = v9 - v10;
      if ( v9 < v10 )
        break;
      v12 = (_OWORD *)*((_QWORD *)this + 7);
      if ( v12 == *((_OWORD **)this + 2) )
      {
        *((_BYTE *)this + 32) = 1;
        LOBYTE(v4) = 1;
        v8 = 1;
      }
      else
      {
        *((_QWORD *)this + 7) = v12 + 1;
        *v7 = *v12;
        v8 = 0;
      }
      v9 = v11;
      if ( !v11 )
        goto LABEL_12;
    }
    *((_QWORD *)this + 5) += v9;
    *((_QWORD *)this + 6) = v10 - v9;
    if ( (_BYTE)v4 )
      goto LABEL_23;
  }
  else
  {
    LOBYTE(v4) = *((_BYTE *)this + 32);
    if ( (_BYTE)v4 )
      goto LABEL_23;
  }
LABEL_13:
  if ( *((_QWORD *)this + 6) )
  {
LABEL_17:
    v4 = 0;
  }
  else
  {
    v4 = (_OWORD *)((char *)this + 40);
    v13 = (_OWORD *)*((_QWORD *)this + 7);
    v14 = *((_QWORD *)this + 2) - (_QWORD)v13;
    while ( v14 )
    {
      *((_QWORD *)this + 7) = v13 + 1;
      *v4 = *v13;
      v14 -= 16;
      ++v13;
      if ( *((_QWORD *)this + 6) )
        goto LABEL_17;
    }
    *((_BYTE *)this + 32) = 1;
    LOBYTE(v4) = 1;
  }
LABEL_23:
  m_val = ec->m_val;
  *((_QWORD *)this + 8) = (unsigned __int64)(ec->m_val == 0) << 16;
  if ( bytes_transferred || m_val )
  {
    LOBYTE(v4) = (m_val != 0) | (unsigned __int8)v4;
    if ( !(_BYTE)v4 )
      goto LABEL_3;
  }
  m_cat = ec->m_cat;
  v20 = ec->m_val;
  v21 = m_cat;
  v19 = v6;
  v17 = *((_QWORD *)this + 18);
  if ( !v17 )
  {
    exception = __cxa_allocate_exception(8u);
    *exception = off_28852C8;
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::bad_function_call,
      (void (*)(void *))&std::exception::~exception);
  }
  (*(void (__fastcall **)(__int64, int *, size_t *, const boost::system::error_category *, size_t, _OWORD *))(*(_QWORD *)v17 + 48LL))(
    v17,
    &v20,
    &v19,
    m_cat,
    v6,
    v4);
}


// Address: 0x266a570 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__16vectorINS0_12const_bufferENS8_9allocatorISA_EEEENS0_6detail15wrapped_handlerINS0_10io_service6strandENS8_6__bindIMN11websocketpp9transport4asio10connectionINSJ_6config11asio_client16transport_configEEEFvNS8_8functionIFvRKNS8_10error_codeEEEERKNS_6system10error_codeEEJNS8_10shared_ptrISQ_EERSW_RKNS8_12placeholders4__phILi1EEEEEENSE_26is_continuation_if_runningEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSY_mEE4typeEE4typeERT_RKT0_OS1G_
boost::asio::async_result<boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const std::vector<boost::asio::const_buffer> *buffers,
        boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *handler)
{
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *f; // rdi
  std::__shared_weak_count *v5; // rbx
  std::__shared_weak_count *v6; // rbx
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v7; // [rsp+0h] [rbp-158h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-150h] BYREF
  int v9; // [rsp+48h] [rbp-110h]
  __int64 v10; // [rsp+50h] [rbp-108h]
  boost::asio::io_service::strand v11; // [rsp+60h] [rbp-F8h]
  __int128 v12; // [rsp+70h] [rbp-E8h]
  std::__shared_weak_count *v13[2]; // [rsp+80h] [rbp-D8h]
  _BYTE v14[32]; // [rsp+90h] [rbp-C8h] BYREF
  std::function<void (const std::error_code &)>::__base *v15; // [rsp+B0h] [rbp-A8h]
  boost::asio::io_service::strand dispatcher; // [rsp+C0h] [rbp-98h]
  __int128 v17; // [rsp+D0h] [rbp-88h]
  std::__shared_weak_count *v18[2]; // [rsp+E0h] [rbp-78h]
  _BYTE v19[32]; // [rsp+F0h] [rbp-68h] BYREF
  std::function<void (const std::error_code &)>::__base *v20; // [rsp+110h] [rbp-48h]
  unsigned __int64 v21; // [rsp+130h] [rbp-28h]

  v21 = __readfsqword(0x28u);
  dispatcher = handler->dispatcher_;
  v17 = *(_OWORD *)&handler->handler_.__f_;
  *(std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> *)v18 = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,false> = 0;
  f = (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v20 = (std::function<void (const std::error_code &)>::__base *)v19;
      ((void (__fastcall *)(boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *, _BYTE *))f->dispatcher_.service_->owner_)(
        f,
        v19);
    }
    else
    {
      v20 = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v20 = 0;
  }
  v7 = s;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    buffers);
  v9 = 0;
  v10 = 0;
  v11 = dispatcher;
  v12 = v17;
  *(_OWORD *)v13 = *(_OWORD *)v18;
  *(_OWORD *)v18 = 0;
  if ( v20 )
  {
    if ( v19 == (_BYTE *)v20 )
    {
      v15 = (std::function<void (const std::error_code &)>::__base *)v14;
      (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *, _BYTE *))v20->_vptr$__base + 3))(
        v20,
        v14);
    }
    else
    {
      v15 = v20;
      v20 = 0;
    }
  }
  else
  {
    v15 = 0;
  }
  boost::system::system_category();
  v9 = 1;
  ptr[7] = &stru_FFF0 + 16;
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
    v7,
    (const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)&v7);
  if ( v14 == (_BYTE *)v15 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v15->_vptr$__base + 4))(v15);
  }
  else if ( v15 )
  {
    (*((void (**)(void))v15->_vptr$__base + 5))();
  }
  v5 = v13[1];
  if ( v13[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v13[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  if ( v19 == (_BYTE *)v20 )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v20->_vptr$__base + 4))(v20);
  }
  else if ( v20 )
  {
    (*((void (**)(void))v20->_vptr$__base + 5))();
  }
  v6 = v18[1];
  if ( v18[1] )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v18[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v6 + 16LL))(v6);
      std::__shared_weak_count::__release_weak(v6);
    }
  }
}


// Address: 0x266b060 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENSt3__16vectorINS0_12const_bufferENS9_9allocatorISB_EEEENS1_14transfer_all_tENS1_15wrapped_handlerINS0_10io_service6strandENS9_6__bindIMN11websocketpp9transport4asio10connectionINSK_6config11asio_client16transport_configEEEFvNS9_8functionIFvRKNS9_10error_codeEEEERKNS_6system10error_codeEEJNS9_10shared_ptrISR_EERSX_RKNS9_12placeholders4__phILi1EEEEEENS1_26is_continuation_if_runningEEEEclES11_mi
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>::operator()(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  _OWORD *v5; // r9
  char v6; // r8
  char v7; // di
  size_t v8; // rax
  unsigned __int64 v9; // rdi
  size_t v10; // rcx
  _OWORD *v11; // rax
  _OWORD *v12; // rax
  __int64 v13; // rdi
  int m_val; // eax

  *((_DWORD *)this + 18) = start;
  if ( start == 1 )
  {
    *((_QWORD *)this + 8) = (unsigned __int64)(ec->m_val == 0) << 16;
LABEL_3:
    boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>::async_write_some<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
      *(boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > **)this,
      (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)((char *)this + 8),
      this);
    return;
  }
  *((_QWORD *)this + 10) += bytes_transferred;
  if ( bytes_transferred )
  {
    v5 = (_OWORD *)((char *)this + 40);
    v6 = *((_BYTE *)this + 32);
    v7 = v6;
    v8 = bytes_transferred;
    while ( 1 )
    {
      if ( v7 )
      {
LABEL_12:
        if ( v6 )
          goto LABEL_23;
        goto LABEL_13;
      }
      v9 = *((_QWORD *)this + 6);
      v10 = v8 - v9;
      if ( v8 < v9 )
        break;
      v11 = (_OWORD *)*((_QWORD *)this + 7);
      if ( v11 == *((_OWORD **)this + 2) )
      {
        *((_BYTE *)this + 32) = 1;
        v6 = 1;
        v7 = 1;
      }
      else
      {
        *((_QWORD *)this + 7) = v11 + 1;
        *v5 = *v11;
        v7 = 0;
      }
      v8 = v10;
      if ( !v10 )
        goto LABEL_12;
    }
    *((_QWORD *)this + 5) += v8;
    *((_QWORD *)this + 6) = v9 - v8;
    if ( v6 )
      goto LABEL_23;
  }
  else
  {
    v6 = *((_BYTE *)this + 32);
    if ( v6 )
      goto LABEL_23;
  }
LABEL_13:
  if ( *((_QWORD *)this + 6) )
  {
LABEL_17:
    v6 = 0;
  }
  else
  {
    v12 = (_OWORD *)*((_QWORD *)this + 7);
    v13 = *((_QWORD *)this + 2) - (_QWORD)v12;
    while ( v13 )
    {
      *((_QWORD *)this + 7) = v12 + 1;
      *(_OWORD *)((char *)this + 40) = *v12;
      v13 -= 16;
      ++v12;
      if ( *((_QWORD *)this + 6) )
        goto LABEL_17;
    }
    *((_BYTE *)this + 32) = 1;
    v6 = 1;
  }
LABEL_23:
  m_val = ec->m_val;
  *((_QWORD *)this + 8) = (unsigned __int64)(ec->m_val == 0) << 16;
  if ( (bytes_transferred || m_val) && !((m_val != 0) | (unsigned __int8)v6) )
    goto LABEL_3;
  boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>::operator()<boost::system::error_code,unsigned long>(
    (boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config>::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::connection<websocketpp::config::asio_client::transport_config> >,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> *)this
  + 1,
    ec,
    (const unsigned __int64 *)this + 10);
}


// Address: 0x26a2020 | Name: _ZN5boost4asio11async_writeINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEEEENSt3__19allocatorIcEERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSC_10shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSQ_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EEOS19_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_write<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rcx
  const void *v5; // r15
  size_t v6; // rbx
  size_t v7; // rax
  std::__shared_weak_count *v8; // rbx
  boost::asio::const_buffers_1 v9; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > v10; // [rsp+10h] [rbp-78h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> f; // [rsp+60h] [rbp-28h]

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v5 = (const void *)*((_QWORD *)b + 3);
  v6 = *((_QWORD *)b + 6) - (_QWORD)v5;
  v10.stream_ = s;
  v10.buffer_.data_ = v5;
  v10.buffer_.size_ = v6;
  v10.total_transferred_ = 0;
  v10.handler_.streambuf_ = b;
  v10.handler_.handler_.f_ = f;
  v10.handler_.handler_.l_.a1_.t_.__ptr_ = ptr;
  v10.handler_.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  boost::system::system_category();
  v10.start_ = 1;
  v7 = 0x10000;
  if ( v6 < 0x10000 )
    v7 = v6;
  v9.data_ = v5;
  v9.size_ = v7;
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_write_some<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
    s,
    &v9,
    &v10);
  v8 = v10.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v10.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x26a2130 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__19allocatorIcEERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSB_5list2INSB_5valueINS8_10shared_ptrISK_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSM_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EEOS15_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rcx
  const void *v5; // r15
  size_t v6; // rbx
  size_t v7; // rax
  std::__shared_weak_count *v8; // rbx
  boost::asio::const_buffers_1 v9; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > v10; // [rsp+10h] [rbp-78h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> f; // [rsp+60h] [rbp-28h]

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v5 = (const void *)*((_QWORD *)b + 3);
  v6 = *((_QWORD *)b + 6) - (_QWORD)v5;
  v10.stream_ = s;
  v10.buffer_.data_ = v5;
  v10.buffer_.size_ = v6;
  v10.total_transferred_ = 0;
  v10.handler_.streambuf_ = b;
  v10.handler_.handler_.f_ = f;
  v10.handler_.handler_.l_.a1_.t_.__ptr_ = ptr;
  v10.handler_.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  boost::system::system_category();
  v7 = 0x10000;
  if ( v6 < 0x10000 )
    v7 = v6;
  v10.start_ = 1;
  v9.data_ = v5;
  v9.size_ = v7;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
    s->service_,
    &s->implementation,
    &v9,
    0,
    &v10);
  v8 = v10.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v10.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x26a2250 | Name: _ZN5boost4asio6detail8write_opINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEEEENS0_15const_buffers_1ENS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSJ_5list2INSJ_5valueINSG_10shared_ptrISS_EEEEPFNS_3argILi1EEEvEEEEEEEEclESW_mi
void __fastcall boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  unsigned __int64 v5; // r8
  size_t size; // rdx
  size_t total_transferred; // rcx
  boost::asio::basic_streambuf<std::allocator<char> > *streambuf; // rdx
  size_t v9; // r10
  __int64 v10; // rax
  int v11; // edi
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>::F f; // rcx
  web::http::client::details::asio_context::ssl_proxy_tunnel *v13; // rdi
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *stream; // rdi
  char *v15; // rax
  size_t v16; // rdx
  boost::asio::const_buffers_1 buffers; // [rsp+8h] [rbp-10h] BYREF

  this->start_ = start;
  if ( start == 1 )
  {
    v5 = (unsigned __int64)(ec->m_val == 0) << 16;
    size = this->buffer_.size_;
    total_transferred = this->total_transferred_;
LABEL_14:
    stream = this->stream_;
    v15 = 0;
    if ( size >= total_transferred )
      v15 = (char *)this->buffer_.data_ + total_transferred;
    else
      size = total_transferred;
    v16 = size - total_transferred;
    if ( v16 >= v5 )
      v16 = v5;
    buffers.data_ = v15;
    buffers.size_ = v16;
    boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_write_some<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
      stream,
      &buffers,
      this);
    return;
  }
  total_transferred = bytes_transferred + this->total_transferred_;
  this->total_transferred_ = total_transferred;
  if ( bytes_transferred )
  {
    if ( !ec->m_val )
    {
      size = this->buffer_.size_;
      if ( total_transferred != size )
      {
        v5 = 0x10000;
        goto LABEL_14;
      }
    }
  }
  streambuf = this->handler_.streambuf_;
  v9 = *((_QWORD *)streambuf + 6);
  if ( *((_QWORD *)streambuf + 4) < v9 )
  {
    *((_QWORD *)streambuf + 2) = *((_QWORD *)streambuf + 9);
    *((_QWORD *)streambuf + 4) = v9;
  }
  v10 = *((_QWORD *)streambuf + 3);
  v11 = v9 - v10;
  if ( v10 + total_transferred <= v9 )
    v11 = total_transferred;
  *((_QWORD *)streambuf + 3) = v10 + v11;
  f = this->handler_.handler_.f_.f_;
  v13 = (web::http::client::details::asio_context::ssl_proxy_tunnel *)((char *)this->handler_.handler_.l_.a1_.t_.__ptr_
                                                                     + *((_QWORD *)&this->handler_.handler_.f_.f_ + 1));
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>::F *)((char *)f + *(_QWORD *)v13 - 1);
  f(v13, ec);
}


// Address: 0x26a2910 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS9_6streamIRS7_EESD_NSF_14transfer_all_tENSF_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvS10_mEE4typeEE4typeERT_RKT0_OS1K_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *handler)
{
  __int128 v3; // xmm0
  __int64 v4; // rax
  __int128 v5; // xmm1
  int start; // ecx
  __int128 v7; // xmm2
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> l; // xmm3
  size_t size; // rcx
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::mutable_buffers_1 v11; // [rsp+0h] [rbp-118h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &> f; // [rsp+10h] [rbp-108h]
  boost::asio::const_buffer buffer; // [rsp+20h] [rbp-F8h]
  boost::system::error_code ec; // [rsp+30h] [rbp-E8h]
  boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> op; // [rsp+40h] [rbp-D8h]
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > > v16; // [rsp+50h] [rbp-C8h] BYREF

  v3 = *(_OWORD *)&handler->next_layer_;
  op = handler->op_;
  v4 = *(_QWORD *)&handler->start_;
  ec = handler->ec_;
  v5 = *(_OWORD *)&handler->bytes_transferred_;
  buffer = handler->handler_.buffer_;
  start = handler->handler_.start_;
  v7 = *(_OWORD *)&handler->handler_.total_transferred_;
  f = handler->handler_.handler_.handler_.f_;
  l = handler->handler_.handler_.handler_.l_;
  handler->handler_.handler_.handler_.l_ = 0;
  v16.stream_ = s;
  v16.buffer_ = buffers->boost::asio::mutable_buffer;
  v16.total_transferred_ = 0;
  *(_OWORD *)&v16.handler_.next_layer_ = v3;
  v16.handler_.op_ = op;
  *(_QWORD *)&v16.handler_.start_ = v4;
  v16.handler_.ec_ = ec;
  *(_OWORD *)&v16.handler_.bytes_transferred_ = v5;
  v16.handler_.handler_.buffer_ = buffer;
  v16.handler_.handler_.start_ = start;
  *(_OWORD *)&v16.handler_.handler_.total_transferred_ = v7;
  v16.handler_.handler_.handler_.handler_.f_ = f;
  v16.handler_.handler_.handler_.handler_.l_ = l;
  boost::system::system_category();
  v16.start_ = 1;
  size = 0x10000;
  if ( v16.buffer_.size_ < 0x10000 )
    size = v16.buffer_.size_;
  v11.data_ = v16.buffer_.data_;
  v11.size_ = size;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>>(
    s->service_,
    &s->implementation,
    &v11,
    0,
    &v16);
  cntrl = v16.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v16.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v16.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a3970 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENS0_15const_buffers_1ENS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSC_10shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEEEclESS_mi
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>::operator()(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  unsigned __int64 v5; // rdx
  size_t size; // rdi
  size_t total_transferred; // rcx
  boost::asio::basic_streambuf<std::allocator<char> > *streambuf; // rdx
  size_t v9; // r10
  __int64 v10; // rax
  int v11; // edi
  boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>::F f; // rcx
  web::http::client::details::asio_context::ssl_proxy_tunnel *v13; // rdi
  char *v14; // rax
  size_t v15; // rdi
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *stream; // rsi
  boost::asio::const_buffers_1 buffers; // [rsp+8h] [rbp-10h] BYREF

  this->start_ = start;
  if ( start == 1 )
  {
    v5 = (unsigned __int64)(ec->m_val == 0) << 16;
    size = this->buffer_.size_;
    total_transferred = this->total_transferred_;
LABEL_14:
    v14 = 0;
    if ( size >= total_transferred )
      v14 = (char *)this->buffer_.data_ + total_transferred;
    else
      size = total_transferred;
    v15 = size - total_transferred;
    if ( v15 >= v5 )
      v15 = v5;
    stream = this->stream_;
    buffers.data_ = v14;
    buffers.size_ = v15;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
      stream->service_,
      &stream->implementation,
      &buffers,
      0,
      this);
    return;
  }
  total_transferred = bytes_transferred + this->total_transferred_;
  this->total_transferred_ = total_transferred;
  if ( bytes_transferred )
  {
    if ( !ec->m_val )
    {
      size = this->buffer_.size_;
      if ( total_transferred != size )
      {
        v5 = 0x10000;
        goto LABEL_14;
      }
    }
  }
  streambuf = this->handler_.streambuf_;
  v9 = *((_QWORD *)streambuf + 6);
  if ( *((_QWORD *)streambuf + 4) < v9 )
  {
    *((_QWORD *)streambuf + 2) = *((_QWORD *)streambuf + 9);
    *((_QWORD *)streambuf + 4) = v9;
  }
  v10 = *((_QWORD *)streambuf + 3);
  v11 = v9 - v10;
  if ( v10 + total_transferred <= v9 )
    v11 = total_transferred;
  *((_QWORD *)streambuf + 3) = v10 + v11;
  f = this->handler_.handler_.f_.f_;
  v13 = (web::http::client::details::asio_context::ssl_proxy_tunnel *)((char *)this->handler_.handler_.l_.a1_.t_.__ptr_
                                                                     + *((_QWORD *)&this->handler_.handler_.f_.f_ + 1));
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>::F *)((char *)f + *(_QWORD *)v13 - 1);
  f(v13, ec);
}


// Address: 0x26a5520 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_7read_opIS8_EENS0_6detail26read_until_delim_string_opINS9_6streamIRS7_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSX_mEE4typeEE4typeERT_RKT0_OS1G_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  __int128 v4; // xmm0
  __int64 v5; // r8
  __int128 v6; // xmm1
  __int64 v7; // r10
  char v8; // di
  void *v9; // r9
  int v10; // eax
  __int64 v11; // rcx
  __int128 v12; // xmm3
  size_t size; // rcx
  std::__shared_weak_count *v14; // rbx
  boost::asio::mutable_buffers_1 v15; // [rsp+0h] [rbp-128h] BYREF
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v16; // [rsp+10h] [rbp-118h] BYREF
  boost::asio::mutable_buffers_1 v17; // [rsp+18h] [rbp-110h]
  int v18; // [rsp+28h] [rbp-100h]
  __int64 v19; // [rsp+30h] [rbp-F8h]
  __int128 v20; // [rsp+38h] [rbp-F0h]
  __int128 v21; // [rsp+48h] [rbp-E0h]
  __int64 v22; // [rsp+58h] [rbp-D0h]
  __int128 v23; // [rsp+60h] [rbp-C8h]
  __int128 v24; // [rsp+70h] [rbp-B8h]
  __int64 v25; // [rsp+80h] [rbp-A8h]
  char v26; // [rsp+88h] [rbp-A0h]
  _BYTE v27[15]; // [rsp+89h] [rbp-9Fh]
  void *ptr; // [rsp+98h] [rbp-90h]
  int v29; // [rsp+A0h] [rbp-88h]
  __int64 v30; // [rsp+A8h] [rbp-80h]
  __int128 v31; // [rsp+B0h] [rbp-78h]
  std::__shared_weak_count *v32[2]; // [rsp+C0h] [rbp-68h]
  __int128 v33; // [rsp+D0h] [rbp-58h]
  __int128 v34; // [rsp+E0h] [rbp-48h]
  __int128 v35; // [rsp+F0h] [rbp-38h]
  _QWORD v36[5]; // [rsp+100h] [rbp-28h] BYREF

  v36[2] = __readfsqword(0x28u);
  v4 = *(_OWORD *)handler;
  v35 = *((_OWORD *)handler + 1);
  v5 = *((_QWORD *)handler + 4);
  v34 = *(_OWORD *)((char *)handler + 40);
  v6 = *(_OWORD *)((char *)handler + 56);
  v7 = *((_QWORD *)handler + 9);
  v8 = *((_BYTE *)handler + 80);
  *(_QWORD *)((char *)v36 + 7) = *((_QWORD *)handler + 11);
  v36[0] = *(_QWORD *)((char *)handler + 81);
  v9 = (void *)*((_QWORD *)handler + 12);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  v10 = *((_DWORD *)handler + 26);
  v11 = *((_QWORD *)handler + 14);
  v33 = *(_OWORD *)((char *)handler + 120);
  v12 = *(_OWORD *)((char *)handler + 136);
  *(_OWORD *)((char *)handler + 136) = 0;
  v16 = s;
  v17 = *buffers;
  v19 = 0;
  v20 = v4;
  v21 = v35;
  v22 = v5;
  v23 = v34;
  v24 = v6;
  v25 = v7;
  v26 = v8;
  *(_QWORD *)&v27[7] = *(_QWORD *)((char *)v36 + 7);
  *(_QWORD *)v27 = v36[0];
  ptr = v9;
  memset(v36, 0, 15);
  v29 = v10;
  v30 = v11;
  v31 = v33;
  *(_OWORD *)v32 = v12;
  boost::system::system_category();
  v18 = 1;
  size = 0x10000;
  if ( v17.size_ < 0x10000 )
    size = v17.size_;
  v15.data_ = v17.data_;
  v15.size_ = size;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
    s->service_,
    &s->implementation,
    &v15,
    0,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *)&v16);
  v14 = v32[1];
  if ( v32[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v32[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(v14);
    std::__shared_weak_count::__release_weak(v14);
    if ( (v26 & 1) == 0 )
      return;
  }
  else if ( (v26 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a8be0 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSD_5list2INSD_5valueINSt3__110shared_ptrISL_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSN_mEE4typeEE4typeERT_RKT0_OS16_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  __int128 v4; // xmm0
  __int64 v5; // rax
  boost::asio::ssl::detail::engine::want want; // ecx
  size_t bytes_transferred; // rdi
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> l; // xmm1
  size_t size; // rcx
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::mutable_buffers_1 v11; // [rsp+0h] [rbp-D8h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+10h] [rbp-C8h]
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v13; // [rsp+28h] [rbp-B0h] BYREF
  boost::system::error_code ec; // [rsp+B0h] [rbp-28h]
  unsigned __int64 v15; // [rsp+C0h] [rbp-18h]

  v15 = __readfsqword(0x28u);
  v4 = *(_OWORD *)&handler->next_layer_;
  v5 = *(_QWORD *)&handler->op_.type_;
  want = handler->want_;
  ec = handler->ec_;
  bytes_transferred = handler->bytes_transferred_;
  f = handler->handler_.f_;
  l = handler->handler_.l_;
  handler->handler_.l_ = 0;
  v13.stream_ = s;
  v13.buffer_ = buffers->boost::asio::mutable_buffer;
  v13.total_transferred_ = 0;
  *(_OWORD *)&v13.handler_.next_layer_ = v4;
  *(_QWORD *)&v13.handler_.op_.type_ = v5;
  v13.handler_.want_ = want;
  v13.handler_.ec_ = ec;
  v13.handler_.bytes_transferred_ = bytes_transferred;
  v13.handler_.handler_.f_ = f;
  v13.handler_.handler_.l_ = l;
  boost::system::system_category();
  v13.start_ = 1;
  size = 0x10000;
  if ( v13.buffer_.size_ < 0x10000 )
    size = v13.buffer_.size_;
  v11.data_ = v13.buffer_.data_;
  v11.size_ = size;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    s->service_,
    &s->implementation,
    &v11,
    0,
    &v13);
  cntrl = v13.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v13.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v13.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a9a70 | Name: _ZN5boost4asio11async_writeINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS6_EEEEEENSt3__19allocatorIcEERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSC_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSP_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EEOS18_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_write<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rcx
  const void *v5; // r15
  size_t v6; // rbx
  size_t v7; // rax
  std::__shared_weak_count *v8; // rbx
  boost::asio::const_buffers_1 v9; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v10; // [rsp+10h] [rbp-78h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+60h] [rbp-28h]

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v5 = (const void *)*((_QWORD *)b + 3);
  v6 = *((_QWORD *)b + 6) - (_QWORD)v5;
  v10.stream_ = s;
  v10.buffer_.data_ = v5;
  v10.buffer_.size_ = v6;
  v10.total_transferred_ = 0;
  v10.handler_.streambuf_ = b;
  v10.handler_.handler_.f_ = f;
  v10.handler_.handler_.l_.a1_.t_.__ptr_ = ptr;
  v10.handler_.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  boost::system::system_category();
  v10.start_ = 1;
  v7 = 0x10000;
  if ( v6 < 0x10000 )
    v7 = v6;
  v9.data_ = v5;
  v9.size_ = v7;
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_write_some<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    s,
    &v9,
    &v10);
  v8 = v10.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v10.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x26a9b80 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENSt3__19allocatorIcEERKNS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSB_5list2INSB_5valueINS8_10shared_ptrISJ_EEEEPFNS_3argILi1EEEvEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSL_mEE4typeEE4typeERT_RNS0_15basic_streambufIT0_EEOS14_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>> const&>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        boost::asio::basic_streambuf<std::allocator<char> > *b,
        const boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > *handler)
{
  std::shared_ptr<web::http::client::details::asio_context>::element_type *ptr; // rax
  volatile signed __int64 *cntrl; // rcx
  const void *v5; // r15
  size_t v6; // rbx
  size_t v7; // rax
  std::__shared_weak_count *v8; // rbx
  boost::asio::const_buffers_1 v9; // [rsp+0h] [rbp-88h] BYREF
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v10; // [rsp+10h] [rbp-78h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+60h] [rbp-28h]

  f = handler->f_;
  ptr = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v5 = (const void *)*((_QWORD *)b + 3);
  v6 = *((_QWORD *)b + 6) - (_QWORD)v5;
  v10.stream_ = s;
  v10.buffer_.data_ = v5;
  v10.buffer_.size_ = v6;
  v10.total_transferred_ = 0;
  v10.handler_.streambuf_ = b;
  v10.handler_.handler_.f_ = f;
  v10.handler_.handler_.l_.a1_.t_.__ptr_ = ptr;
  v10.handler_.handler_.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  boost::system::system_category();
  v7 = 0x10000;
  if ( v6 < 0x10000 )
    v7 = v6;
  v10.start_ = 1;
  v9.data_ = v5;
  v9.size_ = v7;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    s->service_,
    &s->implementation,
    &v9,
    0,
    &v10);
  v8 = v10.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v10.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v10.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v8 + 16LL))(v8);
      std::__shared_weak_count::__release_weak(v8);
    }
  }
}


// Address: 0x26a9ca0 | Name: _ZN5boost4asio6detail8write_opINS0_3ssl6streamIRNS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS7_EEEEEENS0_15const_buffers_1ENS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSJ_5list2INSJ_5valueINSG_10shared_ptrISR_EEEEPFNS_3argILi1EEEvEEEEEEEEclESV_mi
void __fastcall boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
        boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  unsigned __int64 v5; // r8
  size_t size; // rdx
  size_t total_transferred; // rcx
  boost::asio::basic_streambuf<std::allocator<char> > *streambuf; // rdx
  size_t v9; // r10
  __int64 v10; // rax
  int v11; // edi
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F f; // rcx
  web::http::client::details::asio_context *v13; // rdi
  boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &> *stream; // rdi
  char *v15; // rax
  size_t v16; // rdx
  boost::asio::const_buffers_1 buffers; // [rsp+8h] [rbp-10h] BYREF

  this->start_ = start;
  if ( start == 1 )
  {
    v5 = (unsigned __int64)(ec->m_val == 0) << 16;
    size = this->buffer_.size_;
    total_transferred = this->total_transferred_;
LABEL_14:
    stream = this->stream_;
    v15 = 0;
    if ( size >= total_transferred )
      v15 = (char *)this->buffer_.data_ + total_transferred;
    else
      size = total_transferred;
    v16 = size - total_transferred;
    if ( v16 >= v5 )
      v16 = v5;
    buffers.data_ = v15;
    buffers.size_ = v16;
    boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>::async_write_some<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>> &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
      stream,
      &buffers,
      this);
    return;
  }
  total_transferred = bytes_transferred + this->total_transferred_;
  this->total_transferred_ = total_transferred;
  if ( bytes_transferred )
  {
    if ( !ec->m_val )
    {
      size = this->buffer_.size_;
      if ( total_transferred != size )
      {
        v5 = 0x10000;
        goto LABEL_14;
      }
    }
  }
  streambuf = this->handler_.streambuf_;
  v9 = *((_QWORD *)streambuf + 6);
  if ( *((_QWORD *)streambuf + 4) < v9 )
  {
    *((_QWORD *)streambuf + 2) = *((_QWORD *)streambuf + 9);
    *((_QWORD *)streambuf + 4) = v9;
  }
  v10 = *((_QWORD *)streambuf + 3);
  v11 = v9 - v10;
  if ( v10 + total_transferred <= v9 )
    v11 = total_transferred;
  *((_QWORD *)streambuf + 3) = v10 + v11;
  f = this->handler_.handler_.f_.f_;
  v13 = (web::http::client::details::asio_context *)((char *)this->handler_.handler_.l_.a1_.t_.__ptr_
                                                   + *((_QWORD *)&this->handler_.handler_.f_.f_ + 1));
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F *)((char *)f + *(_QWORD *)v13 - 1);
  f(v13, ec);
}


// Address: 0x26aa360 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS9_6streamIRS7_EESD_NSF_14transfer_all_tENSF_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSZ_mEE4typeEE4typeERT_RKT0_OS1J_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  __int128 v3; // xmm0
  __int64 v4; // rax
  __int128 v5; // xmm1
  int start; // ecx
  __int128 v7; // xmm2
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> l; // xmm3
  size_t size; // rcx
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::mutable_buffers_1 v11; // [rsp+0h] [rbp-118h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+10h] [rbp-108h]
  boost::asio::const_buffer buffer; // [rsp+20h] [rbp-F8h]
  boost::system::error_code ec; // [rsp+30h] [rbp-E8h]
  boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1> op; // [rsp+40h] [rbp-D8h]
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > > v16; // [rsp+50h] [rbp-C8h] BYREF

  v3 = *(_OWORD *)&handler->next_layer_;
  op = handler->op_;
  v4 = *(_QWORD *)&handler->start_;
  ec = handler->ec_;
  v5 = *(_OWORD *)&handler->bytes_transferred_;
  buffer = handler->handler_.buffer_;
  start = handler->handler_.start_;
  v7 = *(_OWORD *)&handler->handler_.total_transferred_;
  f = handler->handler_.handler_.handler_.f_;
  l = handler->handler_.handler_.handler_.l_;
  handler->handler_.handler_.handler_.l_ = 0;
  v16.stream_ = s;
  v16.buffer_ = buffers->boost::asio::mutable_buffer;
  v16.total_transferred_ = 0;
  *(_OWORD *)&v16.handler_.next_layer_ = v3;
  v16.handler_.op_ = op;
  *(_QWORD *)&v16.handler_.start_ = v4;
  v16.handler_.ec_ = ec;
  *(_OWORD *)&v16.handler_.bytes_transferred_ = v5;
  v16.handler_.handler_.buffer_ = buffer;
  v16.handler_.handler_.start_ = start;
  *(_OWORD *)&v16.handler_.handler_.total_transferred_ = v7;
  v16.handler_.handler_.handler_.handler_.f_ = f;
  v16.handler_.handler_.handler_.handler_.l_ = l;
  boost::system::system_category();
  v16.start_ = 1;
  size = 0x10000;
  if ( v16.buffer_.size_ < 0x10000 )
    size = v16.buffer_.size_;
  v11.data_ = v16.buffer_.data_;
  v11.size_ = size;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>>(
    s->service_,
    &s->implementation,
    &v11,
    0,
    &v16);
  cntrl = v16.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v16.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v16.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26ab3c0 | Name: _ZN5boost4asio6detail8write_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS5_EEEENS0_15const_buffers_1ENS1_14transfer_all_tENS1_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSC_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEEEclESR_mi
void __fastcall boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>::operator()(
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *this,
        const boost::system::error_code *ec,
        size_t bytes_transferred,
        int start)
{
  unsigned __int64 v5; // rdx
  size_t size; // rdi
  size_t total_transferred; // rcx
  boost::asio::basic_streambuf<std::allocator<char> > *streambuf; // rdx
  size_t v9; // r10
  __int64 v10; // rax
  int v11; // edi
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F f; // rcx
  web::http::client::details::asio_context *v13; // rdi
  char *v14; // rax
  size_t v15; // rdi
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *stream; // rsi
  boost::asio::const_buffers_1 buffers; // [rsp+8h] [rbp-10h] BYREF

  this->start_ = start;
  if ( start == 1 )
  {
    v5 = (unsigned __int64)(ec->m_val == 0) << 16;
    size = this->buffer_.size_;
    total_transferred = this->total_transferred_;
LABEL_14:
    v14 = 0;
    if ( size >= total_transferred )
      v14 = (char *)this->buffer_.data_ + total_transferred;
    else
      size = total_transferred;
    v15 = size - total_transferred;
    if ( v15 >= v5 )
      v15 = v5;
    stream = this->stream_;
    buffers.data_ = v14;
    buffers.size_ = v15;
    boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
      stream->service_,
      &stream->implementation,
      &buffers,
      0,
      this);
    return;
  }
  total_transferred = bytes_transferred + this->total_transferred_;
  this->total_transferred_ = total_transferred;
  if ( bytes_transferred )
  {
    if ( !ec->m_val )
    {
      size = this->buffer_.size_;
      if ( total_transferred != size )
      {
        v5 = 0x10000;
        goto LABEL_14;
      }
    }
  }
  streambuf = this->handler_.streambuf_;
  v9 = *((_QWORD *)streambuf + 6);
  if ( *((_QWORD *)streambuf + 4) < v9 )
  {
    *((_QWORD *)streambuf + 2) = *((_QWORD *)streambuf + 9);
    *((_QWORD *)streambuf + 4) = v9;
  }
  v10 = *((_QWORD *)streambuf + 3);
  v11 = v9 - v10;
  if ( v10 + total_transferred <= v9 )
    v11 = total_transferred;
  *((_QWORD *)streambuf + 3) = v10 + v11;
  f = this->handler_.handler_.f_.f_;
  v13 = (web::http::client::details::asio_context *)((char *)this->handler_.handler_.l_.a1_.t_.__ptr_
                                                   + *((_QWORD *)&this->handler_.handler_.f_.f_ + 1));
  if ( ((unsigned __int8)f & 1) != 0 )
    f = *(boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>::F *)((char *)f + *(_QWORD *)v13 - 1);
  f(v13, ec);
}


// Address: 0x26ad9a0 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_7read_opIS8_EENS0_6detail26read_until_delim_string_opINS9_6streamIRS7_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSW_mEE4typeEE4typeERT_RKT0_OS1F_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  __int128 v4; // xmm0
  __int64 v5; // r8
  __int128 v6; // xmm1
  __int64 v7; // r10
  char v8; // di
  void *v9; // r9
  int v10; // eax
  __int64 v11; // rcx
  __int128 v12; // xmm3
  size_t size; // rcx
  std::__shared_weak_count *v14; // rbx
  boost::asio::mutable_buffers_1 v15; // [rsp+0h] [rbp-128h] BYREF
  boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *v16; // [rsp+10h] [rbp-118h] BYREF
  boost::asio::mutable_buffers_1 v17; // [rsp+18h] [rbp-110h]
  int v18; // [rsp+28h] [rbp-100h]
  __int64 v19; // [rsp+30h] [rbp-F8h]
  __int128 v20; // [rsp+38h] [rbp-F0h]
  __int128 v21; // [rsp+48h] [rbp-E0h]
  __int64 v22; // [rsp+58h] [rbp-D0h]
  __int128 v23; // [rsp+60h] [rbp-C8h]
  __int128 v24; // [rsp+70h] [rbp-B8h]
  __int64 v25; // [rsp+80h] [rbp-A8h]
  char v26; // [rsp+88h] [rbp-A0h]
  _BYTE v27[15]; // [rsp+89h] [rbp-9Fh]
  void *ptr; // [rsp+98h] [rbp-90h]
  int v29; // [rsp+A0h] [rbp-88h]
  __int64 v30; // [rsp+A8h] [rbp-80h]
  __int128 v31; // [rsp+B0h] [rbp-78h]
  std::__shared_weak_count *v32[2]; // [rsp+C0h] [rbp-68h]
  __int128 v33; // [rsp+D0h] [rbp-58h]
  __int128 v34; // [rsp+E0h] [rbp-48h]
  __int128 v35; // [rsp+F0h] [rbp-38h]
  _QWORD v36[5]; // [rsp+100h] [rbp-28h] BYREF

  v36[2] = __readfsqword(0x28u);
  v4 = *(_OWORD *)handler;
  v35 = *((_OWORD *)handler + 1);
  v5 = *((_QWORD *)handler + 4);
  v34 = *(_OWORD *)((char *)handler + 40);
  v6 = *(_OWORD *)((char *)handler + 56);
  v7 = *((_QWORD *)handler + 9);
  v8 = *((_BYTE *)handler + 80);
  *(_QWORD *)((char *)v36 + 7) = *((_QWORD *)handler + 11);
  v36[0] = *(_QWORD *)((char *)handler + 81);
  v9 = (void *)*((_QWORD *)handler + 12);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  v10 = *((_DWORD *)handler + 26);
  v11 = *((_QWORD *)handler + 14);
  v33 = *(_OWORD *)((char *)handler + 120);
  v12 = *(_OWORD *)((char *)handler + 136);
  *(_OWORD *)((char *)handler + 136) = 0;
  v16 = s;
  v17 = *buffers;
  v19 = 0;
  v20 = v4;
  v21 = v35;
  v22 = v5;
  v23 = v34;
  v24 = v6;
  v25 = v7;
  v26 = v8;
  *(_QWORD *)&v27[7] = *(_QWORD *)((char *)v36 + 7);
  *(_QWORD *)v27 = v36[0];
  ptr = v9;
  memset(v36, 0, 15);
  v29 = v10;
  v30 = v11;
  v31 = v33;
  *(_OWORD *)v32 = v12;
  boost::system::system_category();
  v18 = 1;
  size = 0x10000;
  if ( v17.size_ < 0x10000 )
    size = v17.size_;
  v15.data_ = v17.data_;
  v15.size_ = size;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
    s->service_,
    &s->implementation,
    &v15,
    0,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *)&v16);
  v14 = v32[1];
  if ( v32[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v32[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v14 + 16LL))(v14);
    std::__shared_weak_count::__release_weak(v14);
    if ( (v26 & 1) == 0 )
      return;
  }
  else if ( (v26 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26b2410 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_7read_opIS8_EENS0_6detail17read_streambuf_opINS9_6streamIRS7_EENSt3__19allocatorIcEENSE_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSX_mEE4typeEE4typeERT_RKT0_OS1G_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  __int128 v4; // xmm0
  __int64 v5; // rax
  __int128 v6; // xmm1
  __int128 v7; // xmm2
  int start; // ecx
  size_t total_transferred; // rdi
  boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> l; // xmm3
  size_t size; // rcx
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::mutable_buffers_1 v13; // [rsp+0h] [rbp-108h] BYREF
  boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &> f; // [rsp+10h] [rbp-F8h]
  boost::system::error_code ec; // [rsp+20h] [rbp-E8h]
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> op; // [rsp+30h] [rbp-D8h]
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > v17; // [rsp+48h] [rbp-C0h] BYREF

  v4 = *(_OWORD *)&handler->next_layer_;
  op = handler->op_;
  v5 = *(_QWORD *)&handler->start_;
  ec = handler->ec_;
  v6 = *(_OWORD *)&handler->bytes_transferred_;
  v7 = *(_OWORD *)&handler->handler_.stream_;
  start = handler->handler_.start_;
  total_transferred = handler->handler_.total_transferred_;
  f = handler->handler_.handler_.f_;
  l = handler->handler_.handler_.l_;
  handler->handler_.handler_.l_ = 0;
  v17.stream_ = s;
  v17.buffer_ = buffers->boost::asio::mutable_buffer;
  v17.total_transferred_ = 0;
  *(_OWORD *)&v17.handler_.next_layer_ = v4;
  v17.handler_.op_ = op;
  *(_QWORD *)&v17.handler_.start_ = v5;
  v17.handler_.ec_ = ec;
  *(_OWORD *)&v17.handler_.bytes_transferred_ = v6;
  *(_OWORD *)&v17.handler_.handler_.stream_ = v7;
  v17.handler_.handler_.start_ = start;
  v17.handler_.handler_.total_transferred_ = total_transferred;
  v17.handler_.handler_.handler_.f_ = f;
  v17.handler_.handler_.handler_.l_ = l;
  boost::system::system_category();
  v17.start_ = 1;
  size = 0x10000;
  if ( v17.buffer_.size_ < 0x10000 )
    size = v17.buffer_.size_;
  v13.data_ = v17.buffer_.data_;
  v13.size_ = size;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
    s->service_,
    &s->implementation,
    &v13,
    0,
    &v17);
  cntrl = v17.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v17.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v17.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b5e70 | Name: _ZN5boost4asio11async_writeINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceIS4_EEEENS0_17mutable_buffers_1ENS0_3ssl6detail5io_opIS7_NSA_7read_opIS8_EENS0_6detail17read_streambuf_opINS9_6streamIRS7_EENSt3__19allocatorIcEENSE_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSN_5list3INSN_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvENS12_IiEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT1_FvSX_mEE4typeEE4typeERT_RKT0_OS1H_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > >::type __fastcall boost::asio::async_write<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
        boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *s,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > *handler)
{
  __int128 v4; // xmm0
  __int64 v5; // rax
  __int128 v6; // xmm1
  __int128 v7; // xmm2
  int start; // ecx
  size_t total_transferred; // rdi
  boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> v10; // xmm3
  int t; // edx
  size_t size; // rcx
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::mutable_buffers_1 v14; // [rsp+0h] [rbp-108h] BYREF
  boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int> f; // [rsp+10h] [rbp-F8h]
  boost::system::error_code ec; // [rsp+20h] [rbp-E8h]
  boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1> op; // [rsp+30h] [rbp-D8h]
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > > v18; // [rsp+40h] [rbp-C8h] BYREF

  v4 = *(_OWORD *)&handler->next_layer_;
  op = handler->op_;
  v5 = *(_QWORD *)&handler->start_;
  ec = handler->ec_;
  v6 = *(_OWORD *)&handler->bytes_transferred_;
  v7 = *(_OWORD *)&handler->handler_.stream_;
  start = handler->handler_.start_;
  total_transferred = handler->handler_.total_transferred_;
  f = handler->handler_.handler_.f_;
  v10 = handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  t = handler->handler_.handler_.l_.a3_.t_;
  v18.stream_ = s;
  v18.buffer_ = buffers->boost::asio::mutable_buffer;
  v18.total_transferred_ = 0;
  *(_OWORD *)&v18.handler_.next_layer_ = v4;
  v18.handler_.op_ = op;
  *(_QWORD *)&v18.handler_.start_ = v5;
  v18.handler_.ec_ = ec;
  *(_OWORD *)&v18.handler_.bytes_transferred_ = v6;
  *(_OWORD *)&v18.handler_.handler_.stream_ = v7;
  v18.handler_.handler_.start_ = start;
  v18.handler_.handler_.total_transferred_ = total_transferred;
  v18.handler_.handler_.handler_.f_ = f;
  v18.handler_.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = v10;
  v18.handler_.handler_.handler_.l_.a3_.t_ = t;
  boost::system::system_category();
  v18.start_ = 1;
  size = 0x10000;
  if ( v18.buffer_.size_ < 0x10000 )
    size = v18.buffer_.size_;
  v14.data_ = v18.buffer_.data_;
  v14.size_ = size;
  boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>>(
    s->service_,
    &s->implementation,
    &v14,
    0,
    &v18);
  cntrl = v18.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v18.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v18.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


