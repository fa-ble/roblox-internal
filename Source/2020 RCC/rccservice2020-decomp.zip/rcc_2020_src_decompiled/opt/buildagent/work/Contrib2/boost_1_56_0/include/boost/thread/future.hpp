// Address: 0xdbd610 | Name: _ZN5boost7promiseINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEE10get_futureEv
boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type **__fastcall boost::promise<std::string>::get_future(
        boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type **a1,
        boost::promise<std::string > *this)
{
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *px; // rax
  boost::detail::sp_counted_base *pi; // rbx
  const boost::system::error_category *v5; // rbx
  const boost::system::error_category *v6; // rbx
  _BYTE v7[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  _QWORD v9[2]; // [rsp+18h] [rbp-30h] BYREF
  int v10; // [rsp+28h] [rbp-20h]
  const boost::system::error_category *v11; // [rsp+30h] [rbp-18h]

  boost::promise<std::string>::lazy_init(this);
  px = this->future_.px;
  if ( !this->future_.px )
  {
    v5 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v5->_vptr$error_category + 3))(
      v7,
      v5,
      4);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 4;
    v11 = v5;
    v9[0] = off_2878AC8;
    boost::throw_exception<boost::promise_moved>((const boost::promise_moved *)v9);
  }
  if ( this->future_obtained )
  {
    v6 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v6->_vptr$error_category + 3))(
      v7,
      v6,
      2);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 2;
    v11 = v6;
    v9[0] = off_2878C78;
    boost::throw_exception<boost::future_already_retrieved>((const boost::future_already_retrieved *)v9);
  }
  this->future_obtained = 1;
  pi = this->future_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    _InterlockedAdd(&pi->use_count_, 1u);
    *a1 = px;
    a1[1] = (boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *)pi;
    _InterlockedAdd(&pi->use_count_, 1u);
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  else
  {
    *a1 = px;
    a1[1] = 0;
  }
  return a1;
}


// Address: 0xdbdc70 | Name: _ZN5boost7promiseINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEED2Ev
void __fastcall boost::promise<std::string>::~promise(boost::promise<std::string > *this)
{
  boost::detail::sp_counted_base *pi; // rbx
  const boost::system::error_category *v2; // r15
  std::logic_error *exception; // r15
  boost::unique_lock<boost::mutex> v4; // [rsp+8h] [rbp-70h] BYREF
  _QWORD v5[2]; // [rsp+28h] [rbp-50h] BYREF
  __int128 v6; // [rsp+38h] [rbp-40h]
  _BYTE v7[16]; // [rsp+48h] [rbp-30h] BYREF
  void *ptr; // [rsp+58h] [rbp-20h]

  if ( this->future_.px )
  {
    v4.m = &this->future_.px->mutex;
    v4.is_locked = 0;
    boost::unique_lock<boost::mutex>::lock(&v4);
    if ( !this->future_.px->done && !this->future_.px->is_constructed )
    {
      v2 = boost::future_category();
      (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v2->_vptr$error_category + 3))(
        v7,
        v2,
        1);
      std::logic_error::logic_error(v5, v7);
      if ( (v7[0] & 1) != 0 )
        operator delete(ptr);
      LODWORD(v6) = 1;
      *((_QWORD *)&v6 + 1) = v2;
      v5[0] = off_2876850;
      exception = (std::logic_error *)__cxa_allocate_exception(0x28u);
      *((_QWORD *)exception + 4) = &off_2875618;
      std::logic_error::logic_error(exception, (const std::logic_error *)v5);
      *((_OWORD *)exception + 1) = v6;
      *(_QWORD *)exception = &off_28767D0;
      *((_QWORD *)exception + 4) = &off_2876820;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::broken_promise>,
        (void (*)(void *))std::logic_error::~logic_error);
    }
    if ( v4.is_locked )
      boost::mutex::unlock(v4.m);
  }
  pi = this->future_.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xdbdf60 | Name: _ZN5boost6detail17shared_state_base22mark_finished_internalERNS_11unique_lockINS_5mutexEEE
void __fastcall boost::detail::shared_state_base::mark_finished_internal(
        boost::detail::shared_state_base_0 *this,
        boost::unique_lock<boost::mutex> *lock)
{
  boost::detail::shared_state_base_0 *i; // rbx
  boost::detail::sp_counted_base *pi; // r13

  this->done = 1;
  pthread_mutex_lock(&this->waiters.internal_mutex);
  pthread_cond_broadcast(&this->waiters.cond);
  pthread_mutex_unlock(&this->waiters.internal_mutex);
  for ( i = (boost::detail::shared_state_base_0 *)this->external_waiters.__end_.__next_;
        &this->external_waiters != (boost::detail::shared_state_base::waiter_list *)i;
        i = i->weak_this_.px )
  {
    pi = i->weak_this_.pn.pi_;
    pthread_mutex_lock((pthread_mutex_t *)pi);
    pthread_cond_broadcast((pthread_cond_t *)&pi[2].use_count_);
    pthread_mutex_unlock((pthread_mutex_t *)pi);
  }
  boost::detail::shared_state_base::do_continuation(this, lock);
}


// Address: 0xdbdff0 | Name: _ZN5boost6detail17shared_state_base15do_continuationERNS_11unique_lockINS_5mutexEEE
void __fastcall boost::detail::shared_state_base::do_continuation(
        boost::detail::shared_state_base_0 *this,
        boost::unique_lock<boost::mutex> *lock)
{
  boost::shared_ptr<boost::detail::shared_state_base>::element_type *px; // rbx
  boost::detail::sp_counted_base *pi; // r15
  boost::detail::sp_counted_base *v4; // r12

  px = this->continuation_ptr.px;
  if ( px )
  {
    pi = this->continuation_ptr.pn.pi_;
    if ( pi )
    {
      _InterlockedAdd(&pi->use_count_, 1u);
      v4 = this->continuation_ptr.pn.pi_;
      this->continuation_ptr = 0;
      if ( v4 )
      {
        if ( !_InterlockedSub(&v4->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
          if ( !_InterlockedSub(&v4->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
        }
      }
    }
    else
    {
      this->continuation_ptr = 0;
    }
    (*(void (__fastcall **)(boost::shared_ptr<boost::detail::shared_state_base>::element_type *, boost::unique_lock<boost::mutex> *))px->_vptr$shared_state_base)(
      px,
      lock);
    if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
}


// Address: 0xdbe370 | Name: _ZN5boost14broken_promiseD0Ev
void __fastcall boost::broken_promise::~broken_promise(boost::broken_promise *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdbe390 | Name: _ZN5boost12future_errorD0Ev
void __fastcall boost::future_error::~future_error(boost::future_error *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdcaaa0 | Name: _ZN5boost7promiseINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEE13set_exceptionENS_13exception_ptrE
void __fastcall boost::promise<std::string>::set_exception(boost::promise<std::string > *this, boost::exception_ptr p)
{
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *px; // rbx
  int (**v3)(void); // rcx
  int (**v4)(void); // rax
  volatile signed __int32 *pi; // r14
  const boost::system::error_category *v6; // rbx
  boost::unique_lock<boost::mutex> v7; // [rsp+0h] [rbp-58h] BYREF
  _BYTE v8[16]; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]
  _QWORD v10[2]; // [rsp+28h] [rbp-30h] BYREF
  int v11; // [rsp+38h] [rbp-20h]
  const boost::system::error_category *v12; // [rsp+40h] [rbp-18h]

  boost::promise<std::string>::lazy_init(this);
  v7.m = &this->future_.px->mutex;
  v7.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v7);
  px = this->future_.px;
  if ( this->future_.px->done )
  {
    v6 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v6->_vptr$error_category + 3))(
      v8,
      v6,
      3);
    std::logic_error::logic_error(v10, v8);
    if ( (v8[0] & 1) != 0 )
      operator delete(ptr);
    v11 = 3;
    v12 = v6;
    v10[0] = off_2878768;
    boost::throw_exception<boost::promise_already_satisfied>((const boost::promise_already_satisfied *)v10);
  }
  v3 = p.ptr_.px->_vptr$clone_base;
  v4 = p.ptr_.px[1]._vptr$clone_base;
  if ( v4 )
    _InterlockedAdd((volatile signed __int32 *)v4 + 2, 1u);
  px->exception.ptr_.px = (boost::shared_ptr<const boost::exception_detail::clone_base>::element_type *)v3;
  pi = (volatile signed __int32 *)px->exception.ptr_.pn.pi_;
  px->exception.ptr_.pn.pi_ = (boost::detail::sp_counted_base *)v4;
  if ( pi )
  {
    if ( !_InterlockedSub(pi + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
      if ( !_InterlockedSub(pi + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
    }
  }
  boost::detail::shared_state_base::mark_finished_internal(px, &v7);
  if ( v7.is_locked )
    boost::mutex::unlock(v7.m);
}


// Address: 0xdcad00 | Name: _ZN5boost7promiseINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEE9set_valueEOS7_
void __fastcall boost::promise<std::string>::set_value(
        boost::promise<std::string > *this,
        boost::detail::future_traits<std::string >::rvalue_source_type r)
{
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *px; // r14
  std::string *v3; // rax
  void **v4; // rbx
  const boost::system::error_category *v5; // rbx
  boost::unique_lock<boost::mutex> lock; // [rsp+8h] [rbp-60h] BYREF
  _BYTE v7[16]; // [rsp+18h] [rbp-50h] BYREF
  void *ptr; // [rsp+28h] [rbp-40h]
  _QWORD v9[2]; // [rsp+30h] [rbp-38h] BYREF
  int v10; // [rsp+40h] [rbp-28h]
  const boost::system::error_category *v11; // [rsp+48h] [rbp-20h]

  boost::promise<std::string>::lazy_init(this);
  lock.m = &this->future_.px->mutex;
  lock.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lock);
  px = this->future_.px;
  if ( this->future_.px->done )
  {
    v5 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v5->_vptr$error_category + 3))(
      v7,
      v5,
      3);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 3;
    v11 = v5;
    v9[0] = off_2878768;
    boost::throw_exception<boost::promise_already_satisfied>((const boost::promise_already_satisfied *)v9);
  }
  v3 = (std::string *)operator new(0x18u);
  *((_QWORD *)v3 + 2) = *((_QWORD *)r + 2);
  *(_OWORD *)v3 = *(_OWORD *)r;
  *(_OWORD *)r = 0;
  *((_QWORD *)r + 2) = 0;
  v4 = (void **)px->result.px;
  px->result.px = v3;
  if ( v4 )
  {
    if ( (*(_BYTE *)v4 & 1) != 0 )
      operator delete(v4[2]);
    operator delete(v4);
  }
  boost::detail::shared_state_base::mark_finished_internal(px, &lock);
  if ( lock.is_locked )
    boost::mutex::unlock(lock.m);
}


// Address: 0xdcae80 | Name: _ZN5boost7promiseINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEE9lazy_initEv
void __fastcall boost::promise<std::string>::lazy_init(boost::promise<std::string > *this)
{
  unsigned __int64 v1; // r13
  unsigned int v2; // ebx
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *px; // rbx
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_state<std::string > *v5; // rbx
  boost::shared_ptr<boost::detail::shared_state<std::string > > v6; // rdx
  boost::detail::sp_counted_base *v7; // rbx
  volatile signed __int32 *tv_nsec; // rbx
  boost::shared_ptr<boost::detail::shared_state<std::string > > v9; // [rsp+0h] [rbp-58h] BYREF
  struct timespec requested_time; // [rsp+10h] [rbp-48h] BYREF
  __m128i v11[3]; // [rsp+20h] [rbp-38h] BYREF

  v1 = (unsigned __int64)this % 0x29;
  if ( _InterlockedExchange(&dword_29F1450[(unsigned __int64)this % 0x29], 1) )
  {
    v2 = 0;
    v11[0] = _mm_slli_si128((__m128i)0x3E8uLL, 8);
    do
    {
      if ( v2 >= 4 )
      {
        if ( v2 > 0xF )
        {
          if ( v2 < 0x20 || (v2 & 1) != 0 )
          {
            sched_yield();
          }
          else
          {
            requested_time = (struct timespec)_mm_load_si128(v11);
            nanosleep(&requested_time, 0);
          }
        }
        else
        {
          _mm_pause();
        }
      }
      ++v2;
    }
    while ( _InterlockedExchange(&dword_29F1450[v1], 1) );
  }
  px = this->future_.px;
  pi = this->future_.pn.pi_;
  if ( !pi )
  {
    dword_29F1450[v1] = 0;
    if ( px )
      return;
    goto LABEL_18;
  }
  _InterlockedAdd(&pi->use_count_, 1u);
  dword_29F1450[v1] = 0;
  if ( !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
  if ( !px )
  {
LABEL_18:
    requested_time = 0;
    v5 = (boost::detail::shared_state<std::string > *)operator new(0x110u);
    boost::detail::shared_state_base::shared_state_base(v5);
    v5->_vptr$shared_state_base = (int (**)(void))&off_28782E8;
    v5->result.px = 0;
    v9.px = v5;
    v9.pn.pi_ = 0;
    boost::detail::sp_pointer_construct<boost::detail::shared_state<std::string>,boost::detail::shared_state<std::string>>(
      &v9,
      v5,
      &v9.pn);
    v6.px = (boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *)&v9;
    boost::atomic_compare_exchange<boost::detail::shared_state<std::string>>(
      &this->future_,
      (boost::shared_ptr<boost::detail::shared_state<std::string > > *)&requested_time,
      v6);
    v7 = v9.pn.pi_;
    if ( v9.pn.pi_ )
    {
      if ( !_InterlockedSub(&v9.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
    tv_nsec = (volatile signed __int32 *)requested_time.tv_nsec;
    if ( requested_time.tv_nsec && !_InterlockedSub((volatile signed __int32 *)(requested_time.tv_nsec + 8), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)tv_nsec + 16LL))(tv_nsec);
      if ( !_InterlockedSub(tv_nsec + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)tv_nsec + 24LL))(tv_nsec);
    }
  }
}


// Address: 0xdcb370 | Name: _ZN5boost6detail17shared_state_baseC2Ev
void __fastcall boost::detail::shared_state_base::shared_state_base(boost::detail::shared_state_base_0 *this)
{
  this->boost::enable_shared_from_this<boost::detail::shared_state_base> = 0;
  this->_vptr$shared_state_base = (int (**)(void))&off_2878388;
  this->policy_ = boost::launch::none;
  this->is_constructed = 0;
  this->exception = 0;
  *(_WORD *)&this->done = 0;
  boost::mutex::mutex(&this->mutex);
  boost::condition_variable::condition_variable(&this->waiters);
  this->external_waiters.__end_.__prev_ = &this->external_waiters.__end_;
  this->external_waiters.__end_.__next_ = &this->external_waiters.__end_;
  this->thread_was_interrupted = 0;
  this->continuation_ptr = 0;
  *(_OWORD *)&this->external_waiters.__size_alloc_.__value_ = 0;
}


// Address: 0xdcb460 | Name: _ZN5boost6detail17shared_state_base19launch_continuationERNS_11unique_lockINS_5mutexEEE
void __fastcall boost::detail::shared_state_base::launch_continuation(
        boost::detail::shared_state_base_0 *this,
        boost::unique_lock<boost::mutex> *a2)
{
  ;
}


// Address: 0xdcb470 | Name: _ZN5boost6detail12shared_stateINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEED2Ev
void __fastcall boost::detail::shared_state<std::string>::~shared_state(
        boost::detail::shared_state<std::string > *this)
{
  std::string *px; // rbx

  this->_vptr$shared_state_base = (int (**)(void))&off_28782E8;
  px = this->result.px;
  if ( px )
  {
    if ( (*(_BYTE *)px & 1) != 0 )
      operator delete(*((void **)px + 2));
    operator delete(px);
  }
  boost::detail::shared_state_base::~shared_state_base(this);
}


// Address: 0xdcb4c0 | Name: _ZN5boost6detail12shared_stateINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEED0Ev
void __fastcall boost::detail::shared_state<std::string>::~shared_state(
        boost::detail::shared_state<std::string > *this)
{
  std::string *px; // r14

  this->_vptr$shared_state_base = (int (**)(void))&off_28782E8;
  px = this->result.px;
  if ( px )
  {
    if ( (*(_BYTE *)px & 1) != 0 )
      operator delete(*((void **)px + 2));
    operator delete(px);
  }
  boost::detail::shared_state_base::~shared_state_base(this);
  operator delete(this);
}


// Address: 0xdcb510 | Name: _ZN5boost6detail17shared_state_base4waitEb
void __fastcall boost::detail::shared_state_base::wait(boost::detail::shared_state_base_0 *this, bool rethrow)
{
  boost::unique_lock<boost::mutex> v2[2]; // [rsp+0h] [rbp-28h] BYREF

  v2[0].m = &this->mutex;
  v2[0].is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(v2);
  boost::detail::shared_state_base::wait_internal(this, v2, rethrow);
  if ( v2[0].is_locked )
    boost::mutex::unlock(v2[0].m);
}


// Address: 0xdcb590 | Name: _ZN5boost6detail17shared_state_base7executeERNS_11unique_lockINS_5mutexEEE
void __fastcall boost::detail::shared_state_base::execute(
        boost::detail::shared_state_base_0 *this,
        boost::unique_lock<boost::mutex> *a2)
{
  ;
}


// Address: 0xdcb5a0 | Name: _ZN5boost6detail12shared_stateINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEE3getEv
void __fastcall boost::detail::shared_state<std::string>::get(
        __int64 a1,
        boost::detail::shared_state<std::string > *this)
{
  std::string *px; // rax
  boost::unique_lock<boost::mutex> v3[2]; // [rsp+0h] [rbp-28h] BYREF

  v3[0].m = &this->mutex;
  v3[0].is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(v3);
  boost::detail::shared_state_base::wait_internal(this, v3, 1);
  px = this->result.px;
  *(_QWORD *)(a1 + 16) = *((_QWORD *)px + 2);
  *(_OWORD *)a1 = *(_OWORD *)px;
  *(_OWORD *)px = 0;
  *((_QWORD *)px + 2) = 0;
  if ( v3[0].is_locked )
    boost::mutex::unlock(v3[0].m);
}


// Address: 0xdcb650 | Name: _ZN5boost6detail12shared_stateINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEE6get_shEv
boost::detail::shared_state<std::string >::shared_future_get_result_type __fastcall boost::detail::shared_state<std::string>::get_sh(
        boost::detail::shared_state<std::string > *this)
{
  std::string *px; // rbx
  boost::unique_lock<boost::mutex> lk; // [rsp+8h] [rbp-20h] BYREF

  lk.m = &this->mutex;
  lk.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lk);
  boost::detail::shared_state_base::wait_internal(this, &lk, 1);
  px = this->result.px;
  if ( lk.is_locked )
    boost::mutex::unlock(lk.m);
  return px;
}


// Address: 0xdcb7f0 | Name: _ZN5boost6detail17shared_state_baseD2Ev
void __fastcall boost::detail::shared_state_base::~shared_state_base(boost::detail::shared_state_base_0 *this)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v4)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  std::__list_node_base<boost::condition_variable_any *,void *>::__link_pointer prev; // rax
  boost::detail::shared_state_base_0 *next; // rdi
  std::__list_node_base<boost::condition_variable_any *,void *> *v7; // rdx
  boost::detail::shared_state_base_0 *px; // rbx
  boost::detail::sp_counted_base *v9; // rbx
  boost::detail::sp_counted_base *v10; // rdi

  this->_vptr$shared_state_base = (int (**)(void))&off_2878388;
  pi = this->continuation_ptr.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  vtable = this->callback.vtable;
  if ( vtable )
  {
    if ( ((unsigned __int8)vtable & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4(&this->callback.functor, &this->callback.functor, 2);
    }
    this->callback.vtable = 0;
  }
  if ( this->external_waiters.__size_alloc_.__value_ )
  {
    prev = this->external_waiters.__end_.__prev_;
    next = (boost::detail::shared_state_base_0 *)this->external_waiters.__end_.__next_;
    v7 = (std::__list_node_base<boost::condition_variable_any *,void *> *)next->_vptr$shared_state_base;
    v7->__next_ = prev->__next_;
    prev->__next_->__prev_ = v7;
    this->external_waiters.__size_alloc_.__value_ = 0;
    if ( next != (boost::detail::shared_state_base_0 *)&this->external_waiters )
    {
      do
      {
        px = next->weak_this_.px;
        operator delete(next);
        next = px;
      }
      while ( px != (boost::detail::shared_state_base_0 *)&this->external_waiters );
    }
  }
  while ( pthread_mutex_destroy(&this->waiters.internal_mutex) == 4 )
    ;
  while ( pthread_cond_destroy(&this->waiters.cond) == 4 )
    ;
  while ( pthread_mutex_destroy(&this->mutex.m) == 4 )
    ;
  v9 = this->exception.ptr_.pn.pi_;
  if ( v9 )
  {
    if ( !_InterlockedSub(&v9->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  v10 = this->weak_this_.pn.pi_;
  if ( v10 )
  {
    if ( !_InterlockedSub(&v10->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
  }
}


// Address: 0xdcb990 | Name: _ZN5boost6detail17shared_state_baseD0Ev
void __fastcall boost::detail::shared_state_base::~shared_state_base(boost::detail::shared_state_base_0 *this)
{
  boost::detail::shared_state_base::~shared_state_base(this);
  operator delete(this);
}


// Address: 0xdcb9b0 | Name: _ZN5boost6detail17shared_state_base13wait_internalERNS_11unique_lockINS_5mutexEEEb
void __fastcall boost::detail::shared_state_base::wait_internal(
        boost::detail::shared_state_base_0 *this,
        boost::unique_lock<boost::mutex> *lk,
        bool rethrow)
{
  boost::shared_ptr<const boost::exception_detail::clone_base>::element_type *(__fastcall *v4)(const boost::shared_ptr<const boost::exception_detail::clone_base> *); // rcx
  void *exception; // rax

  boost::detail::shared_state_base::do_callback(this, lk);
  if ( this->is_deferred_ )
  {
    this->is_deferred_ = 0;
    (*((void (__fastcall **)(boost::detail::shared_state_base_0 *, boost::unique_lock<boost::mutex> *))this->_vptr$shared_state_base
     + 4))(
      this,
      lk);
  }
  else
  {
    while ( !this->done )
      boost::condition_variable::wait(&this->waiters, lk);
    if ( rethrow )
    {
      if ( this->thread_was_interrupted )
      {
        exception = __cxa_allocate_exception(1u);
        __cxa_throw(exception, (struct type_info *)&`typeinfo for'boost::thread_interrupted, 0);
      }
      v4 = boost::shared_ptr<boost::exception_detail::clone_base const>::get;
      if ( !this->exception.ptr_.px )
        v4 = 0;
      if ( v4 )
        boost::rethrow_exception(&this->exception);
    }
  }
}


// Address: 0xdcba70 | Name: _ZN5boost6detail17shared_state_base11do_callbackERNS_11unique_lockINS_5mutexEEE
void __fastcall boost::detail::shared_state_base::do_callback(
        boost::detail::shared_state_base_0 *this,
        boost::unique_lock<boost::mutex> *lock)
{
  boost::detail::function::vtable_base *vtable; // rax
  void (__fastcall *v3)(boost::function0<void>::dummy *); // rcx
  void (__fastcall *v4)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::function::vtable_base *v5; // [rsp+8h] [rbp-40h]
  boost::detail::function::function_buffer functor; // [rsp+10h] [rbp-38h] BYREF
  _QWORD v7[4]; // [rsp+28h] [rbp-20h] BYREF

  vtable = this->callback.vtable;
  v3 = boost::function0<void>::dummy::nonnull;
  if ( !vtable )
    v3 = 0;
  if ( v3 && !this->done )
  {
    v5 = 0;
    if ( vtable )
    {
      v5 = this->callback.vtable;
      if ( ((unsigned __int8)vtable & 1) != 0 )
        functor = this->callback.functor;
      else
        (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
          &this->callback.functor,
          &functor,
          0);
    }
    boost::unique_lock<boost::mutex>::unlock(lock);
    if ( !v5 )
    {
      std::runtime_error::runtime_error((std::runtime_error *)v7, "call to empty boost::function");
      v7[0] = off_2875ED8;
      boost::throw_exception<boost::bad_function_call>((const boost::bad_function_call *)v7);
    }
    (*(void (__fastcall **)(boost::detail::function::function_buffer *))(((unsigned __int64)v5 & 0xFFFFFFFFFFFFFFFELL)
                                                                       + 8))(&functor);
    boost::unique_lock<boost::mutex>::lock(lock);
    if ( ((unsigned __int8)v5 & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v5 & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4(&functor, &functor, 2);
    }
  }
}


// Address: 0xdcd090 | Name: _ZN5boost25promise_already_satisfiedD0Ev
void __fastcall boost::promise_already_satisfied::~promise_already_satisfied(boost::promise_already_satisfied *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdcddf0 | Name: _ZN5boost13promise_movedD0Ev
void __fastcall boost::promise_moved::~promise_moved(boost::promise_moved *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdce490 | Name: _ZN5boost24future_already_retrievedD0Ev
void __fastcall boost::future_already_retrieved::~future_already_retrieved(boost::future_already_retrieved *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdce630 | Name: _ZN5boost6detail12basic_futureINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEEaSEOS9_
boost::detail::basic_future<std::string > *__fastcall boost::detail::basic_future<std::string>::operator=(
        boost::detail::basic_future<std::string > *this,
        boost::detail::basic_future<std::string > *other)
{
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *px; // rcx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::detail::sp_counted_base *v5; // rbx

  px = other->future_.px;
  pi = other->future_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->future_.px = px;
  v4 = this->future_.pn.pi_;
  this->future_.pn.pi_ = pi;
  if ( v4 )
  {
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
  }
  v5 = other->future_.pn.pi_;
  *other = 0;
  if ( v5 )
  {
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  return this;
}


// Address: 0xdcecb0 | Name: _ZN5boost20future_uninitializedD0Ev
void __fastcall boost::future_uninitialized::~future_uninitialized(boost::future_uninitialized *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0x1200290 | Name: _ZN5boost7promiseIvE10get_futureEv
boost::shared_ptr<boost::detail::shared_state<void> >::element_type **__fastcall boost::promise<void>::get_future(
        boost::shared_ptr<boost::detail::shared_state<void> >::element_type **a1,
        boost::promise<void> *this)
{
  boost::shared_ptr<boost::detail::shared_state<void> >::element_type *px; // rax
  boost::detail::sp_counted_base *pi; // rbx
  const boost::system::error_category *v5; // rbx
  const boost::system::error_category *v6; // rbx
  _BYTE v7[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  _QWORD v9[2]; // [rsp+18h] [rbp-30h] BYREF
  int v10; // [rsp+28h] [rbp-20h]
  const boost::system::error_category *v11; // [rsp+30h] [rbp-18h]

  boost::promise<void>::lazy_init(this);
  px = this->future_.px;
  if ( !this->future_.px )
  {
    v5 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v5->_vptr$error_category + 3))(
      v7,
      v5,
      4);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 4;
    v11 = v5;
    v9[0] = off_2878AC8;
    boost::throw_exception<boost::promise_moved>((const boost::promise_moved *)v9);
  }
  if ( this->future_obtained )
  {
    v6 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v6->_vptr$error_category + 3))(
      v7,
      v6,
      2);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 2;
    v11 = v6;
    v9[0] = off_2878C78;
    boost::throw_exception<boost::future_already_retrieved>((const boost::future_already_retrieved *)v9);
  }
  this->future_obtained = 1;
  pi = this->future_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    _InterlockedAdd(&pi->use_count_, 1u);
    *a1 = px;
    a1[1] = (boost::shared_ptr<boost::detail::shared_state<void> >::element_type *)pi;
    _InterlockedAdd(&pi->use_count_, 1u);
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  else
  {
    *a1 = px;
    a1[1] = 0;
  }
  return a1;
}


// Address: 0x1200440 | Name: _ZN5boost6detail12basic_futureIvED2Ev
void __fastcall boost::detail::basic_future<void>::~basic_future(boost::detail::basic_future<void> *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->future_.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1203d40 | Name: _ZNK5boost6detail12basic_futureINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEE10wait_untilINS_6chrono12steady_clockENSB_8durationIlNS_5ratioILl1ELl1000000000EEEEEEENS_13future_statusERKNSB_10time_pointIT_T0_EE
boost::future_status __fastcall boost::detail::basic_future<std::string>::wait_until<boost::chrono::steady_clock,boost::chrono::duration<long,boost::ratio<1l,1000000000l>>>(
        const boost::detail::basic_future<std::string > *this,
        const boost::chrono::time_point<boost::chrono::steady_clock,boost::chrono::duration<long,boost::ratio<1,1000000000> > > *abs_time)
{
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *px; // rdi
  const boost::system::error_category *v4; // rbx
  _BYTE v5[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  _QWORD v7[2]; // [rsp+18h] [rbp-30h] BYREF
  int v8; // [rsp+28h] [rbp-20h]
  const boost::system::error_category *v9; // [rsp+30h] [rbp-18h]

  px = this->future_.px;
  if ( !px )
  {
    v4 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v4->_vptr$error_category + 3))(
      v5,
      v4,
      4);
    std::logic_error::logic_error(v7, v5);
    if ( (v5[0] & 1) != 0 )
      operator delete(ptr);
    v8 = 4;
    v9 = v4;
    v7[0] = off_2878E28;
    boost::throw_exception<boost::future_uninitialized>((const boost::future_uninitialized *)v7);
  }
  return boost::detail::shared_state_base::wait_until<boost::chrono::steady_clock,boost::chrono::duration<long,boost::ratio<1l,1000000000l>>>(
           px,
           abs_time);
}


// Address: 0x1204910 | Name: _ZN5boost7promiseIvE9lazy_initEv
void __fastcall boost::promise<void>::lazy_init(boost::promise<void> *this)
{
  unsigned __int64 v1; // r13
  unsigned int v2; // ebx
  boost::shared_ptr<boost::detail::shared_state<void> >::element_type *px; // rbx
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_state<void>_0 *v5; // rbx
  boost::shared_ptr<boost::detail::shared_state<void> > v6; // rdx
  boost::detail::sp_counted_base *v7; // rbx
  volatile signed __int32 *tv_nsec; // rbx
  boost::shared_ptr<boost::detail::shared_state<void> > v9; // [rsp+0h] [rbp-58h] BYREF
  struct timespec requested_time; // [rsp+10h] [rbp-48h] BYREF
  __m128i v11[3]; // [rsp+20h] [rbp-38h] BYREF

  v1 = (unsigned __int64)this % 0x29;
  if ( _InterlockedExchange(&dword_29F1450[(unsigned __int64)this % 0x29], 1) )
  {
    v2 = 0;
    v11[0] = _mm_slli_si128((__m128i)0x3E8uLL, 8);
    do
    {
      if ( v2 >= 4 )
      {
        if ( v2 > 0xF )
        {
          if ( v2 < 0x20 || (v2 & 1) != 0 )
          {
            sched_yield();
          }
          else
          {
            requested_time = (struct timespec)_mm_load_si128(v11);
            nanosleep(&requested_time, 0);
          }
        }
        else
        {
          _mm_pause();
        }
      }
      ++v2;
    }
    while ( _InterlockedExchange(&dword_29F1450[v1], 1) );
  }
  px = this->future_.px;
  pi = this->future_.pn.pi_;
  if ( !pi )
  {
    dword_29F1450[v1] = 0;
    if ( px )
      return;
    goto LABEL_18;
  }
  _InterlockedAdd(&pi->use_count_, 1u);
  dword_29F1450[v1] = 0;
  if ( !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
  if ( !px )
  {
LABEL_18:
    requested_time = 0;
    v5 = (boost::detail::shared_state<void>_0 *)operator new(0x108u);
    boost::detail::shared_state_base::shared_state_base(v5);
    v5->_vptr$shared_state_base = (int (**)(void))&off_28A22C8;
    v9.px = v5;
    v9.pn.pi_ = 0;
    boost::detail::sp_pointer_construct<boost::detail::shared_state<void>,boost::detail::shared_state<void>>(
      &v9,
      v5,
      &v9.pn);
    v6.px = (boost::shared_ptr<boost::detail::shared_state<void> >::element_type *)&v9;
    boost::atomic_compare_exchange<boost::detail::shared_state<void>>(
      &this->future_,
      (boost::shared_ptr<boost::detail::shared_state<void> > *)&requested_time,
      v6);
    v7 = v9.pn.pi_;
    if ( v9.pn.pi_ )
    {
      if ( !_InterlockedSub(&v9.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
    tv_nsec = (volatile signed __int32 *)requested_time.tv_nsec;
    if ( requested_time.tv_nsec && !_InterlockedSub((volatile signed __int32 *)(requested_time.tv_nsec + 8), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)tv_nsec + 16LL))(tv_nsec);
      if ( !_InterlockedSub(tv_nsec + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)tv_nsec + 24LL))(tv_nsec);
    }
  }
}


// Address: 0x1204d50 | Name: _ZN5boost6detail12shared_stateIvED0Ev
void __fastcall boost::detail::shared_state<void>::~shared_state(boost::detail::shared_state<void>_0 *this)
{
  boost::detail::shared_state_base::~shared_state_base(this);
  operator delete(this);
}


// Address: 0x1204d70 | Name: _ZN5boost6detail12shared_stateIvE3getEv
void __fastcall boost::detail::shared_state<void>::get(boost::detail::shared_state<void>_0 *this)
{
  boost::unique_lock<boost::mutex> lk; // [rsp+8h] [rbp-20h] BYREF

  lk.m = &this->mutex;
  lk.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lk);
  boost::detail::shared_state_base::wait_internal(this, &lk, 1);
  if ( lk.is_locked )
    boost::mutex::unlock(lk.m);
}


// Address: 0x1204df0 | Name: _ZN5boost6detail12shared_stateIvE6get_shEv
void __fastcall boost::detail::shared_state<void>::get_sh(boost::detail::shared_state<void>_0 *this)
{
  boost::unique_lock<boost::mutex> lk; // [rsp+8h] [rbp-20h] BYREF

  lk.m = &this->mutex;
  lk.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lk);
  boost::detail::shared_state_base::wait_internal(this, &lk, 1);
  if ( lk.is_locked )
    boost::mutex::unlock(lk.m);
}


// Address: 0x1206590 | Name: _ZN5boost13shared_futureINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEC2EOS8_
void __fastcall boost::shared_future<std::string>::shared_future(
        boost::shared_future<std::string > *this,
        boost::shared_future<std::string > *other)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v3; // r14
  boost::shared_future<std::string > v4; // xmm0
  boost::detail::sp_counted_base *v5; // r14

  this->future_.px = other->future_.px;
  pi = other->future_.pn.pi_;
  this->future_.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v3 = other->future_.pn.pi_;
  v4 = 0;
  *other = 0;
  if ( v3 )
  {
    if ( !_InterlockedSub(&v3->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v3->_vptr$sp_counted_base + 2))(v3);
      v4 = 0;
      if ( !_InterlockedSub(&v3->weak_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *, double))v3->_vptr$sp_counted_base + 3))(v3, 0.0);
        v4 = 0;
      }
    }
    v5 = other->future_.pn.pi_;
  }
  else
  {
    v5 = 0;
  }
  *other = v4;
  if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
  }
}


// Address: 0x1208590 | Name: _ZN5boost7promiseIvED2Ev
void __fastcall boost::promise<void>::~promise(boost::promise<void> *this)
{
  boost::detail::sp_counted_base *pi; // rbx
  const boost::system::error_category *v2; // r15
  std::logic_error *exception; // r15
  boost::unique_lock<boost::mutex> v4; // [rsp+8h] [rbp-70h] BYREF
  _QWORD v5[2]; // [rsp+28h] [rbp-50h] BYREF
  __int128 v6; // [rsp+38h] [rbp-40h]
  _BYTE v7[16]; // [rsp+48h] [rbp-30h] BYREF
  void *ptr; // [rsp+58h] [rbp-20h]

  if ( this->future_.px )
  {
    v4.m = &this->future_.px->mutex;
    v4.is_locked = 0;
    boost::unique_lock<boost::mutex>::lock(&v4);
    if ( !this->future_.px->done && !this->future_.px->is_constructed )
    {
      v2 = boost::future_category();
      (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v2->_vptr$error_category + 3))(
        v7,
        v2,
        1);
      std::logic_error::logic_error(v5, v7);
      if ( (v7[0] & 1) != 0 )
        operator delete(ptr);
      LODWORD(v6) = 1;
      *((_QWORD *)&v6 + 1) = v2;
      v5[0] = off_2876850;
      exception = (std::logic_error *)__cxa_allocate_exception(0x28u);
      *((_QWORD *)exception + 4) = &off_2875618;
      std::logic_error::logic_error(exception, (const std::logic_error *)v5);
      *((_OWORD *)exception + 1) = v6;
      *(_QWORD *)exception = &off_28767D0;
      *((_QWORD *)exception + 4) = &off_2876820;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::broken_promise>,
        (void (*)(void *))std::logic_error::~logic_error);
    }
    if ( v4.is_locked )
      boost::mutex::unlock(v4.m);
  }
  pi = this->future_.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1208840 | Name: _ZN5boost6detail12basic_futureIvEaSEOS2_
boost::detail::basic_future<void> *__fastcall boost::detail::basic_future<void>::operator=(
        boost::detail::basic_future<void> *this,
        boost::detail::basic_future<void> *other)
{
  boost::shared_ptr<boost::detail::shared_state<void> >::element_type *px; // rcx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::detail::sp_counted_base *v5; // rbx

  px = other->future_.px;
  pi = other->future_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->future_.px = px;
  v4 = this->future_.pn.pi_;
  this->future_.pn.pi_ = pi;
  if ( v4 )
  {
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
  }
  v5 = other->future_.pn.pi_;
  *other = 0;
  if ( v5 )
  {
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  return this;
}


// Address: 0x12088e0 | Name: _ZN5boost7promiseIvE9set_valueEv
void __fastcall boost::promise<void>::set_value(boost::promise<void> *this)
{
  boost::shared_ptr<boost::detail::shared_state<void> >::element_type *px; // rdi
  const boost::system::error_category *v3; // rbx
  boost::unique_lock<boost::mutex> lock; // [rsp+8h] [rbp-50h] BYREF
  _BYTE v5[16]; // [rsp+18h] [rbp-40h] BYREF
  void *ptr; // [rsp+28h] [rbp-30h]
  _QWORD v7[2]; // [rsp+30h] [rbp-28h] BYREF
  int v8; // [rsp+40h] [rbp-18h]
  const boost::system::error_category *v9; // [rsp+48h] [rbp-10h]

  boost::promise<void>::lazy_init(this);
  lock.m = &this->future_.px->mutex;
  lock.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lock);
  px = this->future_.px;
  if ( this->future_.px->done )
  {
    v3 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v3->_vptr$error_category + 3))(
      v5,
      v3,
      3);
    std::logic_error::logic_error(v7, v5);
    if ( (v5[0] & 1) != 0 )
      operator delete(ptr);
    v8 = 3;
    v9 = v3;
    v7[0] = off_2878768;
    boost::throw_exception<boost::promise_already_satisfied>((const boost::promise_already_satisfied *)v7);
  }
  boost::detail::shared_state_base::mark_finished_internal(px, &lock);
  if ( lock.is_locked )
    boost::mutex::unlock(lock.m);
}


// Address: 0x1208a00 | Name: _ZN5boost13shared_futureIvEC2EOS1_
void __fastcall boost::shared_future<void>::shared_future(
        boost::shared_future<void> *this,
        boost::shared_future<void> *other)
{
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v3; // r14
  boost::shared_future<void> v4; // xmm0
  boost::detail::sp_counted_base *v5; // r14

  this->future_.px = other->future_.px;
  pi = other->future_.pn.pi_;
  this->future_.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v3 = other->future_.pn.pi_;
  v4 = 0;
  *other = 0;
  if ( v3 )
  {
    if ( !_InterlockedSub(&v3->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v3->_vptr$sp_counted_base + 2))(v3);
      v4 = 0;
      if ( !_InterlockedSub(&v3->weak_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *, double))v3->_vptr$sp_counted_base + 3))(v3, 0.0);
        v4 = 0;
      }
    }
    v5 = other->future_.pn.pi_;
  }
  else
  {
    v5 = 0;
  }
  *other = v4;
  if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
  }
}


// Address: 0x1208ab0 | Name: _ZN5boost6detail17shared_state_base10wait_untilINS_6chrono12steady_clockENS3_8durationIlNS_5ratioILl1ELl1000000000EEEEEEENS_13future_statusERKNS3_10time_pointIT_T0_EE
boost::future_status __fastcall boost::detail::shared_state_base::wait_until<boost::chrono::steady_clock,boost::chrono::duration<long,boost::ratio<1l,1000000000l>>>(
        boost::detail::shared_state_base_0 *this,
        const boost::chrono::time_point<boost::chrono::steady_clock,boost::chrono::duration<long,boost::ratio<1,1000000000> > > *abs_time)
{
  boost::future_status v2; // r14d
  boost::chrono::duration<long,boost::ratio<1,1000000000> >::rep rep; // r12
  boost::chrono::steady_clock::time_point v4; // rax
  boost::chrono::duration<long,boost::ratio<1,1000000000> >::rep v5; // rdx
  boost::chrono::duration<long,boost::ratio<1,1000000000> >::rep v6; // rax
  boost::chrono::steady_clock::time_point v7; // rax
  _BOOL4 done; // ecx
  boost::unique_lock<boost::mutex> lock; // [rsp+8h] [rbp-50h] BYREF
  timespec timeout; // [rsp+18h] [rbp-40h] BYREF

  lock.m = &this->mutex;
  lock.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lock);
  v2 = boost::future_status::deferred;
  if ( this->is_deferred_
    || (boost::detail::shared_state_base::do_callback(this, &lock), v2 = boost::future_status::ready, this->done) )
  {
LABEL_5:
    if ( !lock.is_locked )
      return v2;
LABEL_6:
    boost::mutex::unlock(lock.m);
    return v2;
  }
  while ( 1 )
  {
    rep = boost::chrono::system_clock::now().d_.rep_;
    v4.d_.rep_ = boost::chrono::steady_clock::now().d_.rep_;
    v5 = (rep + abs_time->d_.rep_ - v4.d_.rep_) / 1000000000;
    v6 = (rep + abs_time->d_.rep_ - v4.d_.rep_) % 1000000000;
    timeout.tv_sec = v5;
    timeout.tv_nsec = v6;
    boost::condition_variable::do_wait_until(&this->waiters, &lock, &timeout);
    v7.d_.rep_ = boost::chrono::steady_clock::now().d_.rep_;
    done = this->done;
    if ( v7.d_.rep_ >= abs_time->d_.rep_ )
      break;
    if ( done )
      goto LABEL_5;
  }
  v2 = !done;
  if ( lock.is_locked )
    goto LABEL_6;
  return v2;
}


// Address: 0x1284aa0 | Name: _ZN5boost7promiseINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEE9set_valueERKS7_
void __fastcall boost::promise<std::string>::set_value(
        boost::promise<std::string > *this,
        boost::detail::future_traits<std::string >::source_reference_type r)
{
  boost::detail::shared_state<std::string > *px; // rdi
  const boost::system::error_category *v4; // rbx
  boost::unique_lock<boost::mutex> v5; // [rsp+0h] [rbp-58h] BYREF
  _BYTE v6[16]; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]
  _QWORD v8[2]; // [rsp+28h] [rbp-30h] BYREF
  int v9; // [rsp+38h] [rbp-20h]
  const boost::system::error_category *v10; // [rsp+40h] [rbp-18h]

  boost::promise<std::string>::lazy_init(this);
  v5.m = &this->future_.px->mutex;
  v5.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v5);
  px = this->future_.px;
  if ( this->future_.px->done )
  {
    v4 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v4->_vptr$error_category + 3))(
      v6,
      v4,
      3);
    std::logic_error::logic_error(v8, v6);
    if ( (v6[0] & 1) != 0 )
      operator delete(ptr);
    v9 = 3;
    v10 = v4;
    v8[0] = off_2878768;
    boost::throw_exception<boost::promise_already_satisfied>((const boost::promise_already_satisfied *)v8);
  }
  boost::detail::shared_state<std::string>::mark_finished_with_result_internal(px, r, &v5);
  if ( v5.is_locked )
    boost::mutex::unlock(v5.m);
}


// Address: 0x1284bc0 | Name: _ZN5boost6detail12shared_stateINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEE34mark_finished_with_result_internalERKS8_RNS_11unique_lockINS_5mutexEEE
void __fastcall boost::detail::shared_state<std::string>::mark_finished_with_result_internal(
        boost::detail::shared_state<std::string > *this,
        boost::detail::shared_state<std::string >::source_reference_type_0 result_,
        boost::unique_lock<boost::mutex> *lock)
{
  std::string *v4; // r12
  std::string *px; // rbx

  v4 = (std::string *)operator new(0x18u);
  std::string::basic_string(v4, result_);
  px = this->result.px;
  this->result.px = v4;
  if ( px )
  {
    if ( (*(_BYTE *)px & 1) != 0 )
      operator delete(*((void **)px + 2));
    operator delete(px);
  }
  boost::detail::shared_state_base::mark_finished_internal(this, lock);
}


// Address: 0x129edc0 | Name: _ZN5boost7promiseINS_10shared_ptrIN3RBX12HttpResponseEEEE10get_futureEv
boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type **__fastcall boost::promise<boost::shared_ptr<RBX::HttpResponse>>::get_future(
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type **a1,
        boost::promise<boost::shared_ptr<RBX::HttpResponse> > *this)
{
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type *px; // rax
  boost::detail::sp_counted_base *pi; // rbx
  const boost::system::error_category *v5; // rbx
  const boost::system::error_category *v6; // rbx
  _BYTE v7[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  _QWORD v9[2]; // [rsp+18h] [rbp-30h] BYREF
  int v10; // [rsp+28h] [rbp-20h]
  const boost::system::error_category *v11; // [rsp+30h] [rbp-18h]

  boost::promise<boost::shared_ptr<RBX::HttpResponse>>::lazy_init(this);
  px = this->future_.px;
  if ( !this->future_.px )
  {
    v5 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v5->_vptr$error_category + 3))(
      v7,
      v5,
      4);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 4;
    v11 = v5;
    v9[0] = off_2878AC8;
    boost::throw_exception<boost::promise_moved>((const boost::promise_moved *)v9);
  }
  if ( this->future_obtained )
  {
    v6 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v6->_vptr$error_category + 3))(
      v7,
      v6,
      2);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 2;
    v11 = v6;
    v9[0] = off_2878C78;
    boost::throw_exception<boost::future_already_retrieved>((const boost::future_already_retrieved *)v9);
  }
  this->future_obtained = 1;
  pi = this->future_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    _InterlockedAdd(&pi->use_count_, 1u);
    *a1 = px;
    a1[1] = (boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type *)pi;
    _InterlockedAdd(&pi->use_count_, 1u);
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  else
  {
    *a1 = px;
    a1[1] = 0;
  }
  return a1;
}


// Address: 0x129f3c0 | Name: _ZN5boost7promiseINS_10shared_ptrIN3RBX12HttpResponseEEEED2Ev
void __fastcall boost::promise<boost::shared_ptr<RBX::HttpResponse>>::~promise(
        boost::promise<boost::shared_ptr<RBX::HttpResponse> > *this)
{
  boost::detail::sp_counted_base *pi; // rbx
  const boost::system::error_category *v2; // r15
  std::logic_error *exception; // r15
  boost::unique_lock<boost::mutex> v4; // [rsp+8h] [rbp-70h] BYREF
  _QWORD v5[2]; // [rsp+28h] [rbp-50h] BYREF
  __int128 v6; // [rsp+38h] [rbp-40h]
  _BYTE v7[16]; // [rsp+48h] [rbp-30h] BYREF
  void *ptr; // [rsp+58h] [rbp-20h]

  if ( this->future_.px )
  {
    v4.m = &this->future_.px->mutex;
    v4.is_locked = 0;
    boost::unique_lock<boost::mutex>::lock(&v4);
    if ( !this->future_.px->done && !this->future_.px->is_constructed )
    {
      v2 = boost::future_category();
      (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v2->_vptr$error_category + 3))(
        v7,
        v2,
        1);
      std::logic_error::logic_error(v5, v7);
      if ( (v7[0] & 1) != 0 )
        operator delete(ptr);
      LODWORD(v6) = 1;
      *((_QWORD *)&v6 + 1) = v2;
      v5[0] = off_2876850;
      exception = (std::logic_error *)__cxa_allocate_exception(0x28u);
      *((_QWORD *)exception + 4) = &off_2875618;
      std::logic_error::logic_error(exception, (const std::logic_error *)v5);
      *((_OWORD *)exception + 1) = v6;
      *(_QWORD *)exception = &off_28767D0;
      *((_QWORD *)exception + 4) = &off_2876820;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::broken_promise>,
        (void (*)(void *))std::logic_error::~logic_error);
    }
    if ( v4.is_locked )
      boost::mutex::unlock(v4.m);
  }
  pi = this->future_.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x129f6b0 | Name: _ZN5boost7promiseINS_10shared_ptrIN3RBX12HttpResponseEEEE9set_valueEOS4_
void __fastcall boost::promise<boost::shared_ptr<RBX::HttpResponse>>::set_value(
        boost::promise<boost::shared_ptr<RBX::HttpResponse> > *this,
        boost::detail::future_traits<boost::shared_ptr<RBX::HttpResponse> >::rvalue_source_type r)
{
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type *px; // rdi
  const boost::system::error_category *v4; // rbx
  boost::unique_lock<boost::mutex> v5; // [rsp+0h] [rbp-58h] BYREF
  _BYTE v6[16]; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]
  _QWORD v8[2]; // [rsp+28h] [rbp-30h] BYREF
  int v9; // [rsp+38h] [rbp-20h]
  const boost::system::error_category *v10; // [rsp+40h] [rbp-18h]

  boost::promise<boost::shared_ptr<RBX::HttpResponse>>::lazy_init(this);
  v5.m = &this->future_.px->mutex;
  v5.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v5);
  px = this->future_.px;
  if ( this->future_.px->done )
  {
    v4 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v4->_vptr$error_category + 3))(
      v6,
      v4,
      3);
    std::logic_error::logic_error(v8, v6);
    if ( (v6[0] & 1) != 0 )
      operator delete(ptr);
    v9 = 3;
    v10 = v4;
    v8[0] = off_2878768;
    boost::throw_exception<boost::promise_already_satisfied>((const boost::promise_already_satisfied *)v8);
  }
  boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>::mark_finished_with_result_internal(px, r, &v5);
  if ( v5.is_locked )
    boost::mutex::unlock(v5.m);
}


// Address: 0x129f7d0 | Name: _ZN5boost7promiseINS_10shared_ptrIN3RBX12HttpResponseEEEE9lazy_initEv
void __fastcall boost::promise<boost::shared_ptr<RBX::HttpResponse>>::lazy_init(
        boost::promise<boost::shared_ptr<RBX::HttpResponse> > *this)
{
  unsigned __int64 v1; // r13
  unsigned int v2; // ebx
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type *px; // rbx
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *v5; // rbx
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > > v6; // rdx
  boost::detail::sp_counted_base *v7; // rbx
  volatile signed __int32 *tv_nsec; // rbx
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > > v9; // [rsp+0h] [rbp-58h] BYREF
  struct timespec requested_time; // [rsp+10h] [rbp-48h] BYREF
  __m128i v11[3]; // [rsp+20h] [rbp-38h] BYREF

  v1 = (unsigned __int64)this % 0x29;
  if ( _InterlockedExchange(&dword_29F1450[(unsigned __int64)this % 0x29], 1) )
  {
    v2 = 0;
    v11[0] = _mm_slli_si128((__m128i)0x3E8uLL, 8);
    do
    {
      if ( v2 >= 4 )
      {
        if ( v2 > 0xF )
        {
          if ( v2 < 0x20 || (v2 & 1) != 0 )
          {
            sched_yield();
          }
          else
          {
            requested_time = (struct timespec)_mm_load_si128(v11);
            nanosleep(&requested_time, 0);
          }
        }
        else
        {
          _mm_pause();
        }
      }
      ++v2;
    }
    while ( _InterlockedExchange(&dword_29F1450[v1], 1) );
  }
  px = this->future_.px;
  pi = this->future_.pn.pi_;
  if ( !pi )
  {
    dword_29F1450[v1] = 0;
    if ( px )
      return;
    goto LABEL_18;
  }
  _InterlockedAdd(&pi->use_count_, 1u);
  dword_29F1450[v1] = 0;
  if ( !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
  if ( !px )
  {
LABEL_18:
    requested_time = 0;
    v5 = (boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *)operator new(0x110u);
    boost::detail::shared_state_base::shared_state_base(v5);
    v5->_vptr$shared_state_base = (int (**)(void))off_28A6148;
    v5->result.px = 0;
    v9.px = v5;
    v9.pn.pi_ = 0;
    boost::detail::sp_pointer_construct<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>,boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>>(
      &v9,
      v5,
      &v9.pn);
    v6.px = (boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > >::element_type *)&v9;
    boost::atomic_compare_exchange<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>>(
      &this->future_,
      (boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> > > *)&requested_time,
      v6);
    v7 = v9.pn.pi_;
    if ( v9.pn.pi_ )
    {
      if ( !_InterlockedSub(&v9.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
    tv_nsec = (volatile signed __int32 *)requested_time.tv_nsec;
    if ( requested_time.tv_nsec && !_InterlockedSub((volatile signed __int32 *)(requested_time.tv_nsec + 8), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)tv_nsec + 16LL))(tv_nsec);
      if ( !_InterlockedSub(tv_nsec + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)tv_nsec + 24LL))(tv_nsec);
    }
  }
}


// Address: 0x129fa80 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrIN3RBX12HttpResponseEEEE34mark_finished_with_result_internalEOS5_RNS_11unique_lockINS_5mutexEEE
void __fastcall boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>::mark_finished_with_result_internal(
        boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *this,
        boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >::rvalue_source_type result_,
        boost::unique_lock<boost::mutex> *lock)
{
  boost::shared_ptr<RBX::HttpResponse> *v4; // rax
  boost::shared_ptr<RBX::HttpResponse> v5; // xmm0
  boost::shared_ptr<RBX::HttpResponse> *px; // rbx
  volatile signed __int32 *pi; // r12

  v4 = (boost::shared_ptr<RBX::HttpResponse> *)operator new(0x10u);
  v5 = *result_;
  result_->pn.pi_ = 0;
  *v4 = v5;
  result_->px = 0;
  px = this->result.px;
  this->result.px = v4;
  if ( px )
  {
    pi = (volatile signed __int32 *)px->pn.pi_;
    if ( pi )
    {
      if ( !_InterlockedSub(pi + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
        if ( !_InterlockedSub(pi + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
      }
    }
    operator delete(px);
  }
  boost::detail::shared_state_base::mark_finished_internal(this, lock);
}


// Address: 0x129fc80 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrIN3RBX12HttpResponseEEEED2Ev
void __fastcall boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>::~shared_state(
        boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *this)
{
  boost::shared_ptr<RBX::HttpResponse> *px; // r14
  volatile signed __int32 *pi; // r15

  this->_vptr$shared_state_base = (int (**)(void))off_28A6148;
  px = this->result.px;
  if ( px )
  {
    pi = (volatile signed __int32 *)px->pn.pi_;
    if ( pi )
    {
      if ( !_InterlockedSub(pi + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
        if ( !_InterlockedSub(pi + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
      }
    }
    operator delete(px);
  }
  boost::detail::shared_state_base::~shared_state_base(this);
}


// Address: 0x129fcf0 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrIN3RBX12HttpResponseEEEED0Ev
void __fastcall boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>::~shared_state(
        boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *this)
{
  boost::shared_ptr<RBX::HttpResponse> *px; // r14
  volatile signed __int32 *pi; // r15

  this->_vptr$shared_state_base = (int (**)(void))off_28A6148;
  px = this->result.px;
  if ( px )
  {
    pi = (volatile signed __int32 *)px->pn.pi_;
    if ( pi )
    {
      if ( !_InterlockedSub(pi + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
        if ( !_InterlockedSub(pi + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
      }
    }
    operator delete(px);
  }
  boost::detail::shared_state_base::~shared_state_base(this);
  operator delete(this);
}


// Address: 0x129fd60 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrIN3RBX12HttpResponseEEEE3getEv
boost::shared_ptr<RBX::HttpResponse> *__fastcall boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>::get(
        boost::shared_ptr<RBX::HttpResponse> *a1,
        boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *this)
{
  boost::shared_ptr<RBX::HttpResponse> *px; // rax
  boost::shared_ptr<RBX::HttpResponse> v3; // xmm0
  boost::unique_lock<boost::mutex> v5[2]; // [rsp+0h] [rbp-28h] BYREF

  v5[0].m = &this->mutex;
  v5[0].is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(v5);
  boost::detail::shared_state_base::wait_internal(this, v5, 1);
  px = this->result.px;
  v3 = *px;
  px->pn.pi_ = 0;
  *a1 = v3;
  px->px = 0;
  if ( v5[0].is_locked )
    boost::mutex::unlock(v5[0].m);
  return a1;
}


// Address: 0x129fe00 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrIN3RBX12HttpResponseEEEE6get_shEv
boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >::shared_future_get_result_type __fastcall boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse>>::get_sh(
        boost::detail::shared_state<boost::shared_ptr<RBX::HttpResponse> >_0 *this)
{
  boost::shared_ptr<RBX::HttpResponse> *px; // rbx
  boost::unique_lock<boost::mutex> lk; // [rsp+8h] [rbp-20h] BYREF

  lk.m = &this->mutex;
  lk.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lk);
  boost::detail::shared_state_base::wait_internal(this, &lk, 1);
  px = this->result.px;
  if ( lk.is_locked )
    boost::mutex::unlock(lk.m);
  return px;
}


// Address: 0x1586a50 | Name: _ZN5boost7promiseINS_10shared_ptrINSt3__16vectorINS1_INS3_INS1_IN3RBX8InstanceEEENS2_9allocatorIS6_EEEEEENS7_ISA_EEEEEEE10get_futureEv
boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type **__fastcall boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::get_future(
        boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type **a1,
        boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this)
{
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type *px; // rax
  boost::detail::sp_counted_base *pi; // rbx
  const boost::system::error_category *v5; // rbx
  const boost::system::error_category *v6; // rbx
  _BYTE v7[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  _QWORD v9[2]; // [rsp+18h] [rbp-30h] BYREF
  int v10; // [rsp+28h] [rbp-20h]
  const boost::system::error_category *v11; // [rsp+30h] [rbp-18h]

  boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::lazy_init(this);
  px = this->future_.px;
  if ( !this->future_.px )
  {
    v5 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v5->_vptr$error_category + 3))(
      v7,
      v5,
      4);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 4;
    v11 = v5;
    v9[0] = off_2878AC8;
    boost::throw_exception<boost::promise_moved>((const boost::promise_moved *)v9);
  }
  if ( this->future_obtained )
  {
    v6 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v6->_vptr$error_category + 3))(
      v7,
      v6,
      2);
    std::logic_error::logic_error(v9, v7);
    if ( (v7[0] & 1) != 0 )
      operator delete(ptr);
    v10 = 2;
    v11 = v6;
    v9[0] = off_2878C78;
    boost::throw_exception<boost::future_already_retrieved>((const boost::future_already_retrieved *)v9);
  }
  this->future_obtained = 1;
  pi = this->future_.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    _InterlockedAdd(&pi->use_count_, 1u);
    *a1 = px;
    a1[1] = (boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type *)pi;
    _InterlockedAdd(&pi->use_count_, 1u);
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  else
  {
    *a1 = px;
    a1[1] = 0;
  }
  return a1;
}


// Address: 0x1587ff0 | Name: _ZN5boost7promiseIvEaSEOS1_
boost::promise<void> *__fastcall boost::promise<void>::operator=(boost::promise<void> *this, boost::promise<void> *rhs)
{
  boost::shared_ptr<boost::detail::shared_state<void> >::element_type *px; // rcx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::detail::sp_counted_base *v5; // rbx

  px = rhs->future_.px;
  pi = rhs->future_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->future_.px = px;
  v4 = this->future_.pn.pi_;
  this->future_.pn.pi_ = pi;
  if ( v4 )
  {
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
  }
  this->future_obtained = rhs->future_obtained;
  v5 = rhs->future_.pn.pi_;
  rhs->future_ = 0;
  if ( v5 )
  {
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  rhs->future_obtained = 0;
  return this;
}


// Address: 0x15a41e0 | Name: _ZN5boost7promiseINS_10shared_ptrINSt3__16vectorINS1_INS3_INS1_IN3RBX8InstanceEEENS2_9allocatorIS6_EEEEEENS7_ISA_EEEEEEED2Ev
void __fastcall boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::~promise(
        boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this)
{
  boost::detail::sp_counted_base *pi; // rbx
  const boost::system::error_category *v2; // r15
  std::logic_error *exception; // r15
  boost::unique_lock<boost::mutex> v4; // [rsp+8h] [rbp-70h] BYREF
  _QWORD v5[2]; // [rsp+28h] [rbp-50h] BYREF
  __int128 v6; // [rsp+38h] [rbp-40h]
  _BYTE v7[16]; // [rsp+48h] [rbp-30h] BYREF
  void *ptr; // [rsp+58h] [rbp-20h]

  if ( this->future_.px )
  {
    v4.m = &this->future_.px->mutex;
    v4.is_locked = 0;
    boost::unique_lock<boost::mutex>::lock(&v4);
    if ( !this->future_.px->done && !this->future_.px->is_constructed )
    {
      v2 = boost::future_category();
      (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v2->_vptr$error_category + 3))(
        v7,
        v2,
        1);
      std::logic_error::logic_error(v5, v7);
      if ( (v7[0] & 1) != 0 )
        operator delete(ptr);
      LODWORD(v6) = 1;
      *((_QWORD *)&v6 + 1) = v2;
      v5[0] = off_2876850;
      exception = (std::logic_error *)__cxa_allocate_exception(0x28u);
      *((_QWORD *)exception + 4) = &off_2875618;
      std::logic_error::logic_error(exception, (const std::logic_error *)v5);
      *((_OWORD *)exception + 1) = v6;
      *(_QWORD *)exception = &off_28767D0;
      *((_QWORD *)exception + 4) = &off_2876820;
      __cxa_throw(
        exception,
        (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::broken_promise>,
        (void (*)(void *))std::logic_error::~logic_error);
    }
    if ( v4.is_locked )
      boost::mutex::unlock(v4.m);
  }
  pi = this->future_.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x15a44d0 | Name: _ZN5boost7promiseINS_10shared_ptrINSt3__16vectorINS1_INS3_INS1_IN3RBX8InstanceEEENS2_9allocatorIS6_EEEEEENS7_ISA_EEEEEEE9lazy_initEv
void __fastcall boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::lazy_init(
        boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this)
{
  unsigned __int64 v1; // r13
  unsigned int v2; // ebx
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type *px; // rbx
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *v5; // rbx
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > > v6; // rdx
  boost::detail::sp_counted_base *v7; // rbx
  volatile signed __int32 *tv_nsec; // rbx
  boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > > v9; // [rsp+0h] [rbp-58h] BYREF
  struct timespec requested_time; // [rsp+10h] [rbp-48h] BYREF
  __m128i v11[3]; // [rsp+20h] [rbp-38h] BYREF

  v1 = (unsigned __int64)this % 0x29;
  if ( _InterlockedExchange(&dword_29F1450[(unsigned __int64)this % 0x29], 1) )
  {
    v2 = 0;
    v11[0] = _mm_slli_si128((__m128i)0x3E8uLL, 8);
    do
    {
      if ( v2 >= 4 )
      {
        if ( v2 > 0xF )
        {
          if ( v2 < 0x20 || (v2 & 1) != 0 )
          {
            sched_yield();
          }
          else
          {
            requested_time = (struct timespec)_mm_load_si128(v11);
            nanosleep(&requested_time, 0);
          }
        }
        else
        {
          _mm_pause();
        }
      }
      ++v2;
    }
    while ( _InterlockedExchange(&dword_29F1450[v1], 1) );
  }
  px = this->future_.px;
  pi = this->future_.pn.pi_;
  if ( !pi )
  {
    dword_29F1450[v1] = 0;
    if ( px )
      return;
    goto LABEL_18;
  }
  _InterlockedAdd(&pi->use_count_, 1u);
  dword_29F1450[v1] = 0;
  if ( !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
  if ( !px )
  {
LABEL_18:
    requested_time = 0;
    v5 = (boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *)operator new(0x110u);
    boost::detail::shared_state_base::shared_state_base(v5);
    v5->_vptr$shared_state_base = (int (**)(void))off_28C6FD8;
    v5->result.px = 0;
    v9.px = v5;
    v9.pn.pi_ = 0;
    boost::detail::sp_pointer_construct<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>,boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>>(
      &v9,
      v5,
      &v9.pn);
    v6.px = (boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > >::element_type *)&v9;
    boost::atomic_compare_exchange<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>>(
      &this->future_,
      (boost::shared_ptr<boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > > *)&requested_time,
      v6);
    v7 = v9.pn.pi_;
    if ( v9.pn.pi_ )
    {
      if ( !_InterlockedSub(&v9.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 2))(v7);
        if ( !_InterlockedSub(&v7->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v7->_vptr$sp_counted_base + 3))(v7);
      }
    }
    tv_nsec = (volatile signed __int32 *)requested_time.tv_nsec;
    if ( requested_time.tv_nsec && !_InterlockedSub((volatile signed __int32 *)(requested_time.tv_nsec + 8), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)tv_nsec + 16LL))(tv_nsec);
      if ( !_InterlockedSub(tv_nsec + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)tv_nsec + 24LL))(tv_nsec);
    }
  }
}


// Address: 0x15a48e0 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrINSt3__16vectorINS2_INS4_INS2_IN3RBX8InstanceEEENS3_9allocatorIS7_EEEEEENS8_ISB_EEEEEEED2Ev
void __fastcall boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::~shared_state(
        boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this)
{
  boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *px; // r14
  volatile signed __int32 *pi; // r15

  this->_vptr$shared_state_base = (int (**)(void))off_28C6FD8;
  px = this->result.px;
  if ( px )
  {
    pi = (volatile signed __int32 *)px->pn.pi_;
    if ( pi )
    {
      if ( !_InterlockedSub(pi + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
        if ( !_InterlockedSub(pi + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
      }
    }
    operator delete(px);
  }
  boost::detail::shared_state_base::~shared_state_base(this);
}


// Address: 0x15a4950 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrINSt3__16vectorINS2_INS4_INS2_IN3RBX8InstanceEEENS3_9allocatorIS7_EEEEEENS8_ISB_EEEEEEED0Ev
void __fastcall boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::~shared_state(
        boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this)
{
  boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *px; // r14
  volatile signed __int32 *pi; // r15

  this->_vptr$shared_state_base = (int (**)(void))off_28C6FD8;
  px = this->result.px;
  if ( px )
  {
    pi = (volatile signed __int32 *)px->pn.pi_;
    if ( pi )
    {
      if ( !_InterlockedSub(pi + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
        if ( !_InterlockedSub(pi + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
      }
    }
    operator delete(px);
  }
  boost::detail::shared_state_base::~shared_state_base(this);
  operator delete(this);
}


// Address: 0x15a49c0 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrINSt3__16vectorINS2_INS4_INS2_IN3RBX8InstanceEEENS3_9allocatorIS7_EEEEEENS8_ISB_EEEEEEE3getEv
boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *__fastcall boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::get(
        boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *a1,
        boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this)
{
  boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *px; // rax
  boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > v3; // xmm0
  boost::unique_lock<boost::mutex> v5[2]; // [rsp+0h] [rbp-28h] BYREF

  v5[0].m = &this->mutex;
  v5[0].is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(v5);
  boost::detail::shared_state_base::wait_internal(this, v5, 1);
  px = this->result.px;
  v3 = *px;
  px->pn.pi_ = 0;
  *a1 = v3;
  px->px = 0;
  if ( v5[0].is_locked )
    boost::mutex::unlock(v5[0].m);
  return a1;
}


// Address: 0x15a4a60 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrINSt3__16vectorINS2_INS4_INS2_IN3RBX8InstanceEEENS3_9allocatorIS7_EEEEEENS8_ISB_EEEEEEE6get_shEv
boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > >::shared_future_get_result_type __fastcall boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::get_sh(
        boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this)
{
  boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *px; // rbx
  boost::unique_lock<boost::mutex> lk; // [rsp+8h] [rbp-20h] BYREF

  lk.m = &this->mutex;
  lk.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lk);
  boost::detail::shared_state_base::wait_internal(this, &lk, 1);
  px = this->result.px;
  if ( lk.is_locked )
    boost::mutex::unlock(lk.m);
  return px;
}


// Address: 0x15a4ca0 | Name: _ZN5boost7promiseINS_10shared_ptrINSt3__16vectorINS1_INS3_INS1_IN3RBX8InstanceEEENS2_9allocatorIS6_EEEEEENS7_ISA_EEEEEEE9set_valueERKSD_
void __fastcall boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::set_value(
        boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this,
        boost::detail::future_traits<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > >::source_reference_type r)
{
  boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *px; // rdi
  const boost::system::error_category *v4; // rbx
  boost::unique_lock<boost::mutex> v5; // [rsp+0h] [rbp-58h] BYREF
  _BYTE v6[16]; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]
  _QWORD v8[2]; // [rsp+28h] [rbp-30h] BYREF
  int v9; // [rsp+38h] [rbp-20h]
  const boost::system::error_category *v10; // [rsp+40h] [rbp-18h]

  boost::promise<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::lazy_init(this);
  v5.m = &this->future_.px->mutex;
  v5.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v5);
  px = this->future_.px;
  if ( this->future_.px->done )
  {
    v4 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v4->_vptr$error_category + 3))(
      v6,
      v4,
      3);
    std::logic_error::logic_error(v8, v6);
    if ( (v6[0] & 1) != 0 )
      operator delete(ptr);
    v9 = 3;
    v10 = v4;
    v8[0] = off_2878768;
    boost::throw_exception<boost::promise_already_satisfied>((const boost::promise_already_satisfied *)v8);
  }
  boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::mark_finished_with_result_internal(
    px,
    r,
    &v5);
  if ( v5.is_locked )
    boost::mutex::unlock(v5.m);
}


// Address: 0x15a4dc0 | Name: _ZN5boost6detail12shared_stateINS_10shared_ptrINSt3__16vectorINS2_INS4_INS2_IN3RBX8InstanceEEENS3_9allocatorIS7_EEEEEENS8_ISB_EEEEEEE34mark_finished_with_result_internalERKSE_RNS_11unique_lockINS_5mutexEEE
void __fastcall boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>>>>>>::mark_finished_with_result_internal(
        boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > > *this,
        boost::detail::shared_state<boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > >::source_reference_type result_,
        boost::unique_lock<boost::mutex> *lock)
{
  boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *v4; // rax
  boost::detail::sp_counted_base *pi; // rcx
  boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *px; // rbx
  volatile signed __int32 *v7; // r12

  v4 = (boost::shared_ptr<std::vector<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >> > *)operator new(0x10u);
  v4->px = result_->px;
  pi = result_->pn.pi_;
  v4->pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  px = this->result.px;
  this->result.px = v4;
  if ( px )
  {
    v7 = (volatile signed __int32 *)px->pn.pi_;
    if ( v7 )
    {
      if ( !_InterlockedSub(v7 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
        if ( !_InterlockedSub(v7 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
      }
    }
    operator delete(px);
  }
  boost::detail::shared_state_base::mark_finished_internal(this, lock);
}


// Address: 0x173de90 | Name: _ZN5boost13shared_futureINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEE3getEv
boost::detail::shared_state<std::string >::shared_future_get_result_type __fastcall boost::shared_future<std::string>::get(
        boost::shared_future<std::string > *this)
{
  boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *px; // rdi
  const boost::system::error_category *v3; // rbx
  _BYTE v4[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  _QWORD v6[2]; // [rsp+18h] [rbp-30h] BYREF
  int v7; // [rsp+28h] [rbp-20h]
  const boost::system::error_category *v8; // [rsp+30h] [rbp-18h]

  px = this->future_.px;
  if ( !px )
  {
    v3 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v3->_vptr$error_category + 3))(
      v4,
      v3,
      4);
    std::logic_error::logic_error(v6, v4);
    if ( (v4[0] & 1) != 0 )
      operator delete(ptr);
    v7 = 4;
    v8 = v3;
    v6[0] = off_2878E28;
    boost::throw_exception<boost::future_uninitialized>((const boost::future_uninitialized *)v6);
  }
  return (*((boost::detail::shared_state<std::string >::shared_future_get_result_type (__fastcall **)(boost::shared_ptr<boost::detail::shared_state<std::string > >::element_type *))px->_vptr$shared_state_base
          + 6))(px);
}


// Address: 0x1b301b0 | Name: _ZN5boost13shared_futureIvE3getEv
boost::detail::shared_state<void>::shared_future_get_result_type __fastcall boost::shared_future<void>::get(
        boost::shared_future<void> *this)
{
  boost::shared_ptr<boost::detail::shared_state<void> >::element_type *px; // rdi
  const boost::system::error_category *v2; // rbx
  _BYTE v3[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  _QWORD v5[2]; // [rsp+18h] [rbp-30h] BYREF
  int v6; // [rsp+28h] [rbp-20h]
  const boost::system::error_category *v7; // [rsp+30h] [rbp-18h]

  px = this->future_.px;
  if ( !px )
  {
    v2 = boost::future_category();
    (*((void (__fastcall **)(_BYTE *, const boost::system::error_category *, __int64))v2->_vptr$error_category + 3))(
      v3,
      v2,
      4);
    std::logic_error::logic_error(v5, v3);
    if ( (v3[0] & 1) != 0 )
      operator delete(ptr);
    v6 = 4;
    v7 = v2;
    v5[0] = off_2878E28;
    boost::throw_exception<boost::future_uninitialized>((const boost::future_uninitialized *)v5);
  }
  (*((void (__fastcall **)(boost::shared_ptr<boost::detail::shared_state<void> >::element_type *))px->_vptr$shared_state_base
   + 6))(px);
}


// Address: 0x28455b0 | Name: _ZN5boost6detail17shared_state_base10make_readyEv
void __fastcall boost::detail::shared_state_base::make_ready(boost::detail::shared_state_base *this)
{
  boost::unique_lock<boost::mutex> lock; // [rsp+8h] [rbp-20h] BYREF

  lock.m = &this->mutex;
  lock.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&lock);
  boost::detail::shared_state_base::mark_finished_internal(this, &lock);
  if ( lock.is_locked )
    boost::mutex::unlock(lock.m);
}


