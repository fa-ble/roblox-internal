// Address: 0xfe8c00 | Name: _ZN5boost9gregorian9bad_monthD0Ev
void __fastcall boost::gregorian::bad_month::~bad_month(boost::gregorian::bad_month *this)
{
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


