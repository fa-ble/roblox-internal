// Address: 0x26062e0 | Name: _ZN5boost4asio15basic_io_objectINS0_22deadline_timer_serviceINS_10posix_time5ptimeENS0_11time_traitsIS4_EEEELb0EED2Ev
void __fastcall boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>,false>::~basic_io_object(
        boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false> *this)
{
  boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false>::service_type *service; // rbx
  boost::asio::detail::wait_op *i; // rbx
  boost::asio::detail::wait_op *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v5; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v6; // [rsp+10h] [rbp-28h]

  service = this->service;
  boost::system::system_category();
  if ( this->implementation.might_have_pending_waits )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::time_traits<boost::posix_time::ptime>>(
      *((boost::asio::detail::epoll_reactor **)service + 13),
      (boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false>::service_type *)((char *)service + 40),
      &this->implementation.timer_data,
      0xFFFFFFFFFFFFFFFFLL);
    this->implementation.might_have_pending_waits = 0;
  }
  boost::system::system_category();
  for ( i = this->implementation.timer_data.op_queue_.front_; i; i = this->implementation.timer_data.op_queue_.front_ )
  {
    next = (boost::asio::detail::wait_op *)i->next_;
    this->implementation.timer_data.op_queue_.front_ = (boost::asio::detail::wait_op *)i->next_;
    if ( !next )
      this->implementation.timer_data.op_queue_.back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v5 = 0;
    v6 = boost::system::system_category();
    func(0, i, &v5, 0);
  }
}


// Address: 0x2697820 | Name: _ZN5boost4asio15basic_io_objectINS0_22waitable_timer_serviceINSt3__16chrono12steady_clockENS0_11wait_traitsIS5_EEEELb0EED2Ev
void __fastcall boost::asio::basic_io_object<boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>,false>::~basic_io_object(
        boost::asio::basic_io_object<boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> >,false> *this)
{
  boost::asio::basic_io_object<boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> >,false>::service_type *service; // rbx
  boost::asio::detail::wait_op *i; // rbx
  boost::asio::detail::wait_op *next; // rax
  void (__fastcall *func)(_QWORD, _QWORD, _QWORD, _QWORD); // r12
  int v5; // [rsp+8h] [rbp-30h] BYREF
  const boost::system::error_category *v6; // [rsp+10h] [rbp-28h]

  service = this->service;
  boost::system::system_category();
  if ( this->implementation.might_have_pending_waits )
  {
    boost::asio::detail::epoll_reactor::cancel_timer<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>(
      *((boost::asio::detail::epoll_reactor **)service + 11),
      (boost::asio::basic_io_object<boost::asio::waitable_timer_service<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> >,false>::service_type *)((char *)service + 40),
      &this->implementation.timer_data,
      0xFFFFFFFFFFFFFFFFLL);
    this->implementation.might_have_pending_waits = 0;
  }
  boost::system::system_category();
  for ( i = this->implementation.timer_data.op_queue_.front_; i; i = this->implementation.timer_data.op_queue_.front_ )
  {
    next = (boost::asio::detail::wait_op *)i->next_;
    this->implementation.timer_data.op_queue_.front_ = (boost::asio::detail::wait_op *)i->next_;
    if ( !next )
      this->implementation.timer_data.op_queue_.back_ = 0;
    i->next_ = 0;
    func = (void (__fastcall *)(_QWORD, _QWORD, _QWORD, _QWORD))i->func_;
    v5 = 0;
    v6 = boost::system::system_category();
    func(0, i, &v5, 0);
  }
}


