// Address: 0xdd1ac0 | Name: _ZN5boost10flyweights6detail17refcounted_handleIPKNS1_16refcounted_valueINS1_20default_value_policyIN3RBX12SharedString4DataEE8rep_typeES7_EENS1_30flyweight_core_tracking_helperIS8_N4mpl_2naENS0_10refcountedENS0_14hashed_factoryISF_SF_SF_Li0EEENS0_14simple_lockingENS0_13static_holderEEEED2Ev
void __fastcall boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(
        boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *this)
{
  pthread_mutex_t *v1; // r14
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> *h; // rsi

  if ( _InterlockedExchangeAdd((volatile signed __int32 *)this->h + 10, 0xFFFFFFFF) == 1 )
  {
    boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
    v1 = qword_29D5588;
    pthread_mutex_lock(qword_29D5588);
    h = this->h;
    if ( (*((_QWORD *)this->h + 6))-- == 1 )
      boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::erase(
        (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *)(qword_29D5580 + 16),
        (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> >,boost::hash<RBX::SharedString::Data>,std::equal_to<RBX::SharedString::Data>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data>,RBX::SharedString::Data,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::SharedString::Data>::rep_type,RBX::SharedString::Data> > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::iterator)h);
    pthread_mutex_unlock(v1);
  }
}


// Address: 0xecdf40 | Name: _ZNK3RBX7Network16ClientReplicator26schemaGetBytecodeForSourceERKNS_15ProtectedStringE
RBX::SharedString __fastcall RBX::Network::ClientReplicator::schemaGetBytecodeForSource(
        _QWORD *a1,
        const RBX::Network::ClientReplicator *this,
        const RBX::ProtectedString *value)
{
  __int64 v3; // rax

  v3 = *((_QWORD *)value + 7);
  *a1 = v3;
  _InterlockedExchangeAdd((volatile signed __int32 *)(v3 + 40), 1u);
  return (RBX::SharedString)a1;
}


// Address: 0xf2faa0 | Name: _ZN3rbx14implementation12typed_holderIN3RBX12SharedStringEE14construct_funcEPKcPc
void __fastcall rbx::implementation::typed_holder<RBX::SharedString>::construct_func(const char *src, char *dest)
{
  __int64 v2; // rax

  v2 = *(_QWORD *)src;
  *(_QWORD *)dest = *(_QWORD *)src;
  _InterlockedExchangeAdd((volatile signed __int32 *)(v2 + 40), 1u);
}


// Address: 0xf2fac0 | Name: _ZN3rbx14implementation12typed_holderIN3RBX12SharedStringEE18moveConstruct_funcEPcS5_
void __fastcall rbx::implementation::typed_holder<RBX::SharedString>::moveConstruct_func(char *src, char *dest)
{
  __int64 v2; // rax

  v2 = *(_QWORD *)src;
  *(_QWORD *)dest = *(_QWORD *)src;
  _InterlockedExchangeAdd((volatile signed __int32 *)(v2 + 40), 1u);
}


// Address: 0x1114dd0 | Name: _ZN5boost10flyweights6detail17refcounted_handleIPKNS1_16refcounted_valueINS1_20default_value_policyIN3RBX15ProtectedStringEE8rep_typeES6_EENS1_30flyweight_core_tracking_helperIS7_N4mpl_2naENS0_10refcountedENS0_14hashed_factoryISE_SE_SE_Li0EEENS0_14simple_lockingENS0_13static_holderEEEED2Ev
void __fastcall boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(
        boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *this)
{
  pthread_mutex_t *v1; // r14
  boost::multi_index::multi_index_container<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >::node_type *h; // rsi

  if ( _InterlockedExchangeAdd((volatile signed __int32 *)this->h + 16, 0xFFFFFFFF) == 1 )
  {
    boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
    v1 = qword_29FA8D8;
    pthread_mutex_lock(qword_29FA8D8);
    h = (boost::multi_index::multi_index_container<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString> > >::node_type *)this->h;
    if ( (*((_QWORD *)this->h + 9))-- == 1 )
      boost::multi_index::multi_index_container<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>,RBX::ProtectedString,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::ProtectedString>::rep_type,RBX::ProtectedString>>>::erase_(
        qword_29FA8D0,
        h);
    pthread_mutex_unlock(v1);
  }
}


// Address: 0x1542f20 | Name: _ZN5boost10flyweights6detail17refcounted_handleIPKNS1_16refcounted_valueINS1_20default_value_policyINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEEE8rep_typeESB_EENS1_30flyweight_core_tracking_helperISC_N4mpl_2naENS0_10refcountedENS0_14hashed_factoryISJ_SJ_SJ_Li0EEENS0_14simple_lockingENS0_13static_holderEEEED2Ev
void __fastcall boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(
        boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<std::string >,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *this)
{
  pthread_mutex_t *v1; // r14
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *h; // rsi

  if ( _InterlockedExchangeAdd((volatile signed __int32 *)this->h + 6, 0xFFFFFFFF) == 1 )
  {
    boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<std::string>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
    v1 = qword_2A2A798;
    pthread_mutex_lock(qword_2A2A798);
    h = this->h;
    if ( (*((_QWORD *)this->h + 4))-- == 1 )
      boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>,boost::hash<std::string>,std::equal_to<std::string>,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string>::rep_type,std::string>>>,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::erase(
        (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag> *)(qword_2A2A790 + 16),
        (boost::multi_index::detail::hashed_index<boost::multi_index::identity<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > >,boost::hash<std::string>,std::equal_to<std::string >,boost::multi_index::detail::nth_layer<1,boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,boost::flyweights::hashed_factory_class<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string >,std::string,mpl_::na,mpl_::na,mpl_::na>::index_list,std::allocator<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > > >,boost::mpl::vector0<mpl_::na>,boost::multi_index::detail::hashed_unique_tag>::iterator)h);
    pthread_mutex_unlock(v1);
  }
}


// Address: 0x1e2d9c0 | Name: _ZN5boost10flyweights6detail17refcounted_handleIPKNS1_16refcounted_valueINS1_20default_value_policyIN3RBX18PhysicalPropertiesEE8rep_typeES6_EENS1_30flyweight_core_tracking_helperIS7_N4mpl_2naENS0_10refcountedENS0_14hashed_factoryISE_SE_SE_Li0EEENS0_14simple_lockingENS0_13static_holderEEEED2Ev
void __fastcall boost::flyweights::detail::refcounted_handle<boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> const*,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>>::~refcounted_handle(
        boost::flyweights::detail::refcounted_handle<const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> *,boost::flyweights::detail::flyweight_core_tracking_helper<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder> > *this)
{
  pthread_mutex_t *v2; // r14
  boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> *h; // rdi
  boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> **v5; // rcx
  boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> *v6; // rdx
  boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> *v7; // rax
  __int64 v8; // rbx
  boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> *v9; // rsi
  __int64 v10; // rax
  _QWORD *v11; // rcx

  if ( _InterlockedExchangeAdd(&this->h->ref.value_, 0xFFFFFFFF) == 1 )
  {
    boost::flyweights::detail::flyweight_core<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>,mpl_::na,boost::flyweights::refcounted,boost::flyweights::hashed_factory<mpl_::na,mpl_::na,mpl_::na,0>,boost::flyweights::simple_locking,boost::flyweights::static_holder>::init();
    v2 = qword_2AAFBF0;
    pthread_mutex_lock(qword_2AAFBF0);
    h = (boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> *)this->h;
    if ( this->h->del_ref-- == 1 )
    {
      v5 = *(boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> ***)&h[1].x.x.elasticity;
      v6 = *v5;
      --*(_QWORD *)(qword_2AAFBE8 + 72);
      v7 = h + 1;
      v8 = *(_QWORD *)&h[1].x.x.customEnabled;
      v9 = *(boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<RBX::PhysicalProperties>::rep_type,RBX::PhysicalProperties> **)(v8 + 8);
      if ( v9 == &h[1] )
      {
        *(_QWORD *)(v8 + 8) = v5;
        v11 = *(_QWORD **)&h[1].x.x.elasticity;
        if ( v6 != v7 )
          v11 = (_QWORD *)*v11;
        v10 = *(_QWORD *)&v7->x.x.customEnabled;
      }
      else if ( v6 == v7 )
      {
        *(_QWORD *)&v9->x.x.customEnabled = v5;
        v10 = *(_QWORD *)&h[1].x.x.customEnabled;
        v11 = *(_QWORD **)&h[1].x.x.elasticity;
      }
      else
      {
        *(_QWORD *)&v9->x.x.customEnabled = 0;
        *(_QWORD *)(*(_QWORD *)&h[1].x.x.customEnabled + 8LL) = *(_QWORD *)&h[1].x.x.elasticity;
        v10 = *(_QWORD *)&h[1].x.x.customEnabled;
        v11 = **(_QWORD ***)&h[1].x.x.elasticity;
      }
      *v11 = v10;
      operator delete(h);
    }
    pthread_mutex_unlock(v2);
  }
}


