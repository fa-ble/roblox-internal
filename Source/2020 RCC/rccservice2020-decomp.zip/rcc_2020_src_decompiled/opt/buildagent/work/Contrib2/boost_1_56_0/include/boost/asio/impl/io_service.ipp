// Address: 0x25f3a50 | Name: _ZN5boost4asio10io_serviceD2Ev
void __fastcall boost::asio::io_service::~io_service(boost::asio::io_service *this)
{
  boost::asio::detail::service_registry *service_registry; // r14
  boost::asio::io_service::service *first_service; // rbx
  boost::asio::io_service::service *v3; // rdi
  boost::asio::io_service::service *next; // rbx

  service_registry = this->service_registry_;
  if ( this->service_registry_ )
  {
    first_service = service_registry->first_service_;
    if ( first_service )
    {
      do
      {
        (*((void (__fastcall **)(boost::asio::io_service::service *))first_service->_vptr$service + 2))(first_service);
        first_service = first_service->next_;
      }
      while ( first_service );
      v3 = service_registry->first_service_;
      if ( v3 )
      {
        do
        {
          next = v3->next_;
          (*((void (__fastcall **)(boost::asio::io_service::service *))v3->_vptr$service + 1))(v3);
          service_registry->first_service_ = next;
          v3 = next;
        }
        while ( next );
      }
    }
    pthread_mutex_destroy(&service_registry->mutex_.mutex_);
    operator delete(service_registry);
  }
}


// Address: 0x25f7c20 | Name: _ZN5boost4asio10io_service7service12fork_serviceENS1_10fork_eventE
void __fastcall boost::asio::io_service::service::fork_service(
        boost::asio::io_service::service *this,
        boost::asio::io_service::fork_event a2)
{
  ;
}


