// Address: 0x1f8d240 | Name: _ZN5boost4bindIvvN3RBX8Graphics10RenderViewENS_10shared_ptrIN3G3D6GImageEEENS_8weak_ptrINS1_9DataModelEEElPS3_S7_SA_lEENS_3_bi6bind_tIT_NS_4_mfi3mf3IT0_T1_T2_T3_T4_EENSC_9list_av_4IT5_T6_T7_T8_E4typeEEENS_4typeISE_EEMSI_FSH_SJ_SK_SL_ESO_SP_SQ_SR_
boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > > *__fastcall boost::bind<void,void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long,RBX::Graphics::RenderView*,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>(
        boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > > *__return_ptr retstr,
        void (*si0)(RBX::Graphics::RenderView *, boost::shared_ptr<G3D::GImage>, boost::weak_ptr<RBX::DataModel>, __int64),
        void (*f)(RBX::Graphics::RenderView *, boost::shared_ptr<G3D::GImage>, boost::weak_ptr<RBX::DataModel>, __int64),
        RBX::Graphics::RenderView *a1,
        boost::shared_ptr<G3D::GImage> a2,
        boost::weak_ptr<RBX::DataModel> a3)
{
  boost::detail::sp_counted_base *m_byte; // rax
  __int64 v10; // rax
  boost::_bi::value<boost::shared_ptr<G3D::GImage> > v11; // rdx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v14; // rax
  boost::detail::sp_counted_base *v15; // rdi
  boost::detail::sp_counted_base *v16; // rbx
  __int64 v17; // rdi
  boost::detail::sp_counted_base *v18; // rbx
  boost::_bi::value<long> v20; // [rsp+0h] [rbp-78h] BYREF
  __int64 v21; // [rsp+8h] [rbp-70h]
  boost::_bi::value<boost::shared_ptr<G3D::GImage> > a2a; // [rsp+10h] [rbp-68h] BYREF
  boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > v23; // [rsp+20h] [rbp-58h] BYREF

  a2a.t_.px = (boost::shared_ptr<G3D::GImage>::element_type *)a2.px->_vptr$GImage;
  m_byte = (boost::detail::sp_counted_base *)a2.px->m_byte;
  a2a.t_.pn.pi_ = m_byte;
  if ( m_byte )
    _InterlockedAdd(&m_byte->use_count_, 1u);
  a2.px = (boost::shared_ptr<G3D::GImage>::element_type *)a3.px;
  v20.t_ = (__int64)a2.pn.pi_->_vptr$sp_counted_base;
  v10 = *(_QWORD *)&a2.pn.pi_->use_count_;
  v21 = v10;
  if ( v10 )
    _InterlockedAdd((volatile signed __int32 *)(v10 + 12), 1u);
  v11.t_.px = (boost::shared_ptr<G3D::GImage>::element_type *)&a2a;
  v11.t_.pn.pi_ = (boost::detail::sp_counted_base *)&v20;
  boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>::list4(
    &v23,
    (boost::_bi::value<RBX::Graphics::RenderView *>)a1,
    v11,
    (boost::_bi::value<boost::weak_ptr<RBX::DataModel> >)a2,
    v20);
  retstr->f_.f_ = si0;
  *((_QWORD *)&retstr->f_.f_ + 1) = f;
  *(_OWORD *)&retstr->l_.a1_.t_ = *(_OWORD *)&v23.a1_.t_;
  pi = v23.a2_.t_.pn.pi_;
  retstr->l_.a2_.t_.pn.pi_ = v23.a2_.t_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  retstr->l_.a3_.t_.px = v23.a3_.t_.px;
  v14 = v23.a3_.t_.pn.pi_;
  retstr->l_.a3_.t_.pn.pi_ = v23.a3_.t_.pn.pi_;
  if ( v14 )
  {
    _InterlockedAdd(&v14->weak_count_, 1u);
    v15 = v23.a3_.t_.pn.pi_;
    retstr->l_.a4_.t_ = v23.a4_.t_;
    if ( v15 && !_InterlockedSub(&v15->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v15->_vptr$sp_counted_base + 3))(v15);
  }
  else
  {
    retstr->l_.a4_.t_ = v23.a4_.t_;
  }
  v16 = v23.a2_.t_.pn.pi_;
  if ( v23.a2_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v23.a2_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 2))(v16);
      if ( !_InterlockedSub(&v16->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
    }
  }
  v17 = v21;
  if ( v21 && !_InterlockedSub((volatile signed __int32 *)(v21 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v17 + 24LL))(v17);
  v18 = a2a.t_.pn.pi_;
  if ( a2a.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&a2a.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v18->_vptr$sp_counted_base + 2))(v18);
      if ( !_InterlockedSub(&v18->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v18->_vptr$sp_counted_base + 3))(v18);
    }
  }
  return retstr;
}


