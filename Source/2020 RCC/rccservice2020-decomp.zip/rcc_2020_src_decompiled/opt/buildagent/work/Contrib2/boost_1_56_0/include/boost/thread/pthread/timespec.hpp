// Address: 0x28437a0 | Name: _ZN5boost11this_thread21no_interruption_point5hiden9sleep_forERK8timespec
void __fastcall boost::this_thread::no_interruption_point::hiden::sleep_for(const timespec *ts)
{
  if ( ts->tv_nsec + 1000000000 * ts->tv_sec >= 0 )
    nanosleep(ts, 0);
}


