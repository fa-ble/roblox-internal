// Address: 0xd9cce0 | Name: __cxx_global_var_init.90
void __cdecl _cxx_global_var_init_90()
{
  if ( !(_BYTE)qword_29D5520 )
  {
    boost::exception_detail::get_static_exception_object<boost::exception_detail::bad_alloc_>();
    __cxa_atexit((void (*)(void *))boost::exception_ptr::~exception_ptr, &qword_29D5510, &dso_handle);
    qword_29D5520 = 1;
  }
}


// Address: 0xd9cd20 | Name: _ZN5boost16exception_detail27get_static_exception_objectINS0_10bad_alloc_EEENS_13exception_ptrEv
boost::exception_ptr __cdecl boost::exception_detail::get_static_exception_object<boost::exception_detail::bad_alloc_>()
{
  boost::shared_ptr<const boost::exception_detail::clone_base>::element_type *v0; // rdi
  boost::shared_ptr<const boost::exception_detail::clone_base>::element_type *v1; // rbx
  boost::detail::sp_counted_base *pi; // rax
  boost::exception_ptr result; // rax
  char *v4; // r15
  __int64 v5; // rdi
  boost::detail::sp_counted_base *v6; // r15
  unsigned __int128 v7; // [rsp+0h] [rbp-98h] BYREF
  void (__fastcall **v8)(boost::exception_detail::bad_alloc_ *__hidden); // [rsp+10h] [rbp-88h] BYREF
  __int128 v9; // [rsp+18h] [rbp-80h]
  __int64 v10; // [rsp+28h] [rbp-70h]
  int v11; // [rsp+30h] [rbp-68h]
  void (__fastcall **v12)(boost::exception_detail::bad_alloc_ *__hidden); // [rsp+38h] [rbp-60h] BYREF
  _UNKNOWN **v13; // [rsp+40h] [rbp-58h] BYREF
  __int64 v14; // [rsp+48h] [rbp-50h]
  __m128i v15; // [rsp+50h] [rbp-48h]
  int v16; // [rsp+60h] [rbp-38h]
  _BYTE v17[48]; // [rsp+68h] [rbp-30h] BYREF

  v1 = v0;
  v9 = 0;
  v10 = 0;
  v11 = -1;
  std::bad_alloc::bad_alloc((std::bad_alloc *)&v12);
  v8 = off_2875470;
  v12 = off_2875490;
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_impl(
    (boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)&v13,
    (const boost::exception_detail::bad_alloc_ *)&v8);
  v15 = _mm_unpacklo_epi64(
          (__m128i)(unsigned __int64)"boost::exception_ptr boost::exception_detail::get_static_exception_object() [Except"
                                     "ion = boost::exception_detail::bad_alloc_]",
          (__m128i)(unsigned __int64)"/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/exception/detail/exception_ptr.hpp");
  v16 = 128;
  if ( !(_BYTE)byte_29D5560 && __cxa_guard_acquire(&byte_29D5560) )
  {
    v4 = (char *)operator new(0x38u);
    *((_QWORD *)v4 + 6) = &off_2875618;
    *(_QWORD *)v4 = &off_2875508;
    v5 = v14;
    *((_QWORD *)v4 + 1) = v14;
    if ( v5 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 24LL))(v5);
    *((_DWORD *)v4 + 8) = v16;
    *((__m128i *)v4 + 1) = v15;
    *(_QWORD *)v4 = &off_2875530;
    *(__m128i *)(v4 + 40) = _mm_unpacklo_epi64(
                              (__m128i)(unsigned __int64)off_2875560,
                              (__m128i)(unsigned __int64)&off_28755A0);
    v7 = (unsigned __int64)(v4 + 48);
    boost::detail::sp_pointer_construct<boost::exception_detail::clone_base const,boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>>(
      (boost::shared_ptr<const boost::exception_detail::clone_base> *)&v7,
      (boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)v4,
      (boost::detail::shared_count *)&v7 + 1);
    obj = (boost::exception_ptr)v7;
    if ( *((_QWORD *)&v7 + 1) )
    {
      _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v7 + 1) + 8LL), 1u);
      v6 = (boost::detail::sp_counted_base *)*((_QWORD *)&v7 + 1);
      if ( *((_QWORD *)&v7 + 1) )
      {
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v7 + 1) + 8LL), 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 2))(v6);
          if ( !_InterlockedSub(&v6->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
        }
      }
    }
    __cxa_atexit((void (*)(void *))boost::exception_ptr::~exception_ptr, &obj, &dso_handle);
    __cxa_guard_release(&byte_29D5560);
  }
  v1->_vptr$clone_base = (int (**)(void))obj.ptr_.px;
  pi = obj.ptr_.pn.pi_;
  v1[1]._vptr$clone_base = (int (**)(void))obj.ptr_.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  std::bad_alloc::~bad_alloc((std::bad_alloc *)v17);
  v13 = &off_2875508;
  if ( v14 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v14 + 32LL))(v14) )
    v14 = 0;
  std::bad_alloc::~bad_alloc((std::bad_alloc *)&v12);
  v8 = (void (__fastcall **)(boost::exception_detail::bad_alloc_ *__hidden))&off_2875508;
  if ( (_QWORD)v9 && (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)v9 + 32LL))(v9) )
    *(_QWORD *)&v9 = 0;
  result.ptr_.px = v1;
  return result;
}


// Address: 0xd9d050 | Name: _ZN5boost13exception_ptrD2Ev
void __fastcall boost::exception_ptr::~exception_ptr(boost::exception_ptr *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->ptr_.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0xd9d090 | Name: __cxx_global_var_init.91
void __cdecl _cxx_global_var_init_91()
{
  if ( !(_BYTE)qword_29D5538 )
  {
    boost::exception_detail::get_static_exception_object<boost::exception_detail::bad_exception_>();
    __cxa_atexit((void (*)(void *))boost::exception_ptr::~exception_ptr, &qword_29D5528, &dso_handle);
    qword_29D5538 = 1;
  }
}


// Address: 0xd9d0d0 | Name: _ZN5boost16exception_detail27get_static_exception_objectINS0_14bad_exception_EEENS_13exception_ptrEv
boost::exception_ptr __cdecl boost::exception_detail::get_static_exception_object<boost::exception_detail::bad_exception_>()
{
  boost::shared_ptr<const boost::exception_detail::clone_base>::element_type *v0; // rdi
  boost::shared_ptr<const boost::exception_detail::clone_base>::element_type *v1; // r15
  boost::detail::sp_counted_base *v2; // rax
  boost::exception_ptr result; // rax
  char *v4; // r14
  __int64 v5; // rdi
  boost::detail::sp_counted_base *pi; // r14
  boost::shared_ptr<const boost::exception_detail::clone_base> ppx; // [rsp+8h] [rbp-90h] BYREF
  void (__fastcall **v8)(boost::exception_detail::bad_exception_ *__hidden); // [rsp+18h] [rbp-80h] BYREF
  __int128 v9; // [rsp+20h] [rbp-78h]
  __int64 v10; // [rsp+30h] [rbp-68h]
  int v11; // [rsp+38h] [rbp-60h]
  void (__fastcall **v12)(boost::exception_detail::bad_exception_ *__hidden); // [rsp+40h] [rbp-58h] BYREF
  _UNKNOWN **v13; // [rsp+48h] [rbp-50h] BYREF
  __int64 v14; // [rsp+50h] [rbp-48h]
  __m128i v15; // [rsp+58h] [rbp-40h]
  int v16; // [rsp+68h] [rbp-30h]
  _BYTE v17[40]; // [rsp+70h] [rbp-28h] BYREF

  v1 = v0;
  v9 = 0;
  v10 = 0;
  v11 = -1;
  v8 = off_28756B8;
  v12 = off_28756D8;
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_impl(
    (boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)&v13,
    (const boost::exception_detail::bad_exception_ *)&v8);
  v15 = _mm_unpacklo_epi64(
          (__m128i)(unsigned __int64)"boost::exception_ptr boost::exception_detail::get_static_exception_object() [Except"
                                     "ion = boost::exception_detail::bad_exception_]",
          (__m128i)(unsigned __int64)"/opt/buildagent/work/Contrib2/boost_1_56_0/include/boost/exception/detail/exception_ptr.hpp");
  v16 = 128;
  if ( !(_BYTE)byte_29D5578 && __cxa_guard_acquire(&byte_29D5578) )
  {
    v4 = (char *)operator new(0x38u);
    *((_QWORD *)v4 + 6) = &off_2875618;
    *(_QWORD *)v4 = &off_2875508;
    v5 = v14;
    *((_QWORD *)v4 + 1) = v14;
    if ( v5 )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v5 + 24LL))(v5);
    *((_DWORD *)v4 + 8) = v16;
    *((__m128i *)v4 + 1) = v15;
    *(_QWORD *)v4 = &off_2875740;
    *(__m128i *)(v4 + 40) = _mm_unpacklo_epi64(
                              (__m128i)(unsigned __int64)off_2875770,
                              (__m128i)(unsigned __int64)&off_28757B0);
    ppx = (boost::shared_ptr<const boost::exception_detail::clone_base>)(unsigned __int64)(v4 + 48);
    boost::detail::sp_pointer_construct<boost::exception_detail::clone_base const,boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>>(
      &ppx,
      (boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)v4,
      &ppx.pn);
    stru_29D5568 = (boost::exception_ptr)ppx;
    if ( ppx.pn.pi_ )
    {
      _InterlockedAdd(&ppx.pn.pi_->use_count_, 1u);
      pi = ppx.pn.pi_;
      if ( ppx.pn.pi_ )
      {
        if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
      }
    }
    __cxa_atexit((void (*)(void *))boost::exception_ptr::~exception_ptr, &stru_29D5568, &dso_handle);
    __cxa_guard_release(&byte_29D5578);
  }
  v1->_vptr$clone_base = (int (**)(void))stru_29D5568.ptr_.px;
  v2 = stru_29D5568.ptr_.pn.pi_;
  v1[1]._vptr$clone_base = (int (**)(void))stru_29D5568.ptr_.pn.pi_;
  if ( v2 )
    _InterlockedAdd(&v2->use_count_, 1u);
  std::bad_exception::~bad_exception((std::bad_exception *)v17);
  v13 = &off_2875508;
  if ( v14 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v14 + 32LL))(v14) )
    v14 = 0;
  std::bad_exception::~bad_exception((std::bad_exception *)&v12);
  v8 = (void (__fastcall **)(boost::exception_detail::bad_exception_ *__hidden))&off_2875508;
  if ( (_QWORD)v9 && (*(unsigned __int8 (__fastcall **)(_QWORD))(*(_QWORD *)v9 + 32LL))(v9) )
    *(_QWORD *)&v9 = 0;
  result.ptr_.px = v1;
  return result;
}


// Address: 0xd9dfd0 | Name: _ZN5boost16exception_detail10bad_alloc_D2Ev
void __fastcall boost::exception_detail::bad_alloc_::~bad_alloc_(boost::exception_detail::bad_alloc_ *this)
{
  __int64 v2; // rdi

  std::bad_alloc::~bad_alloc((boost::exception_detail::bad_alloc_ *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this + 1) = 0;
  }
}


// Address: 0xd9e010 | Name: _ZN5boost16exception_detail10bad_alloc_D0Ev
void __fastcall boost::exception_detail::bad_alloc_::~bad_alloc_(boost::exception_detail::bad_alloc_ *this)
{
  __int64 v2; // rdi

  std::bad_alloc::~bad_alloc((boost::exception_detail::bad_alloc_ *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete(this);
}


// Address: 0xd9e050 | Name: _ZThn40_N5boost16exception_detail10bad_alloc_D1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::bad_alloc_::~bad_alloc_(
        boost::exception_detail::bad_alloc_ *this)
{
  __int64 v2; // rdi

  std::bad_alloc::~bad_alloc(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this - 4) = 0;
  }
}


// Address: 0xd9e090 | Name: _ZThn40_N5boost16exception_detail10bad_alloc_D0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::bad_alloc_::~bad_alloc_(
        boost::exception_detail::bad_alloc_ *this)
{
  __int64 v2; // rdi

  std::bad_alloc::~bad_alloc(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete((char *)this - 40);
}


// Address: 0xd9e820 | Name: _ZN5boost16exception_detail14bad_exception_D2Ev
void __fastcall boost::exception_detail::bad_exception_::~bad_exception_(boost::exception_detail::bad_exception_ *this)
{
  __int64 v2; // rdi

  std::bad_exception::~bad_exception((boost::exception_detail::bad_exception_ *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this + 1) = 0;
  }
}


// Address: 0xd9e860 | Name: _ZN5boost16exception_detail14bad_exception_D0Ev
void __fastcall boost::exception_detail::bad_exception_::~bad_exception_(boost::exception_detail::bad_exception_ *this)
{
  __int64 v2; // rdi

  std::bad_exception::~bad_exception((boost::exception_detail::bad_exception_ *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete(this);
}


// Address: 0xd9e8a0 | Name: _ZThn40_N5boost16exception_detail14bad_exception_D1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::bad_exception_::~bad_exception_(
        boost::exception_detail::bad_exception_ *this)
{
  __int64 v2; // rdi

  std::bad_exception::~bad_exception(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this - 4) = 0;
  }
}


// Address: 0xd9e8e0 | Name: _ZThn40_N5boost16exception_detail14bad_exception_D0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::bad_exception_::~bad_exception_(
        boost::exception_detail::bad_exception_ *this)
{
  __int64 v2; // rdi

  std::bad_exception::~bad_exception(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete((char *)this - 40);
}


// Address: 0xdbe100 | Name: _ZN5boost17current_exceptionEv
boost::exception_ptr __cdecl __noreturn boost::current_exception()
{
  _OWORD *v0; // rdi

  *v0 = 0;
  boost::exception_detail::current_exception_impl();
}


// Address: 0xdbe400 | Name: _ZN5boost16exception_detail22current_exception_implEv
boost::exception_ptr __cdecl __noreturn boost::exception_detail::current_exception_impl()
{
  __cxa_rethrow();
}


// Address: 0xdbe970 | Name: _ZN5boost16exception_detail39current_exception_unknown_std_exceptionERKSt9exception
void __fastcall __noreturn boost::exception_detail::current_exception_unknown_std_exception(
        __int64 a1,
        const std::exception *e)
{
  const boost::exception_0 *v2; // rax
  const std::type_info *v3; // rax
  boost::exception_detail::clone_impl<boost::unknown_exception> *exception; // rbx
  boost::exception_detail::clone_impl<boost::unknown_exception> *v5; // rbx
  void (__fastcall **v6)(boost::unknown_exception *__hidden); // [rsp+8h] [rbp-60h] BYREF
  __int128 v7; // [rsp+10h] [rbp-58h]
  __int64 v8; // [rsp+20h] [rbp-48h]
  int v9; // [rsp+28h] [rbp-40h]
  void (__fastcall **v10)(boost::unknown_exception *__hidden); // [rsp+30h] [rbp-38h]
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+38h] [rbp-30h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e,
                                     (const struct __class_type_info *)&`typeinfo for'std::exception,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    v7 = 0;
    v8 = 0;
    v9 = -1;
    v6 = off_2876A20;
    v10 = off_2876A40;
    v3 = *(const std::type_info **)(*(_QWORD *)e - 8LL);
    v._vptr$error_info_base = (int (**)(void))&off_2876A98;
    v.value_ = v3;
    boost::exception_detail::set_info<boost::unknown_exception,boost::tag_original_exception_type,std::type_info const*>(
      (const boost::unknown_exception *)&v6,
      &v);
    exception = (boost::exception_detail::clone_impl<boost::unknown_exception> *)__cxa_allocate_exception(0x38u);
    boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(
      exception,
      (const boost::unknown_exception *)&v6);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::unknown_exception>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl);
  }
  boost::unknown_exception::unknown_exception((boost::unknown_exception *)&v6, v2);
  v5 = (boost::exception_detail::clone_impl<boost::unknown_exception> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(v5, (const boost::unknown_exception *)&v6);
  __cxa_throw(
    v5,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::unknown_exception>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl);
}


// Address: 0xdbec20 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt13bad_exceptionEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::bad_exception>(
        __int64 a1,
        const std::bad_exception *e1)
{
  const boost::exception_0 *v2; // rax
  const std::type_info *v3; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *v5; // rbx
  _OWORD v6[2]; // [rsp+0h] [rbp-58h] BYREF
  __int64 v7; // [rsp+20h] [rbp-38h]
  int v8; // [rsp+28h] [rbp-30h]
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+30h] [rbp-28h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::bad_exception,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    v6[1] = 0;
    v7 = 0;
    v8 = -1;
    v6[0] = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876D90, (__m128i)(unsigned __int64)off_2876DB8);
    v3 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
    v._vptr$error_info_base = (int (**)(void))&off_2876A98;
    v.value_ = v3;
    boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>,boost::tag_original_exception_type,std::type_info const*>(
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *)v6,
      &v);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)__cxa_allocate_exception(0x38u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *)v6);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *)v6,
    e1,
    v2);
  v5 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
    v5,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *)v6);
  __cxa_throw(
    v5,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl);
}


// Address: 0xdbeeb0 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt10bad_typeidEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::bad_typeid>(
        __int64 a1,
        const std::bad_typeid *e1)
{
  const boost::exception_0 *v2; // rax
  const std::type_info *v3; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *v5; // rbx
  _OWORD v6[2]; // [rsp+0h] [rbp-58h] BYREF
  __int64 v7; // [rsp+20h] [rbp-38h]
  int v8; // [rsp+28h] [rbp-30h]
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+30h] [rbp-28h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::bad_typeid,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    v6[1] = 0;
    v7 = 0;
    v8 = -1;
    v6[0] = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876F00, (__m128i)(unsigned __int64)off_2876F28);
    v3 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
    v._vptr$error_info_base = (int (**)(void))&off_2876A98;
    v.value_ = v3;
    boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>,boost::tag_original_exception_type,std::type_info const*>(
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *)v6,
      &v);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)__cxa_allocate_exception(0x38u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *)v6);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *)v6,
    e1,
    v2);
  v5 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
    v5,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *)v6);
  __cxa_throw(
    v5,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl);
}


// Address: 0xdbf140 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt8bad_castEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::bad_cast>(
        __int64 a1,
        const std::bad_cast *e1)
{
  const boost::exception_0 *v2; // rax
  const std::type_info *v3; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *v5; // rbx
  _OWORD v6[2]; // [rsp+0h] [rbp-58h] BYREF
  __int64 v7; // [rsp+20h] [rbp-38h]
  int v8; // [rsp+28h] [rbp-30h]
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+30h] [rbp-28h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::bad_cast,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    v6[1] = 0;
    v7 = 0;
    v8 = -1;
    v6[0] = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2877070, (__m128i)(unsigned __int64)off_2877098);
    v3 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
    v._vptr$error_info_base = (int (**)(void))&off_2876A98;
    v.value_ = v3;
    boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>,boost::tag_original_exception_type,std::type_info const*>(
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *)v6,
      &v);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)__cxa_allocate_exception(0x38u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *)v6);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *)v6,
    e1,
    v2);
  v5 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
    v5,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *)v6);
  __cxa_throw(
    v5,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl);
}


// Address: 0xdbf3d0 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt9bad_allocEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::bad_alloc>(
        __int64 a1,
        const std::bad_alloc *e1)
{
  const boost::exception_0 *v2; // rax
  const std::type_info *v3; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *v5; // rbx
  _OWORD v6[2]; // [rsp+0h] [rbp-58h] BYREF
  __int64 v7; // [rsp+20h] [rbp-38h]
  int v8; // [rsp+28h] [rbp-30h]
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+30h] [rbp-28h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::bad_alloc,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    v6[1] = 0;
    v7 = 0;
    v8 = -1;
    v6[0] = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_28771E0, (__m128i)(unsigned __int64)off_2877208);
    v3 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
    v._vptr$error_info_base = (int (**)(void))&off_2876A98;
    v.value_ = v3;
    boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>,boost::tag_original_exception_type,std::type_info const*>(
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *)v6,
      &v);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)__cxa_allocate_exception(0x38u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *)v6);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *)v6,
    e1,
    v2);
  v5 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
    v5,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *)v6);
  __cxa_throw(
    v5,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl);
}


// Address: 0xdbf660 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt13runtime_errorEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::runtime_error>(
        __int64 a1,
        const std::runtime_error *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::runtime_error,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl);
}


// Address: 0xdbf870 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionINSt3__18ios_base7failureEEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::ios_base::failure>(
        __int64 a1,
        const std::ios_base::failure *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *v4; // rbx
  _BYTE v5[32]; // [rsp+8h] [rbp-60h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::ios_base::failure,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)__cxa_allocate_exception(0x50u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl);
}


// Address: 0xdbfa80 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt15underflow_errorEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::underflow_error>(
        __int64 a1,
        const std::underflow_error *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::underflow_error,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl);
}


// Address: 0xdbfc90 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt14overflow_errorEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::overflow_error>(
        __int64 a1,
        const std::overflow_error *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::overflow_error,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl);
}


// Address: 0xdbfea0 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt11range_errorEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::range_error>(
        __int64 a1,
        const std::range_error *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::range_error,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl);
}


// Address: 0xdc00b0 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt11logic_errorEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::logic_error>(
        __int64 a1,
        const std::logic_error *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::logic_error,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl);
}


// Address: 0xdc02c0 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt12out_of_rangeEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::out_of_range>(
        __int64 a1,
        const std::out_of_range *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::out_of_range,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl);
}


// Address: 0xdc04d0 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt12length_errorEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::length_error>(
        __int64 a1,
        const std::length_error *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::length_error,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl);
}


// Address: 0xdc06e0 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt16invalid_argumentEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::invalid_argument>(
        __int64 a1,
        const std::invalid_argument *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::invalid_argument,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl);
}


// Address: 0xdc08f0 | Name: _ZN5boost16exception_detail31current_exception_std_exceptionISt12domain_errorEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::exception_detail::current_exception_std_exception<std::domain_error>(
        __int64 a1,
        const std::domain_error *e1)
{
  const boost::exception_0 *v2; // rax
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *exception; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *v4; // rbx
  _BYTE v5[16]; // [rsp+8h] [rbp-50h] BYREF

  v2 = (const boost::exception_0 *)__dynamic_cast(
                                     e1,
                                     (const struct __class_type_info *)&`typeinfo for'std::domain_error,
                                     (const struct __class_type_info *)&`typeinfo for'boost::exception,
                                     -2);
  if ( !v2 )
  {
    boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>::current_exception_std_exception_wrapper(
      (boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *)v5,
      e1);
    exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)__cxa_allocate_exception(0x40u);
    boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
      exception,
      (const boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *)v5);
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>,
      (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl);
  }
  boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>::current_exception_std_exception_wrapper(
    (boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *)v5,
    e1,
    v2);
  v4 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
    v4,
    (const boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *)v5);
  __cxa_throw(
    v4,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl);
}


// Address: 0xdc0be0 | Name: _ZN5boost17unknown_exceptionD2Ev
void __fastcall boost::unknown_exception::~unknown_exception(boost::unknown_exception *this)
{
  __int64 v2; // rdi

  std::exception::~exception((boost::unknown_exception *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this + 1) = 0;
  }
}


// Address: 0xdc0fe0 | Name: _ZN5boost17unknown_exceptionD0Ev
void __fastcall boost::unknown_exception::~unknown_exception(boost::unknown_exception *this)
{
  __int64 v2; // rdi

  std::exception::~exception((boost::unknown_exception *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete(this);
}


// Address: 0xdc1020 | Name: _ZThn40_N5boost17unknown_exceptionD1Ev
void __fastcall `non-virtual thunk to'boost::unknown_exception::~unknown_exception(boost::unknown_exception *this)
{
  __int64 v2; // rdi

  std::exception::~exception(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this - 4) = 0;
  }
}


// Address: 0xdc1060 | Name: _ZThn40_N5boost17unknown_exceptionD0Ev
void __fastcall `non-virtual thunk to'boost::unknown_exception::~unknown_exception(boost::unknown_exception *this)
{
  __int64 v2; // rdi

  std::exception::~exception(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete((char *)this - 40);
}


// Address: 0xdc11f0 | Name: _ZN5boost17unknown_exceptionC2ERKNS_9exceptionE
void __fastcall boost::unknown_exception::unknown_exception(
        boost::unknown_exception *this,
        const boost::exception_0 *e)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v4; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  *(_QWORD *)this = &off_2875508;
  px = e->data_.px_;
  *((_QWORD *)this + 1) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 8) = e->throw_line_;
  *((_OWORD *)this + 1) = *(_OWORD *)&e->throw_function_;
  *(_QWORD *)this = off_2876A20;
  *((_QWORD *)this + 5) = off_2876A40;
  v4 = (const std::type_info *)*((_QWORD *)e->_vptr$exception - 1);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v4;
  boost::exception_detail::set_info<boost::unknown_exception,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc2250 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt13bad_exceptionEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *this,
        const std::bad_exception *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_exception + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  px = e2->data_.px_;
  *((_QWORD *)this + 2) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 10) = e2->throw_line_;
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)&e2->throw_function_;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876D90, (__m128i)(unsigned __int64)off_2876DB8);
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc2340 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt13bad_exceptionED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_exception::~bad_exception(this);
}


// Address: 0xdc2770 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt13bad_exceptionED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_exception::~bad_exception(this);
  operator delete(this);
}


// Address: 0xdc27c0 | Name: _ZThn8_N5boost16exception_detail39current_exception_std_exception_wrapperISt13bad_exceptionED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *this)
{
  __int64 v2; // rdi
  std::bad_exception *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_exception::~bad_exception(v3);
}


// Address: 0xdc2800 | Name: _ZThn8_N5boost16exception_detail39current_exception_std_exception_wrapperISt13bad_exceptionED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *this)
{
  __int64 v2; // rdi
  std::bad_exception *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_exception::~bad_exception(v3);
  operator delete(v3);
}


// Address: 0xdc2bd0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt10bad_typeidEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *this,
        const std::bad_typeid *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_typeid + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  px = e2->data_.px_;
  *((_QWORD *)this + 2) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 10) = e2->throw_line_;
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)&e2->throw_function_;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876F00, (__m128i)(unsigned __int64)off_2876F28);
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc2cc0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt10bad_typeidED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_typeid::~bad_typeid(this);
}


// Address: 0xdc30f0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt10bad_typeidED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_typeid::~bad_typeid(this);
  operator delete(this);
}


// Address: 0xdc3140 | Name: _ZThn8_N5boost16exception_detail39current_exception_std_exception_wrapperISt10bad_typeidED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *this)
{
  __int64 v2; // rdi
  std::bad_typeid *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_typeid::~bad_typeid(v3);
}


// Address: 0xdc3180 | Name: _ZThn8_N5boost16exception_detail39current_exception_std_exception_wrapperISt10bad_typeidED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *this)
{
  __int64 v2; // rdi
  std::bad_typeid *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_typeid::~bad_typeid(v3);
  operator delete(v3);
}


// Address: 0xdc3550 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt8bad_castEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *this,
        const std::bad_cast *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_cast + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  px = e2->data_.px_;
  *((_QWORD *)this + 2) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 10) = e2->throw_line_;
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)&e2->throw_function_;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2877070, (__m128i)(unsigned __int64)off_2877098);
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc3640 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt8bad_castED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_cast::~bad_cast(this);
}


// Address: 0xdc3a70 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt8bad_castED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_cast::~bad_cast(this);
  operator delete(this);
}


// Address: 0xdc3ac0 | Name: _ZThn8_N5boost16exception_detail39current_exception_std_exception_wrapperISt8bad_castED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_cast::~bad_cast(v3);
}


// Address: 0xdc3b00 | Name: _ZThn8_N5boost16exception_detail39current_exception_std_exception_wrapperISt8bad_castED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_cast::~bad_cast(v3);
  operator delete(v3);
}


// Address: 0xdc3ed0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt9bad_allocEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *this,
        const std::bad_alloc *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_alloc + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  px = e2->data_.px_;
  *((_QWORD *)this + 2) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 10) = e2->throw_line_;
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)&e2->throw_function_;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_28771E0, (__m128i)(unsigned __int64)off_2877208);
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc3fc0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt9bad_allocED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_alloc::~bad_alloc(this);
}


// Address: 0xdc43f0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt9bad_allocED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_alloc::~bad_alloc(this);
  operator delete(this);
}


// Address: 0xdc4440 | Name: _ZThn8_N5boost16exception_detail39current_exception_std_exception_wrapperISt9bad_allocED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *this)
{
  __int64 v2; // rdi
  std::bad_alloc *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_alloc::~bad_alloc(v3);
}


// Address: 0xdc4480 | Name: _ZThn8_N5boost16exception_detail39current_exception_std_exception_wrapperISt9bad_allocED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *this)
{
  __int64 v2; // rdi
  std::bad_alloc *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_alloc::~bad_alloc(v3);
  operator delete(v3);
}


// Address: 0xdc4850 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt13runtime_errorEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *this,
        const std::runtime_error *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_2877350;
  *((_QWORD *)this + 2) = off_2877378;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc4920 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt13runtime_errorED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdc4960 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt13runtime_errorEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *this,
        const std::runtime_error *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_2877350;
  *((_QWORD *)this + 2) = off_2877378;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc4de0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt13runtime_errorED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdc4e30 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt13runtime_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
}


// Address: 0xdc4e70 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt13runtime_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
  operator delete(v3);
}


// Address: 0xdc5200 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEC2ERKS4_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *this,
        const std::ios_base::failure *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::system_error + 16;
  *((_OWORD *)this + 1) = *((_OWORD *)e1 + 1);
  *(_QWORD *)this = (char *)&`vtable for'std::ios_base::failure + 16;
  *((_QWORD *)this + 4) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 5) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 16) = e2->throw_line_;
  *((_OWORD *)this + 3) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_28774C0;
  *((_QWORD *)this + 4) = off_28774E8;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc5300 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperINSt3__18ios_base7failureEED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::ios_base::failure::~failure(this);
}


// Address: 0xdc5340 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEC2ERKS4_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *this,
        const std::ios_base::failure *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::system_error + 16;
  *((_OWORD *)this + 1) = *((_OWORD *)e1 + 1);
  *(_OWORD *)((char *)this + 40) = 0;
  *((_QWORD *)this + 7) = 0;
  *((_DWORD *)this + 16) = -1;
  *(_QWORD *)this = off_28774C0;
  *((_QWORD *)this + 4) = off_28774E8;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc57f0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperINSt3__18ios_base7failureEED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::ios_base::failure::~failure(this);
  operator delete(this);
}


// Address: 0xdc5840 | Name: _ZThn32_N5boost16exception_detail39current_exception_std_exception_wrapperINSt3__18ios_base7failureEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *this)
{
  __int64 v2; // rdi
  std::ios_base::failure *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::ios_base::failure::~failure(v3);
}


// Address: 0xdc5880 | Name: _ZThn32_N5boost16exception_detail39current_exception_std_exception_wrapperINSt3__18ios_base7failureEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *this)
{
  __int64 v2; // rdi
  std::ios_base::failure *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::ios_base::failure::~failure(v3);
  operator delete(v3);
}


// Address: 0xdc5c40 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt15underflow_errorEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *this,
        const std::underflow_error *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::underflow_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_2877630;
  *((_QWORD *)this + 2) = off_2877658;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc5d20 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt15underflow_errorED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::underflow_error::~underflow_error(this);
}


// Address: 0xdc5d60 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt15underflow_errorEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *this,
        const std::underflow_error *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_2877630;
  *((_QWORD *)this + 2) = off_2877658;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc61e0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt15underflow_errorED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::underflow_error::~underflow_error(this);
  operator delete(this);
}


// Address: 0xdc6230 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt15underflow_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *this)
{
  __int64 v2; // rdi
  std::underflow_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::underflow_error::~underflow_error(v3);
}


// Address: 0xdc6270 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt15underflow_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *this)
{
  __int64 v2; // rdi
  std::underflow_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::underflow_error::~underflow_error(v3);
  operator delete(v3);
}


// Address: 0xdc6610 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt14overflow_errorEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *this,
        const std::overflow_error *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::overflow_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_28777A0;
  *((_QWORD *)this + 2) = off_28777C8;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc66f0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt14overflow_errorED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::overflow_error::~overflow_error(this);
}


// Address: 0xdc6730 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt14overflow_errorEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *this,
        const std::overflow_error *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_28777A0;
  *((_QWORD *)this + 2) = off_28777C8;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc6bb0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt14overflow_errorED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::overflow_error::~overflow_error(this);
  operator delete(this);
}


// Address: 0xdc6c00 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt14overflow_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *this)
{
  __int64 v2; // rdi
  std::overflow_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::overflow_error::~overflow_error(v3);
}


// Address: 0xdc6c40 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt14overflow_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *this)
{
  __int64 v2; // rdi
  std::overflow_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::overflow_error::~overflow_error(v3);
  operator delete(v3);
}


// Address: 0xdc6fe0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt11range_errorEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *this,
        const std::range_error *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::range_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_2877910;
  *((_QWORD *)this + 2) = off_2877938;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc70c0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt11range_errorED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::range_error::~range_error(this);
}


// Address: 0xdc7100 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt11range_errorEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *this,
        const std::range_error *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::runtime_error::runtime_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_2877910;
  *((_QWORD *)this + 2) = off_2877938;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc7580 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt11range_errorED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::range_error::~range_error(this);
  operator delete(this);
}


// Address: 0xdc75d0 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt11range_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *this)
{
  __int64 v2; // rdi
  std::range_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::range_error::~range_error(v3);
}


// Address: 0xdc7610 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt11range_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *this)
{
  __int64 v2; // rdi
  std::range_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::range_error::~range_error(v3);
  operator delete(v3);
}


// Address: 0xdc79b0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt11logic_errorEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *this,
        const std::logic_error *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::logic_error::logic_error(this, e1);
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_2877A80;
  *((_QWORD *)this + 2) = off_2877AA8;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc7a80 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt11logic_errorED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdc7ac0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt11logic_errorEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *this,
        const std::logic_error *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_2877A80;
  *((_QWORD *)this + 2) = off_2877AA8;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc7f40 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt11logic_errorED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdc7f90 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt11logic_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdc7fd0 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt11logic_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdc8360 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12out_of_rangeEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *this,
        const std::out_of_range *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::out_of_range + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_2877BF0;
  *((_QWORD *)this + 2) = off_2877C18;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc8440 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12out_of_rangeED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0xdc8480 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12out_of_rangeEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *this,
        const std::out_of_range *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_2877BF0;
  *((_QWORD *)this + 2) = off_2877C18;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc8900 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12out_of_rangeED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0xdc8950 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt12out_of_rangeED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0xdc8990 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt12out_of_rangeED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0xdc8d30 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12length_errorEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *this,
        const std::length_error *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::length_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_2877D60;
  *((_QWORD *)this + 2) = off_2877D88;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc8e10 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12length_errorED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::length_error::~length_error(this);
}


// Address: 0xdc8e50 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12length_errorEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *this,
        const std::length_error *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_2877D60;
  *((_QWORD *)this + 2) = off_2877D88;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc92d0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12length_errorED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::length_error::~length_error(this);
  operator delete(this);
}


// Address: 0xdc9320 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt12length_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *this)
{
  __int64 v2; // rdi
  std::length_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::length_error::~length_error(v3);
}


// Address: 0xdc9360 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt12length_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *this)
{
  __int64 v2; // rdi
  std::length_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::length_error::~length_error(v3);
  operator delete(v3);
}


// Address: 0xdc9700 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt16invalid_argumentEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *this,
        const std::invalid_argument *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::invalid_argument + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_2877ED0;
  *((_QWORD *)this + 2) = off_2877EF8;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdc97e0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt16invalid_argumentED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::invalid_argument::~invalid_argument(this);
}


// Address: 0xdc9820 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt16invalid_argumentEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *this,
        const std::invalid_argument *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_2877ED0;
  *((_QWORD *)this + 2) = off_2877EF8;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdc9ca0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt16invalid_argumentED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::invalid_argument::~invalid_argument(this);
  operator delete(this);
}


// Address: 0xdc9cf0 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt16invalid_argumentED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *this)
{
  __int64 v2; // rdi
  std::invalid_argument *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::invalid_argument::~invalid_argument(v3);
}


// Address: 0xdc9d30 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt16invalid_argumentED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *this)
{
  __int64 v2; // rdi
  std::invalid_argument *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::invalid_argument::~invalid_argument(v3);
  operator delete(v3);
}


// Address: 0xdca0d0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12domain_errorEC2ERKS2_RKNS_9exceptionE
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *this,
        const std::domain_error *e1,
        const boost::exception_0 *e2)
{
  boost::exception_detail::error_info_container *px; // rdi
  const std::type_info *v6; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v; // [rsp+8h] [rbp-30h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_QWORD *)this = (char *)&`vtable for'std::domain_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  px = e2->data_.px_;
  *((_QWORD *)this + 3) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))px->_vptr$error_info_container + 3))(px);
  *((_DWORD *)this + 12) = e2->throw_line_;
  *((_OWORD *)this + 2) = *(_OWORD *)&e2->throw_function_;
  *(_QWORD *)this = off_2878040;
  *((_QWORD *)this + 2) = off_2878068;
  v6 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v.value_ = v6;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v);
}


// Address: 0xdca1b0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12domain_errorED2Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::domain_error::~domain_error(this);
}


// Address: 0xdca1f0 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12domain_errorEC2ERKS2_
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>::current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *this,
        const std::domain_error *e1)
{
  const std::type_info *v2; // rax
  boost::error_info<boost::tag_original_exception_type,const std::type_info *> v3; // [rsp+0h] [rbp-28h] BYREF

  std::logic_error::logic_error(this, e1);
  *(_OWORD *)((char *)this + 24) = 0;
  *((_QWORD *)this + 5) = 0;
  *((_DWORD *)this + 12) = -1;
  *(_QWORD *)this = off_2878040;
  *((_QWORD *)this + 2) = off_2878068;
  v2 = *(const std::type_info **)(*(_QWORD *)e1 - 8LL);
  v3._vptr$error_info_base = (int (**)(void))&off_2876A98;
  v3.value_ = v2;
  boost::exception_detail::set_info<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>,boost::tag_original_exception_type,std::type_info const*>(
    this,
    &v3);
}


// Address: 0xdca670 | Name: _ZN5boost16exception_detail39current_exception_std_exception_wrapperISt12domain_errorED0Ev
void __fastcall boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::domain_error::~domain_error(this);
  operator delete(this);
}


// Address: 0xdca6c0 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt12domain_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *this)
{
  __int64 v2; // rdi
  std::domain_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::domain_error::~domain_error(v3);
}


// Address: 0xdca700 | Name: _ZThn16_N5boost16exception_detail39current_exception_std_exception_wrapperISt12domain_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>::~current_exception_std_exception_wrapper(
        boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *this)
{
  __int64 v2; // rdi
  std::domain_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::domain_error::~domain_error(v3);
  operator delete(v3);
}


// Address: 0xdcac00 | Name: _ZN5boost14copy_exceptionIN3RBX17http_status_errorEEENS_13exception_ptrERKT_
void __fastcall __noreturn boost::copy_exception<RBX::http_status_error>(__int64 a1, const RBX::http_status_error *e)
{
  std::runtime_error *exception; // rbx

  exception = (std::runtime_error *)__cxa_allocate_exception(0x38u);
  *((_QWORD *)exception + 6) = &off_2875618;
  std::runtime_error::runtime_error(exception, e);
  *(_QWORD *)exception = off_2878910;
  std::string::basic_string((char *)exception + 16, (char *)e + 16);
  *((_DWORD *)exception + 10) = *((_DWORD *)e + 10);
  *(_QWORD *)exception = off_2878890;
  *((_QWORD *)exception + 6) = &off_28788E0;
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<RBX::http_status_error>,
    (void (*)(void *))boost::exception_detail::clone_impl<RBX::http_status_error>::~clone_impl);
}


// Address: 0xdcbd90 | Name: _ZN5boost17rethrow_exceptionERKNS_13exception_ptrE
void __fastcall __noreturn boost::rethrow_exception(const boost::exception_ptr *p)
{
  (*((void (__fastcall **)(boost::shared_ptr<const boost::exception_detail::clone_base>::element_type *))p->ptr_.px->_vptr$clone_base
   + 1))(p->ptr_.px);
  abort();
}


