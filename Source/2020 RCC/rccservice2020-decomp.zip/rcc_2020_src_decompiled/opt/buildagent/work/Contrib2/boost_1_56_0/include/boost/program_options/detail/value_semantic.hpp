// Address: 0xe40580 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE4nameEv
__int64 __fastcall boost::program_options::typed_value<std::string,char>::name(__int64 a1, __int64 a2)
{
  unsigned __int64 v3; // rax
  unsigned __int8 *v4; // rax
  unsigned __int64 v5; // rcx
  __int64 v6; // rax
  unsigned __int64 v7; // rdx
  __int64 v8; // rsi
  unsigned __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  unsigned __int64 v11; // rdx
  unsigned __int64 v12; // rdx
  __int64 v13; // rbx
  __int64 v14; // rax
  __int64 v15; // rax
  unsigned __int64 v16; // rax
  __int64 v17; // rax
  char *v18; // rsi
  unsigned __int64 v19; // rdx
  __int64 v20; // rax
  __int64 v21; // rax
  __int128 v23; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+10h] [rbp-58h]
  __int128 v25; // [rsp+20h] [rbp-48h] BYREF
  void *v26; // [rsp+30h] [rbp-38h]
  _BYTE v27[16]; // [rsp+38h] [rbp-30h] BYREF
  void *v28; // [rsp+48h] [rbp-20h]

  v3 = *(unsigned __int8 *)(a2 + 24);
  if ( (v3 & 1) == 0 )
  {
    if ( v3 >> 1 )
      goto LABEL_3;
LABEL_6:
    v4 = (unsigned __int8 *)&xmmword_29F20D0;
    if ( !*(_QWORD *)(a2 + 80) )
      goto LABEL_12;
    goto LABEL_7;
  }
  if ( !*(_QWORD *)(a2 + 32) )
    goto LABEL_6;
LABEL_3:
  v4 = (unsigned __int8 *)(a2 + 24);
  if ( !*(_QWORD *)(a2 + 80) )
  {
LABEL_12:
    if ( *(_QWORD *)(a2 + 48) )
    {
      v10 = *(unsigned __int8 *)(a2 + 56);
      if ( (v10 & 1) != 0 )
      {
        if ( *(_QWORD *)(a2 + 64) )
        {
LABEL_15:
          std::operator+<char>((__int64)&v25, v4, " (=");
          v11 = *(unsigned __int8 *)(a2 + 56);
          if ( (v11 & 1) != 0 )
          {
            v12 = *(_QWORD *)(a2 + 64);
            v13 = *(_QWORD *)(a2 + 72);
          }
          else
          {
            v13 = a2 + 57;
            v12 = v11 >> 1;
          }
          v20 = std::string::append(&v25, v13, v12);
          ptr = *(void **)(v20 + 16);
          v23 = *(_OWORD *)v20;
          *(_OWORD *)v20 = 0;
          *(_QWORD *)(v20 + 16) = 0;
          v21 = std::string::append(&v23, ")");
          *(_QWORD *)(a1 + 16) = *(_QWORD *)(v21 + 16);
          *(_OWORD *)a1 = *(_OWORD *)v21;
          *(_OWORD *)v21 = 0;
          *(_QWORD *)(v21 + 16) = 0;
          if ( (v23 & 1) == 0 )
            goto LABEL_40;
          goto LABEL_39;
        }
      }
      else if ( v10 >> 1 )
      {
        goto LABEL_15;
      }
    }
    std::string::basic_string(a1, v4);
    return a1;
  }
LABEL_7:
  v5 = *(unsigned __int8 *)(a2 + 88);
  if ( (v5 & 1) != 0 )
  {
    if ( !*(_QWORD *)(a2 + 96) )
      goto LABEL_12;
  }
  else if ( !(v5 >> 1) )
  {
    goto LABEL_12;
  }
  std::operator+<char>(v27, "[=", v4);
  v6 = std::string::append(v27, "(=");
  v26 = *(void **)(v6 + 16);
  v25 = *(_OWORD *)v6;
  *(_OWORD *)v6 = 0;
  *(_QWORD *)(v6 + 16) = 0;
  v7 = *(unsigned __int8 *)(a2 + 88);
  if ( (v7 & 1) != 0 )
  {
    v8 = *(_QWORD *)(a2 + 104);
    v9 = *(_QWORD *)(a2 + 96);
  }
  else
  {
    v8 = a2 + 89;
    v9 = v7 >> 1;
  }
  v14 = std::string::append(&v25, v8, v9);
  ptr = *(void **)(v14 + 16);
  v23 = *(_OWORD *)v14;
  *(_OWORD *)v14 = 0;
  *(_QWORD *)(v14 + 16) = 0;
  v15 = std::string::append(&v23, ")]");
  *(_QWORD *)(a1 + 16) = *(_QWORD *)(v15 + 16);
  *(_OWORD *)a1 = *(_OWORD *)v15;
  *(_OWORD *)v15 = 0;
  *(_QWORD *)(v15 + 16) = 0;
  if ( (v23 & 1) != 0 )
  {
    operator delete(ptr);
    if ( (v25 & 1) == 0 )
    {
LABEL_20:
      if ( (v27[0] & 1) == 0 )
        goto LABEL_21;
      goto LABEL_25;
    }
  }
  else if ( (v25 & 1) == 0 )
  {
    goto LABEL_20;
  }
  operator delete(v26);
  if ( (v27[0] & 1) == 0 )
  {
LABEL_21:
    if ( !*(_QWORD *)(a2 + 48) )
      return a1;
    goto LABEL_26;
  }
LABEL_25:
  operator delete(v28);
  if ( !*(_QWORD *)(a2 + 48) )
    return a1;
LABEL_26:
  v16 = *(unsigned __int8 *)(a2 + 56);
  if ( (v16 & 1) != 0 )
  {
    if ( !*(_QWORD *)(a2 + 64) )
      return a1;
  }
  else if ( !(v16 >> 1) )
  {
    return a1;
  }
  std::operator+<char>(&v25, " (=", a2 + 56);
  v17 = std::string::append(&v25, ")");
  ptr = *(void **)(v17 + 16);
  v23 = *(_OWORD *)v17;
  *(_OWORD *)v17 = 0;
  *(_QWORD *)(v17 + 16) = 0;
  if ( (v23 & 1) != 0 )
  {
    v18 = (char *)ptr;
    v19 = *((_QWORD *)&v23 + 1);
  }
  else
  {
    v19 = (unsigned __int64)(unsigned __int8)v23 >> 1;
    v18 = (char *)&v23 + 1;
  }
  std::string::append(a1, v18, v19);
  if ( (v23 & 1) == 0 )
    goto LABEL_40;
LABEL_39:
  operator delete(ptr);
LABEL_40:
  if ( (v25 & 1) != 0 )
    operator delete(v26);
  return a1;
}


// Address: 0xe40a10 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE6notifyERKNS_3anyE
void __fastcall boost::program_options::typed_value<std::string,char>::notify(
        const boost::program_options::typed_value<std::string,char> *this,
        const boost::any_0 *value_store)
{
  int v2; // edx
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9
  void *v7; // rax
  const char *v8; // rdi
  boost::any::placeholder *v9; // rbx
  soap *v10; // rdi
  __int64 v11; // rax
  void (__fastcall *v12)(boost::function1<void,const std::string &>::dummy *); // rcx
  _QWORD v13[4]; // [rsp+8h] [rbp-20h] BYREF

  if ( value_store->content )
    v7 = (void *)(*((__int64 (__fastcall **)(boost::any::placeholder *))value_store->content->_vptr$placeholder + 2))(value_store->content);
  else
    v7 = &`typeinfo for'void;
  v8 = (const char *)*((_QWORD *)v7 + 1);
  if ( v8 == "NSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEE"
    || !strcmp(v8, "NSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEE") )
  {
    v9 = value_store->content + 1;
  }
  else
  {
    v9 = 0;
  }
  v10 = (soap *)*((_QWORD *)this + 2);
  if ( v10 )
    std::string::operator=(v10, (int)v9, v2, v3, v4, v5);
  v11 = *((_QWORD *)this + 15);
  v12 = boost::function1<void,std::string const&>::dummy::nonnull;
  if ( !v11 )
    v12 = 0;
  if ( v12 )
  {
    if ( !v11 )
    {
      std::runtime_error::runtime_error((std::runtime_error *)v13, "call to empty boost::function");
      v13[0] = off_2875ED8;
      boost::throw_exception<boost::bad_function_call>((const boost::bad_function_call *)v13);
    }
    (*(void (__fastcall **)(char *, boost::any::placeholder *))((v11 & 0xFFFFFFFFFFFFFFFELL) + 8))(
      (char *)this + 128,
      v9);
  }
}


// Address: 0xe40bc0 | Name: _ZNK5boost15program_options11typed_valueINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEcE6xparseERNS_3anyERKNS2_6vectorIS8_NS6_IS8_EEEE
void __fastcall boost::program_options::typed_value<std::string,char>::xparse(
        const boost::program_options::typed_value<std::string,char> *this,
        boost::any_0 *value_store,
        const std::vector<std::string> *new_tokens)
{
  __int64 v3; // rdi
  boost::any::placeholder *v4; // rax
  boost::any::placeholder *content; // rdi

  if ( *(_QWORD *)new_tokens == *((_QWORD *)new_tokens + 1) && (v3 = *((_QWORD *)this + 10)) != 0 )
  {
    v4 = (boost::any::placeholder *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
    content = value_store->content;
    value_store->content = v4;
    if ( content )
      (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  }
  else
  {
    boost::program_options::validate(value_store, new_tokens, 0, 0);
  }
}


// Address: 0xe41470 | Name: _ZNK5boost15program_options11typed_valueIicE4nameEv
__int64 __fastcall boost::program_options::typed_value<int,char>::name(__int64 a1, __int64 a2)
{
  unsigned __int64 v3; // rax
  unsigned __int8 *v4; // rax
  unsigned __int64 v5; // rcx
  __int64 v6; // rax
  unsigned __int64 v7; // rdx
  __int64 v8; // rsi
  unsigned __int64 v9; // rdx
  unsigned __int64 v10; // rcx
  unsigned __int64 v11; // rdx
  unsigned __int64 v12; // rdx
  __int64 v13; // rbx
  __int64 v14; // rax
  __int64 v15; // rax
  unsigned __int64 v16; // rax
  __int64 v17; // rax
  char *v18; // rsi
  unsigned __int64 v19; // rdx
  __int64 v20; // rax
  __int64 v21; // rax
  __int128 v23; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+10h] [rbp-58h]
  __int128 v25; // [rsp+20h] [rbp-48h] BYREF
  void *v26; // [rsp+30h] [rbp-38h]
  _BYTE v27[16]; // [rsp+38h] [rbp-30h] BYREF
  void *v28; // [rsp+48h] [rbp-20h]

  v3 = *(unsigned __int8 *)(a2 + 24);
  if ( (v3 & 1) == 0 )
  {
    if ( v3 >> 1 )
      goto LABEL_3;
LABEL_6:
    v4 = (unsigned __int8 *)&xmmword_29F20D0;
    if ( !*(_QWORD *)(a2 + 80) )
      goto LABEL_12;
    goto LABEL_7;
  }
  if ( !*(_QWORD *)(a2 + 32) )
    goto LABEL_6;
LABEL_3:
  v4 = (unsigned __int8 *)(a2 + 24);
  if ( !*(_QWORD *)(a2 + 80) )
  {
LABEL_12:
    if ( *(_QWORD *)(a2 + 48) )
    {
      v10 = *(unsigned __int8 *)(a2 + 56);
      if ( (v10 & 1) != 0 )
      {
        if ( *(_QWORD *)(a2 + 64) )
        {
LABEL_15:
          std::operator+<char>((__int64)&v25, v4, " (=");
          v11 = *(unsigned __int8 *)(a2 + 56);
          if ( (v11 & 1) != 0 )
          {
            v12 = *(_QWORD *)(a2 + 64);
            v13 = *(_QWORD *)(a2 + 72);
          }
          else
          {
            v13 = a2 + 57;
            v12 = v11 >> 1;
          }
          v20 = std::string::append(&v25, v13, v12);
          ptr = *(void **)(v20 + 16);
          v23 = *(_OWORD *)v20;
          *(_OWORD *)v20 = 0;
          *(_QWORD *)(v20 + 16) = 0;
          v21 = std::string::append(&v23, ")");
          *(_QWORD *)(a1 + 16) = *(_QWORD *)(v21 + 16);
          *(_OWORD *)a1 = *(_OWORD *)v21;
          *(_OWORD *)v21 = 0;
          *(_QWORD *)(v21 + 16) = 0;
          if ( (v23 & 1) == 0 )
            goto LABEL_40;
          goto LABEL_39;
        }
      }
      else if ( v10 >> 1 )
      {
        goto LABEL_15;
      }
    }
    std::string::basic_string(a1, v4);
    return a1;
  }
LABEL_7:
  v5 = *(unsigned __int8 *)(a2 + 88);
  if ( (v5 & 1) != 0 )
  {
    if ( !*(_QWORD *)(a2 + 96) )
      goto LABEL_12;
  }
  else if ( !(v5 >> 1) )
  {
    goto LABEL_12;
  }
  std::operator+<char>(v27, "[=", v4);
  v6 = std::string::append(v27, "(=");
  v26 = *(void **)(v6 + 16);
  v25 = *(_OWORD *)v6;
  *(_OWORD *)v6 = 0;
  *(_QWORD *)(v6 + 16) = 0;
  v7 = *(unsigned __int8 *)(a2 + 88);
  if ( (v7 & 1) != 0 )
  {
    v8 = *(_QWORD *)(a2 + 104);
    v9 = *(_QWORD *)(a2 + 96);
  }
  else
  {
    v8 = a2 + 89;
    v9 = v7 >> 1;
  }
  v14 = std::string::append(&v25, v8, v9);
  ptr = *(void **)(v14 + 16);
  v23 = *(_OWORD *)v14;
  *(_OWORD *)v14 = 0;
  *(_QWORD *)(v14 + 16) = 0;
  v15 = std::string::append(&v23, ")]");
  *(_QWORD *)(a1 + 16) = *(_QWORD *)(v15 + 16);
  *(_OWORD *)a1 = *(_OWORD *)v15;
  *(_OWORD *)v15 = 0;
  *(_QWORD *)(v15 + 16) = 0;
  if ( (v23 & 1) != 0 )
  {
    operator delete(ptr);
    if ( (v25 & 1) == 0 )
    {
LABEL_20:
      if ( (v27[0] & 1) == 0 )
        goto LABEL_21;
      goto LABEL_25;
    }
  }
  else if ( (v25 & 1) == 0 )
  {
    goto LABEL_20;
  }
  operator delete(v26);
  if ( (v27[0] & 1) == 0 )
  {
LABEL_21:
    if ( !*(_QWORD *)(a2 + 48) )
      return a1;
    goto LABEL_26;
  }
LABEL_25:
  operator delete(v28);
  if ( !*(_QWORD *)(a2 + 48) )
    return a1;
LABEL_26:
  v16 = *(unsigned __int8 *)(a2 + 56);
  if ( (v16 & 1) != 0 )
  {
    if ( !*(_QWORD *)(a2 + 64) )
      return a1;
  }
  else if ( !(v16 >> 1) )
  {
    return a1;
  }
  std::operator+<char>(&v25, " (=", a2 + 56);
  v17 = std::string::append(&v25, ")");
  ptr = *(void **)(v17 + 16);
  v23 = *(_OWORD *)v17;
  *(_OWORD *)v17 = 0;
  *(_QWORD *)(v17 + 16) = 0;
  if ( (v23 & 1) != 0 )
  {
    v18 = (char *)ptr;
    v19 = *((_QWORD *)&v23 + 1);
  }
  else
  {
    v19 = (unsigned __int64)(unsigned __int8)v23 >> 1;
    v18 = (char *)&v23 + 1;
  }
  std::string::append(a1, v18, v19);
  if ( (v23 & 1) == 0 )
    goto LABEL_40;
LABEL_39:
  operator delete(ptr);
LABEL_40:
  if ( (v25 & 1) != 0 )
    operator delete(v26);
  return a1;
}


// Address: 0xe41900 | Name: _ZNK5boost15program_options11typed_valueIicE6notifyERKNS_3anyE
void __fastcall boost::program_options::typed_value<int,char>::notify(
        const boost::program_options::typed_value<int,char> *this,
        const boost::any_0 *value_store)
{
  void *v4; // rax
  const char *v5; // rdi
  const char *v6; // rsi
  boost::any::placeholder *v7; // rsi
  _DWORD *v8; // rax
  __int64 v9; // rax
  void (__fastcall *v10)(boost::function1<void,const int &>::dummy *); // rcx
  _QWORD v11[4]; // [rsp+8h] [rbp-20h] BYREF

  if ( value_store->content )
    v4 = (void *)(*((__int64 (__fastcall **)(boost::any::placeholder *))value_store->content->_vptr$placeholder + 2))(value_store->content);
  else
    v4 = &`typeinfo for'void;
  v5 = (const char *)*((_QWORD *)v4 + 1);
  v6 = (const char *)`typeinfo for'int[1];
  if ( v5 == v6 || !strcmp(v5, v6) )
    v7 = value_store->content + 1;
  else
    v7 = 0;
  v8 = (_DWORD *)*((_QWORD *)this + 2);
  if ( v8 )
    *v8 = v7->_vptr$placeholder;
  v9 = *((_QWORD *)this + 15);
  v10 = boost::function1<void,int const&>::dummy::nonnull;
  if ( !v9 )
    v10 = 0;
  if ( v10 )
  {
    if ( !v9 )
    {
      std::runtime_error::runtime_error((std::runtime_error *)v11, "call to empty boost::function");
      v11[0] = off_2875ED8;
      boost::throw_exception<boost::bad_function_call>((const boost::bad_function_call *)v11);
    }
    (*(void (__fastcall **)(char *, boost::any::placeholder *))((v9 & 0xFFFFFFFFFFFFFFFELL) + 8))(
      (char *)this + 128,
      v7);
  }
}


// Address: 0xe41ab0 | Name: _ZNK5boost15program_options11typed_valueIicE6xparseERNS_3anyERKNSt3__16vectorINS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENSA_ISC_EEEE
void __fastcall boost::program_options::typed_value<int,char>::xparse(
        const boost::program_options::typed_value<int,char> *this,
        boost::any_0 *value_store,
        const std::vector<std::string> *new_tokens)
{
  __int64 v3; // rdi
  boost::any::placeholder *v4; // rax
  boost::any::placeholder *content; // rdi

  if ( *(_QWORD *)new_tokens == *((_QWORD *)new_tokens + 1) && (v3 = *((_QWORD *)this + 10)) != 0 )
  {
    v4 = (boost::any::placeholder *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
    content = value_store->content;
    value_store->content = v4;
    if ( content )
      (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  }
  else
  {
    boost::program_options::validate<int,char>(value_store, new_tokens, 0, 0);
  }
}


// Address: 0xe41b60 | Name: _ZN5boost15program_options8validateIicEEvRNS_3anyERKNSt3__16vectorINS4_12basic_stringIT0_NS4_11char_traitsIS7_EENS4_9allocatorIS7_EEEENSA_ISC_EEEEPT_l
void __fastcall boost::program_options::validate<int,char>(
        boost::any_0 *v,
        const std::vector<std::string> *xs,
        int *a3,
        __int64 a4)
{
  const std::string *single; // rsi
  const char *v6; // rcx
  unsigned __int64 v7; // rax
  const char *v8; // rax
  char v9; // bl
  bool v10; // al
  unsigned int v11; // ebp
  bool v12; // dl
  boost::any::placeholder *v13; // rax
  int v14; // ecx
  boost::any::placeholder *content; // rdi
  unsigned int v16; // [rsp+4h] [rbp-D4h] BYREF
  unsigned __int8 v17; // [rsp+8h] [rbp-D0h] BYREF
  char v18; // [rsp+9h] [rbp-CFh] BYREF
  unsigned __int64 v19; // [rsp+10h] [rbp-C8h]
  void *ptr; // [rsp+18h] [rbp-C0h]
  boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char> v21; // [rsp+20h] [rbp-B8h] BYREF
  void (**v22)(std::bad_cast *__hidden); // [rsp+40h] [rbp-98h] BYREF
  __m128i v23; // [rsp+48h] [rbp-90h]

  boost::program_options::validators::check_first_occurrence(v);
  single = boost::program_options::validators::get_single_string<char>(xs, 0);
  std::string::basic_string(&v17, single);
  if ( (v17 & 1) != 0 )
  {
    v6 = (const char *)ptr;
    v7 = v19;
    if ( !v19 )
      goto LABEL_18;
  }
  else
  {
    v7 = (unsigned __int64)v17 >> 1;
    v6 = &v18;
    if ( !v7 )
      goto LABEL_18;
  }
  v8 = &v6[v7];
  v16 = 0;
  v9 = *v6;
  if ( *v6 == 45 || v9 == 43 )
    ++v6;
  v21.m_multiplier_overflowed = 0;
  v21.m_multiplier = 1;
  v21.m_value = &v16;
  v21.m_begin = v6;
  v21.m_end = v8;
  v10 = boost::detail::lcast_ret_unsigned<std::char_traits<char>,unsigned int,char>::convert(&v21);
  v11 = v16;
  v12 = v16 < 0x80000001;
  if ( v9 != 45 )
    v12 = (v16 & 0x80000000) == 0;
  if ( !v12 || !v10 )
  {
LABEL_18:
    std::bad_cast::bad_cast((std::bad_cast *)&v22);
    v22 = off_287BC88;
    v23 = _mm_unpacklo_epi64(
            (__m128i)(unsigned __int64)&`typeinfo for'std::string,
            _mm_loadl_epi64((const __m128i *)&`typeinfo for'int));
    boost::throw_exception<boost::bad_lexical_cast>((const boost::bad_lexical_cast *)&v22);
  }
  v13 = (boost::any::placeholder *)operator new(0x10u);
  v14 = -v11;
  if ( v9 != 45 )
    v14 = v11;
  v13->_vptr$placeholder = (int (**)(void))&off_287BF70;
  LODWORD(v13[1]._vptr$placeholder) = v14;
  content = v->content;
  v->content = v13;
  if ( content )
    (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  if ( (v17 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0xe41d90 | Name: _ZN5boost15program_options10validators17get_single_stringIcEERKNSt3__112basic_stringIT_NS3_11char_traitsIS5_EENS3_9allocatorIS5_EEEERKNS3_6vectorISA_NS8_ISA_EEEEb
const std::string *__fastcall boost::program_options::validators::get_single_string<char>(
        const std::vector<std::string> *v,
        bool allow_empty)
{
  __int64 v2; // rax
  bool v3; // zf
  const std::string *result; // rax
  _BYTE v5[16]; // [rsp+8h] [rbp-E0h] BYREF
  void *ptr; // [rsp+18h] [rbp-D0h]
  __int128 v7; // [rsp+20h] [rbp-C8h] BYREF
  void *v8; // [rsp+30h] [rbp-B8h]
  __int128 v9; // [rsp+40h] [rbp-A8h] BYREF
  void *v10; // [rsp+50h] [rbp-98h]
  boost::program_options::validation_error::kind_t v11[2]; // [rsp+58h] [rbp-90h] BYREF

  if ( !(_BYTE)byte_29F1998 && __cxa_guard_acquire(&byte_29F1998) )
  {
    xmmword_29F1980 = 0;
    qword_29F1990 = 0;
    __cxa_atexit((void (*)(void *))&std::string::~string, &xmmword_29F1980, &dso_handle);
    __cxa_guard_release(&byte_29F1998);
  }
  v2 = *((_QWORD *)v + 1) - *(_QWORD *)v;
  if ( 0xAAAAAAAAAAAAAAABLL * (v2 >> 3) >= 2 )
  {
    v9 = 0;
    v10 = 0;
    v7 = 0;
    v8 = 0;
    *(_QWORD *)v11 = off_287BF38;
    boost::program_options::validation_error::get_template(
      (boost::program_options::validation_error *)v5,
      (boost::program_options::validation_error::kind_t)v11);
    boost::program_options::error_with_option_name::error_with_option_name(
      (boost::program_options::error_with_option_name *)v11,
      (const std::string *)v5,
      (const std::string *)&v9,
      (const std::string *)&v7,
      0);
    if ( (v5[0] & 1) != 0 )
      operator delete(ptr);
    *(_QWORD *)v11 = off_287BF38;
    boost::throw_exception<boost::program_options::validation_error>((const boost::program_options::validation_error *)v11);
  }
  if ( v2 != 24 && !allow_empty )
  {
    v9 = 0;
    v10 = 0;
    v7 = 0;
    v8 = 0;
    *(_QWORD *)v11 = off_287BF38;
    boost::program_options::validation_error::get_template(
      (boost::program_options::validation_error *)v5,
      (boost::program_options::validation_error::kind_t)v11);
    boost::program_options::error_with_option_name::error_with_option_name(
      (boost::program_options::error_with_option_name *)v11,
      (const std::string *)v5,
      (const std::string *)&v9,
      (const std::string *)&v7,
      0);
    if ( (v5[0] & 1) != 0 )
      operator delete(ptr);
    *(_QWORD *)v11 = off_287BF38;
    boost::throw_exception<boost::program_options::validation_error>((const boost::program_options::validation_error *)v11);
  }
  v3 = v2 == 24;
  result = (const std::string *)&xmmword_29F1980;
  if ( v3 )
    return *(const std::string **)v;
  return result;
}


// Address: 0xe66b50 | Name: _ZN5boost15program_options10validators17get_single_stringIwEERKNSt3__112basic_stringIT_NS3_11char_traitsIS5_EENS3_9allocatorIS5_EEEERKNS3_6vectorISA_NS8_ISA_EEEEb
const std::wstring *__fastcall boost::program_options::validators::get_single_string<wchar_t>(
        const std::vector<std::wstring> *v,
        bool allow_empty)
{
  __int64 v2; // rax
  bool v3; // zf
  const std::wstring *result; // rax
  __int128 v5; // [rsp+0h] [rbp-C8h] BYREF
  void *v6; // [rsp+10h] [rbp-B8h]
  __int128 v7; // [rsp+20h] [rbp-A8h] BYREF
  void *v8; // [rsp+30h] [rbp-98h]
  _QWORD v9[3]; // [rsp+38h] [rbp-90h] BYREF

  if ( !(_BYTE)byte_29F2100 && __cxa_guard_acquire(&byte_29F2100) )
  {
    xmmword_29F20E8 = 0;
    qword_29F20F8 = 0;
    __cxa_atexit((void (*)(void *))&std::wstring::~wstring, &xmmword_29F20E8, &dso_handle);
    __cxa_guard_release(&byte_29F2100);
  }
  v2 = *((_QWORD *)v + 1) - *(_QWORD *)v;
  if ( 0xAAAAAAAAAAAAAAABLL * (v2 >> 3) >= 2 )
  {
    v7 = 0;
    v8 = 0;
    v5 = 0;
    v6 = 0;
    boost::program_options::validation_error::validation_error(
      (boost::program_options::validation_error *)v9,
      boost::program_options::validation_error::kind_t::multiple_values_not_allowed,
      (const std::string *)&v7,
      (const std::string *)&v5,
      0);
    boost::throw_exception<boost::program_options::validation_error>((const boost::program_options::validation_error *)v9);
  }
  if ( v2 != 24 && !allow_empty )
  {
    v7 = 0;
    v8 = 0;
    v5 = 0;
    v6 = 0;
    boost::program_options::validation_error::validation_error(
      (boost::program_options::validation_error *)v9,
      boost::program_options::validation_error::kind_t::at_least_one_value_required,
      (const std::string *)&v7,
      (const std::string *)&v5,
      0);
    boost::throw_exception<boost::program_options::validation_error>((const boost::program_options::validation_error *)v9);
  }
  v3 = v2 == 24;
  result = (const std::wstring *)&xmmword_29F20E8;
  if ( v3 )
    return *(const std::wstring **)v;
  return result;
}


// Address: 0xe68030 | Name: _ZNK5boost15program_options11typed_valueIbcE4nameEv
__int64 __fastcall boost::program_options::typed_value<bool,char>::name(__int64 a1, __int64 a2)
{
  unsigned __int8 *v3; // rax
  unsigned __int64 v4; // rcx
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // rcx
  __int64 v7; // rax
  unsigned __int64 v8; // rdx
  __int64 v9; // rsi
  unsigned __int64 v10; // rdx
  unsigned __int64 v11; // rcx
  unsigned __int64 v12; // rdx
  unsigned __int64 v13; // rdx
  __int64 v14; // rbx
  __int64 v15; // rax
  __int64 v16; // rax
  unsigned __int64 v17; // rax
  __int64 v18; // rax
  char *v19; // rsi
  unsigned __int64 v20; // rdx
  __int64 v21; // rax
  __int64 v22; // rax
  __int128 v24; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+10h] [rbp-58h]
  __int128 v26; // [rsp+20h] [rbp-48h] BYREF
  void *v27; // [rsp+30h] [rbp-38h]
  _BYTE v28[16]; // [rsp+38h] [rbp-30h] BYREF
  void *v29; // [rsp+48h] [rbp-20h]

  v3 = (unsigned __int8 *)(a2 + 24);
  v4 = *(unsigned __int8 *)(a2 + 24);
  if ( (v4 & 1) != 0 )
    v5 = *(_QWORD *)(a2 + 32);
  else
    v5 = v4 >> 1;
  if ( !v5 )
    v3 = (unsigned __int8 *)&xmmword_29F20D0;
  if ( !*(_QWORD *)(a2 + 80) )
    goto LABEL_12;
  v6 = *(unsigned __int8 *)(a2 + 88);
  if ( (v6 & 1) == 0 )
  {
    if ( v6 >> 1 )
      goto LABEL_9;
LABEL_12:
    if ( *(_QWORD *)(a2 + 48) )
    {
      v11 = *(unsigned __int8 *)(a2 + 56);
      if ( (v11 & 1) != 0 )
      {
        if ( *(_QWORD *)(a2 + 64) )
        {
LABEL_15:
          std::operator+<char>((__int64)&v26, v3, " (=");
          v12 = *(unsigned __int8 *)(a2 + 56);
          if ( (v12 & 1) != 0 )
          {
            v13 = *(_QWORD *)(a2 + 64);
            v14 = *(_QWORD *)(a2 + 72);
          }
          else
          {
            v14 = a2 + 57;
            v13 = v12 >> 1;
          }
          v21 = std::string::append(&v26, v14, v13);
          ptr = *(void **)(v21 + 16);
          v24 = *(_OWORD *)v21;
          *(_OWORD *)v21 = 0;
          *(_QWORD *)(v21 + 16) = 0;
          v22 = std::string::append(&v24, ")");
          *(_QWORD *)(a1 + 16) = *(_QWORD *)(v22 + 16);
          *(_OWORD *)a1 = *(_OWORD *)v22;
          *(_OWORD *)v22 = 0;
          *(_QWORD *)(v22 + 16) = 0;
          if ( (v24 & 1) == 0 )
            goto LABEL_40;
          goto LABEL_39;
        }
      }
      else if ( v11 >> 1 )
      {
        goto LABEL_15;
      }
    }
    std::string::basic_string(a1, v3);
    return a1;
  }
  if ( !*(_QWORD *)(a2 + 96) )
    goto LABEL_12;
LABEL_9:
  std::operator+<char>(v28, "[=", v3);
  v7 = std::string::append(v28, "(=");
  v27 = *(void **)(v7 + 16);
  v26 = *(_OWORD *)v7;
  *(_OWORD *)v7 = 0;
  *(_QWORD *)(v7 + 16) = 0;
  v8 = *(unsigned __int8 *)(a2 + 88);
  if ( (v8 & 1) != 0 )
  {
    v9 = *(_QWORD *)(a2 + 104);
    v10 = *(_QWORD *)(a2 + 96);
  }
  else
  {
    v9 = a2 + 89;
    v10 = v8 >> 1;
  }
  v15 = std::string::append(&v26, v9, v10);
  ptr = *(void **)(v15 + 16);
  v24 = *(_OWORD *)v15;
  *(_OWORD *)v15 = 0;
  *(_QWORD *)(v15 + 16) = 0;
  v16 = std::string::append(&v24, ")]");
  *(_QWORD *)(a1 + 16) = *(_QWORD *)(v16 + 16);
  *(_OWORD *)a1 = *(_OWORD *)v16;
  *(_OWORD *)v16 = 0;
  *(_QWORD *)(v16 + 16) = 0;
  if ( (v24 & 1) != 0 )
  {
    operator delete(ptr);
    if ( (v26 & 1) == 0 )
    {
LABEL_20:
      if ( (v28[0] & 1) == 0 )
        goto LABEL_21;
      goto LABEL_25;
    }
  }
  else if ( (v26 & 1) == 0 )
  {
    goto LABEL_20;
  }
  operator delete(v27);
  if ( (v28[0] & 1) == 0 )
  {
LABEL_21:
    if ( !*(_QWORD *)(a2 + 48) )
      return a1;
    goto LABEL_26;
  }
LABEL_25:
  operator delete(v29);
  if ( !*(_QWORD *)(a2 + 48) )
    return a1;
LABEL_26:
  v17 = *(unsigned __int8 *)(a2 + 56);
  if ( (v17 & 1) != 0 )
  {
    if ( !*(_QWORD *)(a2 + 64) )
      return a1;
  }
  else if ( !(v17 >> 1) )
  {
    return a1;
  }
  std::operator+<char>(&v26, " (=", a2 + 56);
  v18 = std::string::append(&v26, ")");
  ptr = *(void **)(v18 + 16);
  v24 = *(_OWORD *)v18;
  *(_OWORD *)v18 = 0;
  *(_QWORD *)(v18 + 16) = 0;
  if ( (v24 & 1) != 0 )
  {
    v19 = (char *)ptr;
    v20 = *((_QWORD *)&v24 + 1);
  }
  else
  {
    v20 = (unsigned __int64)(unsigned __int8)v24 >> 1;
    v19 = (char *)&v24 + 1;
  }
  std::string::append(a1, v19, v20);
  if ( (v24 & 1) == 0 )
    goto LABEL_40;
LABEL_39:
  operator delete(ptr);
LABEL_40:
  if ( (v26 & 1) != 0 )
    operator delete(v27);
  return a1;
}


// Address: 0xe684b0 | Name: _ZNK5boost15program_options11typed_valueIbcE6notifyERKNS_3anyE
void __fastcall boost::program_options::typed_value<bool,char>::notify(
        const boost::program_options::typed_value<bool,char> *this,
        const boost::any_0 *value_store)
{
  void *v4; // rax
  const char *v5; // rdi
  const char *v6; // rsi
  boost::any::placeholder *v7; // rsi
  _BYTE *v8; // rax
  __int64 v9; // rax
  void (__fastcall *v10)(boost::function1<void,const bool &>::dummy *); // rcx
  _QWORD v11[4]; // [rsp+8h] [rbp-20h] BYREF

  if ( value_store->content )
    v4 = (void *)(*((__int64 (__fastcall **)(boost::any::placeholder *))value_store->content->_vptr$placeholder + 2))(value_store->content);
  else
    v4 = &`typeinfo for'void;
  v5 = (const char *)*((_QWORD *)v4 + 1);
  v6 = (const char *)`typeinfo for'bool[1];
  if ( v5 == v6 || !strcmp(v5, v6) )
    v7 = value_store->content + 1;
  else
    v7 = 0;
  v8 = (_BYTE *)*((_QWORD *)this + 2);
  if ( v8 )
    *v8 = v7->_vptr$placeholder;
  v9 = *((_QWORD *)this + 15);
  v10 = boost::function1<void,bool const&>::dummy::nonnull;
  if ( !v9 )
    v10 = 0;
  if ( v10 )
  {
    if ( !v9 )
    {
      std::runtime_error::runtime_error((std::runtime_error *)v11, "call to empty boost::function");
      v11[0] = off_2875ED8;
      boost::throw_exception<boost::bad_function_call>((const boost::bad_function_call *)v11);
    }
    (*(void (__fastcall **)(char *, boost::any::placeholder *))((v9 & 0xFFFFFFFFFFFFFFFELL) + 8))(
      (char *)this + 128,
      v7);
  }
}


// Address: 0xe68660 | Name: _ZNK5boost15program_options11typed_valueIbcE6xparseERNS_3anyERKNSt3__16vectorINS5_12basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENSA_ISC_EEEE
void __fastcall boost::program_options::typed_value<bool,char>::xparse(
        const boost::program_options::typed_value<bool,char> *this,
        boost::any_0 *value_store,
        const std::vector<std::string> *new_tokens)
{
  int v3; // ecx
  __int64 v4; // rdi
  boost::any::placeholder *v5; // rax
  boost::any::placeholder *content; // rdi

  if ( *(_QWORD *)new_tokens == *((_QWORD *)new_tokens + 1) && (v4 = *((_QWORD *)this + 10)) != 0 )
  {
    v5 = (boost::any::placeholder *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
    content = value_store->content;
    value_store->content = v5;
    if ( content )
      (*((void (__fastcall **)(boost::any::placeholder *))content->_vptr$placeholder + 1))(content);
  }
  else
  {
    boost::program_options::validate(value_store, new_tokens, (bool *)new_tokens, v3);
  }
}


