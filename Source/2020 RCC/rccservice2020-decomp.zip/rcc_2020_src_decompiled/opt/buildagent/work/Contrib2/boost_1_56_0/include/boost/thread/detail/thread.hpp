// Address: 0xdac680 | Name: _ZN5boost6threadC2INS_9function0IvEEEEOT_
void __fastcall boost::thread::thread<boost::function0<void>>(boost::thread *this, boost::function0<void>_0 *f)
{
  void (__fastcall *v2)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::function0<void>_0 v3; // [rsp+0h] [rbp-38h] BYREF

  v3.vtable = 0;
  boost::function0<void>::move_assign(&v3, f);
  boost::thread::make_thread_info<boost::function0<void>>(&v3);
  if ( v3.vtable )
  {
    if ( ((__int64)v3.vtable & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v3.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2(&v3.functor, &v3.functor, 2);
    }
    v3.vtable = 0;
  }
  boost::thread::start_thread(this);
}


// Address: 0xdac8a0 | Name: _ZN5boost6thread4joinEv
void __fastcall boost::thread::join(boost::thread *this)
{
  boost::thread::native_handle_type v1; // r14
  const boost::system::error_category *v2; // rbx
  _QWORD v3[2]; // [rsp+0h] [rbp-48h] BYREF
  int v4; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v5; // [rsp+18h] [rbp-30h]
  __int128 v6; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  v1 = boost::thread::native_handle(this);
  if ( pthread_self() == v1 )
  {
    v2 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v3, "boost thread: trying joining itself");
    v4 = 35;
    v5 = v2;
    v6 = 0;
    ptr = 0;
    v3[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v3);
  }
  boost::thread::join_noexcept(this);
}


// Address: 0xdbc900 | Name: _ZN5boost6threadC2INS_3_bi6bind_tIvPFvRKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS_10shared_ptrIN3RBX9DataModelEEElSC_RKNSD_IKNS_9unordered13unordered_mapISA_NSE_10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairISB_SM_EEEEEEEENSE_5TimerILNSE_4Time12SampleMethodE0EEEENS2_5list6INS2_5valueISA_EENS16_ISG_EENS16_IlEES17_NS16_ISW_EENS16_IS12_EEEEEEEEOT_
void __fastcall boost::thread::thread<boost::_bi::bind_t<void,void (*)(std::string const&,boost::shared_ptr<RBX::DataModel> const&,long,std::string const&,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const> const&,RBX::Timer<(RBX::Time::SampleMethod)0>),boost::_bi::list6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>>>(
        boost::thread *this,
        boost::_bi::bind_t<void,void (*)(const std::string &,const boost::shared_ptr<RBX::DataModel> &,long,const std::string &,const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > &,RBX::Timer<RBX::Time::Fast>),boost::_bi::list6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > > *f)
{
  __int64 v2; // r15
  __int64 v3; // rbp
  char v4; // r14
  __int64 v5; // r12
  char *v6; // rbx
  __int64 v7; // rax
  __int64 v8; // rax
  char v9; // [rsp+Fh] [rbp-89h]
  void *ptr; // [rsp+10h] [rbp-88h]
  void *v11; // [rsp+18h] [rbp-80h]
  __m128i v12; // [rsp+20h] [rbp-78h] BYREF
  __int128 v13; // [rsp+30h] [rbp-68h]
  _QWORD v14[11]; // [rsp+40h] [rbp-58h] BYREF

  v14[4] = __readfsqword(0x28u);
  v2 = *(_QWORD *)f;
  v9 = *((_BYTE *)f + 8);
  *(_QWORD *)((char *)&v14[2] + 7) = *((_QWORD *)f + 2);
  v14[2] = *(_QWORD *)((char *)f + 9);
  v11 = (void *)*((_QWORD *)f + 3);
  *(_OWORD *)((char *)f + 8) = 0;
  *((_QWORD *)f + 3) = 0;
  v13 = *((_OWORD *)f + 2);
  *((_OWORD *)f + 2) = 0;
  v3 = *((_QWORD *)f + 6);
  v4 = *((_BYTE *)f + 56);
  *(_QWORD *)((char *)v14 + 7) = *((_QWORD *)f + 8);
  v14[0] = *(_QWORD *)((char *)f + 57);
  ptr = (void *)*((_QWORD *)f + 9);
  *(_OWORD *)((char *)f + 56) = 0;
  *((_QWORD *)f + 9) = 0;
  v12 = *((__m128i *)f + 5);
  *((_OWORD *)f + 5) = 0;
  v5 = *((_QWORD *)f + 12);
  v6 = (char *)operator new(0x208u);
  boost::detail::thread_data_base::thread_data_base((boost::detail::thread_data_base *)v6);
  *(_QWORD *)v6 = &off_2878FE8;
  *((_QWORD *)v6 + 52) = v2;
  v6[424] = v9;
  v7 = v14[2];
  *((_QWORD *)v6 + 54) = *(_QWORD *)((char *)&v14[2] + 7);
  *(_QWORD *)(v6 + 425) = v7;
  *((_QWORD *)v6 + 55) = v11;
  memset(&v14[2], 0, 15);
  *((_OWORD *)v6 + 28) = v13;
  *((_QWORD *)v6 + 58) = v3;
  v6[472] = v4;
  v8 = v14[0];
  *((_QWORD *)v6 + 60) = *(_QWORD *)((char *)v14 + 7);
  *(_QWORD *)(v6 + 473) = v8;
  *((_QWORD *)v6 + 61) = ptr;
  memset(v14, 0, 15);
  *((__m128i *)v6 + 31) = _mm_load_si128(&v12);
  *((_QWORD *)v6 + 64) = v5;
  this->thread_info.px = v6;
  this->thread_info.pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(std::string const&,boost::shared_ptr<RBX::DataModel> const&,long,std::string const&,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const> const&,RBX::Timer<(RBX::Time::SampleMethod)0>),boost::_bi::list6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>>>>(
    &this->thread_info,
    (boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const std::string &,const boost::shared_ptr<RBX::DataModel> &,long,const std::string &,const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > &,RBX::Timer<RBX::Time::Fast>),boost::_bi::list6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > > > *)v6,
    &this->thread_info.pn);
  boost::thread::start_thread(this);
}


// Address: 0xdcf680 | Name: _ZN5boost6thread12start_threadEv
void __fastcall boost::thread::start_thread(boost::thread *this)
{
  const boost::system::error_category *v1; // rbx
  _QWORD v2[2]; // [rsp+0h] [rbp-48h] BYREF
  int v3; // [rsp+10h] [rbp-38h]
  const boost::system::error_category *v4; // [rsp+18h] [rbp-30h]
  __int128 v5; // [rsp+20h] [rbp-28h]
  void *ptr; // [rsp+30h] [rbp-18h]

  if ( !boost::thread::start_thread_noexcept(this) )
  {
    v1 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)v2, "boost::thread_resource_error");
    v3 = 11;
    v4 = v1;
    v5 = 0;
    ptr = 0;
    v2[0] = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)v2);
  }
}


// Address: 0xdcf8a0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvRKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS_10shared_ptrIN3RBX9DataModelEEElSC_RKNSD_IKNS_9unordered13unordered_mapISA_NSE_10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairISB_SM_EEEEEEEENSE_5TimerILNSE_4Time12SampleMethodE0EEEENS2_5list6INS2_5valueISA_EENS16_ISG_EENS16_IlEES17_NS16_ISW_EENS16_IS12_EEEEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(std::string const&,boost::shared_ptr<RBX::DataModel> const&,long,std::string const&,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const> const&,RBX::Timer<(RBX::Time::SampleMethod)0>),boost::_bi::list6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const std::string &,const boost::shared_ptr<RBX::DataModel> &,long,const std::string &,const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > &,RBX::Timer<RBX::Time::Fast>),boost::_bi::list6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > > > *this)
{
  *(_QWORD *)this = &off_2878FE8;
  boost::_bi::storage5<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>>::~storage5((boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const std::string &,const boost::shared_ptr<RBX::DataModel> &,long,const std::string &,const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > &,RBX::Timer<RBX::Time::Fast>),boost::_bi::list6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > > > *)((char *)this + 424));
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0xdcf8d0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvRKNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS_10shared_ptrIN3RBX9DataModelEEElSC_RKNSD_IKNS_9unordered13unordered_mapISA_NSE_10Reflection7VariantENS_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairISB_SM_EEEEEEEENSE_5TimerILNSE_4Time12SampleMethodE0EEEENS2_5list6INS2_5valueISA_EENS16_ISG_EENS16_IlEES17_NS16_ISW_EENS16_IS12_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(std::string const&,boost::shared_ptr<RBX::DataModel> const&,long,std::string const&,boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const> const&,RBX::Timer<(RBX::Time::SampleMethod)0>),boost::_bi::list6<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>,boost::_bi::value<RBX::Timer<(RBX::Time::SampleMethod)0>>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const std::string &,const boost::shared_ptr<RBX::DataModel> &,long,const std::string &,const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > &,RBX::Timer<RBX::Time::Fast>),boost::_bi::list6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > > > *this)
{
  *(_QWORD *)this = &off_2878FE8;
  boost::_bi::storage5<boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<RBX::DataModel>>,boost::_bi::value<long>,boost::_bi::value<std::string>,boost::_bi::value<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>>::~storage5((boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const std::string &,const boost::shared_ptr<RBX::DataModel> &,long,const std::string &,const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > &,RBX::Timer<RBX::Time::Fast>),boost::_bi::list6<boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<RBX::DataModel> >,boost::_bi::value<long>,boost::_bi::value<std::string >,boost::_bi::value<boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > >,boost::_bi::value<RBX::Timer<RBX::Time::Fast> > > > > *)((char *)this + 424));
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0xdd3a50 | Name: _ZN5boost6thread16make_thread_infoINS_9function0IvEEEENS_10shared_ptrINS_6detail16thread_data_baseEEEOT_
boost::shared_ptr<boost::detail::thread_data_base> *__fastcall boost::thread::make_thread_info<boost::function0<void>>(
        boost::shared_ptr<boost::detail::thread_data_base> *a1,
        boost::function0<void>_0 *f)
{
  boost::function0<void>_0 *v2; // rbx

  v2 = (boost::function0<void>_0 *)operator new(0x1C0u);
  boost::detail::thread_data_base::thread_data_base((boost::detail::thread_data_base *)v2);
  v2->vtable = (boost::detail::function::vtable_base *)&off_28794B8;
  v2[13].vtable = 0;
  boost::function0<void>::move_assign(v2 + 13, f);
  a1->px = v2;
  a1->pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::function0<void>>>(
    a1,
    (boost::detail::thread_data<boost::function0<void> > *)v2,
    &a1->pn);
  return a1;
}


// Address: 0xdd3b20 | Name: _ZN5boost6detail11thread_dataINS_9function0IvEEED2Ev
void __fastcall boost::detail::thread_data<boost::function0<void>>::~thread_data(
        boost::detail::thread_data<boost::function0<void> > *this)
{
  __int64 v1; // rax
  void (__fastcall *v2)(char *, char *, __int64); // rax

  *(_QWORD *)this = &off_28794B8;
  v1 = *((_QWORD *)this + 52);
  if ( v1 )
  {
    if ( (v1 & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(char *, char *, __int64))(v1 & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2((char *)this + 424, (char *)this + 424, 2);
    }
    *((_QWORD *)this + 52) = 0;
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0xdd3b80 | Name: _ZN5boost6detail11thread_dataINS_9function0IvEEED0Ev
void __fastcall boost::detail::thread_data<boost::function0<void>>::~thread_data(
        boost::detail::thread_data<boost::function0<void> > *this)
{
  __int64 v1; // rax
  void (__fastcall *v2)(char *, char *, __int64); // rax

  *(_QWORD *)this = &off_28794B8;
  v1 = *((_QWORD *)this + 52);
  if ( v1 )
  {
    if ( (v1 & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(char *, char *, __int64))(v1 & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2((char *)this + 424, (char *)this + 424, 2);
    }
    *((_QWORD *)this + 52) = 0;
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0xdd3be0 | Name: _ZN5boost6detail11thread_dataINS_9function0IvEEE3runEv
void __fastcall boost::detail::thread_data<boost::function0<void>>::run(
        boost::detail::thread_data<boost::function0<void> > *this)
{
  __int64 v1; // rax
  _QWORD v2[3]; // [rsp+0h] [rbp-18h] BYREF

  v1 = *((_QWORD *)this + 52);
  if ( !v1 )
  {
    std::runtime_error::runtime_error((std::runtime_error *)v2, "call to empty boost::function");
    v2[0] = off_2875ED8;
    boost::throw_exception<boost::bad_function_call>((const boost::bad_function_call *)v2);
  }
  (*(void (__fastcall **)(char *))((v1 & 0xFFFFFFFFFFFFFFFELL) + 8))((char *)this + 424);
}


// Address: 0xe4c8e0 | Name: _ZN5boost6detail11thread_dataIPFvvEED0Ev
void __fastcall boost::detail::thread_data<void (*)(void)>::~thread_data(boost::detail::thread_data<void (*)()> *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0xe4c900 | Name: _ZN5boost6detail11thread_dataIPFvvEE3runEv
void __fastcall boost::detail::thread_data<void (*)(void)>::run(boost::detail::thread_data<void (*)()> *this)
{
  (*((void (**)(void))this + 52))();
}


// Address: 0xfd2010 | Name: _ZN5boost6threadC2IPFvNS_8weak_ptrIN3RBX8Security19AslrPmcSharedHasherEEEES6_EET_T0_NS_10disable_ifINS_13thread_detail14is_convertibleIRS9_NS_17thread_attributesEEEPNS0_5dummyEE4typeE
void __fastcall boost::thread::thread<void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>(
        boost::thread *this,
        void (*f)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),
        boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> a1,
        unsigned __int64 a4)
{
  __int64 v5; // rax
  char *v6; // rbx
  boost::detail::sp_counted_base *pi; // rdi
  __int64 v8; // rdi
  __int64 v9; // [rsp+0h] [rbp-48h] BYREF
  __int64 v10; // [rsp+8h] [rbp-40h]
  boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> > > > v11; // [rsp+10h] [rbp-38h] BYREF

  v9 = *(_QWORD *)a1.px;
  v5 = *((_QWORD *)a1.px + 1);
  v10 = v5;
  if ( v5 )
    _InterlockedAdd((volatile signed __int32 *)(v5 + 12), 1u);
  boost::bind<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>(
    &v11,
    (boost::type<void>)f,
    (void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>))&v9,
    (boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>)__PAIR128__(a4, (unsigned __int64)a1.pn.pi_));
  v6 = (char *)operator new(0x1B8u);
  boost::detail::thread_data_base::thread_data_base((boost::detail::thread_data_base *)v6);
  *(_QWORD *)v6 = &off_2888F98;
  *(boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> > > > *)(v6 + 416) = v11;
  v11.l_ = 0;
  this->thread_info.px = v6;
  this->thread_info.pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>>>>>(
    &this->thread_info,
    (boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> > > > > *)v6,
    &this->thread_info.pn);
  pi = v11.l_.a1_.t_.pn.pi_;
  if ( v11.l_.a1_.t_.pn.pi_ && !_InterlockedSub(&v11.l_.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  v8 = v10;
  if ( v10 && !_InterlockedSub((volatile signed __int32 *)(v10 + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v8 + 24LL))(v8);
  boost::thread::start_thread(this);
}


// Address: 0xfd5870 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX8Security19AslrPmcSharedHasherEEEENS2_5list1INS2_5valueIS8_EEEEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> > > > > *this)
{
  volatile signed __int32 *v2; // rdi

  *(_QWORD *)this = &off_2888F98;
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 54);
  if ( v2 && !_InterlockedSub(v2 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0xfd58b0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX8Security19AslrPmcSharedHasherEEEENS2_5list1INS2_5valueIS8_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> > > > > *this)
{
  volatile signed __int32 *v2; // rdi

  *(_QWORD *)this = &off_2888F98;
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 54);
  if ( v2 && !_InterlockedSub(v2 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0xfd58f0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX8Security19AslrPmcSharedHasherEEEENS2_5list1INS2_5valueIS8_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::Security::AslrPmcSharedHasher>),boost::_bi::list1<boost::_bi::value<boost::weak_ptr<RBX::Security::AslrPmcSharedHasher> > > > > *this)
{
  void (__fastcall *v1)(__int64 *); // rax
  __int64 v2; // rcx
  __int64 v3; // rdi
  __int64 v4; // [rsp+0h] [rbp-18h] BYREF
  __int64 v5; // [rsp+8h] [rbp-10h]

  v1 = (void (__fastcall *)(__int64 *))*((_QWORD *)this + 52);
  v4 = *((_QWORD *)this + 53);
  v2 = *((_QWORD *)this + 54);
  v5 = v2;
  if ( v2 )
    _InterlockedAdd((volatile signed __int32 *)(v2 + 12), 1u);
  v1(&v4);
  v3 = v5;
  if ( v5 )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(v5 + 12), 1u) )
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  }
}


// Address: 0xfe6620 | Name: _ZN5boost6threadC2INS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX9DataModelEEENS4_INS5_7Network16ServerReplicatorEEEi14PacketPriorityiENS2_5list5INS2_5valueIS7_EENSF_ISA_EENSF_IiEENSF_ISB_EESI_EEEEEEOT_
void __fastcall boost::thread::thread<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>(
        boost::thread *this,
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > *f)
{
  boost::detail::thread_data_ptr v3; // rax
  boost::detail::sp_counted_base *pi; // rdi
  boost::detail::sp_counted_base *v5; // rdi
  boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > v6; // [rsp+0h] [rbp-48h] BYREF

  *(_OWORD *)&v6.f_ = *(_OWORD *)&f->f_;
  v6.l_.a1_.t_.pn.pi_ = f->l_.a1_.t_.pn.pi_;
  f->l_.boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::DataModel> > > = 0;
  v6.l_.a2_ = f->l_.a2_;
  f->l_.a2_ = 0;
  v6.l_.a3_.t_ = f->l_.a3_.t_;
  v6.l_.a4_.t_ = f->l_.a4_.t_;
  v6.l_.a5_.t_ = f->l_.a5_.t_;
  v3 = boost::thread::make_thread_info<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>(&v6);
  pi = v6.l_.a2_.t_.pn.pi_;
  if ( v6.l_.a2_.t_.pn.pi_ && !_InterlockedSub(&v6.l_.a2_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > *, boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base
     + 3))(
      pi,
      &v6,
      v3.pn.pi_);
  v5 = v6.l_.a1_.t_.pn.pi_;
  if ( v6.l_.a1_.t_.pn.pi_ && !_InterlockedSub(&v6.l_.a1_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > *, boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base
     + 3))(
      v5,
      &v6,
      v3.pn.pi_);
  boost::thread::start_thread(this);
}


// Address: 0xfeced0 | Name: _ZN5boost6thread16make_thread_infoINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX9DataModelEEENS4_INS5_7Network16ServerReplicatorEEEi14PacketPriorityiENS2_5list5INS2_5valueIS7_EENSF_ISA_EENSF_IiEENSF_ISB_EESI_EEEEEENS_10shared_ptrINS_6detail16thread_data_baseEEEOT_
boost::shared_ptr<boost::detail::thread_data_base> *__fastcall boost::thread::make_thread_info<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *a1,
        boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > *f)
{
  char *v2; // rbx

  v2 = (char *)operator new(0x1D8u);
  boost::detail::thread_data_base::thread_data_base((boost::detail::thread_data_base *)v2);
  *(_QWORD *)v2 = &off_288A8A0;
  *((_OWORD *)v2 + 26) = *(_OWORD *)&f->f_;
  *((_QWORD *)v2 + 54) = f->l_.a1_.t_.pn.pi_;
  f->l_.boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::DataModel> > > = 0;
  *(boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> > *)(v2 + 440) = f->l_.a2_;
  f->l_.a2_ = 0;
  *((_DWORD *)v2 + 114) = f->l_.a3_.t_;
  *((_DWORD *)v2 + 115) = f->l_.a4_.t_;
  *((_DWORD *)v2 + 116) = f->l_.a5_.t_;
  a1->px = v2;
  a1->pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>>(
    a1,
    (boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > > *)v2,
    &a1->pn);
  return a1;
}


// Address: 0xfecfc0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX9DataModelEEENS4_INS5_7Network16ServerReplicatorEEEi14PacketPriorityiENS2_5list5INS2_5valueIS7_EENSF_ISA_EENSF_IiEENSF_ISB_EESI_EEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > > *this)
{
  volatile signed __int32 *v2; // rdi
  volatile signed __int32 *v3; // rdi

  *(_QWORD *)this = &off_288A8A0;
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v2 && !_InterlockedSub(v2 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
  v3 = (volatile signed __int32 *)*((_QWORD *)this + 54);
  if ( v3 && !_InterlockedSub(v3 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0xfed020 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX9DataModelEEENS4_INS5_7Network16ServerReplicatorEEEi14PacketPriorityiENS2_5list5INS2_5valueIS7_EENSF_ISA_EENSF_IiEENSF_ISB_EESI_EEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > > *this)
{
  volatile signed __int32 *v2; // rdi
  volatile signed __int32 *v3; // rdi

  *(_QWORD *)this = &off_288A8A0;
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v2 && !_InterlockedSub(v2 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
  v3 = (volatile signed __int32 *)*((_QWORD *)this + 54);
  if ( v3 && !_InterlockedSub(v3 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0xfed090 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_8weak_ptrIN3RBX9DataModelEEENS4_INS5_7Network16ServerReplicatorEEEi14PacketPriorityiENS2_5list5INS2_5valueIS7_EENSF_ISA_EENSF_IiEENSF_ISB_EESI_EEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > > > *this)
{
  void (*v1)(boost::weak_ptr<RBX::DataModel>, boost::weak_ptr<RBX::Network::ServerReplicator>, int, PacketPriority, int); // rax
  int v2; // r8d
  void (*v3)(boost::weak_ptr<RBX::DataModel>, boost::weak_ptr<RBX::Network::ServerReplicator>, int, PacketPriority, int); // [rsp-8h] [rbp-8h] BYREF

  v3 = v1;
  boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator>>,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int>>::operator()<void (*)(boost::weak_ptr<RBX::DataModel>,boost::weak_ptr<RBX::Network::ServerReplicator>,int,PacketPriority,int),boost::_bi::list0>(
    (boost::_bi::list5<boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<boost::weak_ptr<RBX::Network::ServerReplicator> >,boost::_bi::value<int>,boost::_bi::value<PacketPriority>,boost::_bi::value<int> > *)((char *)this + 424),
    (boost::_bi::type<void>)((_BYTE)this - 96),
    &v3,
    0,
    v2);
}


// Address: 0x102f1b0 | Name: _ZN5boost6threadC2IPFvNS_10shared_ptrIN3RBX8Security19AslrPmcSharedHasherEEENSt3__112basic_stringIcNS7_11char_traitsIcEENS7_9allocatorIcEEEEmES6_SD_mEET_T0_T1_T2_
void __fastcall boost::thread::thread<void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long>(
        boost::thread *this,
        __int64 a2,
        __int64 *a3,
        __int64 a4,
        __int64 a5)
{
  volatile signed __int32 *v6; // rax
  char *v7; // rbx
  volatile signed __int32 *v8; // rax
  volatile signed __int32 *v9; // rbx
  volatile signed __int32 *v10; // rbx
  __int64 v11; // [rsp+0h] [rbp-88h] BYREF
  volatile signed __int32 *v12; // [rsp+8h] [rbp-80h]
  __int128 v13; // [rsp+10h] [rbp-78h] BYREF
  volatile signed __int32 *v14; // [rsp+20h] [rbp-68h]
  __int128 v15; // [rsp+28h] [rbp-60h]
  void *ptr; // [rsp+38h] [rbp-50h]
  __int64 v17; // [rsp+40h] [rbp-48h]
  _BYTE v18[16]; // [rsp+50h] [rbp-38h] BYREF
  void *v19; // [rsp+60h] [rbp-28h]

  v11 = *a3;
  v6 = (volatile signed __int32 *)a3[1];
  v12 = v6;
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  std::string::basic_string(v18, a4);
  boost::bind<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long>(
    &v13,
    a2,
    &v11,
    v18,
    a5);
  v7 = (char *)operator new(0x1D8u);
  boost::detail::thread_data_base::thread_data_base((boost::detail::thread_data_base *)v7);
  *(_QWORD *)v7 = &off_288CDA8;
  *((_OWORD *)v7 + 26) = v13;
  v8 = v14;
  v14 = 0;
  *((_QWORD *)v7 + 54) = v8;
  *((_QWORD *)&v13 + 1) = 0;
  *((_QWORD *)v7 + 57) = ptr;
  *(_OWORD *)(v7 + 440) = v15;
  v15 = 0;
  ptr = 0;
  *((_QWORD *)v7 + 58) = v17;
  this->thread_info.px = v7;
  this->thread_info.pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>>,boost::_bi::value<std::string>,boost::_bi::value<unsigned long>>>>>(
    &this->thread_info,
    (boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> >,boost::_bi::value<std::string >,boost::_bi::value<unsigned long> > > > *)v7,
    &this->thread_info.pn);
  if ( (v15 & 1) != 0 )
    operator delete(ptr);
  v9 = v14;
  if ( v14 )
  {
    if ( !_InterlockedSub(v14 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  if ( (v18[0] & 1) != 0 )
    operator delete(v19);
  v10 = v12;
  if ( v12 )
  {
    if ( !_InterlockedSub(v12 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
      if ( !_InterlockedSub(v10 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
    }
  }
  boost::thread::start_thread(this);
}


// Address: 0x1032610 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_10shared_ptrIN3RBX8Security19AslrPmcSharedHasherEEENSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEEmENS2_5list3INS2_5valueIS8_EENSJ_ISF_EENSJ_ImEEEEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>>,boost::_bi::value<std::string>,boost::_bi::value<unsigned long>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> >,boost::_bi::value<std::string >,boost::_bi::value<unsigned long> > > > *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = &off_288CDA8;
  if ( (*((_BYTE *)this + 440) & 1) != 0 )
    operator delete(*((void **)this + 57));
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 54);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x1032680 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_10shared_ptrIN3RBX8Security19AslrPmcSharedHasherEEENSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEEmENS2_5list3INS2_5valueIS8_EENSJ_ISF_EENSJ_ImEEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>>,boost::_bi::value<std::string>,boost::_bi::value<unsigned long>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> >,boost::_bi::value<std::string >,boost::_bi::value<unsigned long> > > > *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = &off_288CDA8;
  if ( (*((_BYTE *)this + 440) & 1) != 0 )
    operator delete(*((void **)this + 57));
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 54);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x1032700 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvNS_10shared_ptrIN3RBX8Security19AslrPmcSharedHasherEEENSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEEmENS2_5list3INS2_5valueIS8_EENSJ_ISF_EENSJ_ImEEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>>,boost::_bi::value<std::string>,boost::_bi::value<unsigned long>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> >,boost::_bi::value<std::string >,boost::_bi::value<unsigned long> > > > *this)
{
  void (*v1)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>, std::string, unsigned __int64); // rax
  int v2; // r8d
  void (*v3)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>, std::string, unsigned __int64); // [rsp-8h] [rbp-8h] BYREF

  v3 = v1;
  boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>>,boost::_bi::value<std::string>,boost::_bi::value<unsigned long>>::operator()<void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list0>(
    (boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(boost::shared_ptr<RBX::Security::AslrPmcSharedHasher>,std::string,unsigned long),boost::_bi::list3<boost::_bi::value<boost::shared_ptr<RBX::Security::AslrPmcSharedHasher> >,boost::_bi::value<std::string >,boost::_bi::value<unsigned long> > > > *)((char *)this + 424),
    (boost::_bi::type<void>)((_BYTE)this - 96),
    &v3,
    0,
    v2);
}


// Address: 0x1111d60 | Name: _ZN5boost6threadD2Ev
void __fastcall boost::thread::~thread(boost::thread *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  boost::thread::detach(this);
  pi = this->thread_info.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x1111e70 | Name: _ZN5boost6threadaSEOS0_
boost::thread *__fastcall boost::thread::operator=(boost::thread *this, boost::thread *other)
{
  boost::shared_ptr<boost::detail::thread_data_base>::element_type *px; // rcx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // rbx
  boost::detail::sp_counted_base *v5; // rbx

  px = other->thread_info.px;
  pi = other->thread_info.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->thread_info.px = px;
  v4 = this->thread_info.pn.pi_;
  this->thread_info.pn.pi_ = pi;
  if ( v4 )
  {
    if ( !_InterlockedSub(&v4->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
      if ( !_InterlockedSub(&v4->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
    }
  }
  v5 = other->thread_info.pn.pi_;
  *other = 0;
  if ( v5 )
  {
    if ( !_InterlockedSub(&v5->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
      if ( !_InterlockedSub(&v5->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
    }
  }
  return this;
}


// Address: 0x11d8a20 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13ScriptContextEEENS2_5list1INS2_5valueIPS7_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext*>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext *> > > > *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x11d8a40 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13ScriptContextEEENS2_5list1INS2_5valueIPS7_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext*>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::ScriptContext>,boost::_bi::list1<boost::_bi::value<RBX::ScriptContext *> > > > *this)
{
  void (__fastcall *v1)(_QWORD); // rcx
  _QWORD *v2; // rdi

  v1 = (void (__fastcall *)(_QWORD))*((_QWORD *)this + 52);
  v2 = (_QWORD *)(*((_QWORD *)this + 53) + *((_QWORD *)this + 54));
  if ( ((unsigned __int8)v1 & 1) != 0 )
    v1 = *(void (__fastcall **)(_QWORD))((char *)v1 + *v2 - 1);
  v1(v2);
}


// Address: 0x11ff650 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX9Analytics11EventIngest16DeferredReporterENS_10shared_ptrIN12_GLOBAL__N_111SharedStateEEEEENS2_5list2INS2_5valueIPS9_EENSG_ISD_EEEEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Analytics::EventIngest::DeferredReporter,boost::shared_ptr<`anonymous namespace'::SharedState>>,boost::_bi::list2<boost::_bi::value<RBX::Analytics::EventIngest::DeferredReporter*>,boost::_bi::value<boost::shared_ptr<`anonymous namespace'::SharedState>>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Analytics::EventIngest::DeferredReporter,boost::shared_ptr<(anonymous namespace)::SharedState> >,boost::_bi::list2<boost::_bi::value<RBX::Analytics::EventIngest::DeferredReporter *>,boost::_bi::value<boost::shared_ptr<(anonymous namespace)::SharedState> > > > > *this)
{
  volatile signed __int32 *v1; // rbx

  *(_QWORD *)this = &off_28A25F8;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x11ff6b0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX9Analytics11EventIngest16DeferredReporterENS_10shared_ptrIN12_GLOBAL__N_111SharedStateEEEEENS2_5list2INS2_5valueIPS9_EENSG_ISD_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Analytics::EventIngest::DeferredReporter,boost::shared_ptr<`anonymous namespace'::SharedState>>,boost::_bi::list2<boost::_bi::value<RBX::Analytics::EventIngest::DeferredReporter*>,boost::_bi::value<boost::shared_ptr<`anonymous namespace'::SharedState>>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Analytics::EventIngest::DeferredReporter,boost::shared_ptr<(anonymous namespace)::SharedState> >,boost::_bi::list2<boost::_bi::value<RBX::Analytics::EventIngest::DeferredReporter *>,boost::_bi::value<boost::shared_ptr<(anonymous namespace)::SharedState> > > > > *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = &off_28A25F8;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x11ff710 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX9Analytics11EventIngest16DeferredReporterENS_10shared_ptrIN12_GLOBAL__N_111SharedStateEEEEENS2_5list2INS2_5valueIPS9_EENSG_ISD_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Analytics::EventIngest::DeferredReporter,boost::shared_ptr<`anonymous namespace'::SharedState>>,boost::_bi::list2<boost::_bi::value<RBX::Analytics::EventIngest::DeferredReporter*>,boost::_bi::value<boost::shared_ptr<`anonymous namespace'::SharedState>>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Analytics::EventIngest::DeferredReporter,boost::shared_ptr<(anonymous namespace)::SharedState> >,boost::_bi::list2<boost::_bi::value<RBX::Analytics::EventIngest::DeferredReporter *>,boost::_bi::value<boost::shared_ptr<(anonymous namespace)::SharedState> > > > > *this)
{
  __int64 v2; // rdi
  __int64 v3; // rdx
  volatile signed __int32 *v4; // r15
  char *v5; // rcx
  _QWORD *v6; // rdi
  volatile signed __int32 *v7; // rbx
  __int64 v8; // [rsp+0h] [rbp-28h] BYREF
  volatile signed __int32 *v9; // [rsp+8h] [rbp-20h]

  v2 = *((_QWORD *)this + 54);
  v3 = *((_QWORD *)this + 55);
  v4 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v4 )
    _InterlockedAdd(v4 + 2, 1u);
  v5 = (char *)*((_QWORD *)this + 52);
  v6 = (_QWORD *)(*((_QWORD *)this + 53) + v2);
  if ( ((unsigned __int8)v5 & 1) != 0 )
    v5 = *(char **)&v5[*v6 - 1];
  v8 = v3;
  v9 = v4;
  if ( v4 )
    _InterlockedAdd(v4 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))v5)(v6, &v8);
  v7 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  if ( v4 && !_InterlockedSub(v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub(v4 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
  }
}


// Address: 0x11ff890 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX17DeferredEphemeralENS_10shared_ptrIN12_GLOBAL__N_111SharedStateEEEEENS2_5list2INS2_5valueIPS7_EENSE_ISB_EEEEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::DeferredEphemeral,boost::shared_ptr<`anonymous namespace'::SharedState>>,boost::_bi::list2<boost::_bi::value<RBX::DeferredEphemeral*>,boost::_bi::value<boost::shared_ptr<`anonymous namespace'::SharedState>>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::DeferredEphemeral,boost::shared_ptr<(anonymous namespace)::SharedState> >,boost::_bi::list2<boost::_bi::value<RBX::DeferredEphemeral *>,boost::_bi::value<boost::shared_ptr<(anonymous namespace)::SharedState> > > > > *this)
{
  volatile signed __int32 *v1; // rbx

  *(_QWORD *)this = &off_28A26A8;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x11ff8f0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX17DeferredEphemeralENS_10shared_ptrIN12_GLOBAL__N_111SharedStateEEEEENS2_5list2INS2_5valueIPS7_EENSE_ISB_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::DeferredEphemeral,boost::shared_ptr<`anonymous namespace'::SharedState>>,boost::_bi::list2<boost::_bi::value<RBX::DeferredEphemeral*>,boost::_bi::value<boost::shared_ptr<`anonymous namespace'::SharedState>>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::DeferredEphemeral,boost::shared_ptr<(anonymous namespace)::SharedState> >,boost::_bi::list2<boost::_bi::value<RBX::DeferredEphemeral *>,boost::_bi::value<boost::shared_ptr<(anonymous namespace)::SharedState> > > > > *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = &off_28A26A8;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x11ff950 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf1IvN3RBX17DeferredEphemeralENS_10shared_ptrIN12_GLOBAL__N_111SharedStateEEEEENS2_5list2INS2_5valueIPS7_EENSE_ISB_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::DeferredEphemeral,boost::shared_ptr<`anonymous namespace'::SharedState>>,boost::_bi::list2<boost::_bi::value<RBX::DeferredEphemeral*>,boost::_bi::value<boost::shared_ptr<`anonymous namespace'::SharedState>>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::DeferredEphemeral,boost::shared_ptr<(anonymous namespace)::SharedState> >,boost::_bi::list2<boost::_bi::value<RBX::DeferredEphemeral *>,boost::_bi::value<boost::shared_ptr<(anonymous namespace)::SharedState> > > > > *this)
{
  __int64 v2; // rdi
  __int64 v3; // rdx
  volatile signed __int32 *v4; // r15
  char *v5; // rcx
  _QWORD *v6; // rdi
  volatile signed __int32 *v7; // rbx
  __int64 v8; // [rsp+0h] [rbp-28h] BYREF
  volatile signed __int32 *v9; // [rsp+8h] [rbp-20h]

  v2 = *((_QWORD *)this + 54);
  v3 = *((_QWORD *)this + 55);
  v4 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v4 )
    _InterlockedAdd(v4 + 2, 1u);
  v5 = (char *)*((_QWORD *)this + 52);
  v6 = (_QWORD *)(*((_QWORD *)this + 53) + v2);
  if ( ((unsigned __int8)v5 & 1) != 0 )
    v5 = *(char **)&v5[*v6 - 1];
  v8 = v3;
  v9 = v4;
  if ( v4 )
    _InterlockedAdd(v4 + 2, 1u);
  ((void (__fastcall *)(_QWORD *, __int64 *))v5)(v6, &v8);
  v7 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  if ( v4 && !_InterlockedSub(v4 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
    if ( !_InterlockedSub(v4 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
  }
}


// Address: 0x1209de0 | Name: _ZN5boost6thread17do_try_join_untilERK8timespec
bool __fastcall boost::thread::do_try_join_until(boost::thread *this, const timespec *timeout)
{
  boost::thread::native_handle_type v2; // r15
  bool v3; // al
  const boost::system::error_category *v5; // rbx
  bool res[16]; // [rsp+8h] [rbp-50h] BYREF
  int v7; // [rsp+18h] [rbp-40h]
  const boost::system::error_category *v8; // [rsp+20h] [rbp-38h]
  __int128 v9; // [rsp+28h] [rbp-30h]
  void *ptr; // [rsp+38h] [rbp-20h]

  v2 = boost::thread::native_handle(this);
  if ( pthread_self() == v2 )
  {
    v5 = boost::system::system_category();
    std::runtime_error::runtime_error((std::runtime_error *)res, "boost thread: trying joining itself");
    v7 = 35;
    v8 = v5;
    v9 = 0;
    ptr = 0;
    *(_QWORD *)res = off_2876218;
    boost::throw_exception<boost::thread_resource_error>((const boost::thread_resource_error *)res);
  }
  v3 = boost::thread::do_try_join_until_noexcept(this, timeout, res);
  return res[0] && v3;
}


// Address: 0x122adb0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX24CacheableContentProviderEEENS2_5list1INS2_5valueIPS7_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider*>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider *> > > > *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x122add0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX24CacheableContentProviderEEENS2_5list1INS2_5valueIPS7_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider*>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::CacheableContentProvider>,boost::_bi::list1<boost::_bi::value<RBX::CacheableContentProvider *> > > > *this)
{
  void (__fastcall *v1)(_QWORD); // rcx
  _QWORD *v2; // rdi

  v1 = (void (__fastcall *)(_QWORD))*((_QWORD *)this + 52);
  v2 = (_QWORD *)(*((_QWORD *)this + 53) + *((_QWORD *)this + 54));
  if ( ((unsigned __int8)v1 & 1) != 0 )
    v1 = *(void (__fastcall **)(_QWORD))((char *)v1 + *v2 - 1);
  v1(v2);
}


// Address: 0x1290090 | Name: _ZN5boost6threadC2IMN3RBX10HttpClientEFvvEPS3_EET_T0_NS_10disable_ifINS_13thread_detail14is_convertibleIRS7_NS_17thread_attributesEEEPNS0_5dummyEE4typeE
void __fastcall boost::thread::thread<void (RBX::HttpClient::*)(void),RBX::HttpClient*>(
        boost::thread *this,
        void (*f)(RBX::HttpClient *),
        RBX::HttpClient *a1,
        boost::disable_if_c<false,boost::thread::dummy *>::type a4)
{
  boost::detail::thread_data_base *v6; // rbx

  v6 = (boost::detail::thread_data_base *)operator new(0x1B8u);
  boost::detail::thread_data_base::thread_data_base(v6);
  *(_QWORD *)v6 = &off_28A5C38;
  *((_QWORD *)v6 + 52) = f;
  *((_QWORD *)v6 + 53) = a1;
  *((_QWORD *)v6 + 54) = a4;
  this->thread_info.px = v6;
  this->thread_info.pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient*>>>>>(
    &this->thread_info,
    v6,
    &this->thread_info.pn);
  boost::thread::start_thread(this);
}


// Address: 0x1294650 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX17HttpClientHandlerEEENS2_5list1INS2_5valueIPS7_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler*>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler *> > > > *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x1294670 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX17HttpClientHandlerEEENS2_5list1INS2_5valueIPS7_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler*>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClientHandler>,boost::_bi::list1<boost::_bi::value<RBX::HttpClientHandler *> > > > *this)
{
  void (__fastcall *v1)(_QWORD); // rcx
  _QWORD *v2; // rdi

  v1 = (void (__fastcall *)(_QWORD))*((_QWORD *)this + 52);
  v2 = (_QWORD *)(*((_QWORD *)this + 53) + *((_QWORD *)this + 54));
  if ( ((unsigned __int8)v1 & 1) != 0 )
    v1 = *(void (__fastcall **)(_QWORD))((char *)v1 + *v2 - 1);
  v1(v2);
}


// Address: 0x12952f0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX10HttpClientEEENS2_5list1INS2_5valueIPS7_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient*>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient *> > > > *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x1295310 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX10HttpClientEEENS2_5list1INS2_5valueIPS7_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient*>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HttpClient>,boost::_bi::list1<boost::_bi::value<RBX::HttpClient *> > > > *this)
{
  void (__fastcall *v1)(_QWORD); // rcx
  _QWORD *v2; // rdi

  v1 = (void (__fastcall *)(_QWORD))*((_QWORD *)this + 52);
  v2 = (_QWORD *)(*((_QWORD *)this + 53) + *((_QWORD *)this + 54));
  if ( ((unsigned __int8)v1 & 1) != 0 )
    v1 = *(void (__fastcall **)(_QWORD))((char *)v1 + *v2 - 1);
  v1(v2);
}


// Address: 0x133ffb0 | Name: _ZN5boost6detail11thread_dataIZN3RBX10Soundscape12SoundService12endRecordingENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISF_EENS9_8equal_toISF_EENSD_INS9_4pairIKSF_SH_EEEEEEEEEEENS5_IFvSF_EEEE3$_0ED2Ev
void __fastcall boost::detail::thread_data<RBX::Soundscape::SoundService::endRecording(boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>)::$_0>::~thread_data(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:612:19)> *this)
{
  __int64 v1; // rax
  void (__fastcall *v2)(char *, char *, __int64); // rax
  __int64 v3; // rax
  void (__fastcall *v4)(char *, char *, __int64); // rax

  *(_QWORD *)this = &off_28AD788;
  v1 = *((_QWORD *)this + 57);
  if ( v1 )
  {
    if ( (v1 & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(char *, char *, __int64))(v1 & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2((char *)this + 464, (char *)this + 464, 2);
    }
    *((_QWORD *)this + 57) = 0;
  }
  v3 = *((_QWORD *)this + 53);
  if ( v3 )
  {
    if ( (v3 & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(char *, char *, __int64))(v3 & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4((char *)this + 432, (char *)this + 432, 2);
    }
    *((_QWORD *)this + 53) = 0;
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x1340050 | Name: _ZN5boost6detail11thread_dataIZN3RBX10Soundscape12SoundService12endRecordingENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISF_EENS9_8equal_toISF_EENSD_INS9_4pairIKSF_SH_EEEEEEEEEEENS5_IFvSF_EEEE3$_0ED0Ev
void __fastcall boost::detail::thread_data<RBX::Soundscape::SoundService::endRecording(boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>)::$_0>::~thread_data(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:612:19)> *this)
{
  __int64 v1; // rax
  void (__fastcall *v2)(char *, char *, __int64); // rax
  __int64 v3; // rax
  void (__fastcall *v4)(char *, char *, __int64); // rax

  *(_QWORD *)this = &off_28AD788;
  v1 = *((_QWORD *)this + 57);
  if ( v1 )
  {
    if ( (v1 & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(char *, char *, __int64))(v1 & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2((char *)this + 464, (char *)this + 464, 2);
    }
    *((_QWORD *)this + 57) = 0;
  }
  v3 = *((_QWORD *)this + 53);
  if ( v3 )
  {
    if ( (v3 & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(char *, char *, __int64))(v3 & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4((char *)this + 432, (char *)this + 432, 2);
    }
    *((_QWORD *)this + 53) = 0;
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x13400f0 | Name: _ZN5boost6detail11thread_dataIZN3RBX10Soundscape12SoundService12endRecordingENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISF_EENS9_8equal_toISF_EENSD_INS9_4pairIKSF_SH_EEEEEEEEEEENS5_IFvSF_EEEE3$_0E3runEv
void __fastcall boost::detail::thread_data<RBX::Soundscape::SoundService::endRecording(boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>)::$_0>::run(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:612:19)> *this)
{
  boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:612:19)> *v1; // rbx
  __int64 v2; // rax
  __int64 v3; // rax
  void (__fastcall *v4)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v5)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::function<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)>_0 resumeFunction; // [rsp+0h] [rbp-48h] BYREF
  boost::function<void (std::string)>_0 errorFunction; // [rsp+20h] [rbp-28h] BYREF

  v1 = this;
  resumeFunction.vtable = 0;
  v2 = *((_QWORD *)this + 53);
  if ( v2 )
  {
    resumeFunction.vtable = (boost::detail::function::vtable_base *)*((_QWORD *)this + 53);
    if ( (v2 & 1) != 0 )
    {
      resumeFunction.functor = *(boost::detail::function::function_buffer *)((_BYTE *)this + 18);
    }
    else
    {
      this = (boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:612:19)> *)((char *)this + 432);
      (*(void (__fastcall **)(boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:612:19)> *, boost::detail::function::function_buffer *, _QWORD))(v2 & 0xFFFFFFFFFFFFFFFELL))(
        this,
        &resumeFunction.functor,
        0);
    }
  }
  errorFunction.vtable = 0;
  v3 = *((_QWORD *)v1 + 57);
  if ( v3 )
  {
    errorFunction.vtable = (boost::detail::function::vtable_base *)*((_QWORD *)v1 + 57);
    if ( (v3 & 1) != 0 )
    {
      errorFunction.functor = *(boost::detail::function::function_buffer *)((char *)v1 + 464);
    }
    else
    {
      this = (boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:612:19)> *)((char *)v1 + 464);
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))(v3 & 0xFFFFFFFFFFFFFFFELL))(
        (__int64)v1 + 464,
        &errorFunction.functor,
        0);
    }
  }
  RBX::Soundscape::SoundService::handleEndRecording(this, &resumeFunction);
  if ( errorFunction.vtable )
  {
    if ( ((__int64)errorFunction.vtable & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)errorFunction.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4(&errorFunction.functor, &errorFunction.functor, 2);
    }
    errorFunction.vtable = 0;
  }
  if ( resumeFunction.vtable && ((__int64)resumeFunction.vtable & 1) == 0 )
  {
    v5 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)resumeFunction.vtable & 0xFFFFFFFFFFFFFFFELL);
    if ( v5 )
      v5(&resumeFunction.functor, &resumeFunction.functor, 2);
  }
}


// Address: 0x13402e0 | Name: _ZN5boost6detail11thread_dataIZN3RBX10Soundscape12SoundService19getRecordingDevicesENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISF_EENS9_8equal_toISF_EENSD_INS9_4pairIKSF_SH_EEEEEEEEEEENS5_IFvSF_EEEE3$_1ED2Ev
void __fastcall boost::detail::thread_data<RBX::Soundscape::SoundService::getRecordingDevices(boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>)::$_1>::~thread_data(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:622:19)> *this)
{
  __int64 v1; // rax
  void (__fastcall *v2)(char *, char *, __int64); // rax
  __int64 v3; // rax
  void (__fastcall *v4)(char *, char *, __int64); // rax

  *(_QWORD *)this = &off_28AD838;
  v1 = *((_QWORD *)this + 57);
  if ( v1 )
  {
    if ( (v1 & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(char *, char *, __int64))(v1 & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2((char *)this + 464, (char *)this + 464, 2);
    }
    *((_QWORD *)this + 57) = 0;
  }
  v3 = *((_QWORD *)this + 53);
  if ( v3 )
  {
    if ( (v3 & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(char *, char *, __int64))(v3 & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4((char *)this + 432, (char *)this + 432, 2);
    }
    *((_QWORD *)this + 53) = 0;
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x1340380 | Name: _ZN5boost6detail11thread_dataIZN3RBX10Soundscape12SoundService19getRecordingDevicesENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISF_EENS9_8equal_toISF_EENSD_INS9_4pairIKSF_SH_EEEEEEEEEEENS5_IFvSF_EEEE3$_1ED0Ev
void __fastcall boost::detail::thread_data<RBX::Soundscape::SoundService::getRecordingDevices(boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>)::$_1>::~thread_data(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:622:19)> *this)
{
  __int64 v1; // rax
  void (__fastcall *v2)(char *, char *, __int64); // rax
  __int64 v3; // rax
  void (__fastcall *v4)(char *, char *, __int64); // rax

  *(_QWORD *)this = &off_28AD838;
  v1 = *((_QWORD *)this + 57);
  if ( v1 )
  {
    if ( (v1 & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(char *, char *, __int64))(v1 & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2((char *)this + 464, (char *)this + 464, 2);
    }
    *((_QWORD *)this + 57) = 0;
  }
  v3 = *((_QWORD *)this + 53);
  if ( v3 )
  {
    if ( (v3 & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(char *, char *, __int64))(v3 & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4((char *)this + 432, (char *)this + 432, 2);
    }
    *((_QWORD *)this + 53) = 0;
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x1340420 | Name: _ZN5boost6detail11thread_dataIZN3RBX10Soundscape12SoundService19getRecordingDevicesENS_8functionIFvNS_10shared_ptrIKNS_9unordered13unordered_mapINSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEENS2_10Reflection7VariantENS_4hashISF_EENS9_8equal_toISF_EENSD_INS9_4pairIKSF_SH_EEEEEEEEEEENS5_IFvSF_EEEE3$_1E3runEv
void __fastcall boost::detail::thread_data<RBX::Soundscape::SoundService::getRecordingDevices(boost::function<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,boost::function<void ()(std::string)>)::$_1>::run(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:622:19)> *this)
{
  __int64 v1; // rax
  __int64 v2; // rax
  void (__fastcall *v3)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v4)(__int128 *, __int128 *, __int64); // rax
  __int64 v5; // [rsp+0h] [rbp-68h] BYREF
  __int128 v6; // [rsp+8h] [rbp-60h] BYREF
  __int64 v7; // [rsp+18h] [rbp-50h]
  __int64 v8; // [rsp+20h] [rbp-48h]
  __int128 v9; // [rsp+28h] [rbp-40h] BYREF
  __int64 v10; // [rsp+38h] [rbp-30h]
  __int128 v11; // [rsp+40h] [rbp-28h] BYREF
  void *ptr; // [rsp+50h] [rbp-18h]

  v8 = 0;
  v1 = *((_QWORD *)this + 53);
  if ( v1 )
  {
    v8 = *((_QWORD *)this + 53);
    if ( (v1 & 1) != 0 )
    {
      v10 = *((_QWORD *)this + 56);
      v9 = *((_OWORD *)this + 27);
    }
    else
    {
      (*(void (__fastcall **)(char *, __int128 *, _QWORD))(v1 & 0xFFFFFFFFFFFFFFFELL))((char *)this + 432, &v9, 0);
    }
  }
  v5 = 0;
  v2 = *((_QWORD *)this + 57);
  if ( v2 )
  {
    v5 = *((_QWORD *)this + 57);
    if ( (v2 & 1) != 0 )
    {
      v7 = *((_QWORD *)this + 60);
      v6 = *((_OWORD *)this + 29);
    }
    else
    {
      (*(void (__fastcall **)(char *, __int128 *, _QWORD))(v2 & 0xFFFFFFFFFFFFFFFELL))((char *)this + 464, &v6, 0);
    }
  }
  v11 = 0;
  ptr = 0;
  boost::function1<void,std::string>::operator()(&v5, &v11);
  if ( (v11 & 1) != 0 )
    operator delete(ptr);
  if ( v5 )
  {
    if ( (v5 & 1) == 0 )
    {
      v3 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v5 & 0xFFFFFFFFFFFFFFFELL);
      if ( v3 )
        v3(&v6, &v6, 2);
    }
    v5 = 0;
  }
  if ( v8 && (v8 & 1) == 0 )
  {
    v4 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v8 & 0xFFFFFFFFFFFFFFFELL);
    if ( v4 )
      v4(&v9, &v9, 2);
  }
}


// Address: 0x13407b0 | Name: _ZN5boost6detail11thread_dataIZN3RBX10Soundscape12SoundService17onServiceProviderEPNS2_15ServiceProviderES6_E3$_4ED0Ev
void __fastcall boost::detail::thread_data<RBX::Soundscape::SoundService::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_4>::~thread_data(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:1429:23)> *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x13407d0 | Name: _ZN5boost6detail11thread_dataIZN3RBX10Soundscape12SoundService17onServiceProviderEPNS2_15ServiceProviderES6_E3$_4E3runEv
void __fastcall boost::detail::thread_data<RBX::Soundscape::SoundService::onServiceProvider(RBX::ServiceProvider *,RBX::ServiceProvider *)::$_4>::run(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_SoundService_cpp:1429:23)> *this)
{
  RBX::FileSystem::clearOldFilesInCacheDirectory("sounds", maxAgeToKeepInDays);
}


// Address: 0x13516c0 | Name: _ZN5boost6threadC2IPFvPKcNS_10shared_ptrIN3RBX14BaseThreadPool8PoolDataEEENS6_14ShutdownPolicyEES3_S8_S9_EET_T0_T1_T2_
void __fastcall boost::thread::thread<void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy>(
        boost::thread *this,
        void (*f)(const char *, boost::shared_ptr<RBX::BaseThreadPool::PoolData>, RBX::BaseThreadPool::ShutdownPolicy),
        void (*a1)(const char *, boost::shared_ptr<RBX::BaseThreadPool::PoolData>, RBX::BaseThreadPool::ShutdownPolicy),
        boost::shared_ptr<RBX::BaseThreadPool::PoolData> a2,
        unsigned __int64 a3)
{
  __int64 align; // rax
  boost::detail::thread_data_base *v6; // rbx
  boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> > v7; // xmm0
  boost::detail::sp_counted_base *pi; // rbx
  volatile signed __int32 *v9; // rbx
  RBX::BaseThreadPool::ShutdownPolicy v10[2]; // [rsp+0h] [rbp-58h] BYREF
  volatile signed __int32 *v11; // [rsp+8h] [rbp-50h]
  boost::_bi::bind_t<void,void (*)(const char *,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> >,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy> > > v12; // [rsp+10h] [rbp-48h] BYREF

  *(_QWORD *)v10 = a2.px->_vptr$PoolData;
  align = a2.px->cond.internal_mutex.__align;
  v11 = (volatile signed __int32 *)align;
  if ( align )
    _InterlockedAdd((volatile signed __int32 *)(align + 8), 1u);
  boost::bind<void,void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy>(
    &v12,
    (boost::type<void>)f,
    a1,
    (const char *)v10,
    (boost::shared_ptr<RBX::BaseThreadPool::PoolData>)__PAIR128__(a3, (unsigned __int64)a2.pn.pi_),
    v10[0]);
  v6 = (boost::detail::thread_data_base *)operator new(0x1C8u);
  boost::detail::thread_data_base::thread_data_base(v6);
  *(_QWORD *)v6 = &off_28AEB78;
  *((_OWORD *)v6 + 26) = *(_OWORD *)&v12.f_;
  v7 = v12.l_.a2_;
  v12.l_.a2_.t_.pn.pi_ = 0;
  *((boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> > *)v6 + 27) = v7;
  v12.l_.a2_.t_.px = 0;
  *((_DWORD *)v6 + 112) = v12.l_.a3_.t_;
  this->thread_info.px = v6;
  this->thread_info.pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData>>,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy>>>>>(
    &this->thread_info,
    v6,
    &this->thread_info.pn);
  pi = v12.l_.a2_.t_.pn.pi_;
  if ( v12.l_.a2_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v12.l_.a2_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v9 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
      if ( !_InterlockedSub(v9 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
    }
  }
  boost::thread::start_thread(this);
}


// Address: 0x13519d0 | Name: _ZN5boost6thread10timed_joinINS_9date_time18subsecond_durationINS_10posix_time13time_durationELl1000EEEEEbRKT_
bool __fastcall boost::thread::timed_join<boost::date_time::subsecond_duration<boost::posix_time::time_duration,1000l>>(
        boost::thread *this,
        const boost::date_time::subsecond_duration<boost::posix_time::time_duration,1000> *rel_time)
{
  boost::posix_time::ptime v3; // rax
  boost::date_time::int_adapter<long>::int_type value; // rdx
  unsigned __int64 v5; // rcx
  boost::date_time::int_adapter<long>::int_type v6; // rcx
  unsigned __int64 v7; // rdi
  unsigned __int64 v8; // rbx
  bool v9; // zf
  timespec v11; // [rsp+0h] [rbp-28h] BYREF

  v3.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
  value = rel_time->ticks_.value_;
  v5 = rel_time->ticks_.value_ - 0x7FFFFFFFFFFFFFFELL;
  if ( (unsigned __int64)(v3.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) >= 3 && v5 > 2 )
    goto LABEL_3;
  if ( v3.time_.time_count_.value_ != 0x8000000000000000LL )
  {
    if ( v3.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFELL )
    {
      v6 = 0x7FFFFFFFFFFFFFFELL;
      goto LABEL_15;
    }
    if ( v3.time_.time_count_.value_ != 0x7FFFFFFFFFFFFFFFLL && v5 > 2 )
      goto LABEL_3;
  }
  v6 = 0x7FFFFFFFFFFFFFFELL;
  if ( value == 0x7FFFFFFFFFFFFFFELL )
    goto LABEL_15;
  v7 = v3.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFFLL;
  if ( v3.time_.time_count_.value_ == 0x8000000000000000LL )
  {
    v8 = 0x7FFFFFFFFFFFFFFFLL;
    v6 = 0x8000000000000000LL;
LABEL_20:
    if ( value == v8 )
    {
      v6 = 0x7FFFFFFFFFFFFFFELL;
      goto LABEL_4;
    }
    if ( v7 >= 2 )
      goto LABEL_23;
    goto LABEL_4;
  }
  if ( v3.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
  {
    v8 = 0x8000000000000000LL;
    v6 = 0x7FFFFFFFFFFFFFFFLL;
    goto LABEL_20;
  }
  v6 = v3.time_.time_count_.value_;
  if ( v7 >= 2 )
  {
LABEL_23:
    if ( value == 0x8000000000000000LL )
    {
      v6 = 0x8000000000000000LL;
      goto LABEL_15;
    }
    if ( value == 0x7FFFFFFFFFFFFFFFLL )
    {
      v6 = 0x7FFFFFFFFFFFFFFFLL;
      goto LABEL_15;
    }
LABEL_3:
    v6 = v3.time_.time_count_.value_ + value;
  }
LABEL_4:
  if ( (unsigned __int64)(v6 - 0x7FFFFFFFFFFFFFFELL) > 2 )
  {
    v6 -= 210866803200000000LL;
    goto LABEL_18;
  }
LABEL_15:
  if ( (unsigned __int64)(v6 - 0x7FFFFFFFFFFFFFFELL) >= 3 )
  {
    v9 = v6 == 0x82ED263D83A88000LL;
    v6 = 0x8000000000000000LL;
    if ( !v9 )
      v6 = 0x7FFFFFFFFFFFFFFELL;
  }
LABEL_18:
  v11.tv_sec = (int)v6 / 1000000;
  v11.tv_nsec = 1000 * (v6 % 1000000);
  return boost::thread::do_try_join_until(this, &v11);
}


// Address: 0x1352ab0 | Name: _ZN5boost6threadC2EOS0_
void __fastcall boost::thread::thread(boost::thread *this, boost::thread *x)
{
  boost::shared_ptr<boost::detail::thread_data_base>::element_type *px; // rcx
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v4; // r14
  boost::detail::sp_counted_base *v5; // rbx

  *this = 0;
  px = x->thread_info.px;
  pi = x->thread_info.pn.pi_;
  if ( pi )
  {
    _InterlockedAdd(&pi->use_count_, 1u);
    v4 = this->thread_info.pn.pi_;
    this->thread_info.px = px;
    this->thread_info.pn.pi_ = pi;
    if ( v4 )
    {
      if ( !_InterlockedSub(&v4->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 2))(v4);
        if ( !_InterlockedSub(&v4->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
      }
    }
  }
  else
  {
    this->thread_info.px = px;
    this->thread_info.pn.pi_ = 0;
  }
  v5 = x->thread_info.pn.pi_;
  *x = 0;
  if ( v5 && !_InterlockedSub(&v5->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 2))(v5);
    if ( !_InterlockedSub(&v5->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v5->_vptr$sp_counted_base + 3))(v5);
  }
}


// Address: 0x1352c80 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvPKcNS_10shared_ptrIN3RBX14BaseThreadPool8PoolDataEEENS8_14ShutdownPolicyEENS2_5list3INS2_5valueIS5_EENSF_ISA_EENSF_ISB_EEEEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData>>,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const char *,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> >,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy> > > > *this)
{
  volatile signed __int32 *v1; // rbx

  *(_QWORD *)this = &off_28AEB78;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 55);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x1352ce0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvPKcNS_10shared_ptrIN3RBX14BaseThreadPool8PoolDataEEENS8_14ShutdownPolicyEENS2_5list3INS2_5valueIS5_EENSF_ISA_EENSF_ISB_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData>>,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const char *,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> >,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy> > > > *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = &off_28AEB78;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 55);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x1352d40 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvPFvPKcNS_10shared_ptrIN3RBX14BaseThreadPool8PoolDataEEENS8_14ShutdownPolicyEENS2_5list3INS2_5valueIS5_EENSF_ISA_EENSF_ISB_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData>>,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,void (*)(const char *,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list3<boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> >,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy> > > > *this)
{
  void (*v1)(const char *, boost::shared_ptr<RBX::BaseThreadPool::PoolData>, RBX::BaseThreadPool::ShutdownPolicy); // rax
  int v2; // r8d
  void (*v3)(const char *, boost::shared_ptr<RBX::BaseThreadPool::PoolData>, RBX::BaseThreadPool::ShutdownPolicy); // [rsp-8h] [rbp-8h] BYREF

  v3 = v1;
  boost::_bi::list3<boost::_bi::value<char const*>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData>>,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy>>::operator()<void (*)(char const*,boost::shared_ptr<RBX::BaseThreadPool::PoolData>,RBX::BaseThreadPool::ShutdownPolicy),boost::_bi::list0>(
    (boost::_bi::list3<boost::_bi::value<const char *>,boost::_bi::value<boost::shared_ptr<RBX::BaseThreadPool::PoolData> >,boost::_bi::value<RBX::BaseThreadPool::ShutdownPolicy> > *)((char *)this + 424),
    (boost::_bi::type<void>)((_BYTE)this - 96),
    &v3,
    0,
    v2);
}


// Address: 0x13612a0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX8WsClientEEENS2_5list1INS2_5valueIPS7_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient*>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient *> > > > *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x13612c0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX8WsClientEEENS2_5list1INS2_5valueIPS7_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient*>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::WsClient>,boost::_bi::list1<boost::_bi::value<RBX::WsClient *> > > > *this)
{
  void (__fastcall *v1)(_QWORD); // rcx
  _QWORD *v2; // rdi

  v1 = (void (__fastcall *)(_QWORD))*((_QWORD *)this + 52);
  v2 = (_QWORD *)(*((_QWORD *)this + 53) + *((_QWORD *)this + 54));
  if ( ((unsigned __int8)v1 & 1) != 0 )
    v1 = *(void (__fastcall **)(_QWORD))((char *)v1 + *v2 - 1);
  v1(v2);
}


// Address: 0x1370080 | Name: _ZN5boost6detail11thread_dataIZN3RBX18BatchAssetApiState17startWorkerThreadEvE3$_0ED2Ev
void __fastcall boost::detail::thread_data<RBX::BatchAssetApiState::startWorkerThread(void)::$_0>::~thread_data(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_Shared_HttpBatchAsset_cpp:350:38)> *this)
{
  volatile signed __int32 *v1; // rbx

  *(_QWORD *)this = &off_28AF210;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 53);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x13700e0 | Name: _ZN5boost6detail11thread_dataIZN3RBX18BatchAssetApiState17startWorkerThreadEvE3$_0ED0Ev
void __fastcall boost::detail::thread_data<RBX::BatchAssetApiState::startWorkerThread(void)::$_0>::~thread_data(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_util_Shared_HttpBatchAsset_cpp:350:38)> *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = &off_28AF210;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 53);
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x161fa40 | Name: _ZN5boost6threadC2IMN3RBX27DynamicFastVariableReloaderEFvvEPS3_EET_T0_NS_10disable_ifINS_13thread_detail14is_convertibleIRS7_NS_17thread_attributesEEEPNS0_5dummyEE4typeE
void __fastcall boost::thread::thread<void (RBX::DynamicFastVariableReloader::*)(void),RBX::DynamicFastVariableReloader*>(
        boost::thread *this,
        void (*f)(RBX::DynamicFastVariableReloader *),
        RBX::DynamicFastVariableReloader *a1,
        boost::disable_if_c<false,boost::thread::dummy *>::type a4)
{
  boost::detail::thread_data_base *v6; // rbx

  v6 = (boost::detail::thread_data_base *)operator new(0x1B8u);
  boost::detail::thread_data_base::thread_data_base(v6);
  *(_QWORD *)v6 = &off_28CDAD0;
  *((_QWORD *)v6 + 52) = f;
  *((_QWORD *)v6 + 53) = a1;
  *((_QWORD *)v6 + 54) = a4;
  this->thread_info.px = v6;
  this->thread_info.pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader*>>>>>(
    &this->thread_info,
    v6,
    &this->thread_info.pn);
  boost::thread::start_thread(this);
}


// Address: 0x161fdf0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX27DynamicFastVariableReloaderEEENS2_5list1INS2_5valueIPS7_EEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader*>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader *> > > > *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x161fe10 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX27DynamicFastVariableReloaderEEENS2_5list1INS2_5valueIPS7_EEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader*>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::DynamicFastVariableReloader>,boost::_bi::list1<boost::_bi::value<RBX::DynamicFastVariableReloader *> > > > *this)
{
  void (__fastcall *v1)(_QWORD); // rcx
  _QWORD *v2; // rdi

  v1 = (void (__fastcall *)(_QWORD))*((_QWORD *)this + 52);
  v2 = (_QWORD *)(*((_QWORD *)this + 53) + *((_QWORD *)this + 54));
  if ( ((unsigned __int8)v1 & 1) != 0 )
    v1 = *(void (__fastcall **)(_QWORD))((char *)v1 + *v2 - 1);
  v1(v2);
}


// Address: 0x163dcb0 | Name: _ZN5boost6detail11thread_dataIZN3RBX13FriendService18getPlatformFriendsENS_8functionIFvNS_10shared_ptrIKNSt3__16vectorINS2_10Reflection7VariantENS6_9allocatorIS9_EEEEEEEEENS4_IFvNS6_12basic_stringIcNS6_11char_traitsIcEENSA_IcEEEEEEEE3$_0ED0Ev
void __fastcall boost::detail::thread_data<RBX::FriendService::getPlatformFriends(boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>)::$_0>::~thread_data(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_v8datamodel_FriendService_cpp:164:9)> *this)
{
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x163dcd0 | Name: _ZN5boost6detail11thread_dataIZN3RBX13FriendService18getPlatformFriendsENS_8functionIFvNS_10shared_ptrIKNSt3__16vectorINS2_10Reflection7VariantENS6_9allocatorIS9_EEEEEEEEENS4_IFvNS6_12basic_stringIcNS6_11char_traitsIcEENSA_IcEEEEEEEE3$_0E3runEv
void __fastcall boost::detail::thread_data<RBX::FriendService::getPlatformFriends(boost::function<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,boost::function<void ()(std::string)>)::$_0>::run(
        boost::detail::thread_data<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_v8datamodel_FriendService_cpp:164:9)> *this)
{
  __int64 v2; // r14
  boost::detail::sp_if_not_array<std::vector<RBX::Reflection::Variant> >::type v3; // rax
  __int64 (__fastcall ***v4)(_QWORD, _OWORD *, boost::detail::sp_counted_base *); // rdi
  int v5; // r15d
  volatile signed __int32 *v6; // rbp
  void *v7; // rbp
  volatile signed __int32 *v8; // rbx
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // r8
  __int64 v12; // r9
  RBX::DataModel *v13; // r15
  boost::shared_ptr<RBX::TaskScheduler::Job> v14; // rdi
  void (__fastcall *v15)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::shared_ptr<RBX::TaskScheduler::Job> v16; // rdi
  void (__fastcall *v17)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::shared_ptr<RBX::TaskScheduler::Job> v18; // rdi
  void (__fastcall *v19)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v20; // rbx
  RBX::DataModel::Task task; // [rsp+0h] [rbp-68h] BYREF
  __int128 v22; // [rsp+20h] [rbp-48h]
  _OWORD v23[3]; // [rsp+30h] [rbp-38h] BYREF

  v2 = *((_QWORD *)this + 52);
  if ( _InterlockedCompareExchange64((volatile signed __int64 *)(v2 + 432), 1, 0) )
  {
    task.functor.obj_ptr = (void *)*((_QWORD *)this + 53);
    task.vtable = (boost::detail::function::vtable_base *)((char *)off_28D0128 + 1);
    v14.pn.pi_ = (boost::detail::sp_counted_base *)&task;
    v14.px = RBX::DataModel::get((RBX::Instance *)v2);
    RBX::DataModel::submitTask(v14, 1u);
    if ( task.vtable )
    {
      if ( ((__int64)task.vtable & 1) == 0 )
      {
        v15 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)task.vtable & 0xFFFFFFFFFFFFFFFELL);
        if ( v15 )
          v15(&task.functor, &task.functor, 2);
      }
      task.vtable = 0;
    }
  }
  else
  {
    v3 = boost::make_shared<std::vector<RBX::Reflection::Variant>>();
    v4 = *(__int64 (__fastcall ****)(_QWORD, _OWORD *, boost::detail::sp_counted_base *))(v2 + 424);
    v23[0] = v22;
    if ( *((_QWORD *)&v22 + 1) )
      _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
    v5 = (**v4)(v4, v23, v3.pn.pi_);
    v6 = (volatile signed __int32 *)*((_QWORD *)&v23[0] + 1);
    if ( *((_QWORD *)&v23[0] + 1) )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v23[0] + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
    v7 = (void *)*((_QWORD *)this + 53);
    if ( v5 < 0 )
    {
      task.functor.obj_ptr = (void *)*((_QWORD *)this + 53);
      task.vtable = (boost::detail::function::vtable_base *)((char *)off_28D0108 + 1);
      v16.pn.pi_ = (boost::detail::sp_counted_base *)&task;
      v16.px = RBX::DataModel::get((RBX::Instance *)v2);
      RBX::DataModel::submitTask(v16, 1u);
      if ( task.vtable )
      {
        if ( ((__int64)task.vtable & 1) == 0 )
        {
          v17 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)task.vtable & 0xFFFFFFFFFFFFFFFELL);
          if ( v17 )
            v17(&task.functor, &task.functor, 2);
        }
        task.vtable = 0;
      }
    }
    else
    {
      v8 = (volatile signed __int32 *)*((_QWORD *)&v22 + 1);
      if ( *((_QWORD *)&v22 + 1) )
        _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
      v13 = RBX::DataModel::get((RBX::Instance *)v2);
      if ( *((_QWORD *)&v22 + 1) )
      {
        _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
        task.vtable = 0;
        _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
        _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
        _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
        _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
        task.functor.obj_ptr = v7;
        *(_OWORD *)(&task.functor.data + 8) = v22;
        _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(_QWORD, _OWORD *, __int64, __int64, __int64, __int64, boost::detail::function::vtable_base *, void *, _QWORD, void *))(**((_QWORD **)&v22 + 1) + 16LL))(
            *((_QWORD *)&v22 + 1),
            v23,
            v9,
            v10,
            v11,
            v12,
            task.vtable,
            task.functor.obj_ptr,
            *((_QWORD *)&task.functor.data + 1),
            task.functor.bound_memfunc_ptr.obj_ptr);
          if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 12LL), 1u) )
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 24LL))(*((_QWORD *)&v22 + 1));
        }
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 16LL))(*((_QWORD *)&v22 + 1));
          if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 12LL), 1u) )
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 24LL))(*((_QWORD *)&v22 + 1));
        }
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 16LL))(*((_QWORD *)&v22 + 1));
          if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 12LL), 1u) )
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 24LL))(*((_QWORD *)&v22 + 1));
        }
        task.vtable = (boost::detail::function::vtable_base *)&stru_28D00E8;
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 16LL))(*((_QWORD *)&v22 + 1));
          if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 12LL), 1u) )
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 24LL))(*((_QWORD *)&v22 + 1));
        }
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 16LL))(*((_QWORD *)&v22 + 1));
          if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 12LL), 1u) )
            (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 24LL))(*((_QWORD *)&v22 + 1));
        }
      }
      else
      {
        task.functor.obj_ptr = v7;
        *(_OWORD *)(&task.functor.data + 8) = (unsigned __int64)v22;
        task.vtable = (boost::detail::function::vtable_base *)&stru_28D00E8;
      }
      v18.pn.pi_ = (boost::detail::sp_counted_base *)&task;
      v18.px = v13;
      RBX::DataModel::submitTask(v18, 1u);
      if ( task.vtable )
      {
        if ( ((__int64)task.vtable & 1) == 0 )
        {
          v19 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)task.vtable & 0xFFFFFFFFFFFFFFFELL);
          if ( v19 )
            v19(&task.functor, &task.functor, 2);
        }
        task.vtable = 0;
      }
      if ( v8 )
      {
        if ( !_InterlockedSub(v8 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
          if ( !_InterlockedSub(v8 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
        }
      }
    }
    _InterlockedExchange64((volatile __int64 *)(v2 + 432), 0);
    v20 = (volatile signed __int32 *)*((_QWORD *)&v22 + 1);
    if ( *((_QWORD *)&v22 + 1) && !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 16LL))(v20);
      if ( !_InterlockedSub(v20 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 24LL))(v20);
    }
  }
}


// Address: 0x1cceae0 | Name: _ZN5boost6threadC2INS_3_bi6bind_tIvNS_4_mfi3mf3IvN3RBX21ThirdPartyUserServiceENS6_11InputObject13UserInputTypeENS_8functionIFviEEENSA_IFvNSt3__112basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEEEEEEENS2_5list4INS2_5valueIPS7_EENSO_IS9_EENSO_ISC_EENSO_ISL_EEEEEENS6_12DataModelJob8TaskTypeEEET_T0_NS_10disable_ifINS_13thread_detail14is_convertibleIRSY_NS_17thread_attributesEEEPNS0_5dummyEE4typeE
void __fastcall boost::thread::thread<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,RBX::DataModelJob::TaskType>(
        boost::thread *this,
        __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  __int64 v6; // rax
  __int64 v7; // rax
  void (__fastcall *v8)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v9)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v11)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > > v12; // [rsp+0h] [rbp-E8h] BYREF
  boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > >,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType> > > v13; // [rsp+60h] [rbp-88h] BYREF

  v12.f_ = *(boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> > *)a2;
  v12.l_.boost::_bi::storage2<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType> > = *(boost::_bi::storage2<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType> > *)(a2 + 16);
  v12.l_.a3_.t_.vtable = 0;
  v6 = *(_QWORD *)(a2 + 32);
  if ( v6 )
  {
    v12.l_.a3_.t_.vtable = *(boost::detail::function::vtable_base **)(a2 + 32);
    if ( (v6 & 1) != 0 )
      v12.l_.a3_.t_.functor = *(boost::detail::function::function_buffer *)(a2 + 40);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD, __int64, __int64, __int64, boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >::F, _QWORD, RBX::ThirdPartyUserService *, _QWORD, boost::detail::function::vtable_base *))(v6 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 40,
        &v12.l_.a3_.t_.functor,
        0,
        a4,
        a5,
        a6,
        v12.f_.f_,
        *((_QWORD *)&v12.f_.f_ + 1),
        v12.l_.a1_.t_,
        *(_QWORD *)&v12.l_.a2_.t_,
        v12.l_.a3_.t_.vtable);
  }
  v12.l_.a4_.t_.vtable = 0;
  v7 = *(_QWORD *)(a2 + 64);
  if ( v7 )
  {
    v12.l_.a4_.t_.vtable = *(boost::detail::function::vtable_base **)(a2 + 64);
    if ( (v7 & 1) != 0 )
      v12.l_.a4_.t_.functor = *(boost::detail::function::function_buffer *)(a2 + 72);
    else
      (*(void (__fastcall **)(__int64, boost::detail::function::function_buffer *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(
        a2 + 72,
        &v12.l_.a4_.t_.functor,
        0);
  }
  boost::bind<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,RBX::DataModelJob::TaskType>(
    &v13,
    v12);
  boost::thread::make_thread_info<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>(&v13);
  if ( v13.f_.l_.a4_.t_.vtable )
  {
    if ( ((__int64)v13.f_.l_.a4_.t_.vtable & 1) == 0 )
    {
      v8 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v13.f_.l_.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v8 )
        v8(&v13.f_.l_.a4_.t_.functor, &v13.f_.l_.a4_.t_.functor, 2);
    }
    v13.f_.l_.a4_.t_.vtable = 0;
  }
  if ( v13.f_.l_.a3_.t_.vtable )
  {
    if ( ((__int64)v13.f_.l_.a3_.t_.vtable & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v13.f_.l_.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v13.f_.l_.a3_.t_.functor, &v13.f_.l_.a3_.t_.functor, 2);
    }
    v13.f_.l_.a3_.t_.vtable = 0;
  }
  if ( v12.l_.a4_.t_.vtable )
  {
    if ( ((__int64)v12.l_.a4_.t_.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.l_.a4_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v12.l_.a4_.t_.functor, &v12.l_.a4_.t_.functor, 2);
    }
    v12.l_.a4_.t_.vtable = 0;
  }
  if ( v12.l_.a3_.t_.vtable )
  {
    if ( ((__int64)v12.l_.a3_.t_.vtable & 1) == 0 )
    {
      v11 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v12.l_.a3_.t_.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v11 )
        v11(&v12.l_.a3_.t_.functor, &v12.l_.a3_.t_.functor, 2);
    }
    v12.l_.a3_.t_.vtable = 0;
  }
  boost::thread::start_thread(this);
}


// Address: 0x1cd0b50 | Name: _ZN5boost6thread16make_thread_infoINS_3_bi6bind_tIvNS3_IvNS_4_mfi3mf3IvN3RBX21ThirdPartyUserServiceENS6_11InputObject13UserInputTypeENS_8functionIFviEEENSA_IFvNSt3__112basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEEEEEEENS2_5list4INS2_5valueIPS7_EENSO_IS9_EENSO_ISC_EENSO_ISL_EEEEEENS2_5list1INSO_INS6_12DataModelJob8TaskTypeEEEEEEEEENS_10shared_ptrINS_6detail16thread_data_baseEEEOT_
boost::shared_ptr<boost::detail::thread_data_base> *__fastcall boost::thread::make_thread_info<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>(
        boost::shared_ptr<boost::detail::thread_data_base> *a1,
        boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > >,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType> > > *f)
{
  void *v2; // rbx

  v2 = operator new(0x208u);
  boost::detail::thread_data_base::thread_data_base((boost::detail::thread_data_base *)v2);
  *(_QWORD *)v2 = &off_298AB48;
  *((_OWORD *)v2 + 26) = f->f_.f_;
  *((_OWORD *)v2 + 27) = f->f_.l_.boost::_bi::storage2<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType> >;
  *((_QWORD *)v2 + 56) = 0;
  boost::function1<void,int>::move_assign((boost::function1<void,int>_0 *)v2 + 14, &f->f_.l_.a3_.t_);
  *((_QWORD *)v2 + 60) = 0;
  boost::function1<void,std::string>::move_assign((boost::function1<void,std::string >_0 *)v2 + 15, &f->f_.l_.a4_.t_);
  *((_DWORD *)v2 + 128) = f->l_.a1_.t_;
  a1->px = v2;
  a1->pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>>(
    a1,
    (boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > >,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType> > > > *)v2,
    &a1->pn);
  return a1;
}


// Address: 0x1cd0eb0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS3_IvNS_4_mfi3mf3IvN3RBX21ThirdPartyUserServiceENS6_11InputObject13UserInputTypeENS_8functionIFviEEENSA_IFvNSt3__112basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEEEEEEENS2_5list4INS2_5valueIPS7_EENSO_IS9_EENSO_ISC_EENSO_ISL_EEEEEENS2_5list1INSO_INS6_12DataModelJob8TaskTypeEEEEEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > >,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType> > > > *this)
{
  __int64 v1; // rax
  void (__fastcall *v2)(char *, char *, __int64); // rax
  __int64 v3; // rax
  void (__fastcall *v4)(char *, char *, __int64); // rax

  *(_QWORD *)this = &off_298AB48;
  v1 = *((_QWORD *)this + 60);
  if ( v1 )
  {
    if ( (v1 & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(char *, char *, __int64))(v1 & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2((char *)this + 488, (char *)this + 488, 2);
    }
    *((_QWORD *)this + 60) = 0;
  }
  v3 = *((_QWORD *)this + 56);
  if ( v3 )
  {
    if ( (v3 & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(char *, char *, __int64))(v3 & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4((char *)this + 456, (char *)this + 456, 2);
    }
    *((_QWORD *)this + 56) = 0;
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x1cd0f50 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS3_IvNS_4_mfi3mf3IvN3RBX21ThirdPartyUserServiceENS6_11InputObject13UserInputTypeENS_8functionIFviEEENSA_IFvNSt3__112basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEEEEEEENS2_5list4INS2_5valueIPS7_EENSO_IS9_EENSO_ISC_EENSO_ISL_EEEEEENS2_5list1INSO_INS6_12DataModelJob8TaskTypeEEEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > >,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType> > > > *this)
{
  __int64 v1; // rax
  void (__fastcall *v2)(char *, char *, __int64); // rax
  __int64 v3; // rax
  void (__fastcall *v4)(char *, char *, __int64); // rax

  *(_QWORD *)this = &off_298AB48;
  v1 = *((_QWORD *)this + 60);
  if ( v1 )
  {
    if ( (v1 & 1) == 0 )
    {
      v2 = *(void (__fastcall **)(char *, char *, __int64))(v1 & 0xFFFFFFFFFFFFFFFELL);
      if ( v2 )
        v2((char *)this + 488, (char *)this + 488, 2);
    }
    *((_QWORD *)this + 60) = 0;
  }
  v3 = *((_QWORD *)this + 56);
  if ( v3 )
  {
    if ( (v3 & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(char *, char *, __int64))(v3 & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4((char *)this + 456, (char *)this + 456, 2);
    }
    *((_QWORD *)this + 56) = 0;
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x1cd0ff0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS3_IvNS_4_mfi3mf3IvN3RBX21ThirdPartyUserServiceENS6_11InputObject13UserInputTypeENS_8functionIFviEEENSA_IFvNSt3__112basic_stringIcNSD_11char_traitsIcEENSD_9allocatorIcEEEEEEEEENS2_5list4INS2_5valueIPS7_EENSO_IS9_EENSO_ISC_EENSO_ISL_EEEEEENS2_5list1INSO_INS6_12DataModelJob8TaskTypeEEEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService*>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> >,boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > >,boost::_bi::list1<boost::_bi::value<RBX::DataModelJob::TaskType> > > > *this)
{
  int v1; // r8d
  char *v2; // [rsp+0h] [rbp-8h] BYREF

  v2 = (char *)this + 512;
  boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void ()(int)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::operator()<boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void ()(int)>,boost::function<void ()(std::string)>>,boost::_bi::list1<RBX::DataModelJob::TaskType &>>(
    (boost::_bi::list4<boost::_bi::value<RBX::ThirdPartyUserService *>,boost::_bi::value<RBX::InputObject::UserInputType>,boost::_bi::value<boost::function<void (int)> >,boost::_bi::value<boost::function<void (std::string)> > > *)((char *)this + 432),
    (boost::_bi::type<void>)((_BYTE)this - 96),
    (boost::_mfi::mf3<void,RBX::ThirdPartyUserService,RBX::InputObject::UserInputType,boost::function<void (int)>,boost::function<void (std::string)> > *)&v2,
    0,
    v1);
}


// Address: 0x1f8ba90 | Name: _ZN5boost6threadC2IMN3RBX8Graphics10RenderViewEFvNS_10shared_ptrIN3G3D6GImageEEENS_8weak_ptrINS2_9DataModelEEElEPS4_S8_SB_lEET_T0_T1_T2_T3_
void __fastcall boost::thread::thread<void (RBX::Graphics::RenderView::*)(boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long),RBX::Graphics::RenderView*,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>(
        boost::thread *this,
        void (*f)(RBX::Graphics::RenderView *, boost::shared_ptr<G3D::GImage>, boost::weak_ptr<RBX::DataModel>, __int64),
        RBX::Graphics::RenderView *a1,
        boost::shared_ptr<G3D::GImage> a2,
        __int64 a4,
        boost::weak_ptr<RBX::DataModel> a3)
{
  boost::detail::sp_counted_base *v7; // rax
  __int64 v8; // rdi
  boost::shared_ptr<G3D::GImage> v9; // r8
  boost::detail::thread_data_base *v10; // rbx
  __int128 v11; // xmm0
  boost::detail::sp_counted_base *pi; // rdi
  boost::detail::sp_counted_base *v13; // rbx
  __int64 v14; // rdi
  boost::detail::sp_counted_base *v15; // rbx
  boost::weak_ptr<RBX::DataModel> v16; // [rsp+0h] [rbp-88h] BYREF
  __int64 a4a; // [rsp+10h] [rbp-78h]
  boost::shared_ptr<G3D::GImage> v18; // [rsp+18h] [rbp-70h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > > v19; // [rsp+28h] [rbp-60h] BYREF

  v18.px = (boost::shared_ptr<G3D::GImage>::element_type *)a2.pn.pi_->_vptr$sp_counted_base;
  v7 = *(boost::detail::sp_counted_base **)&a2.pn.pi_->use_count_;
  v18.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  v16.pn.pi_ = *(boost::detail::sp_counted_base **)a4;
  v8 = *(_QWORD *)(a4 + 8);
  a4a = v8;
  if ( v8 )
    _InterlockedAdd((volatile signed __int32 *)(v8 + 12), 1u);
  v16.px = a3.px;
  v9.px = (boost::shared_ptr<G3D::GImage>::element_type *)&v18;
  v9.pn.pi_ = (boost::detail::sp_counted_base *)&v16.pn;
  boost::bind<void,void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long,RBX::Graphics::RenderView*,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>(
    &v19,
    (boost::type<void>)f,
    (void (*)(RBX::Graphics::RenderView *, boost::shared_ptr<G3D::GImage>, boost::weak_ptr<RBX::DataModel>, __int64))a1,
    (RBX::Graphics::RenderView *)a2.px,
    v9,
    v16,
    a4a);
  v10 = (boost::detail::thread_data_base *)operator new(0x1E0u);
  boost::detail::thread_data_base::thread_data_base(v10);
  *(_QWORD *)v10 = &off_29A5288;
  *((_OWORD *)v10 + 26) = v19.f_;
  *((_OWORD *)v10 + 27) = *(_OWORD *)&v19.l_.a1_.t_;
  v11 = *(_OWORD *)&v19.l_.a2_.t_.pn.pi_;
  v19.l_.a2_.t_.pn.pi_ = 0;
  v19.l_.a2_.t_.px = 0;
  *((_OWORD *)v10 + 28) = v11;
  *((_QWORD *)v10 + 58) = v19.l_.a3_.t_.pn.pi_;
  v19.l_.a3_ = 0;
  *((_QWORD *)v10 + 59) = v19.l_.a4_.t_;
  this->thread_info.px = v10;
  this->thread_info.pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::detail::thread_data_base,boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView*>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>>>>(
    &this->thread_info,
    v10,
    &this->thread_info.pn);
  pi = v19.l_.a3_.t_.pn.pi_;
  if ( v19.l_.a3_.t_.pn.pi_ && !_InterlockedSub(&v19.l_.a3_.t_.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  v13 = v19.l_.a2_.t_.pn.pi_;
  if ( v19.l_.a2_.t_.pn.pi_ )
  {
    if ( !_InterlockedSub(&v19.l_.a2_.t_.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
      if ( !_InterlockedSub(&v13->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
    }
  }
  v14 = a4a;
  if ( a4a && !_InterlockedSub((volatile signed __int32 *)(a4a + 12), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v14 + 24LL))(v14);
  v15 = v18.pn.pi_;
  if ( v18.pn.pi_ )
  {
    if ( !_InterlockedSub(&v18.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v15->_vptr$sp_counted_base + 2))(v15);
      if ( !_InterlockedSub(&v15->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v15->_vptr$sp_counted_base + 3))(v15);
    }
  }
  boost::thread::start_thread(this);
}


// Address: 0x1f8d420 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf3IvN3RBX8Graphics10RenderViewENS_10shared_ptrIN3G3D6GImageEEENS_8weak_ptrINS6_9DataModelEEElEENS2_5list4INS2_5valueIPS8_EENSI_ISC_EENSI_ISF_EENSI_IlEEEEEEED2Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView*>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > > > *this)
{
  volatile signed __int32 *v2; // rdi
  volatile signed __int32 *v3; // rbx

  *(_QWORD *)this = &off_29A5288;
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 58);
  if ( v2 && !_InterlockedSub(v2 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
  v3 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v3 )
  {
    if ( !_InterlockedSub(v3 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
      if ( !_InterlockedSub(v3 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
}


// Address: 0x1f8d4a0 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf3IvN3RBX8Graphics10RenderViewENS_10shared_ptrIN3G3D6GImageEEENS_8weak_ptrINS6_9DataModelEEElEENS2_5list4INS2_5valueIPS8_EENSI_ISC_EENSI_ISF_EENSI_IlEEEEEEED0Ev
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView*>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>>>::~thread_data(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > > > *this)
{
  volatile signed __int32 *v2; // rdi
  volatile signed __int32 *v3; // rbx

  *(_QWORD *)this = &off_29A5288;
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 58);
  if ( v2 && !_InterlockedSub(v2 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
  v3 = (volatile signed __int32 *)*((_QWORD *)this + 56);
  if ( v3 )
  {
    if ( !_InterlockedSub(v3 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
      if ( !_InterlockedSub(v3 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
    }
  }
  boost::detail::thread_data_base::~thread_data_base(this);
  operator delete(this);
}


// Address: 0x1f8d520 | Name: _ZN5boost6detail11thread_dataINS_3_bi6bind_tIvNS_4_mfi3mf3IvN3RBX8Graphics10RenderViewENS_10shared_ptrIN3G3D6GImageEEENS_8weak_ptrINS6_9DataModelEEElEENS2_5list4INS2_5valueIPS8_EENSI_ISC_EENSI_ISF_EENSI_IlEEEEEEE3runEv
void __fastcall boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView*>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>>>::run(
        boost::detail::thread_data<boost::_bi::bind_t<void,boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > > > *this)
{
  __int64 v1; // rax
  int v2; // r8d
  __int64 v3; // [rsp-8h] [rbp-8h] BYREF

  v3 = v1;
  boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage>>,boost::_bi::value<boost::weak_ptr<RBX::DataModel>>,boost::_bi::value<long>>::operator()<boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long>,boost::_bi::list0>(
    (boost::_bi::list4<boost::_bi::value<RBX::Graphics::RenderView *>,boost::_bi::value<boost::shared_ptr<G3D::GImage> >,boost::_bi::value<boost::weak_ptr<RBX::DataModel> >,boost::_bi::value<long> > *)this
  + 9,
    (boost::_bi::type<void>)((_BYTE)this - 96),
    (boost::_mfi::mf3<void,RBX::Graphics::RenderView,boost::shared_ptr<G3D::GImage>,boost::weak_ptr<RBX::DataModel>,long> *)&v3,
    0,
    v2);
}


