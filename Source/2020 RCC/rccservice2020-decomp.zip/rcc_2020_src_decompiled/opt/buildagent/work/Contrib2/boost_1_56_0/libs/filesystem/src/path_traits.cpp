// Address: 0x283ea50 | Name: _ZN5boost10filesystem11path_traits7convertEPKcS3_RNSt3__112basic_stringIwNS4_11char_traitsIwEENS4_9allocatorIwEEEERKNS4_7codecvtIwc11__mbstate_tEE
void __fastcall boost::filesystem::path_traits::convert(
        const char *from,
        const char *from_end,
        std::wstring *to,
        const boost::filesystem::path_traits::codecvt_type *cvt)
{
  const char *v6; // rbx
  signed __int64 v8; // rax
  unsigned __int64 v9; // rbp
  size_t v10; // rdi
  wchar_t *v11; // r13
  wchar_t v12[256]; // [rsp+0h] [rbp-438h] BYREF
  wchar_t to_end[14]; // [rsp+400h] [rbp-38h] BYREF

  v6 = from_end;
  if ( !from_end )
    v6 = &from[strlen(from)];
  v8 = v6 - from;
  if ( v6 != from )
  {
    v9 = 3 * v8;
    if ( (unsigned __int64)(3 * v8) < 0x101 )
    {
      `anonymous namespace'::convert_aux(from, v6, v12, to_end, to, cvt);
    }
    else
    {
      v10 = -1;
      if ( is_mul_ok(4u, v9) )
        v10 = 12 * v8;
      v11 = (wchar_t *)operator new[](v10);
      `anonymous namespace'::convert_aux(from, v6, v11, &v11[v9], to, cvt);
      operator delete[](v11);
    }
  }
}


// Address: 0x283eb30 | Name: _ZN12_GLOBAL__N_111convert_auxEPKcS1_PwS2_RNSt3__112basic_stringIwNS3_11char_traitsIwEENS3_9allocatorIwEEEERKNS3_7codecvtIwc11__mbstate_tEE
void __fastcall `anonymous namespace'::convert_aux(
        const char *from,
        const char *from_end,
        wchar_t *to,
        wchar_t *to_end,
        std::wstring *target,
        const boost::filesystem::path_traits::codecvt_type *cvt)
{
  int v8; // eax
  int v9; // ebp
  boost::system::system_error *exception; // rbx
  const boost::system::error_category *v11; // rax
  wchar_t *__last; // [rsp+8h] [rbp-30h] BYREF
  __int64 v13; // [rsp+10h] [rbp-28h] BYREF
  _BYTE v14[32]; // [rsp+18h] [rbp-20h] BYREF

  v13 = 0;
  v8 = (*(__int64 (__fastcall **)(const boost::filesystem::path_traits::codecvt_type *, __int64 *, const char *, const char *, _BYTE *, wchar_t *, wchar_t *, wchar_t **))(*(_QWORD *)cvt + 32LL))(
         cvt,
         &v13,
         from,
         from_end,
         v14,
         to,
         to_end,
         &__last);
  if ( v8 )
  {
    v9 = v8;
    exception = (boost::system::system_error *)__cxa_allocate_exception(0x38u);
    v11 = boost::filesystem::codecvt_error_category();
    boost::system::system_error::system_error(exception, v9, v11, "boost::filesystem::path codecvt to wstring");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::system::system_error,
      (void (*)(void *))boost::system::system_error::~system_error);
  }
  std::wstring::__append_forward_unsafe<wchar_t *>((std::wstring *)target, to, __last);
}


// Address: 0x283ebe0 | Name: _ZN5boost10filesystem11path_traits7convertEPKwS3_RNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEERKNS4_7codecvtIwc11__mbstate_tEE
void __fastcall boost::filesystem::path_traits::convert(
        const wchar_t *from,
        const wchar_t *from_end,
        std::string *to,
        const boost::filesystem::path_traits::codecvt_type *cvt)
{
  const wchar_t *v6; // r13
  unsigned __int64 v7; // rbx
  char *v8; // rbp
  char v9[256]; // [rsp+0h] [rbp-138h] BYREF
  char to_end[56]; // [rsp+100h] [rbp-38h] BYREF

  v6 = from_end;
  *(_QWORD *)to_end = __readfsqword(0x28u);
  if ( !from_end )
    v6 = &from[wcslen(from)];
  if ( v6 != from )
  {
    v7 = (char *)v6 - (char *)from + 4;
    if ( v7 < 0x101 )
    {
      `anonymous namespace'::convert_aux(from, v6, v9, to_end, to, cvt);
    }
    else
    {
      v8 = (char *)operator new[]((char *)v6 - (char *)from + 4);
      `anonymous namespace'::convert_aux(from, v6, v8, &v8[v7], to, cvt);
      operator delete[](v8);
    }
  }
}


// Address: 0x283ecc0 | Name: _ZN12_GLOBAL__N_111convert_auxEPKwS1_PcS2_RNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERKNS3_7codecvtIwc11__mbstate_tEE
void __fastcall `anonymous namespace'::convert_aux(
        const wchar_t *from,
        const wchar_t *from_end,
        char *to,
        char *to_end,
        std::string *target,
        const boost::filesystem::path_traits::codecvt_type *cvt)
{
  int v8; // eax
  int v9; // ebp
  boost::system::system_error *exception; // rbx
  const boost::system::error_category *v11; // rax
  char *__last; // [rsp+8h] [rbp-30h] BYREF
  __int64 v13; // [rsp+10h] [rbp-28h] BYREF
  _BYTE v14[32]; // [rsp+18h] [rbp-20h] BYREF

  v13 = 0;
  v8 = (*(__int64 (__fastcall **)(const boost::filesystem::path_traits::codecvt_type *, __int64 *, const wchar_t *, const wchar_t *, _BYTE *, char *, char *, char **))(*(_QWORD *)cvt + 24LL))(
         cvt,
         &v13,
         from,
         from_end,
         v14,
         to,
         to_end,
         &__last);
  if ( v8 )
  {
    v9 = v8;
    exception = (boost::system::system_error *)__cxa_allocate_exception(0x38u);
    v11 = boost::filesystem::codecvt_error_category();
    boost::system::system_error::system_error(exception, v9, v11, "boost::filesystem::path codecvt to string");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'boost::system::system_error,
      (void (*)(void *))boost::system::system_error::~system_error);
  }
  std::string::__append_forward_unsafe<char *>(target, to, __last);
}


