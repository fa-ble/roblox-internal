// Address: 0xf178d0 | Name: _ZN3RBX7Network14MegaReplicator24isPendingNewInstanceItemEPKNS0_10ReplicatorEPKNS_8InstanceE
bool __fastcall RBX::Network::MegaReplicator::isPendingNewInstanceItem(
        RBX::Network::MegaReplicator *this,
        const RBX::Network::Replicator *replicator,
        const RBX::Instance *instance)
{
  unsigned __int64 v3; // rax
  __int64 v4; // rcx
  __int64 v5; // r8
  __int64 ***v6; // rax
  __int64 **v7; // rdi
  __int64 *v8; // rax
  unsigned __int64 v9; // r9
  __int64 *v10; // r8
  bool result; // al
  __int64 v12; // r8
  __int64 **v13; // rax
  __int64 *v14; // rsi

  v3 = (21
      * ((265
        * ((~((unsigned __int64)instance + ((unsigned __int64)instance >> 3))
          + (((_QWORD)instance + ((unsigned __int64)instance >> 3)) << 21))
         ^ ((~((unsigned __int64)instance + ((unsigned __int64)instance >> 3))
           + (((_QWORD)instance + ((unsigned __int64)instance >> 3)) << 21)) >> 24)))
       ^ ((265
         * ((~((unsigned __int64)instance + ((unsigned __int64)instance >> 3))
           + (((_QWORD)instance + ((unsigned __int64)instance >> 3)) << 21))
          ^ ((~((unsigned __int64)instance + ((unsigned __int64)instance >> 3))
            + (((_QWORD)instance + ((unsigned __int64)instance >> 3)) << 21)) >> 24))) >> 14)))
     ^ ((21
       * ((265
         * ((~((unsigned __int64)instance + ((unsigned __int64)instance >> 3))
           + (((_QWORD)instance + ((unsigned __int64)instance >> 3)) << 21))
          ^ ((~((unsigned __int64)instance + ((unsigned __int64)instance >> 3))
            + (((_QWORD)instance + ((unsigned __int64)instance >> 3)) << 21)) >> 24)))
        ^ ((265
          * ((~((unsigned __int64)instance + ((unsigned __int64)instance >> 3))
            + (((_QWORD)instance + ((unsigned __int64)instance >> 3)) << 21))
           ^ ((~((unsigned __int64)instance + ((unsigned __int64)instance >> 3))
             + (((_QWORD)instance + ((unsigned __int64)instance >> 3)) << 21)) >> 24))) >> 14))) >> 28);
  v4 = 2147483649u * v3;
  if ( !*((_QWORD *)this + 2)
    || (v5 = *((_QWORD *)this + 1) - 1LL, (v6 = *(__int64 ****)(*((_QWORD *)this + 5) + 8 * (v4 & v5))) == 0)
    || (v7 = *v6) == 0 )
  {
LABEL_13:
    if ( *((_QWORD *)replicator + 1023) )
    {
      v12 = *((_QWORD *)replicator + 1022) - 1LL;
      v13 = *(__int64 ***)(*((_QWORD *)replicator + 1026) + 8 * (v4 & v12));
      if ( v13 )
      {
        while ( 1 )
        {
          v13 = (__int64 **)*v13;
          if ( !v13 )
            break;
          v14 = v13[1];
          if ( v14 == (__int64 *)v4 )
          {
            if ( v13[2] == (__int64 *)instance )
              return v13 != 0;
          }
          else if ( (v12 & (unsigned __int64)v14) != (v4 & v12) )
          {
            break;
          }
        }
      }
    }
    v13 = 0;
    return v13 != 0;
  }
  while ( 1 )
  {
    v8 = v7[1];
    if ( v8 == (__int64 *)v4 )
      break;
    if ( (v5 & (unsigned __int64)v8) != (v4 & v5) )
      goto LABEL_13;
LABEL_5:
    v7 = (__int64 **)*v7;
    if ( !v7 )
      goto LABEL_13;
  }
  if ( v7[2] != (__int64 *)instance )
    goto LABEL_5;
  v9 = *((unsigned int *)replicator + 1802);
  v10 = v7[13];
  if ( 0xAAAAAAAAAAAAAAABLL * (v7[14] - v10) <= v9 )
    goto LABEL_13;
  result = HIDWORD(v10[3 * v9 + 1]) != 0;
  if ( !LOBYTE(v10[3 * v9 + 2]) )
    goto LABEL_13;
  return result;
}


// Address: 0xf464b0 | Name: _ZN3RBX7Network20ReplicationDataCache23isMrdInCachePendingListEPNS0_19MegaReplicationDataE
bool __fastcall RBX::Network::ReplicationDataCache::isMrdInCachePendingList(
        RBX::Network::ReplicationDataCache *this,
        RBX::Network::MegaReplicationData *mrd)
{
  unsigned __int64 v2; // rcx
  __int64 v3; // rax
  __int64 v4; // r9
  __int64 **v5; // rcx
  __int64 *v6; // rdx
  __int64 v7; // r9
  __int64 **v8; // rcx
  __int64 *v9; // rdx
  __int64 v10; // r8
  __int64 **v11; // rcx
  __int64 *v12; // rdi

  v2 = (21
      * ((265
        * ((~((unsigned __int64)mrd + ((unsigned __int64)mrd >> 3))
          + (((_QWORD)mrd + ((unsigned __int64)mrd >> 3)) << 21))
         ^ ((~((unsigned __int64)mrd + ((unsigned __int64)mrd >> 3))
           + (((_QWORD)mrd + ((unsigned __int64)mrd >> 3)) << 21)) >> 24)))
       ^ ((265
         * ((~((unsigned __int64)mrd + ((unsigned __int64)mrd >> 3))
           + (((_QWORD)mrd + ((unsigned __int64)mrd >> 3)) << 21))
          ^ ((~((unsigned __int64)mrd + ((unsigned __int64)mrd >> 3))
            + (((_QWORD)mrd + ((unsigned __int64)mrd >> 3)) << 21)) >> 24))) >> 14)))
     ^ ((21
       * ((265
         * ((~((unsigned __int64)mrd + ((unsigned __int64)mrd >> 3))
           + (((_QWORD)mrd + ((unsigned __int64)mrd >> 3)) << 21))
          ^ ((~((unsigned __int64)mrd + ((unsigned __int64)mrd >> 3))
            + (((_QWORD)mrd + ((unsigned __int64)mrd >> 3)) << 21)) >> 24)))
        ^ ((265
          * ((~((unsigned __int64)mrd + ((unsigned __int64)mrd >> 3))
            + (((_QWORD)mrd + ((unsigned __int64)mrd >> 3)) << 21))
           ^ ((~((unsigned __int64)mrd + ((unsigned __int64)mrd >> 3))
             + (((_QWORD)mrd + ((unsigned __int64)mrd >> 3)) << 21)) >> 24))) >> 14))) >> 28);
  v3 = 2147483649u * v2;
  if ( *((_QWORD *)this + 3) )
  {
    v4 = v3 & (*((_QWORD *)this + 2) - 1LL);
    v5 = *(__int64 ***)(*((_QWORD *)this + 6) + 8 * v4);
    if ( v5 )
    {
      while ( 1 )
      {
        v5 = (__int64 **)*v5;
        if ( !v5 )
          break;
        v6 = v5[1];
        if ( v6 == (__int64 *)v3 )
        {
          if ( v5[2] == (__int64 *)mrd )
            return 1;
        }
        else if ( ((*((_QWORD *)this + 2) - 1LL) & (unsigned __int64)v6) != v4 )
        {
          break;
        }
      }
    }
  }
  if ( *((_QWORD *)this + 9) )
  {
    v7 = v3 & (*((_QWORD *)this + 8) - 1LL);
    v8 = *(__int64 ***)(*((_QWORD *)this + 12) + 8 * v7);
    if ( v8 )
    {
      while ( 1 )
      {
        v8 = (__int64 **)*v8;
        if ( !v8 )
          break;
        v9 = v8[1];
        if ( v9 == (__int64 *)v3 )
        {
          if ( v8[2] == (__int64 *)mrd )
            return 1;
        }
        else if ( ((*((_QWORD *)this + 8) - 1LL) & (unsigned __int64)v9) != v7 )
        {
          break;
        }
      }
    }
  }
  if ( *((_QWORD *)this + 15) )
  {
    v10 = *((_QWORD *)this + 14) - 1LL;
    v11 = *(__int64 ***)(*((_QWORD *)this + 18) + 8 * (v3 & v10));
    if ( v11 )
    {
      while ( 1 )
      {
        v11 = (__int64 **)*v11;
        if ( !v11 )
          break;
        v12 = v11[1];
        if ( v12 == (__int64 *)v3 )
        {
          if ( v11[2] == (__int64 *)mrd )
            return v11 != 0;
        }
        else if ( (v10 & (unsigned __int64)v12) != (v3 & v10) )
        {
          break;
        }
      }
    }
  }
  v11 = 0;
  return v11 != 0;
}


// Address: 0x1e2ead0 | Name: _ZNK3RBX18PhysicalProperties8hashCodeEv
size_t __fastcall RBX::PhysicalProperties::hashCode(const RBX::PhysicalProperties *this)
{
  __int64 v1; // rax
  __m128i v2; // xmm1
  __int64 v3; // rdx
  __int64 v4; // rsi
  unsigned __int64 v5; // rdx
  __m128i v6; // xmm1
  __int64 v7; // rcx
  __int64 v8; // rsi
  unsigned __int64 v9; // rsi
  __m128i v10; // xmm1
  __int64 v11; // rcx
  bool v12; // zf
  __m128i v13; // xmm1
  __int64 v14; // rdx
  unsigned __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rsi
  unsigned __int64 v18; // rsi
  __m128i v19; // xmm1
  __int64 v20; // rcx

  v1 = 2654435769LL;
  v2 = _mm_cvtsi32_si128(LODWORD(this->density));
  v3 = (unsigned int)_mm_cvtsi128_si32(v2) + 2654435769LL;
  v4 = 2654435769LL;
  if ( *(float *)v2.m128i_i32 != 0.0 )
    v4 = v3;
  v5 = (this->customEnabled + 2654435769LL) ^ (v4 + ((this->customEnabled + 2654435769LL) << 6) + 663608942);
  v6 = _mm_cvtsi32_si128(LODWORD(this->friction));
  v7 = (unsigned int)_mm_cvtsi128_si32(v6) + 2654435769LL;
  v8 = 2654435769LL;
  if ( *(float *)v6.m128i_i32 != 0.0 )
    v8 = v7;
  v9 = v5 ^ (v8 + (v5 << 6) + (v5 >> 2));
  v10 = _mm_cvtsi32_si128(LODWORD(this->frictionWeight));
  v11 = (unsigned int)_mm_cvtsi128_si32(v10) + 2654435769LL;
  v12 = *(float *)v10.m128i_i32 == 0.0;
  v13 = _mm_cvtsi32_si128(LODWORD(this->elasticity));
  v14 = 2654435769LL;
  if ( !v12 )
    v14 = v11;
  v15 = v9 ^ (v14 + (v9 << 6) + (v9 >> 2));
  v16 = (unsigned int)_mm_cvtsi128_si32(v13) + 2654435769LL;
  v17 = 2654435769LL;
  if ( *(float *)v13.m128i_i32 != 0.0 )
    v17 = v16;
  v18 = v15 ^ (v17 + (v15 << 6) + (v15 >> 2));
  v19 = _mm_cvtsi32_si128(LODWORD(this->elasticityWeight));
  v20 = (unsigned int)_mm_cvtsi128_si32(v19) + 2654435769LL;
  if ( *(float *)v19.m128i_i32 != 0.0 )
    v1 = v20;
  return v18 ^ (v1 + (v18 << 6) + (v18 >> 2));
}


// Address: 0x1e2ebe0 | Name: _ZN3RBX10hash_valueERKNS_18PhysicalPropertiesE
size_t __fastcall RBX::hash_value(const RBX::PhysicalProperties *properties)
{
  __int64 v1; // rax
  __m128i v2; // xmm1
  __int64 v3; // rdx
  __int64 v4; // rsi
  unsigned __int64 v5; // rdx
  __m128i v6; // xmm1
  __int64 v7; // rcx
  __int64 v8; // rsi
  unsigned __int64 v9; // rsi
  __m128i v10; // xmm1
  __int64 v11; // rcx
  bool v12; // zf
  __m128i v13; // xmm1
  __int64 v14; // rdx
  unsigned __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rsi
  unsigned __int64 v18; // rsi
  __m128i v19; // xmm1
  __int64 v20; // rcx

  v1 = 2654435769LL;
  v2 = _mm_cvtsi32_si128(LODWORD(properties->density));
  v3 = (unsigned int)_mm_cvtsi128_si32(v2) + 2654435769LL;
  v4 = 2654435769LL;
  if ( *(float *)v2.m128i_i32 != 0.0 )
    v4 = v3;
  v5 = (properties->customEnabled + 2654435769LL) ^ (v4 + ((properties->customEnabled + 2654435769LL) << 6) + 663608942);
  v6 = _mm_cvtsi32_si128(LODWORD(properties->friction));
  v7 = (unsigned int)_mm_cvtsi128_si32(v6) + 2654435769LL;
  v8 = 2654435769LL;
  if ( *(float *)v6.m128i_i32 != 0.0 )
    v8 = v7;
  v9 = v5 ^ (v8 + (v5 << 6) + (v5 >> 2));
  v10 = _mm_cvtsi32_si128(LODWORD(properties->frictionWeight));
  v11 = (unsigned int)_mm_cvtsi128_si32(v10) + 2654435769LL;
  v12 = *(float *)v10.m128i_i32 == 0.0;
  v13 = _mm_cvtsi32_si128(LODWORD(properties->elasticity));
  v14 = 2654435769LL;
  if ( !v12 )
    v14 = v11;
  v15 = v9 ^ (v14 + (v9 << 6) + (v9 >> 2));
  v16 = (unsigned int)_mm_cvtsi128_si32(v13) + 2654435769LL;
  v17 = 2654435769LL;
  if ( *(float *)v13.m128i_i32 != 0.0 )
    v17 = v16;
  v18 = v15 ^ (v17 + (v15 << 6) + (v15 >> 2));
  v19 = _mm_cvtsi32_si128(LODWORD(properties->elasticityWeight));
  v20 = (unsigned int)_mm_cvtsi128_si32(v19) + 2654435769LL;
  if ( *(float *)v19.m128i_i32 != 0.0 )
    v1 = v20;
  return v18 ^ (v1 + (v18 << 6) + (v18 >> 2));
}


// Address: 0x2001f00 | Name: _ZN3RBX8Graphics7Shadows9Timestamp7addNodeEPNS0_17CullableSceneNodeE
void __fastcall RBX::Graphics::Shadows::Timestamp::addNode(
        RBX::Graphics::Shadows::Timestamp *this,
        RBX::Graphics::CullableSceneNode *node)
{
  uint32_t frameNum; // ecx

  this->nodesHash ^= (unsigned __int64)&node[33180447].DontInvalidateLighting
                   + 64 * this->nodesHash
                   + ((unsigned __int64)node >> 3)
                   + (this->nodesHash >> 2)
                   + 1;
  frameNum = this->frameNum;
  if ( frameNum < node->invalidateLightingFrameNum )
    frameNum = node->invalidateLightingFrameNum;
  this->frameNum = frameNum;
  ++this->nodesNum;
}


