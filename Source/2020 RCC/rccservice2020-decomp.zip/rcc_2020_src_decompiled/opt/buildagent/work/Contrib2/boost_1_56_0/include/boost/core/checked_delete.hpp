// Address: 0x10314e0 | Name: _ZN5boost14checked_deleteIN3RBX8Security19AslrPmcSharedHasher17SectionDataVectorEEEvPT_
void __fastcall boost::checked_delete<RBX::Security::AslrPmcSharedHasher::SectionDataVector>(
        RBX::Security::AslrPmcSharedHasher::SectionDataVector *x)
{
  void *v2; // rdi
  void *v3; // rdi
  void *v4; // rdi
  char *v5; // r15
  char *v6; // rbx
  void *v7; // rdi
  void *v8; // rdi
  char *v9; // r12
  void *v10; // rdi
  char *v11; // rdi

  if ( x )
  {
    v2 = (void *)*((_QWORD *)x + 9);
    if ( v2 )
    {
      *((_QWORD *)x + 10) = v2;
      operator delete(v2);
    }
    v3 = (void *)*((_QWORD *)x + 6);
    if ( v3 )
    {
      *((_QWORD *)x + 7) = v3;
      operator delete(v3);
    }
    v4 = (void *)*((_QWORD *)x + 3);
    if ( v4 )
    {
      *((_QWORD *)x + 4) = v4;
      operator delete(v4);
    }
    v5 = *(char **)x;
    if ( *(_QWORD *)x )
    {
      v6 = (char *)*((_QWORD *)x + 1);
      if ( v6 == v5 )
      {
        v11 = *(char **)x;
      }
      else
      {
        do
        {
          v7 = (void *)*((_QWORD *)v6 - 4);
          if ( v7 )
          {
            *((_QWORD *)v6 - 3) = v7;
            operator delete(v7);
          }
          v8 = (void *)*((_QWORD *)v6 - 7);
          if ( v8 )
          {
            *((_QWORD *)v6 - 6) = v8;
            operator delete(v8);
          }
          v9 = v6 - 80;
          v10 = (void *)*((_QWORD *)v6 - 10);
          if ( v10 )
          {
            *((_QWORD *)v6 - 9) = v10;
            operator delete(v10);
          }
          v6 -= 80;
        }
        while ( v5 != v9 );
        v11 = *(char **)x;
      }
      *((_QWORD *)x + 1) = v5;
      operator delete(v11);
    }
    operator delete(x);
  }
}


