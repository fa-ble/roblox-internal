// Address: 0xe5c830 | Name: _ZN5boost15program_options18option_descriptionC2Ev
void __fastcall boost::program_options::option_description::option_description(
        boost::program_options::option_description *this)
{
  *(_QWORD *)this = off_287D8A8;
  *(_OWORD *)((char *)this + 72) = 0;
  *(_OWORD *)((char *)this + 56) = 0;
  *(_OWORD *)((char *)this + 40) = 0;
  *(_OWORD *)((char *)this + 24) = 0;
  *(_OWORD *)((char *)this + 8) = 0;
  *((_QWORD *)this + 11) = 0;
}


// Address: 0xe5c860 | Name: _ZN5boost15program_options18option_descriptionC2EPKcPKNS0_14value_semanticE
void __fastcall boost::program_options::option_description::option_description(
        boost::program_options::option_description *this,
        const char *name,
        const boost::program_options::value_semantic *s)
{
  *(_QWORD *)this = off_287D8A8;
  *(_OWORD *)((char *)this + 56) = 0;
  *(_OWORD *)((char *)this + 40) = 0;
  *(_OWORD *)((char *)this + 24) = 0;
  *(_OWORD *)((char *)this + 8) = 0;
  *((_QWORD *)this + 9) = 0;
  *((_QWORD *)this + 10) = s;
  *((_QWORD *)this + 11) = 0;
  boost::detail::sp_pointer_construct<boost::program_options::value_semantic const,boost::program_options::value_semantic const>(
    (boost::shared_ptr<const boost::program_options::value_semantic>_0 *)this + 5,
    s,
    (boost::detail::shared_count *)this + 11);
  boost::program_options::option_description::set_name(this, name);
}


// Address: 0xe5c980 | Name: _ZN5boost15program_options18option_description8set_nameEPKc
boost::program_options::option_description *__fastcall boost::program_options::option_description::set_name(
        boost::program_options::option_description *this,
        const char *_name)
{
  size_t v3; // rax
  size_t v4; // r13
  char *v5; // r12
  size_t v6; // rbx
  __int64 v7; // rax
  int v8; // edx
  void *v9; // rcx
  size_t v10; // r8
  const void *v11; // r9
  __int64 v12; // r15
  _WORD *v13; // rbx
  char *v14; // rsi
  char v15; // bl
  void *v16; // r15
  _WORD *v17; // rdi
  __int64 v18; // rax
  __int128 v20; // [rsp+0h] [rbp-78h] BYREF
  void *ptr; // [rsp+10h] [rbp-68h]
  __int128 dest; // [rsp+20h] [rbp-58h] BYREF
  void *v23; // [rsp+30h] [rbp-48h]
  _QWORD v24[8]; // [rsp+38h] [rbp-40h]

  v24[2] = __readfsqword(0x28u);
  dest = 0;
  v23 = 0;
  v3 = strlen(_name);
  if ( v3 >= 0xFFFFFFFFFFFFFFF0LL )
    std::__basic_string_common<true>::__throw_length_error(&dest);
  v4 = v3;
  if ( v3 >= 0x17 )
  {
    v6 = (v3 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v5 = (char *)operator new(v6);
    v23 = v5;
    *(_QWORD *)&dest = v6 | 1;
    *((_QWORD *)&dest + 1) = v4;
    goto LABEL_6;
  }
  LOBYTE(dest) = 2 * v3;
  v5 = (char *)&dest + 1;
  if ( v3 )
LABEL_6:
    memcpy(v5, _name, v4);
  v5[v4] = 0;
  v7 = std::string::find(&dest, 44, 0);
  if ( v7 == -1 )
  {
    std::string::operator=((soap *)((char *)this + 32), (int)&dest, v8, v9, v10, v11);
  }
  else
  {
    v12 = v7;
    std::string::basic_string(&v20, &dest, 0, v7, &dest);
    v13 = (_WORD *)((char *)this + 32);
    if ( (*((_BYTE *)this + 32) & 1) != 0 )
    {
      **((_BYTE **)this + 6) = 0;
      *((_QWORD *)this + 5) = 0;
    }
    else
    {
      *v13 = 0;
    }
    std::string::reserve((char *)this + 32, 0);
    *((_QWORD *)this + 6) = ptr;
    *(_OWORD *)v13 = v20;
    std::string::basic_string(&v20, &dest, v12 + 1, 1, &dest);
    if ( (v20 & 1) != 0 )
      v14 = (char *)ptr;
    else
      v14 = (char *)&v20 + 1;
    std::string::insert(&v20, v14, 45);
    v15 = v20;
    v24[0] = *(_QWORD *)((char *)&v20 + 1);
    *(_QWORD *)((char *)v24 + 7) = *((_QWORD *)&v20 + 1);
    v16 = ptr;
    v20 = 0;
    ptr = 0;
    v17 = (_WORD *)((char *)this + 8);
    if ( (*((_BYTE *)this + 8) & 1) != 0 )
    {
      **((_BYTE **)this + 3) = 0;
      *((_QWORD *)this + 2) = 0;
    }
    else
    {
      *v17 = 0;
    }
    std::string::reserve(v17, 0);
    *((_BYTE *)this + 8) = v15;
    v18 = v24[0];
    *((_QWORD *)this + 2) = *(_QWORD *)((char *)v24 + 7);
    *(_QWORD *)((char *)this + 9) = v18;
    *((_QWORD *)this + 3) = v16;
    *(_QWORD *)((char *)v24 + 7) = 0;
    v24[0] = 0;
    if ( (v20 & 1) != 0 )
      operator delete(ptr);
  }
  if ( (dest & 1) != 0 )
    operator delete(v23);
  return this;
}


// Address: 0xe5cc10 | Name: _ZN5boost15program_options18option_descriptionC2EPKcPKNS0_14value_semanticES3_
void __fastcall boost::program_options::option_description::option_description(
        boost::program_options::option_description *this,
        const char *name,
        const boost::program_options::value_semantic *s,
        const char *description)
{
  const char *v6; // r15
  _BYTE *v7; // r14
  size_t v8; // rax
  size_t v9; // rbp
  char *v10; // r14
  size_t v11; // r15
  struct _Unwind_Exception *v12; // r15
  _BYTE *v13; // rbp

  v6 = name;
  *(_QWORD *)this = off_287D8A8;
  v7 = (char *)this + 56;
  *(_OWORD *)((char *)this + 56) = 0;
  *(_OWORD *)((char *)this + 40) = 0;
  *(_OWORD *)((char *)this + 24) = 0;
  *(_OWORD *)((char *)this + 8) = 0;
  *((_QWORD *)this + 9) = 0;
  v8 = strlen(description);
  if ( v8 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v12 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(v7);
    v13 = (char *)this + 8;
    if ( (*((_BYTE *)this + 32) & 1) != 0 )
    {
      operator delete(*((void **)this + 6));
      if ( (*v13 & 1) == 0 )
LABEL_10:
        _Unwind_Resume(v12);
    }
    else if ( (*v13 & 1) == 0 )
    {
      goto LABEL_10;
    }
    operator delete(*((void **)this + 3));
    _Unwind_Resume(v12);
  }
  v9 = v8;
  if ( v8 >= 0x17 )
  {
    v11 = (v8 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v10 = (char *)operator new(v11);
    *((_QWORD *)this + 9) = v10;
    *((_QWORD *)this + 7) = v11 | 1;
    *((_QWORD *)this + 8) = v9;
    v6 = name;
  }
  else
  {
    *v7 = 2 * v8;
    v10 = (char *)this + 57;
    if ( !v8 )
      goto LABEL_7;
  }
  memcpy(v10, description, v9);
LABEL_7:
  v10[v9] = 0;
  *((_QWORD *)this + 10) = s;
  *((_QWORD *)this + 11) = 0;
  boost::detail::sp_pointer_construct<boost::program_options::value_semantic const,boost::program_options::value_semantic const>(
    (boost::shared_ptr<const boost::program_options::value_semantic>_0 *)this + 5,
    s,
    (boost::detail::shared_count *)this + 11);
  boost::program_options::option_description::set_name(this, v6);
}


// Address: 0xe5cdd0 | Name: _ZN5boost15program_options18option_descriptionD2Ev
void __fastcall boost::program_options::option_description::~option_description(
        boost::program_options::option_description *this)
{
  volatile signed __int32 *v1; // r14

  *(_QWORD *)this = off_287D8A8;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 11);
  if ( v1 && !_InterlockedSub(v1 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
    if ( !_InterlockedSub(v1 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
  }
  if ( (*((_BYTE *)this + 56) & 1) != 0 )
  {
    operator delete(*((void **)this + 9));
    if ( (*((_BYTE *)this + 32) & 1) == 0 )
    {
LABEL_7:
      if ( (*((_BYTE *)this + 8) & 1) == 0 )
        return;
LABEL_11:
      operator delete(*((void **)this + 3));
      return;
    }
  }
  else if ( (*((_BYTE *)this + 32) & 1) == 0 )
  {
    goto LABEL_7;
  }
  operator delete(*((void **)this + 6));
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    goto LABEL_11;
}


// Address: 0xe5ce60 | Name: _ZN5boost15program_options18option_descriptionD0Ev
void __fastcall boost::program_options::option_description::~option_description(
        boost::program_options::option_description *this)
{
  boost::program_options::option_description::~option_description(this);
  operator delete(this);
}


// Address: 0xe5ce80 | Name: _ZNK5boost15program_options18option_description5matchERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEbbb
boost::program_options::option_description::match_result __fastcall boost::program_options::option_description::match(
        const boost::program_options::option_description *this,
        const std::string *option,
        bool approx,
        bool long_ignore_case,
        bool short_ignore_case)
{
  _BOOL4 v5; // r15d
  const boost::program_options::option_description *v8; // r14
  char *v9; // rsi
  int v10; // r12d
  unsigned __int8 v11; // al
  unsigned __int64 v12; // rbx
  signed __int64 v13; // rbp
  _BYTE *v14; // rdx
  unsigned __int64 v15; // rcx
  int v16; // esi
  _BYTE *v17; // rcx
  unsigned __int8 v18; // r13
  void *v19; // rdi
  signed __int64 v20; // rbp
  unsigned __int8 *v21; // r15
  signed __int64 v22; // rdx
  __int64 v23; // rbx
  _BYTE *v24; // r14
  _BYTE *v25; // rax
  _BYTE *v26; // r12
  const void *v27; // r12
  int v28; // ebx
  size_t v29; // rdx
  _BYTE *v30; // rax
  __int64 v31; // rax
  size_t v32; // rdx
  unsigned __int8 v33; // r15
  signed __int64 v34; // r13
  _BYTE *v35; // rsi
  __int64 v36; // rcx
  unsigned __int8 *v37; // rbx
  char *v38; // r12
  void *v39; // r14
  size_t v40; // rbp
  char *v41; // rax
  char *v42; // r14
  char *v43; // rax
  bool v44; // zf
  boost::program_options::option_description::match_result v45; // ebx
  size_t v46; // rdx
  char v47; // al
  void *v48; // rbx
  _BYTE *v49; // rsi
  __int64 v50; // rdx
  void *ptr; // [rsp+8h] [rbp-B0h]
  int ptra; // [rsp+8h] [rbp-B0h]
  int ca; // [rsp+14h] [rbp-A4h]
  unsigned __int8 v56; // [rsp+18h] [rbp-A0h] BYREF
  _BYTE v57[7]; // [rsp+19h] [rbp-9Fh] BYREF
  size_t v58; // [rsp+20h] [rbp-98h]
  void *s; // [rsp+28h] [rbp-90h]
  void *v60; // [rsp+30h] [rbp-88h]
  const boost::program_options::option_description *v61; // [rsp+38h] [rbp-80h]
  unsigned __int8 v62; // [rsp+40h] [rbp-78h] BYREF
  _BYTE s1[7]; // [rsp+41h] [rbp-77h] BYREF
  unsigned __int64 v64; // [rsp+48h] [rbp-70h]
  void *v65; // [rsp+50h] [rbp-68h]
  char *v66; // [rsp+58h] [rbp-60h]
  unsigned __int8 v67; // [rsp+60h] [rbp-58h] BYREF
  _BYTE v68[7]; // [rsp+61h] [rbp-57h] BYREF
  size_t n; // [rsp+68h] [rbp-50h]
  void *s2; // [rsp+70h] [rbp-48h]
  _BOOL4 v71; // [rsp+7Ch] [rbp-3Ch]
  const std::string *v72; // [rsp+80h] [rbp-38h]

  v5 = short_ignore_case;
  v8 = this;
  v9 = (char *)this + 32;
  if ( long_ignore_case )
    boost::program_options::`anonymous namespace'::tolower_<char>(&v62, v9);
  else
    std::string::basic_string(&v62, v9);
  if ( (v62 & 1) != 0 )
  {
    if ( v64 )
      goto LABEL_6;
  }
  else if ( (unsigned __int64)v62 >> 1 )
  {
LABEL_6:
    if ( long_ignore_case )
      boost::program_options::`anonymous namespace'::tolower_<char>(&v56, option);
    else
      std::string::basic_string(&v56, option);
    v71 = v5;
    v72 = option;
    v11 = v62;
    v12 = (unsigned __int64)v62 >> 1;
    v13 = v64;
    v14 = s1;
    v66 = s1;
    v15 = v12;
    if ( (v62 & 1) != 0 )
    {
      v14 = v65;
      v15 = v64;
    }
    v16 = 0;
    if ( v14[v15 - 1] != 42 )
    {
LABEL_41:
      ptra = v16;
      v32 = v13;
      if ( (v11 & 1) == 0 )
        v32 = v12;
      v33 = v56;
      if ( (v56 & 1) != 0 )
      {
        v34 = v58;
        if ( v32 != v58 )
          goto LABEL_56;
      }
      else
      {
        v34 = (unsigned __int64)v56 >> 1;
        if ( v32 != v34 )
          goto LABEL_56;
      }
      if ( (v56 & 1) != 0 )
        v35 = s;
      else
        v35 = v57;
      if ( (v11 & 1) != 0 )
      {
        if ( !v32 )
        {
          v10 = 1;
          if ( (v56 & 1) == 0 )
          {
LABEL_85:
            v45 = boost::program_options::option_description::match_result::full_match;
            option = v72;
            if ( v10 == 1 )
              goto LABEL_111;
            if ( v71 )
              goto LABEL_87;
LABEL_10:
            std::string::basic_string(&v56, option);
            std::string::basic_string(&v67, (char *)v8 + 8);
            goto LABEL_88;
          }
LABEL_84:
          operator delete(s);
          goto LABEL_85;
        }
        v60 = v65;
        v10 = 1;
        if ( !memcmp(v65, v35, v32) )
          goto LABEL_83;
        v10 = ptra;
        if ( !approx )
          goto LABEL_83;
        if ( (v33 & 1) == 0 )
        {
LABEL_60:
          v37 = v57;
          if ( v34 )
          {
LABEL_61:
            if ( v13 < v34 )
            {
LABEL_62:
              v10 = ptra;
              if ( (v33 & 1) == 0 )
                goto LABEL_85;
              goto LABEL_84;
            }
            v61 = v8;
            v38 = (char *)v60;
            v66 = (char *)v60 + v13;
            ca = *v37;
            v39 = v60;
            while ( 1 )
            {
              v40 = v13 - v34 + 1;
              if ( !v40 )
                goto LABEL_82;
              v41 = (char *)memchr(v39, ca, v40);
              if ( !v41 )
                goto LABEL_82;
              v42 = v41;
              if ( !memcmp(v41, v37, v34) )
                break;
              v39 = v42 + 1;
              v13 = v66 - (_BYTE *)v39;
              if ( v66 - (_BYTE *)v39 < v34 )
                goto LABEL_82;
            }
            if ( v42 == v66 )
            {
LABEL_82:
              v10 = ptra;
              v8 = v61;
              goto LABEL_83;
            }
            v43 = v38;
            v10 = ptra;
            v44 = v42 == v43;
            v8 = v61;
            if ( v44 )
              goto LABEL_69;
LABEL_83:
            if ( (v33 & 1) == 0 )
              goto LABEL_85;
            goto LABEL_84;
          }
LABEL_69:
          v10 = 2;
          if ( (v33 & 1) == 0 )
            goto LABEL_85;
          goto LABEL_84;
        }
LABEL_68:
        v37 = (unsigned __int8 *)s;
        if ( v34 )
          goto LABEL_61;
        goto LABEL_69;
      }
      v10 = 1;
      if ( !v32 )
        goto LABEL_83;
      v36 = 0;
      while ( s1[v36] == v35[v36] )
      {
        if ( v12 == ++v36 )
          goto LABEL_83;
      }
LABEL_56:
      if ( !approx )
        goto LABEL_62;
      if ( (v11 & 1) != 0 )
      {
        v66 = (char *)v65;
        v12 = v13;
      }
      v60 = v66;
      v13 = v12;
      if ( (v56 & 1) == 0 )
        goto LABEL_60;
      goto LABEL_68;
    }
    std::string::basic_string(&v67, &v62, 0, v15 - 1, &v62);
    if ( (v56 & 1) != 0 )
      v17 = s;
    else
      v17 = v57;
    v18 = v67;
    v19 = s2;
    if ( (v67 & 1) != 0 )
    {
      v20 = n;
      v21 = (unsigned __int8 *)s2;
      if ( n )
        goto LABEL_20;
    }
    else
    {
      v20 = (unsigned __int64)v67 >> 1;
      v21 = v68;
      if ( v20 )
      {
LABEL_20:
        v61 = v8;
        if ( (v56 & 1) != 0 )
          v22 = v58;
        else
          v22 = (unsigned __int64)v56 >> 1;
        ptr = s2;
        v24 = &v17[v22];
        if ( v22 >= v20 )
        {
          v27 = v17;
          v28 = *v21;
          v60 = v17;
          while ( 1 )
          {
            v29 = v22 - v20 + 1;
            if ( !v29 || (v30 = memchr(v27, v28, v29)) == 0 )
            {
LABEL_33:
              v25 = v24;
              v26 = v24;
              goto LABEL_35;
            }
            v26 = v30;
            if ( !memcmp(v30, v21, v20) )
              break;
            v27 = v26 + 1;
            v22 = v24 - (_BYTE *)v27;
            if ( v24 - (_BYTE *)v27 < v20 )
              goto LABEL_33;
          }
          v25 = v26;
LABEL_35:
          v17 = v60;
        }
        else
        {
          v25 = &v17[v22];
          v26 = &v17[v22];
        }
        v31 = v25 - v17;
        v23 = -1;
        if ( v26 != v24 )
          v23 = v31;
        v8 = v61;
        v19 = ptr;
        if ( (v18 & 1) == 0 )
          goto LABEL_40;
LABEL_39:
        operator delete(v19);
LABEL_40:
        v16 = 2 * (v23 == 0);
        v11 = v62;
        v13 = v64;
        v12 = (unsigned __int64)v62 >> 1;
        goto LABEL_41;
      }
    }
    v23 = 0;
    if ( (v67 & 1) == 0 )
      goto LABEL_40;
    goto LABEL_39;
  }
  v10 = 0;
  if ( !v5 )
    goto LABEL_10;
LABEL_87:
  boost::program_options::`anonymous namespace'::tolower_<char>(&v56, option);
  boost::program_options::`anonymous namespace'::tolower_<char>(&v67, (char *)v8 + 8);
LABEL_88:
  v46 = (unsigned __int64)v67 >> 1;
  if ( (v67 & 1) != 0 )
    v46 = n;
  v47 = v56 & 1;
  if ( (v56 & 1) != 0 )
  {
    if ( v46 != v58 )
      goto LABEL_103;
  }
  else if ( v46 != (unsigned __int64)v56 >> 1 )
  {
LABEL_103:
    if ( (v67 & 1) == 0 )
      goto LABEL_109;
    v48 = s2;
LABEL_108:
    operator delete(v48);
    v47 = v56 & 1;
LABEL_109:
    v45 = v10;
    if ( !v47 )
      goto LABEL_111;
    goto LABEL_110;
  }
  v48 = s2;
  if ( v47 )
    v49 = s;
  else
    v49 = v57;
  if ( (v67 & 1) != 0 )
  {
    if ( !v46 || !memcmp(s2, v49, v46) )
      v10 = 1;
    goto LABEL_108;
  }
  if ( v46 )
  {
    v50 = 0;
    while ( v68[v50] == v49[v50] )
    {
      if ( (unsigned __int64)v67 >> 1 == ++v50 )
      {
        v10 = 1;
        goto LABEL_103;
      }
    }
    goto LABEL_103;
  }
  v45 = boost::program_options::option_description::match_result::full_match;
  if ( v47 )
LABEL_110:
    operator delete(s);
LABEL_111:
  if ( (v62 & 1) != 0 )
    operator delete(v65);
  return v45;
}


// Address: 0xe5d410 | Name: _ZN5boost15program_options12_GLOBAL__N_18tolower_IcEENSt3__112basic_stringIT_NS3_11char_traitsIS5_EENS3_9allocatorIS5_EEEERKSA_
__int64 __fastcall boost::program_options::`anonymous namespace'::tolower_<char>(__int64 a1, unsigned __int8 *a2)
{
  unsigned __int64 v2; // rcx
  bool v3; // al
  unsigned __int64 v4; // rbx
  unsigned __int8 *v5; // rcx
  __int32_t v6; // ebp
  unsigned __int64 v7; // rcx

  *(_OWORD *)a1 = 0;
  *(_QWORD *)(a1 + 16) = 0;
  v2 = *a2;
  v3 = (v2 & 1) == 0;
  if ( (v2 & 1) != 0 )
  {
    if ( !*((_QWORD *)a2 + 1) )
      return a1;
  }
  else if ( !(v2 >> 1) )
  {
    return a1;
  }
  v4 = 0;
  do
  {
    while ( 1 )
    {
      v5 = a2 + 1;
      if ( !v3 )
        v5 = (unsigned __int8 *)*((_QWORD *)a2 + 2);
      v6 = (char)v5[v4];
      if ( (unsigned int)(v6 + 128) <= 0x17F )
        v6 = (*__ctype_tolower_loc())[v6];
      std::string::append(a1, 1, (unsigned int)(char)v6);
      ++v4;
      v7 = *a2;
      v3 = (v7 & 1) == 0;
      if ( (v7 & 1) == 0 )
        break;
      if ( v4 >= *((_QWORD *)a2 + 1) )
        return a1;
    }
  }
  while ( v4 < v7 >> 1 );
  return a1;
}


// Address: 0xe5d4f0 | Name: _ZNK5boost15program_options18option_description3keyERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEE
const std::string *__fastcall boost::program_options::option_description::key(
        const boost::program_options::option_description *this,
        const std::string *option)
{
  unsigned __int64 v3; // rax

  v3 = *((unsigned __int8 *)this + 32);
  if ( (v3 & 1) == 0 )
  {
    if ( v3 >> 1 )
      goto LABEL_3;
    return (const boost::program_options::option_description *)((char *)this + 8);
  }
  if ( !*((_QWORD *)this + 5) )
    return (const boost::program_options::option_description *)((char *)this + 8);
LABEL_3:
  if ( std::string::find((char *)this + 32, 42, 0) == -1 )
    return (const boost::program_options::option_description *)((char *)this + 32);
  return option;
}


// Address: 0xe5d550 | Name: _ZNK5boost15program_options18option_description22canonical_display_nameEi
boost::program_options::option_description *__fastcall boost::program_options::option_description::canonical_display_name(
        boost::program_options::option_description *this,
        __int64 a2,
        int a3)
{
  unsigned __int64 v5; // rdi
  unsigned __int64 v6; // rax
  __int64 v7; // rdx
  const char *v8; // rsi
  unsigned __int64 v9; // rbx
  unsigned __int64 v10; // rax
  __int64 v11; // r8
  __int64 v12; // rax
  __int64 v13; // rsi
  __int128 v15; // [rsp+0h] [rbp-28h] BYREF
  __int64 v16; // [rsp+10h] [rbp-18h]

  v5 = *(unsigned __int8 *)(a2 + 32);
  if ( (v5 & 1) != 0 )
    v6 = *(_QWORD *)(a2 + 40);
  else
    v6 = v5 >> 1;
  v7 = a2 + 32;
  if ( v6 )
  {
    if ( a3 == 4096 )
    {
      v8 = "-";
      goto LABEL_19;
    }
    if ( a3 == 1 )
    {
      v8 = "--";
LABEL_19:
      std::operator+<char>(this, v8, v7);
      return this;
    }
  }
  v9 = *(unsigned __int8 *)(a2 + 8);
  if ( (v9 & 1) != 0 )
    v10 = *(_QWORD *)(a2 + 16);
  else
    v10 = v9 >> 1;
  if ( v10 == 2 )
  {
    if ( a3 == 4 )
    {
      v15 = 0;
      v16 = 0;
      LOWORD(v15) = 11522;
      BYTE2(v15) = 0;
      if ( (v9 & 1) != 0 )
        v11 = *(_QWORD *)(a2 + 24);
      else
        v11 = a2 + 9;
      goto LABEL_29;
    }
    if ( a3 == 8 )
    {
      v15 = 0;
      v16 = 0;
      LOWORD(v15) = 12034;
      BYTE2(v15) = 0;
      if ( (v9 & 1) != 0 )
        v11 = *(_QWORD *)(a2 + 24);
      else
        v11 = a2 + 9;
LABEL_29:
      std::string::push_back(&v15, (unsigned int)*(char *)(v11 + 1));
      *((_QWORD *)this + 2) = v16;
      *(_OWORD *)this = v15;
      return this;
    }
  }
  if ( (v5 & 1) != 0 )
    v12 = *(_QWORD *)(a2 + 40);
  else
    v12 = (unsigned __int8)v5 >> 1;
  if ( v12 )
    v13 = a2 + 32;
  else
    v13 = a2 + 8;
  std::string::basic_string(this, v13);
  return this;
}


// Address: 0xe5d6a0 | Name: _ZNK5boost15program_options18option_description9long_nameEv
const std::string *__fastcall boost::program_options::option_description::long_name(
        const boost::program_options::option_description *this)
{
  return (const boost::program_options::option_description *)((char *)this + 32);
}


// Address: 0xe5d6b0 | Name: _ZNK5boost15program_options18option_description11descriptionEv
const std::string *__fastcall boost::program_options::option_description::description(
        const boost::program_options::option_description *this)
{
  return (const boost::program_options::option_description *)((char *)this + 56);
}


// Address: 0xe5d6e0 | Name: _ZNK5boost15program_options18option_description11format_nameEv
boost::program_options::option_description *__fastcall boost::program_options::option_description::format_name(
        boost::program_options::option_description *this,
        __int64 a2)
{
  unsigned __int64 v3; // rax
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rax
  unsigned __int64 v6; // rdx
  unsigned __int64 v7; // rdx
  __int64 v8; // rbx
  __int64 v9; // rsi
  __int64 v10; // rax
  unsigned __int64 v11; // rdx
  unsigned __int64 v12; // rdx
  __int64 v13; // rbx
  char v14; // bp
  __int64 v15; // rax
  __int64 v16; // rax
  __int128 v18; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  v3 = *(unsigned __int8 *)(a2 + 8);
  if ( (v3 & 1) == 0 )
  {
    if ( v3 >> 1 )
      goto LABEL_3;
LABEL_6:
    v18 = 0;
    ptr = 0;
    LOBYTE(v18) = 4;
    *(_WORD *)((char *)&v18 + 1) = 11565;
    BYTE3(v18) = 0;
    v6 = *(unsigned __int8 *)(a2 + 32);
    if ( (v6 & 1) != 0 )
    {
      v7 = *(_QWORD *)(a2 + 40);
      v8 = *(_QWORD *)(a2 + 48);
    }
    else
    {
      v8 = a2 + 33;
      v7 = v6 >> 1;
    }
    v16 = std::string::append(&v18, v8, v7);
    std::string::basic_string(this, v16);
    goto LABEL_19;
  }
  if ( !*(_QWORD *)(a2 + 16) )
    goto LABEL_6;
LABEL_3:
  v4 = *(unsigned __int8 *)(a2 + 32);
  if ( (v4 & 1) != 0 )
    v5 = *(_QWORD *)(a2 + 40);
  else
    v5 = v4 >> 1;
  v9 = a2 + 8;
  if ( v5 )
  {
    std::string::basic_string(&v18, v9);
    v10 = std::string::append(&v18, " [ --");
    v11 = *(unsigned __int8 *)(a2 + 32);
    if ( (v11 & 1) != 0 )
    {
      v12 = *(_QWORD *)(a2 + 40);
      v13 = *(_QWORD *)(a2 + 48);
    }
    else
    {
      v13 = a2 + 33;
      v12 = v11 >> 1;
    }
    v15 = std::string::append(v10, v13, v12);
    v9 = std::string::append(v15, " ]");
    v14 = 1;
  }
  else
  {
    v14 = 0;
  }
  std::string::basic_string(this, v9);
  if ( v14 )
  {
LABEL_19:
    if ( (v18 & 1) != 0 )
      operator delete(ptr);
  }
  return this;
}


// Address: 0xe5d830 | Name: _ZNK5boost15program_options18option_description16format_parameterEv
boost::program_options::option_description *__fastcall boost::program_options::option_description::format_parameter(
        boost::program_options::option_description *this,
        __int64 a2)
{
  if ( (*(unsigned int (__fastcall **)(_QWORD))(**(_QWORD **)(a2 + 80) + 16LL))(*(_QWORD *)(a2 + 80)) )
  {
    (***(void (__fastcall ****)(boost::program_options::option_description *))(a2 + 80))(this);
  }
  else
  {
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
  }
  return this;
}


// Address: 0xe5d870 | Name: _ZN5boost15program_options29options_description_easy_initC2EPNS0_19options_descriptionE
void __fastcall boost::program_options::options_description_easy_init::options_description_easy_init(
        boost::program_options::options_description_easy_init *this,
        boost::program_options::options_description *owner)
{
  this->owner = owner;
}


// Address: 0xe5d880 | Name: _ZN5boost15program_options29options_description_easy_initclEPKcS3_
boost::program_options::options_description_easy_init *__fastcall boost::program_options::options_description_easy_init::operator()(
        boost::program_options::options_description_easy_init *this,
        const char *name,
        const char *description)
{
  boost::program_options::option_description *v5; // rbx
  boost::program_options::value_semantic *v6; // rax
  unsigned __int64 v7; // rdx
  boost::program_options::options_description *owner; // rdi
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v10; // rbx
  boost::shared_ptr<boost::program_options::option_description> ppx; // [rsp+8h] [rbp-40h] BYREF
  boost::shared_ptr<boost::program_options::option_description> desc; // [rsp+18h] [rbp-30h] BYREF

  v5 = (boost::program_options::option_description *)operator new(0x60u);
  v6 = (boost::program_options::value_semantic *)operator new(0x10u);
  v6->_vptr$value_semantic = (int (**)(void))off_287DEE8;
  LOBYTE(v6[1]._vptr$value_semantic) = 1;
  boost::program_options::option_description::option_description(v5, name, v6, description);
  ppx = (boost::shared_ptr<boost::program_options::option_description>)(unsigned __int64)v5;
  boost::detail::sp_pointer_construct<boost::program_options::option_description,boost::program_options::option_description>(
    &ppx,
    v5,
    &ppx.pn);
  owner = this->owner;
  desc = ppx;
  if ( ppx.pn.pi_ )
    _InterlockedAdd(&ppx.pn.pi_->use_count_, 1u);
  boost::program_options::options_description::add(
    owner,
    (boost::shared_ptr<boost::program_options::option_description>)__PAIR128__(v7, &desc));
  pi = desc.pn.pi_;
  if ( desc.pn.pi_ )
  {
    if ( !_InterlockedSub(&desc.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v10 = ppx.pn.pi_;
  if ( ppx.pn.pi_ )
  {
    if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
      if ( !_InterlockedSub(&v10->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
    }
  }
  return this;
}


// Address: 0xe5da40 | Name: _ZN5boost15program_options19options_description3addENS_10shared_ptrINS0_18option_descriptionEEE
void __fastcall boost::program_options::options_description::add(
        boost::program_options::options_description *this,
        boost::shared_ptr<boost::program_options::option_description> desc)
{
  _QWORD *v3; // rax
  __int64 v4; // rcx
  unsigned __int64 v5; // rcx
  std::vector<bool> *v6; // rdi
  std::vector<bool>::size_type_0 v7; // rcx
  const boost::program_options::value_semantic *v8; // rdx

  v3 = (_QWORD *)*((_QWORD *)this + 5);
  if ( v3 == *((_QWORD **)this + 6) )
  {
    std::vector<boost::shared_ptr<boost::program_options::option_description>>::__push_back_slow_path<boost::shared_ptr<boost::program_options::option_description> const&>(
      (boost::program_options::options_description *)((char *)this + 32),
      (const boost::shared_ptr<boost::program_options::option_description> *)desc.px);
  }
  else
  {
    *v3 = *(_QWORD *)desc.px;
    v4 = *((_QWORD *)desc.px + 1);
    v3[1] = v4;
    if ( v4 )
    {
      _InterlockedAdd((volatile signed __int32 *)(v4 + 8), 1u);
      v3 = (_QWORD *)*((_QWORD *)this + 5);
    }
    *((_QWORD *)this + 5) = v3 + 2;
  }
  v5 = *((_QWORD *)this + 8);
  if ( v5 != *((_QWORD *)this + 9) << 6 )
    goto LABEL_14;
  v6 = (boost::program_options::options_description *)((char *)this + 56);
  if ( (__int64)(v5 + 1) >= 0 )
  {
    if ( v5 > 0x3FFFFFFFFFFFFFFELL )
    {
      v7 = 0x7FFFFFFFFFFFFFFFLL;
    }
    else
    {
      v7 = (v5 + 64) & 0xFFFFFFFFFFFFFFC0LL;
      if ( *((_QWORD *)this + 9) << 7 >= v7 )
        v7 = *((_QWORD *)this + 9) << 7;
    }
    std::vector<bool>::reserve(v6, v7);
    v5 = *((_QWORD *)this + 8);
LABEL_14:
    *((_QWORD *)this + 8) = v5 + 1;
    *(_QWORD *)(*((_QWORD *)this + 7) + 8 * (v5 >> 6)) &= __ROL8__(-2, v5);
    return;
  }
  std::__vector_base_common<true>::__throw_length_error(v6);
  boost::program_options::options_description_easy_init::operator()(
    (boost::program_options::options_description_easy_init *)v6,
    (const char *)desc.px,
    v8);
}


// Address: 0xe5db00 | Name: _ZN5boost15program_options29options_description_easy_initclEPKcPKNS0_14value_semanticE
boost::program_options::options_description_easy_init *__fastcall boost::program_options::options_description_easy_init::operator()(
        boost::program_options::options_description_easy_init *this,
        const char *name,
        const boost::program_options::value_semantic *s)
{
  boost::program_options::option_description *v5; // rbx
  unsigned __int64 v6; // rdx
  boost::program_options::options_description *owner; // rdi
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v9; // rbx
  boost::shared_ptr<boost::program_options::option_description> ppx; // [rsp+8h] [rbp-40h] BYREF
  boost::shared_ptr<boost::program_options::option_description> desc; // [rsp+18h] [rbp-30h] BYREF

  v5 = (boost::program_options::option_description *)operator new(0x60u);
  boost::program_options::option_description::option_description(v5, name, s);
  ppx = (boost::shared_ptr<boost::program_options::option_description>)(unsigned __int64)v5;
  boost::detail::sp_pointer_construct<boost::program_options::option_description,boost::program_options::option_description>(
    &ppx,
    v5,
    &ppx.pn);
  owner = this->owner;
  desc = ppx;
  if ( ppx.pn.pi_ )
    _InterlockedAdd(&ppx.pn.pi_->use_count_, 1u);
  boost::program_options::options_description::add(
    owner,
    (boost::shared_ptr<boost::program_options::option_description>)__PAIR128__(v6, &desc));
  pi = desc.pn.pi_;
  if ( desc.pn.pi_ )
  {
    if ( !_InterlockedSub(&desc.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v9 = ppx.pn.pi_;
  if ( ppx.pn.pi_ )
  {
    if ( !_InterlockedSub(&ppx.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
      if ( !_InterlockedSub(&v9->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
    }
  }
  return this;
}


// Address: 0xe5dca0 | Name: _ZN5boost15program_options29options_description_easy_initclEPKcPKNS0_14value_semanticES3_
boost::program_options::options_description_easy_init *__fastcall boost::program_options::options_description_easy_init::operator()(
        boost::program_options::options_description_easy_init *this,
        const char *name,
        const boost::program_options::value_semantic *s,
        const char *description)
{
  boost::program_options::option_description *v7; // rbx
  unsigned __int64 v8; // rdx
  boost::program_options::options_description *owner; // rdi
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v11; // rbx
  boost::shared_ptr<boost::program_options::option_description> v13; // [rsp+0h] [rbp-48h] BYREF
  boost::shared_ptr<boost::program_options::option_description> desc; // [rsp+10h] [rbp-38h] BYREF

  v7 = (boost::program_options::option_description *)operator new(0x60u);
  boost::program_options::option_description::option_description(v7, name, s, description);
  v13 = (boost::shared_ptr<boost::program_options::option_description>)(unsigned __int64)v7;
  boost::detail::sp_pointer_construct<boost::program_options::option_description,boost::program_options::option_description>(
    &v13,
    v7,
    &v13.pn);
  owner = this->owner;
  desc = v13;
  if ( v13.pn.pi_ )
    _InterlockedAdd(&v13.pn.pi_->use_count_, 1u);
  boost::program_options::options_description::add(
    owner,
    (boost::shared_ptr<boost::program_options::option_description>)__PAIR128__(v8, &desc));
  pi = desc.pn.pi_;
  if ( desc.pn.pi_ )
  {
    if ( !_InterlockedSub(&desc.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v11 = v13.pn.pi_;
  if ( v13.pn.pi_ )
  {
    if ( !_InterlockedSub(&v13.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 2))(v11);
      if ( !_InterlockedSub(&v11->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
    }
  }
  return this;
}


// Address: 0xe5de80 | Name: _ZN5boost15program_options19options_descriptionC2ERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEjj
void __fastcall boost::program_options::options_description::options_description(
        boost::program_options::options_description *this,
        const std::string *caption,
        unsigned int line_length,
        unsigned int min_description_length)
{
  std::string::basic_string(this, caption);
  *((_DWORD *)this + 6) = line_length;
  *((_DWORD *)this + 7) = min_description_length;
  *((_OWORD *)this + 5) = 0;
  *((_OWORD *)this + 4) = 0;
  *((_OWORD *)this + 3) = 0;
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 12) = 0;
}


// Address: 0xe5dec0 | Name: _ZN5boost15program_options19options_description3addERKS1_
boost::program_options::options_description *__fastcall boost::program_options::options_description::add(
        boost::program_options::options_description *this,
        const boost::program_options::options_description *desc)
{
  boost::program_options::options_description *v3; // rbx
  unsigned __int64 v4; // rdx
  boost::shared_ptr<boost::program_options::options_description>::element_type **v5; // rax
  boost::detail::sp_counted_base *pi; // rcx
  __int64 v7; // rax
  unsigned __int64 v8; // r13
  __int64 v9; // rbp
  boost::detail::sp_counted_base *v10; // rax
  boost::detail::sp_counted_base *v11; // rbx
  unsigned __int64 v12; // rdx
  __int64 v13; // rsi
  boost::detail::sp_counted_base *v14; // r14
  boost::shared_ptr<boost::program_options::options_description> __x; // [rsp+8h] [rbp-50h] BYREF
  boost::shared_ptr<boost::program_options::option_description> v17; // [rsp+18h] [rbp-40h] BYREF

  v3 = (boost::program_options::options_description *)operator new(0x68u);
  boost::program_options::options_description::options_description(v3, desc);
  boost::shared_ptr<boost::program_options::options_description>::shared_ptr<boost::program_options::options_description>(
    &__x,
    v3);
  v5 = (boost::shared_ptr<boost::program_options::options_description>::element_type **)*((_QWORD *)this + 11);
  if ( v5 == *((boost::shared_ptr<boost::program_options::options_description>::element_type ***)this + 12) )
  {
    std::vector<boost::shared_ptr<boost::program_options::options_description>>::__push_back_slow_path<boost::shared_ptr<boost::program_options::options_description> const&>(
      (boost::program_options::options_description *)((char *)this + 80),
      &__x);
  }
  else
  {
    *v5 = __x.px;
    pi = __x.pn.pi_;
    v5[1] = __x.pn.pi_;
    if ( pi )
    {
      _InterlockedAdd(&pi->use_count_, 1u);
      v5 = (boost::shared_ptr<boost::program_options::options_description>::element_type **)*((_QWORD *)this + 11);
    }
    *((_QWORD *)this + 11) = v5 + 2;
  }
  v7 = *((_QWORD *)desc + 4);
  if ( *((_QWORD *)desc + 5) != v7 )
  {
    v8 = 0;
    v9 = 8;
    do
    {
      v17.px = *(boost::shared_ptr<boost::program_options::option_description>::element_type **)(v7 + v9 - 8);
      v10 = *(boost::detail::sp_counted_base **)(v7 + v9);
      v17.pn.pi_ = v10;
      if ( v10 )
        _InterlockedAdd(&v10->use_count_, 1u);
      boost::program_options::options_description::add(
        this,
        (boost::shared_ptr<boost::program_options::option_description>)__PAIR128__(v4, &v17));
      v11 = v17.pn.pi_;
      if ( v17.pn.pi_ )
      {
        if ( !_InterlockedSub(&v17.pn.pi_->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 2))(v11);
          if ( !_InterlockedSub(&v11->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
        }
      }
      v12 = *((_QWORD *)this + 8) - 1LL;
      v13 = 1LL << v12;
      v4 = v12 >> 6;
      *(_QWORD *)(*((_QWORD *)this + 7) + 8 * v4) |= v13;
      ++v8;
      v7 = *((_QWORD *)desc + 4);
      v9 += 16;
    }
    while ( v8 < (*((_QWORD *)desc + 5) - v7) >> 4 );
  }
  v14 = __x.pn.pi_;
  if ( __x.pn.pi_ )
  {
    if ( !_InterlockedSub(&__x.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
      if ( !_InterlockedSub(&v14->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
    }
  }
  return this;
}


// Address: 0xe5e0e0 | Name: _ZN5boost15program_options19options_description11add_optionsEv
boost::program_options::options_description_easy_init __fastcall boost::program_options::options_description::add_options(
        boost::program_options::options_description *this)
{
  return (boost::program_options::options_description_easy_init)this;
}


// Address: 0xe5e0f0 | Name: _ZNK5boost15program_options19options_description4findERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEbbb
const boost::program_options::option_description *__fastcall boost::program_options::options_description::find(
        const boost::program_options::options_description *this,
        const std::string *name,
        bool approx,
        bool long_ignore_case,
        bool short_ignore_case)
{
  const boost::program_options::option_description *result; // rax
  __int128 v6; // [rsp+0h] [rbp-98h] BYREF
  void *v7; // [rsp+10h] [rbp-88h]
  _QWORD v8[3]; // [rsp+18h] [rbp-80h] BYREF

  result = boost::program_options::options_description::find_nothrow(
             this,
             name,
             approx,
             long_ignore_case,
             short_ignore_case);
  if ( !result )
  {
    v6 = 0;
    v7 = 0;
    boost::program_options::unknown_option::unknown_option(
      (boost::program_options::unknown_option *)v8,
      (const std::string *)&v6);
    boost::throw_exception<boost::program_options::unknown_option>((const boost::program_options::unknown_option *)v8);
  }
  return result;
}


// Address: 0xe5e1c0 | Name: _ZNK5boost15program_options19options_description12find_nothrowERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEbbb
// local variable allocation has failed, the output may be wrong!
const boost::program_options::option_description *__fastcall boost::program_options::options_description::find_nothrow(
        const boost::program_options::options_description *this,
        const std::string *name,
        bool approx,
        bool long_ignore_case,
        bool short_ignore_case)
{
  __int64 v5; // rax
  void **v6; // rax
  void **v7; // rbx
  _BYTE *v8; // rdx
  _BYTE *v9; // rcx
  volatile signed __int32 *v10; // r12
  const boost::program_options::option_description *v11; // r14
  unsigned int v12; // r14d
  unsigned __int64 v13; // r15
  __int64 v14; // r15
  boost::program_options::option_description::match_result v15; // ebp
  __int64 v16; // r13
  unsigned __int64 v17; // rax
  std::string *v18; // r13
  __int64 v19; // rax
  volatile signed __int32 *v20; // rbp
  __int64 v21; // rax
  __int64 v22; // rcx
  unsigned __int64 v23; // rdx
  unsigned __int64 v24; // rcx
  void **v25; // rbp
  void **v26; // rdi
  void **v27; // rbx
  void **v28; // rax
  void **v29; // rbp
  void *v30; // rdi
  void *ptr[2]; // [rsp+0h] [rbp-128h] BYREF
  void *v33; // [rsp+10h] [rbp-118h]
  void *v34[2]; // [rsp+20h] [rbp-108h] BYREF
  void *v35; // [rsp+30h] [rbp-F8h]
  const boost::program_options::option_description *v36; // [rsp+40h] [rbp-E8h]
  bool v37[4]; // [rsp+4Ch] [rbp-DCh]
  bool v38[4]; // [rsp+50h] [rbp-D8h]
  bool v39[4]; // [rsp+54h] [rbp-D4h]
  __int64 v40; // [rsp+58h] [rbp-D0h]
  std::string *option; // [rsp+60h] [rbp-C8h]
  _BYTE v42[192]; // [rsp+68h] [rbp-C0h] BYREF

  option = name;
  *(_OWORD *)ptr = 0;
  v33 = 0;
  *(_OWORD *)v34 = 0;
  v35 = 0;
  v5 = *((_QWORD *)this + 4);
  if ( *((_QWORD *)this + 5) == v5 )
  {
    v6 = 0;
    v7 = 0;
    v8 = 0;
    v9 = 0;
    v10 = 0;
    v11 = 0;
    goto LABEL_33;
  }
  v12 = 1;
  v13 = 0;
  *(_DWORD *)v39 = approx;
  *(_DWORD *)v38 = long_ignore_case;
  *(_DWORD *)v37 = short_ignore_case;
  v40 = 0;
  v36 = 0;
  v10 = 0;
  do
  {
    v14 = 16 * v13;
    name = option;
    v15 = boost::program_options::option_description::match(
            *(const boost::program_options::option_description **)(v5 + v14),
            option,
            v39[0],
            v38[0],
            v37[0]);
    if ( v15 == boost::program_options::option_description::match_result::no_match )
      goto LABEL_31;
    v16 = *(_QWORD *)(*((_QWORD *)this + 4) + v14);
    v17 = *(unsigned __int8 *)(v16 + 32);
    if ( (v17 & 1) != 0 )
    {
      if ( !*(_QWORD *)(v16 + 40) )
      {
LABEL_13:
        v18 = (std::string *)(v16 + 8);
        if ( v15 == boost::program_options::option_description::match_result::full_match )
          goto LABEL_10;
        goto LABEL_14;
      }
    }
    else if ( !(v17 >> 1) )
    {
      goto LABEL_13;
    }
    v18 = (std::string *)(v16 + 32);
    if ( std::string::find(v18, 42, 0) != -1 )
      v18 = option;
    if ( v15 == boost::program_options::option_description::match_result::full_match )
    {
LABEL_10:
      name = v18;
      if ( v34[1] == v35 )
      {
        std::vector<std::string>::__push_back_slow_path<std::string const&>((std::vector<std::string> *)v34, v18);
      }
      else
      {
        std::string::basic_string(v34[1], v18);
        v34[1] = (char *)v34[1] + 24;
      }
      v19 = *((_QWORD *)this + 4);
      v36 = *(const boost::program_options::option_description **)(v19 + v14);
      v20 = *(volatile signed __int32 **)(v19 + v14 + 8);
      if ( v20 )
        _InterlockedAdd(v20 + 2, 1u);
      LOBYTE(v19) = 1;
      v40 = v19;
      if ( v10 )
      {
        if ( !_InterlockedSub(v10 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
          if ( !_InterlockedSub(v10 + 3, 1u) )
            goto LABEL_23;
        }
      }
      goto LABEL_30;
    }
LABEL_14:
    if ( ptr[1] == v33 )
    {
      name = v18;
      std::vector<std::string>::__push_back_slow_path<std::string const&>((std::vector<std::string> *)ptr, v18);
      if ( (v40 & 1) != 0 )
        goto LABEL_31;
LABEL_25:
      v21 = *((_QWORD *)this + 4);
      v36 = *(const boost::program_options::option_description **)(v21 + v14);
      v20 = *(volatile signed __int32 **)(v21 + v14 + 8);
      if ( v20 )
        _InterlockedAdd(v20 + 2, 1u);
      if ( v10 )
      {
        if ( !_InterlockedSub(v10 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
          if ( !_InterlockedSub(v10 + 3, 1u) )
          {
LABEL_23:
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
            v10 = v20;
            goto LABEL_31;
          }
        }
      }
LABEL_30:
      v10 = v20;
      goto LABEL_31;
    }
    name = v18;
    std::string::basic_string(ptr[1], v18);
    ptr[1] = (char *)ptr[1] + 24;
    if ( (v40 & 1) == 0 )
      goto LABEL_25;
LABEL_31:
    v13 = v12;
    v5 = *((_QWORD *)this + 4);
    ++v12;
  }
  while ( (*((_QWORD *)this + 5) - v5) >> 4 > v13 );
  v7 = (void **)v34[0];
  v6 = (void **)v34[1];
  v8 = v34[0];
  v9 = v34[1];
  v11 = v36;
LABEL_33:
  v22 = (v9 - v8) >> 3;
  v23 = 0xAAAAAAAAAAAAAAABLL;
  v24 = 0xAAAAAAAAAAAAAAABLL * v22;
  if ( v24 > 1 )
  {
    boost::program_options::ambiguous_option::ambiguous_option(
      (boost::program_options::ambiguous_option *)v42,
      (const std::vector<std::string> *)v34);
    boost::throw_exception<boost::program_options::ambiguous_option>((const boost::program_options::ambiguous_option *)v42);
  }
  if ( v7 == v6 )
  {
    v24 = 0xAAAAAAAAAAAAAAABLL * (((char *)ptr[1] - (char *)ptr[0]) >> 3);
    if ( v24 >= 2 )
    {
      boost::program_options::ambiguous_option::ambiguous_option(
        (boost::program_options::ambiguous_option *)v42,
        (const std::vector<std::string> *)ptr);
      boost::throw_exception<boost::program_options::ambiguous_option>((const boost::program_options::ambiguous_option *)v42);
    }
  }
  if ( v7 )
  {
    if ( v6 == v7 )
    {
      v26 = v7;
    }
    else
    {
      do
      {
        v25 = v6 - 3;
        if ( (*(_BYTE *)(v6 - 3) & 1) != 0 )
          operator delete(*(v6 - 1));
        v6 = v25;
      }
      while ( v7 != v25 );
      v26 = (void **)v34[0];
    }
    v34[1] = v7;
    operator delete(v26);
  }
  v27 = (void **)ptr[0];
  if ( ptr[0] )
  {
    v28 = (void **)ptr[1];
    if ( ptr[1] == ptr[0] )
    {
      v30 = ptr[0];
    }
    else
    {
      do
      {
        v29 = v28 - 3;
        if ( (*(_BYTE *)(v28 - 3) & 1) != 0 )
          operator delete(*(v28 - 1));
        v28 = v29;
      }
      while ( v27 != v29 );
      v30 = ptr[0];
    }
    ptr[1] = v27;
    operator delete(v30);
  }
  if ( v10 )
  {
    if ( !_InterlockedSub(v10 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, const std::string *, unsigned __int64, unsigned __int64, bool))(*(_QWORD *)v10 + 16LL))(
        v10,
        name,
        v23,
        v24,
        short_ignore_case);
      if ( !_InterlockedSub(v10 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
    }
  }
  return v11;
}


// Address: 0xe5e650 | Name: _ZNK5boost15program_options19options_description7optionsEv
const std::vector<boost::shared_ptr<boost::program_options::option_description>> *__fastcall boost::program_options::options_description::options(
        const boost::program_options::options_description *this)
{
  return (const boost::program_options::options_description *)((char *)this + 32);
}


// Address: 0xe5e660 | Name: _ZN5boost15program_optionslsERNSt3__113basic_ostreamIcNS1_11char_traitsIcEEEERKNS0_19options_descriptionE
std::ostream *__fastcall boost::program_options::operator<<(
        std::ostream *os,
        const boost::program_options::options_description *desc)
{
  boost::program_options::options_description::print(desc, os, 0);
  return os;
}


// Address: 0xe5e680 | Name: _ZNK5boost15program_options19options_description5printERNSt3__113basic_ostreamIcNS2_11char_traitsIcEEEEj
void __fastcall boost::program_options::options_description::print(
        const boost::program_options::options_description *this,
        std::ostream *os,
        unsigned int width)
{
  unsigned int option_column_width; // ebp
  const boost::program_options::options_description *v5; // rbx
  unsigned __int64 v6; // rax
  const char *v7; // rsi
  size_t v8; // rdx
  unsigned __int64 v9; // rdx
  __int64 v10; // rax
  __int64 v11; // rax
  __int64 v12; // r13
  unsigned int v13; // r15d
  std::ostream *v14; // rax
  std::ostream *v15; // rbp
  const char *v16; // rsi
  size_t v17; // rdx
  std::ostream *v18; // rax
  std::ostream *v19; // rbp
  unsigned __int8 v20; // cl
  const char *v21; // rsi
  size_t v22; // rax
  size_t v23; // rdx
  const char *v24; // rsi
  size_t v25; // rdx
  unsigned __int64 v26; // rax
  unsigned int i; // ebp
  unsigned __int64 v28; // rbx
  int v29; // ebp
  int v30; // ebp
  int v31; // ebp
  unsigned __int8 v32; // cl
  __int64 v33; // rax
  unsigned __int64 v34; // rdx
  __int64 v35; // rax
  size_t v36; // rbp
  char *v37; // rax
  size_t v38; // rsi
  size_t v39; // rcx
  unsigned __int64 v40; // rsi
  size_t v41; // rdx
  __int64 k; // rdx
  __int64 v43; // rax
  __int64 v44; // rbp
  char *v45; // r13
  char *v46; // rax
  char *v47; // rbp
  char v48; // r12
  unsigned int v49; // r14d
  std::ostream *v50; // rbp
  char *v51; // rax
  char *v52; // r15
  __int64 v53; // rax
  __int64 v54; // rcx
  __int64 v55; // rax
  bool v56; // zf
  unsigned __int64 v57; // r15
  int v58; // ebp
  char v59; // al
  int v60; // ebx
  char *v61; // rsi
  char v62; // al
  unsigned int j; // ebx
  unsigned int v64; // r15d
  unsigned __int64 v65; // rbp
  std::ostream *v66; // rax
  __m128i *v67; // rax
  unsigned int v68; // [rsp+0h] [rbp-328h]
  char v69; // [rsp+7h] [rbp-321h]
  std::ostream *__os; // [rsp+8h] [rbp-320h]
  unsigned int v71; // [rsp+14h] [rbp-314h]
  unsigned __int8 v72; // [rsp+18h] [rbp-310h] BYREF
  _BYTE v73[7]; // [rsp+19h] [rbp-30Fh] BYREF
  size_t v74; // [rsp+20h] [rbp-308h]
  char *v75; // [rsp+28h] [rbp-300h]
  char v76[16]; // [rsp+30h] [rbp-2F8h] BYREF
  void *v77; // [rsp+40h] [rbp-2E8h]
  unsigned __int8 v78; // [rsp+48h] [rbp-2E0h] BYREF
  char __str[7]; // [rsp+49h] [rbp-2DFh] BYREF
  size_t v80; // [rsp+50h] [rbp-2D8h]
  void *v81; // [rsp+58h] [rbp-2D0h]
  char v82[16]; // [rsp+60h] [rbp-2C8h] BYREF
  void *v83; // [rsp+70h] [rbp-2B8h]
  __int64 v84; // [rsp+78h] [rbp-2B0h]
  char v85; // [rsp+80h] [rbp-2A8h]
  std::__wrap_iter<const char *> next; // [rsp+88h] [rbp-2A0h] BYREF
  std::__wrap_iter<const char *> end; // [rsp+90h] [rbp-298h]
  char v88; // [rsp+98h] [rbp-290h]
  _BYTE v89[16]; // [rsp+A0h] [rbp-288h] BYREF
  void *v90; // [rsp+B0h] [rbp-278h]
  size_t v91; // [rsp+B8h] [rbp-270h]
  int v92; // [rsp+C4h] [rbp-264h]
  unsigned __int64 v93; // [rsp+C8h] [rbp-260h]
  const boost::program_options::options_description *v94; // [rsp+D0h] [rbp-258h]
  __int64 v95; // [rsp+D8h] [rbp-250h]
  size_t __len[2]; // [rsp+E0h] [rbp-248h] BYREF
  void *ptr; // [rsp+F0h] [rbp-238h]
  char v98; // [rsp+F8h] [rbp-230h]
  void *v99; // [rsp+108h] [rbp-220h]
  const char *v100; // [rsp+120h] [rbp-208h]
  const char *v101; // [rsp+128h] [rbp-200h]
  char v102; // [rsp+130h] [rbp-1F8h]
  char v103; // [rsp+138h] [rbp-1F0h]
  void *v104; // [rsp+148h] [rbp-1E0h]
  unsigned __int64 v105; // [rsp+150h] [rbp-1D8h]
  char *v106; // [rsp+158h] [rbp-1D0h]
  _QWORD v107[2]; // [rsp+160h] [rbp-1C8h] BYREF
  _QWORD v108[2]; // [rsp+170h] [rbp-1B8h] BYREF
  char v109[16]; // [rsp+180h] [rbp-1A8h] BYREF
  void *v110; // [rsp+190h] [rbp-198h]
  char v111[16]; // [rsp+198h] [rbp-190h] BYREF
  void *v112; // [rsp+1A8h] [rbp-180h]
  __int64 v113; // [rsp+1B0h] [rbp-178h]
  char v114; // [rsp+1B8h] [rbp-170h]
  __m128i si128; // [rsp+1C0h] [rbp-168h] BYREF
  int *v116; // [rsp+1D0h] [rbp-158h] BYREF
  _QWORD v117[8]; // [rsp+1D8h] [rbp-150h] BYREF
  __int128 v118; // [rsp+218h] [rbp-110h]
  __int128 v119; // [rsp+228h] [rbp-100h]
  int v120; // [rsp+238h] [rbp-F0h]
  _QWORD v121[18]; // [rsp+240h] [rbp-E8h] BYREF
  int v122; // [rsp+2D0h] [rbp-58h]
  __m128i v123[4]; // [rsp+2E0h] [rbp-48h] BYREF

  option_column_width = width;
  v5 = this;
  v6 = *(unsigned __int8 *)this;
  if ( (v6 & 1) == 0 )
  {
    if ( v6 >> 1 )
      goto LABEL_3;
LABEL_6:
    if ( width )
      goto LABEL_7;
    goto LABEL_154;
  }
  if ( !*((_QWORD *)this + 1) )
    goto LABEL_6;
LABEL_3:
  if ( (v6 & 1) != 0 )
  {
    v7 = (const char *)*((_QWORD *)this + 2);
    v8 = *((_QWORD *)this + 1);
  }
  else
  {
    v7 = (char *)this + 1;
    v8 = (unsigned __int8)v6 >> 1;
  }
  v66 = std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)os, v7, v8);
  std::__put_character_sequence<char,std::char_traits<char>>(v66, ":\n", 2u);
  if ( !option_column_width )
LABEL_154:
    option_column_width = boost::program_options::options_description::get_option_column_width(this);
LABEL_7:
  v68 = option_column_width;
  if ( *((_QWORD *)this + 5) != *((_QWORD *)this + 4) )
  {
    v93 = option_column_width;
    v92 = -option_column_width;
    v123[0] = (__m128i)(unsigned __int64)&off_28752F8;
    v9 = 0;
    __os = (std::ostream *)os;
    v94 = this;
    while ( 1 )
    {
      v10 = *(_QWORD *)(*((_QWORD *)v5 + 7) + 8 * (v9 >> 6));
      if ( !_bittest64(&v10, v9) )
        break;
LABEL_147:
      v9 = (unsigned int)(v9 + 1);
      if ( (__int64)(*((_QWORD *)v5 + 5) - *((_QWORD *)v5 + 4)) >> 4 <= v9 )
        goto LABEL_148;
    }
    v11 = *((_QWORD *)v5 + 4);
    v105 = v9;
    v12 = *(_QWORD *)(v11 + 16 * v9);
    v13 = *((_DWORD *)v5 + 6);
    v116 = &off_28751D8;
    v121[0] = &off_2875320;
    si128 = _mm_load_si128(v123);
    std::ios_base::init((std::ios_base *)v121, v117);
    v121[17] = 0;
    v122 = -1;
    si128.m128i_i64[0] = (__int64)&off_28751B0;
    v121[0] = off_2875200;
    v116 = &off_28751D8;
    std::streambuf::basic_streambuf(v117);
    v117[0] = &off_28753A8;
    v119 = 0;
    v118 = 0;
    v120 = 24;
    v14 = std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v116, "  ", 2u);
    v5 = v94;
    v15 = v14;
    boost::program_options::option_description::format_name((boost::program_options::option_description *)&v78, v12);
    if ( (v78 & 1) != 0 )
    {
      v16 = (const char *)v81;
      v17 = v80;
    }
    else
    {
      v17 = (unsigned __int64)v78 >> 1;
      v16 = __str;
    }
    v18 = std::__put_character_sequence<char,std::char_traits<char>>(v15, v16, v17);
    LOBYTE(__len[0]) = 32;
    v19 = std::__put_character_sequence<char,std::char_traits<char>>(v18, (const char *)__len, 1u);
    if ( (*(unsigned int (__fastcall **)(_QWORD))(**(_QWORD **)(v12 + 80) + 16LL))(*(_QWORD *)(v12 + 80)) )
    {
      (***(void (__fastcall ****)(size_t *))(v12 + 80))(__len);
      v20 = __len[0];
      v21 = (const char *)ptr;
      v22 = __len[1];
    }
    else
    {
      *(_OWORD *)__len = 0;
      ptr = 0;
      v22 = 0;
      v21 = 0;
      v20 = 0;
    }
    v23 = v20 >> 1;
    if ( (v20 & 1) != 0 )
      v23 = v22;
    else
      v21 = (char *)__len + 1;
    std::__put_character_sequence<char,std::char_traits<char>>(v19, v21, v23);
    if ( (__len[0] & 1) != 0 )
      operator delete(ptr);
    if ( (v78 & 1) != 0 )
      operator delete(v81);
    std::stringbuf::str((__int64)&v78, (__int64)v117);
    if ( (v78 & 1) != 0 )
    {
      v24 = (const char *)v81;
      v25 = v80;
    }
    else
    {
      v25 = (unsigned __int64)v78 >> 1;
      v24 = __str;
    }
    std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)os, v24, v25);
    if ( (v78 & 1) != 0 )
      operator delete(v81);
    v26 = *(unsigned __int8 *)(v12 + 56);
    if ( (v26 & 1) != 0 )
    {
      if ( !*(_QWORD *)(v12 + 64) )
        goto LABEL_144;
    }
    else if ( !(v26 >> 1) )
    {
      goto LABEL_144;
    }
    std::stringbuf::str((__int64)&v78, (__int64)v117);
    if ( (v78 & 1) != 0 )
    {
      v28 = v80;
      operator delete(v81);
      if ( v28 >= v93 )
      {
LABEL_40:
        std::ostream::put(os, 10);
        for ( i = v68; i; --i )
          std::ostream::put(os, 32);
LABEL_50:
        v31 = 0;
        boost::char_separator<char,std::char_traits<char>>::char_separator(
          (boost::char_separator<char,std::char_traits<char> > *)&v78,
          "\n",
          (const char *)&uri_string,
          boost::empty_token_policy::keep_empty_tokens);
        v32 = *(_BYTE *)(v12 + 56);
        v33 = v12 + 57;
        v34 = (unsigned __int64)v32 >> 1;
        if ( (v32 & 1) != 0 )
          v33 = *(_QWORD *)(v12 + 72);
        v108[0] = v33;
        if ( (v32 & 1) != 0 )
          v34 = *(_QWORD *)(v12 + 64);
        v108[1] = v33 + v34;
        std::string::basic_string(v109, &v78);
        std::string::basic_string(v111, v82);
        v114 = v85;
        v113 = v84;
        if ( (v82[0] & 1) != 0 )
          operator delete(v83);
        if ( (v78 & 1) != 0 )
          operator delete(v81);
        boost::tokenizer<boost::char_separator<char,std::char_traits<char>>,std::__wrap_iter<char const*>,std::string>::begin((const boost::tokenizer<boost::char_separator<char,std::char_traits<char> >,std::__wrap_iter<const char *>,std::string > *)v108);
        boost::tokenizer<boost::char_separator<char,std::char_traits<char>>,std::__wrap_iter<char const*>,std::string>::end((const boost::tokenizer<boost::char_separator<char,std::char_traits<char> >,std::__wrap_iter<const char *>,std::string > *)v108);
        LOBYTE(v31) = v13 > 1;
        v91 = v13 - v68 - v31;
        while ( 1 )
        {
          if ( v102 && v88 )
          {
            if ( v100 == next.__i && v101 == end.__i )
            {
LABEL_133:
              if ( (v103 & 1) != 0 )
                operator delete(v104);
              if ( (v98 & 1) != 0 )
                operator delete(v99);
              v5 = v94;
              if ( (__len[0] & 1) != 0 )
              {
                operator delete(ptr);
                if ( (v89[0] & 1) == 0 )
                  goto LABEL_139;
              }
              else if ( (v89[0] & 1) == 0 )
              {
LABEL_139:
                if ( (v82[0] & 1) == 0 )
                {
LABEL_140:
                  if ( (v78 & 1) == 0 )
                  {
LABEL_141:
                    if ( (v111[0] & 1) == 0 )
                    {
LABEL_142:
                      if ( (v109[0] & 1) != 0 )
LABEL_143:
                        operator delete(v110);
LABEL_144:
                      si128.m128i_i64[0] = (__int64)&off_28751B0;
                      v121[0] = off_2875200;
                      v116 = &off_28751D8;
                      v117[0] = &off_28753A8;
                      if ( (v118 & 1) != 0 )
                        operator delete((void *)v119);
                      std::streambuf::~streambuf(v117);
                      std::iostream::~iostream(&si128, off_2875218);
                      std::ios::~ios(v121);
                      std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)os, "\n", 1u);
                      LODWORD(v9) = v105;
                      goto LABEL_147;
                    }
LABEL_13:
                    operator delete(v112);
                    if ( (v109[0] & 1) == 0 )
                      goto LABEL_144;
                    goto LABEL_143;
                  }
LABEL_12:
                  operator delete(v81);
                  if ( (v111[0] & 1) == 0 )
                    goto LABEL_142;
                  goto LABEL_13;
                }
LABEL_11:
                operator delete(v83);
                if ( (v78 & 1) == 0 )
                  goto LABEL_141;
                goto LABEL_12;
              }
              operator delete(v90);
              if ( (v82[0] & 1) == 0 )
                goto LABEL_140;
              goto LABEL_11;
            }
          }
          else if ( v102 == v88 )
          {
            goto LABEL_133;
          }
          std::string::basic_string(&v72, v89);
          v95 = 0;
          v35 = std::string::find(&v72, 9, 0);
          if ( v35 != -1 )
            break;
LABEL_76:
          if ( (v72 & 1) != 0 )
          {
            v44 = v74;
            if ( v74 >= v91 )
              goto LABEL_78;
          }
          else
          {
            v44 = (unsigned __int64)v72 >> 1;
            if ( v44 >= v91 )
            {
LABEL_78:
              v45 = v75;
              v46 = v75;
              if ( (v72 & 1) == 0 )
                v46 = v73;
              if ( v44 > 0 )
              {
                v47 = &v46[v44];
                if ( (v72 & 1) == 0 )
                  v45 = v73;
                v48 = 1;
                v71 = v68;
                v49 = v91;
                v106 = v47;
                while ( 1 )
                {
                  if ( (v48 & 1) == 0 && *v46 == 32 )
                  {
                    v51 = v46 + 1;
                    if ( v51 < v47 && *v51 != 32 )
                      v45 = v51;
                  }
                  v52 = v45;
                  v53 = (unsigned int)((_DWORD)v47 - (_DWORD)v45);
                  if ( v49 <= (unsigned int)v53 )
                    v53 = v49;
                  v45 += v53;
                  v69 = v48;
                  if ( v52[v53 - 1] != 32 && v45 < v47 )
                    break;
                  v50 = __os;
                  if ( v52 != v45 )
                    goto LABEL_102;
LABEL_103:
                  v57 = (unsigned __int64)v106;
                  v58 = 0;
                  v59 = 0;
                  if ( (v48 & 1) == 0 )
                    v59 = v48;
                  v48 = v59;
                  if ( (v69 & 1) != 0 )
                    v58 = v95;
                  v71 += v58;
                  if ( v106 != v45 )
                  {
                    v76[0] = 10;
                    std::__put_character_sequence<char,std::char_traits<char>>(__os, v76, 1u);
                    if ( v71 )
                    {
                      v60 = -v71;
                      do
                      {
                        std::ostream::put(__os, 32);
                        ++v60;
                      }
                      while ( v60 );
                    }
                  }
                  v49 -= v58;
                  v46 = v45;
                  v47 = (char *)v57;
                  if ( v57 <= (unsigned __int64)v45 )
                    goto LABEL_117;
                }
                v50 = __os;
                if ( *v45 != 32 )
                {
                  v54 = (__int64)&v52[v53 + 1];
                  v55 = -v53;
                  while ( v55 )
                  {
                    ++v55;
                    v56 = *(_BYTE *)(v54 - 2) == 32;
                    --v54;
                    if ( v56 )
                    {
                      if ( v49 >> 1 > (int)v45 - (int)v54 )
                        v45 = (char *)v54;
                      break;
                    }
                  }
                }
                if ( v52 == v45 )
                  goto LABEL_103;
                do
                {
LABEL_102:
                  v76[0] = *v52;
                  std::__put_character_sequence<char,std::char_traits<char>>(v50, v76, 1u);
                  ++v52;
                }
                while ( v45 != v52 );
                goto LABEL_103;
              }
              goto LABEL_117;
            }
          }
          v61 = v73;
          if ( (v72 & 1) != 0 )
            v61 = v75;
          std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)os, v61, v44);
LABEL_117:
          if ( (v72 & 1) != 0 )
            operator delete(v75);
          v62 = boost::char_separator<char,std::char_traits<char>>::operator()<std::__wrap_iter<char const*>,std::string>(
                  (boost::char_separator<char,std::char_traits<char> > *)&v78,
                  &next,
                  end,
                  (std::string *)v89);
          os = __os;
          v88 = v62;
          if ( !v102 || v62 != 1 )
          {
            if ( v102 != v62 )
            {
LABEL_125:
              v76[0] = 10;
              std::__put_character_sequence<char,std::char_traits<char>>(__os, v76, 1u);
              for ( j = v68; j; --j )
                std::ostream::put(__os, 32);
            }
          }
          else if ( v100 != next.__i || v101 != end.__i )
          {
            goto LABEL_125;
          }
        }
        v36 = v35;
        if ( (v72 & 1) != 0 )
        {
          v37 = v75;
          v38 = v74;
          if ( !v74 )
            goto LABEL_73;
        }
        else
        {
          v38 = (unsigned __int64)v72 >> 1;
          v37 = v73;
          if ( !v38 )
          {
LABEL_73:
            std::string::erase(&v72, v36, 1);
            v43 = 0;
            if ( v36 < v91 )
              v43 = (unsigned int)v36;
            v95 = v43;
            os = __os;
            goto LABEL_76;
          }
        }
        v39 = v38 & 7;
        if ( v38 - 1 >= 7 )
        {
          v41 = v39 - v38;
          v40 = 0;
          do
          {
            v40 += (*v37 == 9)
                 + (unsigned __int64)(v37[1] == 9)
                 + (v37[2] == 9)
                 + (v37[3] == 9)
                 + (v37[4] == 9)
                 + (v37[5] == 9)
                 + (v37[6] == 9)
                 + (v37[7] == 9);
            v37 += 8;
            v41 += 8LL;
          }
          while ( v41 );
          if ( !v39 )
          {
LABEL_72:
            if ( v40 >= 2 )
            {
              v67 = (__m128i *)operator new(0x50u);
              v77 = v67;
              *(_OWORD *)v76 = xmmword_3E8C40;
              strcpy(v67[1].m128i_i8, " paragraph is allowed in the options description");
              *v67 = _mm_loadu_si128((const __m128i *)&xmmword_46C412);
              std::logic_error::logic_error(v107, v76);
              v107[0] = off_287CEF8;
              boost::throw_exception<boost::program_options::error>((const boost::program_options::error *)v107);
            }
            goto LABEL_73;
          }
        }
        else
        {
          v40 = 0;
          if ( !v39 )
            goto LABEL_72;
        }
        for ( k = 0; k != v39; ++k )
          v40 += v37[k] == 9;
        goto LABEL_72;
      }
    }
    else if ( (unsigned __int64)v78 >> 1 >= v93 )
    {
      goto LABEL_40;
    }
    std::stringbuf::str((__int64)&v78, (__int64)v117);
    if ( (v78 & 1) != 0 )
    {
      v29 = v80;
      operator delete(v81);
    }
    else
    {
      v29 = v78 >> 1;
    }
    if ( v68 != v29 )
    {
      v30 = v92 + v29;
      do
      {
        std::ostream::put(os, 32);
        ++v30;
      }
      while ( v30 );
    }
    goto LABEL_50;
  }
LABEL_148:
  if ( *((_QWORD *)v5 + 11) != *((_QWORD *)v5 + 10) )
  {
    v64 = 1;
    v65 = 0;
    do
    {
      std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)os, "\n", 1u);
      boost::program_options::options_description::print(
        *(const boost::program_options::options_description **)(*((_QWORD *)v5 + 10) + 16 * v65),
        os,
        v68);
      v65 = v64++;
    }
    while ( (__int64)(*((_QWORD *)v5 + 11) - *((_QWORD *)v5 + 10)) >> 4 > v65 );
  }
}


// Address: 0xe5f610 | Name: _ZNK5boost15program_options19options_description23get_option_column_widthEv
unsigned int __fastcall boost::program_options::options_description::get_option_column_width(
        const boost::program_options::options_description *this)
{
  const boost::program_options::options_description *v1; // r12
  __int64 v2; // rax
  unsigned int v3; // r14d
  int v4; // esi
  __int64 v5; // rcx
  __int64 v6; // r13
  std::ostream *v7; // rbp
  const char *p_str; // rsi
  size_t v9; // rdx
  std::ostream *v10; // rax
  std::ostream *v11; // r12
  unsigned __int8 v12; // cl
  const char *v13; // rsi
  size_t v14; // rax
  size_t v15; // rdx
  __int64 v16; // rax
  unsigned int v17; // ebp
  unsigned __int64 v18; // rcx
  unsigned int option_column_width; // eax
  unsigned int v20; // eax
  size_t __len[2]; // [rsp+0h] [rbp-198h] BYREF
  void *ptr; // [rsp+10h] [rbp-188h]
  unsigned __int8 v24; // [rsp+18h] [rbp-180h] BYREF
  char __str; // [rsp+19h] [rbp-17Fh] BYREF
  size_t v26; // [rsp+20h] [rbp-178h]
  void *v27; // [rsp+28h] [rbp-170h]
  unsigned int v28; // [rsp+34h] [rbp-164h]
  const boost::program_options::options_description *v29; // [rsp+38h] [rbp-160h]
  __m128i v30; // [rsp+40h] [rbp-158h] BYREF
  __m128i v31; // [rsp+50h] [rbp-148h] BYREF
  int *v32; // [rsp+60h] [rbp-138h] BYREF
  _QWORD v33[8]; // [rsp+68h] [rbp-130h] BYREF
  __int128 v34; // [rsp+A8h] [rbp-F0h]
  __int128 v35; // [rsp+B8h] [rbp-E0h]
  int v36; // [rsp+C8h] [rbp-D0h]
  _QWORD v37[18]; // [rsp+D0h] [rbp-C8h] BYREF
  int v38; // [rsp+160h] [rbp-38h]

  v1 = this;
  v2 = *((_QWORD *)this + 4);
  v3 = 23;
  if ( *((_QWORD *)this + 5) != v2 )
  {
    v3 = 23;
    v4 = 1;
    v5 = 0;
    v30 = (__m128i)(unsigned __int64)&off_28752F8;
    v29 = this;
    do
    {
      v28 = v4;
      v6 = *(_QWORD *)(v2 + 16 * v5);
      v32 = &off_28751D8;
      v37[0] = &off_2875320;
      v31 = _mm_load_si128(&v30);
      std::ios_base::init((std::ios_base *)v37, v33);
      v37[17] = 0;
      v38 = -1;
      v31.m128i_i64[0] = (__int64)&off_28751B0;
      v37[0] = off_2875200;
      v32 = &off_28751D8;
      std::streambuf::basic_streambuf(v33);
      v33[0] = &off_28753A8;
      v35 = 0;
      v34 = 0;
      v36 = 24;
      v7 = std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v32, "  ", 2u);
      boost::program_options::option_description::format_name((boost::program_options::option_description *)&v24, v6);
      if ( (v24 & 1) != 0 )
      {
        p_str = (const char *)v27;
        v9 = v26;
      }
      else
      {
        v9 = (unsigned __int64)v24 >> 1;
        p_str = &__str;
      }
      v10 = std::__put_character_sequence<char,std::char_traits<char>>(v7, p_str, v9);
      LOBYTE(__len[0]) = 32;
      v11 = std::__put_character_sequence<char,std::char_traits<char>>(v10, (const char *)__len, 1u);
      if ( (*(unsigned int (__fastcall **)(_QWORD))(**(_QWORD **)(v6 + 80) + 16LL))(*(_QWORD *)(v6 + 80)) )
      {
        (***(void (__fastcall ****)(size_t *))(v6 + 80))(__len);
        v12 = __len[0];
        v13 = (const char *)ptr;
        v14 = __len[1];
      }
      else
      {
        *(_OWORD *)__len = 0;
        ptr = 0;
        v14 = 0;
        v13 = 0;
        v12 = 0;
      }
      v15 = v12 >> 1;
      if ( (v12 & 1) != 0 )
        v15 = v14;
      else
        v13 = (char *)__len + 1;
      std::__put_character_sequence<char,std::char_traits<char>>(v11, v13, v15);
      v1 = v29;
      if ( (__len[0] & 1) != 0 )
        operator delete(ptr);
      if ( (v24 & 1) != 0 )
        operator delete(v27);
      std::stringbuf::str((__int64)&v24, (__int64)v33);
      if ( (v24 & 1) != 0 )
      {
        if ( v3 < (unsigned int)v26 )
          v3 = v26;
        operator delete(v27);
      }
      else if ( v3 < v24 >> 1 )
      {
        v3 = v24 >> 1;
      }
      v31.m128i_i64[0] = (__int64)&off_28751B0;
      v37[0] = off_2875200;
      v32 = &off_28751D8;
      v33[0] = &off_28753A8;
      if ( (v34 & 1) != 0 )
        operator delete((void *)v35);
      std::streambuf::~streambuf(v33);
      std::iostream::~iostream(&v31, off_2875218);
      std::ios::~ios(v37);
      v5 = v28;
      v2 = *((_QWORD *)v1 + 4);
      v4 = v28 + 1;
    }
    while ( (*((_QWORD *)v1 + 5) - v2) >> 4 > (unsigned __int64)v28 );
  }
  v16 = *((_QWORD *)v1 + 10);
  if ( *((_QWORD *)v1 + 11) != v16 )
  {
    v17 = 1;
    v18 = 0;
    do
    {
      option_column_width = boost::program_options::options_description::get_option_column_width(*(const boost::program_options::options_description **)(v16 + 16 * v18));
      if ( v3 < option_column_width )
        v3 = option_column_width;
      v18 = v17;
      v16 = *((_QWORD *)v1 + 10);
      ++v17;
    }
    while ( (*((_QWORD *)v1 + 11) - v16) >> 4 > v18 );
  }
  v20 = *((_DWORD *)v1 + 6) + ~*((_DWORD *)v1 + 7);
  if ( v20 >= v3 )
    v20 = v3;
  return v20 + 1;
}


