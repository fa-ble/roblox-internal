// Address: 0x2605a60 | Name: _ZNK5boost4asio6detail11timer_queueINS0_11time_traitsINS_10posix_time5ptimeEEEE5emptyEv
bool __fastcall boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime>>::empty(
        const boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *this)
{
  return *((_QWORD *)this + 4) == 0;
}


// Address: 0x2605dc0 | Name: _ZN5boost4asio6detail11timer_queueINS0_11time_traitsINS_10posix_time5ptimeEEEE14get_all_timersERNS1_8op_queueINS1_25task_io_service_operationEEE
void __fastcall boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime>>::get_all_timers(
        boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *ops)
{
  __int64 v2; // rax
  __int64 v3; // rdx
  _QWORD *p_next; // rdx

  v2 = *((_QWORD *)this + 4);
  if ( v2 )
  {
    do
    {
      v3 = *(_QWORD *)(v2 + 24);
      *((_QWORD *)this + 4) = v3;
      if ( *(_QWORD *)v2 )
      {
        p_next = &ops->back_->next_;
        if ( !p_next )
          p_next = &ops->front_;
        *p_next = *(_QWORD *)v2;
        ops->back_ = *(boost::asio::detail::task_io_service_operation **)(v2 + 8);
        *(_OWORD *)v2 = 0;
        v3 = *((_QWORD *)this + 4);
      }
      *(_OWORD *)(v2 + 24) = 0;
      v2 = v3;
    }
    while ( v3 );
  }
  *((_QWORD *)this + 6) = *((_QWORD *)this + 5);
}


// Address: 0x2605e20 | Name: _ZN5boost4asio6detail11timer_queueINS1_28forwarding_posix_time_traitsEED2Ev
void __fastcall boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::~timer_queue(
        boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *this)
{
  void *v1; // rax

  *(_QWORD *)this = &off_29C3218;
  v1 = (void *)*((_QWORD *)this + 3);
  if ( v1 )
  {
    *((_QWORD *)this + 4) = v1;
    operator delete(v1);
  }
}


// Address: 0x2605e40 | Name: _ZN5boost4asio6detail11timer_queueINS1_28forwarding_posix_time_traitsEED0Ev
void __fastcall boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::~timer_queue(
        boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *this)
{
  void *v2; // rdi

  *(_QWORD *)this = &off_29C3218;
  v2 = (void *)*((_QWORD *)this + 3);
  if ( v2 )
  {
    *((_QWORD *)this + 4) = v2;
    operator delete(v2);
  }
  operator delete(this);
}


// Address: 0x2605e70 | Name: _ZNK5boost4asio6detail11timer_queueINS1_28forwarding_posix_time_traitsEE5emptyEv
bool __fastcall boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::empty(
        const boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *this)
{
  return *((_QWORD *)this + 2) == 0;
}


// Address: 0x2605e80 | Name: _ZNK5boost4asio6detail11timer_queueINS1_28forwarding_posix_time_traitsEE18wait_duration_msecEl
__int64 __fastcall boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::wait_duration_msec(
        const boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *this,
        __int64 max_duration)
{
  __int64 v2; // r14
  const boost::asio::time_traits<boost::posix_time::ptime>::time_type *v3; // rbx
  __int64 v4; // rdx
  boost::asio::time_traits<boost::posix_time::ptime>::time_type t2; // [rsp+8h] [rbp-20h] BYREF
  unsigned __int64 v7; // [rsp+10h] [rbp-18h]

  v2 = max_duration;
  v3 = (const boost::asio::time_traits<boost::posix_time::ptime>::time_type *)*((_QWORD *)this + 3);
  if ( v3 != *((const boost::asio::time_traits<boost::posix_time::ptime>::time_type **)this + 4) )
  {
    t2.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
    boost::asio::time_traits<boost::posix_time::ptime>::subtract(v3, &t2);
    if ( (__int64)v7 <= 0 )
    {
      return 0;
    }
    else
    {
      v4 = v7 / 0x3E8;
      if ( (__int64)(v7 / 0x3E8) > max_duration )
        v4 = max_duration;
      v2 = 1;
      if ( v7 >= 0x3E8 )
        return v4;
    }
  }
  return v2;
}


// Address: 0x2605f10 | Name: _ZNK5boost4asio6detail11timer_queueINS1_28forwarding_posix_time_traitsEE18wait_duration_usecEl
__int64 __fastcall boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::wait_duration_usec(
        const boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *this,
        __int64 max_duration)
{
  __int64 v2; // rbx
  const boost::asio::time_traits<boost::posix_time::ptime>::time_type *v3; // r14
  boost::asio::time_traits<boost::posix_time::ptime>::time_type t2; // [rsp+8h] [rbp-20h] BYREF
  __int64 v6; // [rsp+10h] [rbp-18h]

  v2 = max_duration;
  v3 = (const boost::asio::time_traits<boost::posix_time::ptime>::time_type *)*((_QWORD *)this + 3);
  if ( v3 != *((const boost::asio::time_traits<boost::posix_time::ptime>::time_type **)this + 4) )
  {
    t2.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
    boost::asio::time_traits<boost::posix_time::ptime>::subtract(v3, &t2);
    if ( v6 <= max_duration )
      v2 = v6;
    if ( v6 <= 0 )
      return 0;
  }
  return v2;
}


// Address: 0x2605f70 | Name: _ZN5boost4asio6detail11timer_queueINS1_28forwarding_posix_time_traitsEE16get_ready_timersERNS1_8op_queueINS1_25task_io_service_operationEEE
void __fastcall boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::get_ready_timers(
        boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *this,
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *ops)
{
  boost::posix_time::ptime v3; // r15
  boost::date_time::int_adapter<long>::int_type *v4; // rax
  boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::per_timer_data *v5; // rsi
  _QWORD *p_next; // rcx

  if ( *((_QWORD *)this + 3) != *((_QWORD *)this + 4) )
  {
    v3.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
    while ( 1 )
    {
      v4 = (boost::date_time::int_adapter<long>::int_type *)*((_QWORD *)this + 3);
      if ( v4 == *((boost::date_time::int_adapter<long>::int_type **)this + 4) || v3.time_.time_count_.value_ < *v4 )
        break;
      v5 = (boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::per_timer_data *)v4[1];
      if ( v5->op_queue_.front_ )
      {
        p_next = &ops->back_->next_;
        if ( !p_next )
          p_next = &ops->front_;
        *p_next = v5->op_queue_.front_;
        ops->back_ = v5->op_queue_.back_;
        v5->op_queue_ = 0;
      }
      boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::remove_timer(this, v5);
    }
  }
}


// Address: 0x2605ff0 | Name: _ZN5boost4asio6detail11timer_queueINS1_28forwarding_posix_time_traitsEE14get_all_timersERNS1_8op_queueINS1_25task_io_service_operationEEE
void __fastcall boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::get_all_timers(
        boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *this,
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *ops)
{
  __int64 v2; // rax
  __int64 v3; // rdx
  _QWORD *p_next; // rdx

  v2 = *((_QWORD *)this + 2);
  if ( v2 )
  {
    do
    {
      v3 = *(_QWORD *)(v2 + 24);
      *((_QWORD *)this + 2) = v3;
      if ( *(_QWORD *)v2 )
      {
        p_next = &ops->back_->next_;
        if ( !p_next )
          p_next = &ops->front_;
        *p_next = *(_QWORD *)v2;
        ops->back_ = *(boost::asio::detail::task_io_service_operation **)(v2 + 8);
        *(_OWORD *)v2 = 0;
        v3 = *((_QWORD *)this + 2);
      }
      *(_OWORD *)(v2 + 24) = 0;
      v2 = v3;
    }
    while ( v3 );
  }
  *((_QWORD *)this + 4) = *((_QWORD *)this + 3);
}


// Address: 0x2608260 | Name: _ZN5boost4asio6detail11timer_queueINS1_28forwarding_posix_time_traitsEE13enqueue_timerERKNS_10posix_time5ptimeERNS4_14per_timer_dataEPNS1_7wait_opE
bool __fastcall boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::enqueue_timer(
        boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *this,
        const boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::time_type *time,
        boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::per_timer_data *timer,
        boost::asio::detail::wait_op *op)
{
  boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::heap_entry *v6; // rax
  __int64 v7; // rax
  __int64 v8; // rcx
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rdx
  boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::per_timer_data *v11; // rax
  boost::asio::detail::wait_op *back; // rax
  boost::asio::detail::wait_op *front; // rax
  boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::heap_entry v15; // [rsp+0h] [rbp-48h] BYREF
  __int128 v16; // [rsp+10h] [rbp-38h]

  if ( !timer->prev_
    && *((boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::per_timer_data **)this + 2) != timer )
  {
    v6 = (boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::heap_entry *)*((_QWORD *)this + 4);
    timer->heap_index_ = ((__int64)v6 - *((_QWORD *)this + 3)) >> 4;
    v15.time_ = (boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::time_type)time->time_.time_count_.value_;
    v15.timer_ = timer;
    if ( *((boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::heap_entry **)this + 5) == v6 )
    {
      std::vector<boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::heap_entry,std::allocator<boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::heap_entry>>::__push_back_slow_path<boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::heap_entry const&>(
        (boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits> *)((char *)this + 24),
        &v15);
      v7 = *((_QWORD *)this + 4);
    }
    else
    {
      *v6 = v15;
      v7 = *((_QWORD *)this + 4) + 16LL;
      *((_QWORD *)this + 4) = v7;
    }
    v8 = *((_QWORD *)this + 3);
    v9 = ((v7 - v8) >> 4) - 1;
    if ( v9 )
    {
      do
      {
        v10 = (v9 - 1) >> 1;
        if ( *(_QWORD *)(v8 + 16 * v9) >= *(_QWORD *)(v8 + 16 * v10) )
          break;
        v16 = *(_OWORD *)(v8 + 16 * v9);
        *(_OWORD *)(v8 + 16 * v9) = *(_OWORD *)(v8 + 16 * v10);
        *(_OWORD *)(*((_QWORD *)this + 3) + 16 * v10) = v16;
        v8 = *((_QWORD *)this + 3);
        *(_QWORD *)(*(_QWORD *)(v8 + 16 * v9 + 8) + 16LL) = v9;
        *(_QWORD *)(*(_QWORD *)(v8 + 16 * v10 + 8) + 16LL) = v10;
        v9 = (v9 - 1) >> 1;
      }
      while ( v10 );
    }
    v11 = (boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::per_timer_data *)*((_QWORD *)this + 2);
    timer->next_ = v11;
    timer->prev_ = 0;
    if ( v11 )
      v11->prev_ = timer;
    *((_QWORD *)this + 2) = timer;
  }
  op->next_ = 0;
  back = timer->op_queue_.back_;
  if ( back )
  {
    back->next_ = op;
    timer->op_queue_.back_ = op;
    front = timer->op_queue_.front_;
  }
  else
  {
    timer->op_queue_.back_ = op;
    timer->op_queue_.front_ = op;
    front = op;
  }
  return (timer->heap_index_ | (unsigned __int64)op ^ (unsigned __int64)front) == 0;
}


// Address: 0x2697310 | Name: _ZN5boost4asio6detail11timer_queueINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEED2Ev
void __fastcall boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::~timer_queue(
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this)
{
  void *v1; // rax

  *(_QWORD *)this = &off_29C7118;
  v1 = (void *)*((_QWORD *)this + 3);
  if ( v1 )
  {
    *((_QWORD *)this + 4) = v1;
    operator delete(v1);
  }
}


// Address: 0x2697330 | Name: _ZN5boost4asio6detail11timer_queueINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEED0Ev
void __fastcall boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::~timer_queue(
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this)
{
  void *v2; // rdi

  *(_QWORD *)this = &off_29C7118;
  v2 = (void *)*((_QWORD *)this + 3);
  if ( v2 )
  {
    *((_QWORD *)this + 4) = v2;
    operator delete(v2);
  }
  operator delete(this);
}


// Address: 0x2697360 | Name: _ZNK5boost4asio6detail11timer_queueINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE5emptyEv
bool __fastcall boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::empty(
        const boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this)
{
  return *((_QWORD *)this + 2) == 0;
}


// Address: 0x2697370 | Name: _ZNK5boost4asio6detail11timer_queueINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE18wait_duration_msecEl
__int64 __fastcall boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::wait_duration_msec(
        const boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        __int64 max_duration)
{
  __int64 v2; // r14
  __int64 *v3; // rbx
  __int64 v4; // rax
  __int64 v5; // rcx
  unsigned __int64 v6; // rcx
  __int64 result; // rax

  v2 = max_duration;
  v3 = (__int64 *)*((_QWORD *)this + 3);
  if ( v3 == *((__int64 **)this + 4) )
    return v2;
  v4 = std::chrono::steady_clock::now((std::chrono::steady_clock *)this);
  v5 = *v3;
  if ( *v3 < 0 )
  {
    if ( v4 >= 0 && (v5 == 0x8000000000000000LL || 0x7FFFFFFFFFFFFFFFLL - v4 < -v5) )
      return 0;
  }
  else if ( v4 < 0 && (v4 == 0x8000000000000000LL || 0x7FFFFFFFFFFFFFFFLL - v5 < -v4) )
  {
    if ( max_duration > 0x8637BD05AF6LL )
      return 0x8637BD05AF6LL;
    return v2;
  }
  v6 = v5 - v4;
  if ( (__int64)v6 <= 0 )
    return 0;
  if ( (__int64)(v6 / 0xF4240) <= max_duration )
    v2 = v6 / 0xF4240;
  result = 1;
  if ( v6 >= 0xF4240 )
    return v2;
  return result;
}


// Address: 0x2697440 | Name: _ZNK5boost4asio6detail11timer_queueINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE18wait_duration_usecEl
__int64 __fastcall boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::wait_duration_usec(
        const boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        __int64 max_duration)
{
  __int64 v2; // r14
  __int64 *v3; // rbx
  __int64 v4; // rax
  __int64 v5; // rcx
  unsigned __int64 v6; // rcx
  __int64 result; // rax

  v2 = max_duration;
  v3 = (__int64 *)*((_QWORD *)this + 3);
  if ( v3 == *((__int64 **)this + 4) )
    return v2;
  v4 = std::chrono::steady_clock::now((std::chrono::steady_clock *)this);
  v5 = *v3;
  if ( *v3 < 0 )
  {
    if ( v4 >= 0 && (v5 == 0x8000000000000000LL || 0x7FFFFFFFFFFFFFFFLL - v4 < -v5) )
      return 0;
  }
  else if ( v4 < 0 && (v4 == 0x8000000000000000LL || 0x7FFFFFFFFFFFFFFFLL - v5 < -v4) )
  {
    if ( max_duration > 0x20C49BA5E353F7LL )
      return 0x20C49BA5E353F7LL;
    return v2;
  }
  v6 = v5 - v4;
  if ( (__int64)v6 <= 0 )
    return 0;
  if ( (__int64)(v6 / 0x3E8) <= max_duration )
    v2 = v6 / 0x3E8;
  result = 1;
  if ( v6 >= 0x3E8 )
    return v2;
  return result;
}


// Address: 0x2697510 | Name: _ZN5boost4asio6detail11timer_queueINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE16get_ready_timersERNS1_8op_queueINS1_25task_io_service_operationEEE
void __fastcall boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::get_ready_timers(
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *ops)
{
  __int64 v3; // r15
  _QWORD *v4; // rax
  boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data *v5; // rsi
  _QWORD *p_next; // rcx

  if ( *((_QWORD *)this + 3) != *((_QWORD *)this + 4) )
  {
    v3 = std::chrono::steady_clock::now((std::chrono::steady_clock *)this);
    while ( 1 )
    {
      v4 = (_QWORD *)*((_QWORD *)this + 3);
      if ( v4 == *((_QWORD **)this + 4) || v3 < *v4 )
        break;
      v5 = (boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data *)v4[1];
      if ( v5->op_queue_.front_ )
      {
        p_next = &ops->back_->next_;
        if ( !p_next )
          p_next = &ops->front_;
        *p_next = v5->op_queue_.front_;
        ops->back_ = v5->op_queue_.back_;
        v5->op_queue_ = 0;
      }
      boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::remove_timer(
        this,
        v5);
    }
  }
}


// Address: 0x2697580 | Name: _ZN5boost4asio6detail11timer_queueINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE14get_all_timersERNS1_8op_queueINS1_25task_io_service_operationEEE
void __fastcall boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::get_all_timers(
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *ops)
{
  __int64 v2; // rax
  __int64 v3; // rdx
  _QWORD *p_next; // rdx

  v2 = *((_QWORD *)this + 2);
  if ( v2 )
  {
    do
    {
      v3 = *(_QWORD *)(v2 + 24);
      *((_QWORD *)this + 2) = v3;
      if ( *(_QWORD *)v2 )
      {
        p_next = &ops->back_->next_;
        if ( !p_next )
          p_next = &ops->front_;
        *p_next = *(_QWORD *)v2;
        ops->back_ = *(boost::asio::detail::task_io_service_operation **)(v2 + 8);
        *(_OWORD *)v2 = 0;
        v3 = *((_QWORD *)this + 2);
      }
      *(_OWORD *)(v2 + 24) = 0;
      v2 = v3;
    }
    while ( v3 );
  }
  *((_QWORD *)this + 4) = *((_QWORD *)this + 3);
}


// Address: 0x269f640 | Name: _ZN5boost4asio6detail11timer_queueINS1_18chrono_time_traitsINSt3__16chrono12steady_clockENS0_11wait_traitsIS6_EEEEE13enqueue_timerERKNS5_10time_pointIS6_NS5_8durationIxNS4_5ratioILl1ELl1000000000EEEEEEERNSA_14per_timer_dataEPNS1_7wait_opE
bool __fastcall boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::enqueue_timer(
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *this,
        const boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::time_type *time,
        boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data *timer,
        boost::asio::detail::wait_op *op)
{
  boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::heap_entry *v6; // rax
  __int64 v7; // rax
  __int64 v8; // rcx
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rdx
  boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data *v11; // rax
  boost::asio::detail::wait_op *back; // rax
  boost::asio::detail::wait_op *front; // rax
  boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::heap_entry v15; // [rsp+0h] [rbp-48h] BYREF
  __int128 v16; // [rsp+10h] [rbp-38h]

  if ( !timer->prev_
    && *((boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data **)this
       + 2) != timer )
  {
    v6 = (boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::heap_entry *)*((_QWORD *)this + 4);
    timer->heap_index_ = ((__int64)v6 - *((_QWORD *)this + 3)) >> 4;
    v15.time_ = (boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::time_type)time->__d_.__rep_;
    v15.timer_ = timer;
    if ( *((boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::heap_entry **)this
         + 5) == v6 )
    {
      std::vector<boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::heap_entry,std::allocator<boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::heap_entry>>::__push_back_slow_path<boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock>>>::heap_entry const&>(
        (boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > > *)((char *)this + 24),
        &v15);
      v7 = *((_QWORD *)this + 4);
    }
    else
    {
      *v6 = v15;
      v7 = *((_QWORD *)this + 4) + 16LL;
      *((_QWORD *)this + 4) = v7;
    }
    v8 = *((_QWORD *)this + 3);
    v9 = ((v7 - v8) >> 4) - 1;
    if ( v9 )
    {
      do
      {
        v10 = (v9 - 1) >> 1;
        if ( *(_QWORD *)(v8 + 16 * v9) >= *(_QWORD *)(v8 + 16 * v10) )
          break;
        v16 = *(_OWORD *)(v8 + 16 * v9);
        *(_OWORD *)(v8 + 16 * v9) = *(_OWORD *)(v8 + 16 * v10);
        *(_OWORD *)(*((_QWORD *)this + 3) + 16 * v10) = v16;
        v8 = *((_QWORD *)this + 3);
        *(_QWORD *)(*(_QWORD *)(v8 + 16 * v9 + 8) + 16LL) = v9;
        *(_QWORD *)(*(_QWORD *)(v8 + 16 * v10 + 8) + 16LL) = v10;
        v9 = (v9 - 1) >> 1;
      }
      while ( v10 );
    }
    v11 = (boost::asio::detail::timer_queue<boost::asio::detail::chrono_time_traits<std::chrono::steady_clock,boost::asio::wait_traits<std::chrono::steady_clock> > >::per_timer_data *)*((_QWORD *)this + 2);
    timer->next_ = v11;
    timer->prev_ = 0;
    if ( v11 )
      v11->prev_ = timer;
    *((_QWORD *)this + 2) = timer;
  }
  op->next_ = 0;
  back = timer->op_queue_.back_;
  if ( back )
  {
    back->next_ = op;
    timer->op_queue_.back_ = op;
    front = timer->op_queue_.front_;
  }
  else
  {
    timer->op_queue_.back_ = op;
    timer->op_queue_.front_ = op;
    front = op;
  }
  return (timer->heap_index_ | (unsigned __int64)op ^ (unsigned __int64)front) == 0;
}


