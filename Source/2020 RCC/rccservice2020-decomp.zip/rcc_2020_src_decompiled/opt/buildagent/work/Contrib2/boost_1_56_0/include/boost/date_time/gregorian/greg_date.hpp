// Address: 0xfe7a80 | Name: _ZN5boost9gregorian4dateC2ENS0_9greg_yearENS0_10greg_monthENS0_8greg_dayE
void __fastcall boost::gregorian::date::date(
        boost::gregorian::date *this,
        boost::gregorian::date::year_type_0 y,
        boost::gregorian::date::month_type_0 m,
        boost::gregorian::date::day_type d)
{
  __int16 v4; // bx
  boost::CV::constrained_value<boost::CV::simple_exception_policy<unsigned short,1,31,boost::gregorian::bad_day_of_month> >::value_type v5; // di
  int v6; // eax
  _QWORD v7[2]; // [rsp+0h] [rbp-38h] BYREF
  __int128 v8; // [rsp+10h] [rbp-28h] BYREF
  void *ptr; // [rsp+20h] [rbp-18h]

  v4 = ((unsigned __int64)(715827883LL * (14 - m.value_)) >> 63) + ((715827883LL * (14 - m.value_)) >> 33);
  this->days_ = (153 * (unsigned int)(unsigned __int16)(m.value_ + 12 * v4 - 3) + 2) / 5
              + ((unsigned int)(2622 * ((unsigned __int16)(y.value_ + 4800 - v4) >> 4)) >> 16)
              + ((unsigned __int16)(y.value_ + 4800 - v4) >> 2)
              + d.value_
              + 365 * (unsigned __int16)(y.value_ + 4800 - v4)
              - 32045
              - ((unsigned int)(5243 * ((unsigned __int16)(y.value_ + 4800 - v4) >> 2)) >> 17);
  if ( m.value_ > 0xBu )
    goto LABEL_9;
  v5 = 30;
  v6 = 2640;
  if ( _bittest(&v6, m.value_) )
    goto LABEL_3;
  if ( m.value_ == 2 )
  {
    v5 = 28;
    if ( (y.value_ & 3) != 0 )
    {
LABEL_3:
      if ( v5 >= d.value_ )
        return;
LABEL_10:
      ptr = operator new(0x30u);
      v8 = xmmword_3EB1A0;
      strcpy((char *)ptr, "Day of month is not valid for year");
      std::logic_error::logic_error(v7, &v8);
      v7[0] = off_2889F48;
      boost::throw_exception<boost::gregorian::bad_day_of_month>((const boost::gregorian::bad_day_of_month *)v7);
    }
    if ( (unsigned __int16)((y.value_ != (boost::gregorian::date::year_type_0)(100 * (y.value_ / 0x64u))
                          || y.value_ == (boost::gregorian::date::year_type_0)(400 * (y.value_ / 0x190u)))
                          | 0x1C) < d.value_ )
      goto LABEL_10;
  }
  else
  {
LABEL_9:
    if ( d.value_ > 0x1Fu )
      goto LABEL_10;
  }
}


