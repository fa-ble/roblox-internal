// Address: 0x2609e80 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSG_mEE4typeEE4typeERNS0_6detail23reactive_socket_serviceIS3_E19implementation_typeERKT_iOSO_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *handler)
{
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *f; // rdi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > v9; // [rsp+0h] [rbp-B8h] BYREF
  unsigned __int64 v10; // [rsp+88h] [rbp-30h]

  v10 = __readfsqword(0x28u);
  *(_OWORD *)&v9.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v9.start_ = handler->start_;
  v9.want_ = handler->want_;
  v9.ec_ = handler->ec_;
  v9.bytes_transferred_ = handler->bytes_transferred_;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *)handler->handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_ == (std::function<void (const boost::system::error_code &)> *)f )
    {
      v9.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&v9.handler_;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > *, std::function<void (const boost::system::error_code &)> *))f->next_layer_->service_)(
        f,
        &v9.handler_);
    }
    else
    {
      v9.handler_.__f_ = handler->handler_.__f_;
      handler->handler_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.__f_ = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v9);
  if ( &v9.handler_ == (std::function<void (const boost::system::error_code &)> *)v9.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v9.handler_.__f_->_vptr$__base
     + 4))(v9.handler_.__f_);
  }
  else if ( v9.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *, boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *))v9.handler_.__f_->_vptr$__base
     + 5))(
      v9.handler_.__f_,
      impl);
  }
}


// Address: 0x260acc0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_11shutdown_opENSt3__18functionIFvRKNS_6system10error_codeEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSJ_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOSS_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *handler)
{
  __int64 v5; // r9
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *f; // rdi
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > v10; // [rsp+0h] [rbp-E8h] BYREF
  unsigned __int64 v11; // [rsp+B8h] [rbp-30h]

  v11 = __readfsqword(0x28u);
  v10.stream_ = handler->stream_;
  v10.buffer_ = handler->buffer_;
  v10.start_ = handler->start_;
  v10.total_transferred_ = handler->total_transferred_;
  *(_OWORD *)&v10.handler_.next_layer_ = *(_OWORD *)&handler->handler_.next_layer_;
  v10.handler_.start_ = handler->handler_.start_;
  v10.handler_.want_ = handler->handler_.want_;
  v10.handler_.ec_ = handler->handler_.ec_;
  v10.handler_.bytes_transferred_ = handler->handler_.bytes_transferred_;
  f = (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *)handler->handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_ == (std::function<void (const boost::system::error_code &)> *)f )
    {
      v10.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &)>::__base *)&v10.handler_.handler_;
      ((void (__fastcall *)(boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *, std::function<void (const boost::system::error_code &)> *, const boost::asio::mutable_buffers_1 *, boost::asio::socket_base::message_flags, boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::shutdown_op,std::function<void (const boost::system::error_code &)> > > *, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, void *, size_t, int, size_t))f->stream_->service_)(
        f,
        &v10.handler_.handler_,
        buffers,
        flags,
        handler,
        v5,
        v10.stream_,
        v10.buffer_.data_,
        v10.buffer_.size_,
        v10.start_,
        v10.total_transferred_);
    }
    else
    {
      v10.handler_.handler_.__f_ = handler->handler_.handler_.__f_;
      handler->handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    v10.handler_.handler_.__f_ = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::shutdown_op,std::function<void ()(boost::system::error_code const&)>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v10);
  if ( &v10.handler_.handler_ == (std::function<void (const boost::system::error_code &)> *)v10.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &)>::__base *))v10.handler_.handler_.__f_->_vptr$__base
     + 4))(v10.handler_.handler_.__f_);
  }
  else if ( v10.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v10.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x2613580 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_8write_opINS7_17consuming_buffersINS0_12const_bufferENSt3__16vectorISH_NSI_9allocatorISH_EEEEEEEENS8_INSC_6streamISA_EESM_SB_N11websocketpp9transport4asio20custom_alloc_handlerINSI_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSX_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS18_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *handler)
{
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // r8
  __int64 v10; // r9
  __int64 v11; // [rsp+0h] [rbp-178h] BYREF
  __int128 v12; // [rsp+8h] [rbp-170h]
  int v13; // [rsp+18h] [rbp-160h]
  __int64 v14; // [rsp+20h] [rbp-158h]
  _BYTE v15[16]; // [rsp+30h] [rbp-148h] BYREF
  void *v16; // [rsp+40h] [rbp-138h]
  void *v17; // [rsp+48h] [rbp-130h]
  void *ptr; // [rsp+A8h] [rbp-D0h]
  void *v19; // [rsp+B0h] [rbp-C8h]
  char v20; // [rsp+110h] [rbp-68h] BYREF
  char *v21; // [rsp+130h] [rbp-48h]
  unsigned __int64 v22; // [rsp+150h] [rbp-28h]

  v22 = __readfsqword(0x28u);
  v11 = *(_QWORD *)handler;
  v12 = *(_OWORD *)((char *)handler + 8);
  v13 = *((_DWORD *)handler + 6);
  v14 = *((_QWORD *)handler + 4);
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v15,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *)((char *)handler + 48));
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > > *)&v11);
  if ( &v20 == v21 )
  {
    (*(void (__fastcall **)(char *, boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *, __int64, __int64, __int64, __int64, __int64, _QWORD, _QWORD, int, __int64))(*(_QWORD *)v21 + 32LL))(
      v21,
      impl,
      v7,
      v8,
      v9,
      v10,
      v11,
      v12,
      *((_QWORD *)&v12 + 1),
      v13,
      v14);
  }
  else if ( v21 )
  {
    (*(void (__fastcall **)(char *, boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *, __int64, __int64, __int64))(*(_QWORD *)v21 + 40LL))(
      v21,
      impl,
      v7,
      v8,
      v9);
  }
  if ( ptr )
  {
    v19 = ptr;
    operator delete(ptr);
  }
  if ( v16 )
  {
    v17 = v16;
    operator delete(v16);
  }
}


// Address: 0x261a730 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEED0Ev
// Alternative name is 'j__ZdlPv_2000'
// attributes: thunk
void __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::~stream_socket_service(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this)
{
  operator delete(this);
}


// Address: 0x261a740 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE16shutdown_serviceEv
void __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::shutdown_service(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this)
{
  ;
}


// Address: 0x2632640 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_12handshake_opENS0_6detail15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSH_8functionIFvRKNSH_10error_codeEEEERKNS_6system10error_codeEEJNSH_10shared_ptrISN_EERST_RKNSH_12placeholders4__phILi1EEEEEENSD_26is_continuation_if_runningEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSV_mEE4typeEE4typeERNSD_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1E_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *handler)
{
  __int64 v5; // r9
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > v11; // [rsp+0h] [rbp-E8h] BYREF
  unsigned __int64 v12; // [rsp+B8h] [rbp-30h]

  v12 = __readfsqword(0x28u);
  *(_OWORD *)&v11.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v11.op_.type_ = handler->op_.type_;
  v11.start_ = handler->start_;
  v11.want_ = handler->want_;
  v11.ec_ = handler->ec_;
  v11.bytes_transferred_ = handler->bytes_transferred_;
  v11.handler_.dispatcher_ = handler->handler_.dispatcher_;
  *(_OWORD *)&v11.handler_.handler_.__f_ = *(_OWORD *)&handler->handler_.handler_.__f_;
  v11.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *)handler->handler_.handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v11.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::asio::mutable_buffers_1 *, boost::asio::socket_base::message_flags, boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > *, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, _QWORD, const boost::system::error_category *, size_t))f->next_layer_->service_)(
        f,
        &v11.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        buffers,
        flags,
        handler,
        v5,
        v11.next_layer_,
        v11.core_,
        *(_QWORD *)&v11.op_.type_,
        v11.want_,
        *(_QWORD *)&v11.ec_.m_val,
        v11.ec_.m_cat,
        v11.bytes_transferred_);
    }
    else
    {
      v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v11);
  if ( &v11.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v11.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v11.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v11.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v11.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v11.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v11.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v11.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x2634b90 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_12handshake_opENS7_15wrapped_handlerINS0_10io_service6strandENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSJ_8functionIFvRKNSJ_10error_codeEEEERKNS_6system10error_codeEEJNSJ_10shared_ptrISP_EERSV_RKNSJ_12placeholders4__phILi1EEEEEENS7_26is_continuation_if_runningEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSX_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1H_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &>,boost::asio::detail::is_continuation_if_running> > > v8; // [rsp+0h] [rbp-118h] BYREF
  unsigned __int64 v9; // [rsp+E8h] [rbp-30h]

  v9 = __readfsqword(0x28u);
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>::write_op(
    &v8,
    handler);
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::asio::detail::wrapped_handler<boost::asio::io_service::strand,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>,boost::asio::detail::is_continuation_if_running>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v8);
  if ( &v8.handler_.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v8.handler_.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26372d0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSD_8functionIFvRKNSD_10error_codeEEEERKNS_6system10error_codeEEJNSD_10shared_ptrISJ_EERSP_RKNSD_12placeholders4__phILi1EEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSR_mEE4typeEE4typeERNS0_6detail23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS18_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *handler)
{
  __int64 v5; // r9
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *f; // rdi
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > v11; // [rsp+0h] [rbp-D8h] BYREF
  unsigned __int64 v12; // [rsp+A8h] [rbp-30h]

  v12 = __readfsqword(0x28u);
  *(_OWORD *)&v11.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v11.op_.type_ = handler->op_.type_;
  v11.start_ = handler->start_;
  v11.want_ = handler->want_;
  v11.ec_ = handler->ec_;
  v11.bytes_transferred_ = handler->bytes_transferred_;
  *(_OWORD *)&v11.handler_.__f_ = *(_OWORD *)&handler->handler_.__f_;
  v11.handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false>;
  handler->handler_.__bound_args_.__base_.std::__tuple_leaf<0,std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,false> = 0;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *)handler->handler_.__bound_args_.__base_.__value_.__f_;
  if ( f )
  {
    if ( &handler->handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)f )
    {
      v11.handler_.__bound_args_.__base_.__value_.__f_ = (std::function<void (const std::error_code &)>::__base *)&v11.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *, std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *, const boost::asio::mutable_buffers_1 *, boost::asio::socket_base::message_flags, boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > *, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, _QWORD, boost::asio::ssl::detail::engine::want, _QWORD, const boost::system::error_category *, size_t))f->next_layer_->service_)(
        f,
        &v11.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false>,
        buffers,
        flags,
        handler,
        v5,
        v11.next_layer_,
        v11.core_,
        *(_QWORD *)&v11.op_.type_,
        v11.want_,
        *(_QWORD *)&v11.ec_.m_val,
        v11.ec_.m_cat,
        v11.bytes_transferred_);
    }
    else
    {
      v11.handler_.__bound_args_.__base_.__value_.__f_ = handler->handler_.__bound_args_.__base_.__value_.__f_;
      handler->handler_.__bound_args_.__base_.__value_.__f_ = 0;
    }
  }
  else
  {
    v11.handler_.__bound_args_.__base_.__value_.__f_ = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v11);
  if ( &v11.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v11.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v11.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v11.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v11.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v11.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v11.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v11.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v11.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x2638050 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_12handshake_opENSt3__16__bindIMN11websocketpp9transport4asio10tls_socket10connectionEFvNSG_8functionIFvRKNSG_10error_codeEEEERKNS_6system10error_codeEEJNSG_10shared_ptrISM_EERSS_RKNSG_12placeholders4__phILi1EEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSU_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1C_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void (const std::error_code &)>,const boost::system::error_code &),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void (const std::error_code &)> &,const std::placeholders::__ph<1> &> > > v8; // [rsp+0h] [rbp-108h] BYREF
  unsigned __int64 v9; // [rsp+D8h] [rbp-30h]

  v9 = __readfsqword(0x28u);
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>::write_op(
    &v8,
    handler);
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,std::__bind<void (websocketpp::transport::asio::tls_socket::connection::*)(std::function<void ()(std::error_code const&)>,boost::system::error_code const&),std::shared_ptr<websocketpp::transport::asio::tls_socket::connection>,std::function<void ()(std::error_code const&)>&,std::placeholders::__ph<1> const&>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v8);
  if ( &v8.handler_.handler_.__bound_args_.__base_.std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> == (std::__tuple_leaf<1,std::function<void (const std::error_code &)>,false> *)v8.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const std::error_code &)>::__base *))v8.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base
     + 4))(v8.handler_.handler_.__bound_args_.__base_.__value_.__f_);
  }
  else if ( v8.handler_.handler_.__bound_args_.__base_.__value_.__f_ )
  {
    (*((void (**)(void))v8.handler_.handler_.__bound_args_.__base_.__value_.__f_->_vptr$__base + 5))();
  }
  cntrl = v8.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_;
  if ( v8.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v8.handler_.handler_.__bound_args_.__base_.__value_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x265c4e0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorIS8_NS9_9allocatorIS8_EEEEEENS6_8write_opINS0_19basic_stream_socketIS3_S4_EESD_NS6_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINS9_8functionIFvRKNS_6system10error_codeEmEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSP_mEE4typeEE4typeERNS6_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOSY_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *v9; // rdi
  __int64 v10; // [rsp+0h] [rbp-E8h] BYREF
  void *ptr[8]; // [rsp+8h] [rbp-E0h] BYREF
  int v12; // [rsp+48h] [rbp-A0h]
  __int64 v13; // [rsp+50h] [rbp-98h]
  __int64 v14; // [rsp+60h] [rbp-88h]
  _BYTE v15[32]; // [rsp+70h] [rbp-78h] BYREF
  _BYTE *v16; // [rsp+90h] [rbp-58h]
  unsigned __int64 v17; // [rsp+B0h] [rbp-38h]

  v17 = __readfsqword(0x28u);
  v10 = *(_QWORD *)handler;
  boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>::consuming_buffers(
    (boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > *)ptr,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)handler + 8));
  v12 = *((_DWORD *)handler + 18);
  v13 = *((_QWORD *)handler + 10);
  v14 = *((_QWORD *)handler + 12);
  v9 = (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)*((_QWORD *)handler + 18);
  if ( v9 )
  {
    if ( (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)((char *)handler + 112) == v9 )
    {
      v16 = v15;
      (*(void (__fastcall **)(boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *, _BYTE *))(*(_QWORD *)v9 + 24LL))(
        v9,
        v15);
    }
    else
    {
      v16 = (_BYTE *)*((_QWORD *)handler + 18);
      *((_QWORD *)handler + 18) = 0;
    }
  }
  else
  {
    v16 = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)&v10);
  if ( v15 == v16 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v16 + 32LL))(v16);
  }
  else if ( v16 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v16 + 40LL))(v16);
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
}


// Address: 0x265dde0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_6detail7read_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSJ_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOSS_
boost::asio::async_result<boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *handler)
{
  __int64 v5; // r9
  boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *f; // rdi
  boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > v10; // [rsp+0h] [rbp-B8h] BYREF
  unsigned __int64 v11; // [rsp+88h] [rbp-30h]

  v11 = __readfsqword(0x28u);
  *(_OWORD *)&v10.completion_condition_.minimum_ = *(_OWORD *)&handler->completion_condition_.minimum_;
  v10.buffer_ = handler->buffer_;
  v10.start_ = handler->start_;
  *(_OWORD *)&v10.total_transferred_ = *(_OWORD *)&handler->total_transferred_;
  f = (boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *)handler->handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v10.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v10.handler_.handler_;
      (*(void (__fastcall **)(boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *, std::function<void (const boost::system::error_code &,unsigned long)> *, const boost::asio::mutable_buffers_1 *, boost::asio::socket_base::message_flags, boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > *, __int64, size_t, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, void *, size_t, int, size_t, websocketpp::transport::asio::handler_allocator *))(f->completion_condition_.minimum_ + 24))(
        f,
        &v10.handler_.handler_,
        buffers,
        flags,
        handler,
        v5,
        v10.completion_condition_.minimum_,
        v10.stream_,
        v10.buffer_.data_,
        v10.buffer_.size_,
        v10.start_,
        v10.total_transferred_,
        v10.handler_.allocator_);
    }
    else
    {
      v10.handler_.handler_.__f_ = handler->handler_.handler_.__f_;
      handler->handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    v10.handler_.handler_.__f_ = 0;
  }
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v10);
  if ( &v10.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v10.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v10.handler_.handler_.__f_->_vptr$__base
     + 4))(v10.handler_.handler_.__f_);
  }
  else if ( v10.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v10.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x26a11f0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_connectIRKNS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeENS2_23basic_resolver_iteratorIS3_EEEENS6_5list3INS6_5valueINSt3__110shared_ptrISF_EEEEPFNS_3argILi1EEEvENSO_ISL_EEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSH_EE4typeEE4typeERNS0_6detail23reactive_socket_serviceIS3_E19implementation_typeERKNS2_14basic_endpointIS3_EEOS14_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_connect<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>> const&>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::stream_socket_service<boost::asio::ip::tcp>::endpoint_type *peer_endpoint,
        const boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *handler)
{
  volatile signed __int64 *cntrl; // rax
  volatile signed __int64 *v5; // rax
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // r8
  __int64 v9; // r9
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > v12; // [rsp+0h] [rbp-58h] BYREF

  v12.f_ = handler->f_;
  v12.l_.a1_.t_.__ptr_ = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  v12.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v12.l_.a3_.t_.values_.__ptr_ = handler->l_.a3_.t_.values_.__ptr_;
  v5 = (volatile signed __int64 *)handler->l_.a3_.t_.values_.__cntrl_;
  v12.l_.a3_.t_.values_.__cntrl_ = (std::__shared_weak_count *)v5;
  if ( v5 )
    _InterlockedAdd64(v5 + 1, 1u);
  v12.l_.a3_.t_.index_ = handler->l_.a3_.t_.index_;
  boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::async_connect<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>(
    &this->service_impl_,
    impl,
    peer_endpoint,
    &v12);
  v10 = v12.l_.a3_.t_.values_.__cntrl_;
  if ( v12.l_.a3_.t_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v12.l_.a3_.t_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *, __int64, __int64, __int64, __int64, boost::_mfi::mf2<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>::element_type *))(*(_QWORD *)v10 + 16LL))(
      v10,
      impl,
      v6,
      v7,
      v8,
      v9,
      v12.f_.f_,
      *((_QWORD *)&v12.f_.f_ + 1),
      v12.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak(v10);
  }
  v11 = v12.l_.a1_.t_.__cntrl_;
  if ( v12.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v12.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
      std::__shared_weak_count::__release_weak(v11);
    }
  }
}


// Address: 0x26a2aa0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS7_6streamIRSB_EESD_NSF_14transfer_all_tENSF_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvS10_mEE4typeEE4typeERNSF_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1K_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > v6; // [rsp+0h] [rbp-A8h] BYREF

  v6 = *handler;
  handler->handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a33d0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_8write_opINS0_15const_buffers_1EEENS8_INSC_6streamIRSA_EESG_SB_NS7_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISY_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvS10_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1L_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > > v6; // [rsp+8h] [rbp-D0h] BYREF

  v6 = *handler;
  handler->handler_.handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a3a50 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_15const_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS7_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSD_10shared_ptrISP_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSR_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1A_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::const_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > v6; // [rsp+0h] [rbp-68h] BYREF

  v6 = *handler;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a5780 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_7read_opIS6_EENS0_6detail26read_until_delim_string_opINS7_6streamIRSB_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSX_mEE4typeEE4typeERNSE_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1G_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *v5; // rbx
  _OWORD v6[2]; // [rsp+0h] [rbp-B8h] BYREF
  int v7; // [rsp+20h] [rbp-98h]
  int v8; // [rsp+24h] [rbp-94h]
  __int128 v9; // [rsp+28h] [rbp-90h]
  __int128 v10; // [rsp+38h] [rbp-80h]
  __int64 v11; // [rsp+48h] [rbp-70h]
  __int128 v12; // [rsp+50h] [rbp-68h]
  void *ptr; // [rsp+60h] [rbp-58h]
  int v14; // [rsp+68h] [rbp-50h]
  __int64 v15; // [rsp+70h] [rbp-48h]
  __int128 v16; // [rsp+78h] [rbp-40h]
  std::__shared_weak_count *v17[2]; // [rsp+88h] [rbp-30h]

  v6[0] = *(_OWORD *)handler;
  v6[1] = *((_OWORD *)handler + 1);
  v7 = *((_DWORD *)handler + 8);
  v8 = *((_DWORD *)handler + 9);
  v9 = *(_OWORD *)((char *)handler + 40);
  v10 = *(_OWORD *)((char *)handler + 56);
  v11 = *((_QWORD *)handler + 9);
  ptr = (void *)*((_QWORD *)handler + 12);
  v12 = *((_OWORD *)handler + 5);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  v14 = *((_DWORD *)handler + 26);
  v15 = *((_QWORD *)handler + 14);
  v16 = *(_OWORD *)((char *)handler + 120);
  *(_OWORD *)v17 = *(_OWORD *)((char *)handler + 136);
  *(_OWORD *)((char *)handler + 136) = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > *)v6);
  v5 = v17[1];
  if ( v17[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v17[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
    if ( (v12 & 1) == 0 )
      return;
  }
  else if ( (v12 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a6330 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS6_EENS7_26read_until_delim_string_opINSC_6streamIRSA_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSO_5list2INSO_5valueINSL_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSZ_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1J_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *handler)
{
  std::__shared_weak_count *v5; // rbx
  __int64 v6; // [rsp+0h] [rbp-D8h] BYREF
  __int128 v7; // [rsp+8h] [rbp-D0h]
  int v8; // [rsp+18h] [rbp-C0h]
  __int128 v9; // [rsp+20h] [rbp-B8h]
  __int64 v10; // [rsp+30h] [rbp-A8h]
  __int128 v11; // [rsp+38h] [rbp-A0h]
  int v12; // [rsp+48h] [rbp-90h]
  int v13; // [rsp+4Ch] [rbp-8Ch]
  __int128 v14; // [rsp+50h] [rbp-88h]
  __int128 v15; // [rsp+60h] [rbp-78h]
  __int64 v16; // [rsp+70h] [rbp-68h]
  __int128 v17; // [rsp+78h] [rbp-60h]
  void *ptr; // [rsp+88h] [rbp-50h]
  int v19; // [rsp+90h] [rbp-48h]
  __int64 v20; // [rsp+98h] [rbp-40h]
  __int128 v21; // [rsp+A0h] [rbp-38h]
  std::__shared_weak_count *v22[2]; // [rsp+B0h] [rbp-28h]

  v6 = *(_QWORD *)handler;
  v7 = *(_OWORD *)((char *)handler + 8);
  v8 = *((_DWORD *)handler + 6);
  v9 = *((_OWORD *)handler + 2);
  v10 = *((_QWORD *)handler + 6);
  v11 = *(_OWORD *)((char *)handler + 56);
  v12 = *((_DWORD *)handler + 18);
  v13 = *((_DWORD *)handler + 19);
  v14 = *((_OWORD *)handler + 5);
  v15 = *((_OWORD *)handler + 6);
  v16 = *((_QWORD *)handler + 14);
  ptr = (void *)*((_QWORD *)handler + 17);
  v17 = *(_OWORD *)((char *)handler + 120);
  *(_OWORD *)((char *)handler + 120) = 0;
  *((_QWORD *)handler + 17) = 0;
  v19 = *((_DWORD *)handler + 36);
  v20 = *((_QWORD *)handler + 19);
  v21 = *((_OWORD *)handler + 10);
  *(_OWORD *)v22 = *((_OWORD *)handler + 11);
  *((_OWORD *)handler + 11) = 0;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > > > *)&v6);
  v5 = v22[1];
  if ( v22[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
    if ( (v17 & 1) == 0 )
      return;
  }
  else if ( (v17 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a6e70 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_6detail26read_until_delim_string_opINS0_19basic_stream_socketIS3_S4_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_context16ssl_proxy_tunnelERKNS_6system10error_codeEEENSE_5list2INSE_5valueINSB_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSP_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS17_
boost::asio::async_result<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *handler)
{
  std::__shared_weak_count *v5; // rbx
  __int128 v6; // [rsp+0h] [rbp-78h] BYREF
  __int128 v7; // [rsp+10h] [rbp-68h]
  void *ptr; // [rsp+20h] [rbp-58h]
  int v9; // [rsp+28h] [rbp-50h]
  __int64 v10; // [rsp+30h] [rbp-48h]
  __int128 v11; // [rsp+38h] [rbp-40h]
  std::__shared_weak_count *v12[2]; // [rsp+48h] [rbp-30h]

  v6 = *(_OWORD *)handler;
  ptr = (void *)*((_QWORD *)handler + 4);
  v7 = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  v9 = *((_DWORD *)handler + 10);
  v10 = *((_QWORD *)handler + 6);
  v11 = *(_OWORD *)((char *)handler + 56);
  *(_OWORD *)v12 = *(_OWORD *)((char *)handler + 72);
  *(_OWORD *)((char *)handler + 72) = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel>>,boost::arg<1> (*)(void)>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context::ssl_proxy_tunnel,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context::ssl_proxy_tunnel> >,boost::arg<1> (*)()> > > *)&v6);
  v5 = v12[1];
  if ( v12[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v12[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
    if ( (v7 & 1) == 0 )
      return;
  }
  else if ( (v7 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26a8d50 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSD_5list2INSD_5valueINSt3__110shared_ptrISL_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSN_mEE4typeEE4typeERNS0_6detail23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS16_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v6; // [rsp+0h] [rbp-78h] BYREF

  v6 = *handler;
  handler->handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v6.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26a9510 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_12handshake_opENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSt3__110shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSQ_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1A_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v6; // [rsp+0h] [rbp-98h] BYREF

  v6 = *handler;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::handshake_op,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26aa4f0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_8write_opINS0_15const_buffers_1EEENS0_6detail8write_opINS7_6streamIRSB_EESD_NSF_14transfer_all_tENSF_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSZ_mEE4typeEE4typeERNSF_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1J_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > v6; // [rsp+0h] [rbp-A8h] BYREF

  v6 = *handler;
  handler->handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26aae20 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_8write_opINS0_15const_buffers_1EEENS8_INSC_6streamIRSA_EESG_SB_NS7_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSM_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSZ_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1K_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > > v6; // [rsp+8h] [rbp-D0h] BYREF

  v6 = *handler;
  handler->handler_.handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::const_buffers_1>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26ab4a0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_15const_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS7_23write_streambuf_handlerINSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSG_5list2INSG_5valueINSD_10shared_ptrISO_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSQ_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS19_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::const_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v6; // [rsp+0h] [rbp-68h] BYREF

  v6 = *handler;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::const_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::const_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::detail::write_streambuf_handler<std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26adc00 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_7read_opIS6_EENS0_6detail26read_until_delim_string_opINS7_6streamIRSB_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSM_5list2INSM_5valueINSJ_10shared_ptrISU_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSW_mEE4typeEE4typeERNSE_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1F_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *v5; // rbx
  _OWORD v6[2]; // [rsp+0h] [rbp-B8h] BYREF
  int v7; // [rsp+20h] [rbp-98h]
  int v8; // [rsp+24h] [rbp-94h]
  __int128 v9; // [rsp+28h] [rbp-90h]
  __int128 v10; // [rsp+38h] [rbp-80h]
  __int64 v11; // [rsp+48h] [rbp-70h]
  __int128 v12; // [rsp+50h] [rbp-68h]
  void *ptr; // [rsp+60h] [rbp-58h]
  int v14; // [rsp+68h] [rbp-50h]
  __int64 v15; // [rsp+70h] [rbp-48h]
  __int128 v16; // [rsp+78h] [rbp-40h]
  std::__shared_weak_count *v17[2]; // [rsp+88h] [rbp-30h]

  v6[0] = *(_OWORD *)handler;
  v6[1] = *((_OWORD *)handler + 1);
  v7 = *((_DWORD *)handler + 8);
  v8 = *((_DWORD *)handler + 9);
  v9 = *(_OWORD *)((char *)handler + 40);
  v10 = *(_OWORD *)((char *)handler + 56);
  v11 = *((_QWORD *)handler + 9);
  ptr = (void *)*((_QWORD *)handler + 12);
  v12 = *((_OWORD *)handler + 5);
  *((_OWORD *)handler + 5) = 0;
  *((_QWORD *)handler + 12) = 0;
  v14 = *((_DWORD *)handler + 26);
  v15 = *((_QWORD *)handler + 14);
  v16 = *(_OWORD *)((char *)handler + 120);
  *(_OWORD *)v17 = *(_OWORD *)((char *)handler + 136);
  *(_OWORD *)((char *)handler + 136) = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *)v6);
  v5 = v17[1];
  if ( v17[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v17[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
    if ( (v12 & 1) == 0 )
      return;
  }
  else if ( (v12 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26ae7b0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS6_EENS7_26read_until_delim_string_opINSC_6streamIRSA_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSO_5list2INSO_5valueINSL_10shared_ptrISW_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSY_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1I_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  std::__shared_weak_count *v5; // rbx
  __int64 v6; // [rsp+0h] [rbp-D8h] BYREF
  __int128 v7; // [rsp+8h] [rbp-D0h]
  int v8; // [rsp+18h] [rbp-C0h]
  __int128 v9; // [rsp+20h] [rbp-B8h]
  __int64 v10; // [rsp+30h] [rbp-A8h]
  __int128 v11; // [rsp+38h] [rbp-A0h]
  int v12; // [rsp+48h] [rbp-90h]
  int v13; // [rsp+4Ch] [rbp-8Ch]
  __int128 v14; // [rsp+50h] [rbp-88h]
  __int128 v15; // [rsp+60h] [rbp-78h]
  __int64 v16; // [rsp+70h] [rbp-68h]
  __int128 v17; // [rsp+78h] [rbp-60h]
  void *ptr; // [rsp+88h] [rbp-50h]
  int v19; // [rsp+90h] [rbp-48h]
  __int64 v20; // [rsp+98h] [rbp-40h]
  __int128 v21; // [rsp+A0h] [rbp-38h]
  std::__shared_weak_count *v22[2]; // [rsp+B0h] [rbp-28h]

  v6 = *(_QWORD *)handler;
  v7 = *(_OWORD *)((char *)handler + 8);
  v8 = *((_DWORD *)handler + 6);
  v9 = *((_OWORD *)handler + 2);
  v10 = *((_QWORD *)handler + 6);
  v11 = *(_OWORD *)((char *)handler + 56);
  v12 = *((_DWORD *)handler + 18);
  v13 = *((_DWORD *)handler + 19);
  v14 = *((_OWORD *)handler + 5);
  v15 = *((_OWORD *)handler + 6);
  v16 = *((_QWORD *)handler + 14);
  ptr = (void *)*((_QWORD *)handler + 17);
  v17 = *(_OWORD *)((char *)handler + 120);
  *(_OWORD *)((char *)handler + 120) = 0;
  *((_QWORD *)handler + 17) = 0;
  v19 = *((_DWORD *)handler + 36);
  v20 = *((_QWORD *)handler + 19);
  v21 = *((_OWORD *)handler + 10);
  *(_OWORD *)v22 = *((_OWORD *)handler + 11);
  *((_OWORD *)handler + 11) = 0;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    (boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_until_delim_string_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *)&v6);
  v5 = v22[1];
  if ( v22[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v22[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
    if ( (v17 & 1) == 0 )
      return;
  }
  else if ( (v17 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26af2f0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_6detail26read_until_delim_string_opINS0_19basic_stream_socketIS3_S4_EENSt3__19allocatorIcEENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSE_5list2INSE_5valueINSB_10shared_ptrISM_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSO_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS16_
boost::asio::async_result<boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  std::__shared_weak_count *v5; // rbx
  __int128 v6; // [rsp+0h] [rbp-78h] BYREF
  __int128 v7; // [rsp+10h] [rbp-68h]
  void *ptr; // [rsp+20h] [rbp-58h]
  int v9; // [rsp+28h] [rbp-50h]
  __int64 v10; // [rsp+30h] [rbp-48h]
  __int128 v11; // [rsp+38h] [rbp-40h]
  std::__shared_weak_count *v12[2]; // [rsp+48h] [rbp-30h]

  v6 = *(_OWORD *)handler;
  ptr = (void *)*((_QWORD *)handler + 4);
  v7 = *((_OWORD *)handler + 1);
  *((_OWORD *)handler + 1) = 0;
  *((_QWORD *)handler + 4) = 0;
  v9 = *((_DWORD *)handler + 10);
  v10 = *((_QWORD *)handler + 6);
  v11 = *(_OWORD *)((char *)handler + 56);
  *(_OWORD *)v12 = *(_OWORD *)((char *)handler + 72);
  *(_OWORD *)((char *)handler + 72) = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    (boost::asio::detail::read_until_delim_string_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *)&v6);
  v5 = v12[1];
  if ( v12[1] && !_InterlockedExchangeAdd64((volatile signed __int64 *)v12[1] + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v5 + 16LL))(v5);
    std::__shared_weak_count::__release_weak(v5);
    if ( (v7 & 1) == 0 )
      return;
  }
  else if ( (v7 & 1) == 0 )
  {
    return;
  }
  operator delete(ptr);
}


// Address: 0x26b2590 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_7read_opIS6_EENS0_6detail17read_streambuf_opINS7_6streamIRSB_EENSt3__19allocatorIcEENSE_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSN_5list2INSN_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSX_mEE4typeEE4typeERNSE_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1G_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > v6; // [rsp+0h] [rbp-A8h] BYREF

  v6 = *handler;
  handler->handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b2e80 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS6_EENS7_17read_streambuf_opINSC_6streamIRSA_EENSt3__19allocatorIcEENS7_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSP_5list2INSP_5valueINSL_10shared_ptrISX_EEEEPFNS_3argILi1EEEvEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSZ_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1J_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > > > v6; // [rsp+0h] [rbp-C8h] BYREF

  v6 = *handler;
  handler->handler_.handler_.handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b35a0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_6detail17read_streambuf_opINS0_19basic_stream_socketIS3_S4_EENSt3__19allocatorIcEENS7_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf1IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEEENSF_5list2INSF_5valueINSB_10shared_ptrISN_EEEEPFNS_3argILi1EEEvEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSP_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS17_
boost::asio::async_result<boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,const boost::system::error_code &>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> > > v6; // [rsp+0h] [rbp-68h] BYREF

  v6 = *handler;
  handler->handler_.l_ = 0;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf1<void,web::http::client::details::asio_context,boost::system::error_code const&>,boost::_bi::list2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void)>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v6.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b5ff0 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_3ssl6detail5io_opINS0_19basic_stream_socketIS3_S4_EENS8_7read_opIS6_EENS0_6detail17read_streambuf_opINS7_6streamIRSB_EENSt3__19allocatorIcEENSE_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSN_5list3INSN_5valueINSJ_10shared_ptrISV_EEEEPFNS_3argILi1EEEvENS12_IiEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSX_mEE4typeEE4typeERNSE_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1H_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > v6; // [rsp+0h] [rbp-A8h] BYREF

  *(_OWORD *)&v6.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v6.op_ = handler->op_;
  v6.start_ = handler->start_;
  v6.want_ = handler->want_;
  v6.ec_ = handler->ec_;
  *(_OWORD *)&v6.bytes_transferred_ = *(_OWORD *)&handler->bytes_transferred_;
  *(_OWORD *)&v6.handler_.stream_ = *(_OWORD *)&handler->handler_.stream_;
  v6.handler_.start_ = handler->handler_.start_;
  v6.handler_.total_transferred_ = handler->handler_.total_transferred_;
  v6.handler_.handler_.f_ = handler->handler_.handler_.f_;
  v6.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  v6.handler_.handler_.l_.a3_.t_ = handler->handler_.handler_.l_.a3_.t_;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b6940 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE10async_sendINS0_17mutable_buffers_1ENS0_6detail8write_opINS0_19basic_stream_socketIS3_S4_EES6_NS7_14transfer_all_tENS0_3ssl6detail5io_opISA_NSD_7read_opIS6_EENS7_17read_streambuf_opINSC_6streamIRSA_EENSt3__19allocatorIcEENS7_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSP_5list3INSP_5valueINSL_10shared_ptrISX_EEEEPFNS_3argILi1EEEvENS14_IiEEEEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSZ_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS1K_
boost::asio::async_result<boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > &>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > > > v6; // [rsp+8h] [rbp-D0h] BYREF

  v6.stream_ = handler->stream_;
  v6.buffer_ = handler->buffer_;
  v6.start_ = handler->start_;
  *(_OWORD *)&v6.total_transferred_ = *(_OWORD *)&handler->total_transferred_;
  v6.handler_.core_ = handler->handler_.core_;
  v6.handler_.op_ = handler->handler_.op_;
  v6.handler_.start_ = handler->handler_.start_;
  v6.handler_.want_ = handler->handler_.want_;
  v6.handler_.ec_ = handler->handler_.ec_;
  *(_OWORD *)&v6.handler_.bytes_transferred_ = *(_OWORD *)&handler->handler_.bytes_transferred_;
  *(_OWORD *)&v6.handler_.handler_.stream_ = *(_OWORD *)&handler->handler_.handler_.stream_;
  v6.handler_.handler_.start_ = handler->handler_.handler_.start_;
  v6.handler_.handler_.total_transferred_ = handler->handler_.handler_.total_transferred_;
  v6.handler_.handler_.handler_.f_ = handler->handler_.handler_.handler_.f_;
  v6.handler_.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = handler->handler_.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.handler_.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  v6.handler_.handler_.handler_.l_.a3_.t_ = handler->handler_.handler_.handler_.l_.a3_.t_;
  boost::asio::detail::reactive_socket_service_base::async_send<boost::asio::mutable_buffers_1,boost::asio::detail::write_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_all_t,boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_streambuf_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>&>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64(
            (volatile signed __int64 *)v6.handler_.handler_.handler_.l_.a1_.t_.__cntrl_ + 1,
            0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26b7080 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_receiveINS0_17mutable_buffers_1ENS0_6detail17read_streambuf_opINS0_19basic_stream_socketIS3_S4_EENSt3__19allocatorIcEENS7_18transfer_exactly_tENS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeEiEENSF_5list3INSF_5valueINSB_10shared_ptrISN_EEEEPFNS_3argILi1EEEvENSU_IiEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT0_FvSP_mEE4typeEE4typeERNS7_23reactive_socket_serviceIS3_E19implementation_typeERKT_iOS18_
boost::asio::async_result<boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::mutable_buffers_1 *buffers,
        boost::asio::socket_base::message_flags flags,
        boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > *handler)
{
  std::__shared_weak_count *cntrl; // rbx
  boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<int> > > > v6; // [rsp+0h] [rbp-68h] BYREF

  *(_OWORD *)&v6.completion_condition_.size_ = *(_OWORD *)&handler->completion_condition_.size_;
  v6.streambuf_ = handler->streambuf_;
  v6.start_ = handler->start_;
  v6.total_transferred_ = handler->total_transferred_;
  v6.handler_.f_ = handler->handler_.f_;
  v6.handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()>;
  handler->handler_.l_.boost::_bi::storage2<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)()> = 0;
  v6.handler_.l_.a3_.t_ = handler->handler_.l_.a3_.t_;
  boost::asio::detail::reactive_socket_service_base::async_receive<boost::asio::mutable_buffers_1,boost::asio::detail::read_streambuf_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,std::allocator<char>,boost::asio::detail::transfer_exactly_t,boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,int>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<int>>>>>(
    &this->service_impl_,
    impl,
    buffers,
    flags,
    &v6);
  cntrl = v6.handler_.l_.a1_.t_.__cntrl_;
  if ( v6.handler_.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v6.handler_.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)cntrl + 16LL))(cntrl);
      std::__shared_weak_count::__release_weak(cntrl);
    }
  }
}


// Address: 0x26bc100 | Name: _ZN5boost4asio21stream_socket_serviceINS0_2ip3tcpEE13async_connectIRKNS_3_bi6bind_tIvNS_4_mfi3mf2IvN3web4http6client7details12asio_contextERKNS_6system10error_codeENS2_23basic_resolver_iteratorIS3_EEEENS6_5list3INS6_5valueINSt3__110shared_ptrISE_EEEEPFNS_3argILi1EEEvENSN_ISK_EEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSG_EE4typeEE4typeERNS0_6detail23reactive_socket_serviceIS3_E19implementation_typeERKNS2_14basic_endpointIS3_EEOS13_
boost::asio::async_result<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > >::type __fastcall boost::asio::stream_socket_service<boost::asio::ip::tcp>::async_connect<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>> const&>(
        boost::asio::stream_socket_service<boost::asio::ip::tcp> *this,
        boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *impl,
        const boost::asio::stream_socket_service<boost::asio::ip::tcp>::endpoint_type *peer_endpoint,
        const boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > *handler)
{
  volatile signed __int64 *cntrl; // rax
  volatile signed __int64 *v5; // rax
  __int64 v6; // rdx
  __int64 v7; // rcx
  __int64 v8; // r8
  __int64 v9; // r9
  std::__shared_weak_count *v10; // rbx
  std::__shared_weak_count *v11; // rbx
  boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context> >,boost::arg<1> (*)(),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> > > > v12; // [rsp+0h] [rbp-58h] BYREF

  v12.f_ = handler->f_;
  v12.l_.a1_.t_.__ptr_ = handler->l_.a1_.t_.__ptr_;
  cntrl = (volatile signed __int64 *)handler->l_.a1_.t_.__cntrl_;
  v12.l_.a1_.t_.__cntrl_ = (std::__shared_weak_count *)cntrl;
  if ( cntrl )
    _InterlockedAdd64(cntrl + 1, 1u);
  v12.l_.a3_.t_.values_.__ptr_ = handler->l_.a3_.t_.values_.__ptr_;
  v5 = (volatile signed __int64 *)handler->l_.a3_.t_.values_.__cntrl_;
  v12.l_.a3_.t_.values_.__cntrl_ = (std::__shared_weak_count *)v5;
  if ( v5 )
    _InterlockedAdd64(v5 + 1, 1u);
  v12.l_.a3_.t_.index_ = handler->l_.a3_.t_.index_;
  boost::asio::detail::reactive_socket_service<boost::asio::ip::tcp>::async_connect<boost::_bi::bind_t<void,boost::_mfi::mf2<void,web::http::client::details::asio_context,boost::system::error_code const&,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>,boost::_bi::list3<boost::_bi::value<std::shared_ptr<web::http::client::details::asio_context>>,boost::arg<1> (*)(void),boost::_bi::value<boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp>>>>>(
    &this->service_impl_,
    impl,
    peer_endpoint,
    &v12);
  v10 = v12.l_.a3_.t_.values_.__cntrl_;
  if ( v12.l_.a3_.t_.values_.__cntrl_
    && !_InterlockedExchangeAdd64((volatile signed __int64 *)v12.l_.a3_.t_.values_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
  {
    (*(void (__fastcall **)(std::__shared_weak_count *, boost::asio::stream_socket_service<boost::asio::ip::tcp>::implementation_type *, __int64, __int64, __int64, __int64, boost::_mfi::mf2<void,web::http::client::details::asio_context,const boost::system::error_code &,boost::asio::ip::basic_resolver_iterator<boost::asio::ip::tcp> >::F, _QWORD, std::shared_ptr<web::http::client::details::asio_context>::element_type *))(*(_QWORD *)v10 + 16LL))(
      v10,
      impl,
      v6,
      v7,
      v8,
      v9,
      v12.f_.f_,
      *((_QWORD *)&v12.f_.f_ + 1),
      v12.l_.a1_.t_.__ptr_);
    std::__shared_weak_count::__release_weak(v10);
  }
  v11 = v12.l_.a1_.t_.__cntrl_;
  if ( v12.l_.a1_.t_.__cntrl_ )
  {
    if ( !_InterlockedExchangeAdd64((volatile signed __int64 *)v12.l_.a1_.t_.__cntrl_ + 1, 0xFFFFFFFFFFFFFFFFLL) )
    {
      (*(void (__fastcall **)(std::__shared_weak_count *))(*(_QWORD *)v11 + 16LL))(v11);
      std::__shared_weak_count::__release_weak(v11);
    }
  }
}


