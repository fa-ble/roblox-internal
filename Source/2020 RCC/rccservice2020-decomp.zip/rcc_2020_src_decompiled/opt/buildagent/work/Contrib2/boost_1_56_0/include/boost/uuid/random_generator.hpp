// Address: 0x1281600 | Name: _ZN5boost5uuids22basic_random_generatorINS_6random23mersenne_twister_engineIjLm32ELm624ELm397ELm31ELj2567483615ELm11ELj4294967295ELm7ELj2636928640ELm15ELj4022730752ELm18ELj1812433253EEEEC2Ev
void __fastcall boost::uuids::basic_random_generator<boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>>::basic_random_generator(
        boost::uuids::basic_random_generator<boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> > *this)
{
  boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> *v2; // rax
  unsigned int v3; // esi
  int v4; // ecx
  __int64 i; // rdx
  int v6; // edi
  unsigned int v7; // ebx
  int v8; // ecx
  int v9; // esi
  unsigned int v10; // esi
  unsigned __int64 v11; // rcx
  boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> *px; // rbx
  boost::uuids::detail::seed_rng v14; // [rsp+0h] [rbp-48h] BYREF
  boost::uuids::detail::generator_iterator<boost::uuids::detail::seed_rng> first; // [rsp+20h] [rbp-28h] BYREF
  boost::uuids::detail::generator_iterator<boost::uuids::detail::seed_rng> v16; // 0:rdx.12

  v2 = (boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> *)operator new(0x9C8u);
  v2->x[0] = 5489;
  v2->i = 1;
  v3 = 5489;
  v4 = 1;
  for ( i = 2; ; i += 2 )
  {
    v7 = v4 + 1812433253 * (v3 ^ (v3 >> 30));
    v2->x[i - 1] = v7;
    if ( i == 624 )
      break;
    v6 = 1812433253 * (v7 ^ (v7 >> 30));
    v3 = v6 + v4 + 1;
    v2->x[i] = i + v6;
    v4 += 2;
  }
  v2->i = 624;
  v8 = v2->x[396] ^ v2->x[623];
  v9 = (2 * v8) ^ 0x321161BF;
  if ( v8 >= 0 )
    v9 = 2 * v8;
  v10 = v2->x[0] & 0x80000000 | v9 & 0x7FFFFFFF;
  v2->x[0] = v10;
  if ( !v10 )
  {
    v11 = 1;
    while ( v11 <= 0x26F )
    {
      if ( v2->x[v11++] != 0 )
        goto LABEL_12;
    }
    v2->x[0] = 0x80000000;
  }
LABEL_12:
  this->pURNG.px = v2;
  this->pURNG.pn.pi_ = 0;
  boost::detail::sp_pointer_construct<boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>,boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>>(
    &this->pURNG,
    v2,
    &this->pURNG.pn);
  px = this->pURNG.px;
  this->generator._eng = this->pURNG.px;
  this->generator._dist = (boost::random::variate_generator<boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> *,boost::uniform_int<unsigned long> >::distribution_type)_mm_slli_si128((__m128i)0xFFFFFFFFFFFFFFFFLL, 8);
  v14.rd_index_ = 5;
  v14.random_ = fopen("/dev/urandom", "rb");
  first.m_g = &v14;
  boost::uuids::detail::seed_rng::sha1_random_digest_(&v14);
  v14.rd_index_ = 1;
  first.m_value = v14.rd_[0];
  v16.m_g = 0;
  v16.m_value = 0;
  boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>::seed<boost::uuids::detail::generator_iterator<boost::uuids::detail::seed_rng>>(
    px,
    &first,
    v16);
  if ( v14.random_ )
    fclose(v14.random_);
}


// Address: 0x1281800 | Name: _ZN5boost5uuids22basic_random_generatorINS_6random23mersenne_twister_engineIjLm32ELm624ELm397ELm31ELj2567483615ELm11ELj4294967295ELm7ELj2636928640ELm15ELj4022730752ELm18ELj1812433253EEEED2Ev
void __fastcall boost::uuids::basic_random_generator<boost::random::mersenne_twister_engine<unsigned int,32ul,624ul,397ul,31ul,2567483615u,11ul,4294967295u,7ul,2636928640u,15ul,4022730752u,18ul,1812433253u>>::~basic_random_generator(
        boost::uuids::basic_random_generator<boost::random::mersenne_twister_engine<unsigned int,32,624,397,31,2567483615,11,4294967295,7,2636928640,15,4022730752,18,1812433253> > *this)
{
  boost::detail::sp_counted_base *pi; // rbx

  pi = this->pURNG.pn.pi_;
  if ( pi && !_InterlockedSub(&pi->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


