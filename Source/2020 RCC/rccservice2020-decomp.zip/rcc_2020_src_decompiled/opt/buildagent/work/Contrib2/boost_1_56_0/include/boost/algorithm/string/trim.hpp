// Address: 0x1015c90 | Name: _ZN5boost9algorithm7trim_ifINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS0_6detail14is_classifiedFEEEvRT_T0_
// local variable allocation has failed, the output may be wrong!
void __fastcall boost::algorithm::trim_if<std::string,boost::algorithm::detail::is_classifiedF>(
        std::string *Input,
        boost::algorithm::detail::is_classifiedF IsSpace)
{
  std::ctype_base::mask *v2; // rbx
  const std::locale *v3; // r15
  boost::algorithm::detail::is_classifiedF *p_IsSpacea; // rsi
  boost::algorithm::detail::is_classifiedF v5; // kr00_16
  boost::algorithm::detail::is_classifiedF *v6; // rsi
  boost::algorithm::detail::is_classifiedF v7; // kr10_16
  std::locale::__imp *v8; // rdx
  std::locale::__imp *v9; // rdx
  boost::algorithm::detail::is_classifiedF v10; // [rsp+8h] [rbp-40h] BYREF
  boost::algorithm::detail::is_classifiedF IsSpacea; // [rsp+18h] [rbp-30h] BYREF

  v2 = *(std::ctype_base::mask **)&IsSpace.m_Type;
  IsSpacea.m_Type = **(_WORD **)&IsSpace.m_Type;
  v3 = (const std::locale *)(*(_QWORD *)&IsSpace.m_Type + 8LL);
  std::locale::locale(&IsSpacea.m_Locale, (const std::locale *)(*(_QWORD *)&IsSpace.m_Type + 8LL));
  p_IsSpacea = &IsSpacea;
  v5.m_Type = (unsigned __int16)p_IsSpacea;
  v5.m_Locale.__locale_ = v8;
  boost::algorithm::trim_right_if<std::string,boost::algorithm::detail::is_classifiedF>(Input, v5);
  std::locale::~locale(&IsSpacea.m_Locale);
  v10.m_Type = *v2;
  std::locale::locale(&v10.m_Locale, v3);
  v6 = &v10;
  v7.m_Type = (unsigned __int16)v6;
  v7.m_Locale.__locale_ = v9;
  boost::algorithm::trim_left_if<std::string,boost::algorithm::detail::is_classifiedF>(Input, v7);
  std::locale::~locale(&v10.m_Locale);
}


// Address: 0x1015d30 | Name: _ZN5boost9algorithm13trim_right_ifINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS0_6detail14is_classifiedFEEEvRT_T0_
// local variable allocation has failed, the output may be wrong!
void __fastcall boost::algorithm::trim_right_if<std::string,boost::algorithm::detail::is_classifiedF>(
        std::string *Input,
        boost::algorithm::detail::is_classifiedF IsSpace)
{
  unsigned __int64 v2; // r15
  char *v3; // r14
  unsigned __int64 v4; // r15
  char *v5; // rbx
  unsigned __int64 v6; // rbp
  __int64 v7; // r12
  __int64 v8; // rax
  unsigned __int64 v9; // rdx
  char *v10; // rax
  unsigned __int64 v11; // rdx
  unsigned __int16 v12; // [rsp+8h] [rbp-60h]
  std::locale v13; // [rsp+10h] [rbp-58h] BYREF
  unsigned __int16 v14; // [rsp+18h] [rbp-50h]
  std::locale v15; // [rsp+20h] [rbp-48h] BYREF
  char *v16; // [rsp+28h] [rbp-40h]
  std::string *v17; // [rsp+30h] [rbp-38h]

  v2 = *(unsigned __int8 *)Input;
  v3 = (char *)Input + 1;
  v17 = Input;
  v16 = (char *)Input + 1;
  if ( (v2 & 1) != 0 )
  {
    v3 = (char *)*((_QWORD *)Input + 2);
    v4 = *((_QWORD *)Input + 1);
  }
  else
  {
    v4 = v2 >> 1;
  }
  v5 = &v3[v4];
  v14 = **(_WORD **)&IsSpace.m_Type;
  std::locale::locale(&v15, (const std::locale *)(*(_QWORD *)&IsSpace.m_Type + 8LL));
  v12 = v14;
  std::locale::locale(&v13, &v15);
  while ( v4 )
  {
    v6 = v4;
    v7 = v3[v4 - 1];
    v8 = std::locale::use_facet(&v13, &std::ctype<char>::id);
    if ( (v7 & 0x80u) != 0LL )
    {
      v3 = v5;
      break;
    }
    --v5;
    --v4;
    if ( (v12 & *(_WORD *)(*(_QWORD *)(v8 + 16) + 2 * v7)) == 0 )
    {
      v3 += v6;
      break;
    }
  }
  std::locale::~locale(&v13);
  v9 = *(unsigned __int8 *)v17;
  if ( (v9 & 1) != 0 )
  {
    v10 = (char *)*((_QWORD *)v17 + 2);
    v11 = *((_QWORD *)v17 + 1);
  }
  else
  {
    v11 = v9 >> 1;
    v10 = v16;
  }
  std::string::erase(v17, v3 - v10, &v10[v11] - v3);
  std::locale::~locale(&v15);
}


// Address: 0x1015e60 | Name: _ZN5boost9algorithm12trim_left_ifINSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS0_6detail14is_classifiedFEEEvRT_T0_
// local variable allocation has failed, the output may be wrong!
void __fastcall boost::algorithm::trim_left_if<std::string,boost::algorithm::detail::is_classifiedF>(
        std::string *Input,
        boost::algorithm::detail::is_classifiedF IsSpace)
{
  char *v2; // r14
  unsigned __int64 v3; // rbp
  char *v4; // r12
  char *v5; // rbx
  __int64 v6; // r14
  __int64 v7; // rax
  unsigned __int16 v8; // [rsp+10h] [rbp-48h]
  std::locale v9; // [rsp+18h] [rbp-40h] BYREF
  char *v10; // [rsp+20h] [rbp-38h]

  v2 = (char *)Input + 1;
  v3 = (unsigned __int64)*(unsigned __int8 *)Input >> 1;
  v4 = (char *)*((_QWORD *)Input + 2);
  if ( (*(_BYTE *)Input & 1) != 0 )
    v3 = *((_QWORD *)Input + 1);
  else
    v4 = (char *)Input + 1;
  v8 = **(_WORD **)&IsSpace.m_Type;
  std::locale::locale(&v9, (const std::locale *)(*(_QWORD *)&IsSpace.m_Type + 8LL));
  if ( !v3 )
  {
    v5 = v4;
    if ( (*(_BYTE *)Input & 1) == 0 )
      goto LABEL_12;
    goto LABEL_11;
  }
  v10 = &v4[v3];
  v5 = v4;
  while ( 1 )
  {
    v6 = *v5;
    v7 = std::locale::use_facet(&v9, &std::ctype<char>::id);
    if ( (v6 & 0x80u) != 0LL || (v8 & *(_WORD *)(*(_QWORD *)(v7 + 16) + 2 * v6)) == 0 )
      break;
    ++v5;
    if ( !--v3 )
    {
      v5 = v10;
      break;
    }
  }
  v2 = (char *)Input + 1;
  if ( (*(_BYTE *)Input & 1) != 0 )
LABEL_11:
    v2 = (char *)*((_QWORD *)Input + 2);
LABEL_12:
  std::string::erase(Input, v4 - v2, v5 - v4);
  std::locale::~locale(&v9);
}


