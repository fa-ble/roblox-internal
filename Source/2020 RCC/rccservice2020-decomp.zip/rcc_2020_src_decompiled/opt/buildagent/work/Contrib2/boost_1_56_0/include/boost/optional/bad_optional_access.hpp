// Address: 0x14b9270 | Name: _ZN5boost19bad_optional_accessD0Ev
void __fastcall boost::bad_optional_access::~bad_optional_access(boost::bad_optional_access *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


