// Address: 0xdc12c0 | Name: _ZN5boost16exception_detail15error_info_baseD2Ev
void __fastcall boost::exception_detail::error_info_base::~error_info_base(
        boost::exception_detail::error_info_base *this)
{
  ;
}


