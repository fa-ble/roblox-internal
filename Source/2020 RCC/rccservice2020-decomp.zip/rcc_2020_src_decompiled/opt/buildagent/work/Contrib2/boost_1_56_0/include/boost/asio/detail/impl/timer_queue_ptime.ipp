// Address: 0x26059f0 | Name: _ZN5boost4asio6detail11timer_queueINS0_11time_traitsINS_10posix_time5ptimeEEEED2Ev
void __fastcall boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime>>::~timer_queue(
        boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *this)
{
  void *v1; // rax

  *(_QWORD *)this = &off_29C3188;
  *((_QWORD *)this + 2) = &off_29C3218;
  v1 = (void *)*((_QWORD *)this + 5);
  if ( v1 )
  {
    *((_QWORD *)this + 6) = v1;
    operator delete(v1);
  }
}


// Address: 0x2605a20 | Name: _ZN5boost4asio6detail11timer_queueINS0_11time_traitsINS_10posix_time5ptimeEEEED0Ev
void __fastcall boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime>>::~timer_queue(
        boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *this)
{
  void *v2; // rdi

  *(_QWORD *)this = &off_29C3188;
  *((_QWORD *)this + 2) = &off_29C3218;
  v2 = (void *)*((_QWORD *)this + 5);
  if ( v2 )
  {
    *((_QWORD *)this + 6) = v2;
    operator delete(v2);
  }
  operator delete(this);
}


// Address: 0x2605a70 | Name: _ZNK5boost4asio6detail11timer_queueINS0_11time_traitsINS_10posix_time5ptimeEEEE18wait_duration_msecEl
__int64 __fastcall boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime>>::wait_duration_msec(
        const boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        __int64 max_duration)
{
  __int64 *v3; // rbx
  boost::posix_time::ptime v4; // rax
  __int64 v5; // rcx
  unsigned __int64 v6; // rcx
  __int64 result; // rax
  unsigned __int64 v8; // rdi
  __int64 v9; // rsi

  v3 = (__int64 *)*((_QWORD *)this + 5);
  if ( v3 == *((__int64 **)this + 6) )
    return max_duration;
  v4.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
  v5 = *v3;
  if ( (unsigned __int64)(v4.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) >= 3
    && (unsigned __int64)(v5 - 0x7FFFFFFFFFFFFFFELL) > 2 )
  {
    v6 = v5 - v4.time_.time_count_.value_;
    goto LABEL_5;
  }
  if ( v5 != 0x8000000000000000LL )
  {
    if ( v5 == 0x7FFFFFFFFFFFFFFELL )
      goto LABEL_35;
    if ( v5 != 0x7FFFFFFFFFFFFFFFLL && (unsigned __int64)(v4.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) > 2 )
    {
LABEL_30:
      v5 -= v4.time_.time_count_.value_;
      goto LABEL_31;
    }
  }
  if ( v4.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFELL )
  {
LABEL_35:
    if ( max_duration > 0x20C49BA5E353F7LL )
      return 0x20C49BA5E353F7LL;
    return max_duration;
  }
  v8 = v5 - 0x7FFFFFFFFFFFFFFFLL;
  if ( v5 == 0x8000000000000000LL )
  {
    if ( v4.time_.time_count_.value_ == 0x8000000000000000LL || v8 <= 1 )
    {
      if ( v4.time_.time_count_.value_ != 0x8000000000000000LL )
        return 0;
      goto LABEL_35;
    }
    goto LABEL_27;
  }
  if ( v5 != 0x7FFFFFFFFFFFFFFFLL )
  {
    if ( v8 < 2 )
    {
LABEL_31:
      v9 = v5;
      goto LABEL_32;
    }
LABEL_27:
    if ( v4.time_.time_count_.value_ != 0x8000000000000000LL )
    {
      if ( v4.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
        return 0;
      goto LABEL_30;
    }
    goto LABEL_35;
  }
  v9 = 0x7FFFFFFFFFFFFFFFLL;
  if ( v4.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
  {
    v9 = 0x7FFFFFFFFFFFFFFELL;
    goto LABEL_32;
  }
  if ( v8 >= 2 )
    goto LABEL_27;
LABEL_32:
  v6 = 0x8000000000000000LL;
  if ( v9 != 0x8000000000000000LL )
    v6 = 0x7FFFFFFFFFFFFFFELL;
  if ( v9 == 0x7FFFFFFFFFFFFFFFLL )
    goto LABEL_35;
LABEL_5:
  if ( (__int64)v6 <= 0 )
    return 0;
  if ( (__int64)(v6 / 0x3E8) <= max_duration )
    max_duration = v6 / 0x3E8;
  result = 1;
  if ( v6 >= 0x3E8 )
    return max_duration;
  return result;
}


// Address: 0x2605bd0 | Name: _ZNK5boost4asio6detail11timer_queueINS0_11time_traitsINS_10posix_time5ptimeEEEE18wait_duration_usecEl
__int64 __fastcall boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime>>::wait_duration_usec(
        const boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        __int64 max_duration)
{
  __int64 v2; // r15
  __int64 *v3; // rbx
  __int64 v4; // r14
  boost::posix_time::ptime v5; // rax
  __int64 v6; // rcx
  __int64 v7; // rax
  unsigned __int64 v8; // rdi
  __int64 v9; // rsi

  v2 = max_duration;
  v3 = (__int64 *)*((_QWORD *)this + 5);
  if ( v3 == *((__int64 **)this + 6) )
    return v2;
  v4 = 0x7FFFFFFFFFFFFFFELL;
  v5.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
  v6 = *v3;
  if ( (unsigned __int64)(v5.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) >= 3
    && (unsigned __int64)(v6 - 0x7FFFFFFFFFFFFFFELL) > 2 )
  {
    v7 = v6 - v5.time_.time_count_.value_;
    goto LABEL_5;
  }
  if ( v6 != 0x8000000000000000LL )
  {
    if ( v6 == 0x7FFFFFFFFFFFFFFELL )
      goto LABEL_35;
    if ( v6 != 0x7FFFFFFFFFFFFFFFLL && (unsigned __int64)(v5.time_.time_count_.value_ - 0x7FFFFFFFFFFFFFFELL) > 2 )
    {
LABEL_30:
      v6 -= v5.time_.time_count_.value_;
      goto LABEL_31;
    }
  }
  if ( v5.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFELL )
  {
LABEL_14:
    v6 = v4;
LABEL_35:
    if ( v6 <= v2 )
      return v6;
    return v2;
  }
  v8 = v6 - 0x7FFFFFFFFFFFFFFFLL;
  if ( v6 == 0x8000000000000000LL )
  {
    if ( v5.time_.time_count_.value_ == 0x8000000000000000LL || v8 <= 1 )
    {
      if ( v5.time_.time_count_.value_ == 0x8000000000000000LL )
      {
        if ( max_duration == 0x7FFFFFFFFFFFFFFFLL )
          return 0x7FFFFFFFFFFFFFFELL;
        return v2;
      }
      return 0;
    }
LABEL_28:
    if ( v5.time_.time_count_.value_ == 0x8000000000000000LL )
    {
      v4 = 0x7FFFFFFFFFFFFFFFLL;
      goto LABEL_14;
    }
    if ( v5.time_.time_count_.value_ != 0x7FFFFFFFFFFFFFFFLL )
      goto LABEL_30;
    return 0;
  }
  if ( v6 != 0x7FFFFFFFFFFFFFFFLL )
  {
    if ( v8 < 2 )
    {
LABEL_31:
      v9 = v6;
      goto LABEL_32;
    }
    goto LABEL_28;
  }
  v9 = 0x7FFFFFFFFFFFFFFFLL;
  if ( v5.time_.time_count_.value_ == 0x7FFFFFFFFFFFFFFFLL )
  {
    v9 = 0x7FFFFFFFFFFFFFFELL;
    goto LABEL_32;
  }
  if ( v8 >= 2 )
    goto LABEL_28;
LABEL_32:
  v7 = 0x8000000000000000LL;
  if ( v9 != 0x8000000000000000LL )
    v7 = 0x7FFFFFFFFFFFFFFELL;
  v6 = 0x7FFFFFFFFFFFFFFFLL;
  if ( v9 == 0x7FFFFFFFFFFFFFFFLL )
    goto LABEL_35;
LABEL_5:
  if ( v7 <= v2 )
    v2 = v7;
  if ( v7 <= 0 )
    return 0;
  return v2;
}


// Address: 0x2605d30 | Name: _ZN5boost4asio6detail11timer_queueINS0_11time_traitsINS_10posix_time5ptimeEEEE16get_ready_timersERNS1_8op_queueINS1_25task_io_service_operationEEE
void __fastcall boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime>>::get_ready_timers(
        boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *this,
        boost::asio::detail::op_queue<boost::asio::detail::task_io_service_operation> *ops)
{
  boost::posix_time::ptime v3; // r15
  boost::date_time::int_adapter<long>::int_type *i; // rax
  boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::per_timer_data *v5; // rsi
  _QWORD *p_next; // rcx

  if ( *((_QWORD *)this + 5) != *((_QWORD *)this + 6) )
  {
    v3.time_.time_count_.value_ = boost::date_time::microsec_clock<boost::posix_time::ptime>::create_time(boost::date_time::c_time::gmtime).time_.time_count_.value_;
    for ( i = (boost::date_time::int_adapter<long>::int_type *)*((_QWORD *)this + 5);
          i != *((boost::date_time::int_adapter<long>::int_type **)this + 6);
          i = (boost::date_time::int_adapter<long>::int_type *)*((_QWORD *)this + 5) )
    {
      if ( v3.time_.time_count_.value_ < *i )
        break;
      v5 = (boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::per_timer_data *)i[1];
      if ( v5->op_queue_.front_ )
      {
        p_next = &ops->back_->next_;
        if ( !p_next )
          p_next = &ops->front_;
        *p_next = v5->op_queue_.front_;
        ops->back_ = v5->op_queue_.back_;
        v5->op_queue_ = 0;
      }
      boost::asio::detail::timer_queue<boost::asio::detail::forwarding_posix_time_traits>::remove_timer(
        (boost::asio::detail::timer_queue<boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this + 16),
        v5);
    }
  }
}


