// Address: 0x2842820 | Name: _ZN5boost13thread_detail17enter_once_regionERNS_9once_flagE
bool __fastcall boost::thread_detail::enter_once_region(boost::once_flag *flag)
{
  char v1; // bl
  int v2; // ebp
  signed __int32 v4; // eax

  if ( flag->storage == 2 )
    goto LABEL_5;
  v1 = (char)flag;
  pthread_mutex_lock(&stru_2CE5670);
  if ( flag->storage == 2 )
  {
    v2 = 0;
  }
  else
  {
    while ( 1 )
    {
      v2 = 1;
      v4 = _InterlockedCompareExchange((volatile signed __int32 *)flag, 1, 0);
      if ( !v4 )
      {
        v1 = 1;
        goto LABEL_4;
      }
      if ( v4 == 2 )
        break;
      pthread_cond_wait(&cond, &stru_2CE5670);
    }
    v1 = 0;
  }
LABEL_4:
  pthread_mutex_unlock(&stru_2CE5670);
  if ( !v2 )
LABEL_5:
    v1 = 0;
  return v1 & 1;
}


// Address: 0x28428e0 | Name: _ZN5boost13thread_detail18commit_once_regionERNS_9once_flagE
void __fastcall boost::thread_detail::commit_once_region(boost::once_flag *flag)
{
  pthread_mutex_lock(&stru_2CE5670);
  flag->storage = 2;
  pthread_mutex_unlock(&stru_2CE5670);
  pthread_cond_broadcast(&cond);
}


// Address: 0x2842920 | Name: _ZN5boost13thread_detail20rollback_once_regionERNS_9once_flagE
void __fastcall boost::thread_detail::rollback_once_region(boost::once_flag *flag)
{
  pthread_mutex_lock(&stru_2CE5670);
  flag->storage = 0;
  pthread_mutex_unlock(&stru_2CE5670);
  pthread_cond_broadcast(&cond);
}


