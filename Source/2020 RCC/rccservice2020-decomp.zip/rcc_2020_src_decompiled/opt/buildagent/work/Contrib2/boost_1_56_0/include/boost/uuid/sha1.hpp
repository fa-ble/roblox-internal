// Address: 0x12824e0 | Name: _ZN5boost5uuids6detail4sha110get_digestERA5_j
void __fastcall boost::uuids::detail::sha1::get_digest(
        boost::uuids::detail::sha1 *this,
        boost::uuids::detail::sha1::digest_type digest)
{
  size_t block_byte_index; // rax
  size_t v3; // rax
  unsigned __int8 v4; // cl
  size_t v5; // rax
  unsigned __int8 v6; // cl
  size_t v7; // rax
  unsigned __int8 v8; // cl
  size_t v9; // rax
  unsigned __int8 bit_count_high; // cl
  size_t v11; // rax
  unsigned __int8 v12; // cl
  size_t v13; // rax
  unsigned __int8 v14; // cl
  size_t v15; // rax
  unsigned __int8 v16; // cl
  size_t v17; // rax
  unsigned __int8 bit_count_low; // cl

  block_byte_index = this->block_byte_index_;
  this->block_byte_index_ = block_byte_index + 1;
  this->block_[block_byte_index] = 0x80;
  v3 = this->block_byte_index_;
  if ( v3 == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
    v3 = this->block_byte_index_;
  }
  if ( v3 < 0x39 )
  {
    if ( v3 == 56 )
    {
      v3 = 56;
    }
    else
    {
      do
      {
        this->block_byte_index_ = v3 + 1;
        this->block_[v3] = 0;
        v3 = this->block_byte_index_;
        if ( v3 == 64 )
        {
          this->block_byte_index_ = 0;
          boost::uuids::detail::sha1::process_block(this);
          v3 = this->block_byte_index_;
        }
      }
      while ( v3 < 0x38 );
    }
  }
  else
  {
    do
    {
      this->block_byte_index_ = v3 + 1;
      this->block_[v3] = 0;
      v3 = this->block_byte_index_;
      if ( v3 == 64 )
      {
        this->block_byte_index_ = 0;
        boost::uuids::detail::sha1::process_block(this);
        v3 = this->block_byte_index_;
      }
    }
    while ( v3 );
    v3 = 0;
    do
    {
      this->block_byte_index_ = v3 + 1;
      this->block_[v3] = 0;
      v3 = this->block_byte_index_;
      if ( v3 == 64 )
      {
        this->block_byte_index_ = 0;
        boost::uuids::detail::sha1::process_block(this);
        v3 = this->block_byte_index_;
      }
    }
    while ( v3 < 0x38 );
  }
  v4 = BYTE3(this->bit_count_high);
  this->block_byte_index_ = v3 + 1;
  this->block_[v3] = v4;
  v5 = this->block_byte_index_;
  if ( v5 == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
    v5 = this->block_byte_index_;
  }
  v6 = BYTE2(this->bit_count_high);
  this->block_byte_index_ = v5 + 1;
  this->block_[v5] = v6;
  v7 = this->block_byte_index_;
  if ( v7 == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
    v7 = this->block_byte_index_;
  }
  v8 = BYTE1(this->bit_count_high);
  this->block_byte_index_ = v7 + 1;
  this->block_[v7] = v8;
  v9 = this->block_byte_index_;
  if ( v9 == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
    v9 = this->block_byte_index_;
  }
  bit_count_high = this->bit_count_high;
  this->block_byte_index_ = v9 + 1;
  this->block_[v9] = bit_count_high;
  v11 = this->block_byte_index_;
  if ( v11 == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
    v11 = this->block_byte_index_;
  }
  v12 = BYTE3(this->bit_count_low);
  this->block_byte_index_ = v11 + 1;
  this->block_[v11] = v12;
  v13 = this->block_byte_index_;
  if ( v13 == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
    v13 = this->block_byte_index_;
  }
  v14 = BYTE2(this->bit_count_low);
  this->block_byte_index_ = v13 + 1;
  this->block_[v13] = v14;
  v15 = this->block_byte_index_;
  if ( v15 == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
    v15 = this->block_byte_index_;
  }
  v16 = BYTE1(this->bit_count_low);
  this->block_byte_index_ = v15 + 1;
  this->block_[v15] = v16;
  v17 = this->block_byte_index_;
  if ( v17 == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
    v17 = this->block_byte_index_;
  }
  bit_count_low = this->bit_count_low;
  this->block_byte_index_ = v17 + 1;
  this->block_[v17] = bit_count_low;
  if ( this->block_byte_index_ == 64 )
  {
    this->block_byte_index_ = 0;
    boost::uuids::detail::sha1::process_block(this);
  }
  (*digest)[0] = this->h_[0];
  (*digest)[1] = this->h_[1];
  (*digest)[2] = this->h_[2];
  (*digest)[3] = this->h_[3];
  (*digest)[4] = this->h_[4];
}


// Address: 0x1282800 | Name: _ZN5boost5uuids6detail4sha113process_blockEv
void __fastcall boost::uuids::detail::sha1::process_block(boost::uuids::detail::sha1 *this)
{
  __m128i v1; // xmm1
  __m128i si128; // xmm0
  __m128i v3; // xmm1
  __m128i v4; // xmm1
  __m128i v5; // xmm1
  __int64 i; // rax
  __m128i v7; // xmm0
  unsigned int v8; // r8d
  unsigned int v9; // eax
  int v10; // edx
  int v11; // ebp
  int v12; // ebx
  unsigned __int64 v13; // r14
  unsigned int v14; // esi
  unsigned int v15; // r10d
  unsigned int v16; // r11d
  int v17; // r9d
  int v18; // eax
  int v19; // ebx
  unsigned int v20; // ecx
  _OWORD v21[2]; // [rsp+0h] [rbp-158h]
  __m128i v22; // [rsp+20h] [rbp-138h]
  _OWORD v23[18]; // [rsp+30h] [rbp-128h]

  v1 = _mm_loadu_si128((const __m128i *)this->block_);
  si128 = _mm_load_si128((const __m128i *)&xmmword_3E58A0);
  v21[0] = _mm_or_si128(
             _mm_or_si128(
               _mm_srli_epi32(v1, 0x18u),
               _mm_slli_epi32(_mm_and_si128(_mm_srli_epi32(v1, 0x10u), si128), 8u)),
             _mm_or_si128(
               _mm_slli_epi32(_mm_and_si128(_mm_srli_epi16(v1, 8u), si128), 0x10u),
               _mm_slli_epi32(v1, 0x18u)));
  v3 = _mm_loadu_si128((const __m128i *)&this->block_[16]);
  v21[1] = _mm_or_si128(
             _mm_or_si128(
               _mm_srli_epi32(v3, 0x18u),
               _mm_slli_epi32(_mm_and_si128(_mm_srli_epi32(v3, 0x10u), si128), 8u)),
             _mm_or_si128(
               _mm_slli_epi32(_mm_and_si128(_mm_srli_epi16(v3, 8u), si128), 0x10u),
               _mm_slli_epi32(v3, 0x18u)));
  v4 = _mm_loadu_si128((const __m128i *)&this->block_[32]);
  v22 = _mm_or_si128(
          _mm_or_si128(_mm_srli_epi32(v4, 0x18u), _mm_slli_epi32(_mm_and_si128(_mm_srli_epi32(v4, 0x10u), si128), 8u)),
          _mm_or_si128(_mm_slli_epi32(_mm_and_si128(_mm_srli_epi16(v4, 8u), si128), 0x10u), _mm_slli_epi32(v4, 0x18u)));
  v5 = _mm_loadu_si128((const __m128i *)&this->block_[48]);
  v23[0] = _mm_or_si128(
             _mm_or_si128(
               _mm_srli_epi32(v5, 0x18u),
               _mm_slli_epi32(_mm_and_si128(_mm_srli_epi32(v5, 0x10u), si128), 8u)),
             _mm_or_si128(
               _mm_slli_epi32(_mm_and_si128(_mm_srli_epi16(v5, 8u), si128), 0x10u),
               _mm_slli_epi32(v5, 0x18u)));
  for ( i = 0; i != 64; ++i )
    *((_DWORD *)&v23[1] + i) = __ROL4__(
                                 *((_DWORD *)v21 + i)
                               ^ *((_DWORD *)v21 + i + 2)
                               ^ *((_DWORD *)v23 + i + 1)
                               ^ v22.m128i_i32[i],
                                 1);
  v7 = _mm_loadu_si128((const __m128i *)this);
  v8 = this->h_[4];
  v9 = _mm_cvtsi128_si32(v7);
  v10 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v7, 229));
  v11 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v7, 78));
  v12 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v7, 231));
  v13 = 0;
  v14 = v8;
  do
  {
    v15 = v9;
    v16 = v11;
    v17 = v12;
    if ( v13 > 0x13 )
    {
      if ( v13 > 0x27 )
      {
        if ( v13 > 0x3B )
        {
          v18 = v12 ^ v10 ^ v11;
          v19 = -899497514;
        }
        else
        {
          v18 = v10 & (v11 | v12) | v11 & v12;
          v19 = -1894007588;
        }
      }
      else
      {
        v18 = v12 ^ v10 ^ v11;
        v19 = 1859775393;
      }
    }
    else
    {
      v18 = v10 & v11 | v12 & ~v10;
      v19 = 1518500249;
    }
    v9 = *((_DWORD *)v21 + v13) + v19 + v18 + __ROL4__(v15, 5) + v14;
    v20 = __ROL4__(v10, 30);
    ++v13;
    v14 = v17;
    v12 = v11;
    v11 = v20;
    v10 = v15;
  }
  while ( v13 != 80 );
  *(__m128i *)this->h_ = _mm_add_epi32(
                           _mm_unpacklo_epi64(
                             _mm_unpacklo_epi32(_mm_cvtsi32_si128(v9), _mm_cvtsi32_si128(v15)),
                             _mm_unpacklo_epi32(_mm_cvtsi32_si128(v20), _mm_cvtsi32_si128(v16))),
                           v7);
  this->h_[4] = v8 + v17;
}


