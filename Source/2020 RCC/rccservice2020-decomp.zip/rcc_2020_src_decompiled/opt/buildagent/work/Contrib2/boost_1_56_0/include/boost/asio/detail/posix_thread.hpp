// Address: 0x261ec10 | Name: _ZN5boost4asio6detail12posix_thread9func_baseD2Ev
void __fastcall boost::asio::detail::posix_thread::func_base::~func_base(
        boost::asio::detail::posix_thread::func_base *this)
{
  ;
}


// Address: 0x261ec20 | Name: _ZN5boost4asio6detail12posix_thread4funcINS1_21resolver_service_base22work_io_service_runnerEED0Ev
// Alternative name is 'j__ZdlPv_2003'
// attributes: thunk
void __fastcall boost::asio::detail::posix_thread::func<boost::asio::detail::resolver_service_base::work_io_service_runner>::~func(
        boost::asio::detail::posix_thread::func<boost::asio::detail::resolver_service_base::work_io_service_runner> *this)
{
  operator delete(this);
}


// Address: 0x261ec30 | Name: _ZN5boost4asio6detail12posix_thread4funcINS1_21resolver_service_base22work_io_service_runnerEE3runEv
void __fastcall boost::asio::detail::posix_thread::func<boost::asio::detail::resolver_service_base::work_io_service_runner>::run(
        boost::asio::detail::posix_thread::func<boost::asio::detail::resolver_service_base::work_io_service_runner> *this)
{
  boost::asio::detail::resolver_service_base::work_io_service_runner::operator()(&this->f_);
}


