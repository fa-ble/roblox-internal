// Address: 0xd9de40 | Name: _ZN5boost16exception_detail10clone_implINS0_10bad_alloc_EEC1ERKS2_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this,
        const boost::exception_detail::bad_alloc_ *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  v3 = *((_QWORD *)x + 1);
  *((_QWORD *)this + 1) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 8) = *((_DWORD *)x + 8);
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = &off_2875530;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_2875560,
                                      (__m128i)(unsigned __int64)&off_28755A0);
  boost::exception_detail::copy_boost_exception((boost::exception *)this, (const boost::exception *)x);
}


// Address: 0xd9df10 | Name: _ZN5boost16exception_detail10clone_implINS0_10bad_alloc_EEC1ERKS3_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  v3 = *((_QWORD *)a2 + 1);
  *((_QWORD *)this + 1) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 8) = *((_DWORD *)a2 + 8);
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = &off_2875530;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_2875560,
                                      (__m128i)(unsigned __int64)&off_28755A0);
}


// Address: 0xd9df90 | Name: _ZN5boost16exception_detail10clone_implINS0_10bad_alloc_EED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  __int64 v2; // rdi

  std::bad_alloc::~bad_alloc((boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this + 1) = 0;
  }
}


// Address: 0xd9e0d0 | Name: _ZN5boost16exception_detail20copy_boost_exceptionEPNS_9exceptionEPKS1_
void __fastcall boost::exception_detail::copy_boost_exception(boost::exception *a, const boost::exception *b)
{
  boost::exception_detail::error_info_container *px; // rsi
  boost::exception_detail::error_info_container *v5; // r14
  boost::exception_detail::error_info_container *v6; // rdi
  boost::exception_detail::error_info_container *v7; // [rsp+8h] [rbp-20h] BYREF

  px = b->data_.px_;
  if ( px )
  {
    (*((void (__fastcall **)(boost::exception_detail::error_info_container **))px->_vptr$error_info_container + 5))(&v7);
    v5 = v7;
    if ( v7 )
    {
      (*((void (__fastcall **)(boost::exception_detail::error_info_container *))v7->_vptr$error_info_container + 3))(v7);
      if ( v7 )
      {
        if ( (*((unsigned __int8 (__fastcall **)(boost::exception_detail::error_info_container *))v7->_vptr$error_info_container
              + 4))(v7) )
          v7 = 0;
      }
    }
  }
  else
  {
    v5 = 0;
  }
  a->throw_line_ = b->throw_line_;
  *(_OWORD *)&a->throw_function_ = *(_OWORD *)&b->throw_function_;
  v6 = a->data_.px_;
  if ( v6
    && (*((unsigned __int8 (__fastcall **)(boost::exception_detail::error_info_container *))v6->_vptr$error_info_container
        + 4))(v6) )
  {
    a->data_.px_ = 0;
  }
  a->data_.px_ = v5;
  if ( v5 )
  {
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))v5->_vptr$error_info_container + 3))(v5);
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *))v5->_vptr$error_info_container + 4))(v5);
  }
}


// Address: 0xd9e1f0 | Name: _ZN5boost16exception_detail10clone_implINS0_10bad_alloc_EED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  __int64 v2; // rdi

  std::bad_alloc::~bad_alloc((boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete(this);
}


// Address: 0xd9e230 | Name: _ZNK5boost16exception_detail10clone_implINS0_10bad_alloc_EE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_impl(v1, this, v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xd9e280 | Name: _ZNK5boost16exception_detail10clone_implINS0_10bad_alloc_EE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_impl(exception, this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::~clone_impl);
}


// Address: 0xd9e2d0 | Name: _ZThn40_N5boost16exception_detail10clone_implINS0_10bad_alloc_EED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  __int64 v2; // rdi

  std::bad_alloc::~bad_alloc(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this - 4) = 0;
  }
}


// Address: 0xd9e310 | Name: _ZThn40_N5boost16exception_detail10clone_implINS0_10bad_alloc_EED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  __int64 v2; // rdi

  std::bad_alloc::~bad_alloc(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete((char *)this - 40);
}


// Address: 0xd9e350 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_10bad_alloc_EE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)((char *)this
                                                                                        + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_impl(v2, v1, v3);
}


// Address: 0xd9e3a0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_10bad_alloc_EE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)((char *)this
                                                                                        + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_impl(exception, v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::~clone_impl);
}


// Address: 0xd9e3f0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_10bad_alloc_EED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  __int64 v2; // r14
  __int64 v3; // rdi

  v2 = *(_QWORD *)(*(_QWORD *)this - 40LL);
  std::bad_alloc::~bad_alloc((boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)((char *)this + v2 + 40));
  *(_QWORD *)((char *)this + v2) = &off_2875508;
  v3 = *(_QWORD *)((char *)this + v2 + 8);
  if ( v3 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v3 + 32LL))(v3) )
      *(_QWORD *)((char *)this + v2 + 8) = 0;
  }
}


// Address: 0xd9e450 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_10bad_alloc_EED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this)
{
  __int64 v2; // r14
  __int64 v3; // rdi

  v2 = *(_QWORD *)(*(_QWORD *)this - 40LL);
  std::bad_alloc::~bad_alloc((boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *)((char *)this + v2 + 40));
  *(_QWORD *)((char *)this + v2) = &off_2875508;
  v3 = *(_QWORD *)((char *)this + v2 + 8);
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 32LL))(v3);
  operator delete((char *)this + v2);
}


// Address: 0xd9e4a0 | Name: _ZN5boost16exception_detail10clone_baseD2Ev
void __fastcall boost::exception_detail::clone_base::~clone_base(boost::exception_detail::clone_base *this)
{
  ;
}


// Address: 0xd9e4b0 | Name: _ZN5boost16exception_detail10clone_baseD0Ev
void __fastcall __noreturn boost::exception_detail::clone_base::~clone_base(boost::exception_detail::clone_base *this)
{
  BUG();
}


// Address: 0xd9e4c0 | Name: _ZN5boost16exception_detail10clone_implINS0_10bad_alloc_EEC1ERKS3_NS3_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_alloc_> *this,
        const boost::exception *x,
        __int64 a3)
{
  boost::exception_detail::error_info_container *px; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  px = x->data_.px_;
  *((_QWORD *)this + 1) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *, const boost::exception *, __int64))px->_vptr$error_info_container
     + 3))(
      px,
      x,
      a3);
  *((_DWORD *)this + 8) = x->throw_line_;
  *((_OWORD *)this + 1) = *(_OWORD *)&x->throw_function_;
  *(_QWORD *)this = &off_2875530;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_2875560,
                                      (__m128i)(unsigned __int64)&off_28755A0);
  boost::exception_detail::copy_boost_exception((boost::exception *)this, x);
}


// Address: 0xd9e690 | Name: _ZN5boost16exception_detail10clone_implINS0_14bad_exception_EEC1ERKS2_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this,
        const boost::exception_detail::bad_exception_ *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  v3 = *((_QWORD *)x + 1);
  *((_QWORD *)this + 1) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 8) = *((_DWORD *)x + 8);
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = &off_2875740;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_2875770,
                                      (__m128i)(unsigned __int64)&off_28757B0);
  boost::exception_detail::copy_boost_exception((boost::exception *)this, (const boost::exception *)x);
}


// Address: 0xd9e760 | Name: _ZN5boost16exception_detail10clone_implINS0_14bad_exception_EEC1ERKS3_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  v3 = *((_QWORD *)a2 + 1);
  *((_QWORD *)this + 1) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 8) = *((_DWORD *)a2 + 8);
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = &off_2875740;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_2875770,
                                      (__m128i)(unsigned __int64)&off_28757B0);
}


// Address: 0xd9e7e0 | Name: _ZN5boost16exception_detail10clone_implINS0_14bad_exception_EED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  __int64 v2; // rdi

  std::bad_exception::~bad_exception((boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this + 1) = 0;
  }
}


// Address: 0xd9e920 | Name: _ZN5boost16exception_detail10clone_implINS0_14bad_exception_EED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  __int64 v2; // rdi

  std::bad_exception::~bad_exception((boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete(this);
}


// Address: 0xd9e960 | Name: _ZNK5boost16exception_detail10clone_implINS0_14bad_exception_EE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_impl(v1, this, v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xd9e9b0 | Name: _ZNK5boost16exception_detail10clone_implINS0_14bad_exception_EE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_impl(exception, this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::~clone_impl);
}


// Address: 0xd9ea00 | Name: _ZThn40_N5boost16exception_detail10clone_implINS0_14bad_exception_EED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  __int64 v2; // rdi

  std::bad_exception::~bad_exception(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this - 4) = 0;
  }
}


// Address: 0xd9ea40 | Name: _ZThn40_N5boost16exception_detail10clone_implINS0_14bad_exception_EED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  __int64 v2; // rdi

  std::bad_exception::~bad_exception(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete((char *)this - 40);
}


// Address: 0xd9ea80 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_14bad_exception_EE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)((char *)this
                                                                                            + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_impl(v2, v1, v3);
}


// Address: 0xd9ead0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_14bad_exception_EE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)((char *)this
                                                                                            + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_impl(exception, v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::~clone_impl);
}


// Address: 0xd9eb20 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_14bad_exception_EED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  __int64 v2; // r14
  __int64 v3; // rdi

  v2 = *(_QWORD *)(*(_QWORD *)this - 40LL);
  std::bad_exception::~bad_exception((boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)((char *)this + v2 + 40));
  *(_QWORD *)((char *)this + v2) = &off_2875508;
  v3 = *(_QWORD *)((char *)this + v2 + 8);
  if ( v3 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v3 + 32LL))(v3) )
      *(_QWORD *)((char *)this + v2 + 8) = 0;
  }
}


// Address: 0xd9eb80 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_14bad_exception_EED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this)
{
  __int64 v2; // r14
  __int64 v3; // rdi

  v2 = *(_QWORD *)(*(_QWORD *)this - 40LL);
  std::bad_exception::~bad_exception((boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *)((char *)this + v2 + 40));
  *(_QWORD *)((char *)this + v2) = &off_2875508;
  v3 = *(_QWORD *)((char *)this + v2 + 8);
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 32LL))(v3);
  operator delete((char *)this + v2);
}


// Address: 0xd9ebd0 | Name: _ZN5boost16exception_detail10clone_implINS0_14bad_exception_EEC1ERKS3_NS3_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::bad_exception_> *this,
        const boost::exception *x,
        __int64 a3)
{
  boost::exception_detail::error_info_container *px; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  px = x->data_.px_;
  *((_QWORD *)this + 1) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *, const boost::exception *, __int64))px->_vptr$error_info_container
     + 3))(
      px,
      x,
      a3);
  *((_DWORD *)this + 8) = x->throw_line_;
  *((_OWORD *)this + 1) = *(_OWORD *)&x->throw_function_;
  *(_QWORD *)this = &off_2875740;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_2875770,
                                      (__m128i)(unsigned __int64)&off_28757B0);
  boost::exception_detail::copy_boost_exception((boost::exception *)this, x);
}


// Address: 0xd9f2e0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::exception::~exception(this);
}


// Address: 0xd9f320 | Name: _ZN5boost16exception_detail19error_info_injectorINS_12bad_weak_ptrEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_weak_ptr>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_weak_ptr> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::exception::~exception(this);
}


// Address: 0xd9f360 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this,
        const boost::exception_detail::error_info_injector<boost::bad_weak_ptr> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2875D28, (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2875C40, (__m128i)(unsigned __int64)off_2875C78);
  *((_QWORD *)this + 6) = &off_2875CB0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xd9f440 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::exception::~exception(this);
  operator delete(this);
}


// Address: 0xd9f4a0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xd9f4f0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl);
}


// Address: 0xd9f540 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  __int64 v2; // rdi
  std::exception *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::exception::~exception(v3);
}


// Address: 0xd9f580 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  __int64 v2; // rdi
  std::exception *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::exception::~exception(v3);
  operator delete(v3);
}


// Address: 0xd9f5d0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xd9f620 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl);
}


// Address: 0xd9f670 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  std::exception *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::exception::~exception(v1);
}


// Address: 0xd9f6c0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this)
{
  std::exception *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::exception::~exception(v1);
  operator delete(v1);
}


// Address: 0xd9f710 | Name: _ZN5boost16exception_detail19error_info_injectorINS_12bad_weak_ptrEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_weak_ptr>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_weak_ptr> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::exception::~exception(this);
  operator delete(this);
}


// Address: 0xd9f760 | Name: _ZThn8_N5boost16exception_detail19error_info_injectorINS_12bad_weak_ptrEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_weak_ptr>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_weak_ptr> *this)
{
  __int64 v2; // rdi
  std::exception *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_weak_ptr> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::exception::~exception(v3);
}


// Address: 0xd9f7a0 | Name: _ZThn8_N5boost16exception_detail19error_info_injectorINS_12bad_weak_ptrEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_weak_ptr>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_weak_ptr> *this)
{
  __int64 v2; // rdi
  std::exception *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_weak_ptr> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::exception::~exception(v3);
  operator delete(v3);
}


// Address: 0xd9f810 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *x,
        __int64 a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2875D28, (__m128i)(unsigned __int64)&off_2875508);
  v4 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64, const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *, __int64))(*(_QWORD *)v4 + 24LL))(
      v4,
      x,
      a3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2875C40, (__m128i)(unsigned __int64)off_2875C78);
  *((_QWORD *)this + 6) = &off_2875CB0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xd9f8f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_weak_ptrEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_weak_ptr> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2875D28, (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)a2 + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)a2 + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)a2 + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2875C40, (__m128i)(unsigned __int64)off_2875C78);
  *((_QWORD *)this + 6) = &off_2875CB0;
}


// Address: 0xd9fff0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
}


// Address: 0xda0030 | Name: _ZN5boost16exception_detail19error_info_injectorINS_17bad_function_callEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_function_call>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_function_call> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
}


// Address: 0xda0070 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this,
        const boost::exception_detail::error_info_injector<boost::bad_function_call> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = off_2875ED8;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2875DF0;
  *((_QWORD *)this + 2) = off_2875E28;
  *((_QWORD *)this + 7) = &off_2875E60;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xda0140 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xda0190 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xda01e0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl);
}


// Address: 0xda0230 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
}


// Address: 0xda0270 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
  operator delete(v3);
}


// Address: 0xda02c0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xda0310 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl);
}


// Address: 0xda0360 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  std::runtime_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::runtime_error::~runtime_error(v1);
}


// Address: 0xda03b0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this)
{
  std::runtime_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::runtime_error::~runtime_error(v1);
  operator delete(v1);
}


// Address: 0xda0400 | Name: _ZN5boost16exception_detail19error_info_injectorINS_17bad_function_callEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_function_call>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_function_call> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xda0450 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_17bad_function_callEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_function_call>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_function_call> *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_function_call> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
}


// Address: 0xda0490 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_17bad_function_callEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_function_call>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_function_call> *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_function_call> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
  operator delete(v3);
}


// Address: 0xda0500 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = off_2875ED8;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2875DF0;
  *((_QWORD *)this + 2) = off_2875E28;
  *((_QWORD *)this + 7) = &off_2875E60;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xda05d0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_17bad_function_callEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_function_call> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875ED8;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2875DF0;
  *((_QWORD *)this + 2) = off_2875E28;
  *((_QWORD *)this + 7) = &off_2875E60;
}


// Address: 0xdafa40 | Name: _ZN5boost24enable_current_exceptionINS_16exception_detail19error_info_injectorINS_21thread_resource_errorEEEEENS1_10clone_implIT_EERKS6_
__int64 __fastcall boost::enable_current_exception<boost::exception_detail::error_info_injector<boost::thread_resource_error>>(
        __int64 a1,
        __int64 a2)
{
  __int64 v3; // rdi

  *(_QWORD *)(a1 + 96) = &off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)a1, (const std::runtime_error *)a2);
  *(_QWORD *)a1 = off_2875F00;
  *(_OWORD *)(a1 + 16) = *(_OWORD *)(a2 + 16);
  std::string::basic_string(a1 + 32, a2 + 32);
  *(_QWORD *)a1 = off_2876218;
  *(_QWORD *)(a1 + 56) = &off_2875508;
  v3 = *(_QWORD *)(a2 + 64);
  *(_QWORD *)(a1 + 64) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *(_DWORD *)(a1 + 88) = *(_DWORD *)(a2 + 88);
  *(_OWORD *)(a1 + 72) = *(_OWORD *)(a2 + 72);
  *(_QWORD *)a1 = off_2876130;
  *(_QWORD *)(a1 + 56) = off_2876168;
  *(_QWORD *)(a1 + 96) = &off_28761A0;
  boost::exception_detail::copy_boost_exception((boost::exception *)(a1 + 56), (const boost::exception *)(a2 + 56));
  return a1;
}


// Address: 0xdafb50 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdafbb0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_21thread_resource_errorEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::thread_resource_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::thread_resource_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdafc10 | Name: _ZN5boost16exception_detail19error_info_injectorINS_21thread_resource_errorEEC2ERKS3_
void __fastcall boost::exception_detail::error_info_injector<boost::thread_resource_error>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::thread_resource_error> *this,
        const boost::exception_detail::error_info_injector<boost::thread_resource_error> *a2)
{
  __int64 v3; // rdi

  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875F00;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  std::string::basic_string((char *)this + 32, (char *)a2 + 32);
  *(_QWORD *)this = off_2876218;
  *((_QWORD *)this + 7) = &off_2875508;
  v3 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 22) = *((_DWORD *)a2 + 22);
  *(_OWORD *)((char *)this + 72) = *(_OWORD *)((char *)a2 + 72);
  *(_QWORD *)this = off_28761D0;
  *((_QWORD *)this + 7) = off_28761F8;
}


// Address: 0xdafcc0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdafd20 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *)operator new(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdafd70 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *)__cxa_allocate_exception(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl);
}


// Address: 0xdafdc0 | Name: _ZThn56_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
}


// Address: 0xdafe20 | Name: _ZThn56_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
  operator delete(v3);
}


// Address: 0xdafe80 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  char *v1; // r14
  char *v2; // r15
  __int64 v3; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (char *)operator new(0x68u);
  *((_QWORD *)v2 + 12) = &off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)v2, (const std::runtime_error *)v1);
  *(_QWORD *)v2 = off_2875F00;
  *((_OWORD *)v2 + 1) = *((_OWORD *)v1 + 1);
  std::string::basic_string(v2 + 32, v1 + 32);
  *(_QWORD *)v2 = off_2876218;
  *((_QWORD *)v2 + 7) = &off_2875508;
  v3 = *((_QWORD *)v1 + 8);
  *((_QWORD *)v2 + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)v2 + 22) = *((_DWORD *)v1 + 22);
  *(_OWORD *)(v2 + 72) = *(_OWORD *)(v1 + 72);
  *(_QWORD *)v2 = off_2876130;
  *((_QWORD *)v2 + 7) = off_2876168;
  *((_QWORD *)v2 + 12) = &off_28761A0;
  boost::exception_detail::copy_boost_exception((boost::exception *)(v2 + 56), (const boost::exception *)(v1 + 56));
}


// Address: 0xdaffc0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *)__cxa_allocate_exception(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl);
}


// Address: 0xdb0010 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  char *v1; // rbx
  __int64 v2; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL);
  *((_QWORD *)v1 + 7) = &off_2875508;
  v2 = *((_QWORD *)v1 + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)v1 = off_2875F00;
  if ( (v1[32] & 1) != 0 )
    operator delete(*((void **)v1 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
}


// Address: 0xdb0070 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this)
{
  char *v1; // rbx
  __int64 v2; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL);
  *((_QWORD *)v1 + 7) = &off_2875508;
  v2 = *((_QWORD *)v1 + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)v1 = off_2875F00;
  if ( (v1[32] & 1) != 0 )
    operator delete(*((void **)v1 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
  operator delete(v1);
}


// Address: 0xdb00e0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_21thread_resource_errorEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::thread_resource_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::thread_resource_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdb0140 | Name: _ZThn56_N5boost16exception_detail19error_info_injectorINS_21thread_resource_errorEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::thread_resource_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::thread_resource_error> *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
}


// Address: 0xdb01a0 | Name: _ZThn56_N5boost16exception_detail19error_info_injectorINS_21thread_resource_errorEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::thread_resource_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::thread_resource_error> *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
  operator delete(v3);
}


// Address: 0xdb0260 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> >::clone_tag a3)
{
  *((_QWORD *)this + 12) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::thread_resource_error>::error_info_injector(this, x);
  *(_QWORD *)this = off_2876130;
  *((_QWORD *)this + 7) = off_2876168;
  *((_QWORD *)this + 12) = &off_28761A0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 56),
    (const boost::exception *)((char *)x + 56));
}


// Address: 0xdb02d0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_21thread_resource_errorEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::thread_resource_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 12) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875F00;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  std::string::basic_string((char *)this + 32, (char *)a2 + 32);
  *(_QWORD *)this = off_2876218;
  *((_QWORD *)this + 7) = &off_2875508;
  v3 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 22) = *((_DWORD *)a2 + 22);
  *(_OWORD *)((char *)this + 72) = *(_OWORD *)((char *)a2 + 72);
  *(_QWORD *)this = off_2876130;
  *((_QWORD *)this + 7) = off_2876168;
  *((_QWORD *)this + 12) = &off_28761A0;
}


// Address: 0xdb0660 | Name: _ZN5boost24enable_current_exceptionINS_16exception_detail19error_info_injectorINS_10lock_errorEEEEENS1_10clone_implIT_EERKS6_
__int64 __fastcall boost::enable_current_exception<boost::exception_detail::error_info_injector<boost::lock_error>>(
        __int64 a1,
        __int64 a2)
{
  __int64 v3; // rdi

  *(_QWORD *)(a1 + 96) = &off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)a1, (const std::runtime_error *)a2);
  *(_QWORD *)a1 = off_2875F00;
  *(_OWORD *)(a1 + 16) = *(_OWORD *)(a2 + 16);
  std::string::basic_string(a1 + 32, a2 + 32);
  *(_QWORD *)a1 = off_28763C8;
  *(_QWORD *)(a1 + 56) = &off_2875508;
  v3 = *(_QWORD *)(a2 + 64);
  *(_QWORD *)(a1 + 64) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *(_DWORD *)(a1 + 88) = *(_DWORD *)(a2 + 88);
  *(_OWORD *)(a1 + 72) = *(_OWORD *)(a2 + 72);
  *(_QWORD *)a1 = off_28762E0;
  *(_QWORD *)(a1 + 56) = off_2876318;
  *(_QWORD *)(a1 + 96) = &off_2876350;
  boost::exception_detail::copy_boost_exception((boost::exception *)(a1 + 56), (const boost::exception *)(a2 + 56));
  return a1;
}


// Address: 0xdb0770 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdb07d0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_10lock_errorEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::lock_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::lock_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdb0830 | Name: _ZN5boost16exception_detail19error_info_injectorINS_10lock_errorEEC2ERKS3_
void __fastcall boost::exception_detail::error_info_injector<boost::lock_error>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::lock_error> *this,
        const boost::exception_detail::error_info_injector<boost::lock_error> *a2)
{
  __int64 v3; // rdi

  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875F00;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  std::string::basic_string((char *)this + 32, (char *)a2 + 32);
  *(_QWORD *)this = off_28763C8;
  *((_QWORD *)this + 7) = &off_2875508;
  v3 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 22) = *((_DWORD *)a2 + 22);
  *(_OWORD *)((char *)this + 72) = *(_OWORD *)((char *)a2 + 72);
  *(_QWORD *)this = off_2876380;
  *((_QWORD *)this + 7) = off_28763A8;
}


// Address: 0xdb08e0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdb0940 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *)operator new(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdb0990 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *)__cxa_allocate_exception(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl);
}


// Address: 0xdb09e0 | Name: _ZThn56_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
}


// Address: 0xdb0a40 | Name: _ZThn56_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
  operator delete(v3);
}


// Address: 0xdb0aa0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  char *v1; // r14
  char *v2; // r15
  __int64 v3; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (char *)operator new(0x68u);
  *((_QWORD *)v2 + 12) = &off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)v2, (const std::runtime_error *)v1);
  *(_QWORD *)v2 = off_2875F00;
  *((_OWORD *)v2 + 1) = *((_OWORD *)v1 + 1);
  std::string::basic_string(v2 + 32, v1 + 32);
  *(_QWORD *)v2 = off_28763C8;
  *((_QWORD *)v2 + 7) = &off_2875508;
  v3 = *((_QWORD *)v1 + 8);
  *((_QWORD *)v2 + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)v2 + 22) = *((_DWORD *)v1 + 22);
  *(_OWORD *)(v2 + 72) = *(_OWORD *)(v1 + 72);
  *(_QWORD *)v2 = off_28762E0;
  *((_QWORD *)v2 + 7) = off_2876318;
  *((_QWORD *)v2 + 12) = &off_2876350;
  boost::exception_detail::copy_boost_exception((boost::exception *)(v2 + 56), (const boost::exception *)(v1 + 56));
}


// Address: 0xdb0be0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *)__cxa_allocate_exception(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl);
}


// Address: 0xdb0c30 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  char *v1; // rbx
  __int64 v2; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL);
  *((_QWORD *)v1 + 7) = &off_2875508;
  v2 = *((_QWORD *)v1 + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)v1 = off_2875F00;
  if ( (v1[32] & 1) != 0 )
    operator delete(*((void **)v1 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
}


// Address: 0xdb0c90 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this)
{
  char *v1; // rbx
  __int64 v2; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL);
  *((_QWORD *)v1 + 7) = &off_2875508;
  v2 = *((_QWORD *)v1 + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)v1 = off_2875F00;
  if ( (v1[32] & 1) != 0 )
    operator delete(*((void **)v1 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
  operator delete(v1);
}


// Address: 0xdb0d00 | Name: _ZN5boost16exception_detail19error_info_injectorINS_10lock_errorEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::lock_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::lock_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdb0d60 | Name: _ZThn56_N5boost16exception_detail19error_info_injectorINS_10lock_errorEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::lock_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::lock_error> *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
}


// Address: 0xdb0dc0 | Name: _ZThn56_N5boost16exception_detail19error_info_injectorINS_10lock_errorEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::lock_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::lock_error> *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
  operator delete(v3);
}


// Address: 0xdb0e50 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> >::clone_tag a3)
{
  *((_QWORD *)this + 12) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::lock_error>::error_info_injector(this, x);
  *(_QWORD *)this = off_28762E0;
  *((_QWORD *)this + 7) = off_2876318;
  *((_QWORD *)this + 12) = &off_2876350;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 56),
    (const boost::exception *)((char *)x + 56));
}


// Address: 0xdb0ec0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_10lock_errorEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::lock_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 12) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875F00;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  std::string::basic_string((char *)this + 32, (char *)a2 + 32);
  *(_QWORD *)this = off_28763C8;
  *((_QWORD *)this + 7) = &off_2875508;
  v3 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 22) = *((_DWORD *)a2 + 22);
  *(_OWORD *)((char *)this + 72) = *(_OWORD *)((char *)a2 + 72);
  *(_QWORD *)this = off_28762E0;
  *((_QWORD *)this + 7) = off_2876318;
  *((_QWORD *)this + 12) = &off_2876350;
}


// Address: 0xdbe0f0 | Name: j_._ZNSt11logic_errorD2Ev
// attributes: thunk
void __fastcall std::logic_error::~logic_error(boost::exception_detail::clone_impl<boost::broken_promise> *this)
{
  ._ZNSt11logic_errorD2Ev(this);
}


// Address: 0xdbe1d0 | Name: _ZN5boost16exception_detail10clone_implINS_14broken_promiseEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::broken_promise>::~clone_impl(
        boost::exception_detail::clone_impl<boost::broken_promise> *this)
{
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdbe1f0 | Name: _ZNK5boost16exception_detail10clone_implINS_14broken_promiseEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::broken_promise>::clone(
        const boost::exception_detail::clone_impl<boost::broken_promise> *this)
{
  boost::exception_detail::clone_base *v1; // rbx

  v1 = (boost::exception_detail::clone_base *)operator new(0x28u);
  v1[4]._vptr$clone_base = (int (**)(void))&off_2875618;
  std::logic_error::logic_error((std::logic_error *)v1, this);
  *(_OWORD *)&v1[2]._vptr$clone_base = *((_OWORD *)this + 1);
  v1->_vptr$clone_base = (int (**)(void))&off_28767D0;
  v1[4]._vptr$clone_base = (int (**)(void))&off_2876820;
  return v1 + 4;
}


// Address: 0xdbe250 | Name: _ZNK5boost16exception_detail10clone_implINS_14broken_promiseEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::broken_promise>::rethrow(
        const boost::exception_detail::clone_impl<boost::broken_promise> *this)
{
  boost::exception_detail::clone_impl<boost::broken_promise> *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::broken_promise> *)__cxa_allocate_exception(0x28u);
  boost::exception_detail::clone_impl<boost::broken_promise>::clone_impl(exception, this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::broken_promise>,
    (void (*)(void *))std::logic_error::~logic_error);
}


// Address: 0xdbe290 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS_14broken_promiseEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::broken_promise>::clone(
        const boost::exception_detail::clone_impl<boost::broken_promise> *this)
{
  __int64 v1; // r12
  std::logic_error *v2; // rbx

  v1 = *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (std::logic_error *)operator new(0x28u);
  *((_QWORD *)v2 + 4) = &off_2875618;
  std::logic_error::logic_error(
    v2,
    (const boost::exception_detail::clone_impl<boost::broken_promise> *)((char *)this + v1));
  *((_OWORD *)v2 + 1) = *(_OWORD *)((char *)this + v1 + 16);
  *(_QWORD *)v2 = &off_28767D0;
  *((_QWORD *)v2 + 4) = &off_2876820;
}


// Address: 0xdbe300 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS_14broken_promiseEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::broken_promise>::rethrow(
        const boost::exception_detail::clone_impl<boost::broken_promise> *this)
{
  const boost::exception_detail::clone_impl<boost::broken_promise> *v1; // rbx
  boost::exception_detail::clone_impl<boost::broken_promise> *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::broken_promise> *)((char *)this
                                                                          + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::broken_promise> *)__cxa_allocate_exception(0x28u);
  boost::exception_detail::clone_impl<boost::broken_promise>::clone_impl(exception, v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::broken_promise>,
    (void (*)(void *))std::logic_error::~logic_error);
}


// Address: 0xdbe340 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS_14broken_promiseEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::broken_promise>::~clone_impl(
        boost::exception_detail::clone_impl<boost::broken_promise> *this)
{
  std::logic_error::~logic_error((boost::exception_detail::clone_impl<boost::broken_promise> *)((char *)this
                                                                                              + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xdbe350 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS_14broken_promiseEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::broken_promise>::~clone_impl(
        boost::exception_detail::clone_impl<boost::broken_promise> *this)
{
  std::logic_error *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::broken_promise> *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xdbe3b0 | Name: _ZN5boost16exception_detail10clone_implINS_14broken_promiseEEC1ERKS3_
void __fastcall boost::exception_detail::clone_impl<boost::broken_promise>::clone_impl(
        boost::exception_detail::clone_impl<boost::broken_promise> *this,
        const boost::exception_detail::clone_impl<boost::broken_promise> *a2)
{
  *((_QWORD *)this + 4) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = &off_28767D0;
  *((_QWORD *)this + 4) = &off_2876820;
}


// Address: 0xdc0c20 | Name: _ZN5boost16exception_detail10clone_implINS_17unknown_exceptionEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  __int64 v2; // rdi

  std::exception::~exception((boost::exception_detail::clone_impl<boost::unknown_exception> *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this + 1) = 0;
  }
}


// Address: 0xdc0c60 | Name: _ZN5boost16exception_detail10clone_implINS_17unknown_exceptionEEC1ERKS2_
void __fastcall boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this,
        const boost::unknown_exception *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  v3 = *((_QWORD *)x + 1);
  *((_QWORD *)this + 1) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 8) = *((_DWORD *)x + 8);
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = &off_2876980;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_28769B0,
                                      (__m128i)(unsigned __int64)&off_28769F0);
  boost::exception_detail::copy_boost_exception((boost::exception *)this, (const boost::exception *)x);
}


// Address: 0xdc0d30 | Name: _ZN5boost16exception_detail10clone_implINS_17unknown_exceptionEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  __int64 v2; // rdi

  std::exception::~exception((boost::exception_detail::clone_impl<boost::unknown_exception> *)((char *)this + 40));
  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete(this);
}


// Address: 0xdc0d70 | Name: _ZNK5boost16exception_detail10clone_implINS_17unknown_exceptionEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::unknown_exception>::clone(
        const boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  boost::exception_detail::clone_impl<boost::unknown_exception> *v1; // rbx
  boost::exception_detail::clone_impl<boost::unknown_exception>::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::unknown_exception> *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(v1, this, v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc0dc0 | Name: _ZNK5boost16exception_detail10clone_implINS_17unknown_exceptionEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::unknown_exception>::rethrow(
        const boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  boost::exception_detail::clone_impl<boost::unknown_exception> *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::unknown_exception> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(exception, this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::unknown_exception>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl);
}


// Address: 0xdc0e10 | Name: _ZThn40_N5boost16exception_detail10clone_implINS_17unknown_exceptionEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  __int64 v2; // rdi

  std::exception::~exception(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
      *((_QWORD *)this - 4) = 0;
  }
}


// Address: 0xdc0e50 | Name: _ZThn40_N5boost16exception_detail10clone_implINS_17unknown_exceptionEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  __int64 v2; // rdi

  std::exception::~exception(this);
  *((_QWORD *)this - 5) = &off_2875508;
  v2 = *((_QWORD *)this - 4);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  operator delete((char *)this - 40);
}


// Address: 0xdc0e90 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS_17unknown_exceptionEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::unknown_exception>::clone(
        const boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  const boost::exception_detail::clone_impl<boost::unknown_exception> *v1; // rbx
  boost::exception_detail::clone_impl<boost::unknown_exception> *v2; // r14
  boost::exception_detail::clone_impl<boost::unknown_exception>::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::unknown_exception> *)((char *)this
                                                                             + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::unknown_exception> *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(v2, v1, v3);
}


// Address: 0xdc0ee0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS_17unknown_exceptionEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::unknown_exception>::rethrow(
        const boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  const boost::exception_detail::clone_impl<boost::unknown_exception> *v1; // rbx
  boost::exception_detail::clone_impl<boost::unknown_exception> *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::unknown_exception> *)((char *)this
                                                                             + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::unknown_exception> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(exception, v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::unknown_exception>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl);
}


// Address: 0xdc0f30 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS_17unknown_exceptionEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  __int64 v2; // r14
  __int64 v3; // rdi

  v2 = *(_QWORD *)(*(_QWORD *)this - 40LL);
  std::exception::~exception((boost::exception_detail::clone_impl<boost::unknown_exception> *)((char *)this + v2 + 40));
  *(_QWORD *)((char *)this + v2) = &off_2875508;
  v3 = *(_QWORD *)((char *)this + v2 + 8);
  if ( v3 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v3 + 32LL))(v3) )
      *(_QWORD *)((char *)this + v2 + 8) = 0;
  }
}


// Address: 0xdc0f90 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS_17unknown_exceptionEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::unknown_exception>::~clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this)
{
  __int64 v2; // r14
  __int64 v3; // rdi

  v2 = *(_QWORD *)(*(_QWORD *)this - 40LL);
  std::exception::~exception((boost::exception_detail::clone_impl<boost::unknown_exception> *)((char *)this + v2 + 40));
  *(_QWORD *)((char *)this + v2) = &off_2875508;
  v3 = *(_QWORD *)((char *)this + v2 + 8);
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 32LL))(v3);
  operator delete((char *)this + v2);
}


// Address: 0xdc10a0 | Name: _ZN5boost16exception_detail10clone_implINS_17unknown_exceptionEEC1ERKS3_NS3_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this,
        const boost::exception *x,
        __int64 a3)
{
  boost::exception_detail::error_info_container *px; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  px = x->data_.px_;
  *((_QWORD *)this + 1) = px;
  if ( px )
    (*((void (__fastcall **)(boost::exception_detail::error_info_container *, const boost::exception *, __int64))px->_vptr$error_info_container
     + 3))(
      px,
      x,
      a3);
  *((_DWORD *)this + 8) = x->throw_line_;
  *((_OWORD *)this + 1) = *(_OWORD *)&x->throw_function_;
  *(_QWORD *)this = &off_2876980;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_28769B0,
                                      (__m128i)(unsigned __int64)&off_28769F0);
  boost::exception_detail::copy_boost_exception((boost::exception *)this, x);
}


// Address: 0xdc1170 | Name: _ZN5boost16exception_detail10clone_implINS_17unknown_exceptionEEC1ERKS3_
void __fastcall boost::exception_detail::clone_impl<boost::unknown_exception>::clone_impl(
        boost::exception_detail::clone_impl<boost::unknown_exception> *this,
        const boost::exception_detail::clone_impl<boost::unknown_exception> *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(_QWORD *)this = &off_2875508;
  v3 = *((_QWORD *)a2 + 1);
  *((_QWORD *)this + 1) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 8) = *((_DWORD *)a2 + 8);
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = &off_2876980;
  *(__m128i *)((char *)this + 40) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)off_28769B0,
                                      (__m128i)(unsigned __int64)&off_28769F0);
}


// Address: 0xdc2380 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_exception::~bad_exception(this);
}


// Address: 0xdc23c0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_exception + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876CF0, (__m128i)(unsigned __int64)off_2876D28);
  *((_QWORD *)this + 6) = &off_2876D60;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xdc24b0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_exception::~bad_exception(this);
  operator delete(this);
}


// Address: 0xdc2500 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc2550 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl);
}


// Address: 0xdc25a0 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  __int64 v2; // rdi
  std::bad_exception *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_exception::~bad_exception(v3);
}


// Address: 0xdc25e0 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  __int64 v2; // rdi
  std::bad_exception *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_exception::~bad_exception(v3);
  operator delete(v3);
}


// Address: 0xdc2630 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc2680 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl);
}


// Address: 0xdc26d0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  std::bad_exception *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_exception::~bad_exception(v1);
}


// Address: 0xdc2720 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this)
{
  std::bad_exception *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_exception::~bad_exception(v1);
  operator delete(v1);
}


// Address: 0xdc2850 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *x,
        __int64 a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_exception + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v4 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64, const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *, __int64))(*(_QWORD *)v4 + 24LL))(
      v4,
      x,
      a3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876CF0, (__m128i)(unsigned __int64)off_2876D28);
  *((_QWORD *)this + 6) = &off_2876D60;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xdc2940 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13bad_exceptionEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_exception> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_exception + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)a2 + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)a2 + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)a2 + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876CF0, (__m128i)(unsigned __int64)off_2876D28);
  *((_QWORD *)this + 6) = &off_2876D60;
}


// Address: 0xdc2d00 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_typeid::~bad_typeid(this);
}


// Address: 0xdc2d40 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_typeid + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876E60, (__m128i)(unsigned __int64)off_2876E98);
  *((_QWORD *)this + 6) = &off_2876ED0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xdc2e30 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_typeid::~bad_typeid(this);
  operator delete(this);
}


// Address: 0xdc2e80 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc2ed0 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl);
}


// Address: 0xdc2f20 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  __int64 v2; // rdi
  std::bad_typeid *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_typeid::~bad_typeid(v3);
}


// Address: 0xdc2f60 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  __int64 v2; // rdi
  std::bad_typeid *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_typeid::~bad_typeid(v3);
  operator delete(v3);
}


// Address: 0xdc2fb0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc3000 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl);
}


// Address: 0xdc3050 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  std::bad_typeid *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_typeid::~bad_typeid(v1);
}


// Address: 0xdc30a0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this)
{
  std::bad_typeid *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_typeid::~bad_typeid(v1);
  operator delete(v1);
}


// Address: 0xdc31d0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *x,
        __int64 a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_typeid + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v4 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64, const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *, __int64))(*(_QWORD *)v4 + 24LL))(
      v4,
      x,
      a3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876E60, (__m128i)(unsigned __int64)off_2876E98);
  *((_QWORD *)this + 6) = &off_2876ED0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xdc32c0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt10bad_typeidEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_typeid> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_typeid + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)a2 + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)a2 + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)a2 + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876E60, (__m128i)(unsigned __int64)off_2876E98);
  *((_QWORD *)this + 6) = &off_2876ED0;
}


// Address: 0xdc3680 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_cast::~bad_cast(this);
}


// Address: 0xdc36c0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_cast + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876FD0, (__m128i)(unsigned __int64)off_2877008);
  *((_QWORD *)this + 6) = &off_2877040;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xdc37b0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_cast::~bad_cast(this);
  operator delete(this);
}


// Address: 0xdc3800 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc3850 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl);
}


// Address: 0xdc38a0 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_cast::~bad_cast(v3);
}


// Address: 0xdc38e0 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_cast::~bad_cast(v3);
  operator delete(v3);
}


// Address: 0xdc3930 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc3980 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl);
}


// Address: 0xdc39d0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  std::bad_cast *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_cast::~bad_cast(v1);
}


// Address: 0xdc3a20 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this)
{
  std::bad_cast *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_cast::~bad_cast(v1);
  operator delete(v1);
}


// Address: 0xdc3b50 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *x,
        __int64 a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_cast + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v4 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64, const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *, __int64))(*(_QWORD *)v4 + 24LL))(
      v4,
      x,
      a3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876FD0, (__m128i)(unsigned __int64)off_2877008);
  *((_QWORD *)this + 6) = &off_2877040;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xdc3c40 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt8bad_castEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_cast> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_cast + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)a2 + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)a2 + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)a2 + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2876FD0, (__m128i)(unsigned __int64)off_2877008);
  *((_QWORD *)this + 6) = &off_2877040;
}


// Address: 0xdc4000 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_alloc::~bad_alloc(this);
}


// Address: 0xdc4040 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_alloc + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2877140, (__m128i)(unsigned __int64)off_2877178);
  *((_QWORD *)this + 6) = &off_28771B0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xdc4130 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_alloc::~bad_alloc(this);
  operator delete(this);
}


// Address: 0xdc4180 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc41d0 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl);
}


// Address: 0xdc4220 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  __int64 v2; // rdi
  std::bad_alloc *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_alloc::~bad_alloc(v3);
}


// Address: 0xdc4260 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  __int64 v2; // rdi
  std::bad_alloc *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_alloc::~bad_alloc(v3);
  operator delete(v3);
}


// Address: 0xdc42b0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc4300 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl);
}


// Address: 0xdc4350 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  std::bad_alloc *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_alloc::~bad_alloc(v1);
}


// Address: 0xdc43a0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this)
{
  std::bad_alloc *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_alloc::~bad_alloc(v1);
  operator delete(v1);
}


// Address: 0xdc44d0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *x,
        __int64 a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_alloc + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v4 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64, const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *, __int64))(*(_QWORD *)v4 + 24LL))(
      v4,
      x,
      a3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2877140, (__m128i)(unsigned __int64)off_2877178);
  *((_QWORD *)this + 6) = &off_28771B0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xdc45c0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt9bad_allocEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::bad_alloc> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_alloc + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)a2 + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)a2 + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)a2 + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2877140, (__m128i)(unsigned __int64)off_2877178);
  *((_QWORD *)this + 6) = &off_28771B0;
}


// Address: 0xdc4a10 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdc4a50 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28772B0;
  *((_QWORD *)this + 2) = off_28772E8;
  *((_QWORD *)this + 7) = &off_2877320;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc4b20 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdc4b70 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc4bc0 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl);
}


// Address: 0xdc4c10 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
}


// Address: 0xdc4c50 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
  operator delete(v3);
}


// Address: 0xdc4ca0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc4cf0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl);
}


// Address: 0xdc4d40 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  std::runtime_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::runtime_error::~runtime_error(v1);
}


// Address: 0xdc4d90 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this)
{
  std::runtime_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::runtime_error::~runtime_error(v1);
  operator delete(v1);
}


// Address: 0xdc4ec0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28772B0;
  *((_QWORD *)this + 2) = off_28772E8;
  *((_QWORD *)this + 7) = &off_2877320;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc4f90 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt13runtime_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::runtime_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_28772B0;
  *((_QWORD *)this + 2) = off_28772E8;
  *((_QWORD *)this + 7) = &off_2877320;
}


// Address: 0xdc5410 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::ios_base::failure::~failure(this);
}


// Address: 0xdc5450 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::system_error + 16;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = (char *)&`vtable for'std::ios_base::failure + 16;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_2877420;
  *((_QWORD *)this + 4) = off_2877458;
  *((_QWORD *)this + 9) = &off_2877490;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdc5530 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::ios_base::failure::~failure(this);
  operator delete(this);
}


// Address: 0xdc5580 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc55d0 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl);
}


// Address: 0xdc5620 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  __int64 v2; // rdi
  std::ios_base::failure *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::ios_base::failure::~failure(v3);
}


// Address: 0xdc5660 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  __int64 v2; // rdi
  std::ios_base::failure *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::ios_base::failure::~failure(v3);
  operator delete(v3);
}


// Address: 0xdc56b0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc5700 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl);
}


// Address: 0xdc5750 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  std::ios_base::failure *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::ios_base::failure::~failure(v1);
}


// Address: 0xdc57a0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this)
{
  std::ios_base::failure *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::ios_base::failure::~failure(v1);
  operator delete(v1);
}


// Address: 0xdc58d0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEEC1ERKS7_NS7_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::system_error + 16;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = (char *)&`vtable for'std::ios_base::failure + 16;
  *((_QWORD *)this + 4) = &off_2875508;
  v4 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_2877420;
  *((_QWORD *)this + 4) = off_2877458;
  *((_QWORD *)this + 9) = &off_2877490;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdc59b0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperINSt3__18ios_base7failureEEEEC1ERKS7_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::ios_base::failure> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::system_error + 16;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = (char *)&`vtable for'std::ios_base::failure + 16;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)a2 + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)a2 + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)a2 + 3);
  *(_QWORD *)this = off_2877420;
  *((_QWORD *)this + 4) = off_2877458;
  *((_QWORD *)this + 9) = &off_2877490;
}


// Address: 0xdc5e10 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::underflow_error::~underflow_error(this);
}


// Address: 0xdc5e50 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::underflow_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877590;
  *((_QWORD *)this + 2) = off_28775C8;
  *((_QWORD *)this + 7) = &off_2877600;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc5f20 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::underflow_error::~underflow_error(this);
  operator delete(this);
}


// Address: 0xdc5f70 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc5fc0 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl);
}


// Address: 0xdc6010 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  __int64 v2; // rdi
  std::underflow_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::underflow_error::~underflow_error(v3);
}


// Address: 0xdc6050 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  __int64 v2; // rdi
  std::underflow_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::underflow_error::~underflow_error(v3);
  operator delete(v3);
}


// Address: 0xdc60a0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc60f0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl);
}


// Address: 0xdc6140 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  std::underflow_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::underflow_error::~underflow_error(v1);
}


// Address: 0xdc6190 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this)
{
  std::underflow_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::underflow_error::~underflow_error(v1);
  operator delete(v1);
}


// Address: 0xdc62c0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::underflow_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877590;
  *((_QWORD *)this + 2) = off_28775C8;
  *((_QWORD *)this + 7) = &off_2877600;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc6390 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt15underflow_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::underflow_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::underflow_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2877590;
  *((_QWORD *)this + 2) = off_28775C8;
  *((_QWORD *)this + 7) = &off_2877600;
}


// Address: 0xdc67e0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::overflow_error::~overflow_error(this);
}


// Address: 0xdc6820 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::overflow_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877700;
  *((_QWORD *)this + 2) = off_2877738;
  *((_QWORD *)this + 7) = &off_2877770;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc68f0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::overflow_error::~overflow_error(this);
  operator delete(this);
}


// Address: 0xdc6940 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc6990 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl);
}


// Address: 0xdc69e0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  __int64 v2; // rdi
  std::overflow_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::overflow_error::~overflow_error(v3);
}


// Address: 0xdc6a20 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  __int64 v2; // rdi
  std::overflow_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::overflow_error::~overflow_error(v3);
  operator delete(v3);
}


// Address: 0xdc6a70 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc6ac0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl);
}


// Address: 0xdc6b10 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  std::overflow_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::overflow_error::~overflow_error(v1);
}


// Address: 0xdc6b60 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this)
{
  std::overflow_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::overflow_error::~overflow_error(v1);
  operator delete(v1);
}


// Address: 0xdc6c90 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::overflow_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877700;
  *((_QWORD *)this + 2) = off_2877738;
  *((_QWORD *)this + 7) = &off_2877770;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc6d60 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt14overflow_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::overflow_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::overflow_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2877700;
  *((_QWORD *)this + 2) = off_2877738;
  *((_QWORD *)this + 7) = &off_2877770;
}


// Address: 0xdc71b0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::range_error::~range_error(this);
}


// Address: 0xdc71f0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::range_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877870;
  *((_QWORD *)this + 2) = off_28778A8;
  *((_QWORD *)this + 7) = &off_28778E0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc72c0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::range_error::~range_error(this);
  operator delete(this);
}


// Address: 0xdc7310 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc7360 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl);
}


// Address: 0xdc73b0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  __int64 v2; // rdi
  std::range_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::range_error::~range_error(v3);
}


// Address: 0xdc73f0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  __int64 v2; // rdi
  std::range_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::range_error::~range_error(v3);
  operator delete(v3);
}


// Address: 0xdc7440 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc7490 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl);
}


// Address: 0xdc74e0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  std::range_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::range_error::~range_error(v1);
}


// Address: 0xdc7530 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this)
{
  std::range_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::range_error::~range_error(v1);
  operator delete(v1);
}


// Address: 0xdc7660 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::range_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877870;
  *((_QWORD *)this + 2) = off_28778A8;
  *((_QWORD *)this + 7) = &off_28778E0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc7730 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11range_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::range_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::range_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2877870;
  *((_QWORD *)this + 2) = off_28778A8;
  *((_QWORD *)this + 7) = &off_28778E0;
}


// Address: 0xdc7b70 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdc7bb0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28779E0;
  *((_QWORD *)this + 2) = off_2877A18;
  *((_QWORD *)this + 7) = &off_2877A50;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc7c80 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdc7cd0 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc7d20 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl);
}


// Address: 0xdc7d70 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdc7db0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdc7e00 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc7e50 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl);
}


// Address: 0xdc7ea0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xdc7ef0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xdc8020 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28779E0;
  *((_QWORD *)this + 2) = off_2877A18;
  *((_QWORD *)this + 7) = &off_2877A50;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc80f0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt11logic_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::logic_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_28779E0;
  *((_QWORD *)this + 2) = off_2877A18;
  *((_QWORD *)this + 7) = &off_2877A50;
}


// Address: 0xdc8530 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0xdc8570 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::out_of_range + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877B50;
  *((_QWORD *)this + 2) = off_2877B88;
  *((_QWORD *)this + 7) = &off_2877BC0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc8640 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0xdc8690 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc86e0 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl);
}


// Address: 0xdc8730 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0xdc8770 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0xdc87c0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc8810 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl);
}


// Address: 0xdc8860 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
}


// Address: 0xdc88b0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
  operator delete(v1);
}


// Address: 0xdc89e0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::out_of_range + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877B50;
  *((_QWORD *)this + 2) = off_2877B88;
  *((_QWORD *)this + 7) = &off_2877BC0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc8ab0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12out_of_rangeEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::out_of_range> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::out_of_range + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2877B50;
  *((_QWORD *)this + 2) = off_2877B88;
  *((_QWORD *)this + 7) = &off_2877BC0;
}


// Address: 0xdc8f00 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::length_error::~length_error(this);
}


// Address: 0xdc8f40 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::length_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877CC0;
  *((_QWORD *)this + 2) = off_2877CF8;
  *((_QWORD *)this + 7) = &off_2877D30;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc9010 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::length_error::~length_error(this);
  operator delete(this);
}


// Address: 0xdc9060 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc90b0 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl);
}


// Address: 0xdc9100 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  __int64 v2; // rdi
  std::length_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::length_error::~length_error(v3);
}


// Address: 0xdc9140 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  __int64 v2; // rdi
  std::length_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::length_error::~length_error(v3);
  operator delete(v3);
}


// Address: 0xdc9190 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc91e0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl);
}


// Address: 0xdc9230 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  std::length_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::length_error::~length_error(v1);
}


// Address: 0xdc9280 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this)
{
  std::length_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::length_error::~length_error(v1);
  operator delete(v1);
}


// Address: 0xdc93b0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::length_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877CC0;
  *((_QWORD *)this + 2) = off_2877CF8;
  *((_QWORD *)this + 7) = &off_2877D30;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc9480 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12length_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::length_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::length_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2877CC0;
  *((_QWORD *)this + 2) = off_2877CF8;
  *((_QWORD *)this + 7) = &off_2877D30;
}


// Address: 0xdc98d0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::invalid_argument::~invalid_argument(this);
}


// Address: 0xdc9910 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::invalid_argument + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877E30;
  *((_QWORD *)this + 2) = off_2877E68;
  *((_QWORD *)this + 7) = &off_2877EA0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc99e0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::invalid_argument::~invalid_argument(this);
  operator delete(this);
}


// Address: 0xdc9a30 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdc9a80 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl);
}


// Address: 0xdc9ad0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  __int64 v2; // rdi
  std::invalid_argument *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::invalid_argument::~invalid_argument(v3);
}


// Address: 0xdc9b10 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  __int64 v2; // rdi
  std::invalid_argument *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::invalid_argument::~invalid_argument(v3);
  operator delete(v3);
}


// Address: 0xdc9b60 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdc9bb0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl);
}


// Address: 0xdc9c00 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  std::invalid_argument *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::invalid_argument::~invalid_argument(v1);
}


// Address: 0xdc9c50 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this)
{
  std::invalid_argument *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::invalid_argument::~invalid_argument(v1);
  operator delete(v1);
}


// Address: 0xdc9d80 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::invalid_argument + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877E30;
  *((_QWORD *)this + 2) = off_2877E68;
  *((_QWORD *)this + 7) = &off_2877EA0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdc9e50 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt16invalid_argumentEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::invalid_argument> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::invalid_argument + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2877E30;
  *((_QWORD *)this + 2) = off_2877E68;
  *((_QWORD *)this + 7) = &off_2877EA0;
}


// Address: 0xdca2a0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::domain_error::~domain_error(this);
}


// Address: 0xdca2e0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this,
        const boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::domain_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877FA0;
  *((_QWORD *)this + 2) = off_2877FD8;
  *((_QWORD *)this + 7) = &off_2878010;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdca3b0 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::domain_error::~domain_error(this);
  operator delete(this);
}


// Address: 0xdca400 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdca450 | Name: _ZNK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl);
}


// Address: 0xdca4a0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  __int64 v2; // rdi
  std::domain_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::domain_error::~domain_error(v3);
}


// Address: 0xdca4e0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  __int64 v2; // rdi
  std::domain_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::domain_error::~domain_error(v3);
  operator delete(v3);
}


// Address: 0xdca530 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdca580 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl);
}


// Address: 0xdca5d0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  std::domain_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::domain_error::~domain_error(v1);
}


// Address: 0xdca620 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this)
{
  std::domain_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::domain_error::~domain_error(v1);
  operator delete(v1);
}


// Address: 0xdca750 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::domain_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2877FA0;
  *((_QWORD *)this + 2) = off_2877FD8;
  *((_QWORD *)this + 7) = &off_2878010;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xdca820 | Name: _ZN5boost16exception_detail10clone_implINS0_39current_exception_std_exception_wrapperISt12domain_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::current_exception_std_exception_wrapper<std::domain_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::domain_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2877FA0;
  *((_QWORD *)this + 2) = off_2877FD8;
  *((_QWORD *)this + 7) = &off_2878010;
}


// Address: 0xdcc0a0 | Name: _ZN5boost24enable_current_exceptionINS_16exception_detail19error_info_injectorINS_15condition_errorEEEEENS1_10clone_implIT_EERKS6_
__int64 __fastcall boost::enable_current_exception<boost::exception_detail::error_info_injector<boost::condition_error>>(
        __int64 a1,
        __int64 a2)
{
  __int64 v3; // rdi

  *(_QWORD *)(a1 + 96) = &off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)a1, (const std::runtime_error *)a2);
  *(_QWORD *)a1 = off_2875F00;
  *(_OWORD *)(a1 + 16) = *(_OWORD *)(a2 + 16);
  std::string::basic_string(a1 + 32, a2 + 32);
  *(_QWORD *)a1 = off_2878558;
  *(_QWORD *)(a1 + 56) = &off_2875508;
  v3 = *(_QWORD *)(a2 + 64);
  *(_QWORD *)(a1 + 64) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *(_DWORD *)(a1 + 88) = *(_DWORD *)(a2 + 88);
  *(_OWORD *)(a1 + 72) = *(_OWORD *)(a2 + 72);
  *(_QWORD *)a1 = off_2878470;
  *(_QWORD *)(a1 + 56) = off_28784A8;
  *(_QWORD *)(a1 + 96) = &off_28784E0;
  boost::exception_detail::copy_boost_exception((boost::exception *)(a1 + 56), (const boost::exception *)(a2 + 56));
  return a1;
}


// Address: 0xdcc1b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdcc210 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15condition_errorEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::condition_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::condition_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdcc270 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15condition_errorEEC2ERKS3_
void __fastcall boost::exception_detail::error_info_injector<boost::condition_error>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::condition_error> *this,
        const boost::exception_detail::error_info_injector<boost::condition_error> *a2)
{
  __int64 v3; // rdi

  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875F00;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  std::string::basic_string((char *)this + 32, (char *)a2 + 32);
  *(_QWORD *)this = off_2878558;
  *((_QWORD *)this + 7) = &off_2875508;
  v3 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 22) = *((_DWORD *)a2 + 22);
  *(_OWORD *)((char *)this + 72) = *(_OWORD *)((char *)a2 + 72);
  *(_QWORD *)this = off_2878510;
  *((_QWORD *)this + 7) = off_2878538;
}


// Address: 0xdcc320 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdcc380 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *)operator new(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdcc3d0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *)__cxa_allocate_exception(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl);
}


// Address: 0xdcc420 | Name: _ZThn56_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
}


// Address: 0xdcc480 | Name: _ZThn56_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
  operator delete(v3);
}


// Address: 0xdcc4e0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  char *v1; // r14
  char *v2; // r15
  __int64 v3; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (char *)operator new(0x68u);
  *((_QWORD *)v2 + 12) = &off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)v2, (const std::runtime_error *)v1);
  *(_QWORD *)v2 = off_2875F00;
  *((_OWORD *)v2 + 1) = *((_OWORD *)v1 + 1);
  std::string::basic_string(v2 + 32, v1 + 32);
  *(_QWORD *)v2 = off_2878558;
  *((_QWORD *)v2 + 7) = &off_2875508;
  v3 = *((_QWORD *)v1 + 8);
  *((_QWORD *)v2 + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)v2 + 22) = *((_DWORD *)v1 + 22);
  *(_OWORD *)(v2 + 72) = *(_OWORD *)(v1 + 72);
  *(_QWORD *)v2 = off_2878470;
  *((_QWORD *)v2 + 7) = off_28784A8;
  *((_QWORD *)v2 + 12) = &off_28784E0;
  boost::exception_detail::copy_boost_exception((boost::exception *)(v2 + 56), (const boost::exception *)(v1 + 56));
}


// Address: 0xdcc620 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *)__cxa_allocate_exception(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl);
}


// Address: 0xdcc670 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  char *v1; // rbx
  __int64 v2; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL);
  *((_QWORD *)v1 + 7) = &off_2875508;
  v2 = *((_QWORD *)v1 + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)v1 = off_2875F00;
  if ( (v1[32] & 1) != 0 )
    operator delete(*((void **)v1 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
}


// Address: 0xdcc6d0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this)
{
  char *v1; // rbx
  __int64 v2; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL);
  *((_QWORD *)v1 + 7) = &off_2875508;
  v2 = *((_QWORD *)v1 + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)v1 = off_2875F00;
  if ( (v1[32] & 1) != 0 )
    operator delete(*((void **)v1 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
  operator delete(v1);
}


// Address: 0xdcc740 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15condition_errorEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::condition_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::condition_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdcc7a0 | Name: _ZThn56_N5boost16exception_detail19error_info_injectorINS_15condition_errorEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::condition_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::condition_error> *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
}


// Address: 0xdcc800 | Name: _ZThn56_N5boost16exception_detail19error_info_injectorINS_15condition_errorEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::condition_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::condition_error> *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
  operator delete(v3);
}


// Address: 0xdcc890 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> >::clone_tag a3)
{
  *((_QWORD *)this + 12) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::condition_error>::error_info_injector(this, x);
  *(_QWORD *)this = off_2878470;
  *((_QWORD *)this + 7) = off_28784A8;
  *((_QWORD *)this + 12) = &off_28784E0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 56),
    (const boost::exception *)((char *)x + 56));
}


// Address: 0xdcc900 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15condition_errorEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::condition_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 12) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875F00;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  std::string::basic_string((char *)this + 32, (char *)a2 + 32);
  *(_QWORD *)this = off_2878558;
  *((_QWORD *)this + 7) = &off_2875508;
  v3 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 22) = *((_DWORD *)a2 + 22);
  *(_OWORD *)((char *)this + 72) = *(_OWORD *)((char *)a2 + 72);
  *(_QWORD *)this = off_2878470;
  *((_QWORD *)this + 7) = off_28784A8;
  *((_QWORD *)this + 12) = &off_28784E0;
}


// Address: 0xdccb90 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdccbd0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_25promise_already_satisfiedEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::promise_already_satisfied>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::promise_already_satisfied> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdccc10 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this,
        const boost::exception_detail::error_info_injector<boost::promise_already_satisfied> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = off_2878768;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_2878680;
  *((_QWORD *)this + 4) = off_28786B8;
  *((_QWORD *)this + 9) = &off_28786F0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdcccf0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdccd40 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdccd90 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl);
}


// Address: 0xdccde0 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdcce20 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdcce70 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdccec0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl);
}


// Address: 0xdccf10 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xdccf60 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xdccfb0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_25promise_already_satisfiedEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::promise_already_satisfied>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::promise_already_satisfied> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdcd000 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINS_25promise_already_satisfiedEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::promise_already_satisfied>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::promise_already_satisfied> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::promise_already_satisfied> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdcd040 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINS_25promise_already_satisfiedEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::promise_already_satisfied>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::promise_already_satisfied> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::promise_already_satisfied> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdcd0b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = off_2878768;
  *((_QWORD *)this + 4) = &off_2875508;
  v4 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_2878680;
  *((_QWORD *)this + 4) = off_28786B8;
  *((_QWORD *)this + 9) = &off_28786F0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdcd190 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_25promise_already_satisfiedEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_already_satisfied> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = off_2878768;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)a2 + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)a2 + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)a2 + 3);
  *(_QWORD *)this = off_2878680;
  *((_QWORD *)this + 4) = off_28786B8;
  *((_QWORD *)this + 9) = &off_28786F0;
}


// Address: 0xdcd230 | Name: j_._ZNSt13runtime_errorD2Ev
// attributes: thunk
void __fastcall std::runtime_error::~runtime_error(boost::exception_detail::clone_impl<std::runtime_error> *this)
{
  ._ZNSt13runtime_errorD2Ev(this);
}


// Address: 0xdcd240 | Name: _ZN5boost16exception_detail10clone_implISt13runtime_errorED0Ev
void __fastcall boost::exception_detail::clone_impl<std::runtime_error>::~clone_impl(
        boost::exception_detail::clone_impl<std::runtime_error> *this)
{
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdcd260 | Name: _ZNK5boost16exception_detail10clone_implISt13runtime_errorE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<std::runtime_error>::clone(
        const boost::exception_detail::clone_impl<std::runtime_error> *this)
{
  boost::exception_detail::clone_base *v1; // rbx

  v1 = (boost::exception_detail::clone_base *)operator new(0x18u);
  v1[2]._vptr$clone_base = (int (**)(void))&off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)v1, this);
  v1->_vptr$clone_base = (int (**)(void))&off_28787D0;
  v1[2]._vptr$clone_base = (int (**)(void))&off_2878820;
  return v1 + 2;
}


// Address: 0xdcd2b0 | Name: _ZNK5boost16exception_detail10clone_implISt13runtime_errorE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<std::runtime_error>::rethrow(
        const boost::exception_detail::clone_impl<std::runtime_error> *this)
{
  boost::exception_detail::clone_impl<std::runtime_error> *exception; // rbx

  exception = (boost::exception_detail::clone_impl<std::runtime_error> *)__cxa_allocate_exception(0x18u);
  boost::exception_detail::clone_impl<std::runtime_error>::clone_impl(exception, this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<std::runtime_error>,
    (void (*)(void *))std::runtime_error::~runtime_error);
}


// Address: 0xdcd2f0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implISt13runtime_errorE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<std::runtime_error>::clone(
        const boost::exception_detail::clone_impl<std::runtime_error> *this)
{
  const std::runtime_error *v1; // r14
  std::runtime_error *v2; // rbx

  v1 = (const boost::exception_detail::clone_impl<std::runtime_error> *)((char *)this
                                                                       + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (std::runtime_error *)operator new(0x18u);
  *((_QWORD *)v2 + 2) = &off_2875618;
  std::runtime_error::runtime_error(v2, v1);
  *(_QWORD *)v2 = &off_28787D0;
  *((_QWORD *)v2 + 2) = &off_2878820;
}


// Address: 0xdcd350 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implISt13runtime_errorE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<std::runtime_error>::rethrow(
        const boost::exception_detail::clone_impl<std::runtime_error> *this)
{
  const boost::exception_detail::clone_impl<std::runtime_error> *v1; // rbx
  boost::exception_detail::clone_impl<std::runtime_error> *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<std::runtime_error> *)((char *)this
                                                                       + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<std::runtime_error> *)__cxa_allocate_exception(0x18u);
  boost::exception_detail::clone_impl<std::runtime_error>::clone_impl(exception, v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<std::runtime_error>,
    (void (*)(void *))std::runtime_error::~runtime_error);
}


// Address: 0xdcd390 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implISt13runtime_errorED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<std::runtime_error>::~clone_impl(
        boost::exception_detail::clone_impl<std::runtime_error> *this)
{
  std::runtime_error::~runtime_error((boost::exception_detail::clone_impl<std::runtime_error> *)((char *)this
                                                                                               + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xdcd3a0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implISt13runtime_errorED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<std::runtime_error>::~clone_impl(
        boost::exception_detail::clone_impl<std::runtime_error> *this)
{
  std::runtime_error *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<std::runtime_error> *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  std::runtime_error::~runtime_error(v1);
  operator delete(v1);
}


// Address: 0xdcd3c0 | Name: _ZN5boost16exception_detail10clone_implISt13runtime_errorEC1ERKS3_
void __fastcall boost::exception_detail::clone_impl<std::runtime_error>::clone_impl(
        boost::exception_detail::clone_impl<std::runtime_error> *this,
        const boost::exception_detail::clone_impl<std::runtime_error> *a2)
{
  *((_QWORD *)this + 2) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = &off_28787D0;
  *((_QWORD *)this + 2) = &off_2878820;
}


// Address: 0xdcd3f0 | Name: _ZN5boost16exception_detail10clone_implIN3RBX17http_status_errorEED1Ev
void __fastcall boost::exception_detail::clone_impl<RBX::http_status_error>::~clone_impl(
        boost::exception_detail::clone_impl<RBX::http_status_error> *this)
{
  *(_QWORD *)this = off_2878910;
  if ( (*((_BYTE *)this + 16) & 1) != 0 )
    operator delete(*((void **)this + 4));
  std::runtime_error::~runtime_error(this);
}


// Address: 0xdcd420 | Name: _ZN5boost16exception_detail10clone_implIN3RBX17http_status_errorEED0Ev
void __fastcall boost::exception_detail::clone_impl<RBX::http_status_error>::~clone_impl(
        boost::exception_detail::clone_impl<RBX::http_status_error> *this)
{
  *(_QWORD *)this = off_2878910;
  if ( (*((_BYTE *)this + 16) & 1) != 0 )
    operator delete(*((void **)this + 4));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xdcd450 | Name: _ZNK5boost16exception_detail10clone_implIN3RBX17http_status_errorEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<RBX::http_status_error>::clone(
        const boost::exception_detail::clone_impl<RBX::http_status_error> *this)
{
  boost::exception_detail::clone_base *v1; // rbx

  v1 = (boost::exception_detail::clone_base *)operator new(0x38u);
  v1[6]._vptr$clone_base = (int (**)(void))&off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)v1, this);
  v1->_vptr$clone_base = (int (**)(void))off_2878910;
  std::string::basic_string(&v1[2], (char *)this + 16);
  LODWORD(v1[5]._vptr$clone_base) = *((_DWORD *)this + 10);
  v1->_vptr$clone_base = (int (**)(void))off_2878890;
  v1[6]._vptr$clone_base = (int (**)(void))&off_28788E0;
  return v1 + 6;
}


// Address: 0xdcd4e0 | Name: _ZNK5boost16exception_detail10clone_implIN3RBX17http_status_errorEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<RBX::http_status_error>::rethrow(
        const boost::exception_detail::clone_impl<RBX::http_status_error> *this)
{
  boost::exception_detail::clone_impl<RBX::http_status_error> *exception; // rbx

  exception = (boost::exception_detail::clone_impl<RBX::http_status_error> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<RBX::http_status_error>::clone_impl(exception, this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<RBX::http_status_error>,
    (void (*)(void *))boost::exception_detail::clone_impl<RBX::http_status_error>::~clone_impl);
}


// Address: 0xdcd530 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implIN3RBX17http_status_errorEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<RBX::http_status_error>::clone(
        const boost::exception_detail::clone_impl<RBX::http_status_error> *this)
{
  __int64 v1; // r12
  std::runtime_error *v2; // rbx

  v1 = *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (std::runtime_error *)operator new(0x38u);
  *((_QWORD *)v2 + 6) = &off_2875618;
  std::runtime_error::runtime_error(
    v2,
    (const boost::exception_detail::clone_impl<RBX::http_status_error> *)((char *)this + v1));
  *(_QWORD *)v2 = off_2878910;
  std::string::basic_string((char *)v2 + 16, (char *)this + v1 + 16);
  *((_DWORD *)v2 + 10) = *(_DWORD *)((char *)this + v1 + 40);
  *(_QWORD *)v2 = off_2878890;
  *((_QWORD *)v2 + 6) = &off_28788E0;
}


// Address: 0xdcd5d0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implIN3RBX17http_status_errorEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<RBX::http_status_error>::rethrow(
        const boost::exception_detail::clone_impl<RBX::http_status_error> *this)
{
  const boost::exception_detail::clone_impl<RBX::http_status_error> *v1; // rbx
  boost::exception_detail::clone_impl<RBX::http_status_error> *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<RBX::http_status_error> *)((char *)this
                                                                           + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<RBX::http_status_error> *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<RBX::http_status_error>::clone_impl(exception, v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<RBX::http_status_error>,
    (void (*)(void *))boost::exception_detail::clone_impl<RBX::http_status_error>::~clone_impl);
}


// Address: 0xdcd620 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implIN3RBX17http_status_errorEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<RBX::http_status_error>::~clone_impl(
        boost::exception_detail::clone_impl<RBX::http_status_error> *this)
{
  void **v1; // rbx

  v1 = (void **)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *v1 = off_2878910;
  if ( ((_BYTE)v1[2] & 1) != 0 )
    operator delete(v1[4]);
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
}


// Address: 0xdcd650 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implIN3RBX17http_status_errorEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<RBX::http_status_error>::~clone_impl(
        boost::exception_detail::clone_impl<RBX::http_status_error> *this)
{
  void **v1; // rbx

  v1 = (void **)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *v1 = off_2878910;
  if ( ((_BYTE)v1[2] & 1) != 0 )
    operator delete(v1[4]);
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
  operator delete(v1);
}


// Address: 0xdcd6c0 | Name: _ZN5boost16exception_detail10clone_implIN3RBX17http_status_errorEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<RBX::http_status_error>::clone_impl(
        boost::exception_detail::clone_impl<RBX::http_status_error> *this,
        const boost::exception_detail::clone_impl<RBX::http_status_error> *a2)
{
  *((_QWORD *)this + 6) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2878910;
  std::string::basic_string((char *)this + 16, (char *)a2 + 16);
  *((_DWORD *)this + 10) = *((_DWORD *)a2 + 10);
  *(_QWORD *)this = off_2878890;
  *((_QWORD *)this + 6) = &off_28788E0;
}


// Address: 0xdcd8f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdcd930 | Name: _ZN5boost16exception_detail19error_info_injectorINS_13promise_movedEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::promise_moved>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::promise_moved> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdcd970 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this,
        const boost::exception_detail::error_info_injector<boost::promise_moved> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = off_2878AC8;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_28789E0;
  *((_QWORD *)this + 4) = off_2878A18;
  *((_QWORD *)this + 9) = &off_2878A50;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdcda50 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdcdaa0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdcdaf0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl);
}


// Address: 0xdcdb40 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdcdb80 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdcdbd0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdcdc20 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl);
}


// Address: 0xdcdc70 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xdcdcc0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xdcdd10 | Name: _ZN5boost16exception_detail19error_info_injectorINS_13promise_movedEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::promise_moved>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::promise_moved> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdcdd60 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINS_13promise_movedEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::promise_moved>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::promise_moved> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::promise_moved> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdcdda0 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINS_13promise_movedEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::promise_moved>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::promise_moved> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::promise_moved> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdcde10 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = off_2878AC8;
  *((_QWORD *)this + 4) = &off_2875508;
  v4 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_28789E0;
  *((_QWORD *)this + 4) = off_2878A18;
  *((_QWORD *)this + 9) = &off_2878A50;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdcdef0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_13promise_movedEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::promise_moved> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = off_2878AC8;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)a2 + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)a2 + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)a2 + 3);
  *(_QWORD *)this = off_28789E0;
  *((_QWORD *)this + 4) = off_2878A18;
  *((_QWORD *)this + 9) = &off_2878A50;
}


// Address: 0xdcdf90 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdcdfd0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_24future_already_retrievedEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::future_already_retrieved>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::future_already_retrieved> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdce010 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this,
        const boost::exception_detail::error_info_injector<boost::future_already_retrieved> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = off_2878C78;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_2878B90;
  *((_QWORD *)this + 4) = off_2878BC8;
  *((_QWORD *)this + 9) = &off_2878C00;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdce0f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdce140 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdce190 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl);
}


// Address: 0xdce1e0 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdce220 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdce270 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdce2c0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl);
}


// Address: 0xdce310 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xdce360 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xdce3b0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_24future_already_retrievedEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::future_already_retrieved>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::future_already_retrieved> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdce400 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINS_24future_already_retrievedEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::future_already_retrieved>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::future_already_retrieved> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::future_already_retrieved> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdce440 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINS_24future_already_retrievedEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::future_already_retrieved>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::future_already_retrieved> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::future_already_retrieved> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdce4b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = off_2878C78;
  *((_QWORD *)this + 4) = &off_2875508;
  v4 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_2878B90;
  *((_QWORD *)this + 4) = off_2878BC8;
  *((_QWORD *)this + 9) = &off_2878C00;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdce590 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_24future_already_retrievedEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_already_retrieved> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = off_2878C78;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)a2 + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)a2 + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)a2 + 3);
  *(_QWORD *)this = off_2878B90;
  *((_QWORD *)this + 4) = off_2878BC8;
  *((_QWORD *)this + 9) = &off_2878C00;
}


// Address: 0xdce7b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdce7f0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_20future_uninitializedEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::future_uninitialized>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::future_uninitialized> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xdce830 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this,
        const boost::exception_detail::error_info_injector<boost::future_uninitialized> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = off_2878E28;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_2878D40;
  *((_QWORD *)this + 4) = off_2878D78;
  *((_QWORD *)this + 9) = &off_2878DB0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdce910 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdce960 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xdce9b0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl);
}


// Address: 0xdcea00 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdcea40 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdcea90 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xdceae0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl);
}


// Address: 0xdceb30 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xdceb80 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xdcebd0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_20future_uninitializedEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::future_uninitialized>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::future_uninitialized> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xdcec20 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINS_20future_uninitializedEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::future_uninitialized>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::future_uninitialized> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::future_uninitialized> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xdcec60 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINS_20future_uninitializedEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::future_uninitialized>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::future_uninitialized> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::future_uninitialized> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xdcecd0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = off_2878E28;
  *((_QWORD *)this + 4) = &off_2875508;
  v4 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_2878D40;
  *((_QWORD *)this + 4) = off_2878D78;
  *((_QWORD *)this + 9) = &off_2878DB0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0xdcedb0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_20future_uninitializedEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::future_uninitialized> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_2876878;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = off_2878E28;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)a2 + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)a2 + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)a2 + 3);
  *(_QWORD *)this = off_2878D40;
  *((_QWORD *)this + 4) = off_2878D78;
  *((_QWORD *)this + 9) = &off_2878DB0;
}


// Address: 0xe40df0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 3) = &off_2875508;
  v2 = *((_QWORD *)this + 4);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 4) = 0;
  std::bad_cast::~bad_cast(this);
}


// Address: 0xe40e30 | Name: _ZN5boost16exception_detail19error_info_injectorINS_16bad_lexical_castEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_lexical_cast>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_lexical_cast> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 3) = &off_2875508;
  v2 = *((_QWORD *)this + 4);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 4) = 0;
  std::bad_cast::~bad_cast(this);
}


// Address: 0xe40e70 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this,
        const boost::exception_detail::error_info_injector<boost::bad_lexical_cast> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 8) = &off_2875618;
  *(_QWORD *)this = off_287BC88;
  *(_OWORD *)((char *)this + 8) = *(_OWORD *)((char *)x + 8);
  *((_QWORD *)this + 3) = &off_2875508;
  v3 = *((_QWORD *)x + 4);
  *((_QWORD *)this + 4) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 14) = *((_DWORD *)x + 14);
  *(_OWORD *)((char *)this + 40) = *(_OWORD *)((char *)x + 40);
  *(_QWORD *)this = off_287BBA0;
  *((_QWORD *)this + 3) = off_287BBD8;
  *((_QWORD *)this + 8) = &off_287BC10;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 24),
    (const boost::exception *)((char *)x + 24));
}


// Address: 0xe40f40 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 3) = &off_2875508;
  v2 = *((_QWORD *)this + 4);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 4) = 0;
  std::bad_cast::~bad_cast(this);
  operator delete(this);
}


// Address: 0xe40fa0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)operator new(0x48u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe40ff0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)__cxa_allocate_exception(0x48u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl);
}


// Address: 0xe41040 | Name: _ZThn24_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)((char *)this - 24);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 4) = 0;
  std::bad_cast::~bad_cast(v3);
}


// Address: 0xe41080 | Name: _ZThn24_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)((char *)this - 24);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 4) = 0;
  std::bad_cast::~bad_cast(v3);
  operator delete(v3);
}


// Address: 0xe410d0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)operator new(0x48u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xe41120 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)__cxa_allocate_exception(0x48u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl);
}


// Address: 0xe41170 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  std::bad_cast *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 3) = &off_2875508;
  v2 = *((_QWORD *)v1 + 4);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 4) = 0;
  std::bad_cast::~bad_cast(v1);
}


// Address: 0xe411c0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this)
{
  std::bad_cast *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 3) = &off_2875508;
  v2 = *((_QWORD *)v1 + 4);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 4) = 0;
  std::bad_cast::~bad_cast(v1);
  operator delete(v1);
}


// Address: 0xe41210 | Name: _ZN5boost16exception_detail19error_info_injectorINS_16bad_lexical_castEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_lexical_cast>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_lexical_cast> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 3) = &off_2875508;
  v2 = *((_QWORD *)this + 4);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 4) = 0;
  std::bad_cast::~bad_cast(this);
  operator delete(this);
}


// Address: 0xe41260 | Name: _ZThn24_N5boost16exception_detail19error_info_injectorINS_16bad_lexical_castEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_lexical_cast>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_lexical_cast> *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_lexical_cast> *)((char *)this - 24);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 4) = 0;
  std::bad_cast::~bad_cast(v3);
}


// Address: 0xe412a0 | Name: _ZThn24_N5boost16exception_detail19error_info_injectorINS_16bad_lexical_castEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_lexical_cast>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_lexical_cast> *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_lexical_cast> *)((char *)this - 24);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 4) = 0;
  std::bad_cast::~bad_cast(v3);
  operator delete(v3);
}


// Address: 0xe41310 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *x,
        __int64 a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 8) = &off_2875618;
  *(_QWORD *)this = off_287BC88;
  *(_OWORD *)((char *)this + 8) = *(_OWORD *)((char *)x + 8);
  *((_QWORD *)this + 3) = &off_2875508;
  v4 = *((_QWORD *)x + 4);
  *((_QWORD *)this + 4) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64, const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *, __int64))(*(_QWORD *)v4 + 24LL))(
      v4,
      x,
      a3);
  *((_DWORD *)this + 14) = *((_DWORD *)x + 14);
  *(_OWORD *)((char *)this + 40) = *(_OWORD *)((char *)x + 40);
  *(_QWORD *)this = off_287BBA0;
  *((_QWORD *)this + 3) = off_287BBD8;
  *((_QWORD *)this + 8) = &off_287BC10;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 24),
    (const boost::exception *)((char *)x + 24));
}


// Address: 0xe413e0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_16bad_lexical_castEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_lexical_cast> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 8) = &off_2875618;
  *(_QWORD *)this = off_287BC88;
  *(_OWORD *)((char *)this + 8) = *(_OWORD *)((char *)a2 + 8);
  *((_QWORD *)this + 3) = &off_2875508;
  v3 = *((_QWORD *)a2 + 4);
  *((_QWORD *)this + 4) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 14) = *((_DWORD *)a2 + 14);
  *(_OWORD *)((char *)this + 40) = *(_OWORD *)((char *)a2 + 40);
  *(_QWORD *)this = off_287BBA0;
  *((_QWORD *)this + 3) = off_287BBD8;
  *((_QWORD *)this + 8) = &off_287BC10;
}


// Address: 0xe422c0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEED1Ev
// attributes: thunk
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector(this);
}


// Address: 0xe422d0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options16validation_errorEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::validation_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 16) = &off_2875508;
  v2 = *((_QWORD *)this + 17);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 17) = 0;
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe42360 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options16validation_errorEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::validation_error>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::validation_error> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::validation_error> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *(_QWORD *)this = off_287BF38;
  *((_DWORD *)this + 30) = *((_DWORD *)a2 + 30);
  *((_QWORD *)this + 16) = &off_2875508;
  v3 = *((_QWORD *)a2 + 17);
  *((_QWORD *)this + 17) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 40) = *((_DWORD *)a2 + 40);
  *((_OWORD *)this + 9) = *((_OWORD *)a2 + 9);
  *(_QWORD *)this = &off_287BEE0;
  *((_QWORD *)this + 16) = off_287BF18;
}


// Address: 0xe42440 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe424f0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *)operator new(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe42540 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *)__cxa_allocate_exception(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl);
}


// Address: 0xe42590 | Name: _ZThn128_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *)((char *)this - 128));
}


// Address: 0xe425a0 | Name: _ZThn128_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0xe425c0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  char *v1; // rbx
  char *v2; // r14

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (char *)operator new(0xB0u);
  *((_QWORD *)v2 + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::validation_error> *)v2,
    (const boost::exception_detail::error_info_injector<boost::program_options::validation_error> *)v1);
  *(_QWORD *)v2 = &off_287BE30;
  *((_QWORD *)v2 + 16) = off_287BE78;
  *((_QWORD *)v2 + 21) = &off_287BEB0;
  boost::exception_detail::copy_boost_exception((boost::exception *)(v2 + 128), (const boost::exception *)(v1 + 128));
}


// Address: 0xe42660 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *)__cxa_allocate_exception(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl);
}


// Address: 0xe426b0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xe426c0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error> *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector(v1);
  operator delete(v1);
}


// Address: 0xe426e0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options16validation_errorEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::validation_error> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe42700 | Name: _ZThn128_N5boost16exception_detail19error_info_injectorINS_15program_options16validation_errorEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::validation_error> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::validation_error> *)((char *)this - 128));
}


// Address: 0xe42710 | Name: _ZThn128_N5boost16exception_detail19error_info_injectorINS_15program_options16validation_errorEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::validation_error> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::validation_error> *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0xe43670 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> >::clone_tag a3)
{
  *((_QWORD *)this + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::error_info_injector(this, x);
  *(_QWORD *)this = &off_287BE30;
  *((_QWORD *)this + 16) = off_287BE78;
  *((_QWORD *)this + 21) = &off_287BEB0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 128),
    (const boost::exception *)((char *)x + 128));
}


// Address: 0xe436f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16validation_errorEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::validation_error> > *a2)
{
  *((_QWORD *)this + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::validation_error>::error_info_injector(this, a2);
  *(_QWORD *)this = &off_287BE30;
  *((_QWORD *)this + 16) = off_287BE78;
  *((_QWORD *)this + 21) = &off_287BEB0;
}


// Address: 0xe43bb0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEED1Ev
// attributes: thunk
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector(this);
}


// Address: 0xe43bc0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options20invalid_option_valueEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 16) = &off_2875508;
  v2 = *((_QWORD *)this + 17);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 17) = 0;
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe43c50 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options20invalid_option_valueEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *((_DWORD *)this + 30) = *((_DWORD *)a2 + 30);
  *(_QWORD *)this = off_287C168;
  *((_QWORD *)this + 16) = &off_2875508;
  v3 = *((_QWORD *)a2 + 17);
  *((_QWORD *)this + 17) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 40) = *((_DWORD *)a2 + 40);
  *((_OWORD *)this + 9) = *((_OWORD *)a2 + 9);
  *(_QWORD *)this = &off_287C110;
  *((_QWORD *)this + 16) = off_287C148;
}


// Address: 0xe43d30 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe43d50 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *)operator new(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe43da0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *)__cxa_allocate_exception(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl);
}


// Address: 0xe43df0 | Name: _ZThn128_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *)((char *)this - 128));
}


// Address: 0xe43e00 | Name: _ZThn128_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0xe43e20 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  char *v1; // rbx
  char *v2; // r14

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (char *)operator new(0xB0u);
  *((_QWORD *)v2 + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *)v2,
    (const boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *)v1);
  *(_QWORD *)v2 = &off_287C060;
  *((_QWORD *)v2 + 16) = off_287C0A8;
  *((_QWORD *)v2 + 21) = &off_287C0E0;
  boost::exception_detail::copy_boost_exception((boost::exception *)(v2 + 128), (const boost::exception *)(v1 + 128));
}


// Address: 0xe43ec0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *)__cxa_allocate_exception(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl);
}


// Address: 0xe43f10 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xe43f20 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector(v1);
  operator delete(v1);
}


// Address: 0xe43f40 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options20invalid_option_valueEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe43f60 | Name: _ZThn128_N5boost16exception_detail19error_info_injectorINS_15program_options20invalid_option_valueEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *)((char *)this - 128));
}


// Address: 0xe43f70 | Name: _ZThn128_N5boost16exception_detail19error_info_injectorINS_15program_options20invalid_option_valueEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0xe43ff0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> >::clone_tag a3)
{
  *((_QWORD *)this + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::error_info_injector(
    this,
    x);
  *(_QWORD *)this = &off_287C060;
  *((_QWORD *)this + 16) = off_287C0A8;
  *((_QWORD *)this + 21) = &off_287C0E0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 128),
    (const boost::exception *)((char *)x + 128));
}


// Address: 0xe44070 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20invalid_option_valueEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value> > *a2)
{
  *((_QWORD *)this + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_option_value>::error_info_injector(
    this,
    a2);
  *(_QWORD *)this = &off_287C060;
  *((_QWORD *)this + 16) = off_287C0A8;
  *((_QWORD *)this + 21) = &off_287C0E0;
}


// Address: 0xe45150 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_cast::~bad_cast(this);
}


// Address: 0xe45190 | Name: _ZN5boost16exception_detail19error_info_injectorINS_12bad_any_castEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_any_cast>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_any_cast> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_cast::~bad_cast(this);
}


// Address: 0xe451d0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this,
        const boost::exception_detail::error_info_injector<boost::bad_any_cast> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_287C328, (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_287C240, (__m128i)(unsigned __int64)off_287C278);
  *((_QWORD *)this + 6) = &off_287C2B0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xe452b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_cast::~bad_cast(this);
  operator delete(this);
}


// Address: 0xe45310 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe45360 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl);
}


// Address: 0xe453b0 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_cast::~bad_cast(v3);
}


// Address: 0xe453f0 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_cast::~bad_cast(v3);
  operator delete(v3);
}


// Address: 0xe45440 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xe45490 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl);
}


// Address: 0xe454e0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  std::bad_cast *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_cast::~bad_cast(v1);
}


// Address: 0xe45530 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this)
{
  std::bad_cast *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_cast::~bad_cast(v1);
  operator delete(v1);
}


// Address: 0xe45580 | Name: _ZN5boost16exception_detail19error_info_injectorINS_12bad_any_castEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_any_cast>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_any_cast> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_cast::~bad_cast(this);
  operator delete(this);
}


// Address: 0xe455d0 | Name: _ZThn8_N5boost16exception_detail19error_info_injectorINS_12bad_any_castEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_any_cast>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_any_cast> *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_any_cast> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_cast::~bad_cast(v3);
}


// Address: 0xe45610 | Name: _ZThn8_N5boost16exception_detail19error_info_injectorINS_12bad_any_castEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_any_cast>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_any_cast> *this)
{
  __int64 v2; // rdi
  std::bad_cast *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_any_cast> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_cast::~bad_cast(v3);
  operator delete(v3);
}


// Address: 0xe45680 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *x,
        __int64 a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_287C328, (__m128i)(unsigned __int64)&off_2875508);
  v4 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64, const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *, __int64))(*(_QWORD *)v4 + 24LL))(
      v4,
      x,
      a3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_287C240, (__m128i)(unsigned __int64)off_287C278);
  *((_QWORD *)this + 6) = &off_287C2B0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xe45760 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_12bad_any_castEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_any_cast> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_287C328, (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)a2 + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)a2 + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)a2 + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_287C240, (__m128i)(unsigned __int64)off_287C278);
  *((_QWORD *)this + 6) = &off_287C2B0;
}


// Address: 0xe590c0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xe59100 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options26invalid_command_line_styleEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xe59140 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this,
        const boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_287CE98;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287D150;
  *((_QWORD *)this + 2) = off_287D188;
  *((_QWORD *)this + 7) = &off_287D1C0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xe59210 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe59260 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe592b0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl);
}


// Address: 0xe59300 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xe59340 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xe59390 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xe593e0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl);
}


// Address: 0xe59430 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xe59480 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xe594d0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options26invalid_command_line_styleEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe59520 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_15program_options26invalid_command_line_styleEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xe59560 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_15program_options26invalid_command_line_styleEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xe595b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_287CE98;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287D150;
  *((_QWORD *)this + 2) = off_287D188;
  *((_QWORD *)this + 7) = &off_287D1C0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xe59680 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options26invalid_command_line_styleEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_style> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_287CE98;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_287D150;
  *((_QWORD *)this + 2) = off_287D188;
  *((_QWORD *)this + 7) = &off_287D1C0;
}


// Address: 0xe5a130 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xe5a170 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options33too_many_positional_options_errorEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xe5a1b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this,
        const boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_287CF20;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287D2E0;
  *((_QWORD *)this + 2) = off_287D318;
  *((_QWORD *)this + 7) = &off_287D350;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xe5a280 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe5a2d0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe5a320 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl);
}


// Address: 0xe5a370 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xe5a3b0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xe5a400 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xe5a450 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl);
}


// Address: 0xe5a4a0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xe5a4f0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xe5a540 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options33too_many_positional_options_errorEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe5a590 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_15program_options33too_many_positional_options_errorEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xe5a5d0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_15program_options33too_many_positional_options_errorEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xe5a620 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_287CF20;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287D2E0;
  *((_QWORD *)this + 2) = off_287D318;
  *((_QWORD *)this + 7) = &off_287D350;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xe5a6f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options33too_many_positional_options_errorEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::too_many_positional_options_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_287CF20;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_287D2E0;
  *((_QWORD *)this + 2) = off_287D318;
  *((_QWORD *)this + 7) = &off_287D350;
}


// Address: 0xe5a780 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEED1Ev
// attributes: thunk
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector(this);
}


// Address: 0xe5a790 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options14unknown_optionEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 15) = &off_2875508;
  v2 = *((_QWORD *)this + 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 16) = 0;
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe5a820 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options14unknown_optionEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *(_QWORD *)this = off_287CF68;
  *((_QWORD *)this + 15) = &off_2875508;
  v3 = *((_QWORD *)a2 + 16);
  *((_QWORD *)this + 16) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 38) = *((_DWORD *)a2 + 38);
  *(_OWORD *)((char *)this + 136) = *(_OWORD *)((char *)a2 + 136);
  *(_QWORD *)this = &off_287D500;
  *((_QWORD *)this + 15) = off_287D538;
}


// Address: 0xe5a8f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe5a910 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *)operator new(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe5a960 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *)__cxa_allocate_exception(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl);
}


// Address: 0xe5a9b0 | Name: _ZThn120_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *)((char *)this - 120));
}


// Address: 0xe5a9c0 | Name: _ZThn120_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *)((char *)this - 120));
  operator delete((char *)this - 120);
}


// Address: 0xe5a9e0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  const boost::exception *v1; // rbx
  boost::exception *v2; // r14

  v1 = (const boost::exception *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception *)operator new(0xA8u);
  v2[4]._vptr$exception = (int (**)(void))&off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *)v2,
    (const boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *)v1);
  v2->_vptr$exception = (int (**)(void))&off_287D450;
  v2[3]._vptr$exception = (int (**)(void))off_287D498;
  v2[4]._vptr$exception = (int (**)(void))&off_287D4D0;
  boost::exception_detail::copy_boost_exception(v2 + 3, v1 + 3);
}


// Address: 0xe5aa80 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *)__cxa_allocate_exception(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl);
}


// Address: 0xe5aad0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xe5aae0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector(v1);
  operator delete(v1);
}


// Address: 0xe5ab00 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options14unknown_optionEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe5ab20 | Name: _ZThn120_N5boost16exception_detail19error_info_injectorINS_15program_options14unknown_optionEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *)((char *)this - 120));
}


// Address: 0xe5ab30 | Name: _ZThn120_N5boost16exception_detail19error_info_injectorINS_15program_options14unknown_optionEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *)((char *)this - 120));
  operator delete((char *)this - 120);
}


// Address: 0xe5ab50 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::clone_impl(
        boost::exception *this,
        const boost::exception *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> >::clone_tag a3)
{
  *((_QWORD *)this + 20) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *)this,
    (const boost::exception_detail::error_info_injector<boost::program_options::unknown_option> *)x);
  this->_vptr$exception = (int (**)(void))&off_287D450;
  *((_QWORD *)this + 15) = off_287D498;
  *((_QWORD *)this + 20) = &off_287D4D0;
  boost::exception_detail::copy_boost_exception(this + 3, x + 3);
}


// Address: 0xe5abd0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options14unknown_optionEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::unknown_option> > *a2)
{
  *((_QWORD *)this + 20) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::unknown_option>::error_info_injector(this, a2);
  *(_QWORD *)this = &off_287D450;
  *((_QWORD *)this + 15) = off_287D498;
  *((_QWORD *)this + 20) = &off_287D4D0;
}


// Address: 0xe5ac10 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEED1Ev
// attributes: thunk
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector(this);
}


// Address: 0xe5ac20 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options27invalid_command_line_syntaxEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 16) = &off_2875508;
  v2 = *((_QWORD *)this + 17);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 17) = 0;
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe5acb0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *((_DWORD *)this + 30) = *((_DWORD *)a2 + 30);
  *(_QWORD *)this = off_287D010;
  *((_QWORD *)this + 16) = &off_2875508;
  v3 = *((_QWORD *)a2 + 17);
  *((_QWORD *)this + 17) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 40) = *((_DWORD *)a2 + 40);
  *((_OWORD *)this + 9) = *((_OWORD *)a2 + 9);
  *(_QWORD *)this = &off_287D698;
  *((_QWORD *)this + 16) = off_287D6D8;
}


// Address: 0xe5ad90 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe5adb0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *)operator new(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe5ae00 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *)__cxa_allocate_exception(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl);
}


// Address: 0xe5ae50 | Name: _ZThn128_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *)((char *)this - 128));
}


// Address: 0xe5ae60 | Name: _ZThn128_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0xe5ae80 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  char *v1; // rbx
  char *v2; // r14

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (char *)operator new(0xB0u);
  *((_QWORD *)v2 + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *)v2,
    (const boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *)v1);
  *(_QWORD *)v2 = &off_287D5E0;
  *((_QWORD *)v2 + 16) = off_287D630;
  *((_QWORD *)v2 + 21) = &off_287D668;
  boost::exception_detail::copy_boost_exception((boost::exception *)(v2 + 128), (const boost::exception *)(v1 + 128));
}


// Address: 0xe5af20 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *)__cxa_allocate_exception(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl);
}


// Address: 0xe5af70 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xe5af80 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector(v1);
  operator delete(v1);
}


// Address: 0xe5afa0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options27invalid_command_line_syntaxEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe5afc0 | Name: _ZThn128_N5boost16exception_detail19error_info_injectorINS_15program_options27invalid_command_line_syntaxEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *)((char *)this - 128));
}


// Address: 0xe5afd0 | Name: _ZThn128_N5boost16exception_detail19error_info_injectorINS_15program_options27invalid_command_line_syntaxEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0xe5aff0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> >::clone_tag a3)
{
  *((_QWORD *)this + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::error_info_injector(
    this,
    x);
  *(_QWORD *)this = &off_287D5E0;
  *((_QWORD *)this + 16) = off_287D630;
  *((_QWORD *)this + 21) = &off_287D668;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 128),
    (const boost::exception *)((char *)x + 128));
}


// Address: 0xe5b070 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options27invalid_command_line_syntaxEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax> > *a2)
{
  *((_QWORD *)this + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_command_line_syntax>::error_info_injector(
    this,
    a2);
  *(_QWORD *)this = &off_287D5E0;
  *((_QWORD *)this + 16) = off_287D630;
  *((_QWORD *)this + 21) = &off_287D668;
}


// Address: 0xe5b760 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xe5b7a0 | Name: _ZN5boost16exception_detail19error_info_injectorISt11logic_errorED2Ev
void __fastcall boost::exception_detail::error_info_injector<std::logic_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::logic_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xe5b7e0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this,
        const boost::exception_detail::error_info_injector<std::logic_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287D7C0;
  *((_QWORD *)this + 2) = off_287D7F8;
  *((_QWORD *)this + 7) = &off_287D830;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xe5b8b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe5b900 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe5b950 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl);
}


// Address: 0xe5b9a0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xe5b9e0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xe5ba30 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xe5ba80 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl);
}


// Address: 0xe5bad0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xe5bb20 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xe5bb70 | Name: _ZN5boost16exception_detail19error_info_injectorISt11logic_errorED0Ev
void __fastcall boost::exception_detail::error_info_injector<std::logic_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::logic_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe5bbc0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt11logic_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::logic_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::logic_error> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::logic_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xe5bc00 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt11logic_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::logic_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::logic_error> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::logic_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xe5bc50 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287D7C0;
  *((_QWORD *)this + 2) = off_287D7F8;
  *((_QWORD *)this + 7) = &off_287D830;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xe5bd20 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt11logic_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::logic_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_287D7C0;
  *((_QWORD *)this + 2) = off_287D7F8;
  *((_QWORD *)this + 7) = &off_287D830;
}


// Address: 0xe61040 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xe61080 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options5errorEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0xe610c0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this,
        const boost::exception_detail::error_info_injector<boost::program_options::error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_287CEF8;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287D960;
  *((_QWORD *)this + 2) = off_287D998;
  *((_QWORD *)this + 7) = &off_287D9D0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xe61190 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe611e0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe61230 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl);
}


// Address: 0xe61280 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xe612c0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xe61310 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xe61360 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl);
}


// Address: 0xe613b0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0xe61400 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0xe61450 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options5errorEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0xe614a0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_15program_options5errorEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::error> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::program_options::error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0xe614e0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_15program_options5errorEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::error> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::program_options::error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0xe61530 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_287CEF8;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287D960;
  *((_QWORD *)this + 2) = off_287D998;
  *((_QWORD *)this + 7) = &off_287D9D0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xe61600 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options5errorEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_287CEF8;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_287D960;
  *((_QWORD *)this + 2) = off_287D998;
  *((_QWORD *)this + 7) = &off_287D9D0;
}


// Address: 0xe62410 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 18) = &off_2875508;
  v2 = *((_QWORD *)this + 19);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(this);
}


// Address: 0xe62460 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options16ambiguous_optionEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 18) = &off_2875508;
  v2 = *((_QWORD *)this + 19);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(this);
}


// Address: 0xe624b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this,
        const boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *x)
{
  *((_QWORD *)this + 23) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::error_info_injector(this, x);
  *(_QWORD *)this = &off_287DBF0;
  *((_QWORD *)this + 18) = off_287DC38;
  *((_QWORD *)this + 23) = &off_287DC70;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 144),
    (const boost::exception *)((char *)x + 144));
}


// Address: 0xe62570 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options16ambiguous_optionEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *(_QWORD *)this = off_287DE18;
  std::vector<std::string>::vector(
    (boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *)((char *)this + 120),
    (const boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *)((char *)a2 + 120));
  *((_QWORD *)this + 18) = &off_2875508;
  v3 = *((_QWORD *)a2 + 19);
  *((_QWORD *)this + 19) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 44) = *((_DWORD *)a2 + 44);
  *((_OWORD *)this + 10) = *((_OWORD *)a2 + 10);
  *(_QWORD *)this = &off_287DCA0;
  *((_QWORD *)this + 18) = off_287DCD8;
}


// Address: 0xe62670 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 18) = &off_2875508;
  v2 = *((_QWORD *)this + 19);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(this);
  operator delete(this);
}


// Address: 0xe626c0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)operator new(0xC0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe62710 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)__cxa_allocate_exception(0xC0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl);
}


// Address: 0xe62760 | Name: _ZThn144_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  __int64 v2; // rdi
  boost::program_options::ambiguous_option *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)((char *)this - 144);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(v3);
}


// Address: 0xe627b0 | Name: _ZThn144_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  __int64 v2; // rdi
  boost::program_options::ambiguous_option *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)((char *)this - 144);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(v3);
  operator delete(v3);
}


// Address: 0xe62800 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)operator new(0xC0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xe62850 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)__cxa_allocate_exception(0xC0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl);
}


// Address: 0xe628a0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  boost::program_options::ambiguous_option *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 18) = &off_2875508;
  v2 = *((_QWORD *)v1 + 19);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(v1);
}


// Address: 0xe628f0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this)
{
  boost::program_options::ambiguous_option *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 18) = &off_2875508;
  v2 = *((_QWORD *)v1 + 19);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(v1);
  operator delete(v1);
}


// Address: 0xe62950 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options16ambiguous_optionEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 18) = &off_2875508;
  v2 = *((_QWORD *)this + 19);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(this);
  operator delete(this);
}


// Address: 0xe629a0 | Name: _ZThn144_N5boost16exception_detail19error_info_injectorINS_15program_options16ambiguous_optionEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *this)
{
  __int64 v2; // rdi
  boost::program_options::ambiguous_option *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *)((char *)this - 144);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(v3);
}


// Address: 0xe629f0 | Name: _ZThn144_N5boost16exception_detail19error_info_injectorINS_15program_options16ambiguous_optionEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *this)
{
  __int64 v2; // rdi
  boost::program_options::ambiguous_option *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *)((char *)this - 144);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 19) = 0;
  boost::program_options::ambiguous_option::~ambiguous_option(v3);
  operator delete(v3);
}


// Address: 0xe62a40 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> >::clone_tag a3)
{
  *((_QWORD *)this + 23) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::error_info_injector(this, x);
  *(_QWORD *)this = &off_287DBF0;
  *((_QWORD *)this + 18) = off_287DC38;
  *((_QWORD *)this + 23) = &off_287DC70;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 144),
    (const boost::exception *)((char *)x + 144));
}


// Address: 0xe62b00 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options16ambiguous_optionEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> > *a2)
{
  *((_QWORD *)this + 23) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::error_info_injector(this, a2);
  *(_QWORD *)this = &off_287DBF0;
  *((_QWORD *)this + 18) = off_287DC38;
  *((_QWORD *)this + 23) = &off_287DC70;
}


// Address: 0xe62b40 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options16ambiguous_optionEEC2ERKS3_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *this,
        const boost::program_options::ambiguous_option *x)
{
  boost::program_options::error_with_option_name::error_with_option_name(this, x);
  *(_QWORD *)this = off_287DE18;
  std::vector<std::string>::vector(
    (boost::exception_detail::error_info_injector<boost::program_options::ambiguous_option> *)((char *)this + 120),
    (const boost::program_options::ambiguous_option *)((char *)x + 120));
  *(_OWORD *)((char *)this + 152) = 0;
  *((_QWORD *)this + 21) = 0;
  *((_DWORD *)this + 44) = -1;
  *(_QWORD *)this = &off_287DCA0;
  *((_QWORD *)this + 18) = off_287DCD8;
}


// Address: 0xe67710 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEED1Ev
// attributes: thunk
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector(this);
}


// Address: 0xe67720 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options20multiple_occurrencesEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 15) = &off_2875508;
  v2 = *((_QWORD *)this + 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 16) = 0;
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe677b0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options20multiple_occurrencesEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *(_QWORD *)this = off_287E048;
  *((_QWORD *)this + 15) = &off_2875508;
  v3 = *((_QWORD *)a2 + 16);
  *((_QWORD *)this + 16) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 38) = *((_DWORD *)a2 + 38);
  *(_OWORD *)((char *)this + 136) = *(_OWORD *)((char *)a2 + 136);
  *(_QWORD *)this = &off_287E220;
  *((_QWORD *)this + 15) = off_287E258;
}


// Address: 0xe67880 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe678a0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *)operator new(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe678f0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *)__cxa_allocate_exception(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl);
}


// Address: 0xe67940 | Name: _ZThn120_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *)((char *)this - 120));
}


// Address: 0xe67950 | Name: _ZThn120_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *)((char *)this - 120));
  operator delete((char *)this - 120);
}


// Address: 0xe67970 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  const boost::exception *v1; // rbx
  boost::exception *v2; // r14

  v1 = (const boost::exception *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception *)operator new(0xA8u);
  v2[4]._vptr$exception = (int (**)(void))&off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *)v2,
    (const boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *)v1);
  v2->_vptr$exception = (int (**)(void))&off_287E170;
  v2[3]._vptr$exception = (int (**)(void))off_287E1B8;
  v2[4]._vptr$exception = (int (**)(void))&off_287E1F0;
  boost::exception_detail::copy_boost_exception(v2 + 3, v1 + 3);
}


// Address: 0xe67a10 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *)__cxa_allocate_exception(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl);
}


// Address: 0xe67a60 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xe67a70 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector(v1);
  operator delete(v1);
}


// Address: 0xe67a90 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options20multiple_occurrencesEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe67ab0 | Name: _ZThn120_N5boost16exception_detail19error_info_injectorINS_15program_options20multiple_occurrencesEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *)((char *)this - 120));
}


// Address: 0xe67ac0 | Name: _ZThn120_N5boost16exception_detail19error_info_injectorINS_15program_options20multiple_occurrencesEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *)((char *)this - 120));
  operator delete((char *)this - 120);
}


// Address: 0xe67ae0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::clone_impl(
        boost::exception *this,
        const boost::exception *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> >::clone_tag a3)
{
  *((_QWORD *)this + 20) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *)this,
    (const boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> *)x);
  this->_vptr$exception = (int (**)(void))&off_287E170;
  *((_QWORD *)this + 15) = off_287E1B8;
  *((_QWORD *)this + 20) = &off_287E1F0;
  boost::exception_detail::copy_boost_exception(this + 3, x + 3);
}


// Address: 0xe67b60 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options20multiple_occurrencesEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences> > *a2)
{
  *((_QWORD *)this + 20) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::multiple_occurrences>::error_info_injector(
    this,
    a2);
  *(_QWORD *)this = &off_287E170;
  *((_QWORD *)this + 15) = off_287E1B8;
  *((_QWORD *)this + 20) = &off_287E1F0;
}


// Address: 0xe67ba0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEED1Ev
// attributes: thunk
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector(this);
}


// Address: 0xe67bb0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options15multiple_valuesEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 15) = &off_2875508;
  v2 = *((_QWORD *)this + 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 16) = 0;
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe67c40 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options15multiple_valuesEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *(_QWORD *)this = off_287E098;
  *((_QWORD *)this + 15) = &off_2875508;
  v3 = *((_QWORD *)a2 + 16);
  *((_QWORD *)this + 16) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 38) = *((_DWORD *)a2 + 38);
  *(_OWORD *)((char *)this + 136) = *(_OWORD *)((char *)a2 + 136);
  *(_QWORD *)this = &off_287E3B0;
  *((_QWORD *)this + 15) = off_287E3E8;
}


// Address: 0xe67d10 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe67d30 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *)operator new(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe67d80 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *)__cxa_allocate_exception(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl);
}


// Address: 0xe67dd0 | Name: _ZThn120_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *)((char *)this - 120));
}


// Address: 0xe67de0 | Name: _ZThn120_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *)((char *)this - 120));
  operator delete((char *)this - 120);
}


// Address: 0xe67e00 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  const boost::exception *v1; // rbx
  boost::exception *v2; // r14

  v1 = (const boost::exception *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception *)operator new(0xA8u);
  v2[4]._vptr$exception = (int (**)(void))&off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *)v2,
    (const boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *)v1);
  v2->_vptr$exception = (int (**)(void))&off_287E300;
  v2[3]._vptr$exception = (int (**)(void))off_287E348;
  v2[4]._vptr$exception = (int (**)(void))&off_287E380;
  boost::exception_detail::copy_boost_exception(v2 + 3, v1 + 3);
}


// Address: 0xe67ea0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *)__cxa_allocate_exception(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl);
}


// Address: 0xe67ef0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xe67f00 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector(v1);
  operator delete(v1);
}


// Address: 0xe67f20 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options15multiple_valuesEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe67f40 | Name: _ZThn120_N5boost16exception_detail19error_info_injectorINS_15program_options15multiple_valuesEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *)((char *)this - 120));
}


// Address: 0xe67f50 | Name: _ZThn120_N5boost16exception_detail19error_info_injectorINS_15program_options15multiple_valuesEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *)((char *)this - 120));
  operator delete((char *)this - 120);
}


// Address: 0xe67f70 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::clone_impl(
        boost::exception *this,
        const boost::exception *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> >::clone_tag a3)
{
  *((_QWORD *)this + 20) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *)this,
    (const boost::exception_detail::error_info_injector<boost::program_options::multiple_values> *)x);
  this->_vptr$exception = (int (**)(void))&off_287E300;
  *((_QWORD *)this + 15) = off_287E348;
  *((_QWORD *)this + 20) = &off_287E380;
  boost::exception_detail::copy_boost_exception(this + 3, x + 3);
}


// Address: 0xe67ff0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15multiple_valuesEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::multiple_values> > *a2)
{
  *((_QWORD *)this + 20) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::multiple_values>::error_info_injector(this, a2);
  *(_QWORD *)this = &off_287E300;
  *((_QWORD *)this + 15) = off_287E348;
  *((_QWORD *)this + 20) = &off_287E380;
}


// Address: 0xe68870 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEED1Ev
// attributes: thunk
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector(this);
}


// Address: 0xe68880 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options18invalid_bool_valueEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 16) = &off_2875508;
  v2 = *((_QWORD *)this + 17);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 17) = 0;
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe68910 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options18invalid_bool_valueEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *((_DWORD *)this + 30) = *((_DWORD *)a2 + 30);
  *(_QWORD *)this = off_287DD88;
  *((_QWORD *)this + 16) = &off_2875508;
  v3 = *((_QWORD *)a2 + 17);
  *((_QWORD *)this + 17) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 40) = *((_DWORD *)a2 + 40);
  *((_OWORD *)this + 9) = *((_OWORD *)a2 + 9);
  *(_QWORD *)this = &off_287E660;
  *((_QWORD *)this + 16) = off_287E698;
}


// Address: 0xe689f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe68a10 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *)operator new(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe68a60 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *)__cxa_allocate_exception(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl);
}


// Address: 0xe68ab0 | Name: _ZThn128_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *)((char *)this - 128));
}


// Address: 0xe68ac0 | Name: _ZThn128_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0xe68ae0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  char *v1; // rbx
  char *v2; // r14

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (char *)operator new(0xB0u);
  *((_QWORD *)v2 + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *)v2,
    (const boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *)v1);
  *(_QWORD *)v2 = &off_287E5B0;
  *((_QWORD *)v2 + 16) = off_287E5F8;
  *((_QWORD *)v2 + 21) = &off_287E630;
  boost::exception_detail::copy_boost_exception((boost::exception *)(v2 + 128), (const boost::exception *)(v1 + 128));
}


// Address: 0xe68b80 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *)__cxa_allocate_exception(0xB0u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl);
}


// Address: 0xe68bd0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xe68be0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector(v1);
  operator delete(v1);
}


// Address: 0xe68c00 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options18invalid_bool_valueEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe68c20 | Name: _ZThn128_N5boost16exception_detail19error_info_injectorINS_15program_options18invalid_bool_valueEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *)((char *)this - 128));
}


// Address: 0xe68c30 | Name: _ZThn128_N5boost16exception_detail19error_info_injectorINS_15program_options18invalid_bool_valueEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0xe68c50 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> >::clone_tag a3)
{
  *((_QWORD *)this + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::error_info_injector(this, x);
  *(_QWORD *)this = &off_287E5B0;
  *((_QWORD *)this + 16) = off_287E5F8;
  *((_QWORD *)this + 21) = &off_287E630;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 128),
    (const boost::exception *)((char *)x + 128));
}


// Address: 0xe68cd0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options18invalid_bool_valueEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value> > *a2)
{
  *((_QWORD *)this + 21) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::invalid_bool_value>::error_info_injector(
    this,
    a2);
  *(_QWORD *)this = &off_287E5B0;
  *((_QWORD *)this + 16) = off_287E5F8;
  *((_QWORD *)this + 21) = &off_287E630;
}


// Address: 0xe6ab20 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEED1Ev
// attributes: thunk
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector(this);
}


// Address: 0xe6ab30 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options15required_optionEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::required_option> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 15) = &off_2875508;
  v2 = *((_QWORD *)this + 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 16) = 0;
  *(_QWORD *)this = off_287DDC0;
  if ( (*((_BYTE *)this + 96) & 1) != 0 )
    operator delete(*((void **)this + 14));
  if ( (*((_BYTE *)this + 72) & 1) != 0 )
    operator delete(*((void **)this + 11));
  std::__tree<std::__value_type<std::string,std::pair<std::string,std::string>>,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string>>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > > *)this
  + 2,
    *((std::__tree<std::__value_type<std::string,std::pair<std::string,std::string > >,std::__map_value_compare<std::string,std::__value_type<std::string,std::pair<std::string,std::string > >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::pair<std::string,std::string > > > >::__node_pointer *)this
    + 7));
  std::__tree<std::__value_type<std::string,std::string>,std::__map_value_compare<std::string,std::__value_type<std::string,std::string>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,std::string>>>::destroy(
    (std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > > *)this
  + 1,
    *((std::__tree<std::__value_type<std::string,std::string >,std::__map_value_compare<std::string,std::__value_type<std::string,std::string >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,std::string > > >::__node_pointer *)this
    + 4));
  std::logic_error::~logic_error(this);
}


// Address: 0xe6abc0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options15required_optionEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::required_option>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::required_option> *this,
        const boost::exception_detail::error_info_injector<boost::program_options::required_option> *a2)
{
  __int64 v3; // rdi

  boost::program_options::error_with_option_name::error_with_option_name(this, a2);
  *(_QWORD *)this = off_287E7E8;
  *((_QWORD *)this + 15) = &off_2875508;
  v3 = *((_QWORD *)a2 + 16);
  *((_QWORD *)this + 16) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 38) = *((_DWORD *)a2 + 38);
  *(_OWORD *)((char *)this + 136) = *(_OWORD *)((char *)a2 + 136);
  *(_QWORD *)this = &off_287E970;
  *((_QWORD *)this + 15) = off_287E9A8;
}


// Address: 0xe6ac90 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe6acb0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *)operator new(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xe6ad00 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *)__cxa_allocate_exception(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl);
}


// Address: 0xe6ad50 | Name: _ZThn120_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *)((char *)this - 120));
}


// Address: 0xe6ad60 | Name: _ZThn120_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *)((char *)this - 120));
  operator delete((char *)this - 120);
}


// Address: 0xe6ad80 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  const boost::exception *v1; // rbx
  boost::exception *v2; // r14

  v1 = (const boost::exception *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception *)operator new(0xA8u);
  v2[4]._vptr$exception = (int (**)(void))&off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::required_option> *)v2,
    (const boost::exception_detail::error_info_injector<boost::program_options::required_option> *)v1);
  v2->_vptr$exception = (int (**)(void))&off_287E8C0;
  v2[3]._vptr$exception = (int (**)(void))off_287E908;
  v2[4]._vptr$exception = (int (**)(void))&off_287E940;
  boost::exception_detail::copy_boost_exception(v2 + 3, v1 + 3);
}


// Address: 0xe6ae20 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *)__cxa_allocate_exception(0xA8u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl);
}


// Address: 0xe6ae70 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector((boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0xe6ae80 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option> *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector(v1);
  operator delete(v1);
}


// Address: 0xe6aea0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_15program_options15required_optionEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::required_option> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector(this);
  operator delete(this);
}


// Address: 0xe6aec0 | Name: _ZThn120_N5boost16exception_detail19error_info_injectorINS_15program_options15required_optionEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::required_option> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::required_option> *)((char *)this - 120));
}


// Address: 0xe6aed0 | Name: _ZThn120_N5boost16exception_detail19error_info_injectorINS_15program_options15required_optionEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::program_options::required_option> *this)
{
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::~error_info_injector((boost::exception_detail::error_info_injector<boost::program_options::required_option> *)((char *)this - 120));
  operator delete((char *)this - 120);
}


// Address: 0xe6aef0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::clone_impl(
        boost::exception *this,
        const boost::exception *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> >::clone_tag a3)
{
  *((_QWORD *)this + 20) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::error_info_injector(
    (boost::exception_detail::error_info_injector<boost::program_options::required_option> *)this,
    (const boost::exception_detail::error_info_injector<boost::program_options::required_option> *)x);
  this->_vptr$exception = (int (**)(void))&off_287E8C0;
  *((_QWORD *)this + 15) = off_287E908;
  *((_QWORD *)this + 20) = &off_287E940;
  boost::exception_detail::copy_boost_exception(this + 3, x + 3);
}


// Address: 0xe6af70 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_15program_options15required_optionEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::program_options::required_option> > *a2)
{
  *((_QWORD *)this + 20) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::program_options::required_option>::error_info_injector(this, a2);
  *(_QWORD *)this = &off_287E8C0;
  *((_QWORD *)this + 15) = off_287E908;
  *((_QWORD *)this + 20) = &off_287E940;
}


// Address: 0xea7e30 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::length_error::~length_error(this);
}


// Address: 0xea7e70 | Name: _ZN5boost16exception_detail19error_info_injectorISt12length_errorED2Ev
void __fastcall boost::exception_detail::error_info_injector<std::length_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::length_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::length_error::~length_error(this);
}


// Address: 0xea7eb0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this,
        const boost::exception_detail::error_info_injector<std::length_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::length_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287F2F0;
  *((_QWORD *)this + 2) = off_287F328;
  *((_QWORD *)this + 7) = &off_287F360;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xea7f80 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::length_error::~length_error(this);
  operator delete(this);
}


// Address: 0xea7fd0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xea8020 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl);
}


// Address: 0xea8070 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  __int64 v2; // rdi
  std::length_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::length_error::~length_error(v3);
}


// Address: 0xea80b0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  __int64 v2; // rdi
  std::length_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::length_error::~length_error(v3);
  operator delete(v3);
}


// Address: 0xea8100 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xea8150 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl);
}


// Address: 0xea81a0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  std::length_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::length_error::~length_error(v1);
}


// Address: 0xea81f0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this)
{
  std::length_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::length_error::~length_error(v1);
  operator delete(v1);
}


// Address: 0xea8240 | Name: _ZN5boost16exception_detail19error_info_injectorISt12length_errorED0Ev
void __fastcall boost::exception_detail::error_info_injector<std::length_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::length_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::length_error::~length_error(this);
  operator delete(this);
}


// Address: 0xea8290 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt12length_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::length_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::length_error> *this)
{
  __int64 v2; // rdi
  std::length_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::length_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::length_error::~length_error(v3);
}


// Address: 0xea82d0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt12length_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::length_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::length_error> *this)
{
  __int64 v2; // rdi
  std::length_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::length_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::length_error::~length_error(v3);
  operator delete(v3);
}


// Address: 0xea8320 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::length_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_287F2F0;
  *((_QWORD *)this + 2) = off_287F328;
  *((_QWORD *)this + 7) = &off_287F360;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xea83f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12length_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::length_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::length_error + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_287F2F0;
  *((_QWORD *)this + 2) = off_287F328;
  *((_QWORD *)this + 7) = &off_287F360;
}


// Address: 0xf80670 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_alloc::~bad_alloc(this);
}


// Address: 0xf806b0 | Name: _ZN5boost16exception_detail19error_info_injectorISt9bad_allocED2Ev
void __fastcall boost::exception_detail::error_info_injector<std::bad_alloc>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::bad_alloc> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_alloc::~bad_alloc(this);
}


// Address: 0xf806f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this,
        const boost::exception_detail::error_info_injector<std::bad_alloc> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_alloc + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2885380, (__m128i)(unsigned __int64)off_28853B8);
  *((_QWORD *)this + 6) = &off_28853F0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xf807e0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_alloc::~bad_alloc(this);
  operator delete(this);
}


// Address: 0xf80830 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xf80880 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl);
}


// Address: 0xf808d0 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  __int64 v2; // rdi
  std::bad_alloc *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_alloc::~bad_alloc(v3);
}


// Address: 0xf80910 | Name: _ZThn8_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  __int64 v2; // rdi
  std::bad_alloc *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_alloc::~bad_alloc(v3);
  operator delete(v3);
}


// Address: 0xf80960 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)operator new(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xf809b0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)__cxa_allocate_exception(0x38u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl);
}


// Address: 0xf80a00 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  std::bad_alloc *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_alloc::~bad_alloc(v1);
}


// Address: 0xf80a50 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this)
{
  std::bad_alloc *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 1) = &off_2875508;
  v2 = *((_QWORD *)v1 + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 2) = 0;
  std::bad_alloc::~bad_alloc(v1);
  operator delete(v1);
}


// Address: 0xf80aa0 | Name: _ZN5boost16exception_detail19error_info_injectorISt9bad_allocED0Ev
void __fastcall boost::exception_detail::error_info_injector<std::bad_alloc>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::bad_alloc> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 1) = &off_2875508;
  v2 = *((_QWORD *)this + 2);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 2) = 0;
  std::bad_alloc::~bad_alloc(this);
  operator delete(this);
}


// Address: 0xf80af0 | Name: _ZThn8_N5boost16exception_detail19error_info_injectorISt9bad_allocED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::bad_alloc>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::bad_alloc> *this)
{
  __int64 v2; // rdi
  std::bad_alloc *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::bad_alloc> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_alloc::~bad_alloc(v3);
}


// Address: 0xf80b30 | Name: _ZThn8_N5boost16exception_detail19error_info_injectorISt9bad_allocED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::bad_alloc>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::bad_alloc> *this)
{
  __int64 v2; // rdi
  std::bad_alloc *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::bad_alloc> *)((char *)this - 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 2) = 0;
  std::bad_alloc::~bad_alloc(v3);
  operator delete(v3);
}


// Address: 0xf80b80 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *x,
        __int64 a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_alloc + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v4 = *((_QWORD *)x + 2);
  *((_QWORD *)this + 2) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64, const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *, __int64))(*(_QWORD *)v4 + 24LL))(
      v4,
      x,
      a3);
  *((_DWORD *)this + 10) = *((_DWORD *)x + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)x + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2885380, (__m128i)(unsigned __int64)off_28853B8);
  *((_QWORD *)this + 6) = &off_28853F0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 8),
    (const boost::exception *)((char *)x + 8));
}


// Address: 0xf80c70 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt9bad_allocEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::bad_alloc> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 6) = &off_2875618;
  *(__m128i *)this = _mm_unpacklo_epi64(
                       (__m128i)((unsigned __int64)&`vtable for'std::bad_alloc + 16),
                       (__m128i)(unsigned __int64)&off_2875508);
  v3 = *((_QWORD *)a2 + 2);
  *((_QWORD *)this + 2) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 10) = *((_DWORD *)a2 + 10);
  *(_OWORD *)((char *)this + 24) = *(_OWORD *)((char *)a2 + 24);
  *(__m128i *)this = _mm_unpacklo_epi64((__m128i)(unsigned __int64)off_2885380, (__m128i)(unsigned __int64)off_28853B8);
  *((_QWORD *)this + 6) = &off_28853F0;
}


// Address: 0xfe7e70 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0xfe7eb0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_9gregorian8bad_yearEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::gregorian::bad_year>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_year> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0xfe7ef0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this,
        const boost::exception_detail::error_info_injector<boost::gregorian::bad_year> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2889BE8;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2889B00;
  *((_QWORD *)this + 2) = off_2889B38;
  *((_QWORD *)this + 7) = &off_2889B70;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xfe7fc0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0xfe8010 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xfe8060 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl);
}


// Address: 0xfe80b0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0xfe80f0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0xfe8140 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xfe8190 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl);
}


// Address: 0xfe81e0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
}


// Address: 0xfe8230 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
  operator delete(v1);
}


// Address: 0xfe8280 | Name: _ZN5boost16exception_detail19error_info_injectorINS_9gregorian8bad_yearEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::gregorian::bad_year>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_year> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0xfe82d0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_9gregorian8bad_yearEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::gregorian::bad_year>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_year> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::gregorian::bad_year> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0xfe8310 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_9gregorian8bad_yearEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::gregorian::bad_year>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_year> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::gregorian::bad_year> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0xfe8380 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2889BE8;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2889B00;
  *((_QWORD *)this + 2) = off_2889B38;
  *((_QWORD *)this + 7) = &off_2889B70;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xfe8450 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian8bad_yearEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_year> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_2889BE8;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2889B00;
  *((_QWORD *)this + 2) = off_2889B38;
  *((_QWORD *)this + 7) = &off_2889B70;
}


// Address: 0xfe8710 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0xfe8750 | Name: _ZN5boost16exception_detail19error_info_injectorINS_9gregorian9bad_monthEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::gregorian::bad_month>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_month> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0xfe8790 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this,
        const boost::exception_detail::error_info_injector<boost::gregorian::bad_month> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2889D98;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2889CB0;
  *((_QWORD *)this + 2) = off_2889CE8;
  *((_QWORD *)this + 7) = &off_2889D20;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xfe8860 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0xfe88b0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xfe8900 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl);
}


// Address: 0xfe8950 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0xfe8990 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0xfe89e0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xfe8a30 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl);
}


// Address: 0xfe8a80 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
}


// Address: 0xfe8ad0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
  operator delete(v1);
}


// Address: 0xfe8b20 | Name: _ZN5boost16exception_detail19error_info_injectorINS_9gregorian9bad_monthEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::gregorian::bad_month>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_month> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0xfe8b70 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_9gregorian9bad_monthEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::gregorian::bad_month>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_month> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::gregorian::bad_month> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0xfe8bb0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_9gregorian9bad_monthEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::gregorian::bad_month>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_month> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::gregorian::bad_month> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0xfe8c20 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2889D98;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2889CB0;
  *((_QWORD *)this + 2) = off_2889CE8;
  *((_QWORD *)this + 7) = &off_2889D20;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xfe8cf0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian9bad_monthEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_month> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_2889D98;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2889CB0;
  *((_QWORD *)this + 2) = off_2889CE8;
  *((_QWORD *)this + 7) = &off_2889D20;
}


// Address: 0xfe8fc0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0xfe9000 | Name: _ZN5boost16exception_detail19error_info_injectorINS_9gregorian16bad_day_of_monthEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0xfe9040 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this,
        const boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2889F48;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2889E60;
  *((_QWORD *)this + 2) = off_2889E98;
  *((_QWORD *)this + 7) = &off_2889ED0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xfe9110 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0xfe9160 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xfe91b0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl);
}


// Address: 0xfe9200 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0xfe9240 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0xfe9290 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xfe92e0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl);
}


// Address: 0xfe9330 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
}


// Address: 0xfe9380 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
  operator delete(v1);
}


// Address: 0xfe93d0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_9gregorian16bad_day_of_monthEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0xfe9420 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_9gregorian16bad_day_of_monthEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0xfe9460 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_9gregorian16bad_day_of_monthEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0xfe94d0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_2889F48;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2889E60;
  *((_QWORD *)this + 2) = off_2889E98;
  *((_QWORD *)this + 7) = &off_2889ED0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xfe95a0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_9gregorian16bad_day_of_monthEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::gregorian::bad_day_of_month> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_2889F48;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2889E60;
  *((_QWORD *)this + 2) = off_2889E98;
  *((_QWORD *)this + 7) = &off_2889ED0;
}


// Address: 0xfe9950 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
}


// Address: 0xfe9990 | Name: _ZN5boost16exception_detail19error_info_injectorISt13runtime_errorED2Ev
void __fastcall boost::exception_detail::error_info_injector<std::runtime_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::runtime_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
}


// Address: 0xfe99d0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this,
        const boost::exception_detail::error_info_injector<std::runtime_error> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2889FF0;
  *((_QWORD *)this + 2) = off_288A028;
  *((_QWORD *)this + 7) = &off_288A060;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xfe9aa0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xfe9af0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0xfe9b40 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl);
}


// Address: 0xfe9b90 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
}


// Address: 0xfe9bd0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
  operator delete(v3);
}


// Address: 0xfe9c20 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0xfe9c70 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl);
}


// Address: 0xfe9cc0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  std::runtime_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::runtime_error::~runtime_error(v1);
}


// Address: 0xfe9d10 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this)
{
  std::runtime_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::runtime_error::~runtime_error(v1);
  operator delete(v1);
}


// Address: 0xfe9d60 | Name: _ZN5boost16exception_detail19error_info_injectorISt13runtime_errorED0Ev
void __fastcall boost::exception_detail::error_info_injector<std::runtime_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::runtime_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0xfe9db0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt13runtime_errorED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::runtime_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::runtime_error> *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::runtime_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
}


// Address: 0xfe9df0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt13runtime_errorED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::runtime_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::runtime_error> *this)
{
  __int64 v2; // rdi
  std::runtime_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::runtime_error> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::runtime_error::~runtime_error(v3);
  operator delete(v3);
}


// Address: 0xfe9e40 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_2889FF0;
  *((_QWORD *)this + 2) = off_288A028;
  *((_QWORD *)this + 7) = &off_288A060;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0xfe9f10 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt13runtime_errorEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::runtime_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_2889FF0;
  *((_QWORD *)this + 2) = off_288A028;
  *((_QWORD *)this + 7) = &off_288A060;
}


// Address: 0x1218070 | Name: _ZN5boost16exception_detail19error_info_injectorISt12out_of_rangeED2Ev
void __fastcall boost::exception_detail::error_info_injector<std::out_of_range>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::out_of_range> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0x12180b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
}


// Address: 0x12180f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this,
        const boost::exception_detail::error_info_injector<std::out_of_range> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::out_of_range + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28A2E20;
  *((_QWORD *)this + 2) = off_28A2E58;
  *((_QWORD *)this + 7) = &off_28A2E90;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0x12181c0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0x1218210 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0x1218260 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl);
}


// Address: 0x12182b0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0x12182f0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0x1218340 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0x1218390 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl);
}


// Address: 0x12183e0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
}


// Address: 0x1218430 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this)
{
  std::out_of_range *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::out_of_range::~out_of_range(v1);
  operator delete(v1);
}


// Address: 0x1218480 | Name: _ZN5boost16exception_detail19error_info_injectorISt12out_of_rangeED0Ev
void __fastcall boost::exception_detail::error_info_injector<std::out_of_range>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::out_of_range> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::out_of_range::~out_of_range(this);
  operator delete(this);
}


// Address: 0x12184d0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt12out_of_rangeED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::out_of_range>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::out_of_range> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::out_of_range> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
}


// Address: 0x1218510 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt12out_of_rangeED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::out_of_range>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::out_of_range> *this)
{
  __int64 v2; // rdi
  std::out_of_range *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::out_of_range> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::out_of_range::~out_of_range(v3);
  operator delete(v3);
}


// Address: 0x1218560 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::out_of_range + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28A2E20;
  *((_QWORD *)this + 2) = off_28A2E58;
  *((_QWORD *)this + 7) = &off_28A2E90;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0x1218630 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt12out_of_rangeEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::out_of_range> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::out_of_range + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_28A2E20;
  *((_QWORD *)this + 2) = off_28A2E58;
  *((_QWORD *)this + 7) = &off_28A2E90;
}


// Address: 0x1282c50 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::invalid_argument::~invalid_argument(this);
}


// Address: 0x1282c90 | Name: _ZN5boost16exception_detail19error_info_injectorISt16invalid_argumentED2Ev
void __fastcall boost::exception_detail::error_info_injector<std::invalid_argument>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::invalid_argument> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::invalid_argument::~invalid_argument(this);
}


// Address: 0x1282cd0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this,
        const boost::exception_detail::error_info_injector<std::invalid_argument> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::invalid_argument + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28A5430;
  *((_QWORD *)this + 2) = off_28A5468;
  *((_QWORD *)this + 7) = &off_28A54A0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0x1282da0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::invalid_argument::~invalid_argument(this);
  operator delete(this);
}


// Address: 0x1282df0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0x1282e40 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl);
}


// Address: 0x1282e90 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  __int64 v2; // rdi
  std::invalid_argument *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::invalid_argument::~invalid_argument(v3);
}


// Address: 0x1282ed0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  __int64 v2; // rdi
  std::invalid_argument *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::invalid_argument::~invalid_argument(v3);
  operator delete(v3);
}


// Address: 0x1282f20 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0x1282f70 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl);
}


// Address: 0x1282fc0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  std::invalid_argument *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::invalid_argument::~invalid_argument(v1);
}


// Address: 0x1283010 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this)
{
  std::invalid_argument *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::invalid_argument::~invalid_argument(v1);
  operator delete(v1);
}


// Address: 0x1283060 | Name: _ZN5boost16exception_detail19error_info_injectorISt16invalid_argumentED0Ev
void __fastcall boost::exception_detail::error_info_injector<std::invalid_argument>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::invalid_argument> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::invalid_argument::~invalid_argument(this);
  operator delete(this);
}


// Address: 0x12830b0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt16invalid_argumentED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::invalid_argument>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::invalid_argument> *this)
{
  __int64 v2; // rdi
  std::invalid_argument *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::invalid_argument> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::invalid_argument::~invalid_argument(v3);
}


// Address: 0x12830f0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorISt16invalid_argumentED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::invalid_argument>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::invalid_argument> *this)
{
  __int64 v2; // rdi
  std::invalid_argument *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::invalid_argument> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::invalid_argument::~invalid_argument(v3);
  operator delete(v3);
}


// Address: 0x1283140 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::invalid_argument + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28A5430;
  *((_QWORD *)this + 2) = off_28A5468;
  *((_QWORD *)this + 7) = &off_28A54A0;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0x1283210 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorISt16invalid_argumentEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::invalid_argument> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::invalid_argument + 16;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_28A5430;
  *((_QWORD *)this + 2) = off_28A5468;
  *((_QWORD *)this + 7) = &off_28A54A0;
}


// Address: 0x1284c40 | Name: j_._ZNSt9exceptionD2Ev
// attributes: thunk
void __fastcall std::exception::~exception(boost::exception_detail::clone_impl<std::exception> *this)
{
  ._ZNSt9exceptionD2Ev(this);
}


// Address: 0x1284c50 | Name: _ZN5boost16exception_detail10clone_implISt9exceptionED0Ev
void __fastcall boost::exception_detail::clone_impl<std::exception>::~clone_impl(
        boost::exception_detail::clone_impl<std::exception> *this)
{
  std::exception::~exception(this);
  operator delete(this);
}


// Address: 0x1284c70 | Name: _ZNK5boost16exception_detail10clone_implISt9exceptionE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<std::exception>::clone(
        const boost::exception_detail::clone_impl<std::exception> *this)
{
  char *v1; // rax

  v1 = (char *)operator new(0x10u);
  *(__m128i *)v1 = _mm_unpacklo_epi64((__m128i)(unsigned __int64)&off_28A55F0, (__m128i)(unsigned __int64)&off_28A5640);
  return (const boost::exception_detail::clone_base *)(v1 + 8);
}


// Address: 0x1284cb0 | Name: _ZNK5boost16exception_detail10clone_implISt9exceptionE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<std::exception>::rethrow(
        const boost::exception_detail::clone_impl<std::exception> *this)
{
  __m128i *exception; // rax

  exception = (__m128i *)__cxa_allocate_exception(0x10u);
  *exception = _mm_unpacklo_epi64((__m128i)(unsigned __int64)&off_28A55F0, (__m128i)(unsigned __int64)&off_28A5640);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<std::exception>,
    (void (*)(void *))std::exception::~exception);
}


// Address: 0x1284d00 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implISt9exceptionE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<std::exception>::clone(
        const boost::exception_detail::clone_impl<std::exception> *this)
{
  *(__m128i *)operator new(0x10u) = _mm_unpacklo_epi64(
                                      (__m128i)(unsigned __int64)&off_28A55F0,
                                      (__m128i)(unsigned __int64)&off_28A5640);
}


// Address: 0x1284d40 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implISt9exceptionE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<std::exception>::rethrow(
        const boost::exception_detail::clone_impl<std::exception> *this)
{
  __m128i *exception; // rax

  exception = (__m128i *)__cxa_allocate_exception(0x10u);
  *exception = _mm_unpacklo_epi64((__m128i)(unsigned __int64)&off_28A55F0, (__m128i)(unsigned __int64)&off_28A5640);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<std::exception>,
    (void (*)(void *))std::exception::~exception);
}


// Address: 0x1284d90 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implISt9exceptionED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<std::exception>::~clone_impl(
        boost::exception_detail::clone_impl<std::exception> *this)
{
  std::exception::~exception((boost::exception_detail::clone_impl<std::exception> *)((char *)this
                                                                                   + *(_QWORD *)(*(_QWORD *)this - 40LL)));
}


// Address: 0x1284da0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implISt9exceptionED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<std::exception>::~clone_impl(
        boost::exception_detail::clone_impl<std::exception> *this)
{
  std::exception *v1; // rbx

  v1 = (boost::exception_detail::clone_impl<std::exception> *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  std::exception::~exception(v1);
  operator delete(v1);
}


// Address: 0x14b8d80 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0x14b8dc0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_19bad_optional_accessEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_optional_access>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_optional_access> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
}


// Address: 0x14b8e00 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEEC1ERKS4_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this,
        const boost::exception_detail::error_info_injector<boost::bad_optional_access> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_28BAEB8;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28BADD0;
  *((_QWORD *)this + 2) = off_28BAE08;
  *((_QWORD *)this + 7) = &off_28BAE40;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0x14b8ed0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0x14b8f20 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0x14b8f70 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl);
}


// Address: 0x14b8fc0 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0x14b9000 | Name: _ZThn16_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0x14b9050 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)operator new(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0x14b90a0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)__cxa_allocate_exception(0x40u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl);
}


// Address: 0x14b90f0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
}


// Address: 0x14b9140 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this)
{
  std::logic_error *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 2) = &off_2875508;
  v2 = *((_QWORD *)v1 + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 3) = 0;
  std::logic_error::~logic_error(v1);
  operator delete(v1);
}


// Address: 0x14b9190 | Name: _ZN5boost16exception_detail19error_info_injectorINS_19bad_optional_accessEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::bad_optional_access>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_optional_access> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 2) = &off_2875508;
  v2 = *((_QWORD *)this + 3);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 3) = 0;
  std::logic_error::~logic_error(this);
  operator delete(this);
}


// Address: 0x14b91e0 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_19bad_optional_accessEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_optional_access>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_optional_access> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_optional_access> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
}


// Address: 0x14b9220 | Name: _ZThn16_N5boost16exception_detail19error_info_injectorINS_19bad_optional_accessEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::bad_optional_access>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::bad_optional_access> *this)
{
  __int64 v2; // rdi
  std::logic_error *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<boost::bad_optional_access> *)((char *)this - 16);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 3) = 0;
  std::logic_error::~logic_error(v3);
  operator delete(v3);
}


// Address: 0x14b9290 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEEC1ERKS5_NS5_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, x);
  *(_QWORD *)this = off_28BAEB8;
  *((_QWORD *)this + 2) = &off_2875508;
  v4 = *((_QWORD *)x + 3);
  *((_QWORD *)this + 3) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 12) = *((_DWORD *)x + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)x + 2);
  *(_QWORD *)this = off_28BADD0;
  *((_QWORD *)this + 2) = off_28BAE08;
  *((_QWORD *)this + 7) = &off_28BAE40;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 16),
    (const boost::exception *)((char *)x + 16));
}


// Address: 0x14b9360 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_19bad_optional_accessEEEEC1ERKS5_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::bad_optional_access> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 7) = &off_2875618;
  std::logic_error::logic_error(this, a2);
  *(_QWORD *)this = off_28BAEB8;
  *((_QWORD *)this + 2) = &off_2875508;
  v3 = *((_QWORD *)a2 + 3);
  *((_QWORD *)this + 3) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 12) = *((_DWORD *)a2 + 12);
  *((_OWORD *)this + 2) = *((_OWORD *)a2 + 2);
  *(_QWORD *)this = off_28BADD0;
  *((_QWORD *)this + 2) = off_28BAE08;
  *((_QWORD *)this + 7) = &off_28BAE40;
}


// Address: 0x202a0b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::ios_base::failure::~failure(this);
}


// Address: 0x202a0f0 | Name: _ZN5boost16exception_detail19error_info_injectorINSt3__18ios_base7failureEED2Ev
void __fastcall boost::exception_detail::error_info_injector<std::ios_base::failure>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::ios_base::failure> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::ios_base::failure::~failure(this);
}


// Address: 0x202a130 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this,
        const boost::exception_detail::error_info_injector<std::ios_base::failure> *x)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::system_error + 16;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = (char *)&`vtable for'std::ios_base::failure + 16;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_29A6D20;
  *((_QWORD *)this + 4) = off_29A6D58;
  *((_QWORD *)this + 9) = &off_29A6D90;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0x202a210 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::ios_base::failure::~failure(this);
  operator delete(this);
}


// Address: 0x202a260 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0x202a2b0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl);
}


// Address: 0x202a300 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  __int64 v2; // rdi
  std::ios_base::failure *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::ios_base::failure::~failure(v3);
}


// Address: 0x202a340 | Name: _ZThn32_N5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  __int64 v2; // rdi
  std::ios_base::failure *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::ios_base::failure::~failure(v3);
  operator delete(v3);
}


// Address: 0x202a390 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *v2; // r14
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> >::clone_tag v3; // dl

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL));
  v2 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)operator new(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone_impl(
    v2,
    v1,
    v3);
}


// Address: 0x202a3e0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)__cxa_allocate_exception(0x50u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl);
}


// Address: 0x202a430 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  std::ios_base::failure *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::ios_base::failure::~failure(v1);
}


// Address: 0x202a480 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this)
{
  std::ios_base::failure *v1; // rbx
  __int64 v2; // rdi

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL));
  *((_QWORD *)v1 + 4) = &off_2875508;
  v2 = *((_QWORD *)v1 + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 5) = 0;
  std::ios_base::failure::~failure(v1);
  operator delete(v1);
}


// Address: 0x202a4d0 | Name: _ZN5boost16exception_detail19error_info_injectorINSt3__18ios_base7failureEED0Ev
void __fastcall boost::exception_detail::error_info_injector<std::ios_base::failure>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::ios_base::failure> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 4) = &off_2875508;
  v2 = *((_QWORD *)this + 5);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 5) = 0;
  std::ios_base::failure::~failure(this);
  operator delete(this);
}


// Address: 0x202a520 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINSt3__18ios_base7failureEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::ios_base::failure>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::ios_base::failure> *this)
{
  __int64 v2; // rdi
  std::ios_base::failure *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::ios_base::failure> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::ios_base::failure::~failure(v3);
}


// Address: 0x202a560 | Name: _ZThn32_N5boost16exception_detail19error_info_injectorINSt3__18ios_base7failureEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<std::ios_base::failure>::~error_info_injector(
        boost::exception_detail::error_info_injector<std::ios_base::failure> *this)
{
  __int64 v2; // rdi
  std::ios_base::failure *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (boost::exception_detail::error_info_injector<std::ios_base::failure> *)((char *)this - 32);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 5) = 0;
  std::ios_base::failure::~failure(v3);
  operator delete(v3);
}


// Address: 0x202a5b0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEEC1ERKS7_NS7_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> >::clone_tag a3)
{
  __int64 v4; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::runtime_error::runtime_error(this, x);
  *(_QWORD *)this = (char *)&`vtable for'std::system_error + 16;
  *((_OWORD *)this + 1) = *((_OWORD *)x + 1);
  *(_QWORD *)this = (char *)&`vtable for'std::ios_base::failure + 16;
  *((_QWORD *)this + 4) = &off_2875508;
  v4 = *((_QWORD *)x + 5);
  *((_QWORD *)this + 5) = v4;
  if ( v4 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  *((_DWORD *)this + 16) = *((_DWORD *)x + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)x + 3);
  *(_QWORD *)this = off_29A6D20;
  *((_QWORD *)this + 4) = off_29A6D58;
  *((_QWORD *)this + 9) = &off_29A6D90;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 32),
    (const boost::exception *)((char *)x + 32));
}


// Address: 0x202a690 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINSt3__18ios_base7failureEEEEC1ERKS7_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<std::ios_base::failure> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 9) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = (char *)&`vtable for'std::system_error + 16;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  *(_QWORD *)this = (char *)&`vtable for'std::ios_base::failure + 16;
  *((_QWORD *)this + 4) = &off_2875508;
  v3 = *((_QWORD *)a2 + 5);
  *((_QWORD *)this + 5) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 16) = *((_DWORD *)a2 + 16);
  *((_OWORD *)this + 3) = *((_OWORD *)a2 + 3);
  *(_QWORD *)this = off_29A6D20;
  *((_QWORD *)this + 4) = off_29A6D58;
  *((_QWORD *)this + 9) = &off_29A6D90;
}


// Address: 0x25f4580 | Name: _ZN5boost24enable_current_exceptionINS_16exception_detail19error_info_injectorINS_6system12system_errorEEEEENS1_10clone_implIT_EERKS7_
__int64 __fastcall boost::enable_current_exception<boost::exception_detail::error_info_injector<boost::system::system_error>>(
        __int64 a1,
        __int64 a2)
{
  __int64 v3; // rdi

  *(_QWORD *)(a1 + 96) = &off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)a1, (const std::runtime_error *)a2);
  *(_QWORD *)a1 = off_2875F00;
  *(_OWORD *)(a1 + 16) = *(_OWORD *)(a2 + 16);
  std::string::basic_string(a1 + 32, a2 + 32);
  *(_QWORD *)(a1 + 56) = &off_2875508;
  v3 = *(_QWORD *)(a2 + 64);
  *(_QWORD *)(a1 + 64) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *(_DWORD *)(a1 + 88) = *(_DWORD *)(a2 + 88);
  *(_OWORD *)(a1 + 72) = *(_OWORD *)(a2 + 72);
  *(_QWORD *)a1 = off_29C2700;
  *(_QWORD *)(a1 + 56) = off_29C2738;
  *(_QWORD *)(a1 + 96) = &off_29C2770;
  boost::exception_detail::copy_boost_exception((boost::exception *)(a1 + 56), (const boost::exception *)(a2 + 56));
  return a1;
}


// Address: 0x25f4680 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEED1Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0x25f46e0 | Name: _ZN5boost16exception_detail19error_info_injectorINS_6system12system_errorEED2Ev
void __fastcall boost::exception_detail::error_info_injector<boost::system::system_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::system::system_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
}


// Address: 0x25f4740 | Name: _ZN5boost16exception_detail19error_info_injectorINS_6system12system_errorEEC2ERKS4_
void __fastcall boost::exception_detail::error_info_injector<boost::system::system_error>::error_info_injector(
        boost::exception_detail::error_info_injector<boost::system::system_error> *this,
        const boost::exception_detail::error_info_injector<boost::system::system_error> *a2)
{
  __int64 v3; // rdi

  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875F00;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  std::string::basic_string((char *)this + 32, (char *)a2 + 32);
  *((_QWORD *)this + 7) = &off_2875508;
  v3 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 22) = *((_DWORD *)a2 + 22);
  *(_OWORD *)((char *)this + 72) = *(_OWORD *)((char *)a2 + 72);
  *(_QWORD *)this = off_29C27A0;
  *((_QWORD *)this + 7) = off_29C27C8;
}


// Address: 0x25f47f0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEED0Ev
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0x25f4850 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEE5cloneEv
const boost::exception_detail::clone_base *__fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> >::clone_tag v2; // dl

  v1 = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *)operator new(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::clone_impl(
    v1,
    this,
    v2);
  return (const boost::exception_detail::clone_base *)((char *)v1 + *(_QWORD *)(*(_QWORD *)v1 - 24LL));
}


// Address: 0x25f48a0 | Name: _ZNK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEE7rethrowEv
void __fastcall __noreturn boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *exception; // rbx

  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *)__cxa_allocate_exception(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::clone_impl(
    exception,
    this);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl);
}


// Address: 0x25f48f0 | Name: _ZThn56_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
}


// Address: 0x25f4950 | Name: _ZThn56_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
  operator delete(v3);
}


// Address: 0x25f49b0 | Name: _ZTv0_n24_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEE5cloneEv
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::clone(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  char *v1; // r14
  char *v2; // r15
  __int64 v3; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 24LL);
  v2 = (char *)operator new(0x68u);
  *((_QWORD *)v2 + 12) = &off_2875618;
  std::runtime_error::runtime_error((std::runtime_error *)v2, (const std::runtime_error *)v1);
  *(_QWORD *)v2 = off_2875F00;
  *((_OWORD *)v2 + 1) = *((_OWORD *)v1 + 1);
  std::string::basic_string(v2 + 32, v1 + 32);
  *((_QWORD *)v2 + 7) = &off_2875508;
  v3 = *((_QWORD *)v1 + 8);
  *((_QWORD *)v2 + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)v2 + 22) = *((_DWORD *)v1 + 22);
  *(_OWORD *)(v2 + 72) = *(_OWORD *)(v1 + 72);
  *(_QWORD *)v2 = off_29C2700;
  *((_QWORD *)v2 + 7) = off_29C2738;
  *((_QWORD *)v2 + 12) = &off_29C2770;
  boost::exception_detail::copy_boost_exception((boost::exception *)(v2 + 56), (const boost::exception *)(v1 + 56));
}


// Address: 0x25f4af0 | Name: _ZTv0_n32_NK5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEE7rethrowEv
void __fastcall __noreturn `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::rethrow(
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *v1; // rbx
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *exception; // r14

  v1 = (const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *)((char *)this + *(_QWORD *)(*(_QWORD *)this - 32LL));
  exception = (boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *)__cxa_allocate_exception(0x68u);
  boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::clone_impl(
    exception,
    v1);
  __cxa_throw(
    exception,
    (struct type_info *)&`typeinfo for'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>,
    (void (*)(void *))boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl);
}


// Address: 0x25f4b40 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEED1Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  char *v1; // rbx
  __int64 v2; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL);
  *((_QWORD *)v1 + 7) = &off_2875508;
  v2 = *((_QWORD *)v1 + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)v1 = off_2875F00;
  if ( (v1[32] & 1) != 0 )
    operator delete(*((void **)v1 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
}


// Address: 0x25f4ba0 | Name: _ZTv0_n40_N5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEED0Ev
void __fastcall `virtual thunk to'boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::~clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this)
{
  char *v1; // rbx
  __int64 v2; // rdi

  v1 = (char *)this + *(_QWORD *)(*(_QWORD *)this - 40LL);
  *((_QWORD *)v1 + 7) = &off_2875508;
  v2 = *((_QWORD *)v1 + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v1 + 8) = 0;
  *(_QWORD *)v1 = off_2875F00;
  if ( (v1[32] & 1) != 0 )
    operator delete(*((void **)v1 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v1);
  operator delete(v1);
}


// Address: 0x25f4c10 | Name: _ZN5boost16exception_detail19error_info_injectorINS_6system12system_errorEED0Ev
void __fastcall boost::exception_detail::error_info_injector<boost::system::system_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::system::system_error> *this)
{
  __int64 v2; // rdi

  *((_QWORD *)this + 7) = &off_2875508;
  v2 = *((_QWORD *)this + 8);
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)this + 8) = 0;
  *(_QWORD *)this = off_2875F00;
  if ( (*((_BYTE *)this + 32) & 1) != 0 )
    operator delete(*((void **)this + 6));
  std::runtime_error::~runtime_error(this);
  operator delete(this);
}


// Address: 0x25f4c70 | Name: _ZThn56_N5boost16exception_detail19error_info_injectorINS_6system12system_errorEED1Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::system::system_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::system::system_error> *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
}


// Address: 0x25f4cd0 | Name: _ZThn56_N5boost16exception_detail19error_info_injectorINS_6system12system_errorEED0Ev
void __fastcall `non-virtual thunk to'boost::exception_detail::error_info_injector<boost::system::system_error>::~error_info_injector(
        boost::exception_detail::error_info_injector<boost::system::system_error> *this)
{
  __int64 v2; // rdi
  char *v3; // rbx

  *(_QWORD *)this = &off_2875508;
  v2 = *((_QWORD *)this + 1);
  v3 = (char *)this - 56;
  if ( v2 && (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2) )
    *((_QWORD *)v3 + 8) = 0;
  *(_QWORD *)v3 = off_2875F00;
  if ( (v3[32] & 1) != 0 )
    operator delete(*((void **)v3 + 6));
  std::runtime_error::~runtime_error((std::runtime_error *)v3);
  operator delete(v3);
}


// Address: 0x25f4d30 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEEC1ERKS6_NS6_9clone_tagE
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *x,
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> >::clone_tag a3)
{
  *((_QWORD *)this + 12) = &off_2875618;
  boost::exception_detail::error_info_injector<boost::system::system_error>::error_info_injector(this, x);
  *(_QWORD *)this = off_29C2700;
  *((_QWORD *)this + 7) = off_29C2738;
  *((_QWORD *)this + 12) = &off_29C2770;
  boost::exception_detail::copy_boost_exception(
    (boost::exception *)((char *)this + 56),
    (const boost::exception *)((char *)x + 56));
}


// Address: 0x25f4da0 | Name: _ZN5boost16exception_detail10clone_implINS0_19error_info_injectorINS_6system12system_errorEEEEC1ERKS6_
void __fastcall boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error>>::clone_impl(
        boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *this,
        const boost::exception_detail::clone_impl<boost::exception_detail::error_info_injector<boost::system::system_error> > *a2)
{
  __int64 v3; // rdi

  *((_QWORD *)this + 12) = &off_2875618;
  std::runtime_error::runtime_error(this, a2);
  *(_QWORD *)this = off_2875F00;
  *((_OWORD *)this + 1) = *((_OWORD *)a2 + 1);
  std::string::basic_string((char *)this + 32, (char *)a2 + 32);
  *((_QWORD *)this + 7) = &off_2875508;
  v3 = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 8) = v3;
  if ( v3 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v3 + 24LL))(v3);
  *((_DWORD *)this + 22) = *((_DWORD *)a2 + 22);
  *(_OWORD *)((char *)this + 72) = *(_OWORD *)((char *)a2 + 72);
  *(_QWORD *)this = off_29C2700;
  *((_QWORD *)this + 7) = off_29C2738;
  *((_QWORD *)this + 12) = &off_29C2770;
}


