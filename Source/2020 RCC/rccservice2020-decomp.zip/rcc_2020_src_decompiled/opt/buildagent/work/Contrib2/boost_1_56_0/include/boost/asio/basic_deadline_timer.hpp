// Address: 0x26055a0 | Name: _ZN5boost4asio20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsIS3_EENS0_22deadline_timer_serviceIS3_S5_EEEC2ERNS0_10io_serviceERKNS2_13time_durationE
void __fastcall boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>::basic_deadline_timer(
        boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *this,
        boost::asio::io_service *io_service,
        const boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > >::duration_type *expiry_time)
{
  boost::asio::detail::service_registry *service_registry; // rdi
  int m_val; // ebp
  const boost::system::error_category *m_cat; // r14
  boost::system::error_code v8; // [rsp+0h] [rbp-68h] BYREF
  boost::asio::io_service::service::key_0 key; // [rsp+10h] [rbp-58h] BYREF
  int v10; // [rsp+20h] [rbp-48h]
  const boost::system::error_category *v11; // [rsp+28h] [rbp-40h]
  __int128 v12; // [rsp+30h] [rbp-38h]
  void *ptr; // [rsp+40h] [rbp-28h]

  service_registry = io_service->service_registry_;
  key.type_info_ = (const std::type_info *)&`typeinfo for'boost::asio::detail::typeid_wrapper<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>;
  key.id_ = 0;
  this->service = (boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false>::service_type *)boost::asio::detail::service_registry::do_use_service(service_registry, &key, boost::asio::detail::service_registry::create<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>);
  this->implementation.timer_data.op_queue_ = 0;
  *(_OWORD *)&this->implementation.timer_data.next_ = 0;
  this->implementation.expiry.time_.time_count_.value_ = 0x7FFFFFFFFFFFFFFELL;
  this->implementation.might_have_pending_waits = 0;
  v8.m_val = 0;
  v8.m_cat = boost::system::system_category();
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::expires_from_now(
    (boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this->service + 40),
    &this->implementation,
    expiry_time,
    &v8);
  m_val = v8.m_val;
  if ( v8.m_val )
  {
    m_cat = v8.m_cat;
    std::runtime_error::runtime_error((std::runtime_error *)&key, "expires_from_now");
    key.type_info_ = (const std::type_info *)off_2875F00;
    v10 = m_val;
    v11 = m_cat;
    v12 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)&key);
  }
}


// Address: 0x2612800 | Name: _ZN5boost4asio20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsIS3_EENS0_22deadline_timer_serviceIS3_S5_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISF_EEEENSB_8write_opINS0_6detail17consuming_buffersINS0_12const_bufferENSt3__16vectorISM_NSN_9allocatorISM_EEEEEEEENSK_8write_opINSA_6streamISI_EESR_NSK_14transfer_all_tEN11websocketpp9transport4asio20custom_alloc_handlerINSN_8functionIFvRKNS_6system10error_codeEmEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvS14_EE4typeEE4typeEOS1E_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > >::type __fastcall boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *this,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false>::service_type *service; // rbx
  _BYTE v3[16]; // [rsp+0h] [rbp-148h] BYREF
  void *v4; // [rsp+10h] [rbp-138h]
  void *v5; // [rsp+18h] [rbp-130h]
  void *ptr; // [rsp+78h] [rbp-D0h]
  void *v7; // [rsp+80h] [rbp-C8h]
  char v8; // [rsp+E0h] [rbp-68h] BYREF
  char *v9; // [rsp+100h] [rbp-48h]
  unsigned __int64 v10; // [rsp+128h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  service = this->service;
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>::io_op(
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v3,
    handler);
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer>>>,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
    (boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false>::service_type *)((char *)service + 40),
    &this->implementation,
    (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::write_op<boost::asio::detail::consuming_buffers<boost::asio::const_buffer,std::vector<boost::asio::const_buffer> > >,boost::asio::detail::write_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,std::vector<boost::asio::const_buffer>,boost::asio::detail::transfer_all_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)v3);
  if ( &v8 == v9 )
  {
    (*(void (__fastcall **)(char *))(*(_QWORD *)v9 + 32LL))(v9);
  }
  else if ( v9 )
  {
    (*(void (**)(void))(*(_QWORD *)v9 + 40LL))();
  }
  if ( ptr )
  {
    v7 = ptr;
    operator delete(ptr);
  }
  if ( v4 )
  {
    v5 = v4;
    operator delete(v4);
  }
}


// Address: 0x2616230 | Name: _ZN5boost4asio20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsIS3_EENS0_22deadline_timer_serviceIS3_S5_EEE10async_waitINS0_3ssl6detail5io_opINS0_19basic_stream_socketINS0_2ip3tcpENS0_21stream_socket_serviceISF_EEEENSB_7read_opINS0_17mutable_buffers_1EEENS0_6detail7read_opINSA_6streamISI_EESK_NSM_19transfer_at_least_tEN11websocketpp9transport4asio20custom_alloc_handlerINSt3__18functionIFvRKNS_6system10error_codeEmEEEEEEEEEEENS0_12async_resultINS0_12handler_typeIT_FvSY_EE4typeEE4typeEOS18_
boost::asio::async_result<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > >::type __fastcall boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
        boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *this,
        boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *handler)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // r9
  boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false>::service_type *service; // r14
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *f; // rdi
  boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > v9; // [rsp+0h] [rbp-E8h] BYREF
  unsigned __int64 v10; // [rsp+C8h] [rbp-20h]

  v10 = __readfsqword(0x28u);
  service = this->service;
  *(_OWORD *)&v9.next_layer_ = *(_OWORD *)&handler->next_layer_;
  v9.op_ = handler->op_;
  v9.start_ = handler->start_;
  v9.want_ = handler->want_;
  v9.ec_ = handler->ec_;
  *(_OWORD *)&v9.bytes_transferred_ = *(_OWORD *)&handler->bytes_transferred_;
  v9.handler_.stream_ = handler->handler_.stream_;
  v9.handler_.buffer_ = handler->handler_.buffer_;
  v9.handler_.start_ = handler->handler_.start_;
  *(_OWORD *)&v9.handler_.total_transferred_ = *(_OWORD *)&handler->handler_.total_transferred_;
  f = (boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *)handler->handler_.handler_.handler_.__f_;
  if ( f )
  {
    if ( &handler->handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)f )
    {
      v9.handler_.handler_.handler_.__f_ = (std::function<void (const boost::system::error_code &,unsigned long)>::__base *)&v9.handler_.handler_.handler_;
      ((void (__fastcall *)(boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> >,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > >,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void (const boost::system::error_code &,unsigned long)> > > > *, std::function<void (const boost::system::error_code &,unsigned long)> *, __int64, __int64, __int64, __int64, boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > *, boost::asio::ssl::detail::stream_core *, void *, size_t, _QWORD, _QWORD, const boost::system::error_category *, size_t, size_t, boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp> > > *, void *, size_t, int, size_t, websocketpp::transport::asio::handler_allocator *))f->next_layer_->service_)(
        f,
        &v9.handler_.handler_.handler_,
        v2,
        v3,
        v4,
        v5,
        v9.next_layer_,
        v9.core_,
        v9.op_.buffers_.data_,
        v9.op_.buffers_.size_,
        *(_QWORD *)&v9.start_,
        *(_QWORD *)&v9.ec_.m_val,
        v9.ec_.m_cat,
        v9.bytes_transferred_,
        v9.handler_.completion_condition_.minimum_,
        v9.handler_.stream_,
        v9.handler_.buffer_.data_,
        v9.handler_.buffer_.size_,
        v9.handler_.start_,
        v9.handler_.total_transferred_,
        v9.handler_.handler_.allocator_);
    }
    else
    {
      v9.handler_.handler_.handler_.__f_ = handler->handler_.handler_.handler_.__f_;
      handler->handler_.handler_.handler_.__f_ = 0;
    }
  }
  else
  {
    v9.handler_.handler_.handler_.__f_ = 0;
  }
  boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::async_wait<boost::asio::ssl::detail::io_op<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>,boost::asio::ssl::detail::read_op<boost::asio::mutable_buffers_1>,boost::asio::detail::read_op<boost::asio::ssl::stream<boost::asio::basic_stream_socket<boost::asio::ip::tcp,boost::asio::stream_socket_service<boost::asio::ip::tcp>>>,boost::asio::mutable_buffers_1,boost::asio::detail::transfer_at_least_t,websocketpp::transport::asio::custom_alloc_handler<std::function<void ()(boost::system::error_code const&,unsigned long)>>>>>(
    (boost::asio::basic_io_object<boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> >,false>::service_type *)((char *)service + 40),
    &this->implementation,
    &v9);
  if ( &v9.handler_.handler_.handler_ == (std::function<void (const boost::system::error_code &,unsigned long)> *)v9.handler_.handler_.handler_.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (const boost::system::error_code &,unsigned long)>::__base *))v9.handler_.handler_.handler_.__f_->_vptr$__base
     + 4))(v9.handler_.handler_.handler_.__f_);
  }
  else if ( v9.handler_.handler_.handler_.__f_ )
  {
    (*((void (**)(void))v9.handler_.handler_.handler_.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x2698020 | Name: _ZN5boost4asio20basic_deadline_timerINS_10posix_time5ptimeENS0_11time_traitsIS3_EENS0_22deadline_timer_serviceIS3_S5_EEE16expires_from_nowERKNS2_13time_durationE
size_t __fastcall boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>>>::expires_from_now(
        boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > > *this,
        const boost::asio::basic_deadline_timer<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime>,boost::asio::deadline_timer_service<boost::posix_time::ptime,boost::asio::time_traits<boost::posix_time::ptime> > >::duration_type *expiry_time)
{
  size_t result; // rax
  int m_val; // ebp
  const boost::system::error_category *m_cat; // rbx
  boost::system::error_code v5; // [rsp+0h] [rbp-68h] BYREF
  _QWORD v6[2]; // [rsp+10h] [rbp-58h] BYREF
  int v7; // [rsp+20h] [rbp-48h]
  const boost::system::error_category *v8; // [rsp+28h] [rbp-40h]
  __int128 v9; // [rsp+30h] [rbp-38h]
  void *ptr; // [rsp+40h] [rbp-28h]

  v5.m_val = 0;
  v5.m_cat = boost::system::system_category();
  result = boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime>>::expires_from_now(
             (boost::asio::detail::deadline_timer_service<boost::asio::time_traits<boost::posix_time::ptime> > *)((char *)this->service + 40),
             &this->implementation,
             expiry_time,
             &v5);
  m_val = v5.m_val;
  if ( v5.m_val )
  {
    m_cat = v5.m_cat;
    std::runtime_error::runtime_error((std::runtime_error *)v6, "expires_from_now");
    v6[0] = off_2875F00;
    v7 = m_val;
    v8 = m_cat;
    v9 = 0;
    ptr = 0;
    boost::throw_exception<boost::system::system_error>((const boost::system::system_error *)v6);
  }
  return result;
}


