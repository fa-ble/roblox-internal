// Address: 0x10ce1c0 | Name: _ZN3RBX12GuiDrawImage8setImageEPNS_5AdornERKNS_9TextureIdEPN3G3D7Vector2EPNS_8InstanceEPKcb
__int64 __fastcall RBX::GuiDrawImage::setImage(
        rbx::signals::connection *this,
        RBX::Adorn *adorn,
        const RBX::TextureId *textureId,
        RBX::Vector2 *outSize,
        RBX::Instance *contextInstance,
        char *contextProperty,
        __m128 a7,
        char a8)
{
  rbx::signal<void ()> *v12; // rax
  rbx::signals::slot_base *p; // rdi
  bool v14; // al
  int v15; // edx
  void *v16; // rcx
  size_t v17; // r8
  const void *v18; // r9
  char *v19; // r13
  volatile signed __int32 *v20; // rbx
  unsigned __int64 v21; // rax
  size_t v22; // rax
  rbx::signals::slot_base *v23; // rbp
  char *v24; // r14
  size_t v25; // rbx
  volatile signed __int32 *v26; // rbx
  volatile signed __int32 *v27; // rbx
  __int64 v28; // rdi
  void *v30; // rax
  char v31; // [rsp+Fh] [rbp-D9h] BYREF
  rbx::signals::connection other[2]; // [rsp+10h] [rbp-D8h] BYREF
  void *v33; // [rsp+20h] [rbp-C8h]
  RBX::Vector2 *v34; // [rsp+30h] [rbp-B8h]
  RBX::Adorn *v35; // [rsp+38h] [rbp-B0h]
  boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::GuiDrawImage>,boost::_bi::list1<boost::_bi::value<RBX::GuiDrawImage *> > > function; // [rsp+40h] [rbp-A8h] BYREF
  char v37; // [rsp+58h] [rbp-90h]
  void *v38; // [rsp+68h] [rbp-80h]
  char v39; // [rsp+70h] [rbp-78h]
  void *ptr; // [rsp+80h] [rbp-68h]
  __m128i v41; // [rsp+90h] [rbp-58h] BYREF
  RBX::Instance *instance; // [rsp+A0h] [rbp-48h]
  char *s; // [rsp+A8h] [rbp-40h]

  s = contextProperty;
  if ( !RBX::operator!=(textureId, (const RBX::ContentId *)this) )
    goto LABEL_50;
  if ( !(_BYTE)byte_2A08A58 && __cxa_guard_acquire(&byte_2A08A58) )
  {
    xmmword_2A08A40 = 0;
    qword_2A08A50 = 0;
    __cxa_atexit((void (*)(void *))RBX::ContentId::~ContentId, &xmmword_2A08A40, &dso_handle);
    __cxa_guard_release(&byte_2A08A58);
  }
  std::string::basic_string(&function, &xmmword_2A08A40);
  if ( ((__int64)this->weak_slot.p_ & 1) != 0 )
  {
    **((_BYTE **)this + 2) = 0;
    *((_QWORD *)this + 1) = 0;
  }
  else
  {
    LOWORD(this->weak_slot.p_) = 0;
  }
  instance = contextInstance;
  std::string::reserve(this, 0);
  *(this + 2) = (rbx::signals::connection)function.l_.a1_.t_;
  a7 = (__m128)_mm_loadu_si128((const __m128i *)&function);
  *(__m128 *)&this->weak_slot.p_ = a7;
  v34 = outSize;
  if ( !rbx::signals::connection::connected(this + 9) )
  {
    v12 = (rbx::signal<void ()> *)(*(__int64 (__fastcall **)(RBX::Adorn *))(*(_QWORD *)adorn + 48LL))(adorn);
    a7 = (__m128)(unsigned __int64)RBX::GuiDrawImage::OnUnbindResourceSignalHint;
    function.f_ = (boost::_mfi::mf0<void,RBX::GuiDrawImage>)(unsigned __int64)RBX::GuiDrawImage::OnUnbindResourceSignalHint;
    function.l_.a1_.t_ = (RBX::GuiDrawImage *)this;
    rbx::signal<void ()(void)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::GuiDrawImage>,boost::_bi::list1<boost::_bi::value<RBX::GuiDrawImage*>>>>(
      v12,
      &function);
    if ( rbx::signals::connection::operator!=(this + 9, other) )
    {
      rbx::signals::connection::disconnect(this + 9);
      rbx::signals::connection::operator=(this + 9, other);
    }
    p = other[0].weak_slot.p_;
    if ( other[0].weak_slot.p_ && !_InterlockedSub(&other[0].weak_slot.p_->weak.v, 1u) )
      operator delete(p);
    outSize = v34;
  }
  v35 = adorn;
  v14 = RBX::operator!=(textureId, (const RBX::ContentId *)(this + 3));
  v19 = s;
  if ( v14 )
  {
    v20 = (volatile signed __int32 *)*((_QWORD *)this + 7);
    a7 = 0;
    *((_OWORD *)this + 3) = 0;
    if ( v20 )
    {
      if ( !_InterlockedSub(v20 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 16LL))(v20);
        if ( !_InterlockedSub(v20 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 24LL))(v20);
      }
    }
    *((_QWORD *)this + 8) = 0;
    std::string::operator=((soap *)(this + 3), (int)textureId, v15, v16, v17, v18);
    outSize = v34;
  }
  v21 = *(unsigned __int8 *)textureId;
  if ( (v21 & 1) != 0 )
  {
    if ( !*((_QWORD *)textureId + 1) )
      goto LABEL_49;
  }
  else if ( !(v21 >> 1) )
  {
    goto LABEL_49;
  }
  v31 = 0;
  *(_OWORD *)&other[0].weak_slot.p_ = 0;
  v33 = 0;
  v22 = strlen(v19);
  if ( v22 >= 0xFFFFFFFFFFFFFFF0LL )
  {
    v30 = (void *)std::__basic_string_common<true>::__throw_length_error(other);
    sub_D9C950(v30);
  }
  v23 = (rbx::signals::slot_base *)v22;
  if ( v22 >= 0x17 )
  {
    v25 = (v22 + 16) & 0xFFFFFFFFFFFFFFF0LL;
    v24 = (char *)operator new(v25);
    v33 = v24;
    other[0].weak_slot.p_ = (rbx::signals::slot_base *)(v25 | 1);
    other[1].weak_slot.p_ = v23;
  }
  else
  {
    LOBYTE(other[0].weak_slot.p_) = 2 * v22;
    v24 = (char *)&other[0].weak_slot.p_ + 1;
    if ( !v22 )
      goto LABEL_29;
  }
  memcpy(v24, v19, (size_t)v23);
LABEL_29:
  *((_BYTE *)&v23->strong.v + (_QWORD)v24) = 0;
  RBX::InstanceIdentifier::InstanceIdentifier(
    (RBX::InstanceIdentifier *)&function,
    instance,
    (const std::string *)other);
  (*(void (__fastcall **)(__m128i *, RBX::Adorn *, const RBX::TextureId *, char *, boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::GuiDrawImage>,boost::_bi::list1<boost::_bi::value<RBX::GuiDrawImage *> > > *, _QWORD))(*(_QWORD *)v35 + 24LL))(
    &v41,
    v35,
    textureId,
    &v31,
    &function,
    0);
  a7 = (__m128)_mm_load_si128(&v41);
  v41 = 0;
  v26 = (volatile signed __int32 *)*((_QWORD *)this + 7);
  *((__m128 *)this + 3) = a7;
  if ( v26 )
  {
    if ( !_InterlockedSub(v26 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 16LL))(v26);
      if ( !_InterlockedSub(v26 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 24LL))(v26);
    }
  }
  v27 = (volatile signed __int32 *)v41.m128i_i64[1];
  if ( v41.m128i_i64[1] )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(v41.m128i_i64[1] + 8), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 16LL))(v27);
      if ( !_InterlockedSub(v27 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 24LL))(v27);
    }
  }
  if ( (v39 & 1) != 0 )
    operator delete(ptr);
  outSize = v34;
  if ( (v37 & 1) != 0 )
  {
    operator delete(v38);
    if ( ((__int64)function.f_.f_ & 1) == 0 )
    {
LABEL_41:
      if ( ((__int64)other[0].weak_slot.p_ & 1) == 0 )
        goto LABEL_42;
      goto LABEL_47;
    }
  }
  else if ( ((__int64)function.f_.f_ & 1) == 0 )
  {
    goto LABEL_41;
  }
  operator delete(function.l_.a1_.t_);
  if ( ((__int64)other[0].weak_slot.p_ & 1) == 0 )
  {
LABEL_42:
    if ( v31 )
      goto LABEL_43;
    goto LABEL_48;
  }
LABEL_47:
  operator delete(v33);
  if ( !v31 )
  {
LABEL_48:
    if ( !(*(unsigned __int8 (__fastcall **)(_QWORD))(**((_QWORD **)this + 6) + 24LL))(*((_QWORD *)this + 6)) )
      goto LABEL_50;
LABEL_49:
    std::string::operator=((soap *)this, (int)textureId, v15, v16, v17, v18);
    goto LABEL_50;
  }
LABEL_43:
  LOBYTE(v23) = 1;
  if ( a8 )
  {
    RBX::Adorn::addTextureLoadDependency(v35);
LABEL_50:
    LODWORD(v23) = 0;
  }
  v28 = *((_QWORD *)this + 6);
  if ( v28 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v28 + 24LL))(v28) )
    {
      LOBYTE(v23) = 1;
      if ( outSize )
      {
        *(double *)a7.m128_u64 = (*(double (__fastcall **)(_QWORD))(**((_QWORD **)this + 6) + 16LL))(*((_QWORD *)this + 6));
        LODWORD(outSize->x) = _mm_cvtsi128_si32((__m128i)a7);
        LODWORD(outSize->y) = _mm_shuffle_ps(a7, a7, 77).m128_u32[0];
      }
    }
  }
  return (unsigned int)v23;
}


// Address: 0x10ce6a0 | Name: _ZN3RBX12GuiDrawImage26OnUnbindResourceSignalHintEv
void __fastcall RBX::GuiDrawImage::OnUnbindResourceSignalHint(RBX::GuiDrawImage *this)
{
  volatile signed __int32 *v1; // r14
  __int128 v2; // [rsp+0h] [rbp-28h] BYREF
  __int64 v3; // [rsp+10h] [rbp-18h]

  if ( !(_BYTE)byte_2A08A58 && __cxa_guard_acquire(&byte_2A08A58) )
  {
    xmmword_2A08A40 = 0;
    qword_2A08A50 = 0;
    __cxa_atexit((void (*)(void *))RBX::ContentId::~ContentId, &xmmword_2A08A40, &dso_handle);
    __cxa_guard_release(&byte_2A08A58);
  }
  std::string::basic_string(&v2, &xmmword_2A08A40);
  if ( (*(_BYTE *)this & 1) != 0 )
  {
    **((_BYTE **)this + 2) = 0;
    *((_QWORD *)this + 1) = 0;
  }
  else
  {
    *(_WORD *)this = 0;
  }
  std::string::reserve(this, 0);
  *((_QWORD *)this + 2) = v3;
  *(_OWORD *)this = v2;
  v1 = (volatile signed __int32 *)*((_QWORD *)this + 7);
  *((_OWORD *)this + 3) = 0;
  if ( v1 )
  {
    if ( !_InterlockedSub(v1 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
      if ( !_InterlockedSub(v1 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
    }
  }
  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 9);
}


// Address: 0x10ce7b0 | Name: _ZN3RBX12GuiDrawImage8setVideoEPNS_5AdornERKNS_7VideoIdERN5boost10shared_ptrINS_11VideoStreamEEEPN3G3D7Vector2Eb
bool __fastcall RBX::GuiDrawImage::setVideo(
        RBX::GuiDrawImage *this,
        RBX::Adorn *adorn,
        const RBX::VideoId *textureId,
        boost::shared_ptr<RBX::VideoStream> *videoStream,
        RBX::Vector2 *outSize,
        bool loadDependency)
{
  __m128 si128; // xmm0
  _BOOL4 v7; // r14d
  RBX::Vector2 *v12; // r14
  rbx::signal<void ()> *v13; // rax
  rbx::signals::slot_base *p; // rdi
  __m128i *v15; // r13
  volatile signed __int32 *v16; // rbp
  unsigned __int64 v17; // rax
  unsigned __int64 v18; // rax
  boost::shared_ptr<RBX::VideoStream> *v19; // r14
  boost::detail::sp_counted_base *pi; // rax
  volatile signed __int32 *v21; // rbp
  volatile signed __int32 *v22; // rbp
  volatile signed __int32 *v23; // rbp
  __int64 v24; // rdi
  bool v25; // bp
  boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::GuiDrawImage>,boost::_bi::list1<boost::_bi::value<RBX::GuiDrawImage *> > > v27; // [rsp+0h] [rbp-78h] BYREF
  rbx::signals::connection other; // [rsp+18h] [rbp-60h] BYREF
  _BOOL4 v29; // [rsp+24h] [rbp-54h]
  boost::shared_ptr<RBX::VideoStream>::element_type *px; // [rsp+28h] [rbp-50h] BYREF
  volatile signed __int32 *v31; // [rsp+30h] [rbp-48h]
  boost::shared_ptr<RBX::VideoStream> *v32; // [rsp+38h] [rbp-40h]

  v7 = loadDependency;
  if ( RBX::operator!=(textureId, this) )
  {
    if ( !(_BYTE)byte_2A08A58 && __cxa_guard_acquire(&byte_2A08A58) )
    {
      xmmword_2A08A40 = 0;
      qword_2A08A50 = 0;
      __cxa_atexit((void (*)(void *))RBX::ContentId::~ContentId, &xmmword_2A08A40, &dso_handle);
      __cxa_guard_release(&byte_2A08A58);
    }
    std::string::basic_string(&v27, &xmmword_2A08A40);
    if ( (*(_BYTE *)this & 1) != 0 )
    {
      **((_BYTE **)this + 2) = 0;
      *((_QWORD *)this + 1) = 0;
    }
    else
    {
      *(_WORD *)this = 0;
    }
    v32 = videoStream;
    v29 = v7;
    std::string::reserve(this, 0);
    v12 = outSize;
    *((_QWORD *)this + 2) = v27.l_.a1_.t_;
    *(__m128i *)this = _mm_loadu_si128((const __m128i *)&v27);
    if ( !rbx::signals::connection::connected((const rbx::signals::connection *)this + 9) )
    {
      v13 = (rbx::signal<void ()> *)(*(__int64 (__fastcall **)(RBX::Adorn *))(*(_QWORD *)adorn + 48LL))(adorn);
      v27.f_ = (boost::_mfi::mf0<void,RBX::GuiDrawImage>)(unsigned __int64)RBX::GuiDrawImage::OnUnbindResourceSignalHint;
      v27.l_.a1_.t_ = this;
      rbx::signal<void ()(void)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::GuiDrawImage>,boost::_bi::list1<boost::_bi::value<RBX::GuiDrawImage*>>>>(
        v13,
        &v27);
      if ( rbx::signals::connection::operator!=((const rbx::signals::connection *)this + 9, &other) )
      {
        rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 9);
        rbx::signals::connection::operator=((rbx::signals::connection *)this + 9, &other);
      }
      p = other.weak_slot.p_;
      if ( other.weak_slot.p_ && !_InterlockedSub(&other.weak_slot.p_->weak.v, 1u) )
        operator delete(p);
    }
    v15 = (__m128i *)((char *)this + 24);
    if ( RBX::operator!=(textureId, (RBX::GuiDrawImage *)((char *)this + 24)) )
    {
      v16 = (volatile signed __int32 *)*((_QWORD *)this + 7);
      *((_OWORD *)this + 3) = 0;
      if ( v16 )
      {
        if ( !_InterlockedSub(v16 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
          if ( !_InterlockedSub(v16 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
        }
      }
      *((_QWORD *)this + 8) = 0;
      std::string::basic_string(&v27, textureId);
      if ( (*((_BYTE *)this + 24) & 1) != 0 )
      {
        **((_BYTE **)this + 5) = 0;
        *((_QWORD *)this + 4) = 0;
      }
      else
      {
        v15->m128i_i16[0] = 0;
      }
      std::string::reserve((char *)this + 24, 0);
      *((_QWORD *)this + 5) = v27.l_.a1_.t_;
      *v15 = _mm_loadu_si128((const __m128i *)&v27);
    }
    v17 = *(unsigned __int8 *)textureId;
    if ( (v17 & 1) != 0 )
      v18 = *((_QWORD *)textureId + 1);
    else
      v18 = v17 >> 1;
    outSize = v12;
    v19 = v32;
    if ( !v18 )
    {
      std::string::basic_string(&v27, textureId);
      if ( (*(_BYTE *)this & 1) != 0 )
      {
        **((_BYTE **)this + 2) = 0;
        *((_QWORD *)this + 1) = 0;
      }
      else
      {
        *(_WORD *)this = 0;
      }
      goto LABEL_49;
    }
    px = v32->px;
    pi = v32->pn.pi_;
    v31 = (volatile signed __int32 *)pi;
    if ( pi )
      _InterlockedAdd(&pi->use_count_, 1u);
    (*(void (__fastcall **)(boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::GuiDrawImage>,boost::_bi::list1<boost::_bi::value<RBX::GuiDrawImage *> > > *, RBX::Adorn *, boost::shared_ptr<RBX::VideoStream>::element_type **))(*(_QWORD *)adorn + 40LL))(
      &v27,
      adorn,
      &px);
    si128 = (__m128)_mm_load_si128((const __m128i *)&v27);
    v27.f_ = 0;
    v21 = (volatile signed __int32 *)*((_QWORD *)this + 7);
    *((__m128 *)this + 3) = si128;
    if ( v21 )
    {
      if ( !_InterlockedSub(v21 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 16LL))(v21);
        if ( !_InterlockedSub(v21 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 24LL))(v21);
      }
    }
    v22 = (volatile signed __int32 *)*((_QWORD *)&v27.f_.f_ + 1);
    if ( *((_QWORD *)&v27.f_.f_ + 1) )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v27.f_.f_ + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 16LL))(v22);
        if ( !_InterlockedSub(v22 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 24LL))(v22);
      }
    }
    v23 = v31;
    if ( v31 )
    {
      if ( !_InterlockedSub(v31 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 16LL))(v23);
        if ( !_InterlockedSub(v23 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 24LL))(v23);
      }
    }
    if ( v19->px )
    {
      if ( (*(unsigned __int8 (__fastcall **)(_QWORD))(**((_QWORD **)this + 6) + 24LL))(*((_QWORD *)this + 6)) )
      {
        std::string::basic_string(&v27, textureId);
        if ( (*(_BYTE *)this & 1) != 0 )
        {
          **((_BYTE **)this + 2) = 0;
          *((_QWORD *)this + 1) = 0;
        }
        else
        {
          *(_WORD *)this = 0;
        }
LABEL_49:
        std::string::reserve(this, 0);
        *((_QWORD *)this + 2) = v27.l_.a1_.t_;
        si128 = (__m128)_mm_loadu_si128((const __m128i *)&v27);
        *(__m128 *)this = si128;
      }
    }
    else if ( v29 )
    {
      RBX::Adorn::addTextureLoadDependency(adorn);
    }
  }
  v24 = *((_QWORD *)this + 6);
  if ( !v24 || !(*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v24 + 24LL))(v24) )
    return 0;
  v25 = 1;
  if ( outSize )
  {
    *(double *)si128.m128_u64 = (*(double (__fastcall **)(_QWORD))(**((_QWORD **)this + 6) + 16LL))(*((_QWORD *)this + 6));
    LODWORD(outSize->x) = _mm_cvtsi128_si32((__m128i)si128);
    LODWORD(outSize->y) = _mm_shuffle_ps(si128, si128, 77).m128_u32[0];
  }
  return v25;
}


// Address: 0x10cec20 | Name: _ZN3RBX12GuiDrawImage8render2dEPNS_5AdornEbRKNS_4RectEbb
void __fastcall RBX::GuiDrawImage::render2d(
        RBX::GuiDrawImage *this,
        RBX::Adorn *adorn,
        bool enabled,
        const RBX::Rect *rect,
        bool isSelected,
        bool wrapTexture)
{
  float x; // xmm0_4
  __m128 x_low; // xmm1
  __m128 y_low; // xmm2
  __m128 v12; // xmm3
  float y; // xmm4_4
  __m128 v14; // xmm5
  const G3D::Color3 *v15; // rax
  RBX::Color4 v16; // [rsp+0h] [rbp-78h] BYREF
  RBX::Vector2 texbr; // [rsp+10h] [rbp-68h] BYREF
  RBX::Vector2 texul; // [rsp+18h] [rbp-60h] BYREF
  RBX::Rotation2D modifier; // [rsp+20h] [rbp-58h] BYREF
  RBX::Rect2D v20; // [rsp+40h] [rbp-38h] BYREF

  x = rect->high.x;
  x_low = (__m128)LODWORD(rect->low.x);
  y_low = (__m128)LODWORD(rect->low.y);
  v12 = x_low;
  v12.m128_f32[0] = fminf(x_low.m128_f32[0], x);
  y = rect->high.y;
  v14 = y_low;
  v14.m128_f32[0] = fminf(y_low.m128_f32[0], y);
  x_low.m128_f32[0] = fmaxf(x_low.m128_f32[0], x);
  y_low.m128_f32[0] = fmaxf(y_low.m128_f32[0], y);
  v20 = (RBX::Rect2D)_mm_movelh_ps(_mm_unpacklo_ps(v12, v14), _mm_unpacklo_ps(x_low, y_low));
  texul = 0;
  texbr = (RBX::Vector2)0x3F8000003F800000LL;
  v15 = G3D::Color3::white();
  v16.r = v15->r;
  v16.g = v15->g;
  v16.b = v15->b;
  v16.a = 1.0;
  *(_OWORD *)&modifier.angle.value = xmmword_3E4990;
  modifier.center.y = 0.0;
  RBX::GuiDrawImage::render2dImpl<RBX::Rotation2D>(
    this,
    adorn,
    enabled,
    &v20,
    &texul,
    &texbr,
    &v16,
    &modifier,
    isSelected,
    wrapTexture);
}


// Address: 0x10ced00 | Name: _ZN3RBX12GuiDrawImage8render2dEPNS_5AdornEbRKNS_4RectERKN3G3D7Vector2ES9_RKNS6_6Color4ERKNS_10Rotation2DEbb
void __fastcall RBX::GuiDrawImage::render2d(
        RBX::GuiDrawImage *this,
        RBX::Adorn *adorn,
        bool enabled,
        const RBX::Rect *rect,
        const RBX::Vector2 *texul,
        const RBX::Vector2 *texbr,
        const RBX::Color4 *color,
        const RBX::Rotation2D *rotation,
        bool isSelected,
        bool wrapTexture)
{
  float x; // xmm1_4
  __m128 x_low; // xmm2
  __m128 y_low; // xmm3
  __m128 v13; // xmm4
  float y; // xmm5_4
  __m128 v15; // xmm6
  RBX::Rect2D v16; // [rsp+28h] [rbp-10h] BYREF

  x = rect->high.x;
  x_low = (__m128)LODWORD(rect->low.x);
  y_low = (__m128)LODWORD(rect->low.y);
  v13 = x_low;
  v13.m128_f32[0] = fminf(x_low.m128_f32[0], x);
  y = rect->high.y;
  v15 = y_low;
  v15.m128_f32[0] = fminf(y_low.m128_f32[0], y);
  x_low.m128_f32[0] = fmaxf(x_low.m128_f32[0], x);
  y_low.m128_f32[0] = fmaxf(y_low.m128_f32[0], y);
  v16 = (RBX::Rect2D)_mm_movelh_ps(_mm_unpacklo_ps(v13, v15), _mm_unpacklo_ps(x_low, y_low));
  RBX::GuiDrawImage::render2dImpl<RBX::Rotation2D>(
    this,
    adorn,
    enabled,
    &v16,
    texul,
    texbr,
    color,
    rotation,
    isSelected,
    wrapTexture);
}


// Address: 0x10ced70 | Name: _ZN3RBX12GuiDrawImage8render2dEPNS_5AdornEbRKNS_4RectERKN3G3D7Vector2ES9_RKNS6_6Color4ES5_bb
void __fastcall RBX::GuiDrawImage::render2d(
        RBX::GuiDrawImage *this,
        RBX::Adorn *adorn,
        bool enabled,
        const RBX::Rect *rect,
        const RBX::Vector2 *texul,
        const RBX::Vector2 *texbr,
        const RBX::Color4 *color,
        const RBX::Rect *clipRect,
        bool isSelected,
        bool wrapTexture)
{
  float x; // xmm3_4
  __m128 x_low; // xmm6
  __m128 v12; // xmm9
  float y; // xmm4_4
  __m128 v14; // xmm8
  __m128 y_low; // xmm2
  float v16; // xmm7_4
  __m128 v17; // xmm4
  float v18; // xmm1_4
  __m128 v19; // xmm5
  __m128 v20; // xmm0
  __m128 v21; // xmm3
  G3D::Rect2D modifier; // [rsp+8h] [rbp-20h] BYREF
  RBX::Rect2D recta; // [rsp+18h] [rbp-10h] BYREF

  x = rect->high.x;
  x_low = (__m128)LODWORD(rect->low.x);
  y_low = (__m128)LODWORD(rect->low.y);
  v12 = x_low;
  v12.m128_f32[0] = fminf(x_low.m128_f32[0], x);
  y = rect->high.y;
  v14 = y_low;
  v14.m128_f32[0] = fminf(y_low.m128_f32[0], y);
  x_low.m128_f32[0] = fmaxf(x_low.m128_f32[0], x);
  y_low.m128_f32[0] = fmaxf(y_low.m128_f32[0], y);
  recta = (RBX::Rect2D)_mm_movelh_ps(_mm_unpacklo_ps(v12, v14), _mm_unpacklo_ps(x_low, y_low));
  v16 = clipRect->high.x;
  v20 = (__m128)LODWORD(clipRect->low.x);
  v21 = (__m128)LODWORD(clipRect->low.y);
  v17 = v20;
  v17.m128_f32[0] = fminf(v20.m128_f32[0], v16);
  v18 = clipRect->high.y;
  v19 = v21;
  v19.m128_f32[0] = fminf(v21.m128_f32[0], v18);
  v20.m128_f32[0] = fmaxf(v20.m128_f32[0], v16);
  v21.m128_f32[0] = fmaxf(v21.m128_f32[0], v18);
  modifier = (G3D::Rect2D)_mm_movelh_ps(_mm_unpacklo_ps(v17, v19), _mm_unpacklo_ps(v20, v21));
  if ( x_low.m128_f32[0] > v17.m128_f32[0]
    && y_low.m128_f32[0] > v19.m128_f32[0]
    && v20.m128_f32[0] > v12.m128_f32[0]
    && v21.m128_f32[0] > v14.m128_f32[0] )
  {
    RBX::GuiDrawImage::render2dImpl<G3D::Rect2D>(
      this,
      adorn,
      enabled,
      &recta,
      texul,
      texbr,
      color,
      &modifier,
      isSelected,
      wrapTexture);
  }
}


// Address: 0x10cf0a0 | Name: _ZN3RBX12GuiDrawImage12render2dImplINS_10Rotation2DEEEvPNS_5AdornEbRKN3G3D6Rect2DERKNS5_7Vector2ESB_RKNS5_6Color4ERKT_bb
void __fastcall RBX::GuiDrawImage::render2dImpl<RBX::Rotation2D>(
        const RBX::TextureProxyBaseRef *this,
        RBX::Adorn *adorn,
        bool enabled,
        const RBX::Rect2D *rect,
        const RBX::Vector2 *texul,
        const RBX::Vector2 *texbr,
        const RBX::Color4 *color,
        const RBX::Rotation2D *modifier,
        bool isSelected,
        bool wrapTexture)
{
  boost::detail::sp_counted_base *v14; // r13
  RBX::Color4 v15; // [rsp+0h] [rbp-48h] BYREF

  if ( *((_QWORD *)this + 6) )
  {
    RBX::Adorn::setTexture(adorn, 0, this + 3, wrapTexture);
    RBX::Adorn::rect2d(adorn, rect, texul, texbr, color, modifier);
    v15 = 0;
    RBX::Adorn::setTexture(adorn, 0, (const RBX::TextureProxyBaseRef *)&v15, 0);
    v14 = *(boost::detail::sp_counted_base **)&v15.b;
    if ( *(_QWORD *)&v15.b )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v15.b + 8LL), 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
        if ( !_InterlockedSub(&v14->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
      }
    }
    if ( !enabled )
    {
      v15 = (RBX::Color4)xmmword_3E95B0;
      RBX::Adorn::rect2d(adorn, rect, texul, texbr, &v15, modifier);
    }
  }
}


// Address: 0x10cf1d0 | Name: _ZN3RBX12GuiDrawImage12render2dImplIN3G3D6Rect2DEEEvPNS_5AdornEbRKS3_RKNS2_7Vector2ESA_RKNS2_6Color4ERKT_bb
void __fastcall RBX::GuiDrawImage::render2dImpl<G3D::Rect2D>(
        const RBX::TextureProxyBaseRef *this,
        RBX::Adorn *adorn,
        bool enabled,
        const RBX::Rect2D *rect,
        const RBX::Vector2 *texul,
        const RBX::Vector2 *texbr,
        const RBX::Color4 *color,
        const G3D::Rect2D *modifier,
        bool isSelected,
        bool wrapTexture)
{
  boost::detail::sp_counted_base *v14; // r13
  RBX::Color4 v15; // [rsp+0h] [rbp-48h] BYREF

  if ( *((_QWORD *)this + 6) )
  {
    RBX::Adorn::setTexture(adorn, 0, this + 3, wrapTexture);
    RBX::Adorn::rect2d(adorn, rect, texul, texbr, color, modifier);
    v15 = 0;
    RBX::Adorn::setTexture(adorn, 0, (const RBX::TextureProxyBaseRef *)&v15, 0);
    v14 = *(boost::detail::sp_counted_base **)&v15.b;
    if ( *(_QWORD *)&v15.b )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v15.b + 8LL), 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
        if ( !_InterlockedSub(&v14->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
      }
    }
    if ( !enabled )
    {
      v15 = (RBX::Color4)xmmword_3E95B0;
      RBX::Adorn::rect2d(adorn, rect, texul, texbr, &v15, modifier);
    }
  }
}


// Address: 0x10cf330 | Name: _GLOBAL__sub_I_GuiDraw.cpp
void __cdecl GLOBAL__sub_I_GuiDraw_cpp()
{
  qword_2A08A28 = (__int64)boost::system::generic_category();
  qword_2A08A30 = (__int64)boost::system::generic_category();
  qword_2A08A38 = (__int64)boost::system::system_category();
}


