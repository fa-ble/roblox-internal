// Address: 0x10e7130 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN8FreefallE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Freefall *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08E88;
  if ( !qword_2A08E88 )
  {
    result = RBX::Name::declare("Freefall");
    qword_2A08E88 = result;
  }
  return result;
}


// Address: 0x10e7160 | Name: _ZNK3RBX5HUMAN8Freefall7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Freefall::getName(const RBX::HUMAN::Freefall *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08E88;
  if ( !qword_2A08E88 )
  {
    result = RBX::Name::declare("Freefall");
    qword_2A08E88 = result;
  }
  return result;
}


// Address: 0x10e7190 | Name: _ZN3RBX5HUMAN8Freefall26characterVelocityInfluenceEv
float __cdecl RBX::HUMAN::Freefall::characterVelocityInfluence()
{
  return 0.0;
}


// Address: 0x10e71a0 | Name: _ZN3RBX5HUMAN8Freefall22floorVelocityInfluenceEv
float __cdecl RBX::HUMAN::Freefall::floorVelocityInfluence()
{
  return 0.94999999;
}


// Address: 0x10e71b0 | Name: _ZN3RBX5HUMAN8Freefall13velocityDecayEv
float __cdecl RBX::HUMAN::Freefall::velocityDecay()
{
  return 0.050000001;
}


// Address: 0x10e71c0 | Name: _ZN3RBX5HUMAN8Freefall18unstickForceAttackEv
float __cdecl RBX::HUMAN::Freefall::unstickForceAttack()
{
  return (float)dword_2859588 / 10.0;
}


// Address: 0x10e71e0 | Name: _ZN3RBX5HUMAN8Freefall17unstickForceDecayEv
float __cdecl RBX::HUMAN::Freefall::unstickForceDecay()
{
  return (float)dword_2859578 / 10.0;
}


// Address: 0x10e7200 | Name: _ZN3RBX5HUMAN8Freefall19maximumUnstickForceEv
float __cdecl RBX::HUMAN::Freefall::maximumUnstickForce()
{
  return (float)dword_2859598;
}


// Address: 0x10e7210 | Name: _ZN3RBX5HUMAN8Freefall19unstickForceEpsilonEv
float __cdecl RBX::HUMAN::Freefall::unstickForceEpsilon()
{
  return (float)dword_28595A8 / 100.0;
}


// Address: 0x10e7230 | Name: _ZN3RBX5HUMAN8Freefall19minimumMoveDistanceEv
float __cdecl RBX::HUMAN::Freefall::minimumMoveDistance()
{
  return (float)dword_2859558 / 10.0;
}


// Address: 0x10e7250 | Name: _ZN3RBX5HUMAN8Freefall15maximumMoveTimeEv
float __cdecl RBX::HUMAN::Freefall::maximumMoveTime()
{
  return (float)dword_2859568 / 10.0;
}


// Address: 0x10e7270 | Name: _ZN3RBX5HUMAN8FreefallC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Freefall::Freefall(
        RBX::HUMAN::Freefall *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  float v3; // xmm1_4
  RBX::PartInstance *HeadSlow; // rax
  RBX::Primitive *px; // rdi
  RBX::PartInstance *TorsoSlow; // rax
  RBX::Primitive *v8; // rdi
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v10; // rbx
  float v11; // xmm0_4

  RBX::HUMAN::Balancing::Balancing(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895910;
  *((_OWORD *)this + 26) = 0;
  *(_OWORD *)((char *)this + 404) = 0;
  *(_OWORD *)((char *)this + 388) = 0;
  HeadSlow = RBX::Humanoid::getHeadSlow(humanoid);
  if ( HeadSlow )
  {
    px = HeadSlow->primitive.px;
    *((_DWORD *)this + 107) = *((_DWORD *)px + 144);
    RBX::Primitive::setFriction(px, v3);
  }
  TorsoSlow = RBX::Humanoid::getTorsoSlow(humanoid);
  if ( TorsoSlow )
  {
    v8 = TorsoSlow->primitive.px;
    *((_DWORD *)this + 106) = *((_DWORD *)v8 + 144);
    RBX::Primitive::setFriction(v8, v3);
  }
  RootBodyFast = RBX::Humanoid::getRootBodyFast(humanoid);
  v10 = RootBodyFast;
  if ( RootBodyFast )
  {
    RBX::Body::updatePV(RootBodyFast);
    *((_DWORD *)this + 109) = LODWORD(v10->pv.position.translation.y);
  }
  *((_DWORD *)this + 108) = *((_DWORD *)this + 4);
  if ( stru_2A10FE8.value )
    v11 = (float)dword_28595C8;
  else
    v11 = 5000.0;
  *((float *)this + 78) = v11;
}


// Address: 0x10e73e0 | Name: _ZN3RBX5HUMAN8FreefallD2Ev
void __fastcall RBX::HUMAN::Freefall::~Freefall(RBX::HUMAN::Freefall *this)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::PartInstance *HeadSlow; // rax
  RBX::Humanoid *v4; // rax
  RBX::PartInstance *TorsoSlow; // rax
  __int64 v6; // r14
  __int64 v7; // rbx
  volatile signed __int32 *v8; // rdi
  void *v9; // rdi

  *(_QWORD *)this = &off_2895910;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  HeadSlow = RBX::Humanoid::getHeadSlow(HumanoidConst);
  if ( HeadSlow && *((float *)this + 107) > 0.0 )
    RBX::Primitive::setFriction(HeadSlow->primitive.px, 0.0);
  v4 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  TorsoSlow = RBX::Humanoid::getTorsoSlow(v4);
  if ( TorsoSlow && *((float *)this + 106) > 0.0 )
    RBX::Primitive::setFriction(TorsoSlow->primitive.px, 0.0);
  *(_QWORD *)this = &off_2895850;
  v6 = *((_QWORD *)this + 44);
  if ( v6 )
  {
    v7 = *((_QWORD *)this + 45);
    if ( v7 == v6 )
    {
      v9 = (void *)*((_QWORD *)this + 44);
    }
    else
    {
      do
      {
        v8 = *(volatile signed __int32 **)(v7 - 8);
        if ( v8 && !_InterlockedSub(v8 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
        v7 -= 16;
      }
      while ( v6 != v7 );
      v9 = (void *)*((_QWORD *)this + 44);
    }
    *((_QWORD *)this + 45) = v6;
    operator delete(v9);
  }
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
}


// Address: 0x10e74f0 | Name: _ZN3RBX5HUMAN8FreefallD0Ev
void __fastcall RBX::HUMAN::Freefall::~Freefall(RBX::HUMAN::Freefall *this)
{
  RBX::HUMAN::Freefall::~Freefall(this);
  operator delete(this);
}


// Address: 0x10e7510 | Name: _ZN3RBX5HUMAN8Freefall10kTurnSpeedEv
float __cdecl RBX::HUMAN::Freefall::kTurnSpeed()
{
  return 6.0;
}


// Address: 0x10e7520 | Name: _ZN3RBX5HUMAN8Freefall16kTurnSpeedForPGSEv
float __cdecl RBX::HUMAN::Freefall::kTurnSpeedForPGS()
{
  return 8.0;
}


// Address: 0x10e7530 | Name: _ZN3RBX5HUMAN8Freefall19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::Freefall::onSimulatorStepImpl(RBX::HUMAN::Freefall *this, double a2, float stepDt)
{
  const RBX::Humanoid *HumanoidConst; // rax
  float v5; // xmm0_4
  __m128 v6; // xmm2
  float v7; // xmm1_4
  __m128 v8; // xmm2
  __m128 v9; // xmm3
  const RBX::Humanoid *v10; // rax
  double v11; // xmm1_8
  RBX::GameBasicSettings *v12; // rax
  float v13; // xmm0_4
  bool v14; // cf
  float v15; // xmm0_4
  float v16; // xmm1_4
  float v17; // xmm1_4
  float v18; // [rsp+0h] [rbp-38h]
  double v19; // [rsp+0h] [rbp-38h]
  float v20; // [rsp+Ch] [rbp-2Ch]
  __int128 v21; // [rsp+10h] [rbp-28h] BYREF
  __int64 v22; // [rsp+20h] [rbp-18h]

  v20 = *(float *)&a2;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  (*(void (__fastcall **)(__int128 *, const RBX::Humanoid *, double, float))(*(_QWORD *)HumanoidConst + 416LL))(
    &v21,
    HumanoidConst,
    a2,
    stepDt);
  *((_OWORD *)this + 25) = v21;
  *((_QWORD *)this + 52) = v22;
  v5 = *((float *)this + 97) + *((float *)this + 100);
  *((float *)this + 100) = v5;
  v6 = _mm_add_ps((__m128)*(unsigned __int64 *)((char *)this + 404), (__m128)*((unsigned __int64 *)this + 49));
  *((_DWORD *)this + 101) = v6.m128_i32[0];
  LODWORD(v7) = _mm_shuffle_ps(v6, v6, 229).m128_u32[0];
  *((float *)this + 102) = v7;
  v8 = _mm_mul_ps(v6, v6);
  if ( fsqrt(_mm_shuffle_ps(v8, v8, 229).m128_f32[0] + (float)((float)(v5 * v5) + v8.m128_f32[0])) >= 0.1 )
  {
    v9 = _mm_mul_ps((__m128)*(unsigned __int64 *)((char *)&v21 + 4), (__m128)*(unsigned __int64 *)((char *)&v21 + 4));
    if ( fsqrt(_mm_shuffle_ps(v9, v9, 229).m128_f32[0] + (float)((float)(*(float *)&v21 * *(float *)&v21)
                                                               + v9.m128_f32[0])) > 0.1 )
    {
      v18 = atan2f(-v5, -v7);
      v10 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
      v11 = (float)(v18 - RBX::Humanoid::getTorsoHeading(v10));
      v19 = v11;
      if ( v11 < -3.141592653589793 || v11 >= 3.141592653589793 )
        v19 = v11 - floor((v11 + 3.141592653589793) / 6.283185307179586) * 6.283185307179586;
      v12 = RBX::GlobalBasicSettingsItem<RBX::GameBasicSettings>::singleton();
      if ( (*((_DWORD *)v12 + 48) != 1 || !*((_BYTE *)v12 + 240))
        && *((char *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 705) > 0 )
      {
        v13 = v19;
        v14 = v13 < 0.0;
        v15 = fabs(v13);
        v16 = flt_4905E0[!v14];
        if ( v15 >= 1.0 )
          *((float *)this + 104) = v16;
        else
          *((float *)this + 104) = v15 * v16;
      }
    }
  }
  else
  {
    if ( !(_BYTE)byte_2A08DC8 && __cxa_guard_acquire(&byte_2A08DC8) )
    {
      *(_OWORD *)&vel.linear.x = 0;
      *(_QWORD *)&vel.rotational.y = 0;
      __cxa_guard_release(&byte_2A08DC8);
    }
    *(RBX::Velocity *)((char *)this + 400) = vel;
  }
  v17 = (float)((float)(v20 * -0.050000001) / 0.033333335) + 1.0;
  *((float *)this + 97) = *((float *)this + 97) * v17;
  *((float *)this + 98) = *((float *)this + 98) * v17;
  *((float *)this + 99) = v17 * *((float *)this + 99);
}


// Address: 0x10e77d0 | Name: _ZN3RBX5HUMAN8Freefall18onComputeForceImplEv
void __fastcall RBX::HUMAN::Freefall::onComputeForceImpl(RBX::HUMAN::Freefall *this)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v4; // r14
  __m128 v5; // xmm1
  __m128 v6; // xmm4
  __m128 v7; // xmm3
  RBX::Matrix3 *v8; // rcx
  RBX::Matrix3 *p_iBody; // rax
  float v10; // ebp
  RBX::Cofm *cofm; // rbx
  __int128 v12; // xmm0
  __int128 v13; // xmm1
  RBX::Cofm *v14; // rbx
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  float *p_moment; // rax
  RBX::Body *root; // rax
  RBX::Solver::SolverRigidBody *rigidBody; // rbx
  float v20; // xmm5_4
  float v21; // xmm0_4
  float v22; // xmm2_4
  RBX::Solver::SolverRigidBody *v23; // rdi
  RBX::Body **p_root; // r15
  __m128 *v25; // rax
  RBX::Cofm *v26; // rbx
  __m128 v27; // xmm0
  __m128 v28; // xmm1
  __m128 *v29; // rax
  RBX::Body *v30; // rax
  RBX::Solver::SolverRigidBody *v31; // rbx
  __m128 v32; // xmm2
  float v33; // xmm0_4
  float v34; // xmm0_4
  float v35; // xmm0_4
  float v36; // xmm5_4
  float v37; // xmm1_4
  float v38; // xmm0_4
  float v39; // xmm4_4
  float v40; // xmm5_4
  float v41; // xmm3_4
  float v42; // xmm7_4
  float v43; // xmm0_4
  RBX::Velocity *v44; // rbx
  RBX::Velocity *v45; // rbx
  __m128 v46; // xmm6
  float v47; // xmm4_4
  __m128 v48; // xmm3
  __m128 v49; // xmm5
  float v50; // xmm2_4
  float v51; // xmm1_4
  float v52; // xmm2_4
  float v53; // xmm1_4
  __m128 v54; // xmm2
  RBX::Cofm *v55; // rbx
  RBX::Cofm *v56; // rdi
  float *p_mass; // r14
  float v58; // xmm1_4
  float v59; // xmm0_4
  RBX::Solver::SolverRigidBody *v60; // rbx
  float v61; // xmm2_4
  float v62; // xmm1_4
  __m128 v63; // xmm0
  float v64; // [rsp+0h] [rbp-C8h]
  float v65; // [rsp+0h] [rbp-C8h]
  float v66; // [rsp+1Ch] [rbp-ACh] BYREF
  __m128 v67; // [rsp+20h] [rbp-A8h]
  __m128 v68; // [rsp+30h] [rbp-98h]
  RBX::Matrix3 iBody; // [rsp+40h] [rbp-88h] BYREF
  RBX::Matrix3 v70; // [rsp+68h] [rbp-60h] BYREF
  __m128 v71; // [rsp+90h] [rbp-38h]
  G3D::Vector3 v72; // 0:kr00_12.12
  RBX::Vector3 ContactRepelForceInBalancing; // 0:kr34_12.12

  RBX::HUMAN::Balancing::onComputeForceImpl(this);
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RootBodyFast = RBX::Humanoid::getRootBodyFast(HumanoidConst);
  if ( !RootBodyFast )
    return;
  v4 = RootBodyFast;
  if ( stru_2A10FE8.value )
  {
    RBX::Body::updatePV(RootBodyFast);
    RBX::Body::updatePV(v4);
    v67.m128_f32[0] = *((float *)this + 103) - v4->pv.velocity.rotational.x;
    v63 = (__m128)*(unsigned __int64 *)&v4->pv.velocity.rotational.y;
    v5 = _mm_sub_ps((__m128)*((unsigned __int64 *)this + 52), v63);
    v68 = v5;
    v72 = G3D::Matrix3::column(&v4->pv.position.rotation, 1);
    v63.m128_i32[0] = LODWORD(v72.x);
    v63.m128_i32[1] = LODWORD(v72.y);
    v5.m128_i32[0] = LODWORD(v72.z);
    v6 = _mm_shuffle_ps(v63, v63, 229);
    v7 = _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(v5, v6, 0), v6, 226), v68);
    v66 = (float)dword_28595B8
        * (float)(_mm_shuffle_ps(v7, v7, 229).m128_f32[0] + (float)((float)(v67.m128_f32[0] * v72.x) + v7.m128_f32[0]));
    iBody.elt[0][0] = -160000.0;
    v70.elt[0][0] = 160000.0;
    v8 = &v70;
    if ( v66 < 160000.0 )
      v8 = (RBX::Matrix3 *)&v66;
    p_iBody = &iBody;
    if ( v8->elt[0][0] > -160000.0 )
      p_iBody = v8;
    v10 = p_iBody->elt[0][0];
    v66 = p_iBody->elt[0][0];
    cofm = v4->cofm;
    v71 = v63;
    v67 = v6;
    if ( cofm )
    {
      RBX::Cofm::updateIfDirty(cofm);
      iBody.elt[2][2] = cofm->branch.moment.elt[2][2];
      v12 = *(_OWORD *)&cofm->branch.moment.elt[0][0];
      v13 = *(_OWORD *)&cofm->branch.moment.elt[1][1];
    }
    else
    {
      if ( !v4->isMassless || v4->root == v4 )
        p_moment = (float *)&v4->bodyMass.moment;
      else
        p_moment = (float *)&unk_58DF6C;
      iBody.elt[2][2] = p_moment[8];
      v12 = *(_OWORD *)p_moment;
      v13 = *((_OWORD *)p_moment + 1);
    }
    *(_OWORD *)&iBody.elt[1][1] = v13;
    *(_OWORD *)&iBody.elt[0][0] = v12;
    RBX::Body::updatePV(v4);
    RBX::Math::momentToWorldSpace(&v70, &iBody, &v4->pv.position.rotation);
    root = v4->root;
    rigidBody = root->rigidBody;
    if ( rigidBody )
    {
      v20 = (float)(v70.elt[0][2] * (float)(v72.z * v10))
          + (float)((float)(v70.elt[0][1] * (float)(v67.m128_f32[0] * v10))
                  + (float)(v70.elt[0][0] * (float)(v71.m128_f32[0] * v10)));
      v21 = (float)(v70.elt[1][2] * (float)(v72.z * v10))
          + (float)((float)(v70.elt[1][1] * (float)(v67.m128_f32[0] * v10))
                  + (float)(v70.elt[1][0] * (float)(v71.m128_f32[0] * v10)));
      v22 = (float)((float)(v72.z * v10) * v70.elt[2][2])
          + (float)((float)((float)(v67.m128_f32[0] * v10) * v70.elt[2][1])
                  + (float)((float)(v71.m128_f32[0] * v10) * v70.elt[2][0]));
      if ( rigidBody->dirty )
      {
        v23 = root->rigidBody;
        v68.m128_f32[0] = (float)(v70.elt[0][2] * (float)(v72.z * v10))
                        + (float)((float)(v70.elt[0][1] * (float)(v67.m128_f32[0] * v10))
                                + (float)(v70.elt[0][0] * (float)(v71.m128_f32[0] * v10)));
        v67.m128_f32[0] = (float)(v70.elt[1][2] * (float)(v72.z * v10))
                        + (float)((float)(v70.elt[1][1] * (float)(v67.m128_f32[0] * v10))
                                + (float)(v70.elt[1][0] * (float)(v71.m128_f32[0] * v10)));
        RBX::Solver::SolverRigidBody::update(v23);
        v21 = v67.m128_f32[0];
        v20 = v68.m128_f32[0];
      }
      rigidBody->torque.x = v20 + rigidBody->torque.x;
      rigidBody->torque.y = v21 + rigidBody->torque.y;
      rigidBody->torque.z = v22 + rigidBody->torque.z;
    }
    p_root = &v4->root;
  }
  else
  {
    v14 = RootBodyFast->cofm;
    if ( v14 )
    {
      RBX::Cofm::updateIfDirty(RootBodyFast->cofm);
      iBody.elt[2][2] = v14->branch.moment.elt[2][2];
      v15 = *(__m128 *)&v14->branch.moment.elt[0][0];
      v16 = *(__m128 *)&v14->branch.moment.elt[1][1];
    }
    else
    {
      if ( !RootBodyFast->isMassless || RootBodyFast->root == RootBodyFast )
        v25 = (__m128 *)&RootBodyFast->bodyMass.moment;
      else
        v25 = (__m128 *)&unk_58DF6C;
      LODWORD(iBody.elt[2][2]) = v25[2].m128_i32[0];
      v15 = *v25;
      v16 = v25[1];
    }
    *(__m128 *)&iBody.elt[1][1] = v16;
    *(__m128 *)&iBody.elt[0][0] = v15;
    v15.m128_u64[0] = (unsigned __int64)RBX::Math::toDiagonal(&iBody);
    v68 = v15;
    v64 = *((float *)this + 104);
    RBX::Body::updatePV(v4);
    v65 = v64 - v4->pv.velocity.rotational.y;
    v26 = v4->cofm;
    if ( v26 )
    {
      RBX::Cofm::updateIfDirty(v4->cofm);
      iBody.elt[2][2] = v26->branch.moment.elt[2][2];
      v27 = *(__m128 *)&v26->branch.moment.elt[0][0];
      v28 = *(__m128 *)&v26->branch.moment.elt[1][1];
    }
    else
    {
      if ( !v4->isMassless || v4->root == v4 )
        v29 = (__m128 *)&v4->bodyMass.moment;
      else
        v29 = (__m128 *)&unk_58DF6C;
      LODWORD(iBody.elt[2][2]) = v29[2].m128_i32[0];
      v27 = *v29;
      v28 = v29[1];
    }
    *(__m128 *)&iBody.elt[1][1] = v28;
    *(__m128 *)&iBody.elt[0][0] = v27;
    v27.m128_u64[0] = (unsigned __int64)RBX::Math::toDiagonal(&iBody);
    v30 = v4->root;
    v31 = v30->rigidBody;
    if ( v31 )
      v32 = (__m128)*(unsigned __int64 *)&v31->torque.x;
    else
      v32 = 0;
    p_root = &v4->root;
    if ( v31 )
    {
      v33 = _mm_shuffle_ps(v27, v27, 229).m128_f32[0];
      v34 = fminf(
              v33 * 160000.0,
              fmaxf(
                -(float)(v33 * 160000.0),
                (float)((float)(_mm_shuffle_ps(v68, v68, 229).m128_f32[0] * 375.0) * v65)
              - _mm_shuffle_ps(v32, v32, 229).m128_f32[0]));
      if ( v31->dirty )
        RBX::Solver::SolverRigidBody::update(v30->rigidBody);
      v31->torque.x = v31->torque.x + 0.0;
      v31->torque.y = v34 + v31->torque.y;
      v31->torque.z = v31->torque.z + 0.0;
    }
  }
  ContactRepelForceInBalancing = RBX::HUMAN::Balancing::getContactRepelForceInBalancing(this);
  v68.m128_i32[0] = LODWORD(ContactRepelForceInBalancing.z);
  v35 = *((float *)this + 95);
  v36 = (float)(*((float *)this + 96) * 0.0) + (float)((float)(*((float *)this + 94) * 0.0) + v35);
  v37 = *((float *)this + 94) - (float)(0.0 * v36);
  v38 = v35 - v36;
  v39 = *((float *)this + 96) - (float)(0.0 * v36);
  v40 = *((float *)this + 101);
  v41 = *((float *)this + 102);
  v42 = (float)(v41 * v39) + (float)((float)(v40 * v38) + (float)(*((float *)this + 100) * v37));
  *((float *)this + 100) = *((float *)this + 100) - (float)(v37 * v42);
  *((float *)this + 101) = v40 - (float)(v38 * v42);
  *((float *)this + 102) = v41 - (float)(v42 * v39);
  v43 = RBX::HUMAN::HumanoidState::runningKMovePForPGS();
  v44 = (RBX::Velocity *)(*p_root)->rigidBody;
  if ( v44 )
  {
    v45 = v44 + 3;
  }
  else
  {
    v45 = &vel;
    if ( !(_BYTE)byte_2A08DC8 )
    {
      v67.m128_f32[0] = v43;
      if ( __cxa_guard_acquire(&byte_2A08DC8) )
      {
        *(_OWORD *)&vel.linear.x = 0;
        *(_QWORD *)&vel.rotational.y = 0;
        __cxa_guard_release(&byte_2A08DC8);
      }
      v43 = v67.m128_f32[0];
    }
  }
  v46 = (__m128)*((unsigned int *)this + 100);
  v46.m128_f32[0] = (float)(v46.m128_f32[0] - v45->linear.x) * v43;
  v47 = (float)(*((float *)this + 102) - v45->linear.z) * v43;
  v48 = (__m128)_mm_shuffle_epi32(_mm_loadl_epi64((const __m128i *)&qword_28595E4), 229);
  v48.m128_f32[0] = fminf(
                      v48.m128_f32[0],
                      fmaxf(
                        *(float *)_mm_shuffle_epi32(_mm_loadl_epi64((const __m128i *)&qword_28595D8), 229).m128i_i32,
                        (float)(*((float *)this + 101) - v45->linear.y) * v43));
  v49 = _mm_unpacklo_ps(v46, v48);
  v50 = (float)(v47 * v47) + (float)((float)(v46.m128_f32[0] * v46.m128_f32[0]) + 0.0);
  if ( v50 > 20449.0 )
  {
    v51 = 0.0;
    v52 = fsqrt(v50);
    if ( v52 >= 0.0000001 )
    {
      if ( v52 >= 1.00001 || v52 <= 0.99998999 )
      {
        v53 = 1.0 / v52;
        v46.m128_f32[0] = v46.m128_f32[0] * (float)(1.0 / v52);
        v54 = 0;
        v54.m128_f32[0] = 0.0 * v53;
        v47 = v47 * v53;
        LODWORD(v51) = _mm_unpacklo_ps(v46, v54).m128_u32[0];
      }
      else
      {
        v51 = v46.m128_f32[0];
      }
    }
    else
    {
      v47 = 0.0;
    }
    v47 = v47 * 143.0;
    v49.m128_f32[0] = v51 * 143.0;
  }
  v55 = v4->cofm;
  if ( v55 )
  {
    v56 = v4->cofm;
    v67.m128_f32[0] = v47;
    v71 = v49;
    RBX::Cofm::updateIfDirty(v56);
    v49.m128_i32[0] = v71.m128_i32[0];
    v47 = v67.m128_f32[0];
    p_mass = &v55->branch.mass;
    v58 = v68.m128_f32[0];
LABEL_56:
    v59 = *p_mass;
    goto LABEL_57;
  }
  v58 = v68.m128_f32[0];
  if ( !v4->isMassless || (v59 = 0.0, v4->root == v4) )
  {
    p_mass = &v4->bodyMass.mass;
    goto LABEL_56;
  }
LABEL_57:
  v60 = (*p_root)->rigidBody;
  if ( v60 )
  {
    v61 = (float)(ContactRepelForceInBalancing.x + v49.m128_f32[0]) * v59;
    v62 = (float)(v58 + v47) * v59;
    if ( v60->dirty )
    {
      v68.m128_f32[0] = v62;
      RBX::Solver::SolverRigidBody::update(v60);
      v62 = v68.m128_f32[0];
    }
    v60->force.x = v61 + v60->force.x;
    v60->force.y = v60->force.y + 0.0;
    v60->force.z = v62 + v60->force.z;
  }
}


// Address: 0x10e7f80 | Name: _GLOBAL__sub_I_Freefall.cpp
void __cdecl GLOBAL__sub_I_Freefall_cpp()
{
  qword_2A08E50 = (__int64)boost::system::generic_category();
  qword_2A08E58 = (__int64)boost::system::generic_category();
  qword_2A08E60 = (__int64)boost::system::system_category();
  dword_2A08E68 = FLog::RegisterInt(
                    "MinimumFreefallMoveDistanceInTenths",
                    &dword_2859558,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08E6C = FLog::RegisterInt("MaximumFreefallMoveTimeInTenths", &dword_2859568, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08E70 = FLog::RegisterInt("UnstickForceDecayInTenths", &dword_2859578, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08E74 = FLog::RegisterInt("UnstickForceAttackInTenths", &dword_2859588, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08E78 = FLog::RegisterInt("MaximumUnstickForceInGs", &dword_2859598, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08E7C = FLog::RegisterInt("UnstickForceEpsilonInHundredths", &dword_28595A8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08E80 = FLog::RegisterInt("FreeFallOrientationP", &dword_28595B8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08E84 = FLog::RegisterInt("FreeFallBalanceP", &dword_28595C8, FastVarType::FASTVARTYPE_DYNAMIC);
}


