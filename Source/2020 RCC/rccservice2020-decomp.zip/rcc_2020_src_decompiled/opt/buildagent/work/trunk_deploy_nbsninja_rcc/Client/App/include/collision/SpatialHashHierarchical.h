// Address: 0x1dff4b0 | Name: _ZNK3RBX9Collision23SpatialHashHierarchical11getNodesOutEv
int __fastcall RBX::Collision::SpatialHashHierarchical::getNodesOut(
        const RBX::Collision::SpatialHashHierarchical *this)
{
  return 0;
}


// Address: 0x1dff4c0 | Name: _ZNK3RBX9Collision23SpatialHashHierarchical12getMaxBucketEv
int __fastcall RBX::Collision::SpatialHashHierarchical::getMaxBucket(
        const RBX::Collision::SpatialHashHierarchical *this)
{
  return 0;
}


