// Address: 0x1deaf60 | Name: _ZN3RBX9Collision15BallBallContact16getNumCollisionsEv
unsigned int __fastcall RBX::Collision::BallBallContact::getNumCollisions(RBX::Collision::BallBallContact *this)
{
  return this->collisionConnector != 0;
}


// Address: 0x1deaf70 | Name: _ZN3RBX9Collision15BallBallContact21getCollisionConnectorEj
RBX::CollisionConnector *__fastcall RBX::Collision::BallBallContact::getCollisionConnector(
        RBX::Collision::BallBallContact *this,
        unsigned int i)
{
  return this->collisionConnector;
}


// Address: 0x1deaf80 | Name: _ZN3RBX9Collision15BallBallContact24deleteCollisionConnectorEj
void __fastcall RBX::Collision::BallBallContact::deleteCollisionConnector(
        RBX::Collision::BallBallContact *this,
        unsigned int i)
{
  RBX::CollisionConnector *collisionConnector; // rdi

  collisionConnector = this->collisionConnector;
  if ( collisionConnector )
  {
    operator delete(collisionConnector);
    this->collisionConnector = 0;
  }
}


// Address: 0x1deafa0 | Name: _ZN3RBX9Collision15BallBallContact18computeIsCollidingEf
__int64 __fastcall RBX::Collision::BallBallContact::computeIsColliding(
        RBX::Collision::BallBallContact *this,
        __m128 a2,
        float overlapIgnored)
{
  RBX::Body *Body; // rbx
  unsigned int v4; // r15d
  RBX::Body *v5; // rbp
  __m128 x_low; // xmm4
  __m128 v7; // xmm3
  __m128 v8; // xmm2
  float v9; // xmm1_4
  bool v10; // zf
  char *v11; // rbx
  __int64 v12; // rax
  RBX::Body *v13; // rbx
  float v14; // xmm0_4
  float v15; // xmm3_4
  RBX::CollisionConnector *collisionConnector; // rax
  float v18; // [rsp+Ch] [rbp-7Ch]
  float v19; // [rsp+Ch] [rbp-7Ch]
  G3D::Vector3 v20; // [rsp+10h] [rbp-78h] BYREF
  __m128 v21; // [rsp+20h] [rbp-68h]
  __m128 v22; // [rsp+30h] [rbp-58h]
  __m128 v23; // [rsp+40h] [rbp-48h]
  RBX::CollisionParams v24; // [rsp+50h] [rbp-38h] BYREF

  v21.m128_i32[0] = a2.m128_i32[0];
  *(double *)a2.m128_u64 = (*(double (__fastcall **)(_QWORD, double, float))(**((_QWORD **)this->prim0 + 18) + 56LL))(
                             *((_QWORD *)this->prim0 + 18),
                             *(double *)a2.m128_u64,
                             overlapIgnored);
  v23 = a2;
  v18 = (*(float (__fastcall **)(_QWORD))(**((_QWORD **)this->prim1 + 18) + 56LL))(*((_QWORD *)this->prim1 + 18));
  Body = RBX::Collision::Contact::getBody(this, 1);
  RBX::Body::updatePV(Body);
  v4 = 0;
  v5 = RBX::Collision::Contact::getBody(this, 0);
  RBX::Body::updatePV(v5);
  v19 = v18 + v23.m128_f32[0];
  if ( (float)(v19 - v21.m128_f32[0]) > 0.0 )
  {
    x_low = (__m128)LODWORD(Body->pv.position.translation.x);
    x_low.m128_f32[0] = x_low.m128_f32[0] - v5->pv.position.translation.x;
    v7 = _mm_sub_ps(
           (__m128)*(unsigned __int64 *)&Body->pv.position.translation.y,
           (__m128)*(unsigned __int64 *)&v5->pv.position.translation.y);
    v8 = _mm_mul_ps(v7, v7);
    v9 = (float)(x_low.m128_f32[0] * x_low.m128_f32[0]) + v8.m128_f32[0];
    if ( (float)((float)(v19 - v21.m128_f32[0]) * (float)(v19 - v21.m128_f32[0])) <= (float)(_mm_shuffle_ps(v8, v8, 229).m128_f32[0]
                                                                                           + v9) )
    {
      return 0;
    }
    else
    {
      v10 = this->collisionConnector == 0;
      v22 = v7;
      if ( v10 )
      {
        v21 = x_low;
        v11 = (char *)operator new(0x40u);
        RBX::Collision::Contact::computeCollisionParams(&v24, this->prim0, this->prim1);
        v12 = *(_QWORD *)&v24.friction;
        *(_OWORD *)v11 = *(_OWORD *)&v24.b0;
        *((_QWORD *)v11 + 2) = v12;
        *(_OWORD *)(v11 + 36) = 0;
        *(_OWORD *)(v11 + 24) = 0;
        *((_DWORD *)v11 + 13) = -1;
        v11[56] = 1;
        this->collisionConnector = (RBX::CollisionConnector *)v11;
        v7 = v22;
        x_low = v21;
      }
      v21 = _mm_unpacklo_ps(x_low, v7);
      v13 = RBX::Collision::Contact::getBody(this, 0);
      _mm_storel_ps((double *)&v20.x, v21);
      LODWORD(v20.z) = _mm_shuffle_ps(v22, v22, 229).m128_u32[0];
      v14 = G3D::Vector3::unitize(&v20, v9);
      v15 = (float)(v23.m128_f32[0] * v20.z) + v13->pv.position.translation.z;
      collisionConnector = this->collisionConnector;
      _mm_storel_ps(
        (double *)&collisionConnector->contactPoint.x,
        _mm_add_ps(
          (__m128)*(unsigned __int64 *)&v13->pv.position.translation.x,
          _mm_mul_ps(_mm_shuffle_ps(v23, v23, 224), (__m128)*(unsigned __int64 *)&v20.x)));
      collisionConnector->contactPoint.z = v15;
      collisionConnector->normal = v20;
      collisionConnector->depth = v14 - v19;
      LOBYTE(v4) = 1;
    }
  }
  return v4;
}


// Address: 0x1deb1b0 | Name: _ZN3RBX9Collision15BallBallContactC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::BallBallContact::BallBallContact(
        RBX::Collision::BallBallContact *this,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  RBX::Collision::Contact::Contact(this, p0, p1);
  this->_vptr$Contact = (int (**)(void))&off_299DBD0;
  this->collisionConnector = 0;
}


// Address: 0x1deb1d0 | Name: _ZN3RBX9Collision15BallBallContactD2Ev
void __fastcall RBX::Collision::BallBallContact::~BallBallContact(RBX::Collision::BallBallContact *this)
{
  this->_vptr$Contact = (int (**)(void))&off_299DBD0;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
}


// Address: 0x1deb1f0 | Name: _ZN3RBX9Collision15BallBallContactD0Ev
void __fastcall RBX::Collision::BallBallContact::~BallBallContact(RBX::Collision::BallBallContact *this)
{
  this->_vptr$Contact = (int (**)(void))&off_299DBD0;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
  operator delete(this);
}


// Address: 0x1deb220 | Name: _GLOBAL__sub_I_BallBallContact.cpp
void __cdecl GLOBAL__sub_I_BallBallContact_cpp()
{
  qword_2AAF510 = (__int64)boost::system::generic_category();
  qword_2AAF518 = (__int64)boost::system::generic_category();
  qword_2AAF520 = (__int64)boost::system::system_category();
}


