// Address: 0x10e9030 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN7RagdollE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Ragdoll *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08F08;
  if ( !qword_2A08F08 )
  {
    result = RBX::Name::declare("Ragdoll");
    qword_2A08F08 = result;
  }
  return result;
}


// Address: 0x10e9060 | Name: _ZNK3RBX5HUMAN7Ragdoll7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Ragdoll::getName(const RBX::HUMAN::Ragdoll *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08F08;
  if ( !qword_2A08F08 )
  {
    result = RBX::Name::declare("Ragdoll");
    qword_2A08F08 = result;
  }
  return result;
}


// Address: 0x10e9090 | Name: _ZN3RBX5HUMAN7RagdollC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Ragdoll::Ragdoll(
        RBX::HUMAN::Ragdoll *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895B50;
  *((float *)this + 4) = (float)dword_2859630 / 10.0;
}


// Address: 0x10e90c0 | Name: _ZN3RBX5HUMAN7RagdollD2Ev
void __fastcall RBX::HUMAN::Ragdoll::~Ragdoll(RBX::HUMAN::Ragdoll *this)
{
  const RBX::Humanoid *HumanoidConst; // r14
  char v2; // al
  char v3; // cl
  int v4; // eax

  *(_QWORD *)this = &off_2895B50;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  v2 = RBX::globalRand();
  v3 = 1;
  v4 = v2 & 0x7F;
  if ( v4 )
    v3 = v4;
  *((_BYTE *)HumanoidConst + 700) = -v3;
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
}


// Address: 0x10e9120 | Name: _ZN3RBX5HUMAN7RagdollD0Ev
void __fastcall RBX::HUMAN::Ragdoll::~Ragdoll(RBX::HUMAN::Ragdoll *this)
{
  const RBX::Humanoid *HumanoidConst; // r14
  char v2; // al
  char v3; // cl
  int v4; // eax

  *(_QWORD *)this = &off_2895B50;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  v2 = RBX::globalRand();
  v3 = 1;
  v4 = v2 & 0x7F;
  if ( v4 )
    v3 = v4;
  *((_BYTE *)HumanoidConst + 700) = -v3;
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e9180 | Name: _ZN3RBX5HUMAN7Ragdoll10onStepImplEv
void __fastcall RBX::HUMAN::Ragdoll::onStepImpl(RBX::HUMAN::Ragdoll *this)
{
  char *HumanoidConst; // rax
  RBX::PartInstance *TorsoSlow; // rax
  const RBX::PartInstance *v3; // r14
  const RBX::Vector3 *LinearVelocity; // rax
  __m128 v5; // xmm1
  const RBX::Vector3 *RotationalVelocity; // rax
  __m128 v7; // xmm1
  float v8; // [rsp+0h] [rbp-14h]

  HumanoidConst = (char *)RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  if ( HumanoidConst )
  {
    if ( HumanoidConst[697] > 0 && (float)((float)(dword_2859630 - dword_2859640) / 10.0) >= *((float *)this + 4)
      || (TorsoSlow = RBX::Humanoid::getTorsoSlow((RBX::Humanoid *)HumanoidConst)) != 0
      && (v3 = TorsoSlow,
          v8 = (float)((float)dword_2859650 / 10.0) * (float)((float)dword_2859650 / 10.0),
          LinearVelocity = RBX::PartInstance::getLinearVelocity(TorsoSlow),
          v5 = _mm_mul_ps(
                 (__m128)*(unsigned __int64 *)&LinearVelocity->y,
                 (__m128)*(unsigned __int64 *)&LinearVelocity->y),
          v8 > (float)(_mm_shuffle_ps(v5, v5, 229).m128_f32[0]
                     + (float)((float)(LinearVelocity->x * LinearVelocity->x) + v5.m128_f32[0])))
      && (RotationalVelocity = RBX::PartInstance::getRotationalVelocity(v3),
          v7 = _mm_mul_ps(
                 (__m128)*(unsigned __int64 *)&RotationalVelocity->y,
                 (__m128)*(unsigned __int64 *)&RotationalVelocity->y),
          v8 > (float)(_mm_shuffle_ps(v7, v7, 229).m128_f32[0]
                     + (float)((float)(RotationalVelocity->x * RotationalVelocity->x) + v7.m128_f32[0]))) )
    {
      *((_DWORD *)this + 4) = 0;
    }
  }
}


// Address: 0x10e92b0 | Name: _GLOBAL__sub_I_Ragdoll.cpp
void __cdecl GLOBAL__sub_I_Ragdoll_cpp()
{
  qword_2A08EE0 = (__int64)boost::system::generic_category();
  qword_2A08EE8 = (__int64)boost::system::generic_category();
  qword_2A08EF0 = (__int64)boost::system::system_category();
  dword_2A08EF8 = FLog::RegisterInt("RagdollDefaultTimerTenthSecond", &dword_2859630, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08EFC = FLog::RegisterInt("RagdollEarlyExitTimeTenthSecond", &dword_2859640, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F00 = FLog::RegisterInt("RagdollSlowEnoughToNotTenth", &dword_2859650, FastVarType::FASTVARTYPE_DYNAMIC);
}


