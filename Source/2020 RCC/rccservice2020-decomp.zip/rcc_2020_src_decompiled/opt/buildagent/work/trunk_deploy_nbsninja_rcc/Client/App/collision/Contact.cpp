// Address: 0x10cf360 | Name: _ZN3RBX9Collision7ContactC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::Contact::Contact(RBX::Collision::Contact *this, RBX::Primitive *p0, RBX::Primitive *p1)
{
  const RBX::Assembly *ConstPrimitiveAssembly; // r15
  const RBX::Assembly *v4; // r14
  char v5; // al

  this->_vptr$Contact = (int (**)(void))&off_2894FC8;
  this->prim0 = p0;
  this->prim1 = p1;
  *(_WORD *)&this->disabled = 0;
  ConstPrimitiveAssembly = RBX::Assembly::getConstPrimitiveAssembly(p0);
  v4 = RBX::Assembly::getConstPrimitiveAssembly(this->prim1);
  v5 = 1;
  if ( ConstPrimitiveAssembly && v4 )
    v5 = RBX::Assembly::getCanThrottle(ConstPrimitiveAssembly) && RBX::Assembly::getCanThrottle(v4);
  this->canThrottle = v5;
  *(_OWORD *)&this->index0 = -1;
  this->contactManagerSleepIndex = -1;
}


// Address: 0x10cf3e0 | Name: _ZN3RBX9Collision7Contact18computeCanThrottleEv
bool __fastcall RBX::Collision::Contact::computeCanThrottle(RBX::Collision::Contact *this)
{
  const RBX::Assembly *ConstPrimitiveAssembly; // r15
  const RBX::Assembly *v2; // r14
  bool result; // al

  ConstPrimitiveAssembly = RBX::Assembly::getConstPrimitiveAssembly(this->prim0);
  v2 = RBX::Assembly::getConstPrimitiveAssembly(this->prim1);
  result = 1;
  if ( ConstPrimitiveAssembly && v2 )
    return RBX::Assembly::getCanThrottle(ConstPrimitiveAssembly) && RBX::Assembly::getCanThrottle(v2);
  return result;
}


// Address: 0x10cf430 | Name: _ZN3RBX9Collision7Contact16stepContactAsyncEv
bool __fastcall RBX::Collision::Contact::stepContactAsync(RBX::Collision::Contact *this)
{
  return (*((bool (__fastcall **)(RBX::Collision::Contact *, float))this->_vptr$Contact + 3))(
           this,
           *(float *)&dword_2A08A88);
}


// Address: 0x10cf450 | Name: _ZN3RBX9Collision7Contact21updateContactInKernelEPNS_6KernelEPNS_14ContactManagerEb
void __fastcall RBX::Collision::Contact::updateContactInKernel(
        RBX::Collision::Contact *this,
        RBX::Kernel *kernel,
        RBX::ContactManager *cMan,
        bool contactResult)
{
  int (**v5)(void); // rax

  v5 = this->_vptr$Contact;
  if ( contactResult )
  {
    if ( ((unsigned __int8 (__fastcall *)(RBX::Collision::Contact *, RBX::Kernel *))v5[5])(this, kernel) )
    {
      if ( RBX::Collision::Contact::computeHighVelocityNewCollision(this) )
        RBX::ContactManager::requestContactRecursiveWake(cMan, this);
      else
        RBX::ContactManager::requestContactWake(cMan, this);
      RBX::Primitive::onNewOverlap(this->prim0, this->prim1);
    }
  }
  else if ( ((unsigned __int8 (__fastcall *)(RBX::Collision::Contact *, RBX::Kernel *))v5[6])(this, kernel) )
  {
    RBX::Primitive::onStopOverlap(this->prim0, this->prim1);
    RBX::ContactManager::requestContactWake(cMan, this);
  }
}


// Address: 0x10cf4d0 | Name: _ZN3RBX9Collision7Contact31computeHighVelocityNewCollisionEv
bool __fastcall RBX::Collision::Contact::computeHighVelocityNewCollision(RBX::Collision::Contact *this)
{
  RBX::Primitive *prim0; // rdi
  RBX::Primitive *prim1; // r15
  __m128 v4; // xmm1
  RBX::Assembly *v5; // rbp
  RBX::Primitive *v6; // rax
  const RBX::PV *v7; // rax
  __m128 v8; // xmm5
  __m128 v9; // xmm0
  __m128 v10; // xmm4
  bool v11; // r14
  const RBX::PV *v12; // rbx
  __m128 v13; // xmm1
  __m128 v14; // xmm3
  float v15; // xmm1_4
  __m128 v16; // xmm3
  __m128 v17; // xmm0
  RBX::Assembly *v18; // rbx
  RBX::Primitive *v19; // rax
  const RBX::PV *v20; // rax
  __m128 v21; // xmm5
  __m128 v22; // xmm4
  __m128 v23; // xmm0
  const RBX::PV *v24; // rbp
  __m128 v25; // xmm1
  __m128 v26; // xmm3
  RBX::Assembly *PrimitiveAssembly; // r15
  RBX::Primitive *AssemblyPrimitive; // rax
  const RBX::PV *PV; // rax
  const RBX::PV *v31; // rbp
  __m128 maxRadiusCached_low; // xmm0
  __m128 v33; // xmm2
  float v34; // xmm0_4
  __m128 v35; // xmm1
  RBX::Assembly *v36; // rbx
  RBX::Primitive *v37; // rax
  const RBX::PV *v38; // rax
  float *v39; // rbp
  float v40; // [rsp+Ch] [rbp-7Ch]
  __m128 v41; // [rsp+10h] [rbp-78h]
  __m128 v42; // [rsp+10h] [rbp-78h]
  __m128 v43; // [rsp+30h] [rbp-58h]
  __m128 v44; // [rsp+40h] [rbp-48h]
  __m128 v45; // [rsp+50h] [rbp-38h]

  if ( !stru_2AAF1E8.value )
  {
    PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(this->prim0);
    AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(PrimitiveAssembly);
    PV = RBX::Primitive::getPV(AssemblyPrimitive);
    v11 = 1;
    if ( fabs(PV->velocity.linear.x) <= 1.0 )
    {
      v31 = PV;
      if ( fabs(PV->velocity.linear.y) <= 1.0 && fabs(PV->velocity.linear.z) <= 1.0 )
      {
        if ( PrimitiveAssembly->maxRadiusDirty )
          RBX::Assembly::computeAssemblyMaxRadius(PrimitiveAssembly);
        maxRadiusCached_low = (__m128)LODWORD(PrimitiveAssembly->maxRadiusCached);
        v33 = _mm_mul_ps(
                _mm_shuffle_ps(maxRadiusCached_low, maxRadiusCached_low, 224),
                (__m128)*(unsigned __int64 *)&v31->velocity.rotational.x);
        v34 = maxRadiusCached_low.m128_f32[0] * v31->velocity.rotational.z;
        v35 = _mm_cmplt_ps(*(__m128 *)&stru_3E5440.x, _mm_and_ps(v33, (__m128)xmmword_3E5B40));
        v43 = _mm_shuffle_ps(v35, v35, 212);
        if ( (v43.m128_i8[0] & 1) == 0 && (v43.m128_i8[8] & 1) == 0 && fabs(v34) <= 1.0 )
        {
          v36 = RBX::Assembly::getPrimitiveAssembly(this->prim1);
          v37 = RBX::Assembly::getAssemblyPrimitive(v36);
          v38 = RBX::Primitive::getPV(v37);
          if ( fabs(v38->velocity.linear.x) <= 1.0 )
          {
            v39 = (float *)v38;
            if ( fabs(v38->velocity.linear.y) <= 1.0 && fabs(v38->velocity.linear.z) <= 1.0 )
            {
              if ( v36->maxRadiusDirty )
                RBX::Assembly::computeAssemblyMaxRadius(v36);
              return (fabs(v39[15] * v36->maxRadiusCached) > 1.0)
                   | (fabs(v39[16] * v36->maxRadiusCached) > 1.0)
                   | (fabs(v36->maxRadiusCached * v39[17]) > 1.0);
            }
          }
        }
      }
    }
    return v11;
  }
  prim0 = this->prim0;
  prim1 = this->prim1;
  v4 = (__m128)*(unsigned int *)(*(_QWORD *)(*((_QWORD *)prim1 + 25) + 64LL) + 228LL);
  v40 = v4.m128_f32[0];
  v41 = (__m128)*(unsigned int *)(*(_QWORD *)(*((_QWORD *)prim0 + 25) + 64LL) + 228LL);
  v4.m128_f32[0] = v4.m128_f32[0] / v41.m128_f32[0];
  v5 = RBX::Assembly::getPrimitiveAssembly(prim0);
  v6 = RBX::Assembly::getAssemblyPrimitive(v5);
  v7 = RBX::Primitive::getPV(v6);
  v8 = v4;
  v9 = (__m128)(unsigned int)dword_285943C;
  v10 = (__m128)xmmword_3E5B40;
  v11 = 1;
  if ( fabs(v7->velocity.linear.x * v4.m128_f32[0]) > *(float *)&dword_285943C )
    return v11;
  v12 = v7;
  if ( fabs(v7->velocity.linear.y * v4.m128_f32[0]) > *(float *)&dword_285943C
    || fabs(v7->velocity.linear.z * v4.m128_f32[0]) > *(float *)&dword_285943C )
  {
    return v11;
  }
  if ( v5->maxRadiusDirty )
  {
    RBX::Assembly::computeAssemblyMaxRadius(v5);
    v8 = v4;
    v10 = (__m128)xmmword_3E5B40;
    v9 = (__m128)(unsigned int)dword_285943C;
  }
  v13 = (__m128)LODWORD(v5->maxRadiusCached);
  v14 = _mm_mul_ps(_mm_shuffle_ps(v13, v13, 224), (__m128)*(unsigned __int64 *)&v12->velocity.rotational.x);
  v15 = v13.m128_f32[0] * v12->velocity.rotational.z;
  v16 = _mm_cmplt_ps(_mm_shuffle_ps(v9, v9, 224), _mm_and_ps(_mm_mul_ps(_mm_shuffle_ps(v8, v8, 224), v14), v10));
  v45 = _mm_shuffle_ps(v16, v16, 212);
  if ( (v45.m128_i8[0] & 1) != 0 )
    return v11;
  if ( (v45.m128_i8[8] & 1) != 0 )
    return v11;
  if ( COERCE_FLOAT(COERCE_UNSIGNED_INT(v8.m128_f32[0] * v15) & v10.m128_i32[0]) > v9.m128_f32[0] )
    return v11;
  v17 = v41;
  v17.m128_f32[0] = v41.m128_f32[0] / v40;
  v42 = v17;
  v18 = RBX::Assembly::getPrimitiveAssembly(prim1);
  v19 = RBX::Assembly::getAssemblyPrimitive(v18);
  v20 = RBX::Primitive::getPV(v19);
  v21 = (__m128)xmmword_3E5B40;
  v22 = v17;
  v23 = (__m128)(unsigned int)dword_285943C;
  if ( fabs(v20->velocity.linear.x * v22.m128_f32[0]) > *(float *)&dword_285943C )
    return v11;
  v24 = v20;
  if ( fabs(v20->velocity.linear.y * v42.m128_f32[0]) > *(float *)&dword_285943C
    || fabs(v20->velocity.linear.z * v42.m128_f32[0]) > *(float *)&dword_285943C )
  {
    return v11;
  }
  if ( v18->maxRadiusDirty )
  {
    RBX::Assembly::computeAssemblyMaxRadius(v18);
    v21 = (__m128)xmmword_3E5B40;
    v22 = v42;
    v23 = (__m128)(unsigned int)dword_285943C;
  }
  v25 = (__m128)LODWORD(v18->maxRadiusCached);
  v26 = _mm_cmplt_ps(
          _mm_shuffle_ps(v23, v23, 224),
          _mm_and_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(v22, v22, 224),
              _mm_mul_ps(_mm_shuffle_ps(v25, v25, 224), (__m128)*(unsigned __int64 *)&v24->velocity.rotational.x)),
            v21));
  v44 = _mm_shuffle_ps(v26, v26, 212);
  return (v44.m128_i8[8] | v44.m128_i8[0]) & 1
       | (COERCE_FLOAT(
            COERCE_UNSIGNED_INT((float)(v25.m128_f32[0] * v24->velocity.rotational.z) * v22.m128_f32[0])
          & v21.m128_i32[0]) > v23.m128_f32[0]);
}


// Address: 0x10cf8e0 | Name: _ZN3RBX9Collision7Contact11stepContactEPNS_6KernelEPNS_14ContactManagerEiii
bool __fastcall RBX::Collision::Contact::stepContact(
        RBX::Collision::Contact *this,
        RBX::Kernel *kernel,
        RBX::ContactManager *cMan,
        int worldStepId,
        int uiStepId,
        int throttling)
{
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  const RBX::CoordinateFrame *v8; // rax
  int (**v9)(void); // rcx
  bool v10; // bp
  char v12; // al

  CoordinateFrame = RBX::Primitive::getCoordinateFrame(this->prim0);
  if ( RBX::Math::hasNanOrInf(CoordinateFrame)
    || (v8 = RBX::Primitive::getCoordinateFrame(this->prim1), RBX::Math::hasNanOrInf(v8)) )
  {
    v9 = this->_vptr$Contact;
LABEL_4:
    if ( ((unsigned __int8 (__fastcall *)(RBX::Collision::Contact *, RBX::Kernel *))v9[6])(this, kernel) )
    {
      RBX::Primitive::onStopOverlap(this->prim0, this->prim1);
      RBX::ContactManager::requestContactWake(cMan, this);
    }
    return 0;
  }
  v12 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *, float))this->_vptr$Contact + 3))(
          this,
          *(float *)&dword_2A08A88);
  v9 = this->_vptr$Contact;
  if ( !v12 )
    goto LABEL_4;
  v10 = 1;
  if ( ((unsigned __int8 (__fastcall *)(RBX::Collision::Contact *, RBX::Kernel *))v9[5])(this, kernel) )
  {
    if ( RBX::Collision::Contact::computeHighVelocityNewCollision(this) )
      RBX::ContactManager::requestContactRecursiveWake(cMan, this);
    else
      RBX::ContactManager::requestContactWake(cMan, this);
    RBX::Primitive::onNewOverlap(this->prim0, this->prim1);
  }
  return v10;
}


// Address: 0x10cf9b0 | Name: _ZNK3RBX9Collision7Contact21primsHaveValidCFramesEv
bool __fastcall RBX::Collision::Contact::primsHaveValidCFrames(const RBX::Collision::Contact *this)
{
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  const RBX::CoordinateFrame *v3; // rax

  CoordinateFrame = RBX::Primitive::getCoordinateFrame(this->prim0);
  if ( RBX::Math::hasNanOrInf(CoordinateFrame) )
    return 0;
  v3 = RBX::Primitive::getCoordinateFrame(this->prim1);
  return !RBX::Math::hasNanOrInf(v3);
}


// Address: 0x10cf9f0 | Name: _ZN3RBX9Collision7Contact24atLeastOneAssemblyMovingEv
bool __fastcall RBX::Collision::Contact::atLeastOneAssemblyMoving(RBX::Collision::Contact *this)
{
  unsigned __int32 v1; // ecx
  bool result; // al
  RBX::Assembly *PrimitiveAssemblyFast; // rax

  v1 = RBX::Assembly::getPrimitiveAssemblyFast(this->prim0)->state - 1;
  result = 1;
  if ( v1 >= 3 )
  {
    PrimitiveAssemblyFast = RBX::Assembly::getPrimitiveAssemblyFast(this->prim1);
    return (PrimitiveAssemblyFast->state | 2) == 3 || PrimitiveAssemblyFast->state == WAKE_PENDING;
  }
  return result;
}


// Address: 0x10cfa30 | Name: _ZN3RBX9Collision7Contact39atLeastOneAssemblyMovingOrInterpolatingEv
bool __fastcall RBX::Collision::Contact::atLeastOneAssemblyMovingOrInterpolating(RBX::Collision::Contact *this)
{
  RBX::Assembly *PrimitiveAssemblyFast; // rbx
  RBX::Assembly *v2; // r14
  bool v3; // bp
  RBX::Primitive *v4; // rax
  RBX::Primitive *AssemblyPrimitive; // rax

  PrimitiveAssemblyFast = RBX::Assembly::getPrimitiveAssemblyFast(this->prim0);
  v2 = RBX::Assembly::getPrimitiveAssemblyFast(this->prim1);
  v3 = 1;
  if ( (unsigned int)(PrimitiveAssemblyFast->state - 1) >= 3 && (unsigned int)(v2->state - 1) >= 3 )
  {
    if ( PrimitiveAssemblyFast->filterPhase < NoSim_Send
      || (v4 = RBX::Assembly::getAssemblyPrimitive(PrimitiveAssemblyFast),
          RBX::Primitive::getNetworkInterpolationCanSleep(v4)) )
    {
      if ( v2->filterPhase < NoSim_Send )
      {
        return 0;
      }
      else
      {
        AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(v2);
        return !RBX::Primitive::getNetworkInterpolationCanSleep(AssemblyPrimitive);
      }
    }
  }
  return v3;
}


// Address: 0x10cfab0 | Name: _ZN3RBX9Collision7Contact12getInContactEv
bool __fastcall RBX::Collision::Contact::getInContact(RBX::Collision::Contact *this)
{
  return this->inContact;
}


// Address: 0x10cfac0 | Name: _ZN3RBX9Collision7Contact27updateCollisionDataInKernelEPNS_6KernelE
bool __fastcall RBX::Collision::Contact::updateCollisionDataInKernel(
        RBX::Collision::Contact *this,
        RBX::Kernel *kernel)
{
  bool v2; // r15
  int v3; // eax
  unsigned int v4; // ebp
  int v5; // r12d
  RBX::CollisionConnector *v6; // rax
  float x; // xmm0_4

  v2 = RBX::ContactManager::doPrimitivesCollide(
         *(RBX::ContactManager **)(*((_QWORD *)this->prim0 + 17) + 784LL),
         this->prim0,
         this->prim1);
  v3 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *))this->_vptr$Contact + 1))(this);
  if ( v3 )
  {
    v4 = v3 - 1;
    v5 = 0;
    do
    {
      v6 = (RBX::CollisionConnector *)(*((__int64 (__fastcall **)(RBX::Collision::Contact *, _QWORD))this->_vptr$Contact
                                       + 2))(
                                        this,
                                        v4);
      if ( v6 )
      {
        x = v6->normal.x;
        if ( v6->collisionIndex < 0 )
        {
          if ( x != 0.0 || v6->normal.y != 0.0 || v6->normal.z != 0.0 )
          {
            if ( v2 )
              RBX::Kernel::insertCollision(kernel, v6);
            LOBYTE(v6) = 1;
            if ( this->inContact )
              LODWORD(v6) = v5;
            this->inContact = 1;
            v5 = (int)v6;
          }
        }
        else if ( x == 0.0 && v6->normal.y == 0.0 && v6->normal.z == 0.0 )
        {
          RBX::Kernel::removeCollision(kernel, v6);
          ((void (__fastcall *)(RBX::Collision::Contact *, _QWORD))*this->_vptr$Contact)(this, v4);
        }
      }
      --v4;
    }
    while ( v4 != -1 );
  }
  else
  {
    LOBYTE(v5) = 0;
  }
  return v5 & 1;
}


// Address: 0x10cfbe0 | Name: _ZN3RBX9Collision7Contact29removeCollisionDataFromKernelEPNS_6KernelE
bool __fastcall RBX::Collision::Contact::removeCollisionDataFromKernel(
        RBX::Collision::Contact *this,
        RBX::Kernel *kernel)
{
  bool inContact; // r15
  int v3; // eax
  unsigned int v4; // ebp
  RBX::CollisionConnector *v5; // rax

  inContact = this->inContact;
  this->inContact = 0;
  v3 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *))this->_vptr$Contact + 1))(this);
  if ( v3 )
  {
    v4 = v3 - 1;
    do
    {
      v5 = (RBX::CollisionConnector *)(*((__int64 (__fastcall **)(RBX::Collision::Contact *, _QWORD))this->_vptr$Contact
                                       + 2))(
                                        this,
                                        v4);
      if ( v5 )
      {
        if ( v5->collisionIndex >= 0 )
        {
          RBX::Kernel::removeCollision(kernel, v5);
          inContact = 1;
        }
        ((void (__fastcall *)(RBX::Collision::Contact *, _QWORD))*this->_vptr$Contact)(this, v4);
      }
      --v4;
    }
    while ( v4 != -1 );
  }
  return inContact;
}


// Address: 0x10cfc60 | Name: _ZN3RBX9Collision7Contact37removeCollisionDataFromKernelForSleepEPNS_6KernelE
bool __fastcall RBX::Collision::Contact::removeCollisionDataFromKernelForSleep(
        RBX::Collision::Contact *this,
        RBX::Kernel *kernel)
{
  int v2; // eax
  unsigned int v3; // ebp
  bool v4; // r15
  RBX::CollisionConnector *v5; // rax
  float *v6; // rbx

  if ( !this->inContact )
    return 0;
  v2 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *))this->_vptr$Contact + 1))(this);
  if ( !v2 )
    return 0;
  v3 = v2 - 1;
  v4 = 0;
  do
  {
    v5 = (RBX::CollisionConnector *)(*((__int64 (__fastcall **)(RBX::Collision::Contact *, _QWORD))this->_vptr$Contact
                                     + 2))(
                                      this,
                                      v3);
    if ( v5 )
    {
      v6 = (float *)v5;
      if ( v5->collisionIndex >= 0 )
      {
        RBX::Kernel::removeCollision(kernel, v5);
        v4 = 1;
        if ( v6[9] == 0.0 && v6[10] == 0.0 && v6[11] == 0.0 )
          ((void (__fastcall *)(RBX::Collision::Contact *, _QWORD))*this->_vptr$Contact)(this, v3);
      }
    }
    --v3;
  }
  while ( v3 != -1 );
  return v4;
}


// Address: 0x10cfd10 | Name: _ZN3RBX9Collision7Contact35updateCollisionDataInKernelForSleepEPNS_6KernelE
bool __fastcall RBX::Collision::Contact::updateCollisionDataInKernelForSleep(
        RBX::Collision::Contact *this,
        RBX::Kernel *kernel)
{
  return this->inContact
      && (*((bool (__fastcall **)(RBX::Collision::Contact *, RBX::Kernel *))this->_vptr$Contact + 5))(this, kernel);
}


// Address: 0x10cfd30 | Name: _ZN3RBX9Collision7Contact28deleteAllCollisionConnectorsEv
void __fastcall RBX::Collision::Contact::deleteAllCollisionConnectors(RBX::Collision::Contact *this)
{
  int v1; // eax
  unsigned int v2; // ebp

  v1 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *))this->_vptr$Contact + 1))(this);
  if ( v1 )
  {
    v2 = v1 - 1;
    do
      ((void (__fastcall *)(RBX::Collision::Contact *, _QWORD))*this->_vptr$Contact)(this, v2--);
    while ( v2 != -1 );
  }
}


// Address: 0x10cfd70 | Name: _ZN3RBX9Collision18highVelocityVectorERKN3G3D7Vector3Ef
bool __fastcall RBX::Collision::highVelocityVector(const RBX::Vector3 *v, float a2, float max)
{
  bool result; // al

  result = 1;
  if ( fabs(v->x) <= a2 && fabs(v->y) <= a2 )
    return fabs(v->z) > a2;
  return result;
}


// Address: 0x10cfdb0 | Name: _ZN3RBX9Collision7Contact22computeCollisionParamsEPNS_9PrimitiveES3_
RBX::CollisionParams *__fastcall RBX::Collision::Contact::computeCollisionParams(
        RBX::CollisionParams *__return_ptr retstr,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  float v4; // eax
  float v5; // ecx
  float outRest; // [rsp+8h] [rbp-20h] BYREF
  float outFric[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  RBX::MaterialProperties::updateFricRestPrims(outFric, &outRest, p0, p1);
  v4 = outFric[0];
  v5 = outRest;
  retstr->b0 = (RBX::Body *)((char *)p0 + 152);
  retstr->b1 = (RBX::Body *)((char *)p1 + 152);
  retstr->friction = v4;
  retstr->restitution = v5;
  return retstr;
}


// Address: 0x10cfe10 | Name: _ZN3RBX9Collision7Contact35onPrimitiveContactParamatersChangedEv
void __fastcall RBX::Collision::Contact::onPrimitiveContactParamatersChanged(RBX::Collision::Contact *this)
{
  int v1; // eax
  int v2; // r14d
  unsigned int i; // ebp
  __int64 v4; // rax
  float v5; // edx
  float outRest; // [rsp+8h] [rbp-20h] BYREF
  float outFric[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  v1 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *))this->_vptr$Contact + 1))(this);
  if ( v1 )
  {
    v2 = v1;
    RBX::MaterialProperties::updateFricRestPrims(outFric, &outRest, this->prim0, this->prim1);
    for ( i = 0; i != v2; ++i )
    {
      v4 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *, _QWORD))this->_vptr$Contact + 2))(this, i);
      v5 = outRest;
      *(float *)(v4 + 16) = outFric[0];
      *(float *)(v4 + 20) = v5;
    }
  }
}


// Address: 0x10cfe80 | Name: _ZN3RBX9Collision7Contact18recursiveWakeEventEv
void __fastcall RBX::Collision::Contact::recursiveWakeEvent(RBX::Collision::Contact *this)
{
  RBX::Primitive *prim0; // rdi
  RBX::World *v3; // r14

  prim0 = this->prim0;
  v3 = (RBX::World *)*((_QWORD *)prim0 + 17);
  RBX::Primitive::updateAssemblyContactsOnWake(prim0, v3, depthLeft);
  RBX::Primitive::updateAssemblyContactsOnWake(this->prim1, v3, depthLeft);
}


// Address: 0x10cfec0 | Name: _ZN3RBX9Collision7Contact9wakeEventEv
void __fastcall RBX::Collision::Contact::wakeEvent(RBX::Collision::Contact *this)
{
  RBX::Primitive *prim0; // rdi
  RBX::World *v3; // r14

  prim0 = this->prim0;
  v3 = (RBX::World *)*((_QWORD *)prim0 + 17);
  RBX::Primitive::updateAssemblyContactsOnWake(prim0, v3, 0);
  RBX::Primitive::updateAssemblyContactsOnWake(this->prim1, v3, 0);
}


// Address: 0x10cff20 | Name: _ZN3RBX9Collision7Contact24primitiveMovedExternallyEPNS_6KernelE
void __fastcall RBX::Collision::Contact::primitiveMovedExternally(RBX::Collision::Contact *this, RBX::Kernel *kernel)
{
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Collision::Contact *, RBX::Kernel *))this->_vptr$Contact + 6))(
         this,
         kernel) )
  {
    RBX::Primitive::onStopOverlap(this->prim0, this->prim1);
  }
  (*((void (__fastcall **)(RBX::Collision::Contact *))this->_vptr$Contact + 10))(this);
}


// Address: 0x10cff50 | Name: _ZN3RBX9Collision7Contact25computeIsCollidingNonStepEf
bool __fastcall RBX::Collision::Contact::computeIsCollidingNonStep(
        RBX::Collision::Contact *this,
        float a2,
        double overlapIgnored)
{
  bool value; // bl
  const RBX::CoordinateFrame *CoordinateFrame; // rdi
  const RBX::CoordinateFrame *v6; // rax
  const RBX::CoordinateFrame *v8; // rax

  RBX::Primitive::getFastFuzzyExtents(this->prim0);
  RBX::Primitive::getFastFuzzyExtents(this->prim1);
  value = stru_2AAF230.value;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(this->prim0);
  if ( value )
  {
    if ( RBX::Math::hasNanOrInfFast(CoordinateFrame) )
      return 0;
    v6 = RBX::Primitive::getCoordinateFrame(this->prim1);
    if ( RBX::Math::hasNanOrInfFast(v6) )
      return 0;
  }
  else
  {
    if ( RBX::Math::hasNanOrInf(CoordinateFrame) )
      return 0;
    v8 = RBX::Primitive::getCoordinateFrame(this->prim1);
    if ( RBX::Math::hasNanOrInf(v8) )
      return 0;
  }
  if ( !this->disabled )
    return (*((bool (__fastcall **)(RBX::Collision::Contact *, float, double))this->_vptr$Contact + 3))(
             this,
             a2,
             overlapIgnored);
  return 0;
}


// Address: 0x10cfff0 | Name: _ZN3RBX9Collision7Contact24computeIsAdjacentNonStepEf
bool __fastcall RBX::Collision::Contact::computeIsAdjacentNonStep(
        RBX::Collision::Contact *this,
        float a2,
        double spaceAllowed)
{
  return !RBX::Collision::Contact::computeIsCollidingNonStep(this, a2, spaceAllowed)
      && RBX::Collision::Contact::computeIsCollidingNonStep(this, -a2, spaceAllowed);
}


// Address: 0x10d0030 | Name: _ZN3RBX9Collision7Contact19getDeepestCollisionEv
const RBX::CollisionConnector *__fastcall RBX::Collision::Contact::getDeepestCollision(RBX::Collision::Contact *this)
{
  int v1; // eax
  unsigned int v2; // ebp
  int v3; // r15d
  const RBX::CollisionConnector *v4; // r14
  __int64 v5; // rax

  if ( !this->inContact )
    return 0;
  if ( (*((unsigned int (__fastcall **)(RBX::Collision::Contact *))this->_vptr$Contact + 4))(this) == 2 )
    return 0;
  v1 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *))this->_vptr$Contact + 1))(this);
  v2 = 0;
  if ( !v1 )
    return 0;
  v3 = v1;
  v4 = 0;
  do
  {
    v5 = (*((__int64 (__fastcall **)(RBX::Collision::Contact *, _QWORD))this->_vptr$Contact + 2))(this, v2);
    if ( *(int *)(v5 + 52) >= 0 && *(float *)(v5 + 48) < 3.4028235e38 )
      v4 = (const RBX::CollisionConnector *)v5;
    ++v2;
  }
  while ( v3 != v2 );
  return v4;
}


// Address: 0x10d00a0 | Name: _ZN3RBX9Collision7Contact21getDebugContactPointsEb
RBX::Collision::Contact *__fastcall RBX::Collision::Contact::getDebugContactPoints(
        RBX::Collision::Contact *this,
        _BYTE *a2,
        int a3)
{
  RBX::Collision::Contact *v3; // r15
  _BYTE *v5; // r14
  std::vector<RBX::Collision::DebugContactPoint>::size_type v6; // rbx
  unsigned int v7; // ebp
  __int64 v8; // r15
  char *v9; // rax
  __int64 v10; // rax
  int v11; // esi
  int v12; // edi
  RBX::Primitive *prim0; // r12
  RBX::Primitive *prim1; // rax
  int (**v15)(void); // r13
  signed __int64 v16; // r12
  __int64 v17; // r14
  unsigned __int64 v18; // rax
  unsigned __int64 v19; // rax
  char *v20; // rsi
  RBX::Primitive *v21; // rbx
  struct _Unwind_Exception *v23; // rbx
  int (**v24)(void); // rdi
  int v26; // [rsp+10h] [rbp-58h]
  int v27; // [rsp+14h] [rbp-54h]
  _BYTE v28[24]; // [rsp+18h] [rbp-50h]

  v3 = this;
  *(_OWORD *)&this->_vptr$Contact = 0;
  this->prim1 = 0;
  if ( a2[25] )
  {
    v5 = a2;
    if ( (*(unsigned int (__fastcall **)(_BYTE *))(*(_QWORD *)a2 + 32LL))(a2) != 2 )
    {
      v6 = (*(unsigned int (__fastcall **)(_BYTE *))(*(_QWORD *)a2 + 8LL))(a2);
      std::vector<RBX::Collision::DebugContactPoint>::reserve(
        (std::vector<RBX::Collision::DebugContactPoint> *)this,
        v6);
      if ( (_DWORD)v6 )
      {
        v7 = 0;
        v26 = a3;
        v27 = v6;
        do
        {
          v10 = (*(__int64 (__fastcall **)(_BYTE *, _QWORD))(*(_QWORD *)v5 + 16LL))(v5, v7);
          if ( (_BYTE)a3 )
          {
            if ( *(int *)(v10 + 52) >= 0 )
              goto LABEL_12;
          }
          else if ( *(float *)(v10 + 36) != 0.0 || *(float *)(v10 + 40) != 0.0 || *(float *)(v10 + 44) != 0.0 )
          {
LABEL_12:
            v11 = a3;
            *(_DWORD *)&v28[8] = *(_DWORD *)(v10 + 32);
            *(_QWORD *)v28 = *(_QWORD *)(v10 + 24);
            *(_DWORD *)&v28[20] = *(_DWORD *)(v10 + 44);
            *(_QWORD *)&v28[12] = *(_QWORD *)(v10 + 36);
            v12 = *(_DWORD *)(v10 + 48);
            prim0 = v3->prim0;
            prim1 = v3->prim1;
            if ( prim0 >= prim1 )
            {
              v15 = v3->_vptr$Contact;
              v16 = prim0 - (RBX::Primitive *)v3->_vptr$Contact;
              v17 = 0x6DB6DB6DB6DB6DB7LL * (v16 >> 2);
              if ( (unsigned __int64)(v17 + 1) > 0x924924924924924LL )
              {
                v23 = (struct _Unwind_Exception *)std::__vector_base_common<true>::__throw_length_error(this);
                v24 = this->_vptr$Contact;
                if ( this->_vptr$Contact )
                {
                  this->prim0 = (RBX::Primitive *)v24;
                  operator delete(v24);
                }
                _Unwind_Resume(v23);
              }
              v18 = 0x6DB6DB6DB6DB6DB7LL * ((prim1 - (RBX::Primitive *)v15) >> 2);
              v8 = 0x924924924924924LL;
              if ( v18 > 0x492492492492491LL )
                goto LABEL_19;
              v19 = 2 * v18;
              if ( v19 < v17 + 1 )
                v19 = v17 + 1;
              v8 = v19;
              if ( v19 )
              {
LABEL_19:
                v9 = (char *)operator new(28 * v8);
              }
              else
              {
                v8 = 0;
                v9 = 0;
              }
              v20 = &v9[4 * (v16 >> 2)];
              v21 = (RBX::Primitive *)&v9[28 * v8];
              *((_QWORD *)v20 + 2) = *(_QWORD *)&v28[16];
              *(_OWORD *)v20 = *(_OWORD *)v28;
              *((_DWORD *)v20 + 6) = v12;
              if ( v16 > 0 )
                memcpy(&v20[28 * (v16 / -28)], v15, v16);
              this->_vptr$Contact = (int (**)(void))&v20[28 * (v16 / -28)];
              v3 = this;
              this->prim0 = (RBX::Primitive *)(v20 + 28);
              this->prim1 = v21;
              a3 = v26;
              v5 = a2;
              if ( v15 )
                operator delete(v15);
            }
            else
            {
              *((_QWORD *)prim0 + 2) = *(_QWORD *)&v28[16];
              *(_OWORD *)prim0 = *(_OWORD *)v28;
              *((_DWORD *)prim0 + 6) = v12;
              v3->prim0 = (RBX::Primitive *)((char *)v3->prim0 + 28);
              a3 = v11;
            }
            LODWORD(v6) = v27;
          }
          ++v7;
        }
        while ( v7 < (unsigned int)v6 );
      }
    }
  }
  return v3;
}


// Address: 0x10d04e0 | Name: _GLOBAL__sub_I_Contact.cpp
void __cdecl GLOBAL__sub_I_Contact_cpp()
{
  qword_2A08A60 = (__int64)boost::system::generic_category();
  qword_2A08A68 = (__int64)boost::system::generic_category();
  qword_2A08A70 = (__int64)boost::system::system_category();
  dword_2A08A78 = FLog::RegisterInt("OptimizedContactWakeDepth", &depthLeft, FastVarType::FASTVARTYPE_STATIC);
  dword_2A08A80 = FLog::RegisterInt("OptimizedContactOverlapGoalMicro", &dword_2A08A7C, FastVarType::FASTVARTYPE_STATIC);
  dword_2A08A84 = FLog::RegisterInt(
                    "OptimizedContactPipelineSpatialHashOverlapToleranceMicro",
                    &dword_2859428,
                    FastVarType::FASTVARTYPE_STATIC);
}


