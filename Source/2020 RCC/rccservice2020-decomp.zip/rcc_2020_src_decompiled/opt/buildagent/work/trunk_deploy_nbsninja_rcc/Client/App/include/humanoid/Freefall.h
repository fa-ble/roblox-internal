// Address: 0x10e7f30 | Name: _ZN3RBX5HUMAN8Freefall15ladderCheckRateEv
int __fastcall RBX::HUMAN::Freefall::ladderCheckRate(RBX::HUMAN::Freefall *this)
{
  return 0;
}


// Address: 0x10e7f40 | Name: _ZNK3RBX5HUMAN8Freefall17armsShouldCollideEv
bool __fastcall RBX::HUMAN::Freefall::armsShouldCollide(const RBX::HUMAN::Freefall *this)
{
  return 0;
}


// Address: 0x10e7f50 | Name: _ZNK3RBX5HUMAN8Freefall17legsShouldCollideEv
bool __fastcall RBX::HUMAN::Freefall::legsShouldCollide(const RBX::HUMAN::Freefall *this)
{
  return 0;
}


// Address: 0x10e7f60 | Name: _ZNK3RBX5HUMAN8Freefall14enableAutoJumpEv
bool __fastcall RBX::HUMAN::Freefall::enableAutoJump(const RBX::HUMAN::Freefall *this)
{
  return 0;
}


// Address: 0x10e7f70 | Name: _ZNK3RBX5HUMAN8Freefall12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::Freefall::getStateType(const RBX::HUMAN::Freefall *this)
{
  return RBX::HUMAN::StateType::FREE_FALL;
}


