// Address: 0x10ccd50 | Name: _ZN3RBX10Tattletale22containsBacklistedWordERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERS7_
bool __fastcall RBX::Tattletale::containsBacklistedWord(const std::string *text, std::string *swearMatch)
{
  bool v2; // bl
  boost::upgrade_lock<boost::shared_mutex> v4; // [rsp+8h] [rbp-20h] BYREF

  v4.m = &stru_2A088D8;
  v4.is_locked = 0;
  boost::upgrade_lock<boost::shared_mutex>::lock(&v4);
  v2 = `anonymous namespace'::containsBacklistedWordNoLock(text, swearMatch);
  if ( v4.is_locked )
    boost::shared_mutex::unlock_upgrade(v4.m);
  return v2;
}


// Address: 0x10ccdd0 | Name: _ZN12_GLOBAL__N_128containsBacklistedWordNoLockERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEERS6_
bool __fastcall `anonymous namespace'::containsBacklistedWordNoLock(const std::string *text, std::string *match)
{
  size_t v2; // r8
  const void *v3; // r9
  unsigned __int8 v4; // r12
  unsigned __int64 v5; // rax
  bool v6; // r14
  unsigned int v7; // ebp
  unsigned __int64 v8; // r13
  char *v9; // rbx
  const unsigned __int16 **v10; // rax
  char *v11; // rsi
  _BYTE *v12; // rcx
  const unsigned __int16 **v13; // rdx
  _BYTE *v14; // r15
  __int64 v15; // rbx
  _BYTE *v16; // r14
  const unsigned __int16 **v17; // r12
  const __int32_t **v18; // rax
  unsigned __int64 v19; // rax
  __int64 v20; // r14
  std::uniform_int_distribution<long>::param_type *v21; // rbp
  __int64 v22; // rbx
  unsigned __int64 v23; // r14
  std::uniform_int_distribution<long>::result_type v24; // rbx
  std::uniform_int_distribution<long>::result_type v25; // rax
  __int64 v26; // rax
  unsigned __int8 *v27; // r12
  size_t v28; // rdx
  char *v29; // rcx
  int v30; // r15d
  unsigned __int64 v31; // rbx
  const char *v32; // rsi
  unsigned __int8 *v33; // r13
  signed __int64 v34; // rbx
  int v35; // r14d
  void *v36; // rbp
  char *v37; // rax
  char *v38; // rbp
  bool v39; // bl
  bool v41; // [rsp+Eh] [rbp-BAh]
  bool value; // [rsp+Fh] [rbp-B9h]
  unsigned __int8 v43; // [rsp+10h] [rbp-B8h] BYREF
  _BYTE v44[7]; // [rsp+11h] [rbp-B7h] BYREF
  char *v45; // [rsp+18h] [rbp-B0h]
  void *ptr; // [rsp+20h] [rbp-A8h]
  void *s; // [rsp+28h] [rbp-A0h]
  int v48; // [rsp+34h] [rbp-94h]
  _BYTE *v49; // [rsp+38h] [rbp-90h]
  char *v50; // [rsp+40h] [rbp-88h]
  RBX::Random v51; // [rsp+48h] [rbp-80h] BYREF
  std::uniform_int_distribution<long>::param_type __p; // [rsp+50h] [rbp-78h] BYREF
  std::uniform_int_distribution<long>::result_type a; // [rsp+60h] [rbp-68h]
  soap *v54; // [rsp+70h] [rbp-58h]
  unsigned __int8 *v55; // [rsp+78h] [rbp-50h]
  std::uniform_int_distribution<long> v56; // [rsp+80h] [rbp-48h] BYREF

  v54 = (soap *)match;
  std::string::basic_string(&v43, text);
  v4 = v43;
  v5 = (unsigned __int64)v43 >> 1;
  v6 = (v43 & 1) == 0;
  if ( (v43 & 1) != 0 )
    v5 = (unsigned __int64)v45;
  if ( v5 )
  {
    v7 = 1;
    v8 = 0;
    v9 = v45;
    v10 = __ctype_b_loc();
    v11 = v9;
    v12 = v44;
    v13 = v10;
    do
    {
      v14 = v12;
      if ( !v6 )
        v14 = ptr;
      v15 = (unsigned __int8)v14[v8];
      if ( ((*v13)[v15] & 0x100) != 0 )
      {
        if ( (unsigned int)(v15 + 128) <= 0x17F )
        {
          v16 = v12;
          v17 = v13;
          v18 = __ctype_tolower_loc();
          v13 = v17;
          v12 = v16;
          LODWORD(v15) = (*v18)[v15];
        }
        v14[v8] = v15;
        v4 = v43;
        v11 = v45;
      }
      v8 = v7;
      v6 = (v4 & 1) == 0;
      v19 = v4 >> 1;
      if ( (v4 & 1) != 0 )
        v19 = (unsigned __int64)v11;
      ++v7;
    }
    while ( v19 > v8 );
  }
  if ( (_BYTE)byte_2A08A18 || !__cxa_guard_acquire(&byte_2A08A18) )
  {
    if ( !stru_2A088A0.value )
      goto LABEL_24;
  }
  else
  {
    `anonymous namespace'::getNaughtyList();
    __cxa_guard_release(&byte_2A08A18);
    if ( !stru_2A088A0.value )
      goto LABEL_24;
  }
  if ( !dword_2A08A10 )
  {
    v20 = *(&xmmword_2A088C0 + 1);
    v21 = (std::uniform_int_distribution<long>::param_type *)xmmword_2A088C0;
    v22 = *(&xmmword_2A088C0 + 1) - xmmword_2A088C0;
    if ( *(&xmmword_2A088C0 + 1) != xmmword_2A088C0 )
    {
      v51.state = 0;
      RBX::Random::Random(&v51);
      if ( v22 >= 25 )
      {
        v56 = (std::uniform_int_distribution<long>)_mm_slli_si128((__m128i)0x7FFFFFFFFFFFFFFFuLL, 8);
        v23 = v20 - 24;
        if ( v23 > (unsigned __int64)v21 )
        {
          v24 = v22 / 0x18uLL - 1;
          do
          {
            __p.__a_ = 0;
            __p.__b_ = v24;
            v25 = std::uniform_int_distribution<long>::operator()<RBX::random_generator>(
                    &v56,
                    (RBX::random_generator *)&v51,
                    &__p);
            if ( v25 )
            {
              a = v21[1].__a_;
              __p = *v21;
              v26 = 3 * v25;
              v21[1].__a_ = *(&v21[1].__a_ + v26);
              *v21 = *(std::uniform_int_distribution<long>::param_type *)((char *)v21 + 8 * v26);
              *(&v21[1].__a_ + v26) = a;
              *(__m128i *)((char *)v21 + 8 * v26) = _mm_load_si128((const __m128i *)&__p);
            }
            v21 = (std::uniform_int_distribution<long>::param_type *)((char *)v21 + 24);
            --v24;
          }
          while ( (unsigned __int64)v21 < v23 );
        }
      }
    }
  }
LABEL_24:
  v27 = (unsigned __int8 *)xmmword_2A088C0;
  v55 = (unsigned __int8 *)*(&xmmword_2A088C0 + 1);
  if ( xmmword_2A088C0 != *(&xmmword_2A088C0 + 1) )
  {
    value = stru_2A08870.value;
    v48 = dword_2859400;
    if ( (v43 & 1) != 0 )
    {
      v28 = (size_t)ptr;
      v29 = v45;
    }
    else
    {
      v29 = (char *)((unsigned __int64)v43 >> 1);
      v28 = (size_t)v44;
    }
    v41 = dword_2859400 > 0 && stru_2A088A0.value;
    v49 = v29;
    s = (void *)v28;
    v50 = &v29[v28];
    v30 = 0;
    while ( 1 )
    {
      v31 = *v27;
      if ( value )
      {
        if ( (v31 & 1) != 0 )
          v32 = (const char *)*((_QWORD *)v27 + 2);
        else
          v32 = (const char *)(v27 + 1);
        if ( strstr((const char *)s, v32) )
        {
LABEL_51:
          v39 = 1;
          std::string::operator=(v54, (int)v27, v28, v29, v2, v3);
          if ( (v43 & 1) != 0 )
            goto LABEL_52;
          return v39;
        }
      }
      else
      {
        if ( (v31 & 1) != 0 )
        {
          v33 = (unsigned __int8 *)*((_QWORD *)v27 + 2);
          v34 = *((_QWORD *)v27 + 1);
          if ( !v34 )
            goto LABEL_51;
        }
        else
        {
          v33 = v27 + 1;
          v34 = v31 >> 1;
          if ( !v34 )
            goto LABEL_51;
        }
        if ( (__int64)v49 >= v34 )
        {
          v35 = *v33;
          v28 = (size_t)v49;
          v36 = s;
          do
          {
            v28 = v28 - v34 + 1;
            if ( !v28 )
              break;
            v37 = (char *)memchr(v36, v35, v28);
            if ( !v37 )
              break;
            v38 = v37;
            if ( !memcmp(v37, v33, v34) )
            {
              if ( v38 == v50 || v38 - (_BYTE *)s == -1 )
                break;
              goto LABEL_51;
            }
            v36 = v38 + 1;
            v28 = v50 - (_BYTE *)v36;
          }
          while ( v50 - (_BYTE *)v36 >= v34 );
        }
      }
      if ( !v41 || (++v30, v30 < v48) )
      {
        v27 += 24;
        if ( v27 != v55 )
          continue;
      }
      break;
    }
  }
  v39 = 0;
  if ( (v43 & 1) != 0 )
LABEL_52:
    operator delete(ptr);
  return v39;
}


// Address: 0x10cd220 | Name: _ZN3RBX10Tattletale14trimWhitespaceERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
__int64 __fastcall RBX::Tattletale::trimWhitespace(__int64 a1, unsigned __int8 *a2)
{
  char v2; // al
  char *v3; // r14
  unsigned __int64 v4; // rbp
  __int64 v5; // rbx
  unsigned __int64 v6; // rcx
  unsigned __int64 v7; // r13
  char *v8; // r12
  const unsigned __int16 *v9; // rax
  __int64 v10; // rbx
  __int64 v11; // rbp
  __int64 v12; // rbx
  unsigned __int64 v13; // r13
  char *v14; // rax
  char *v15; // rdx
  signed __int64 v16; // r14
  __int64 v17; // rcx
  unsigned __int64 v19; // rcx
  __int64 v20; // rdx
  __int64 v21; // rsi
  __int64 v22; // rdi
  __int128 v23; // xmm1
  __int128 v24; // xmm1
  __int128 v25; // xmm1
  __int128 v26; // xmm1
  __int64 v27; // rsi
  __int64 v28; // rdx
  __int128 v29; // xmm1
  unsigned __int64 v30; // [rsp+8h] [rbp-50h]
  char v31; // [rsp+10h] [rbp-48h]
  char *v32; // [rsp+18h] [rbp-40h]

  v2 = *a2;
  v3 = (char *)(a2 + 1);
  v4 = (unsigned __int64)*a2 >> 1;
  v5 = *((_QWORD *)a2 + 2);
  if ( (*a2 & 1) != 0 )
    v3 = (char *)*((_QWORD *)a2 + 2);
  v6 = *((_QWORD *)a2 + 1);
  v7 = v6;
  if ( (v2 & 1) == 0 )
    v7 = (unsigned __int64)*a2 >> 1;
  v8 = v3;
  if ( v7 )
  {
    v30 = *((_QWORD *)a2 + 1);
    v31 = *a2;
    v32 = &v3[v7];
    v9 = *__ctype_b_loc();
    v8 = v3;
    while ( (v9[*v8] & 0x2000) != 0 )
    {
      ++v8;
      if ( !--v7 )
      {
        v8 = v32;
        break;
      }
    }
    v2 = v31;
    v6 = v30;
  }
  v10 = v6 + v5;
  v11 = (__int64)&a2[v4 + 1];
  if ( (v2 & 1) != 0 )
    v11 = v10;
  while ( v3 != (char *)v11 )
  {
    v12 = *(char *)--v11;
    if ( ((*__ctype_b_loc())[v12] & 0x2000) == 0 )
    {
      v3 = (char *)(v11 + 1);
      break;
    }
  }
  *(_OWORD *)a1 = 0;
  *(_QWORD *)(a1 + 16) = 0;
  v13 = v3 - v8;
  if ( (unsigned __int64)(v3 - v8) >= 0xFFFFFFFFFFFFFFF0LL )
  {
    std::__basic_string_common<true>::__throw_length_error(a1);
    JUMPOUT(0x10CD48B);
  }
  if ( v13 > 0x16 )
  {
    v14 = (char *)operator new((v13 + 16) & 0xFFFFFFFFFFFFFFF0LL);
    *(_QWORD *)(a1 + 16) = v14;
    *(_QWORD *)a1 = (v13 + 16) & 0xFFFFFFFFFFFFFFF0LL | 1;
    *(_QWORD *)(a1 + 8) = v13;
    if ( v8 == v3 )
      goto LABEL_27;
LABEL_19:
    if ( v13 < 0x20 || v14 < v3 && v8 < &v3[v14 - v8] )
    {
      v15 = v14;
      goto LABEL_23;
    }
    v19 = v13 & 0xFFFFFFFFFFFFFFE0LL;
    v20 = ((unsigned __int8)(((v13 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3;
    if ( (v13 & 0xFFFFFFFFFFFFFFE0LL) - 32 >= 0x60 )
    {
      v22 = v20 - ((((v13 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1);
      v21 = 0;
      do
      {
        v23 = *(_OWORD *)&v8[v21 + 16];
        *(_OWORD *)&v14[v21] = *(_OWORD *)&v8[v21];
        *(_OWORD *)&v14[v21 + 16] = v23;
        v24 = *(_OWORD *)&v8[v21 + 48];
        *(_OWORD *)&v14[v21 + 32] = *(_OWORD *)&v8[v21 + 32];
        *(_OWORD *)&v14[v21 + 48] = v24;
        v25 = *(_OWORD *)&v8[v21 + 80];
        *(_OWORD *)&v14[v21 + 64] = *(_OWORD *)&v8[v21 + 64];
        *(_OWORD *)&v14[v21 + 80] = v25;
        v26 = *(_OWORD *)&v8[v21 + 112];
        *(_OWORD *)&v14[v21 + 96] = *(_OWORD *)&v8[v21 + 96];
        *(_OWORD *)&v14[v21 + 112] = v26;
        v21 += 128;
        v22 += 4;
      }
      while ( v22 );
      if ( (((unsigned __int8)(((v13 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
        goto LABEL_36;
    }
    else
    {
      v21 = 0;
      if ( (((unsigned __int8)(((v13 & 0xFFFFFFFFFFFFFFE0LL) - 32) >> 5) + 1) & 3) == 0 )
      {
LABEL_36:
        if ( v19 == v13 )
        {
LABEL_25:
          v14 += v13;
          goto LABEL_27;
        }
        v15 = &v14[v19];
        v8 += v19;
LABEL_23:
        v16 = v3 - v8;
        v17 = 0;
        do
        {
          v15[v17] = v8[v17];
          ++v17;
        }
        while ( v16 != v17 );
        goto LABEL_25;
      }
    }
    v27 = v21 + 16;
    v28 = -v20;
    do
    {
      v29 = *(_OWORD *)&v8[v27];
      *(_OWORD *)&v14[v27 - 16] = *(_OWORD *)&v8[v27 - 16];
      *(_OWORD *)&v14[v27] = v29;
      v27 += 32;
      ++v28;
    }
    while ( v28 );
    goto LABEL_36;
  }
  *(_BYTE *)a1 = 2 * v13;
  v14 = (char *)(a1 + 1);
  if ( v8 != v3 )
    goto LABEL_19;
LABEL_27:
  *v14 = 0;
  return a1;
}


// Address: 0x10cd490 | Name: _ZN3RBX10Tattletale13truncateBeginERNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEm
void __fastcall RBX::Tattletale::truncateBegin(std::string *str, std::string::size_type length)
{
  std::string::size_type v2; // rcx
  char *v3; // rcx
  char *v4; // rdx

  v2 = *((_QWORD *)str + 1);
  if ( (*(_BYTE *)str & 1) == 0 )
    v2 = (unsigned __int64)*(unsigned __int8 *)str >> 1;
  if ( v2 > length )
  {
    v3 = (char *)str + 1;
    v4 = (char *)str + ((unsigned __int64)*(unsigned __int8 *)str >> 1) - length + 1;
    if ( (*(_BYTE *)str & 1) != 0 )
    {
      v3 = (char *)*((_QWORD *)str + 2);
      v4 = &v3[*((_QWORD *)str + 1) - length];
    }
    std::string::replace(str, 0, v4 + 1 - v3, "~");
  }
}


// Address: 0x10cd4f0 | Name: _ZN3RBX10Tattletale11truncateEndERNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEm
void __fastcall RBX::Tattletale::truncateEnd(std::string *str, std::string::size_type length)
{
  unsigned __int64 v2; // rax

  v2 = *(unsigned __int8 *)str;
  if ( (v2 & 1) == 0 )
  {
    if ( v2 >> 1 <= length )
      return;
    goto LABEL_5;
  }
  if ( *((_QWORD *)str + 1) > length )
LABEL_5:
    std::string::replace(str, length - 1, -1, "~");
}


// Address: 0x10cd530 | Name: _ZN3RBX10Tattletale8scanTextERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEPKNS_8InstanceEb
bool __fastcall RBX::Tattletale::scanText(const std::string *text, const RBX::Instance *context, bool onRender)
{
  RBX::Time v3; // xmm0_8
  RBX::Instance *parent; // rax
  const RBX::Instance *i; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::ChatService *v8; // r15
  int v9; // edx
  __int128 v11; // [rsp+0h] [rbp-68h] BYREF
  void *v12; // [rsp+10h] [rbp-58h]
  _BYTE v13[16]; // [rsp+18h] [rbp-50h] BYREF
  void *ptr; // [rsp+28h] [rbp-40h]
  _BYTE v15[16]; // [rsp+30h] [rbp-38h] BYREF
  void *v16; // [rsp+40h] [rbp-28h]

  if ( !RBX::DataModel::get(context) )
    return 0;
  v11 = 0;
  v12 = 0;
  if ( `anonymous namespace'::containsBacklistedWordNoLock(text, (std::string *)&v11) )
  {
    v3.sec = RBX::Time::now<(RBX::Time::SampleMethod)2>().sec;
    if ( context )
    {
      parent = context->parent;
      for ( i = context; parent; parent = parent->parent )
        i = parent;
      descriptor = i->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        v8 = RBX::ServiceProvider::create<RBX::ChatService>((const RBX::ServiceProvider *)i);
        if ( v8 )
        {
          RBX::Instance::getFullName((RBX::Instance *)v15);
          std::string::basic_string(v13, *((_QWORD *)context->descriptor + 1));
          RBX::ChatService::reportUnfilteredText(v8, text, &v11, v15, v13, v3.sec);
          if ( (v13[0] & 1) != 0 )
            operator delete(ptr);
          if ( (v15[0] & 1) != 0 )
            operator delete(v16);
        }
      }
    }
  }
  v9 = 0;
  if ( dword_28593F0 <= 0 )
    v9 = dword_2A08A10 + 1;
  if ( !stru_2A088A0.value )
    v9 = dword_2A08A10 + 1;
  if ( dword_2A08A10 + 1 < dword_28593F0 )
    v9 = dword_2A08A10 + 1;
  dword_2A08A10 = v9;
  if ( (v11 & 1) != 0 )
    operator delete(v12);
  return 1;
}


// Address: 0x10cd6f0 | Name: _ZN3RBX10Tattletale28whitelistAnyBlacklistedWordsERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::Tattletale::whitelistAnyBlacklistedWords(const std::string *text)
{
  unsigned __int8 v1; // r12
  unsigned __int64 v2; // rax
  bool v3; // r14
  unsigned int v4; // ebp
  unsigned __int64 v5; // r13
  signed __int64 v6; // rbx
  const unsigned __int16 **v7; // rax
  signed __int64 v8; // rsi
  _BYTE *v9; // rcx
  const unsigned __int16 **v10; // rdx
  _BYTE *v11; // r15
  __int64 v12; // rbx
  _BYTE *v13; // r14
  const unsigned __int16 **v14; // r12
  const __int32_t **v15; // rax
  unsigned __int64 v16; // rax
  unsigned __int8 *v17; // rax
  unsigned __int64 v18; // r15
  unsigned __int8 *v19; // rbx
  _BYTE *v20; // rcx
  unsigned __int64 v21; // r12
  signed __int64 v22; // r12
  signed __int64 v23; // rdx
  unsigned __int8 *v24; // rax
  unsigned __int8 *v25; // r15
  unsigned __int8 *v26; // rbp
  const void *v27; // rbp
  char *v28; // r13
  int v29; // r14d
  size_t v30; // rdx
  char *v31; // rax
  char *v32; // rbp
  boost::unique_lock<boost::shared_mutex> v33; // [rsp+0h] [rbp-88h] BYREF
  unsigned __int8 v34; // [rsp+10h] [rbp-78h] BYREF
  _BYTE s[7]; // [rsp+11h] [rbp-77h] BYREF
  signed __int64 v36; // [rsp+18h] [rbp-70h]
  void *ptr; // [rsp+20h] [rbp-68h]
  void *s2; // [rsp+28h] [rbp-60h]
  _BYTE *v39; // [rsp+30h] [rbp-58h]
  unsigned __int8 *v40; // [rsp+38h] [rbp-50h]
  boost::upgrade_to_unique_lock<boost::shared_mutex> v41; // [rsp+40h] [rbp-48h] BYREF

  std::string::basic_string(&v34, text);
  v1 = v34;
  v2 = (unsigned __int64)v34 >> 1;
  v3 = (v34 & 1) == 0;
  if ( (v34 & 1) != 0 )
    v2 = v36;
  if ( v2 )
  {
    v4 = 1;
    v5 = 0;
    v6 = v36;
    v7 = __ctype_b_loc();
    v8 = v6;
    v9 = s;
    v10 = v7;
    do
    {
      v11 = v9;
      if ( !v3 )
        v11 = ptr;
      v12 = (unsigned __int8)v11[v5];
      if ( ((*v10)[v12] & 0x100) != 0 )
      {
        if ( (unsigned int)(v12 + 128) <= 0x17F )
        {
          v13 = v9;
          v14 = v10;
          v15 = __ctype_tolower_loc();
          v10 = v14;
          v9 = v13;
          LODWORD(v12) = (*v15)[v12];
        }
        v11[v5] = v12;
        v1 = v34;
        v8 = v36;
      }
      v5 = v4;
      v3 = (v1 & 1) == 0;
      v16 = v1 >> 1;
      if ( (v1 & 1) != 0 )
        v16 = v8;
      ++v4;
    }
    while ( v16 > v5 );
  }
  v33.m = &stru_2A088D8;
  v33.is_locked = 0;
  boost::upgrade_lock<boost::shared_mutex>::lock((boost::upgrade_lock<boost::shared_mutex> *)&v33);
  `anonymous namespace'::getNaughtyList();
  v17 = (unsigned __int8 *)xmmword_2A088C0;
  v18 = *(&xmmword_2A088C0 + 1);
  if ( *(&xmmword_2A088C0 + 1) > xmmword_2A088C0 )
  {
    v19 = (unsigned __int8 *)xmmword_2A088C0;
    do
    {
      v20 = s;
      if ( (v34 & 1) != 0 )
        v20 = ptr;
      v21 = *v17;
      v40 = v17;
      if ( (v21 & 1) != 0 )
      {
        s2 = (void *)*((_QWORD *)v19 + 2);
        v22 = *((_QWORD *)v19 + 1);
        if ( !v22 )
          goto LABEL_24;
      }
      else
      {
        s2 = v17 + 1;
        v22 = v21 >> 1;
        if ( !v22 )
        {
LABEL_24:
          v41.source = (boost::upgrade_lock<boost::shared_mutex> *)&v33;
          v41.exclusive = v33;
          if ( v33.is_locked )
          {
            boost::shared_mutex::unlock_upgrade_and_lock(v33.m);
            v18 = *(&xmmword_2A088C0 + 1);
          }
          v33.m = 0;
          v33.is_locked = 0;
          v24 = v19 + 24;
          if ( v19 + 24 == (unsigned __int8 *)v18 )
            goto LABEL_54;
          v25 = (unsigned __int8 *)(v18 - 24);
          do
          {
            if ( (*v19 & 1) != 0 )
            {
              **((_BYTE **)v19 + 2) = 0;
              *((_QWORD *)v19 + 1) = 0;
            }
            else
            {
              *(_WORD *)v19 = 0;
            }
            std::string::reserve(v19, 0);
            *((_QWORD *)v19 + 2) = *((_QWORD *)v19 + 5);
            *(_OWORD *)v19 = *(_OWORD *)(v19 + 24);
            *(_OWORD *)(v19 + 24) = 0;
            *((_QWORD *)v19 + 5) = 0;
            v19 += 24;
          }
          while ( v25 != v19 );
          v24 = (unsigned __int8 *)*(&xmmword_2A088C0 + 1);
          if ( (unsigned __int8 *)*(&xmmword_2A088C0 + 1) != v19 )
          {
LABEL_54:
            do
            {
              v26 = v24 - 24;
              if ( (*(v24 - 24) & 1) != 0 )
                operator delete(*((void **)v24 - 1));
              v24 = v26;
            }
            while ( v19 != v26 );
          }
          *(&xmmword_2A088C0 + 1) = v19;
          boost::upgrade_to_unique_lock<boost::shared_mutex>::~upgrade_to_unique_lock(&v41);
          v18 = *(&xmmword_2A088C0 + 1);
          v17 = v40;
          v19 = v40;
          continue;
        }
      }
      if ( (v34 & 1) != 0 )
      {
        v23 = v36;
        if ( v36 >= v22 )
          goto LABEL_38;
      }
      else
      {
        v23 = (unsigned __int64)v34 >> 1;
        if ( v23 >= v22 )
        {
LABEL_38:
          v27 = v20;
          v28 = &v20[v23];
          v29 = *(unsigned __int8 *)s2;
          v39 = v20;
          do
          {
            v30 = v23 - v22 + 1;
            if ( !v30 )
              break;
            v31 = (char *)memchr(v27, v29, v30);
            if ( !v31 )
              break;
            v32 = v31;
            if ( !memcmp(v31, s2, v22) )
            {
              if ( v32 != v28 && v32 - v39 != -1 )
                goto LABEL_24;
              break;
            }
            v27 = v32 + 1;
            v23 = v28 - (_BYTE *)v27;
          }
          while ( v28 - (_BYTE *)v27 >= v22 );
        }
      }
      v19 += 24;
      v17 = v19;
    }
    while ( v18 > (unsigned __int64)v17 );
  }
  if ( v33.is_locked )
    boost::shared_mutex::unlock_upgrade(v33.m);
  if ( (v34 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x10cda90 | Name: _ZN12_GLOBAL__N_114getNaughtyListEv
std::vector<std::string> *__cdecl `anonymous namespace'::getNaughtyList()
{
  std::vector<std::string> *result; // rax
  __int64 i; // rbp
  std::istream *v2; // rax
  std::istream *v3; // rax
  std::istream *v4; // rax
  std::istream *v5; // rax
  __int128 v6; // [rsp+0h] [rbp-188h] BYREF
  void *ptr; // [rsp+10h] [rbp-178h]
  __int128 v8; // [rsp+20h] [rbp-168h] BYREF
  void *v9; // [rsp+30h] [rbp-158h]
  __int128 v10; // [rsp+40h] [rbp-148h] BYREF
  _QWORD v11[8]; // [rsp+50h] [rbp-138h] BYREF
  __int128 v12; // [rsp+90h] [rbp-F8h]
  void *v13[2]; // [rsp+A0h] [rbp-E8h]
  int v14; // [rsp+B0h] [rbp-D8h]
  _QWORD v15[18]; // [rsp+B8h] [rbp-D0h] BYREF
  int v16; // [rsp+148h] [rbp-40h]

  LOBYTE(result) = byte_2A08A20;
  if ( !(_BYTE)byte_2A08A20 )
  {
    LODWORD(result) = __cxa_guard_acquire(&byte_2A08A20);
    if ( (_DWORD)result )
    {
      v8 = 0;
      v9 = 0;
      for ( i = 0; i != 278; ++i )
        std::string::push_back(
          &v8,
          (unsigned int)(char)(byte_4AD820[i] + ((32897 * ((unsigned int)byte_4AD820[i] + 94)) >> 23) + 94));
      v15[0] = &off_2878EF0;
      v10 = (unsigned __int64)&off_2878EC8;
      std::ios_base::init((std::ios_base *)v15, v11);
      v15[17] = 0;
      v16 = -1;
      *(_QWORD *)&v10 = &off_2878E58;
      v15[0] = off_2878E80;
      std::streambuf::basic_streambuf(v11);
      v11[0] = &off_28753A8;
      *(_OWORD *)v13 = 0;
      v12 = 0;
      v14 = 8;
      std::stringbuf::str((std::stringbuf *)v11, (const std::stringbuf::string_type *)&v8);
      v6 = 0;
      ptr = 0;
      while ( 1 )
      {
        v2 = std::getline<char,std::char_traits<char>,std::allocator<char>>(
               (std::istream *)&v10,
               (std::string *)&v6,
               10);
        if ( (*((_BYTE *)v2 + *(_QWORD *)(*(_QWORD *)v2 - 24LL) + 32) & 5) != 0 )
          break;
        if ( *(&xmmword_2A088C0 + 1) == qword_2A088D0 )
        {
          std::vector<std::string>::__push_back_slow_path<std::string const&>(
            (std::vector<std::string> *)&xmmword_2A088C0,
            (const std::string *)&v6);
          if ( stru_2A08888.value )
            goto LABEL_12;
        }
        else
        {
          std::string::basic_string(*(&xmmword_2A088C0 + 1), &v6);
          *(&xmmword_2A088C0 + 1) += 24LL;
          if ( stru_2A08888.value )
          {
LABEL_12:
            while ( 1 )
            {
              v3 = std::getline<char,std::char_traits<char>,std::allocator<char>>(
                     (std::istream *)&v10,
                     (std::string *)&v6,
                     10);
              if ( (*((_BYTE *)v3 + *(_QWORD *)(*(_QWORD *)v3 - 24LL) + 32) & 5) != 0 )
                goto LABEL_27;
              if ( *(&xmmword_2A088C0 + 1) == qword_2A088D0 )
              {
                std::vector<std::string>::__push_back_slow_path<std::string const&>(
                  (std::vector<std::string> *)&xmmword_2A088C0,
                  (const std::string *)&v6);
                if ( stru_2A08888.value )
                  goto LABEL_17;
              }
              else
              {
                std::string::basic_string(*(&xmmword_2A088C0 + 1), &v6);
                *(&xmmword_2A088C0 + 1) += 24LL;
                if ( stru_2A08888.value )
                {
LABEL_17:
                  while ( 1 )
                  {
                    v4 = std::getline<char,std::char_traits<char>,std::allocator<char>>(
                           (std::istream *)&v10,
                           (std::string *)&v6,
                           10);
                    if ( (*((_BYTE *)v4 + *(_QWORD *)(*(_QWORD *)v4 - 24LL) + 32) & 5) != 0 )
                      goto LABEL_27;
                    if ( *(&xmmword_2A088C0 + 1) == qword_2A088D0 )
                    {
                      std::vector<std::string>::__push_back_slow_path<std::string const&>(
                        (std::vector<std::string> *)&xmmword_2A088C0,
                        (const std::string *)&v6);
                      if ( stru_2A08888.value )
                      {
                        do
                        {
LABEL_22:
                          v5 = std::getline<char,std::char_traits<char>,std::allocator<char>>(
                                 (std::istream *)&v10,
                                 (std::string *)&v6,
                                 10);
                          if ( (*((_BYTE *)v5 + *(_QWORD *)(*(_QWORD *)v5 - 24LL) + 32) & 5) != 0 )
                            break;
                          if ( *(&xmmword_2A088C0 + 1) == qword_2A088D0 )
                          {
                            std::vector<std::string>::__push_back_slow_path<std::string const&>(
                              (std::vector<std::string> *)&xmmword_2A088C0,
                              (const std::string *)&v6);
                          }
                          else
                          {
                            std::string::basic_string(*(&xmmword_2A088C0 + 1), &v6);
                            *(&xmmword_2A088C0 + 1) += 24LL;
                          }
                        }
                        while ( !stru_2A08888.value );
                        goto LABEL_27;
                      }
                    }
                    else
                    {
                      std::string::basic_string(*(&xmmword_2A088C0 + 1), &v6);
                      *(&xmmword_2A088C0 + 1) += 24LL;
                      if ( stru_2A08888.value )
                        goto LABEL_22;
                    }
                  }
                }
              }
            }
          }
        }
      }
LABEL_27:
      if ( (v6 & 1) != 0 )
        operator delete(ptr);
      *(_QWORD *)&v10 = &off_2878E58;
      v15[0] = off_2878E80;
      v11[0] = &off_28753A8;
      if ( (v12 & 1) != 0 )
        operator delete(v13[0]);
      std::streambuf::~streambuf(v11);
      std::istream::~istream(&v10, off_2878E98);
      std::ios::~ios(v15);
      if ( (v8 & 1) != 0 )
        operator delete(v9);
      __cxa_guard_release(&byte_2A08A20);
    }
  }
  return result;
}


// Address: 0x10ce060 | Name: _GLOBAL__sub_I_Tattletale.cpp
void __cdecl GLOBAL__sub_I_Tattletale_cpp()
{
  qword_2A08850 = (__int64)boost::system::generic_category();
  qword_2A08858 = (__int64)boost::system::generic_category();
  qword_2A08860 = (__int64)boost::system::system_category();
  dword_2A08868 = FLog::RegisterInt(
                    "TattletaleReportToRCCCooldownSeconds",
                    &dword_28593C8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08870.value = 0;
  stru_2A08870.name = "TattletaleUseStrstr";
  dword_2A08880 = FLog::RegisterFlag("TattletaleUseStrstr", &stru_2A08870, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08888.value = 0;
  stru_2A08888.name = "TattletaleUseOriginalWordList";
  dword_2A08898 = FLog::RegisterFlag("TattletaleUseOriginalWordList", &stru_2A08888, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A088A0.value = 0;
  stru_2A088A0.name = (char *)&stru_3FD3B6.weight + 2;
  dword_2A088B0 = FLog::RegisterFlag(
                    (const char *)&stru_3FD3B6.weight + 2,
                    &stru_2A088A0,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A088B4 = FLog::RegisterInt("TattletaleShuffleCount", &dword_28593F0, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A088B8 = FLog::RegisterInt("TattletaleCheckWordCount", &dword_2859400, FastVarType::FASTVARTYPE_DYNAMIC);
  xmmword_2A088C0 = 0;
  qword_2A088D0 = 0;
  __cxa_atexit((void (*)(void *))std::__vector_base<std::string>::~__vector_base, &xmmword_2A088C0, &dso_handle);
  boost::shared_mutex::shared_mutex(&stru_2A088D8);
  __cxa_atexit((void (*)(void *))boost::shared_mutex::~shared_mutex, &stru_2A088D8, &dso_handle);
}


