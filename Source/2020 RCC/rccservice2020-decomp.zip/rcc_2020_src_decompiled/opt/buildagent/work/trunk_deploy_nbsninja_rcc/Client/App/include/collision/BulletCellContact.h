// Address: 0x1df1410 | Name: _ZNK3RBX9Collision17BulletCellContact14getContactTypeEv
RBX::Collision::Contact::ContactType __fastcall RBX::Collision::BulletCellContact::getContactType(
        const RBX::Collision::BulletCellContact *this)
{
  return RBX::Collision::Contact::ContactType::Contact_Cell;
}


