// Address: 0x10e4790 | Name: _ZN3RBX5HUMAN13HumanoidState19setTorsoHasBuoyancyEb
void __fastcall RBX::HUMAN::HumanoidState::setTorsoHasBuoyancy(RBX::HUMAN::HumanoidState *this, bool value)
{
  *((_BYTE *)this + 280) = value;
}


// Address: 0x10e47a0 | Name: _ZN3RBX5HUMAN13HumanoidState21setLeftLegHasBuoyancyEb
void __fastcall RBX::HUMAN::HumanoidState::setLeftLegHasBuoyancy(RBX::HUMAN::HumanoidState *this, bool value)
{
  *((_BYTE *)this + 281) = value;
}


// Address: 0x10e47b0 | Name: _ZN3RBX5HUMAN13HumanoidState22setRightLegHasBuoyancyEb
void __fastcall RBX::HUMAN::HumanoidState::setRightLegHasBuoyancy(RBX::HUMAN::HumanoidState *this, bool value)
{
  *((_BYTE *)this + 282) = value;
}


// Address: 0x10e4910 | Name: _ZN3RBX5HUMAN13HumanoidState15ladderCheckRateEv
int __fastcall RBX::HUMAN::HumanoidState::ladderCheckRate(RBX::HUMAN::HumanoidState *this)
{
  return 2;
}


// Address: 0x10e4920 | Name: _ZN3RBX5HUMAN13HumanoidState10onStepImplEv
void __fastcall RBX::HUMAN::HumanoidState::onStepImpl(RBX::HUMAN::HumanoidState *this)
{
  ;
}


// Address: 0x10e4930 | Name: _ZN3RBX5HUMAN13HumanoidState19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::HumanoidState::onSimulatorStepImpl(
        RBX::HUMAN::HumanoidState *this,
        double a2,
        float stepDt)
{
  ;
}


// Address: 0x10e4940 | Name: _ZNK3RBX5HUMAN13HumanoidState17headShouldCollideEv
bool __fastcall RBX::HUMAN::HumanoidState::headShouldCollide(const RBX::HUMAN::HumanoidState *this)
{
  return 1;
}


// Address: 0x10e4950 | Name: _ZNK3RBX5HUMAN13HumanoidState18torsoShouldCollideEv
bool __fastcall RBX::HUMAN::HumanoidState::torsoShouldCollide(const RBX::HUMAN::HumanoidState *this)
{
  return 1;
}


// Address: 0x10e4960 | Name: _ZNK3RBX5HUMAN13HumanoidState14enableAutoJumpEv
bool __fastcall RBX::HUMAN::HumanoidState::enableAutoJump(const RBX::HUMAN::HumanoidState *this)
{
  return 1;
}


// Address: 0x10e4970 | Name: j__ZN3RBX5HUMAN13HumanoidState12preStepFloorEv
// attributes: thunk
void __fastcall RBX::HUMAN::HumanoidState::preStepFloor(RBX::HUMAN::HumanoidState *this)
{
  _ZN3RBX5HUMAN13HumanoidState12preStepFloorEv(this);
}


// Address: 0x10e4980 | Name: _ZNK3RBX5HUMAN13HumanoidState26getYAxisRotationalVelocityEv
float __fastcall RBX::HUMAN::HumanoidState::getYAxisRotationalVelocity(const RBX::HUMAN::HumanoidState *this)
{
  return 0.0;
}


