// Address: 0x10acc90 | Name: _ZN3RBX20HumanoidAssetSwapper12AssetTrackerD2Ev
void __fastcall RBX::HumanoidAssetSwapper::AssetTracker::~AssetTracker(RBX::HumanoidAssetSwapper::AssetTracker *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,long> >,RBX::Instance *,long,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,boost::weak_ptr<RBX::Instance> > >,RBX::Instance *,boost::weak_ptr<RBX::Instance>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::bucket_pointer v5; // r15
  size_t v6; // r12
  boost::unordered::detail::ptr_bucket *v7; // rbx
  volatile signed __int32 *v8; // rdi

  buckets = this->instanceToAsset.table_.buckets_;
  if ( buckets )
  {
    if ( this->instanceToAsset.table_.size_ )
    {
      bucket_count = this->instanceToAsset.table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->instanceToAsset.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->instanceToAsset.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->instanceToAsset.table_.max_load_ = 0;
  }
  v5 = this->instanceToWeakPointer.table_.buckets_;
  if ( v5 )
  {
    if ( this->instanceToWeakPointer.table_.size_ )
    {
      v6 = this->instanceToWeakPointer.table_.bucket_count_;
      v7 = v5[v6].next_;
      do
      {
        v5[v6] = (boost::unordered::detail::ptr_bucket)v7->next_;
        v8 = (volatile signed __int32 *)v7[4].next_;
        if ( v8 && !_InterlockedSub(v8 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
        operator delete(v7);
        --this->instanceToWeakPointer.table_.size_;
        v7 = v5[v6].next_;
      }
      while ( v7 );
      v5 = this->instanceToWeakPointer.table_.buckets_;
    }
    operator delete(v5);
    *(_OWORD *)&this->instanceToWeakPointer.table_.max_load_ = 0;
  }
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<long const,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *>>>>,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *>>,boost::hash<long>,std::equal_to<long>>>::~table(&this->assetToInstances.table_);
}


