// Address: 0x10cff00 | Name: _ZN3RBX9Collision7Contact7getBodyEi
RBX::Body *__fastcall RBX::Collision::Contact::getBody(RBX::Collision::Contact *this, int i)
{
  return (RBX::Body *)(*((_QWORD *)&this->prim0 + (i != 0)) + 152LL);
}


// Address: 0x10d04a0 | Name: _ZNK3RBX9Collision7Contact14getContactTypeEv
RBX::Collision::Contact::ContactType __fastcall RBX::Collision::Contact::getContactType(
        const RBX::Collision::Contact *this)
{
  return RBX::Collision::Contact::ContactType::Contact_Simple;
}


// Address: 0x10d04b0 | Name: _ZN3RBX9Collision7Contact22invalidateContactCacheEv
void __fastcall RBX::Collision::Contact::invalidateContactCache(RBX::Collision::Contact *this)
{
  ;
}


// Address: 0x10d04c0 | Name: _ZN3RBX9Collision7ContactD2Ev
void __fastcall RBX::Collision::Contact::~Contact(RBX::Collision::Contact *this)
{
  ;
}


// Address: 0x10d04d0 | Name: _ZN3RBX9Collision7ContactD0Ev
void __fastcall __noreturn RBX::Collision::Contact::~Contact(RBX::Collision::Contact *this)
{
  BUG();
}


// Address: 0x1deaf40 | Name: _ZN3RBX9Collision15BallBallContact4ballEi
RBX::Ball *__fastcall RBX::Collision::BallBallContact::ball(RBX::Collision::BallBallContact *this, int i)
{
  return *(RBX::Ball **)(*((_QWORD *)&this->prim0 + (i != 0)) + 144LL);
}


// Address: 0x1deb720 | Name: _ZN3RBX9Collision15BallPolyContact4ballEv
RBX::Ball *__fastcall RBX::Collision::BallPolyContact::ball(RBX::Collision::BallPolyContact *this)
{
  return (RBX::Ball *)*((_QWORD *)this->prim0 + 18);
}


// Address: 0x1deb730 | Name: _ZN3RBX9Collision15BallPolyContact4polyEv
RBX::Poly *__fastcall RBX::Collision::BallPolyContact::poly(RBX::Collision::BallPolyContact *this)
{
  return (RBX::Poly *)*((_QWORD *)this->prim1 + 18);
}


// Address: 0x1deea20 | Name: _ZN3RBX9Collision19BuoyancyBallContact23initializeCrossSectionsEv
void __fastcall RBX::Collision::BuoyancyBallContact::initializeCrossSections(RBX::Collision::BuoyancyBallContact *this)
{
  float v1; // xmm0_4
  float v2; // xmm1_4

  v1 = *(float *)(*((_QWORD *)this->prim1 + 18) + 8LL) * 0.5;
  this->radius = v1;
  v2 = (float)(3.1415927 * v1) * v1;
  this->crossSectionArea = v2;
  this->fullSurfaceArea = v2 * 4.0;
}


// Address: 0x1def140 | Name: _ZN3RBX9Collision18BuoyancyBoxContact23initializeCrossSectionsEv
void __fastcall RBX::Collision::BuoyancyBoxContact::initializeCrossSections(RBX::Collision::BuoyancyBoxContact *this)
{
  float *v1; // rax
  float v2; // xmm0_4
  float v3; // xmm1_4
  float v4; // xmm2_4
  float v5; // xmm3_4
  float v6; // xmm2_4
  float v7; // xmm0_4
  float v8; // xmm2_4

  v1 = (float *)*((_QWORD *)this->prim1 + 18);
  v2 = v1[2];
  v3 = v1[3];
  v4 = v1[4];
  v5 = v3 * v4;
  this->crossSectionSurfaceAreas.x = v3 * v4;
  v6 = v4 * v2;
  this->crossSectionSurfaceAreas.y = v6;
  v7 = v2 * v3;
  this->crossSectionSurfaceAreas.z = v7;
  this->tangentSurfaceAreas.x = (float)(v7 + v6) + (float)(v7 + v6);
  v8 = v6 + v5;
  this->tangentSurfaceAreas.y = (float)(v7 + v5) + (float)(v7 + v5);
  this->tangentSurfaceAreas.z = v8 + v8;
  this->fullSurfaceArea = (float)(v8 + v7) + (float)(v8 + v7);
}


// Address: 0x1def690 | Name: _ZN3RBX9Collision23BuoyancyCylinderContact23initializeCrossSectionsEv
void __fastcall RBX::Collision::BuoyancyCylinderContact::initializeCrossSections(
        RBX::Collision::BuoyancyCylinderContact *this)
{
  float *v1; // rax
  float v2; // xmm0_4
  float v3; // xmm1_4
  float v4; // xmm2_4
  float v5; // xmm3_4
  float v6; // xmm2_4
  float v7; // xmm0_4
  float v8; // xmm2_4

  v1 = (float *)*((_QWORD *)this->prim1 + 18);
  v2 = v1[2];
  v3 = v1[3];
  v4 = v1[4];
  v5 = v3 * v4;
  v6 = v4 * v2;
  this->crossSectionSurfaceAreas.y = v6;
  v7 = v2 * v3;
  this->crossSectionSurfaceAreas.z = v7;
  this->tangentSurfaceAreas.x = (float)(v7 + v6) + (float)(v7 + v6);
  this->tangentSurfaceAreas.y = (float)(v7 + v5) + (float)(v7 + v5);
  v8 = v6 + v5;
  this->tangentSurfaceAreas.z = v8 + v8;
  this->fullSurfaceArea = (float)(v7 + v8) + (float)(v7 + v8);
  this->crossSectionSurfaceAreas.x = (float)(3.1415927 * (float)(v1[3] * 0.5)) * (float)(v1[3] * 0.5);
}


// Address: 0x1defa00 | Name: _ZN3RBX9Collision20BuoyancyWedgeContact23initializeCrossSectionsEv
void __fastcall RBX::Collision::BuoyancyWedgeContact::initializeCrossSections(
        RBX::Collision::BuoyancyWedgeContact *this)
{
  float *v1; // rax
  float v2; // xmm1_4
  float v3; // xmm2_4
  float v4; // xmm3_4
  float v5; // xmm0_4
  float v6; // xmm4_4
  float v7; // xmm5_4
  float v8; // xmm1_4

  v1 = (float *)*((_QWORD *)this->prim1 + 18);
  v2 = v1[2];
  v3 = v1[3];
  v4 = v1[4];
  v5 = (float)(v3 * v4) * 0.5;
  this->crossSectionSurfaceAreas.x = v5;
  v6 = v2 * v4;
  this->crossSectionSurfaceAreas.y = v2 * v4;
  v7 = v2 * v3;
  this->crossSectionSurfaceAreas.z = v2 * v3;
  v8 = (float)((float)(v2 * v3) + (float)(v2 * v4)) + (float)(fsqrt((float)(v4 * v4) + (float)(v3 * v3)) * v2);
  this->tangentSurfaceAreas.x = v8;
  this->tangentSurfaceAreas.y = (float)(v7 + v5) + (float)(v7 + v5);
  this->tangentSurfaceAreas.z = (float)(v6 + v5) + (float)(v6 + v5);
  this->fullSurfaceArea = (float)(v5 + v5) + v8;
}


// Address: 0x1defb50 | Name: _ZN3RBX9Collision26BuoyancyCornerWedgeContact23initializeCrossSectionsEv
void __fastcall RBX::Collision::BuoyancyCornerWedgeContact::initializeCrossSections(
        RBX::Collision::BuoyancyCornerWedgeContact *this)
{
  float *v1; // rax
  float v2; // xmm0_4
  float v3; // xmm2_4
  float v4; // xmm1_4
  float v5; // xmm4_4
  float v6; // xmm5_4
  float v7; // xmm3_4

  v1 = (float *)*((_QWORD *)this->prim1 + 18);
  v2 = v1[2];
  v3 = v1[3];
  v4 = v1[4];
  v5 = (float)(v3 * v4) * 0.5;
  this->crossSectionSurfaceAreas.x = v5;
  this->crossSectionSurfaceAreas.y = v2 * v4;
  v6 = (float)(v2 * v3) * 0.5;
  this->crossSectionSurfaceAreas.z = v6;
  this->tangentSurfaceAreas.x = (float)((float)(v2 * v4) + v6) + (float)((float)(v2 * v4) + v6);
  v7 = (float)(v2 * v4) + v5;
  this->tangentSurfaceAreas.y = (float)(v6 + v5) + (float)(v6 + v5);
  this->tangentSurfaceAreas.z = v7 + v7;
  this->fullSurfaceArea = (float)((float)(v7 + v6) + (float)(fsqrt((float)(v4 * v4) + (float)(v3 * v3)) * v2))
                        + (float)(fsqrt((float)(v2 * v2) + (float)(v3 * v3)) * v4);
}


// Address: 0x1df0750 | Name: _ZN3RBX9Collision16BallBlockContact8ballPrimEv
RBX::Primitive *__fastcall RBX::Collision::BallBlockContact::ballPrim(RBX::Collision::BallBlockContact *this)
{
  return this->prim0;
}


// Address: 0x1df0760 | Name: _ZN3RBX9Collision16BallBlockContact9blockPrimEv
RBX::Primitive *__fastcall RBX::Collision::BallBlockContact::blockPrim(RBX::Collision::BallBlockContact *this)
{
  return this->prim1;
}


// Address: 0x1df0770 | Name: _ZN3RBX9Collision16BallBlockContact4ballEv
RBX::Ball *__fastcall RBX::Collision::BallBlockContact::ball(RBX::Collision::BallBlockContact *this)
{
  return (RBX::Ball *)*((_QWORD *)this->prim0 + 18);
}


// Address: 0x1df0780 | Name: _ZN3RBX9Collision16BallBlockContact5blockEv
RBX::Block *__fastcall RBX::Collision::BallBlockContact::block(RBX::Collision::BallBlockContact *this)
{
  return (RBX::Block *)*((_QWORD *)this->prim1 + 18);
}


// Address: 0x1e04fe0 | Name: _ZN3RBX9Collision17BlockBlockContact5blockEi
RBX::Block *__fastcall RBX::Collision::BlockBlockContact::block(RBX::Collision::BlockBlockContact *this, int i)
{
  return *(RBX::Block **)(*((_QWORD *)&this->prim0 + (i != 0)) + 144LL);
}


// Address: 0x1e086a0 | Name: _ZN3RBX9Collision21BlockBlockContact_New5blockEi
RBX::Block *__fastcall RBX::Collision::BlockBlockContact_New::block(RBX::Collision::BlockBlockContact_New *this, int i)
{
  return *(RBX::Block **)(*((_QWORD *)&this->prim0 + (i != 0)) + 144LL);
}


// Address: 0x1e29690 | Name: _ZNK3RBX11ContactList7getNextEPKNS_9PrimitiveEPNS_9Collision7ContactE
RBX::Collision::Contact *__fastcall RBX::ContactList::getNext(
        const RBX::ContactList *this,
        const RBX::Primitive *p,
        RBX::Collision::Contact *c)
{
  unsigned __int64 v3; // rax
  __int64 v4; // rcx

  v3 = (unsigned int)(*(&c->index0 + (c->prim0 != p)) + 1);
  v4 = *((_QWORD *)this + 1);
  if ( (*((_QWORD *)this + 2) - v4) >> 4 <= v3 )
    return 0;
  else
    return *(RBX::Collision::Contact **)(v4 + 16 * v3);
}


// Address: 0x1e29730 | Name: _ZN3RBX11ContactList13removeContactEPNS_9Collision7ContactE
void __fastcall RBX::ContactList::removeContact(RBX::ContactList *this, RBX::Collision::Contact *c)
{
  int v2; // r8d
  __int64 v3; // rdx
  __int64 v4; // rax
  __int64 v5; // rcx
  __int64 v6; // r9
  __int64 v7; // rax
  RBX::Primitive *v8; // rdx

  v2 = *(&c->index0 + (c->prim0 != *(RBX::Primitive **)this));
  v3 = *((_QWORD *)this + 1);
  v4 = *((_QWORD *)this + 2);
  v5 = *(_QWORD *)(v4 - 16);
  v6 = *(_QWORD *)(v4 - 8);
  v7 = 16LL * v2;
  *(_QWORD *)(v3 + v7) = v5;
  *(_QWORD *)(v3 + v7 + 8) = v6;
  *((_QWORD *)this + 2) -= 16LL;
  v8 = *(RBX::Primitive **)this;
  if ( *(_QWORD *)(v5 + 8) == *(_QWORD *)this )
  {
    *(_DWORD *)(v5 + 28) = v2;
    if ( c->prim0 != v8 )
      goto LABEL_3;
  }
  else
  {
    *(_DWORD *)(v5 + 32) = v2;
    if ( c->prim0 != v8 )
    {
LABEL_3:
      c->index1 = -1;
      return;
    }
  }
  c->index0 = -1;
}


// Address: 0x1e29a00 | Name: _ZN3RBX9Primitive17getNextContactNewEPNS_9Collision7ContactE
RBX::Collision::Contact *__fastcall RBX::Primitive::getNextContactNew(
        RBX::Primitive *this,
        RBX::Collision::Contact *prev)
{
  unsigned __int64 v2; // rax
  __int64 v3; // rcx

  v2 = (unsigned int)(*(&prev->index0 + (prev->prim0 != this)) + 1);
  v3 = *((_QWORD *)this + 58);
  if ( (*((_QWORD *)this + 59) - v3) >> 4 <= v2 )
    return 0;
  else
    return *(RBX::Collision::Contact **)(v3 + 16 * v2);
}


// Address: 0x1e29e70 | Name: _ZN3RBX9Primitive13removeContactEPNS_9Collision7ContactE
void __fastcall RBX::Primitive::removeContact(RBX::Collision::Contact *c)
{
  RBX::Primitive *prim0; // rsi
  RBX::Primitive *prim1; // r9
  int v3; // r8d
  __int64 v4; // rcx
  __int64 v5; // rax
  __int64 v6; // rdx
  __int64 v7; // r10
  __int64 v8; // rax
  RBX::Primitive *v9; // rsi
  int *p_index0; // r8
  int *p_index1; // r10
  RBX::Primitive *v12; // rcx
  int *v13; // rax
  __int64 v14; // r11
  __int64 v15; // rax
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // rdx
  __int64 v19; // rsi
  RBX::Primitive *v20; // rax

  prim0 = c->prim0;
  prim1 = c->prim1;
  v3 = *(&c->index0 + (prim0 != *((RBX::Primitive **)prim0 + 57)));
  v4 = *((_QWORD *)prim0 + 58);
  v5 = *((_QWORD *)prim0 + 59);
  v6 = *(_QWORD *)(v5 - 16);
  v7 = *(_QWORD *)(v5 - 8);
  v8 = 16LL * v3;
  *(_QWORD *)(v4 + v8) = v6;
  *(_QWORD *)(v4 + v8 + 8) = v7;
  *((_QWORD *)prim0 + 59) -= 16LL;
  v9 = (RBX::Primitive *)*((_QWORD *)prim0 + 57);
  if ( *(RBX::Primitive **)(v6 + 8) == v9 )
    *(_DWORD *)(v6 + 28) = v3;
  else
    *(_DWORD *)(v6 + 32) = v3;
  p_index0 = &c->index0;
  p_index1 = &c->index1;
  v12 = c->prim0;
  if ( v12 == v9 )
    *p_index0 = -1;
  else
    *p_index1 = -1;
  v13 = &c->index1;
  if ( v12 == *((RBX::Primitive **)prim1 + 57) )
    v13 = &c->index0;
  v14 = *v13;
  v15 = *((_QWORD *)prim1 + 58);
  v16 = *((_QWORD *)prim1 + 59);
  v17 = *(_QWORD *)(v16 - 16);
  v18 = *(_QWORD *)(v16 - 8);
  v19 = 16 * v14;
  *(_QWORD *)(v15 + v19) = v17;
  *(_QWORD *)(v15 + v19 + 8) = v18;
  *((_QWORD *)prim1 + 59) -= 16LL;
  v20 = (RBX::Primitive *)*((_QWORD *)prim1 + 57);
  if ( *(RBX::Primitive **)(v17 + 8) == v20 )
  {
    *(_DWORD *)(v17 + 28) = v14;
    if ( c->prim0 != v20 )
      goto LABEL_11;
  }
  else
  {
    *(_DWORD *)(v17 + 32) = v14;
    if ( c->prim0 != v20 )
    {
LABEL_11:
      *p_index1 = -1;
      return;
    }
  }
  *p_index0 = -1;
}


