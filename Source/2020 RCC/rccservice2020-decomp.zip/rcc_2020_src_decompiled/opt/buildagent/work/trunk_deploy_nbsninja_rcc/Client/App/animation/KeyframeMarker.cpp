// Address: 0x106d4a0 | Name: _ZN3RBX14KeyframeMarker8setValueENSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::KeyframeMarker::setValue(
        RBX::Instance *this,
        unsigned __int8 *a2,
        __int64 a3,
        __int64 a4,
        size_t a5,
        const void *a6)
{
  RBX::Instance *v7; // r12
  unsigned __int64 v8; // rcx
  void *v9; // rax
  size_t v10; // rdx
  unsigned __int64 v11; // rsi
  unsigned __int64 v12; // rdi
  const void *v13; // rsi
  RBX::Keyframe *parent; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v17; // rbx
  RBX::Reflection::ClassDescriptor *v18; // rax

  v7 = this;
  v8 = *((unsigned __int8 *)this + 128);
  v9 = (void *)(v8 >> 1);
  v10 = v8 >> 1;
  if ( (v8 & 1) != 0 )
    v10 = *((_QWORD *)this + 17);
  v11 = *a2;
  if ( (v11 & 1) != 0 )
    v12 = *((_QWORD *)a2 + 1);
  else
    v12 = v11 >> 1;
  if ( v10 == v12 )
  {
    if ( (v11 & 1) != 0 )
      v13 = (const void *)*((_QWORD *)a2 + 2);
    else
      v13 = a2 + 1;
    if ( (v8 & 1) != 0 )
    {
      if ( !v10 || !memcmp(v7[1].weak_this_.pn.pi_, v13, v10) )
        return;
    }
    else
    {
      if ( !v10 )
        return;
      v8 = 0;
      while ( 1 )
      {
        LODWORD(v10) = *((unsigned __int8 *)&v7[1]._vptr$EventSource + v8 + 1);
        if ( (_BYTE)v10 != *((_BYTE *)v13 + v8) )
          break;
        if ( v9 == (void *)++v8 )
          return;
      }
    }
  }
  std::string::operator=((soap *)&v7[1], (int)a2, v10, (void *)v8, a5, a6);
  RBX::Instance::raisePropertyChanged(v7, &stru_2A04BF0);
  while ( 1 )
  {
    parent = (RBX::Keyframe *)v7->parent;
    if ( !parent )
      break;
    descriptor = parent->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      RBX::Keyframe::invalidate(parent);
      return;
    }
    v7 = v7->parent;
    if ( v7 )
    {
      v17 = v7->descriptor;
      v18 = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)v17 + 363) - (unsigned int)*((unsigned __int16 *)v18 + 363) <= *((unsigned __int16 *)v18
                                                                                                + 364) )
        continue;
    }
    return;
  }
}


// Address: 0x106d5f0 | Name: _ZN3RBX14KeyframeMarkerC2Ev
void __fastcall RBX::KeyframeMarker::KeyframeMarker(RBX::KeyframeMarker *this)
{
  char v1; // [rsp+8h] [rbp-30h] BYREF
  char v2[15]; // [rsp+9h] [rbp-2Fh] BYREF
  void *ptr; // [rsp+18h] [rbp-20h]

  RBX::Instance::Instance((RBX::Instance *)this);
  *(_QWORD *)this = &off_28915D8;
  *((_QWORD *)this + 3) = Class_getDescriptorPtr(this);
  *(_QWORD *)this = &off_28912A8;
  *((_OWORD *)this + 8) = 0;
  *((_QWORD *)this + 18) = 0;
  *((_BYTE *)this + 129) = 0;
  ptr = 0;
  v1 = 28;
  strcpy(v2, "KeyframeMarker");
  RBX::Instance::setName((RBX::Instance *)this, (const std::string *)&v1);
  if ( (v1 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x106d6e0 | Name: _ZN3RBX14KeyframeMarker10invalidateEv
void __fastcall RBX::KeyframeMarker::invalidate(RBX::KeyframeMarker *this)
{
  RBX::Keyframe *v2; // r14
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v5; // r14
  RBX::Reflection::ClassDescriptor *v6; // rax

  while ( 1 )
  {
    v2 = (RBX::Keyframe *)*((_QWORD *)this + 11);
    if ( !v2 )
      break;
    descriptor = v2->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      RBX::Keyframe::invalidate(v2);
      return;
    }
    this = (RBX::KeyframeMarker *)*((_QWORD *)this + 11);
    if ( this )
    {
      v5 = *((_QWORD *)this + 3);
      v6 = Class_getDescriptorPtr(0);
      if ( *(unsigned __int16 *)(v5 + 726) - (unsigned int)*((unsigned __int16 *)v6 + 363) <= *((unsigned __int16 *)v6
                                                                                              + 364) )
        continue;
    }
    return;
  }
}


// Address: 0x106d770 | Name: _ZN3RBX14KeyframeMarker18findKeyframeParentEv
RBX::Keyframe *__fastcall RBX::KeyframeMarker::findKeyframeParent(__int64 a1)
{
  __int64 v2; // r14
  __int64 v3; // r15
  __int64 v4; // r12
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v6; // r15
  RBX::Reflection::ClassDescriptor *v7; // rax

  v2 = 0;
  while ( 1 )
  {
    v3 = *(_QWORD *)(a1 + 88);
    if ( !v3 )
      break;
    v4 = *(_QWORD *)(v3 + 24);
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *(unsigned __int16 *)(v4 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      return (RBX::Keyframe *)v3;
    a1 = *(_QWORD *)(a1 + 88);
    if ( a1 )
    {
      v6 = *(_QWORD *)(a1 + 24);
      v7 = Class_getDescriptorPtr(0);
      if ( *(unsigned __int16 *)(v6 + 726) - (unsigned int)*((unsigned __int16 *)v7 + 363) <= *((unsigned __int16 *)v7
                                                                                              + 364) )
        continue;
    }
    return (RBX::Keyframe *)v2;
  }
  return (RBX::Keyframe *)v2;
}


// Address: 0x106d800 | Name: _Z22Class_getDescriptorPtrPN3RBX14KeyframeMarkerE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::KeyframeMarker *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A04C48;
  if ( !qword_2A04C48 )
  {
    if ( !(_BYTE)byte_2A04F90 )
    {
      if ( __cxa_guard_acquire(&byte_2A04F90) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A04C50,
          v2,
          "KeyframeMarker",
          0,
          attributes,
          RBX::Security::Permissions::None,
          &dword_2A04350);
        stru_2A04F88._vptr$ICreator = (int (**)(void))&off_2891428;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A04C58, &stru_2A04F88);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::KeyframeMarker,true>::~ClassRegistrar,
          &unk_2A04C50,
          &dso_handle);
        __cxa_guard_release(&byte_2A04F90);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A04C50;
    qword_2A04C48 = (RBX::Reflection::ClassDescriptor *)&unk_2A04C50;
  }
  return result;
}


// Address: 0x106d960 | Name: _Z16Class_getNamePtrPN3RBX14KeyframeMarkerE
const RBX::Name *__fastcall Class_getNamePtr(RBX::KeyframeMarker *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A04F98;
  if ( !qword_2A04F98 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A04F98 = result;
  }
  return result;
}


// Address: 0x106e0e0 | Name: _GLOBAL__sub_I_KeyframeMarker.cpp
void __cdecl GLOBAL__sub_I_KeyframeMarker_cpp()
{
  RBX::KeyframeMarker *v0; // rdi
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // r14
  char *v2; // rbx
  const RBX::Reflection::Type *v3; // rax
  RBX::Reflection::PropertyDescriptor::Attributes attributes; // [rsp+0h] [rbp-58h]
  RBX::Reflection::PropertyDescriptor::Attributes v5; // [rsp+30h] [rbp-28h] BYREF

  qword_2A04BD8 = (__int64)boost::system::generic_category();
  qword_2A04BE0 = (__int64)boost::system::generic_category();
  qword_2A04BE8 = (__int64)boost::system::system_category();
  DescriptorPtr = Class_getDescriptorPtr(v0);
  v2 = (char *)operator new(0x28u);
  *(_QWORD *)v2 = &off_2891578;
  *(_OWORD *)(v2 + 8) = (unsigned __int64)RBX::KeyframeMarker::getValue;
  *(_OWORD *)(v2 + 24) = (unsigned __int64)RBX::KeyframeMarker::setValue;
  v5.isDeprecated = 0;
  v5.preferred = 0;
  v5.flags = RBX::Reflection::PropertyDescriptor::Functionality::STANDARD;
  v3 = RBX::Reflection::Type::getSingleton<std::string>();
  *(_QWORD *)&attributes.flags = *(_QWORD *)&v5.flags;
  attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v5);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A04BF0,
    DescriptorPtr,
    v3,
    "Value",
    &stru_458781.gap0,
    attributes,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A04BF0._vptr$Descriptor = (int (**)(void))&off_287FD58;
  qword_2A04C40 = (__int64)v2;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2) )
    *((_BYTE *)&stru_2A04BF0.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A04BF0._vptr$Descriptor + 3))(&stru_2A04BF0) )
    *((_BYTE *)&stru_2A04BF0.security + 4) &= 0xF3u;
  stru_2A04BF0._vptr$Descriptor = (int (**)(void))&off_28914B8;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A04BF0,
    &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_0);
}


