// Address: 0x15d0c10 | Name: _ZN3RBX7GuiItem12disabledFillEv
const RBX::Color4 *__cdecl RBX::GuiItem::disabledFill()
{
  if ( !(_BYTE)byte_2A30AD0 && __cxa_guard_acquire(&byte_2A30AD0) )
  {
    stru_2A30AC0 = (RBX::Color4)xmmword_3E67E0;
    __cxa_guard_release(&byte_2A30AD0);
  }
  return &stru_2A30AC0;
}


// Address: 0x15d0c50 | Name: _ZN3RBX7GuiItem10menuSelectEv
const RBX::Color4 *__cdecl RBX::GuiItem::menuSelect()
{
  if ( !(_BYTE)byte_2A30AF0 && __cxa_guard_acquire(&byte_2A30AF0) )
  {
    stru_2A30AE0 = (RBX::Color4)xmmword_3E85A0;
    __cxa_guard_release(&byte_2A30AF0);
  }
  return &stru_2A30AE0;
}


// Address: 0x15d0c90 | Name: _ZN3RBX7GuiItem19translucentBackdropEv
const RBX::Color4 *__cdecl RBX::GuiItem::translucentBackdrop()
{
  if ( !(_BYTE)byte_2A30B10 && __cxa_guard_acquire(&byte_2A30B10) )
  {
    stru_2A30B00 = (RBX::Color4)xmmword_3E50F0;
    __cxa_guard_release(&byte_2A30B10);
  }
  return &stru_2A30B00;
}


// Address: 0x15d0cd0 | Name: _ZN3RBX7GuiItemC2Ev
void __fastcall RBX::GuiItem::GuiItem(RBX::GuiItem *this)
{
  *(_OWORD *)((char *)this + 8) = 0;
  *(_QWORD *)this = off_28C93F0;
  *(_OWORD *)((char *)this + 56) = 0;
  *(_OWORD *)((char *)this + 72) = 0;
  *(_OWORD *)((char *)this + 40) = 0;
  *(_OWORD *)((char *)this + 24) = 0;
  *((_BYTE *)this + 64) = 30;
  strcpy((char *)this + 65, "Unnamed GuiItem");
  *(_OWORD *)((char *)this + 88) = 0;
  *((_QWORD *)this + 13) = 0;
  if ( byte_2A349E0 )
    FLog::FastLog(byte_2A349E0, "GuiItem created: %p", this);
}


// Address: 0x15d0e60 | Name: _ZN3RBX7GuiItemD0Ev
void __fastcall RBX::GuiItem::~GuiItem(RBX::GuiItem *this)
{
  RBX::GuiItem::~GuiItem(this);
  operator delete(this);
}


// Address: 0x15d0e80 | Name: _ZN3RBX7GuiItem12getGuiParentEv
RBX::GuiItem *__fastcall RBX::GuiItem::getGuiParent(RBX::GuiItem *this)
{
  volatile signed __int32 *v1; // rbx
  signed __int32 v2; // eax
  RBX::GuiItem *v3; // r14
  signed __int32 v4; // ett

  v1 = (volatile signed __int32 *)*((_QWORD *)this + 4);
  if ( !v1 )
    return 0;
  v2 = *((_DWORD *)v1 + 2);
  v3 = 0;
  while ( v2 )
  {
    v4 = v2;
    v2 = _InterlockedCompareExchange(v1 + 2, v2 + 1, v2);
    if ( v4 == v2 )
    {
      v3 = (RBX::GuiItem *)*((_QWORD *)this + 3);
      if ( !_InterlockedSub(v1 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
        if ( !_InterlockedSub(v1 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
      }
      return v3;
    }
  }
  return v3;
}


// Address: 0x15d0ef0 | Name: _ZNK3RBX7GuiItem12getGuiParentEv
const RBX::GuiItem *__fastcall RBX::GuiItem::getGuiParent(const RBX::GuiItem *this)
{
  volatile signed __int32 *v1; // rbx
  signed __int32 v2; // eax
  const RBX::GuiItem *v3; // r14
  signed __int32 v4; // ett

  v1 = (volatile signed __int32 *)*((_QWORD *)this + 4);
  if ( !v1 )
    return 0;
  v2 = *((_DWORD *)v1 + 2);
  v3 = 0;
  while ( v2 )
  {
    v4 = v2;
    v2 = _InterlockedCompareExchange(v1 + 2, v2 + 1, v2);
    if ( v4 == v2 )
    {
      v3 = (const RBX::GuiItem *)*((_QWORD *)this + 3);
      if ( !_InterlockedSub(v1 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
        if ( !_InterlockedSub(v1 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 24LL))(v1);
      }
      return v3;
    }
  }
  return v3;
}


// Address: 0x15d0f60 | Name: _ZN3RBX7GuiItem10getGuiItemEi
RBX::GuiItem *__fastcall RBX::GuiItem::getGuiItem(RBX::GuiItem *this, int index)
{
  return *(RBX::GuiItem **)(*((_QWORD *)this + 5) + 16LL * index);
}


// Address: 0x15d0f70 | Name: _ZNK3RBX7GuiItem10getGuiItemEi
const RBX::GuiItem *__fastcall RBX::GuiItem::getGuiItem(const RBX::GuiItem *this, int index)
{
  return *(const RBX::GuiItem **)(*((_QWORD *)this + 5) + 16LL * index);
}


// Address: 0x15d0f90 | Name: _ZN3RBX7GuiItem20onDescendantRemovingERKN5boost10shared_ptrIS0_EE
void __fastcall RBX::GuiItem::onDescendantRemoving(RBX::GuiItem *this, const boost::shared_ptr<RBX::GuiItem> *item)
{
  void (__fastcall ***px)(_QWORD); // rdi
  volatile signed __int32 *v4; // rbx
  signed __int32 v5; // eax
  signed __int32 v6; // ett
  __int64 v7; // rdi
  volatile signed __int32 *v8; // rbx

  px = (void (__fastcall ***)(_QWORD))item->px;
  if ( item->px == (boost::shared_ptr<RBX::GuiItem>::element_type *)*((_QWORD *)this + 11) )
  {
    if ( px )
      (**px)(px);
    v8 = (volatile signed __int32 *)*((_QWORD *)this + 12);
    *(_OWORD *)((char *)this + 88) = 0;
    if ( v8 )
    {
      if ( !_InterlockedSub(v8 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
        if ( !_InterlockedSub(v8 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
      }
    }
  }
  v4 = (volatile signed __int32 *)*((_QWORD *)this + 4);
  if ( v4 )
  {
    v5 = *((_DWORD *)v4 + 2);
    while ( v5 )
    {
      v6 = v5;
      v5 = _InterlockedCompareExchange(v4 + 2, v5 + 1, v5);
      if ( v6 == v5 )
      {
        v7 = *((_QWORD *)this + 3);
        if ( v7 )
          (*(void (__fastcall **)(__int64, const boost::shared_ptr<RBX::GuiItem> *))(*(_QWORD *)v7 + 88LL))(v7, item);
        if ( !_InterlockedSub(v4 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
          if ( !_InterlockedSub(v4 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        }
        return;
      }
    }
  }
}


// Address: 0x15d1080 | Name: _ZN3RBX7GuiItem15getRootAncestorEv
RBX::GuiItem *__fastcall RBX::GuiItem::getRootAncestor(RBX::GuiItem *this)
{
  RBX::GuiItem *RootAncestor; // r14
  volatile signed __int32 *v2; // rbx
  signed __int32 v3; // eax
  signed __int32 v4; // ett
  RBX::GuiItem *v5; // rdi

  RootAncestor = this;
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 4);
  if ( v2 )
  {
    v3 = *((_DWORD *)v2 + 2);
    while ( v3 )
    {
      v4 = v3;
      v3 = _InterlockedCompareExchange(v2 + 2, v3 + 1, v3);
      if ( v4 == v3 )
      {
        v5 = (RBX::GuiItem *)*((_QWORD *)this + 3);
        if ( v5 )
          RootAncestor = RBX::GuiItem::getRootAncestor(v5);
        if ( !_InterlockedSub(v2 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
          if ( !_InterlockedSub(v2 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
        }
        return RootAncestor;
      }
    }
  }
  return RootAncestor;
}


// Address: 0x15d1130 | Name: _ZNK3RBX7GuiItem9getMyRectENS_6CanvasE
__m128 __fastcall RBX::GuiItem::getMyRect(const RBX::GuiItem *this, __m128 canvas)
{
  double v3; // [rsp+0h] [rbp-28h]
  __m128 v4; // [rsp+10h] [rbp-18h]

  v3 = *(double *)canvas.m128_u64;
  *(double *)canvas.m128_u64 = (*(double (__fastcall **)(const RBX::GuiItem *))(*(_QWORD *)this + 16LL))(this);
  v4 = canvas;
  (*(void (__fastcall **)(const RBX::GuiItem *, double))(*(_QWORD *)this + 56LL))(this, v3);
  return v4;
}


// Address: 0x15d1170 | Name: _ZN3RBX7GuiItem15processNonFocusERKN5boost10shared_ptrINS_11InputObjectEEE
RBX::GuiResponse *__fastcall RBX::GuiItem::processNonFocus(
        RBX::GuiResponse *__return_ptr retstr,
        RBX::GuiItem *this,
        const boost::shared_ptr<RBX::InputObject> *event)
{
  __int64 v4; // rax
  __int64 v5; // rbx
  unsigned __int64 v6; // r15
  RBX::GuiItem *v7; // r13
  boost::detail::sp_counted_base *pi; // rdi
  void (__fastcall ***v10)(_QWORD); // rdi
  volatile signed __int32 *v11; // r15
  boost::shared_ptr<RBX::GuiItem> v12; // rax
  volatile signed __int32 *v13; // rbx
  __int64 v14; // rbp
  void (__fastcall ***v15)(_QWORD, RBX::GuiItem *, boost::detail::sp_counted_base *); // rdi
  volatile signed __int32 *v16; // rbx
  __int128 v17; // [rsp+0h] [rbp-48h]

  v4 = *((_QWORD *)this + 5);
  if ( *((_QWORD *)this + 6) == v4 )
  {
LABEL_10:
    *(_QWORD *)&retstr->response = 0;
    retstr->mouseWasOver = RBX::GuiResponse::MouseOverType::NOT_MOUSE_OVER;
    retstr->target = 0;
    return retstr;
  }
  v5 = 0;
  v6 = 0;
  while ( 1 )
  {
    v7 = *(RBX::GuiItem **)(v4 + (v5 >> 28));
    if ( v7 )
    {
      if ( v7 != *((RBX::GuiItem **)this + 11) )
        break;
    }
LABEL_9:
    ++v6;
    v4 = *((_QWORD *)this + 5);
    v5 += 0x100000000LL;
    if ( v6 >= (*((_QWORD *)this + 6) - v4) >> 4 )
      goto LABEL_10;
  }
  (*(void (__fastcall **)(RBX::GuiResponse *, RBX::GuiItem *, const boost::shared_ptr<RBX::InputObject> *))(*(_QWORD *)v7 + 64LL))(
    retstr,
    v7,
    event);
  if ( retstr->response != RBX::GuiResponse::ResponseType::SUNK )
  {
    pi = retstr->target.pn.pi_;
    if ( pi && !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    goto LABEL_9;
  }
  v10 = (void (__fastcall ***)(_QWORD))*((_QWORD *)this + 11);
  if ( v10 )
    (**v10)(v10);
  v11 = (volatile signed __int32 *)*((_QWORD *)this + 12);
  *(_OWORD *)((char *)this + 88) = 0;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
  v12 = RBX::shared_from<RBX::GuiItem>(v7);
  v13 = (volatile signed __int32 *)*((_QWORD *)this + 12);
  *(_OWORD *)((char *)this + 88) = v17;
  if ( v13 )
  {
    if ( !_InterlockedSub(v13 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, RBX::GuiItem *, boost::detail::sp_counted_base *))(*(_QWORD *)v13 + 16LL))(
        v13,
        v7,
        v12.pn.pi_);
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
    }
  }
  v14 = *((_QWORD *)this + 11);
  v15 = *(void (__fastcall ****)(_QWORD, RBX::GuiItem *, boost::detail::sp_counted_base *))(v14 + 88);
  if ( v15 )
    (**v15)(v15, v7, v12.pn.pi_);
  v16 = *(volatile signed __int32 **)(v14 + 96);
  *(_OWORD *)(v14 + 88) = 0;
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, RBX::GuiItem *, boost::detail::sp_counted_base *))(*(_QWORD *)v16 + 16LL))(
        v16,
        v7,
        v12.pn.pi_);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  return retstr;
}


// Address: 0x15d13b0 | Name: _ZN3RBX7GuiItem7processERKN5boost10shared_ptrINS_11InputObjectEEE
RBX::GuiResponse *__fastcall RBX::GuiItem::process(
        RBX::GuiResponse *__return_ptr retstr,
        RBX::GuiItem *this,
        const boost::shared_ptr<RBX::InputObject> *event)
{
  __int64 v5; // rdi
  boost::detail::sp_counted_base *v6; // rdi
  void (__fastcall ***v7)(_QWORD); // rdi
  volatile signed __int32 *v8; // r12
  boost::detail::sp_counted_base *pi; // rdi
  __int64 v11; // [rsp+8h] [rbp-40h] BYREF
  RBX::GuiResponse::MouseOverType v12; // [rsp+10h] [rbp-38h]
  boost::weak_ptr<RBX::Instance> v13; // [rsp+18h] [rbp-30h]

  v5 = *((_QWORD *)this + 11);
  if ( !v5 )
    goto LABEL_18;
  if ( !(*(unsigned __int8 (__fastcall **)(__int64))(*(_QWORD *)v5 + 8LL))(v5) )
  {
LABEL_7:
    (*(void (__fastcall **)(__int64 *, _QWORD, const boost::shared_ptr<RBX::InputObject> *))(**((_QWORD **)this + 11)
                                                                                           + 64LL))(
      &v11,
      *((_QWORD *)this + 11),
      event);
    if ( (_DWORD)v11 == 1 )
    {
      retstr->mouseWasOver = v12;
      *(_QWORD *)&retstr->response = v11;
      retstr->target = v13;
      return retstr;
    }
    v7 = (void (__fastcall ***)(_QWORD))*((_QWORD *)this + 11);
    if ( v7 )
      (**v7)(v7);
    v8 = (volatile signed __int32 *)*((_QWORD *)this + 12);
    *(_OWORD *)((char *)this + 88) = 0;
    if ( v8 )
    {
      if ( !_InterlockedSub(v8 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
        if ( !_InterlockedSub(v8 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
      }
    }
    pi = v13.pn.pi_;
    if ( v13.pn.pi_ && !_InterlockedSub(&v13.pn.pi_->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
LABEL_18:
    RBX::GuiItem::processNonFocus(retstr, this, event);
    return retstr;
  }
  RBX::GuiItem::processNonFocus(retstr, this, event);
  if ( retstr->response != RBX::GuiResponse::ResponseType::SUNK )
  {
    v6 = retstr->target.pn.pi_;
    if ( v6 && !_InterlockedSub(&v6->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
    goto LABEL_7;
  }
  return retstr;
}


// Address: 0x15d1500 | Name: _ZNK3RBX7GuiItem7label2dEPNS_5AdornERKNSt3__112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEERKN3G3D6Color4ESF_NS_4Text6XAlignE
void __fastcall RBX::GuiItem::label2d(
        const RBX::GuiItem *this,
        RBX::Adorn *adorn,
        const std::string *label,
        const RBX::Color4 *fill,
        const RBX::Color4 *border,
        RBX::Text::XAlign align)
{
  __m128 v6; // xmm0
  __m128 v7; // xmm1
  unsigned __int64 v12; // rax
  __m128 v13; // xmm0
  float v14; // xmm3_4
  __m128 v15; // xmm0
  double v16; // xmm1_8
  int v17; // eax
  RBX::Vector2 position; // [rsp+0h] [rbp-98h] BYREF
  RBX::Vector2 availableSpace; // [rsp+8h] [rbp-90h] BYREF
  RBX::Rotation2D rotation; // [rsp+10h] [rbp-88h] BYREF
  __m128 v21; // [rsp+30h] [rbp-68h]
  __m128 v22; // [rsp+40h] [rbp-58h]
  RBX::Rect2D clippingRect; // [rsp+58h] [rbp-40h] BYREF

  v12 = *(unsigned __int8 *)label;
  if ( (v12 & 1) == 0 )
  {
    if ( !(v12 >> 1) )
      return;
LABEL_5:
    *(double *)v6.m128_u64 = (*(double (__fastcall **)(RBX::Adorn *))(*(_QWORD *)adorn + 104LL))(adorn);
    v22 = _mm_sub_ps(v7, v6);
    v13.m128_u64[1] = v22.m128_u64[1];
    *(double *)v13.m128_u64 = (*(double (__fastcall **)(const RBX::GuiItem *, double))(*(_QWORD *)this + 16LL))(
                                this,
                                *(double *)v22.m128_u64);
    v21 = v13;
    v13.m128_u64[1] = v22.m128_u64[1];
    *(double *)v13.m128_u64 = (*(double (__fastcall **)(const RBX::GuiItem *, double))(*(_QWORD *)this + 56LL))(
                                this,
                                *(double *)v22.m128_u64);
    v14 = v21.m128_f32[0];
    v15 = _mm_add_ps(v13, v21);
    HIDWORD(v16) = v15.m128_i32[1];
    *(float *)&v16 = v15.m128_f32[0] - v21.m128_f32[0];
    _mm_storel_ps((double *)&position, _mm_mul_ps(_mm_add_ps(v21, v15), *(__m128 *)&stru_3EB1B0.x));
    if ( align )
    {
      if ( align == RBX::Text::XAlign::XALIGN_CENTER )
      {
LABEL_10:
        v17 = (*(__int64 (__fastcall **)(const RBX::GuiItem *, double, double))(*(_QWORD *)this + 32LL))(
                this,
                *(double *)v15.m128_u64,
                v16);
        _mm_storel_ps((double *)&availableSpace, (__m128)0LL);
        clippingRect = (RBX::Rect2D)xmmword_3E7230;
        *(_OWORD *)&rotation.angle.value = xmmword_3E4990;
        rotation.center.y = 0.0;
        RBX::Adorn::drawFont2D(
          adorn,
          label,
          &position,
          (float)v17,
          0,
          fill,
          border,
          RBX::Text::Font::FONT_LEGACY,
          align,
          RBX::Text::YAlign::YALIGN_CENTER,
          &availableSpace,
          &clippingRect,
          &rotation,
          1);
        return;
      }
      *(float *)&v16 = (float)(*(float *)&v16 * 0.1) + v14;
    }
    else
    {
      *(float *)&v16 = (float)(*(float *)&v16 * -0.1) + v15.m128_f32[0];
    }
    position.x = *(float *)&v16;
    goto LABEL_10;
  }
  if ( *((_QWORD *)label + 1) )
    goto LABEL_5;
}


// Address: 0x15d1650 | Name: _ZN3RBX7GuiRootC2Ev
void __fastcall RBX::GuiRoot::GuiRoot(RBX::GuiRoot *this)
{
  RBX::GuiItem::GuiItem(this);
  *(_QWORD *)this = off_28C9480;
  std::string::assign((char *)this + 64, "GuiRoot");
}


// Address: 0x15d16a0 | Name: _ZNK3RBX6Canvas11toPixelSizeERKN3G3D7Vector2E
RBX::Vector2 __fastcall RBX::Canvas::toPixelSize(const RBX::Canvas *this, const RBX::Vector2 *percent)
{
  __m128 x_low; // xmm1
  __m128 y_low; // xmm2
  __m128 v4; // xmm3
  __m128 v5; // xmm5
  __m128 v6; // xmm0

  x_low = (__m128)LODWORD(this->size.x);
  y_low = (__m128)LODWORD(this->size.y);
  v4 = (__m128)0x3F400000u;
  v4.m128_f32[0] = 0.75 * x_low.m128_f32[0];
  v5 = (__m128)0x3FAA3D71u;
  v5.m128_f32[0] = 1.33 * y_low.m128_f32[0];
  v6 = (__m128)_mm_srai_epi32(
                 _mm_slli_epi32(
                   _mm_shuffle_epi32(_mm_cvtsi32_si128(y_low.m128_f32[0] > (float)(0.75 * x_low.m128_f32[0])), 80),
                   0x1Fu),
                 0x1Fu);
  return (RBX::Vector2)_mm_mul_ps(
                         _mm_or_ps(
                           _mm_andnot_ps(v6, _mm_unpacklo_ps(v5, y_low)),
                           _mm_and_ps(_mm_unpacklo_ps(x_low, v4), v6)),
                         _mm_mul_ps((__m128)*(_QWORD *)percent, (__m128)xmmword_3EB1E0)).m128_u64[0];
}


// Address: 0x15d1700 | Name: _ZNK3RBX6Canvas18normalizedFontSizeEi
int __fastcall RBX::Canvas::normalizedFontSize(const RBX::Canvas *this, int fontSize)
{
  __m128 y_low; // xmm3
  __m128 v3; // xmm0
  __m128 v4; // xmm0

  y_low = (__m128)LODWORD(this->size.y);
  v3 = (__m128)0x3F400000u;
  v3.m128_f32[0] = 0.75 * this->size.x;
  v4 = _mm_cmplt_ss(v3, y_low);
  y_low.m128_f32[0] = y_low.m128_f32[0] * 1.33;
  v4.m128_f32[0] = floorf(
                     (float)(COERCE_FLOAT(_mm_andnot_ps(v4, y_low).m128_u32[0] | LODWORD(this->size.x) & v4.m128_i32[0])
                           * (float)fontSize)
                   / 1000.0);
  return (int)(float)(v4.m128_f32[0] + flt_4907B0[v4.m128_f32[0] >= 0.0]);
}


// Address: 0x15d1760 | Name: _ZN3RBX7GuiRoot8render2dEPNS_11LegacyAdornERKN3G3D7Vector2E
void __fastcall RBX::GuiRoot::render2d(RBX::GuiRoot *this, RBX::LegacyAdorn *adorn, const RBX::Vector2 *pos)
{
  __int64 v3; // rax
  __int64 v4; // rcx
  __int64 v7; // rbx
  unsigned __int64 v8; // rbp
  __int64 v9; // rdi

  v3 = *((_QWORD *)this + 5);
  v4 = *((_QWORD *)this + 6);
  if ( v4 != v3 )
  {
    v7 = 0;
    v8 = 0;
    do
    {
      v9 = *(_QWORD *)(v3 + (v7 >> 28));
      if ( v9 )
      {
        (*(void (__fastcall **)(__int64, RBX::LegacyAdorn *, const RBX::Vector2 *))(*(_QWORD *)v9 + 80LL))(
          v9,
          adorn,
          pos);
        v3 = *((_QWORD *)this + 5);
        v4 = *((_QWORD *)this + 6);
      }
      ++v8;
      v7 += 0x100000000LL;
    }
    while ( v8 < (v4 - v3) >> 4 );
  }
}


// Address: 0x15d17e0 | Name: _ZN3RBX13RelativePanel4initERKNS_6LayoutE
void __fastcall RBX::RelativePanel::init(RBX::RelativePanel *this, const RBX::Layout *layout)
{
  std::string::assign((char *)this + 64, "RelativePanel");
  *((_DWORD *)this + 32) = layout->layoutStyle;
  *((_OWORD *)this + 7) = layout->backdropColor;
  *((_DWORD *)this + 34) = layout->xLocation;
  *((_DWORD *)this + 35) = layout->yLocation;
  *((_DWORD *)this + 36) = layout->offset;
}


// Address: 0x15d1840 | Name: _ZN3RBX13RelativePanel8render2dEPNS_11LegacyAdornERKN3G3D7Vector2E
void __fastcall RBX::RelativePanel::render2d(
        RBX::RelativePanel *this,
        RBX::LegacyAdorn *adorn,
        const RBX::Vector2 *pos)
{
  __m128 v3; // xmm0
  __int64 v4; // rax
  float v5; // r15d
  float v6; // r13d
  __int64 v7; // rbp
  unsigned __int64 v8; // r14
  float *v9; // rbx
  float v10; // eax
  float v11; // ecx
  int v12; // edx
  __m128i v13; // xmm1
  __m128i v14; // xmm1
  __m128i v15; // xmm1
  __m128i v16; // xmm1
  float v17; // xmm2_4
  float v18; // xmm3_4
  __m128 v19; // xmm0
  __m128 v20; // xmm1
  RBX::Rect v21; // kr00_16
  const G3D::Color4 *v22; // rax
  double v23; // xmm0_8
  __m128 v24; // xmm1
  __m128 v25; // xmm2
  __m128 v26; // xmm3
  __m128 v27; // xmm4
  __int64 v28; // rax
  __int64 v29; // r13
  unsigned __int64 v30; // rbp
  unsigned int *v31; // rbx
  float v32; // [rsp+Ch] [rbp-8Ch]
  __int64 v33; // [rsp+18h] [rbp-80h] BYREF
  __m128 v34; // [rsp+20h] [rbp-78h]
  RBX::Rect v35; // [rsp+38h] [rbp-60h] BYREF
  RBX::Rect child; // [rsp+48h] [rbp-50h] BYREF
  __m128 v37[4]; // [rsp+58h] [rbp-40h] BYREF

  if ( *((_BYTE *)this + 132) )
  {
    v4 = *((_QWORD *)this + 5);
    v5 = 0.0;
    v6 = 0.0;
    if ( *((_QWORD *)this + 6) != v4 )
    {
      v34.m128_i32[0] = _mm_cvtsi128_si32((__m128i)0LL);
      v7 = 0;
      v5 = 0.0;
      v6 = 0.0;
      v3 = 0;
      v32 = v34.m128_f32[0];
      v8 = 0;
      do
      {
        v9 = *(float **)(v4 + (v7 >> 28));
        if ( v9
          && (*(unsigned __int8 (__fastcall **)(float *, RBX::LegacyAdorn *, const RBX::Vector2 *))(*(_QWORD *)v9 + 40LL))(
               v9,
               adorn,
               pos) )
        {
          v10 = v9[26];
          v11 = v9[27];
          v12 = *((_DWORD *)this + 32);
          if ( v12 == 1 )
          {
            v15 = _mm_cvtsi32_si128(LODWORD(v32));
            v6 = COERCE_FLOAT(_mm_cvtsi128_si32(v15));
            if ( v10 > *(float *)v15.m128i_i32 )
              v6 = v9[26];
            v16 = (__m128i)v34.m128_u32[0];
            v3 = (__m128)_mm_cvtsi32_si128(LODWORD(v6));
            v32 = COERCE_FLOAT(_mm_cvtsi128_si32((__m128i)v3));
            v34.m128_f32[0] = v34.m128_f32[0] + v11;
            *(float *)v16.m128i_i32 = v34.m128_f32[0];
            v5 = COERCE_FLOAT(_mm_cvtsi128_si32(v16));
          }
          else if ( !v12 )
          {
            v13 = _mm_cvtsi32_si128(v34.m128_u32[0]);
            v5 = COERCE_FLOAT(_mm_cvtsi128_si32(v13));
            if ( v11 > *(float *)v13.m128i_i32 )
              v5 = v9[27];
            v14 = (__m128i)LODWORD(v32);
            v3 = (__m128)_mm_cvtsi32_si128(LODWORD(v5));
            v34.m128_i32[0] = _mm_cvtsi128_si32((__m128i)v3);
            v32 = v32 + v10;
            *(float *)v14.m128i_i32 = v32;
            v6 = COERCE_FLOAT(_mm_cvtsi128_si32(v14));
          }
        }
        ++v8;
        v4 = *((_QWORD *)this + 5);
        pos = (const RBX::Vector2 *)0x100000000LL;
        v7 += 0x100000000LL;
      }
      while ( v8 < (*((_QWORD *)this + 6) - v4) >> 4 );
    }
    *(double *)v3.m128_u64 = (*((double (__fastcall **)(RBX::LegacyAdorn *, RBX::LegacyAdorn *, const RBX::Vector2 *))adorn->_vptr$LegacyAdorn
                              + 2))(
                               adorn,
                               adorn,
                               pos);
    child.low = 0;
    child.high.x = v6;
    child.high.y = v5;
    v17 = (float)*((__int16 *)this + 73);
    v18 = v3.m128_f32[0] - (float)*((__int16 *)this + 72);
    v19 = _mm_shuffle_ps(v3, v3, 229);
    v35.low.x = (float)*((__int16 *)this + 72);
    v35.low.y = v17;
    v35.high.x = v18;
    v35.high.y = v19.m128_f32[0] - v17;
    v21 = RBX::Rect::positionChild(
            &v35,
            &child,
            (RBX::Rect::Location)*((_DWORD *)this + 34),
            (RBX::Rect::Location)*((_DWORD *)this + 35));
    *(RBX::Vector2 *)v20.m128_f32 = v21.high;
    *(RBX::Vector2 *)v19.m128_f32 = v21.low;
    v34 = v19;
    _mm_storel_ps((double *)&v33, v19);
    v22 = G3D::Color4::clear();
    if ( *((float *)this + 28) != v22->r
      || *((float *)this + 29) != v22->g
      || *((float *)this + 30) != v22->b
      || (*(_QWORD *)&v23 = *((unsigned int *)this + 31), *(float *)&v23 != v22->a) )
    {
      *(_QWORD *)&v23 = _mm_shuffle_ps(v34, v34, 229).m128_u64[0];
      v24 = (__m128)_mm_cvtsi32_si128(LODWORD(v6));
      v24.m128_f32[0] = v24.m128_f32[0] + v34.m128_f32[0];
      v25 = (__m128)_mm_cvtsi32_si128(LODWORD(v5));
      v25.m128_f32[0] = v25.m128_f32[0] + *(float *)&v23;
      v26 = v24;
      v26.m128_f32[0] = fminf(v24.m128_f32[0], v34.m128_f32[0]);
      v27 = v25;
      v27.m128_f32[0] = fminf(v25.m128_f32[0], *(float *)&v23);
      v24.m128_f32[0] = fmaxf(v24.m128_f32[0], v34.m128_f32[0]);
      v25.m128_f32[0] = fmaxf(v25.m128_f32[0], *(float *)&v23);
      v20 = _mm_unpacklo_ps(v24, v25);
      v37[0] = _mm_movelh_ps(_mm_unpacklo_ps(v26, v27), v20);
      (*((void (__fastcall **)(RBX::LegacyAdorn *, __m128 *, char *))adorn->_vptr$LegacyAdorn + 3))(
        adorn,
        v37,
        (char *)this + 112);
    }
    v28 = *((_QWORD *)this + 5);
    if ( *((_QWORD *)this + 6) != v28 )
    {
      v29 = 0;
      v30 = 0;
      do
      {
        v31 = *(unsigned int **)(v28 + (v29 >> 28));
        if ( v31 )
        {
          if ( (*(unsigned __int8 (__fastcall **)(unsigned int *, double, double))(*(_QWORD *)v31 + 40LL))(
                 v31,
                 v23,
                 *(double *)v20.m128_u64) )
          {
            (*(void (__fastcall **)(unsigned int *, RBX::LegacyAdorn *, __int64 *))(*(_QWORD *)v31 + 80LL))(
              v31,
              adorn,
              &v33);
            *(_QWORD *)&v23 = v31[27];
            *(float *)&v23 = *(float *)&v23 + *((float *)&v33 + 1);
            HIDWORD(v33) = LODWORD(v23);
          }
        }
        ++v30;
        v28 = *((_QWORD *)this + 5);
        v29 += 0x100000000LL;
      }
      while ( v30 < (*((_QWORD *)this + 6) - v28) >> 4 );
    }
  }
}


// Address: 0x15d1b40 | Name: _ZN3RBX10TopMenuBar4initEv
void __fastcall RBX::TopMenuBar::init(RBX::TopMenuBar *this)
{
  *((_DWORD *)this + 32) = 0;
  *((G3D::Color4 *)this + 7) = *G3D::Color4::clear();
  *((_BYTE *)this + 132) = 1;
}


// Address: 0x15d1b70 | Name: _ZN3RBX10TopMenuBarC2ERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEENS_6Layout5StyleEb
void __fastcall RBX::TopMenuBar::TopMenuBar(
        RBX::TopMenuBar *this,
        const std::string *_title,
        RBX::Layout::Style _layoutStyle,
        bool translucentBackdrop)
{
  int v6; // edx
  void *v7; // rcx
  size_t v8; // r8
  const void *v9; // r9

  RBX::GuiItem::GuiItem(this);
  *(_QWORD *)this = off_28C9510;
  *((_OWORD *)this + 7) = xmmword_3EA480;
  *((_DWORD *)this + 32) = 0;
  *((G3D::Color4 *)this + 7) = *G3D::Color4::clear();
  *((_BYTE *)this + 132) = 1;
  std::string::operator=((soap *)((char *)this + 64), (int)_title, v6, v7, v8, v9);
  *((_DWORD *)this + 32) = _layoutStyle;
  if ( translucentBackdrop )
  {
    if ( !(_BYTE)byte_2A30B10 )
    {
      if ( __cxa_guard_acquire(&byte_2A30B10) )
      {
        stru_2A30B00 = (RBX::Color4)xmmword_3E50F0;
        __cxa_guard_release(&byte_2A30B10);
      }
    }
    *((RBX::Color4 *)this + 7) = stru_2A30B00;
  }
}


// Address: 0x15d1c40 | Name: _ZN3RBX10TopMenuBarC2ERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEENS_6Layout5StyleEN3G3D6Color4E
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::TopMenuBar::TopMenuBar(
        RBX::TopMenuBar *this,
        const std::string *_title,
        RBX::Layout::Style _layoutStyle,
        RBX::Color4 _backdropColor)
{
  int v5; // edx
  void *v6; // rcx
  size_t v7; // r8
  const void *v8; // r9

  RBX::GuiItem::GuiItem(this);
  *(_QWORD *)this = off_28C9510;
  *((_OWORD *)this + 7) = xmmword_3EA480;
  *((_DWORD *)this + 32) = 0;
  *((G3D::Color4 *)this + 7) = *G3D::Color4::clear();
  *((_BYTE *)this + 132) = 1;
  std::string::operator=((soap *)((char *)this + 64), (int)_title, v5, v6, v7, v8);
  *((_DWORD *)this + 32) = _layoutStyle;
  *((__m128d *)this + 7) = _mm_unpacklo_pd((__m128d)_backdropColor, *(__m128d *)&_backdropColor.b);
}


// Address: 0x15d1cd0 | Name: _ZN3RBX10TopMenuBar8render2dEPNS_11LegacyAdornERKN3G3D7Vector2E
void __fastcall RBX::TopMenuBar::render2d(RBX::TopMenuBar *this, RBX::LegacyAdorn *adorn, const RBX::Vector2 *pos)
{
  RBX::Vector2 v3; // rbx
  const G3D::Color4 *v4; // rax
  __int64 v5; // rcx
  __int64 v6; // r8
  __int64 v7; // r9
  __m128 v8; // xmm2
  __m128 v9; // xmm3
  __m128 v10; // xmm4
  __m128 v11; // xmm5
  __int64 v12; // rax
  __int64 v13; // rcx
  __int64 v14; // r13
  unsigned __int64 v15; // r15
  float *v16; // rbx
  RBX::Vector2 v17; // [rsp+0h] [rbp-48h] BYREF
  __m128 v18[4]; // [rsp+8h] [rbp-40h] BYREF

  if ( *((_BYTE *)this + 132) )
  {
    v3 = *pos;
    v17 = *pos;
    v4 = G3D::Color4::clear();
    if ( *((float *)this + 28) != v4->r
      || *((float *)this + 29) != v4->g
      || *((float *)this + 30) != v4->b
      || *((float *)this + 31) != v4->a )
    {
      v8 = (__m128)*((unsigned int *)this + 26);
      v8.m128_f32[0] = v8.m128_f32[0] + v3.x;
      v9 = (__m128)*((unsigned int *)this + 27);
      v9.m128_f32[0] = v9.m128_f32[0] + v3.y;
      v10 = v8;
      v10.m128_f32[0] = fminf(v8.m128_f32[0], v3.x);
      v11 = v9;
      v11.m128_f32[0] = fminf(v9.m128_f32[0], v3.y);
      v8.m128_f32[0] = fmaxf(v8.m128_f32[0], v3.x);
      v9.m128_f32[0] = fmaxf(v9.m128_f32[0], v3.y);
      v18[0] = _mm_movelh_ps(_mm_unpacklo_ps(v10, v11), _mm_unpacklo_ps(v8, v9));
      (*((void (__fastcall **)(RBX::LegacyAdorn *, __m128 *, char *, __int64, __int64, __int64, RBX::Vector2))adorn->_vptr$LegacyAdorn
       + 3))(
        adorn,
        v18,
        (char *)this + 112,
        v5,
        v6,
        v7,
        v17);
    }
    v12 = *((_QWORD *)this + 5);
    v13 = *((_QWORD *)this + 6);
    if ( v13 != v12 )
    {
      v14 = 0;
      v15 = 0;
      do
      {
        v16 = *(float **)(v12 + (v14 >> 28));
        if ( v16 )
        {
          (*(void (__fastcall **)(float *, RBX::LegacyAdorn *, RBX::Vector2 *))(*(_QWORD *)v16 + 80LL))(
            v16,
            adorn,
            &v17);
          v17.y = v16[27] + v17.y;
          v12 = *((_QWORD *)this + 5);
          v13 = *((_QWORD *)this + 6);
        }
        ++v15;
        v14 += 0x100000000LL;
      }
      while ( v15 < (v13 - v12) >> 4 );
    }
  }
}


// Address: 0x15d1e10 | Name: _ZN3RBX11TextDisplay4initEv
void __fastcall RBX::TextDisplay::init(RBX::TextDisplay *this)
{
  const G3D::Color3 *v1; // rax
  __int64 v2; // rcx

  *((_QWORD *)this + 13) = 0x41F0000043340000LL;
  *((_DWORD *)this + 34) = 18;
  v1 = G3D::Color3::purple();
  v2 = *(_QWORD *)&v1->r;
  *(float *)&v1 = v1->b;
  *(_QWORD *)((char *)this + 140) = v2;
  *((_DWORD *)this + 37) = (_DWORD)v1;
  *((_DWORD *)this + 38) = 1065353216;
  *(G3D::Color4 *)((char *)this + 156) = *G3D::Color4::clear();
  *((_DWORD *)this + 43) = 1;
  *((_BYTE *)this + 176) = 1;
}


// Address: 0x15d1e70 | Name: _ZN3RBX11TextDisplayC2ERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_
void __fastcall RBX::TextDisplay::TextDisplay(
        RBX::TextDisplay *this,
        const std::string *_title,
        const std::string *_label)
{
  int v3; // r15d
  const G3D::Color3 *v4; // rax
  __int64 v5; // rcx
  int v6; // edx
  void *v7; // rcx
  size_t v8; // r8
  const void *v9; // r9
  int v10; // edx
  void *v11; // rcx
  size_t v12; // r8
  const void *v13; // r9

  v3 = (int)_label;
  RBX::GuiItem::GuiItem(this);
  *(_QWORD *)this = off_28C95A0;
  *((_OWORD *)this + 7) = 0;
  *((_QWORD *)this + 16) = 0;
  *(_OWORD *)((char *)this + 140) = xmmword_3EA480;
  *(_OWORD *)((char *)this + 156) = xmmword_3EA480;
  *((_QWORD *)this + 13) = 0x41F0000043340000LL;
  *((_DWORD *)this + 34) = 18;
  v4 = G3D::Color3::purple();
  v5 = *(_QWORD *)&v4->r;
  *(float *)&v4 = v4->b;
  *(_QWORD *)((char *)this + 140) = v5;
  *((_DWORD *)this + 37) = (_DWORD)v4;
  *((_DWORD *)this + 38) = 1065353216;
  *(G3D::Color4 *)((char *)this + 156) = *G3D::Color4::clear();
  *((_DWORD *)this + 43) = 1;
  *((_BYTE *)this + 176) = 1;
  std::string::operator=((soap *)((char *)this + 64), (int)_title, v6, v7, v8, v9);
  std::string::operator=((soap *)((char *)this + 112), v3, v10, v11, v12, v13);
}


// Address: 0x15d1f60 | Name: _ZN3RBX11TextDisplay8render2dEPNS_11LegacyAdornERKN3G3D7Vector2E
void __fastcall RBX::TextDisplay::render2d(RBX::TextDisplay *this, RBX::LegacyAdorn *adorn, const RBX::Vector2 *pos)
{
  if ( *((_BYTE *)this + 176) )
    (*((void (__fastcall **)(RBX::LegacyAdorn *, char *, const RBX::Vector2 *, _QWORD, char *))adorn->_vptr$LegacyAdorn
     + 4))(
      adorn,
      (char *)this + 112,
      pos,
      *((unsigned int *)this + 34),
      (char *)this + 140);
}


// Address: 0x15d1f90 | Name: _ZN3RBX7GuiItemD2Ev
void __fastcall RBX::GuiItem::~GuiItem(RBX::GuiItem *this)
{
  volatile signed __int32 *v2; // rbx
  __int64 v3; // r15
  __int64 v4; // rbx
  volatile signed __int32 *v5; // r12
  void *v6; // rdi
  volatile signed __int32 *v7; // rdi
  volatile signed __int32 *v8; // rdi

  *(_QWORD *)this = off_28C93F0;
  if ( byte_2A349E0 )
    FLog::FastLog(byte_2A349E0, "GuiItem destroyed: %p", this);
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 12);
  if ( v2 )
  {
    if ( !_InterlockedSub(v2 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
      if ( !_InterlockedSub(v2 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
    }
  }
  if ( (*((_BYTE *)this + 64) & 1) != 0 )
    operator delete(*((void **)this + 10));
  v3 = *((_QWORD *)this + 5);
  if ( v3 )
  {
    v4 = *((_QWORD *)this + 6);
    if ( v4 == v3 )
    {
      v6 = (void *)*((_QWORD *)this + 5);
    }
    else
    {
      do
      {
        v5 = *(volatile signed __int32 **)(v4 - 8);
        if ( v5 )
        {
          if ( !_InterlockedSub(v5 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 16LL))(v5);
            if ( !_InterlockedSub(v5 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
          }
        }
        v4 -= 16;
      }
      while ( v3 != v4 );
      v6 = (void *)*((_QWORD *)this + 5);
    }
    *((_QWORD *)this + 6) = v3;
    operator delete(v6);
  }
  v7 = (volatile signed __int32 *)*((_QWORD *)this + 4);
  if ( v7 && !_InterlockedSub(v7 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
  v8 = (volatile signed __int32 *)*((_QWORD *)this + 2);
  if ( v8 )
  {
    if ( !_InterlockedSub(v8 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
  }
}


// Address: 0x15d2510 | Name: _GLOBAL__sub_I_GUI.cpp
void __cdecl GLOBAL__sub_I_GUI_cpp()
{
  qword_2A30AA0 = (__int64)boost::system::generic_category();
  qword_2A30AA8 = (__int64)boost::system::generic_category();
  qword_2A30AB0 = (__int64)boost::system::system_category();
}


