// Address: 0x10d1740 | Name: _ZN3RBX32HumanoidBodyPartAssetRequirementD0Ev
// Alternative name is 'j__ZdlPv_319'
// attributes: thunk
void __fastcall RBX::HumanoidBodyPartAssetRequirement::~HumanoidBodyPartAssetRequirement(
        RBX::HumanoidBodyPartAssetRequirement *this)
{
  operator delete(this);
}


// Address: 0x10d1750 | Name: _ZN3RBX28HumanoidNullAssetRequirementD0Ev
// Alternative name is 'j__ZdlPv_320'
// attributes: thunk
void __fastcall RBX::HumanoidNullAssetRequirement::~HumanoidNullAssetRequirement(
        RBX::HumanoidNullAssetRequirement *this)
{
  operator delete(this);
}


// Address: 0x10d1760 | Name: _ZN3RBX31HumanoidClothesAssetRequirementD0Ev
// Alternative name is 'j__ZdlPv_321'
// attributes: thunk
void __fastcall RBX::HumanoidClothesAssetRequirement::~HumanoidClothesAssetRequirement(
        RBX::HumanoidClothesAssetRequirement *this)
{
  operator delete(this);
}


// Address: 0x10d1770 | Name: _ZN3RBX28HumanoidFaceAssetRequirementD0Ev
// Alternative name is 'j__ZdlPv_322'
// attributes: thunk
void __fastcall RBX::HumanoidFaceAssetRequirement::~HumanoidFaceAssetRequirement(
        RBX::HumanoidFaceAssetRequirement *this)
{
  operator delete(this);
}


// Address: 0x10d1780 | Name: _ZN3RBX24HumanoidAssetRequirementD2Ev
void __fastcall RBX::HumanoidAssetRequirement::~HumanoidAssetRequirement(RBX::HumanoidAssetRequirement *this)
{
  ;
}


// Address: 0x10d1790 | Name: _ZN3RBX28HumanoidHeadAssetRequirementD0Ev
// Alternative name is 'j__ZdlPv_323'
// attributes: thunk
void __fastcall RBX::HumanoidHeadAssetRequirement::~HumanoidHeadAssetRequirement(
        RBX::HumanoidHeadAssetRequirement *this)
{
  operator delete(this);
}


// Address: 0x10d17a0 | Name: _ZN3RBX33HumanoidAccessoryAssetRequirementD0Ev
// Alternative name is 'j__ZdlPv_324'
// attributes: thunk
void __fastcall RBX::HumanoidAccessoryAssetRequirement::~HumanoidAccessoryAssetRequirement(
        RBX::HumanoidAccessoryAssetRequirement *this)
{
  operator delete(this);
}


// Address: 0x10d17b0 | Name: _ZN3RBX33HumanoidAnimationAssetRequirementD0Ev
// Alternative name is 'j__ZdlPv_325'
// attributes: thunk
void __fastcall RBX::HumanoidAnimationAssetRequirement::~HumanoidAnimationAssetRequirement(
        RBX::HumanoidAnimationAssetRequirement *this)
{
  operator delete(this);
}


// Address: 0x10d17c0 | Name: _ZN3RBX24HumanoidAssetRequirementD0Ev
void __fastcall __noreturn RBX::HumanoidAssetRequirement::~HumanoidAssetRequirement(
        RBX::HumanoidAssetRequirement *this)
{
  BUG();
}


