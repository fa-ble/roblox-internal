// Address: 0x10efde0 | Name: _ZN3RBX19HumanoidDescription14setScaleHeightEf
void __fastcall RBX::HumanoidDescription::setScaleHeight(RBX::HumanoidDescription *this, float a2, float scale)
{
  if ( this->scaleHeight != a2 )
  {
    this->scaleHeight = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09420);
  }
}


// Address: 0x10efe10 | Name: _ZN3RBX19HumanoidDescription13setScaleWidthEf
void __fastcall RBX::HumanoidDescription::setScaleWidth(RBX::HumanoidDescription *this, float a2, float scale)
{
  if ( this->scaleWidth != a2 )
  {
    this->scaleWidth = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09478);
  }
}


// Address: 0x10efe40 | Name: _ZN3RBX19HumanoidDescription12setScaleHeadEf
void __fastcall RBX::HumanoidDescription::setScaleHead(RBX::HumanoidDescription *this, float a2, float scale)
{
  if ( this->scaleHead != a2 )
  {
    this->scaleHead = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A094D0);
  }
}


// Address: 0x10efe70 | Name: _ZN3RBX19HumanoidDescription13setScaleDepthEf
void __fastcall RBX::HumanoidDescription::setScaleDepth(RBX::HumanoidDescription *this, float a2, float scale)
{
  if ( this->scaleDepth != a2 )
  {
    this->scaleDepth = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09528);
  }
}


// Address: 0x10efea0 | Name: _ZN3RBX19HumanoidDescription18setScaleProportionEf
void __fastcall RBX::HumanoidDescription::setScaleProportion(RBX::HumanoidDescription *this, float a2, float scale)
{
  if ( this->scaleProportion != a2 )
  {
    this->scaleProportion = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09580);
  }
}


// Address: 0x10efed0 | Name: _ZN3RBX19HumanoidDescription16setScaleBodyTypeEf
void __fastcall RBX::HumanoidDescription::setScaleBodyType(RBX::HumanoidDescription *this, float a2, float scale)
{
  if ( this->scaleBodyType != a2 )
  {
    this->scaleBodyType = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A095D8);
  }
}


// Address: 0x10f01c0 | Name: _ZN3RBX19HumanoidDescription17setAccessoriesHatERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setAccessoriesHat(
        RBX::HumanoidDescription *this,
        const std::string *accessory)
{
  size_t v3; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r8
  size_t bucket_count; // r10
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rcx
  _QWORD *p_next; // rax
  _QWORD *v9; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v10; // r14
  size_t v11; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > v13; // [rsp+0h] [rbp-48h] BYREF

  RBX::toUnorderedSetAssets(&v13, accessory);
  if ( v13.table_.size_ == this->accessoriesHat.table_.size_ )
  {
    if ( v13.table_.size_ )
    {
      next = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      if ( next )
      {
        bucket_count = this->accessoriesHat.table_.bucket_count_;
        buckets = this->accessoriesHat.table_.buckets_;
LABEL_5:
        v7 = next[2].next_;
        v3 = (unsigned __int64)v7 % bucket_count;
        p_next = &buckets[(unsigned __int64)v7 % bucket_count].next_->next_;
        if ( !p_next )
          goto LABEL_15;
        v9 = (_QWORD *)*p_next;
        if ( !*p_next )
          goto LABEL_15;
        while ( 1 )
        {
          if ( (boost::unordered::detail::ptr_bucket::link_pointer)v9[1] == v7 )
          {
            if ( v7 == (boost::unordered::detail::ptr_bucket::link_pointer)v9[2] )
            {
              next = next->next_;
              if ( !next )
                break;
              goto LABEL_5;
            }
          }
          else
          {
            v3 = v9[1] % bucket_count;
            if ( v3 != (size_t)next[2].next_ % bucket_count )
              goto LABEL_15;
          }
          v9 = (_QWORD *)*v9;
          if ( !v9 )
            goto LABEL_15;
        }
      }
    }
  }
  else
  {
LABEL_15:
    if ( &v13 != &this->accessoriesHat )
      boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::assign(
        &this->accessoriesHat.table_,
        &v13.table_,
        (boost::unordered::detail::false_type)v3);
    RBX::Instance::raisePropertyChanged(this, &stru_2A09840);
  }
  v10 = v13.table_.buckets_;
  if ( v13.table_.buckets_ )
  {
    if ( v13.table_.size_ )
    {
      v11 = v13.table_.bucket_count_;
      v12 = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      do
      {
        v10[v11] = (boost::unordered::detail::ptr_bucket)v12->next_;
        operator delete(v12);
        --v13.table_.size_;
        v12 = v10[v11].next_;
      }
      while ( v12 );
      v10 = v13.table_.buckets_;
    }
    operator delete(v10);
  }
}


// Address: 0x10f0380 | Name: _ZN3RBX19HumanoidDescription18setAccessoriesHairERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setAccessoriesHair(
        RBX::HumanoidDescription *this,
        const std::string *accessory)
{
  size_t v3; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r8
  size_t bucket_count; // r10
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rcx
  _QWORD *p_next; // rax
  _QWORD *v9; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v10; // r14
  size_t v11; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > v13; // [rsp+0h] [rbp-48h] BYREF

  RBX::toUnorderedSetAssets(&v13, accessory);
  if ( v13.table_.size_ == this->accessoriesHair.table_.size_ )
  {
    if ( v13.table_.size_ )
    {
      next = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      if ( next )
      {
        bucket_count = this->accessoriesHair.table_.bucket_count_;
        buckets = this->accessoriesHair.table_.buckets_;
LABEL_5:
        v7 = next[2].next_;
        v3 = (unsigned __int64)v7 % bucket_count;
        p_next = &buckets[(unsigned __int64)v7 % bucket_count].next_->next_;
        if ( !p_next )
          goto LABEL_15;
        v9 = (_QWORD *)*p_next;
        if ( !*p_next )
          goto LABEL_15;
        while ( 1 )
        {
          if ( (boost::unordered::detail::ptr_bucket::link_pointer)v9[1] == v7 )
          {
            if ( v7 == (boost::unordered::detail::ptr_bucket::link_pointer)v9[2] )
            {
              next = next->next_;
              if ( !next )
                break;
              goto LABEL_5;
            }
          }
          else
          {
            v3 = v9[1] % bucket_count;
            if ( v3 != (size_t)next[2].next_ % bucket_count )
              goto LABEL_15;
          }
          v9 = (_QWORD *)*v9;
          if ( !v9 )
            goto LABEL_15;
        }
      }
    }
  }
  else
  {
LABEL_15:
    if ( &v13 != &this->accessoriesHair )
      boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::assign(
        &this->accessoriesHair.table_,
        &v13.table_,
        (boost::unordered::detail::false_type)v3);
    RBX::Instance::raisePropertyChanged(this, &stru_2A09898);
  }
  v10 = v13.table_.buckets_;
  if ( v13.table_.buckets_ )
  {
    if ( v13.table_.size_ )
    {
      v11 = v13.table_.bucket_count_;
      v12 = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      do
      {
        v10[v11] = (boost::unordered::detail::ptr_bucket)v12->next_;
        operator delete(v12);
        --v13.table_.size_;
        v12 = v10[v11].next_;
      }
      while ( v12 );
      v10 = v13.table_.buckets_;
    }
    operator delete(v10);
  }
}


// Address: 0x10f0540 | Name: _ZN3RBX19HumanoidDescription18setAccessoriesFaceERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setAccessoriesFace(
        RBX::HumanoidDescription *this,
        const std::string *accessory)
{
  size_t v3; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r8
  size_t bucket_count; // r10
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rcx
  _QWORD *p_next; // rax
  _QWORD *v9; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v10; // r14
  size_t v11; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > v13; // [rsp+0h] [rbp-48h] BYREF

  RBX::toUnorderedSetAssets(&v13, accessory);
  if ( v13.table_.size_ == this->accessoriesFace.table_.size_ )
  {
    if ( v13.table_.size_ )
    {
      next = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      if ( next )
      {
        bucket_count = this->accessoriesFace.table_.bucket_count_;
        buckets = this->accessoriesFace.table_.buckets_;
LABEL_5:
        v7 = next[2].next_;
        v3 = (unsigned __int64)v7 % bucket_count;
        p_next = &buckets[(unsigned __int64)v7 % bucket_count].next_->next_;
        if ( !p_next )
          goto LABEL_15;
        v9 = (_QWORD *)*p_next;
        if ( !*p_next )
          goto LABEL_15;
        while ( 1 )
        {
          if ( (boost::unordered::detail::ptr_bucket::link_pointer)v9[1] == v7 )
          {
            if ( v7 == (boost::unordered::detail::ptr_bucket::link_pointer)v9[2] )
            {
              next = next->next_;
              if ( !next )
                break;
              goto LABEL_5;
            }
          }
          else
          {
            v3 = v9[1] % bucket_count;
            if ( v3 != (size_t)next[2].next_ % bucket_count )
              goto LABEL_15;
          }
          v9 = (_QWORD *)*v9;
          if ( !v9 )
            goto LABEL_15;
        }
      }
    }
  }
  else
  {
LABEL_15:
    if ( &v13 != &this->accessoriesFace )
      boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::assign(
        &this->accessoriesFace.table_,
        &v13.table_,
        (boost::unordered::detail::false_type)v3);
    RBX::Instance::raisePropertyChanged(this, &stru_2A098F0);
  }
  v10 = v13.table_.buckets_;
  if ( v13.table_.buckets_ )
  {
    if ( v13.table_.size_ )
    {
      v11 = v13.table_.bucket_count_;
      v12 = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      do
      {
        v10[v11] = (boost::unordered::detail::ptr_bucket)v12->next_;
        operator delete(v12);
        --v13.table_.size_;
        v12 = v10[v11].next_;
      }
      while ( v12 );
      v10 = v13.table_.buckets_;
    }
    operator delete(v10);
  }
}


// Address: 0x10f0700 | Name: _ZN3RBX19HumanoidDescription18setAccessoriesNeckERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setAccessoriesNeck(
        RBX::HumanoidDescription *this,
        const std::string *accessory)
{
  size_t v3; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r8
  size_t bucket_count; // r10
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rcx
  _QWORD *p_next; // rax
  _QWORD *v9; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v10; // r14
  size_t v11; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > v13; // [rsp+0h] [rbp-48h] BYREF

  RBX::toUnorderedSetAssets(&v13, accessory);
  if ( v13.table_.size_ == this->accessoriesNeck.table_.size_ )
  {
    if ( v13.table_.size_ )
    {
      next = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      if ( next )
      {
        bucket_count = this->accessoriesNeck.table_.bucket_count_;
        buckets = this->accessoriesNeck.table_.buckets_;
LABEL_5:
        v7 = next[2].next_;
        v3 = (unsigned __int64)v7 % bucket_count;
        p_next = &buckets[(unsigned __int64)v7 % bucket_count].next_->next_;
        if ( !p_next )
          goto LABEL_15;
        v9 = (_QWORD *)*p_next;
        if ( !*p_next )
          goto LABEL_15;
        while ( 1 )
        {
          if ( (boost::unordered::detail::ptr_bucket::link_pointer)v9[1] == v7 )
          {
            if ( v7 == (boost::unordered::detail::ptr_bucket::link_pointer)v9[2] )
            {
              next = next->next_;
              if ( !next )
                break;
              goto LABEL_5;
            }
          }
          else
          {
            v3 = v9[1] % bucket_count;
            if ( v3 != (size_t)next[2].next_ % bucket_count )
              goto LABEL_15;
          }
          v9 = (_QWORD *)*v9;
          if ( !v9 )
            goto LABEL_15;
        }
      }
    }
  }
  else
  {
LABEL_15:
    if ( &v13 != &this->accessoriesNeck )
      boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::assign(
        &this->accessoriesNeck.table_,
        &v13.table_,
        (boost::unordered::detail::false_type)v3);
    RBX::Instance::raisePropertyChanged(this, &stru_2A09948);
  }
  v10 = v13.table_.buckets_;
  if ( v13.table_.buckets_ )
  {
    if ( v13.table_.size_ )
    {
      v11 = v13.table_.bucket_count_;
      v12 = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      do
      {
        v10[v11] = (boost::unordered::detail::ptr_bucket)v12->next_;
        operator delete(v12);
        --v13.table_.size_;
        v12 = v10[v11].next_;
      }
      while ( v12 );
      v10 = v13.table_.buckets_;
    }
    operator delete(v10);
  }
}


// Address: 0x10f08c0 | Name: _ZN3RBX19HumanoidDescription23setAccessoriesShouldersERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setAccessoriesShoulders(
        RBX::HumanoidDescription *this,
        const std::string *accessory)
{
  size_t v3; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r8
  size_t bucket_count; // r10
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rcx
  _QWORD *p_next; // rax
  _QWORD *v9; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v10; // r14
  size_t v11; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > v13; // [rsp+0h] [rbp-48h] BYREF

  RBX::toUnorderedSetAssets(&v13, accessory);
  if ( v13.table_.size_ == this->accessoriesShoulders.table_.size_ )
  {
    if ( v13.table_.size_ )
    {
      next = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      if ( next )
      {
        bucket_count = this->accessoriesShoulders.table_.bucket_count_;
        buckets = this->accessoriesShoulders.table_.buckets_;
LABEL_5:
        v7 = next[2].next_;
        v3 = (unsigned __int64)v7 % bucket_count;
        p_next = &buckets[(unsigned __int64)v7 % bucket_count].next_->next_;
        if ( !p_next )
          goto LABEL_15;
        v9 = (_QWORD *)*p_next;
        if ( !*p_next )
          goto LABEL_15;
        while ( 1 )
        {
          if ( (boost::unordered::detail::ptr_bucket::link_pointer)v9[1] == v7 )
          {
            if ( v7 == (boost::unordered::detail::ptr_bucket::link_pointer)v9[2] )
            {
              next = next->next_;
              if ( !next )
                break;
              goto LABEL_5;
            }
          }
          else
          {
            v3 = v9[1] % bucket_count;
            if ( v3 != (size_t)next[2].next_ % bucket_count )
              goto LABEL_15;
          }
          v9 = (_QWORD *)*v9;
          if ( !v9 )
            goto LABEL_15;
        }
      }
    }
  }
  else
  {
LABEL_15:
    if ( &v13 != &this->accessoriesShoulders )
      boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::assign(
        &this->accessoriesShoulders.table_,
        &v13.table_,
        (boost::unordered::detail::false_type)v3);
    RBX::Instance::raisePropertyChanged(this, &stru_2A099A0);
  }
  v10 = v13.table_.buckets_;
  if ( v13.table_.buckets_ )
  {
    if ( v13.table_.size_ )
    {
      v11 = v13.table_.bucket_count_;
      v12 = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      do
      {
        v10[v11] = (boost::unordered::detail::ptr_bucket)v12->next_;
        operator delete(v12);
        --v13.table_.size_;
        v12 = v10[v11].next_;
      }
      while ( v12 );
      v10 = v13.table_.buckets_;
    }
    operator delete(v10);
  }
}


// Address: 0x10f0a80 | Name: _ZN3RBX19HumanoidDescription19setAccessoriesFrontERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setAccessoriesFront(
        RBX::HumanoidDescription *this,
        const std::string *accessory)
{
  size_t v3; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r8
  size_t bucket_count; // r10
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rcx
  _QWORD *p_next; // rax
  _QWORD *v9; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v10; // r14
  size_t v11; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > v13; // [rsp+0h] [rbp-48h] BYREF

  RBX::toUnorderedSetAssets(&v13, accessory);
  if ( v13.table_.size_ == this->accessoriesFront.table_.size_ )
  {
    if ( v13.table_.size_ )
    {
      next = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      if ( next )
      {
        bucket_count = this->accessoriesFront.table_.bucket_count_;
        buckets = this->accessoriesFront.table_.buckets_;
LABEL_5:
        v7 = next[2].next_;
        v3 = (unsigned __int64)v7 % bucket_count;
        p_next = &buckets[(unsigned __int64)v7 % bucket_count].next_->next_;
        if ( !p_next )
          goto LABEL_15;
        v9 = (_QWORD *)*p_next;
        if ( !*p_next )
          goto LABEL_15;
        while ( 1 )
        {
          if ( (boost::unordered::detail::ptr_bucket::link_pointer)v9[1] == v7 )
          {
            if ( v7 == (boost::unordered::detail::ptr_bucket::link_pointer)v9[2] )
            {
              next = next->next_;
              if ( !next )
                break;
              goto LABEL_5;
            }
          }
          else
          {
            v3 = v9[1] % bucket_count;
            if ( v3 != (size_t)next[2].next_ % bucket_count )
              goto LABEL_15;
          }
          v9 = (_QWORD *)*v9;
          if ( !v9 )
            goto LABEL_15;
        }
      }
    }
  }
  else
  {
LABEL_15:
    if ( &v13 != &this->accessoriesFront )
      boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::assign(
        &this->accessoriesFront.table_,
        &v13.table_,
        (boost::unordered::detail::false_type)v3);
    RBX::Instance::raisePropertyChanged(this, &stru_2A099F8);
  }
  v10 = v13.table_.buckets_;
  if ( v13.table_.buckets_ )
  {
    if ( v13.table_.size_ )
    {
      v11 = v13.table_.bucket_count_;
      v12 = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      do
      {
        v10[v11] = (boost::unordered::detail::ptr_bucket)v12->next_;
        operator delete(v12);
        --v13.table_.size_;
        v12 = v10[v11].next_;
      }
      while ( v12 );
      v10 = v13.table_.buckets_;
    }
    operator delete(v10);
  }
}


// Address: 0x10f0c40 | Name: _ZN3RBX19HumanoidDescription18setAccessoriesBackERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setAccessoriesBack(
        RBX::HumanoidDescription *this,
        const std::string *accessory)
{
  size_t v3; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r8
  size_t bucket_count; // r10
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rcx
  _QWORD *p_next; // rax
  _QWORD *v9; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v10; // r14
  size_t v11; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > v13; // [rsp+0h] [rbp-48h] BYREF

  RBX::toUnorderedSetAssets(&v13, accessory);
  if ( v13.table_.size_ == this->accessoriesBack.table_.size_ )
  {
    if ( v13.table_.size_ )
    {
      next = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      if ( next )
      {
        bucket_count = this->accessoriesBack.table_.bucket_count_;
        buckets = this->accessoriesBack.table_.buckets_;
LABEL_5:
        v7 = next[2].next_;
        v3 = (unsigned __int64)v7 % bucket_count;
        p_next = &buckets[(unsigned __int64)v7 % bucket_count].next_->next_;
        if ( !p_next )
          goto LABEL_15;
        v9 = (_QWORD *)*p_next;
        if ( !*p_next )
          goto LABEL_15;
        while ( 1 )
        {
          if ( (boost::unordered::detail::ptr_bucket::link_pointer)v9[1] == v7 )
          {
            if ( v7 == (boost::unordered::detail::ptr_bucket::link_pointer)v9[2] )
            {
              next = next->next_;
              if ( !next )
                break;
              goto LABEL_5;
            }
          }
          else
          {
            v3 = v9[1] % bucket_count;
            if ( v3 != (size_t)next[2].next_ % bucket_count )
              goto LABEL_15;
          }
          v9 = (_QWORD *)*v9;
          if ( !v9 )
            goto LABEL_15;
        }
      }
    }
  }
  else
  {
LABEL_15:
    if ( &v13 != &this->accessoriesBack )
      boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::assign(
        &this->accessoriesBack.table_,
        &v13.table_,
        (boost::unordered::detail::false_type)v3);
    RBX::Instance::raisePropertyChanged(this, &stru_2A09A50);
  }
  v10 = v13.table_.buckets_;
  if ( v13.table_.buckets_ )
  {
    if ( v13.table_.size_ )
    {
      v11 = v13.table_.bucket_count_;
      v12 = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      do
      {
        v10[v11] = (boost::unordered::detail::ptr_bucket)v12->next_;
        operator delete(v12);
        --v13.table_.size_;
        v12 = v10[v11].next_;
      }
      while ( v12 );
      v10 = v13.table_.buckets_;
    }
    operator delete(v10);
  }
}


// Address: 0x10f0e00 | Name: _ZN3RBX19HumanoidDescription19setAccessoriesWaistERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setAccessoriesWaist(
        RBX::HumanoidDescription *this,
        const std::string *accessory)
{
  size_t v3; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // r8
  size_t bucket_count; // r10
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r9
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rcx
  _QWORD *p_next; // rax
  _QWORD *v9; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v10; // r14
  size_t v11; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > v13; // [rsp+0h] [rbp-48h] BYREF

  RBX::toUnorderedSetAssets(&v13, accessory);
  if ( v13.table_.size_ == this->accessoriesWaist.table_.size_ )
  {
    if ( v13.table_.size_ )
    {
      next = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      if ( next )
      {
        bucket_count = this->accessoriesWaist.table_.bucket_count_;
        buckets = this->accessoriesWaist.table_.buckets_;
LABEL_5:
        v7 = next[2].next_;
        v3 = (unsigned __int64)v7 % bucket_count;
        p_next = &buckets[(unsigned __int64)v7 % bucket_count].next_->next_;
        if ( !p_next )
          goto LABEL_15;
        v9 = (_QWORD *)*p_next;
        if ( !*p_next )
          goto LABEL_15;
        while ( 1 )
        {
          if ( (boost::unordered::detail::ptr_bucket::link_pointer)v9[1] == v7 )
          {
            if ( v7 == (boost::unordered::detail::ptr_bucket::link_pointer)v9[2] )
            {
              next = next->next_;
              if ( !next )
                break;
              goto LABEL_5;
            }
          }
          else
          {
            v3 = v9[1] % bucket_count;
            if ( v3 != (size_t)next[2].next_ % bucket_count )
              goto LABEL_15;
          }
          v9 = (_QWORD *)*v9;
          if ( !v9 )
            goto LABEL_15;
        }
      }
    }
  }
  else
  {
LABEL_15:
    if ( &v13 != &this->accessoriesWaist )
      boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::assign(
        &this->accessoriesWaist.table_,
        &v13.table_,
        (boost::unordered::detail::false_type)v3);
    RBX::Instance::raisePropertyChanged(this, &stru_2A09AA8);
  }
  v10 = v13.table_.buckets_;
  if ( v13.table_.buckets_ )
  {
    if ( v13.table_.size_ )
    {
      v11 = v13.table_.bucket_count_;
      v12 = v13.table_.buckets_[v13.table_.bucket_count_].next_;
      do
      {
        v10[v11] = (boost::unordered::detail::ptr_bucket)v12->next_;
        operator delete(v12);
        --v13.table_.size_;
        v12 = v10[v11].next_;
      }
      while ( v12 );
      v10 = v13.table_.buckets_;
    }
    operator delete(v10);
  }
}


// Address: 0x10f0fa0 | Name: _ZN3RBX19HumanoidDescription15setClothesShirtEl
void __fastcall RBX::HumanoidDescription::setClothesShirt(RBX::HumanoidDescription *this, int64_t clothes)
{
  if ( this->clothesShirt != clothes )
  {
    this->clothesShirt = clothes;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09B00);
  }
}


// Address: 0x10f0fc0 | Name: _ZN3RBX19HumanoidDescription15setClothesPantsEl
void __fastcall RBX::HumanoidDescription::setClothesPants(RBX::HumanoidDescription *this, int64_t clothes)
{
  if ( this->clothesPants != clothes )
  {
    this->clothesPants = clothes;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09B58);
  }
}


// Address: 0x10f0fe0 | Name: _ZN3RBX19HumanoidDescription23setClothesGraphicTShirtEl
void __fastcall RBX::HumanoidDescription::setClothesGraphicTShirt(RBX::HumanoidDescription *this, int64_t clothes)
{
  if ( this->clothesGraphicTShirt != clothes )
  {
    this->clothesGraphicTShirt = clothes;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09BB0);
  }
}


// Address: 0x10f1000 | Name: _ZN3RBX19HumanoidDescription16setBodyPartsFaceEl
void __fastcall RBX::HumanoidDescription::setBodyPartsFace(RBX::HumanoidDescription *this, int64_t bodyPart)
{
  if ( this->bodyPartsFace != bodyPart )
  {
    this->bodyPartsFace = bodyPart;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09C08);
  }
}


// Address: 0x10f1020 | Name: _ZN3RBX19HumanoidDescription16setBodyPartsHeadEl
void __fastcall RBX::HumanoidDescription::setBodyPartsHead(RBX::HumanoidDescription *this, int64_t bodyPart)
{
  if ( this->bodyPartsHead != bodyPart )
  {
    this->bodyPartsHead = bodyPart;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09C60);
  }
}


// Address: 0x10f1040 | Name: _ZN3RBX19HumanoidDescription17setBodyPartsTorsoEl
void __fastcall RBX::HumanoidDescription::setBodyPartsTorso(RBX::HumanoidDescription *this, int64_t bodyPart)
{
  if ( this->bodyPartsTorso != bodyPart )
  {
    this->bodyPartsTorso = bodyPart;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09CB8);
  }
}


// Address: 0x10f1060 | Name: _ZN3RBX19HumanoidDescription19setBodyPartsLeftArmEl
void __fastcall RBX::HumanoidDescription::setBodyPartsLeftArm(RBX::HumanoidDescription *this, int64_t bodyPart)
{
  if ( this->bodyPartsLeftArm != bodyPart )
  {
    this->bodyPartsLeftArm = bodyPart;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09D10);
  }
}


// Address: 0x10f1080 | Name: _ZN3RBX19HumanoidDescription20setBodyPartsRightArmEl
void __fastcall RBX::HumanoidDescription::setBodyPartsRightArm(RBX::HumanoidDescription *this, int64_t bodyPart)
{
  if ( this->bodyPartsRightArm != bodyPart )
  {
    this->bodyPartsRightArm = bodyPart;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09D68);
  }
}


// Address: 0x10f10a0 | Name: _ZN3RBX19HumanoidDescription19setBodyPartsLeftLegEl
void __fastcall RBX::HumanoidDescription::setBodyPartsLeftLeg(RBX::HumanoidDescription *this, int64_t bodyPart)
{
  if ( this->bodyPartsLeftLeg != bodyPart )
  {
    this->bodyPartsLeftLeg = bodyPart;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09DC0);
  }
}


// Address: 0x10f10c0 | Name: _ZN3RBX19HumanoidDescription20setBodyPartsRightLegEl
void __fastcall RBX::HumanoidDescription::setBodyPartsRightLeg(RBX::HumanoidDescription *this, int64_t bodyPart)
{
  if ( this->bodyPartsRightLeg != bodyPart )
  {
    this->bodyPartsRightLeg = bodyPart;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09E18);
  }
}


// Address: 0x10f10e0 | Name: _ZN3RBX19HumanoidDescription16setAnimationWalkEl
void __fastcall RBX::HumanoidDescription::setAnimationWalk(RBX::HumanoidDescription *this, int64_t animation)
{
  if ( this->animationWalk != animation )
  {
    this->animationWalk = animation;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09E70);
  }
}


// Address: 0x10f1100 | Name: _ZN3RBX19HumanoidDescription15setAnimationRunEl
void __fastcall RBX::HumanoidDescription::setAnimationRun(RBX::HumanoidDescription *this, int64_t animation)
{
  if ( this->animationRun != animation )
  {
    this->animationRun = animation;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09EC8);
  }
}


// Address: 0x10f1120 | Name: _ZN3RBX19HumanoidDescription16setAnimationFallEl
void __fastcall RBX::HumanoidDescription::setAnimationFall(RBX::HumanoidDescription *this, int64_t animation)
{
  if ( this->animationFall != animation )
  {
    this->animationFall = animation;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09F20);
  }
}


// Address: 0x10f1140 | Name: _ZN3RBX19HumanoidDescription16setAnimationJumpEl
void __fastcall RBX::HumanoidDescription::setAnimationJump(RBX::HumanoidDescription *this, int64_t animation)
{
  if ( this->animationJump != animation )
  {
    this->animationJump = animation;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09F78);
  }
}


// Address: 0x10f1160 | Name: _ZN3RBX19HumanoidDescription16setAnimationSwimEl
void __fastcall RBX::HumanoidDescription::setAnimationSwim(RBX::HumanoidDescription *this, int64_t animation)
{
  if ( this->animationSwim != animation )
  {
    this->animationSwim = animation;
    RBX::Instance::raisePropertyChanged(this, &stru_2A09FD0);
  }
}


// Address: 0x10f1180 | Name: _ZN3RBX19HumanoidDescription17setAnimationClimbEl
void __fastcall RBX::HumanoidDescription::setAnimationClimb(RBX::HumanoidDescription *this, int64_t animation)
{
  if ( this->animationClimb != animation )
  {
    this->animationClimb = animation;
    RBX::Instance::raisePropertyChanged(this, &stru_2A0A028);
  }
}


// Address: 0x10f11a0 | Name: _ZN3RBX19HumanoidDescription16setAnimationIdleEl
void __fastcall RBX::HumanoidDescription::setAnimationIdle(RBX::HumanoidDescription *this, int64_t animation)
{
  if ( this->animationIdle != animation )
  {
    this->animationIdle = animation;
    RBX::Instance::raisePropertyChanged(this, &stru_2A0A080);
  }
}


// Address: 0x10f11c0 | Name: _ZNK3RBX19HumanoidDescription13getEmotesDataEv
RBX::HumanoidDescription *__fastcall RBX::HumanoidDescription::getEmotesData(
        RBX::HumanoidDescription *this,
        _QWORD *a2)
{
  RBX::HumanoidDescription *v2; // rbp
  _QWORD *i; // r14
  const char *p_str; // rsi
  size_t v5; // rdx
  std::ostream *v6; // rax
  _QWORD *v7; // r12
  std::ostream *v8; // rax
  _QWORD *v9; // rcx
  _QWORD *v10; // rax
  __int64 v11; // r12
  bool v12; // zf
  char v14; // [rsp+Fh] [rbp-169h] BYREF
  unsigned __int8 v15; // [rsp+10h] [rbp-168h] BYREF
  char __str; // [rsp+11h] [rbp-167h] BYREF
  size_t v17; // [rsp+18h] [rbp-160h]
  void *ptr; // [rsp+20h] [rbp-158h]
  RBX::HumanoidDescription *v19; // [rsp+28h] [rbp-150h]
  __int128 v20; // [rsp+30h] [rbp-148h] BYREF
  int *v21; // [rsp+40h] [rbp-138h] BYREF
  _QWORD v22[8]; // [rsp+48h] [rbp-130h] BYREF
  __int128 v23; // [rsp+88h] [rbp-F0h]
  void *v24[2]; // [rsp+98h] [rbp-E0h]
  int v25; // [rsp+A8h] [rbp-D0h]
  _QWORD v26[18]; // [rsp+B0h] [rbp-C8h] BYREF
  int v27; // [rsp+140h] [rbp-38h]

  v2 = this;
  if ( stru_2A09408.value )
  {
    v26[0] = &off_2875320;
    v20 = (unsigned __int64)&off_28752F8;
    std::ios_base::init((std::ios_base *)v26, v22);
    v19 = this;
    v26[17] = 0;
    v27 = -1;
    *(_QWORD *)&v20 = &off_28751B0;
    v26[0] = off_2875200;
    v21 = &off_28751D8;
    std::streambuf::basic_streambuf(v22);
    v22[0] = &off_28753A8;
    *(_OWORD *)v24 = 0;
    v23 = 0;
    v25 = 24;
    if ( a2[97] )
    {
      for ( i = *(_QWORD **)(a2[100] + 8LL * a2[96]); i; i = (_QWORD *)*i )
      {
        std::string::basic_string(&v15, i + 2);
        if ( (v15 & 1) != 0 )
        {
          p_str = (const char *)ptr;
          v5 = v17;
        }
        else
        {
          v5 = (unsigned __int64)v15 >> 1;
          p_str = &__str;
        }
        v6 = std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v21, p_str, v5);
        v14 = 94;
        std::__put_character_sequence<char,std::char_traits<char>>(v6, &v14, 1u);
        v7 = (_QWORD *)i[5];
        if ( v7 != i + 6 )
        {
          do
          {
            v8 = (std::ostream *)std::ostream::operator<<(&v21, v7[4]);
            v14 = 94;
            std::__put_character_sequence<char,std::char_traits<char>>(v8, &v14, 1u);
            v9 = (_QWORD *)v7[1];
            if ( v9 )
            {
              do
              {
                v10 = v9;
                v9 = (_QWORD *)*v9;
              }
              while ( v9 );
            }
            else
            {
              v10 = (_QWORD *)v7[2];
              if ( (_QWORD *)*v10 != v7 )
              {
                v11 = (__int64)(v7 + 2);
                do
                {
                  v10 = *(_QWORD **)(*(_QWORD *)v11 + 16LL);
                  v12 = *v10 == *(_QWORD *)v11;
                  v11 = *(_QWORD *)v11 + 16LL;
                }
                while ( !v12 );
              }
            }
            v7 = v10;
          }
          while ( v10 != i + 6 );
        }
        v14 = 92;
        std::__put_character_sequence<char,std::char_traits<char>>((std::ostream *)&v21, &v14, 1u);
        if ( (v15 & 1) != 0 )
          operator delete(ptr);
      }
    }
    v2 = v19;
    std::stringbuf::str((__int64)v19, (__int64)v22);
    *(_QWORD *)&v20 = &off_28751B0;
    v26[0] = off_2875200;
    v21 = &off_28751D8;
    v22[0] = &off_28753A8;
    if ( (v23 & 1) != 0 )
      operator delete(v24[0]);
    std::streambuf::~streambuf(v22);
    std::iostream::~iostream(&v20, off_2875218);
    std::ios::~ios(v26);
  }
  else
  {
    *(_OWORD *)&this->_vptr$EventSource = 0;
    this->weak_this_.pn.pi_ = 0;
  }
  return v2;
}


// Address: 0x10f1580 | Name: _ZN3RBX19HumanoidDescription13setEmotesDataENSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setEmotesData(__int64 a1, const std::stringbuf::string_type *a2)
{
  std::istream *v2; // rax
  __int64 v3; // rbp
  std::istream *v4; // rax
  int64_t v5; // rbp
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *left; // r14
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *p_pair1; // r12
  int64_t v8; // rax
  _QWORD *p_left; // rax
  std::__tree_node_base<void *> *v10; // rax
  std::__tree<long> *v11; // rax
  RBX::HumanoidDescription *v12; // rbx
  boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > EmotesLua; // rax
  boost::detail::sp_counted_base *pi; // rbx
  std::__tree<long> __first; // [rsp+8h] [rbp-320h] BYREF
  __int128 v16; // [rsp+20h] [rbp-308h] BYREF
  void *ptr; // [rsp+30h] [rbp-2F8h]
  __int128 v18; // [rsp+40h] [rbp-2E8h] BYREF
  void *v19; // [rsp+50h] [rbp-2D8h]
  int64_t value; // [rsp+60h] [rbp-2C8h] BYREF
  RBX::Instance *v21; // [rsp+68h] [rbp-2C0h]
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > > *v22; // [rsp+70h] [rbp-2B8h]
  boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > args; // [rsp+78h] [rbp-2B0h] BYREF
  _BYTE k[16]; // [rsp+88h] [rbp-2A0h] BYREF
  void *v25; // [rsp+98h] [rbp-290h]
  _BYTE v26[24]; // [rsp+A0h] [rbp-288h] BYREF
  int *v27; // [rsp+B8h] [rbp-270h] BYREF
  void *v28[2]; // [rsp+C0h] [rbp-268h]
  __int128 v29; // [rsp+F8h] [rbp-230h]
  void *v30[2]; // [rsp+108h] [rbp-220h]
  int v31; // [rsp+118h] [rbp-210h]
  _QWORD v32[18]; // [rsp+120h] [rbp-208h] BYREF
  int v33; // [rsp+1B0h] [rbp-178h]
  __m128i si128; // [rsp+1C0h] [rbp-168h] BYREF
  int *v35; // [rsp+1D0h] [rbp-158h]
  _QWORD v36[8]; // [rsp+1D8h] [rbp-150h] BYREF
  __int128 v37; // [rsp+218h] [rbp-110h]
  __int128 v38; // [rsp+228h] [rbp-100h]
  int v39; // [rsp+238h] [rbp-F0h]
  _QWORD v40[18]; // [rsp+240h] [rbp-E8h] BYREF
  int v41; // [rsp+2D0h] [rbp-58h]
  __m128i v42[4]; // [rsp+2E0h] [rbp-48h] BYREF

  if ( !stru_2A09408.value )
    return;
  *(_OWORD *)&v26[8] = 0x10u;
  LODWORD(v27) = 1065353216;
  *(_OWORD *)v28 = 0;
  v22 = (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > > *)(a1 + 760);
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets((boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > > *)(a1 + 760));
  *(_DWORD *)(a1 + 784) = 1065353216;
  *(_OWORD *)(a1 + 792) = *(_OWORD *)v28;
  *(_OWORD *)(a1 + 768) = *(_OWORD *)&v26[8];
  *(_OWORD *)v28 = 0;
  v32[0] = &off_2875320;
  v42[0] = (__m128i)(unsigned __int64)&off_28752F8;
  *(_OWORD *)v26 = (unsigned __int64)&off_28752F8;
  std::ios_base::init((std::ios_base *)v32, &v27);
  v32[17] = 0;
  v33 = -1;
  *(_QWORD *)v26 = &off_28751B0;
  v32[0] = off_2875200;
  *(_QWORD *)&v26[16] = &off_28751D8;
  std::streambuf::basic_streambuf(&v27);
  v21 = (RBX::Instance *)a1;
  v27 = &off_28753A8;
  *(_OWORD *)v30 = 0;
  v29 = 0;
  v31 = 24;
  std::stringbuf::str((std::stringbuf *)&v27, a2);
  v18 = 0;
  v19 = 0;
LABEL_3:
  v2 = std::getline<char,std::char_traits<char>,std::allocator<char>>((std::istream *)v26, (std::string *)&v18, 92);
  if ( (*((_BYTE *)v2 + *(_QWORD *)(*(_QWORD *)v2 - 24LL) + 32) & 5) == 0 )
  {
    v3 = std::string::find(&v18, 94, 0) << 32;
    if ( v3 != 0xFFFFFFFF00000000LL )
    {
      std::string::basic_string(k, &v18, 0, v3 >> 32, &v18);
      *(_OWORD *)&__first.__pair1_.__value_.__left_ = 0;
      __first.__begin_node_ = &__first.__pair1_.__value_;
      std::string::basic_string(&v16, &v18, (v3 + 0x100000000LL) >> 32, -1, &v18);
      v35 = &off_28751D8;
      v40[0] = &off_2875320;
      si128 = _mm_load_si128(v42);
      std::ios_base::init((std::ios_base *)v40, v36);
      v40[17] = 0;
      v41 = -1;
      si128.m128i_i64[0] = (__int64)&off_28751B0;
      v40[0] = off_2875200;
      v35 = &off_28751D8;
      std::streambuf::basic_streambuf(v36);
      v36[0] = &off_28753A8;
      v38 = 0;
      v37 = 0;
      v39 = 24;
      std::stringbuf::str((std::stringbuf *)v36, (const std::stringbuf::string_type *)&v16);
      if ( (v16 & 1) != 0 )
        operator delete(ptr);
      v16 = 0;
      ptr = 0;
      while ( 1 )
      {
LABEL_9:
        v4 = std::getline<char,std::char_traits<char>,std::allocator<char>>(
               (std::istream *)&si128,
               (std::string *)&v16,
               94);
        if ( (*((_BYTE *)v4 + *(_QWORD *)(*(_QWORD *)v4 - 24LL) + 32) & 5) != 0 )
        {
          v11 = (std::__tree<long> *)((char *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[](
                                                v22,
                                                k)
                                    + 24);
          if ( v11 != &__first )
            std::__tree<long>::__assign_multi<std::__tree_const_iterator<long,std::__tree_node<long,void *> *,long>>(
              v11,
              (std::__tree_const_iterator<long,std::__tree_node<long,void *> *,long>)__first.__begin_node_,
              (std::__tree_const_iterator<long,std::__tree_node<long,void *> *,long>)&__first.__pair1_);
          if ( (v16 & 1) != 0 )
            operator delete(ptr);
          si128.m128i_i64[0] = (__int64)&off_28751B0;
          v40[0] = off_2875200;
          v35 = &off_28751D8;
          v36[0] = &off_28753A8;
          if ( (v37 & 1) != 0 )
            operator delete((void *)v38);
          std::streambuf::~streambuf(v36);
          std::iostream::~iostream(&si128, off_2875218);
          std::ios::~ios(v40);
          std::__tree<long>::destroy(&__first, (std::__tree<long>::__node_pointer)__first.__pair1_.__value_.__left_);
          if ( (k[0] & 1) != 0 )
            operator delete(v25);
          goto LABEL_3;
        }
        value = 0;
        RBX::StringConverter<long>::convertToValue((const std::string *)&v16, &value);
        v5 = value;
        if ( !value )
          continue;
        left = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)__first.__pair1_.__value_.__left_;
        if ( !__first.__pair1_.__value_.__left_ )
        {
          left = &__first.__pair1_;
          p_pair1 = &__first.__pair1_;
          goto LABEL_23;
        }
        p_pair1 = &__first.__pair1_;
        while ( 1 )
        {
          v8 = (int64_t)left[4].__value_.__left_;
          if ( value < v8 )
            break;
          if ( v8 >= value || (p_pair1 = left + 1, (p_left = &left[1].__value_.__left_->__left_) == 0) )
          {
            if ( p_pair1->__value_.__left_ )
              goto LABEL_9;
            goto LABEL_23;
          }
LABEL_13:
          left = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)p_left;
        }
        p_left = &left->__value_.__left_->__left_;
        p_pair1 = left;
        if ( left->__value_.__left_ )
          goto LABEL_13;
        p_pair1 = left;
        if ( left->__value_.__left_ )
          continue;
LABEL_23:
        v10 = (std::__tree_node_base<void *> *)operator new(0x28u);
        v10[1].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v5;
        *(_OWORD *)&v10->__left_ = 0;
        v10->__parent_ = &left->__value_;
        p_pair1->__value_.__left_ = v10;
        if ( __first.__begin_node_->__left_ )
        {
          __first.__begin_node_ = __first.__begin_node_->__left_;
          v10 = p_pair1->__value_.__left_;
        }
        std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(__first.__pair1_.__value_.__left_, v10);
        ++__first.__pair3_.__value_;
      }
    }
  }
  v12 = (RBX::HumanoidDescription *)v21;
  RBX::Instance::raisePropertyChanged(v21, &stru_2A0A0D8);
  if ( stru_2A093F0.value )
  {
    EmotesLua = RBX::HumanoidDescription::getEmotesLua(v12);
    rbx::signal<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>::operator()(
      &v12->emotesChangedSignal,
      (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)__PAIR128__((unsigned __int64)EmotesLua.pn.pi_, &args));
    pi = args.pn.pi_;
    if ( args.pn.pi_ )
    {
      if ( !_InterlockedSub(&args.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
  if ( (v18 & 1) != 0 )
    operator delete(v19);
  *(_QWORD *)v26 = &off_28751B0;
  v32[0] = off_2875200;
  *(_QWORD *)&v26[16] = &off_28751D8;
  v27 = &off_28753A8;
  if ( (v29 & 1) != 0 )
    operator delete(v30[0]);
  std::streambuf::~streambuf(&v27);
  std::iostream::~iostream(v26, off_2875218);
  std::ios::~ios(v32);
}


// Address: 0x10f1f30 | Name: _ZNK3RBX19HumanoidDescription21getEquippedEmotesDataEv
RBX::HumanoidDescription *__fastcall RBX::HumanoidDescription::getEquippedEmotesData(
        RBX::HumanoidDescription *this,
        _QWORD *a2)
{
  __int64 *i; // r14
  std::ostream *v3; // rax
  std::ostream *v4; // rax
  unsigned __int64 v5; // rdx
  const char *v6; // rsi
  size_t v7; // rdx
  std::ostream *v8; // rax
  char __str; // [rsp+Fh] [rbp-149h] BYREF
  __int128 v11; // [rsp+10h] [rbp-148h] BYREF
  int *v12; // [rsp+20h] [rbp-138h] BYREF
  _QWORD v13[8]; // [rsp+28h] [rbp-130h] BYREF
  __int128 v14; // [rsp+68h] [rbp-F0h]
  void *ptr[2]; // [rsp+78h] [rbp-E0h]
  int v16; // [rsp+88h] [rbp-D0h]
  _QWORD v17[18]; // [rsp+90h] [rbp-C8h] BYREF
  int v18; // [rsp+120h] [rbp-38h]

  if ( stru_2A09408.value )
  {
    v17[0] = &off_2875320;
    v11 = (unsigned __int64)&off_28752F8;
    std::ios_base::init((std::ios_base *)v17, v13);
    v17[17] = 0;
    v18 = -1;
    *(_QWORD *)&v11 = &off_28751B0;
    v17[0] = off_2875200;
    v12 = &off_28751D8;
    std::streambuf::basic_streambuf(v13);
    v13[0] = &off_28753A8;
    *(_OWORD *)ptr = 0;
    v14 = 0;
    v16 = 24;
    if ( a2[103] )
    {
      for ( i = *(__int64 **)(a2[106] + 8LL * a2[102]); i; i = (__int64 *)*i )
      {
        v3 = (std::ostream *)std::ostream::operator<<(&v12, *((unsigned int *)i + 4));
        __str = 94;
        v4 = std::__put_character_sequence<char,std::char_traits<char>>(v3, &__str, 1u);
        v5 = *((unsigned __int8 *)i + 24);
        if ( (v5 & 1) != 0 )
        {
          v6 = (const char *)i[5];
          v7 = i[4];
        }
        else
        {
          v6 = (char *)i + 25;
          v7 = v5 >> 1;
        }
        v8 = std::__put_character_sequence<char,std::char_traits<char>>(v4, v6, v7);
        __str = 92;
        std::__put_character_sequence<char,std::char_traits<char>>(v8, &__str, 1u);
      }
    }
    std::stringbuf::str((__int64)this, (__int64)v13);
    *(_QWORD *)&v11 = &off_28751B0;
    v17[0] = off_2875200;
    v12 = &off_28751D8;
    v13[0] = &off_28753A8;
    if ( (v14 & 1) != 0 )
      operator delete(ptr[0]);
    std::streambuf::~streambuf(v13);
    std::iostream::~iostream(&v11, off_2875218);
    std::ios::~ios(v17);
  }
  else
  {
    *(_OWORD *)&this->_vptr$EventSource = 0;
    this->weak_this_.pn.pi_ = 0;
  }
  return this;
}


// Address: 0x10f21c0 | Name: _ZN3RBX19HumanoidDescription21setEquippedEmotesDataENSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::setEquippedEmotesData(__int64 a1, const std::stringbuf::string_type *a2)
{
  const boost::unordered::detail::false_type *v4; // rax
  __int64 v5; // rcx
  const boost::unordered::detail::false_type *v6; // rdx
  __int64 v7; // rsi
  const boost::unordered::detail::false_type *v8; // rdx
  __int64 v9; // rax
  _QWORD *v10; // r14
  __int64 v11; // rbx
  void **v12; // rbp
  int v13; // ecx
  __int128 v14; // rdi
  int *v15; // rdx
  std::istream *v16; // rax
  __int64 v17; // r13
  char *v18; // rax
  int v19; // edx
  void *v20; // rcx
  size_t v21; // r8
  const void *v22; // r9
  RBX::HumanoidDescription *v23; // rbx
  boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > EquippedEmotesLua; // rax
  boost::detail::sp_counted_base *pi; // rbx
  __int128 v26; // [rsp+0h] [rbp-1B8h] BYREF
  void *v27; // [rsp+10h] [rbp-1A8h]
  RBX::Instance *v28; // [rsp+20h] [rbp-198h]
  boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > args; // [rsp+28h] [rbp-190h] BYREF
  int value; // [rsp+3Ch] [rbp-17Ch] BYREF
  _BYTE v31[16]; // [rsp+40h] [rbp-178h] BYREF
  void *v32; // [rsp+50h] [rbp-168h]
  _BYTE v33[16]; // [rsp+58h] [rbp-160h] BYREF
  void *ptr; // [rsp+68h] [rbp-150h]
  __int128 v35; // [rsp+70h] [rbp-148h] BYREF
  int *v36; // [rsp+80h] [rbp-138h]
  int *v37; // [rsp+88h] [rbp-130h] BYREF
  __int128 v38; // [rsp+90h] [rbp-128h]
  __int128 v39; // [rsp+C8h] [rbp-F0h]
  void *v40[2]; // [rsp+D8h] [rbp-E0h]
  int v41; // [rsp+E8h] [rbp-D0h]
  _QWORD v42[18]; // [rsp+F0h] [rbp-C8h] BYREF
  int v43; // [rsp+180h] [rbp-38h]

  if ( stru_2A09408.value )
  {
    LOBYTE(v35) = 0;
    v4 = &stru_495510;
    v5 = 38;
    do
    {
      v6 = v4;
      v7 = v5 + ~(v5 / 2);
      if ( *(_QWORD *)&v4[8 * (v5 / 2)].gap0 >= 0xBu )
        v7 = v5 / 2;
      v4 += 8 * (v5 / 2) + 8;
      if ( *(_QWORD *)&v6[8 * (v5 / 2)].gap0 >= 0xBu )
        v4 = v6;
      v5 = v7;
    }
    while ( v7 );
    v8 = v4 - 8;
    if ( v4 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS"
                                                             "0_5list1INS0_5valueIPS5_EEEEEE" )
      v8 = v4;
    v9 = *(_QWORD *)&v8->gap0;
    *((_QWORD *)&v35 + 1) = *(_QWORD *)&v8->gap0;
    v36 = 0;
    LODWORD(v37) = 1065353216;
    v38 = 0;
    v10 = *(_QWORD **)(a1 + 848);
    if ( v10 )
    {
      if ( *(_QWORD *)(a1 + 824) )
      {
        v11 = *(_QWORD *)(a1 + 816);
        v12 = (void **)v10[v11];
        do
        {
          v10[v11] = *v12;
          if ( ((_BYTE)v12[3] & 1) != 0 )
            operator delete(v12[5]);
          operator delete(v12);
          --*(_QWORD *)(a1 + 824);
          v12 = (void **)v10[v11];
        }
        while ( v12 );
        v10 = *(_QWORD **)(a1 + 848);
      }
      operator delete(v10);
      *(_OWORD *)(a1 + 840) = 0;
      v13 = (int)v37;
      v14 = v38;
      v9 = *((_QWORD *)&v35 + 1);
      v15 = v36;
    }
    else
    {
      v13 = 1065353216;
      v15 = 0;
      v14 = 0u;
    }
    *(_DWORD *)(a1 + 832) = v13;
    *(_OWORD *)(a1 + 840) = v14;
    *(_QWORD *)(a1 + 816) = v9;
    *(_QWORD *)(a1 + 824) = v15;
    v42[0] = &off_2875320;
    v35 = (unsigned __int64)&off_28752F8;
    std::ios_base::init((std::ios_base *)v42, &v37);
    v42[17] = 0;
    v43 = -1;
    *(_QWORD *)&v35 = &off_28751B0;
    v42[0] = off_2875200;
    v36 = &off_28751D8;
    std::streambuf::basic_streambuf(&v37);
    v37 = &off_28753A8;
    *(_OWORD *)v40 = 0;
    v39 = 0;
    v41 = 24;
    std::stringbuf::str((std::stringbuf *)&v37, a2);
    v26 = 0;
    v27 = 0;
    v28 = (RBX::Instance *)a1;
    while ( 1 )
    {
      v16 = std::getline<char,std::char_traits<char>,std::allocator<char>>(
              (std::istream *)&v35,
              (std::string *)&v26,
              92);
      if ( (*((_BYTE *)v16 + *(_QWORD *)(*(_QWORD *)v16 - 24LL) + 32) & 5) != 0 )
        break;
      v17 = std::string::find(&v26, 94, 0) << 32;
      if ( v17 == 0xFFFFFFFF00000000LL )
        break;
      std::string::basic_string(v33, &v26, 0, v17 >> 32, &v26);
      RBX::StringConverter<int>::convertToValue((const std::string *)v33, &value);
      std::string::basic_string(v31, &v26, (v17 + 0x100000000LL) >> 32, -1, &v26);
      v18 = (char *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<int const,std::string>>,int,std::string,boost::hash<int>,std::equal_to<int>>>::operator[](
                      (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const int,std::string > >,int,std::string,boost::hash<int>,std::equal_to<int> > > *)(a1 + 808),
                      &value);
      std::string::operator=((soap *)(v18 + 8), (int)v31, v19, v20, v21, v22);
      if ( (v31[0] & 1) != 0 )
        operator delete(v32);
      if ( (v33[0] & 1) != 0 )
        operator delete(ptr);
    }
    v23 = (RBX::HumanoidDescription *)v28;
    RBX::Instance::raisePropertyChanged(v28, &stru_2A0A130);
    if ( stru_2A093F0.value )
    {
      EquippedEmotesLua = RBX::HumanoidDescription::getEquippedEmotesLua(v23);
      rbx::signal<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>::operator()(
        &v23->equippedEmotesChangedSignal,
        (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)__PAIR128__(
                                                                           (unsigned __int64)EquippedEmotesLua.pn.pi_,
                                                                           &args));
      pi = args.pn.pi_;
      if ( args.pn.pi_ )
      {
        if ( !_InterlockedSub(&args.pn.pi_->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
      }
    }
    if ( (v26 & 1) != 0 )
      operator delete(v27);
    *(_QWORD *)&v35 = &off_28751B0;
    v42[0] = off_2875200;
    v36 = &off_28751D8;
    v37 = &off_28753A8;
    if ( (v39 & 1) != 0 )
      operator delete(v40[0]);
    std::streambuf::~streambuf(&v37);
    std::iostream::~iostream(&v35, off_2875218);
    std::ios::~ios(v42);
  }
}


// Address: 0x10f2770 | Name: _ZN3RBX19HumanoidDescription11addEmoteLuaENSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEl
void __fastcall RBX::HumanoidDescription::addEmoteLua(RBX::HumanoidDescription *this, char *k, __int64 a3)
{
  unsigned __int64 v5; // rcx
  char *v6; // rax
  unsigned __int64 v7; // rcx
  boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > *p_emotesMap; // rbx
  __int64 v9; // r8
  unsigned __int64 v10; // rcx
  boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > *v11; // r9
  unsigned __int64 v12; // rdi
  unsigned __int64 v13; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > >::iterator v14; // rax
  boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::set<long> > > >::node_pointer node; // r13
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v16; // rbx
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v17; // rbp
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v18; // rax
  std::__tree_node_base<void *> *v19; // rax
  __int64 v20; // rcx
  std::__tree<long> *v21; // rax
  boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > EmotesLua; // rax
  volatile signed __int32 *v23; // rbx
  __int64 v24; // [rsp+0h] [rbp-48h] BYREF
  __int64 __last; // [rsp+8h] [rbp-40h] BYREF
  volatile signed __int32 *v26; // [rsp+10h] [rbp-38h]

  if ( !stru_2A093F0.value )
    RBX::throw_runtime_error(xmmword_3F2662, k);
  v5 = (unsigned __int8)*k;
  if ( (v5 & 1) != 0 )
  {
    v6 = (char *)*((_QWORD *)k + 2);
    v7 = *((_QWORD *)k + 1);
  }
  else
  {
    v6 = k + 1;
    v7 = v5 >> 1;
  }
  p_emotesMap = &this->emotesMap;
  if ( !v7 )
  {
    v10 = 0;
    goto LABEL_14;
  }
  v9 = v7 & 1;
  if ( v7 == 1 )
  {
    v10 = 0;
    if ( !v9 )
      goto LABEL_14;
LABEL_13:
    v10 ^= (v10 << 6) + 2654435769u + (v10 >> 2) + *v6;
    goto LABEL_14;
  }
  v11 = &this->emotesMap;
  v12 = v9 - v7;
  v10 = 0;
  do
  {
    v13 = v10 ^ (*v6 + (v10 >> 2) + (v10 << 6) + 2654435769u);
    v10 = v13 ^ (v6[1] + (v13 >> 2) + (v13 << 6) + 2654435769u);
    v6 += 2;
    v12 += 2LL;
  }
  while ( v12 );
  p_emotesMap = v11;
  if ( v9 )
    goto LABEL_13;
LABEL_14:
  v14.node_ = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
                &p_emotesMap->table_,
                2147483649u
              * ((21
                * ((265 * ((~v10 + (v10 << 21)) ^ ((~v10 + (v10 << 21)) >> 24)))
                 ^ ((265 * ((~v10 + (v10 << 21)) ^ ((~v10 + (v10 << 21)) >> 24))) >> 14)))
               ^ ((21
                 * ((265 * ((~v10 + (v10 << 21)) ^ ((~v10 + (v10 << 21)) >> 24)))
                  ^ ((265 * ((~v10 + (v10 << 21)) ^ ((~v10 + (v10 << 21)) >> 24))) >> 14))) >> 28)),
                (const std::string *)k,
                (const std::equal_to<std::string > *)&this->emotesMap.table_.funcs_[(unsigned __int8)this->emotesMap.table_.current_]).node_;
  if ( !v14.node_ )
  {
    v24 = a3;
    v21 = (std::__tree<long> *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[](
                                 &p_emotesMap->table_,
                                 k);
    std::__tree<long>::__assign_unique<long const*>(v21 + 1, &v24, &__last);
    goto LABEL_29;
  }
  node = v14.node_;
  v16 = &v14.node_->value_base_.data_.data_.align_ + 4;
  v17 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)*((_QWORD *)&v14.node_->value_base_.data_.data_.align_ + 4);
  if ( !v17 )
  {
    v17 = &v14.node_->value_base_.data_.data_.align_ + 4;
    if ( !*(_QWORD *)v16 )
      goto LABEL_25;
    goto LABEL_29;
  }
  while ( *(_QWORD *)&v17[4] <= a3 )
  {
    if ( *(_QWORD *)&v17[4] >= a3
      || (v16 = v17 + 1,
          (v18 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)v17[1]) == 0) )
    {
      if ( *v16 )
        goto LABEL_29;
      goto LABEL_25;
    }
LABEL_18:
    v17 = v18;
  }
  v18 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)*v17;
  v16 = v17;
  if ( *v17 )
    goto LABEL_18;
  v16 = v17;
  if ( *v17 )
    goto LABEL_29;
LABEL_25:
  v19 = (std::__tree_node_base<void *> *)operator new(0x28u);
  v19[1].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)a3;
  *(_OWORD *)&v19->__left_ = 0;
  v19->__parent_ = (std::__tree_node_base<void *>::__parent_pointer)v17;
  *v16 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type)v19;
  v20 = **((_QWORD **)&node->value_base_.data_.data_.align_ + 3);
  if ( v20 )
  {
    *((_QWORD *)&node->value_base_.data_.data_.align_ + 3) = v20;
    v19 = (std::__tree_node_base<void *> *)*v16;
  }
  std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(
    *((std::__tree_node_base<void *> **)&node->value_base_.data_.data_.align_ + 4),
    v19);
  ++*((_QWORD *)&node->value_base_.data_.data_.align_ + 5);
LABEL_29:
  RBX::Instance::raisePropertyChanged(this, &stru_2A0A0D8);
  EmotesLua = RBX::HumanoidDescription::getEmotesLua(this);
  rbx::signal<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>::operator()(
    &this->emotesChangedSignal,
    (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)__PAIR128__((unsigned __int64)EmotesLua.pn.pi_, &__last));
  v23 = v26;
  if ( v26 && !_InterlockedSub(v26 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 16LL))(v23);
    if ( !_InterlockedSub(v23 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 24LL))(v23);
  }
}


// Address: 0x10f2a60 | Name: _ZN3RBX19HumanoidDescription14removeEmoteLuaENSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDescription::removeEmoteLua(RBX::HumanoidDescription *this, std::string *k)
{
  unsigned __int64 v3; // rdx
  char *v4; // rcx
  unsigned __int64 v5; // rdx
  __int64 v6; // r9
  unsigned __int64 v7; // rdx
  unsigned __int64 v8; // rdi
  unsigned __int64 v9; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > >::iterator v10; // rax
  boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > EmotesLua; // rax
  volatile signed __int32 *v12; // rbx
  __int64 v13; // [rsp+0h] [rbp-28h] BYREF
  volatile signed __int32 *v14; // [rsp+8h] [rbp-20h]

  if ( !stru_2A093F0.value )
    RBX::throw_runtime_error(xmmword_3F2662, k);
  v3 = *(unsigned __int8 *)k;
  if ( (v3 & 1) != 0 )
  {
    v4 = (char *)*((_QWORD *)k + 2);
    v5 = *((_QWORD *)k + 1);
  }
  else
  {
    v4 = (char *)k + 1;
    v5 = v3 >> 1;
  }
  if ( v5 )
  {
    v6 = v5 & 1;
    if ( v5 == 1 )
    {
      v7 = 0;
      if ( !v6 )
        goto LABEL_14;
      goto LABEL_13;
    }
    v8 = v6 - v5;
    v7 = 0;
    do
    {
      v9 = v7 ^ (*v4 + (v7 >> 2) + (v7 << 6) + 2654435769u);
      v7 = v9 ^ (v4[1] + (v9 >> 2) + (v9 << 6) + 2654435769u);
      v4 += 2;
      v8 += 2LL;
    }
    while ( v8 );
    if ( v6 )
LABEL_13:
      v7 ^= (v7 << 6) + 2654435769u + (v7 >> 2) + *v4;
  }
  else
  {
    v7 = 0;
  }
LABEL_14:
  v10.node_ = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
                &this->emotesMap.table_,
                2147483649u
              * ((21
                * ((265 * ((~v7 + (v7 << 21)) ^ ((~v7 + (v7 << 21)) >> 24)))
                 ^ ((265 * ((~v7 + (v7 << 21)) ^ ((~v7 + (v7 << 21)) >> 24))) >> 14)))
               ^ ((21
                 * ((265 * ((~v7 + (v7 << 21)) ^ ((~v7 + (v7 << 21)) >> 24)))
                  ^ ((265 * ((~v7 + (v7 << 21)) ^ ((~v7 + (v7 << 21)) >> 24))) >> 14))) >> 28)),
                k,
                (const std::equal_to<std::string > *)&this->emotesMap.table_.funcs_[(unsigned __int8)this->emotesMap.table_.current_]).node_;
  if ( v10.node_ )
  {
    boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::erase_nodes(
      &this->emotesMap.table_,
      v10.node_,
      (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > >::node_pointer)v10.node_->next_);
    RBX::Instance::raisePropertyChanged(this, &stru_2A0A0D8);
    EmotesLua = RBX::HumanoidDescription::getEmotesLua(this);
    rbx::signal<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>::operator()(
      &this->emotesChangedSignal,
      (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)__PAIR128__((unsigned __int64)EmotesLua.pn.pi_, &v13));
    v12 = v14;
    if ( v14 )
    {
      if ( !_InterlockedSub(v14 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
        if ( !_InterlockedSub(v12 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
      }
    }
  }
}


// Address: 0x10f2c70 | Name: _ZN3RBX19HumanoidDescription12getEmotesLuaEv
boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > **__fastcall RBX::HumanoidDescription::getEmotesLua(
        boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > **a1,
        RBX::HumanoidDescription *this)
{
  boost::detail::sp_if_not_array<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >::type v2; // rax
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx
  boost::unordered::detail::ptr_bucket *v4; // r14
  boost::unordered::detail::ptr_bucket::link_pointer v5; // r13
  boost::unordered::detail::ptr_bucket::link_pointer v6; // rbx
  std::vector<RBX::Reflection::Variant> *px; // rbp
  unsigned __int64 v8; // r12
  const rbx::implementation::type_holder *holder; // rax
  _QWORD *p_next; // rcx
  _QWORD *v11; // rax
  __int64 v12; // r14
  bool v13; // zf
  boost::unordered::detail::ptr_bucket::link_pointer *v14; // rbx
  char *v15; // rbp
  boost::detail::sp_counted_base *pi; // rbp
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > **v17; // rbp
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > *v19; // [rsp+0h] [rbp-E8h]
  volatile signed __int32 *v20; // [rsp+8h] [rbp-E0h]
  boost::shared_ptr<std::vector<RBX::Reflection::Variant> > rhs; // [rsp+10h] [rbp-D8h] BYREF
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > **v22; // [rsp+20h] [rbp-C8h]
  boost::unordered::detail::ptr_bucket::link_pointer v23; // [rsp+28h] [rbp-C0h]
  __m128i v24; // [rsp+30h] [rbp-B8h] BYREF
  RBX::Reflection::Variant __x; // [rsp+40h] [rbp-A8h] BYREF
  unsigned __int64 v26; // [rsp+B0h] [rbp-38h]

  v22 = a1;
  v26 = __readfsqword(0x28u);
  if ( !stru_2A093F0.value )
    RBX::throw_runtime_error(xmmword_3F2662, this);
  v2 = boost::make_shared<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>();
  if ( this->emotesMap.table_.size_ )
  {
    next = this->emotesMap.table_.buckets_[this->emotesMap.table_.bucket_count_].next_;
    if ( next )
    {
      v24 = _mm_unpacklo_epi64(
              (__m128i)(unsigned __int64)rbx::implementation::typed_holder<long>::construct_func,
              (__m128i)(unsigned __int64)rbx::implementation::typed_holder<long>::moveConstruct_func);
      do
      {
        boost::make_shared<std::vector<RBX::Reflection::Variant>>();
        v4 = next[5].next_;
        v23 = next;
        v5 = next + 6;
        if ( v4 != &next[6] )
        {
          do
          {
            v6 = v4[4].next_;
            px = (std::vector<RBX::Reflection::Variant> *)rhs.px;
            __x._type = RBX::Reflection::Type::getSingleton<long>();
            __x.value.holder = 0;
            *(_QWORD *)__x.value.data = v6;
            if ( !(_BYTE)byte_29F1F80 && __cxa_guard_acquire(&byte_29F1F80) )
            {
              xmmword_29F1F68 = (__int128)_mm_load_si128(&v24);
              qword_29F1F78 = (__int64)rbx::implementation::typed_holder<long>::destruct_func;
              __cxa_guard_release(&byte_29F1F80);
            }
            __x.value.holder = (const rbx::implementation::type_holder *)&xmmword_29F1F68;
            v8 = *((_QWORD *)px + 1);
            if ( v8 >= *((_QWORD *)px + 2) )
            {
              std::vector<RBX::Reflection::Variant>::__push_back_slow_path<RBX::Reflection::Variant>(px, &__x);
              if ( __x.value.holder )
                __x.value.holder->destruct(__x.value.data);
            }
            else
            {
              *(_QWORD *)v8 = __x._type;
              *(_QWORD *)(v8 + 8) = 0;
              if ( __x.value.holder )
              {
                __x.value.holder->moveConstruct(__x.value.data, (char *)(v8 + 16));
                holder = __x.value.holder;
              }
              else
              {
                holder = 0;
              }
              *(_QWORD *)(v8 + 8) = holder;
              if ( __x.value.holder )
              {
                __x.value.holder->destruct(__x.value.data);
                __x.value.holder = 0;
              }
              __x._type = RBX::Reflection::Type::getSingleton<void>();
              if ( __x.value.holder )
              {
                __x.value.holder->destruct(__x.value.data);
                __x.value.holder = 0;
              }
              *((_QWORD *)px + 1) += 112LL;
            }
            p_next = &v4[1].next_->next_;
            if ( p_next )
            {
              do
              {
                v11 = p_next;
                p_next = (_QWORD *)*p_next;
              }
              while ( p_next );
            }
            else
            {
              v11 = &v4[2].next_->next_;
              if ( (boost::unordered::detail::ptr_bucket *)*v11 != v4 )
              {
                v12 = (__int64)&v4[2];
                do
                {
                  v11 = *(_QWORD **)(*(_QWORD *)v12 + 16LL);
                  v13 = *v11 == *(_QWORD *)v12;
                  v12 = *(_QWORD *)v12 + 16LL;
                }
                while ( !v13 );
              }
            }
            v4 = (boost::unordered::detail::ptr_bucket *)v11;
          }
          while ( v11 != (_QWORD *)v5 );
        }
        v14 = &v23->next_;
        v15 = (char *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::operator[](
                        v19,
                        &v23[2]);
        *((_QWORD *)v15 + 3) = RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>();
        this = (RBX::HumanoidDescription *)&rhs;
        rbx::placement_any<RBX::Reflection::Variant::Storage>::operator=<boost::shared_ptr<std::vector<RBX::Reflection::Variant>>>(
          (rbx::placement_any<RBX::Reflection::Variant::Storage> *)(v15 + 32),
          &rhs);
        pi = rhs.pn.pi_;
        if ( rhs.pn.pi_ )
        {
          if ( !_InterlockedSub(&rhs.pn.pi_->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
            if ( !_InterlockedSub(&pi->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
          }
        }
        next = *v14;
      }
      while ( next );
    }
  }
  v17 = v22;
  *v22 = v19;
  v17[1] = (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > *)v20;
  if ( v20 )
  {
    _InterlockedAdd(v20 + 2, 1u);
    if ( !_InterlockedSub(v20 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, RBX::HumanoidDescription *, boost::detail::sp_counted_base *))(*(_QWORD *)v20 + 16LL))(
        v20,
        this,
        v2.pn.pi_);
      if ( !_InterlockedSub(v20 + 3, 1u) )
        (*(void (__fastcall **)())(*(_QWORD *)v20 + 24LL))();
    }
  }
  return v17;
}


// Address: 0x10f3050 | Name: _ZN3RBX19HumanoidDescription12setEmotesLuaEN5boost10shared_ptrIKNS1_9unordered13unordered_mapINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_10Reflection7VariantENS1_4hashISB_EENS5_8equal_toISB_EENS9_INS5_4pairIKSB_SD_EEEEEEEE
void __fastcall RBX::HumanoidDescription::setEmotesLua(
        RBX::HumanoidDescription *this,
        boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > emotes)
{
  _QWORD *i; // r15
  const RBX::Reflection::Type *v3; // rbx
  void (__fastcall **v4)(__int64, unsigned __int64 *); // rax
  __int64 v5; // rax
  const RBX::Reflection::Type *v6; // rbx
  __int64 *v7; // rcx
  __int64 *v8; // rax
  volatile signed __int32 *v9; // rcx
  __int64 v10; // r14
  __int64 v11; // rbp
  const RBX::Reflection::Type *type; // rax
  void (__fastcall **v13)(__int64, char *); // rcx
  const rbx::implementation::type_holder *v14; // rcx
  __int64 v15; // r12
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *left; // rbx
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *p_pair1; // r13
  __int64 v18; // rax
  _QWORD *p_left; // rax
  std::__tree_node_base<void *> *v20; // rax
  std::__tree<long> *v21; // rax
  RBX::HumanoidDescription *v22; // rbp
  unsigned __int64 v23; // rdx
  boost::detail::sp_counted_base *pi; // rbx
  volatile signed __int32 *v25; // [rsp+8h] [rbp-170h]
  std::__tree<long> v26; // [rsp+10h] [rbp-168h] BYREF
  RBX::Instance *v27; // [rsp+28h] [rbp-150h]
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > > *p_table; // [rsp+30h] [rbp-148h]
  _BYTE k[16]; // [rsp+38h] [rbp-140h] BYREF
  void *ptr; // [rsp+48h] [rbp-130h]
  boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > args; // [rsp+50h] [rbp-128h] BYREF
  RBX::Reflection::Variant v32; // [rsp+60h] [rbp-118h] BYREF
  const RBX::Reflection::Type *v33; // [rsp+D0h] [rbp-A8h]
  __m128i v34; // [rsp+D8h] [rbp-A0h] BYREF
  int v35; // [rsp+E8h] [rbp-90h]
  void *v36[2]; // [rsp+F0h] [rbp-88h]
  unsigned __int64 v37; // [rsp+140h] [rbp-38h]

  v37 = __readfsqword(0x28u);
  if ( !stru_2A093F0.value )
    RBX::throw_runtime_error(xmmword_3F2662, emotes.px, emotes.pn.pi_);
  LOBYTE(v33) = 0;
  v34 = (__m128i)0x10uLL;
  v35 = 1065353216;
  *(_OWORD *)v36 = 0;
  p_table = &this->emotesMap.table_;
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(&this->emotesMap.table_);
  this->emotesMap.table_.mlf_ = 1.0;
  *(_OWORD *)&this->emotesMap.table_.max_load_ = *(_OWORD *)v36;
  v27 = this;
  *(__m128i *)&this->emotesMap.table_.bucket_count_ = _mm_loadu_si128(&v34);
  v34.m128i_i64[1] = 0;
  *(_OWORD *)v36 = 0;
  if ( *(_QWORD *)(*(_QWORD *)emotes.px + 16LL) )
  {
    for ( i = *(_QWORD **)(*(_QWORD *)(*(_QWORD *)emotes.px + 40LL) + 8LL * *(_QWORD *)(*(_QWORD *)emotes.px + 8LL));
          i;
          i = (_QWORD *)*i )
    {
      std::string::basic_string(k, i + 2);
      *(_OWORD *)&v26.__pair1_.__value_.__left_ = 0;
      v26.__begin_node_ = &v26.__pair1_.__value_;
      v3 = (const RBX::Reflection::Type *)i[5];
      v33 = v3;
      v34.m128i_i64[0] = 0;
      v4 = (void (__fastcall **)(__int64, unsigned __int64 *))i[6];
      if ( v4 )
      {
        (*v4)((__int64)(i + 7), &v34.m128i_u64[1]);
        v5 = i[6];
        v3 = v33;
      }
      else
      {
        v5 = 0;
      }
      v34.m128i_i64[0] = v5;
      if ( RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>() == v3 )
      {
        v6 = v33;
        if ( RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>() != v6 )
          RBX::throw_runtime_error("Variant cast failed");
        v7 = (__int64 *)v34.m128i_i64[0];
        if ( v34.m128i_i64[0] )
          v7 = &v34.m128i_i64[1];
        v8 = (__int64 *)*v7;
        v9 = (volatile signed __int32 *)v7[1];
        if ( v9 )
          _InterlockedAdd(v9 + 2, 1u);
        v25 = v9;
        v10 = *v8;
        v11 = v8[1];
        if ( *v8 != v11 )
        {
          do
          {
            type = *(const RBX::Reflection::Type **)v10;
            v32._type = *(const RBX::Reflection::Type **)v10;
            v32.value.holder = 0;
            v13 = *(void (__fastcall ***)(__int64, char *))(v10 + 8);
            if ( v13 )
            {
              (*v13)(v10 + 16, v32.value.data);
              v14 = *(const rbx::implementation::type_holder **)(v10 + 8);
              type = v32._type;
            }
            else
            {
              v14 = 0;
            }
            v32.value.holder = v14;
            if ( !type->isNumber )
              goto LABEL_39;
            v15 = RBX::Reflection::Variant::get<long>(&v32);
            left = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)v26.__pair1_.__value_.__left_;
            p_pair1 = &v26.__pair1_;
            if ( v26.__pair1_.__value_.__left_ )
            {
              while ( 1 )
              {
                v18 = (__int64)left[4].__value_.__left_;
                if ( v15 >= v18 )
                {
                  if ( v18 >= v15 || (p_pair1 = left + 1, (p_left = &left[1].__value_.__left_->__left_) == 0) )
                  {
                    if ( p_pair1->__value_.__left_ )
                      goto LABEL_39;
                    goto LABEL_35;
                  }
                }
                else
                {
                  p_left = &left->__value_.__left_->__left_;
                  p_pair1 = left;
                  if ( !left->__value_.__left_ )
                  {
                    p_pair1 = left;
                    if ( !left->__value_.__left_ )
                      goto LABEL_35;
                    goto LABEL_39;
                  }
                }
                left = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)p_left;
              }
            }
            left = &v26.__pair1_;
LABEL_35:
            v20 = (std::__tree_node_base<void *> *)operator new(0x28u);
            v20[1].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v15;
            *(_OWORD *)&v20->__left_ = 0;
            v20->__parent_ = &left->__value_;
            p_pair1->__value_.__left_ = v20;
            if ( v26.__begin_node_->__left_ )
            {
              v26.__begin_node_ = v26.__begin_node_->__left_;
              v20 = p_pair1->__value_.__left_;
            }
            std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(v26.__pair1_.__value_.__left_, v20);
            ++v26.__pair3_.__value_;
LABEL_39:
            if ( v32.value.holder )
              v32.value.holder->destruct(v32.value.data);
            v10 += 112;
          }
          while ( v10 != v11 );
        }
        if ( v26.__pair3_.__value_ )
        {
          v21 = (std::__tree<long> *)((char *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::operator[](
                                                p_table,
                                                k)
                                    + 24);
          if ( v21 != &v26 )
            std::__tree<long>::__assign_multi<std::__tree_const_iterator<long,std::__tree_node<long,void *> *,long>>(
              v21,
              (std::__tree_const_iterator<long,std::__tree_node<long,void *> *,long>)v26.__begin_node_,
              (std::__tree_const_iterator<long,std::__tree_node<long,void *> *,long>)&v26.__pair1_);
        }
        if ( v25 )
        {
          if ( !_InterlockedSub(v25 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 16LL))(v25);
            if ( !_InterlockedSub(v25 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 24LL))(v25);
          }
        }
      }
      if ( v34.m128i_i64[0] )
        (*(void (__fastcall **)(unsigned __int64 *))(v34.m128i_i64[0] + 16))(&v34.m128i_u64[1]);
      std::__tree<long>::destroy(&v26, (std::__tree<long>::__node_pointer)v26.__pair1_.__value_.__left_);
      if ( (k[0] & 1) != 0 )
        operator delete(ptr);
    }
  }
  v22 = (RBX::HumanoidDescription *)v27;
  RBX::Instance::raisePropertyChanged(v27, &stru_2A0A0D8);
  RBX::HumanoidDescription::getEmotesLua(
    (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > **)&args,
    v22);
  rbx::signal<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>::operator()(
    &v22->emotesChangedSignal,
    (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)__PAIR128__(v23, &args));
  pi = args.pn.pi_;
  if ( args.pn.pi_ && !_InterlockedSub(&args.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10f3680 | Name: _ZN3RBX19HumanoidDescription20getEquippedEmotesLuaEv
std::vector<RBX::Reflection::Variant> **__fastcall RBX::HumanoidDescription::getEquippedEmotesLua(
        std::vector<RBX::Reflection::Variant> **a1,
        RBX::HumanoidDescription *this)
{
  boost::detail::sp_if_not_array<std::vector<RBX::Reflection::Variant> >::type v2; // rax
  boost::unordered::detail::ptr_bucket::link_pointer next; // r15
  int v4; // edx
  void *v5; // rcx
  size_t v6; // r8
  const void *v7; // r9
  _QWORD *v8; // rbp
  __int64 v9; // rax
  char *v10; // rbp
  __int64 v11; // rax
  unsigned __int64 v12; // r13
  const rbx::implementation::type_holder *holder; // rax
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > *v15; // [rsp+8h] [rbp-100h]
  volatile signed __int32 *v16; // [rsp+10h] [rbp-F8h]
  std::vector<RBX::Reflection::Variant> *v17; // [rsp+18h] [rbp-F0h]
  volatile signed __int32 *v18; // [rsp+20h] [rbp-E8h]
  __m128i v19; // [rsp+30h] [rbp-D8h] BYREF
  __m128i v20; // [rsp+40h] [rbp-C8h] BYREF
  __m128i v21; // [rsp+50h] [rbp-B8h] BYREF
  RBX::Reflection::Variant k; // [rsp+60h] [rbp-A8h] BYREF
  unsigned __int64 v23; // [rsp+D0h] [rbp-38h]

  v23 = __readfsqword(0x28u);
  if ( !stru_2A093F0.value )
    RBX::throw_runtime_error(xmmword_3F2662, this);
  v2 = boost::make_shared<std::vector<RBX::Reflection::Variant>>();
  if ( this->equippedEmotes.table_.size_ )
  {
    next = this->equippedEmotes.table_.buckets_[this->equippedEmotes.table_.bucket_count_].next_;
    if ( next )
    {
      v21 = _mm_unpacklo_epi64(
              (__m128i)(unsigned __int64)rbx::implementation::typed_holder<int>::construct_func,
              (__m128i)(unsigned __int64)rbx::implementation::typed_holder<int>::moveConstruct_func);
      v20 = _mm_unpacklo_epi64(
              (__m128i)(unsigned __int64)rbx::implementation::typed_holder<std::string>::construct_func,
              (__m128i)(unsigned __int64)rbx::implementation::typed_holder<std::string>::moveConstruct_func);
      v19 = _mm_unpacklo_epi64(
              (__m128i)(unsigned __int64)rbx::implementation::typed_holder<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>::construct_func,
              (__m128i)(unsigned __int64)rbx::implementation::typed_holder<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>::moveConstruct_func);
      while ( 1 )
      {
        boost::make_shared<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>();
        memset(&k, 0, 24);
        LOBYTE(k._type) = 8;
        strcpy((char *)&k._type + 1, "Slot");
        v8 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::operator[](
               v15,
               &k);
        v8[3] = RBX::Reflection::Type::getSingleton<int>();
        if ( !(_BYTE)byte_29F1EC8 && __cxa_guard_acquire(&byte_29F1EC8) )
        {
          *(__m128i *)&xmmword_29F1EB0 = _mm_load_si128(&v21);
          qword_29F1EC0 = (__int64)rbx::implementation::typed_holder<int>::destruct_func;
          __cxa_guard_release(&byte_29F1EC8);
        }
        v9 = v8[4];
        if ( (__int64 (__fastcall **)(_QWORD, _QWORD))v9 == &xmmword_29F1EB0 )
          break;
        if ( v9 )
        {
          (*(void (__fastcall **)(_QWORD *))(v9 + 16))(v8 + 5);
          v8[4] = 0;
        }
        *((_DWORD *)v8 + 10) = next[2].next_;
        v8[4] = &xmmword_29F1EB0;
        if ( ((__int64)k._type & 1) != 0 )
          goto LABEL_16;
LABEL_17:
        memset(&k, 0, 24);
        LOBYTE(k._type) = 8;
        strcpy((char *)&k._type + 1, "Name");
        v10 = (char *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::operator[](
                        v15,
                        &k);
        *((_QWORD *)v10 + 3) = RBX::Reflection::Type::getSingleton<std::string>();
        if ( !(_BYTE)byte_29F1F00 && __cxa_guard_acquire(&byte_29F1F00) )
        {
          *(__m128i *)&xmmword_29F1EE8 = _mm_load_si128(&v20);
          qword_29F1EF8 = (__int64)rbx::implementation::typed_holder<std::string>::destruct_func;
          __cxa_guard_release(&byte_29F1F00);
        }
        v11 = *((_QWORD *)v10 + 4);
        if ( (__int64 (__fastcall **)(_QWORD, _QWORD))v11 != &xmmword_29F1EE8 )
        {
          if ( v11 )
          {
            (*(void (__fastcall **)(char *))(v11 + 16))(v10 + 40);
            *((_QWORD *)v10 + 4) = 0;
          }
          this = (RBX::HumanoidDescription *)&next[3];
          std::string::basic_string(v10 + 40, &next[3]);
          *((_QWORD *)v10 + 4) = &xmmword_29F1EE8;
          if ( ((__int64)k._type & 1) == 0 )
            goto LABEL_27;
LABEL_26:
          operator delete(*(void **)k.value.data);
          goto LABEL_27;
        }
        this = (RBX::HumanoidDescription *)&next[3];
        std::string::operator=((soap *)(v10 + 40), (_DWORD)next + 24, v4, v5, v6, v7);
        if ( ((__int64)k._type & 1) != 0 )
          goto LABEL_26;
LABEL_27:
        *(_OWORD *)&k._type = (unsigned __int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>();
        *(_QWORD *)k.value.data = v15;
        *(_QWORD *)&k.value.data[8] = v16;
        if ( v16 )
          _InterlockedAdd(v16 + 2, 1u);
        if ( !(_BYTE)byte_2A0A8B0 && __cxa_guard_acquire(&byte_2A0A8B0) )
        {
          xmmword_2A0A898 = (__int128)_mm_load_si128(&v19);
          qword_2A0A8A8 = (__int64)rbx::implementation::typed_holder<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>>::destruct_func;
          __cxa_guard_release(&byte_2A0A8B0);
        }
        k.value.holder = (const rbx::implementation::type_holder *)&xmmword_2A0A898;
        v12 = *((_QWORD *)v17 + 1);
        if ( v12 >= *((_QWORD *)v17 + 2) )
        {
          this = (RBX::HumanoidDescription *)&k;
          std::vector<RBX::Reflection::Variant>::__push_back_slow_path<RBX::Reflection::Variant>(v17, &k);
          if ( k.value.holder )
            k.value.holder->destruct(k.value.data);
        }
        else
        {
          *(_QWORD *)v12 = k._type;
          *(_QWORD *)(v12 + 8) = 0;
          if ( k.value.holder )
          {
            this = (RBX::HumanoidDescription *)(v12 + 16);
            k.value.holder->moveConstruct(k.value.data, (char *)(v12 + 16));
            holder = k.value.holder;
          }
          else
          {
            holder = 0;
          }
          *(_QWORD *)(v12 + 8) = holder;
          if ( k.value.holder )
          {
            k.value.holder->destruct(k.value.data);
            k.value.holder = 0;
          }
          k._type = RBX::Reflection::Type::getSingleton<void>();
          if ( k.value.holder )
          {
            k.value.holder->destruct(k.value.data);
            k.value.holder = 0;
          }
          *((_QWORD *)v17 + 1) += 112LL;
        }
        if ( v16 )
        {
          if ( !_InterlockedSub(v16 + 2, 1u) )
          {
            (*(void (__fastcall **)())(*(_QWORD *)v16 + 16LL))();
            if ( !_InterlockedSub(v16 + 3, 1u) )
              (*(void (__fastcall **)())(*(_QWORD *)v16 + 24LL))();
          }
        }
        next = next->next_;
        if ( !next )
          goto LABEL_46;
      }
      *((_DWORD *)v8 + 10) = next[2].next_;
      if ( ((__int64)k._type & 1) == 0 )
        goto LABEL_17;
LABEL_16:
      operator delete(*(void **)k.value.data);
      goto LABEL_17;
    }
  }
LABEL_46:
  *a1 = v17;
  a1[1] = (std::vector<RBX::Reflection::Variant> *)v18;
  if ( v18 )
  {
    _InterlockedAdd(v18 + 2, 1u);
    if ( !_InterlockedSub(v18 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, RBX::HumanoidDescription *, boost::detail::sp_counted_base *))(*(_QWORD *)v18 + 16LL))(
        v18,
        this,
        v2.pn.pi_);
      if ( !_InterlockedSub(v18 + 3, 1u) )
        (*(void (__fastcall **)())(*(_QWORD *)v18 + 24LL))();
    }
  }
  return a1;
}


// Address: 0x10f3c60 | Name: _ZN3RBX19HumanoidDescription20setEquippedEmotesLuaEN5boost10shared_ptrIKNSt3__16vectorINS_10Reflection7VariantENS3_9allocatorIS6_EEEEEE
void __fastcall RBX::HumanoidDescription::setEquippedEmotesLua(
        RBX::HumanoidDescription *this,
        boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > newEquippedEmotes)
{
  __int64 **px; // r14
  const boost::unordered::detail::false_type *v4; // rax
  __int64 v5; // rcx
  const boost::unordered::detail::false_type *v6; // rdx
  __int64 v7; // rsi
  size_t *v8; // rdx
  size_t v9; // rax
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const int,std::string > >,int,std::string,boost::hash<int>,std::equal_to<int> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbp
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx
  float v13; // ecx
  __int128 v14; // rdi
  size_t v15; // rdx
  __int64 v16; // r15
  __int64 v17; // r13
  __int64 v18; // r15
  const RBX::Reflection::Type *v19; // rbp
  void (__fastcall **v20)(__int64, size_t *); // rax
  size_t v21; // rax
  const RBX::Reflection::Type *v22; // rax
  const RBX::Reflection::Type *v23; // rbx
  const RBX::Reflection::Type *v24; // rbx
  const boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > **v25; // rax
  const boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > *v26; // rbp
  volatile signed __int32 *v27; // r14
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > >::iterator v28; // r13
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > >::iterator v29; // r12
  const RBX::Reflection::Type *v30; // rbx
  const RBX::Reflection::Type *v31; // rbx
  __int64 v32; // rax
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v33; // r12
  char *v34; // rax
  int v35; // edx
  void *v36; // rcx
  size_t v37; // r8
  const void *v38; // r9
  signed __int32 v39; // et0
  size_t *v40; // rbp
  char *v41; // rax
  int v42; // edx
  void *v43; // rcx
  size_t v44; // r8
  const void *v45; // r9
  __int64 v46; // rax
  RBX::HumanoidDescription *v47; // rbx
  unsigned __int64 v48; // rdx
  boost::detail::sp_counted_base *pi; // rbx
  __int128 v50; // [rsp+0h] [rbp-F8h] BYREF
  void *ptr; // [rsp+10h] [rbp-E8h]
  int v52; // [rsp+20h] [rbp-D8h]
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const int,std::string > >,int,std::string,boost::hash<int>,std::equal_to<int> > >::key_type k; // [rsp+24h] [rbp-D4h] BYREF
  RBX::Instance *v54; // [rsp+28h] [rbp-D0h]
  __int64 v55; // [rsp+30h] [rbp-C8h]
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const int,std::string > >,int,std::string,boost::hash<int>,std::equal_to<int> > > *v56; // [rsp+38h] [rbp-C0h]
  boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > args; // [rsp+40h] [rbp-B8h] BYREF
  const RBX::Reflection::Type *v58; // [rsp+50h] [rbp-A8h]
  size_t v59; // [rsp+58h] [rbp-A0h]
  size_t v60; // [rsp+60h] [rbp-98h] BYREF
  int v61; // [rsp+68h] [rbp-90h]
  __int128 v62; // [rsp+70h] [rbp-88h]
  unsigned __int64 v63; // [rsp+C0h] [rbp-38h]

  v63 = __readfsqword(0x28u);
  if ( !stru_2A093F0.value )
    RBX::throw_runtime_error(xmmword_3F2662, newEquippedEmotes.px, newEquippedEmotes.pn.pi_);
  px = (__int64 **)newEquippedEmotes.px;
  LOBYTE(v58) = 0;
  v4 = &stru_495510;
  v5 = 38;
  do
  {
    v6 = v4;
    v7 = v5 + ~(v5 / 2);
    if ( *(_QWORD *)&v4[8 * (v5 / 2)].gap0 >= 0xBu )
      v7 = v5 / 2;
    v4 += 8 * (v5 / 2) + 8;
    if ( *(_QWORD *)&v6[8 * (v5 / 2)].gap0 >= 0xBu )
      v4 = v6;
    v5 = v7;
  }
  while ( v7 );
  v8 = (size_t *)&v4[-8];
  if ( v4 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v8 = (size_t *)v4;
  v9 = *v8;
  v59 = *v8;
  v60 = 0;
  v61 = 1065353216;
  v62 = 0;
  buckets = this->equippedEmotes.table_.buckets_;
  if ( buckets )
  {
    if ( this->equippedEmotes.table_.size_ )
    {
      bucket_count = this->equippedEmotes.table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        if ( ((__int64)next[3].next_ & 1) != 0 )
          operator delete(next[5].next_);
        operator delete(next);
        --this->equippedEmotes.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->equippedEmotes.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->equippedEmotes.table_.max_load_ = 0;
    v13 = *(float *)&v61;
    v14 = v62;
    v9 = v59;
    v15 = v60;
  }
  else
  {
    v13 = 1.0;
    v15 = 0;
    v14 = 0u;
  }
  this->equippedEmotes.table_.mlf_ = v13;
  *(_OWORD *)&this->equippedEmotes.table_.max_load_ = v14;
  this->equippedEmotes.table_.bucket_count_ = v9;
  v54 = this;
  this->equippedEmotes.table_.size_ = v15;
  v16 = **px;
  v17 = (*px)[1];
  if ( v16 != v17 )
  {
    v56 = (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const int,std::string > >,int,std::string,boost::hash<int>,std::equal_to<int> > > *)&v54[6].RBX::GuidItem<RBX::Instance>;
    v18 = v16 + 16;
    v52 = 1;
    v55 = v17;
    do
    {
      v19 = *(const RBX::Reflection::Type **)(v18 - 16);
      v58 = v19;
      v59 = 0;
      v20 = *(void (__fastcall ***)(__int64, size_t *))(v18 - 8);
      if ( v20 )
      {
        (*v20)(v18, &v60);
        v21 = *(_QWORD *)(v18 - 8);
        v19 = v58;
      }
      else
      {
        v21 = 0;
      }
      v59 = v21;
      v22 = RBX::Reflection::Type::getSingleton<std::string>();
      v23 = v58;
      if ( v22 == v19 )
      {
        if ( RBX::Reflection::Type::getSingleton<std::string>() != v23 )
          RBX::throw_runtime_error("Variant cast failed");
        v40 = (size_t *)v59;
        LODWORD(v50) = v52;
        v41 = (char *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<int const,std::string>>,int,std::string,boost::hash<int>,std::equal_to<int>>>::operator[](
                        v56,
                        (const boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const int,std::string > >,int,std::string,boost::hash<int>,std::equal_to<int> > >::key_type *)&v50);
        if ( v40 )
          v40 = &v60;
        std::string::operator=((soap *)(v41 + 8), (int)v40, v42, v43, v44, v45);
        ++v52;
      }
      else if ( RBX::Reflection::Type::getSingleton<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>() == v23 )
      {
        v24 = v58;
        if ( RBX::Reflection::Type::getSingleton<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>() != v24 )
          RBX::throw_runtime_error("Variant cast failed");
        v25 = (const boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > **)v59;
        if ( v59 )
          v25 = (const boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > **)&v60;
        v26 = *v25;
        v27 = (volatile signed __int32 *)v25[1];
        if ( v27 )
          _InterlockedAdd(v27 + 2, 1u);
        v50 = 0;
        ptr = 0;
        LOBYTE(v50) = 8;
        *(_DWORD *)((char *)&v50 + 1) = 1953459283;
        BYTE5(v50) = 0;
        v28.node_ = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
                      v26,
                      0x607D7D7DD1AB7669uLL,
                      (const std::string *)&v50,
                      (const std::equal_to<std::string > *)&v26->funcs_[(unsigned __int8)v26->current_]).node_;
        if ( (v50 & 1) != 0 )
          operator delete(ptr);
        v50 = 0;
        ptr = 0;
        LOBYTE(v50) = 8;
        *(_DWORD *)((char *)&v50 + 1) = 1701667150;
        BYTE5(v50) = 0;
        v29.node_ = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
                      v26,
                      0xBF51A7318EC7734BLL,
                      (const std::string *)&v50,
                      (const std::equal_to<std::string > *)&v26->funcs_[(unsigned __int8)v26->current_]).node_;
        if ( (v50 & 1) != 0 )
          operator delete(ptr);
        if ( v28.node_ )
        {
          if ( v29.node_ )
          {
            if ( *(_BYTE *)(*((_QWORD *)&v28.node_->value_base_.data_.data_.align_ + 3) + 53LL) )
            {
              v30 = (const RBX::Reflection::Type *)*((_QWORD *)&v29.node_->value_base_.data_.data_.align_ + 3);
              if ( RBX::Reflection::Type::getSingleton<std::string>() == v30 )
              {
                k = RBX::Reflection::Variant::get<int>((const RBX::Reflection::Variant *)(&v28.node_->value_base_.data_.data_.align_
                                                                                        + 3));
                v31 = (const RBX::Reflection::Type *)*((_QWORD *)&v29.node_->value_base_.data_.data_.align_ + 3);
                if ( RBX::Reflection::Type::getSingleton<std::string>() != v31 )
                  RBX::throw_runtime_error("Variant cast failed");
                v32 = *((_QWORD *)&v29.node_->value_base_.data_.data_.align_ + 4);
                v33 = &v29.node_->value_base_.data_.data_.align_ + 5;
                if ( !v32 )
                  v33 = 0;
                std::string::basic_string(&v50, v33);
                v34 = (char *)boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<int const,std::string>>,int,std::string,boost::hash<int>,std::equal_to<int>>>::operator[](
                                v56,
                                &k);
                std::string::operator=((soap *)(v34 + 8), (int)&v50, v35, v36, v37, v38);
                if ( (v50 & 1) != 0 )
                  operator delete(ptr);
              }
            }
          }
        }
        if ( v27 )
        {
          v39 = _InterlockedSub(v27 + 2, 1u);
          v17 = v55;
          if ( !v39 )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 16LL))(v27);
            if ( !_InterlockedSub(v27 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 24LL))(v27);
          }
        }
        else
        {
          v17 = v55;
        }
      }
      if ( v59 )
        (*(void (__fastcall **)(size_t *))(v59 + 16))(&v60);
      v46 = v18 - 16;
      v18 += 112;
    }
    while ( v46 + 112 != v17 );
  }
  v47 = (RBX::HumanoidDescription *)v54;
  RBX::Instance::raisePropertyChanged(v54, &stru_2A0A130);
  RBX::HumanoidDescription::getEquippedEmotesLua((std::vector<RBX::Reflection::Variant> **)&args, v47);
  rbx::signal<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>::operator()(
    &v47->equippedEmotesChangedSignal,
    (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)__PAIR128__(v48, &args));
  pi = args.pn.pi_;
  if ( args.pn.pi_ && !_InterlockedSub(&args.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10f4260 | Name: _ZN3RBX19HumanoidDescription21setNumberEmotesLoadedEi
void __fastcall RBX::HumanoidDescription::setNumberEmotesLoaded(
        RBX::HumanoidDescription *this,
        int newNumberEmotesLoaded)
{
  if ( this->numberEmotesLoaded != newNumberEmotesLoaded )
  {
    this->numberEmotesLoaded = newNumberEmotesLoaded;
    RBX::Instance::raisePropertyChanged(this, &stru_2A0A480);
  }
}


// Address: 0x10f4280 | Name: _ZN3RBX19HumanoidDescriptionC2Ev
void __fastcall RBX::HumanoidDescription::HumanoidDescription(RBX::HumanoidDescription *this)
{
  const boost::unordered::detail::false_type *v2; // rdx
  __int64 v3; // rax
  const boost::unordered::detail::false_type *v4; // rcx
  __int64 v5; // rsi
  const boost::unordered::detail::false_type *v6; // rcx
  size_t *v7; // rsi
  __int64 v8; // rdx
  const boost::unordered::detail::false_type *v9; // rsi
  __int64 v10; // rdi
  const boost::unordered::detail::false_type *v11; // rdx
  size_t *v12; // rsi
  __int64 v13; // rcx
  const boost::unordered::detail::false_type *v14; // rsi
  __int64 v15; // rdi
  const boost::unordered::detail::false_type *v16; // rcx
  size_t *v17; // rsi
  __int64 v18; // rdx
  const boost::unordered::detail::false_type *v19; // rsi
  __int64 v20; // rdi
  const boost::unordered::detail::false_type *v21; // rdx
  size_t *v22; // rsi
  __int64 v23; // rcx
  const boost::unordered::detail::false_type *v24; // rsi
  __int64 v25; // rdi
  const boost::unordered::detail::false_type *v26; // rcx
  size_t *v27; // rsi
  __int64 v28; // rdx
  const boost::unordered::detail::false_type *v29; // rsi
  __int64 v30; // rdi
  const boost::unordered::detail::false_type *v31; // rdx
  size_t *v32; // rsi
  __int64 v33; // rcx
  const boost::unordered::detail::false_type *v34; // rsi
  __int64 v35; // rdi
  const boost::unordered::detail::false_type *v36; // rcx
  size_t *v37; // rsi
  __int64 v38; // rdx
  const boost::unordered::detail::false_type *v39; // rsi
  __int64 v40; // rdi
  size_t *v41; // rdx
  const boost::unordered::detail::false_type *v42; // rcx
  __int64 v43; // rdx
  const boost::unordered::detail::false_type *v44; // rsi
  __int64 v45; // rdi
  size_t *v46; // rdx
  void *v47[17]; // [rsp+10h] [rbp-88h] BYREF

  RBX::Instance::Instance(this);
  this->_vptr$EventSource = (int (**)(void))&off_2898978;
  this->descriptor = Class_getDescriptorPtr(this);
  this->_vptr$EventSource = (int (**)(void))off_2897790;
  *(_OWORD *)&this->emotesChangedSignal.head.px = 0;
  *(RBX::Vector4 *)&this->scaleHeight = stru_3E5460;
  *(_QWORD *)&this->scaleProportion = 0x3E99999A3F800000LL;
  *(_OWORD *)((char *)&this->bodyColorRightLeg.b + 1) = 0;
  *(_OWORD *)&this->bodyColorRightLeg.r = 0;
  *(_OWORD *)&this->bodyColorRightArm.b = 0;
  *(_OWORD *)&this->bodyColorTorso.g = 0;
  *(_OWORD *)&this->bodyColorHead.r = 0;
  v2 = &stru_495510;
  v3 = 38;
  do
  {
    v4 = v2;
    v5 = v3 + ~(v3 / 2);
    if ( *(_QWORD *)&v2[8 * (v3 / 2)].gap0 >= 0xBu )
      v5 = v3 / 2;
    v2 += 8 * (v3 / 2) + 8;
    if ( *(_QWORD *)&v4[8 * (v3 / 2)].gap0 >= 0xBu )
      v2 = v4;
    v3 = v5;
  }
  while ( v5 );
  v6 = &stru_495510;
  v7 = (size_t *)&v2[-8];
  if ( v2 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v7 = (size_t *)v2;
  this->accessoriesHat.table_.bucket_count_ = *v7;
  this->accessoriesHat.table_.size_ = 0;
  this->accessoriesHat.table_.mlf_ = 1.0;
  v47[10] = &this->accessoriesHat.table_.max_load_;
  *(_OWORD *)&this->accessoriesHat.table_.max_load_ = 0;
  this->accessoriesHair.table_.current_ = 0;
  v8 = 38;
  do
  {
    v9 = v6;
    v10 = v8 + ~(v8 / 2);
    if ( *(_QWORD *)&v6[8 * (v8 / 2)].gap0 >= 0xBu )
      v10 = v8 / 2;
    v6 += 8 * (v8 / 2) + 8;
    if ( *(_QWORD *)&v9[8 * (v8 / 2)].gap0 >= 0xBu )
      v6 = v9;
    v8 = v10;
  }
  while ( v10 );
  v11 = &stru_495510;
  v12 = (size_t *)&v6[-8];
  if ( v6 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v12 = (size_t *)v6;
  this->accessoriesHair.table_.bucket_count_ = *v12;
  this->accessoriesHair.table_.size_ = 0;
  this->accessoriesHair.table_.mlf_ = 1.0;
  v47[9] = &this->accessoriesHair.table_.max_load_;
  *(_OWORD *)&this->accessoriesHair.table_.max_load_ = 0;
  this->accessoriesFace.table_.current_ = 0;
  v13 = 38;
  do
  {
    v14 = v11;
    v15 = v13 + ~(v13 / 2);
    if ( *(_QWORD *)&v11[8 * (v13 / 2)].gap0 >= 0xBu )
      v15 = v13 / 2;
    v11 += 8 * (v13 / 2) + 8;
    if ( *(_QWORD *)&v14[8 * (v13 / 2)].gap0 >= 0xBu )
      v11 = v14;
    v13 = v15;
  }
  while ( v15 );
  v16 = &stru_495510;
  v17 = (size_t *)&v11[-8];
  if ( v11 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0"
                                                            "_5list1INS0_5valueIPS5_EEEEEE" )
    v17 = (size_t *)v11;
  this->accessoriesFace.table_.bucket_count_ = *v17;
  this->accessoriesFace.table_.size_ = 0;
  this->accessoriesFace.table_.mlf_ = 1.0;
  v47[8] = &this->accessoriesFace.table_.max_load_;
  *(_OWORD *)&this->accessoriesFace.table_.max_load_ = 0;
  this->accessoriesNeck.table_.current_ = 0;
  v18 = 38;
  do
  {
    v19 = v16;
    v20 = v18 + ~(v18 / 2);
    if ( *(_QWORD *)&v16[8 * (v18 / 2)].gap0 >= 0xBu )
      v20 = v18 / 2;
    v16 += 8 * (v18 / 2) + 8;
    if ( *(_QWORD *)&v19[8 * (v18 / 2)].gap0 >= 0xBu )
      v16 = v19;
    v18 = v20;
  }
  while ( v20 );
  v21 = &stru_495510;
  v22 = (size_t *)&v16[-8];
  if ( v16 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0"
                                                            "_5list1INS0_5valueIPS5_EEEEEE" )
    v22 = (size_t *)v16;
  this->accessoriesNeck.table_.bucket_count_ = *v22;
  this->accessoriesNeck.table_.size_ = 0;
  this->accessoriesNeck.table_.mlf_ = 1.0;
  v47[7] = &this->accessoriesNeck.table_.max_load_;
  *(_OWORD *)&this->accessoriesNeck.table_.max_load_ = 0;
  this->accessoriesShoulders.table_.current_ = 0;
  v23 = 38;
  do
  {
    v24 = v21;
    v25 = v23 + ~(v23 / 2);
    if ( *(_QWORD *)&v21[8 * (v23 / 2)].gap0 >= 0xBu )
      v25 = v23 / 2;
    v21 += 8 * (v23 / 2) + 8;
    if ( *(_QWORD *)&v24[8 * (v23 / 2)].gap0 >= 0xBu )
      v21 = v24;
    v23 = v25;
  }
  while ( v25 );
  v26 = &stru_495510;
  v27 = (size_t *)&v21[-8];
  if ( v21 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0"
                                                            "_5list1INS0_5valueIPS5_EEEEEE" )
    v27 = (size_t *)v21;
  this->accessoriesShoulders.table_.bucket_count_ = *v27;
  this->accessoriesShoulders.table_.size_ = 0;
  this->accessoriesShoulders.table_.mlf_ = 1.0;
  v47[6] = &this->accessoriesShoulders.table_.max_load_;
  *(_OWORD *)&this->accessoriesShoulders.table_.max_load_ = 0;
  this->accessoriesFront.table_.current_ = 0;
  v28 = 38;
  do
  {
    v29 = v26;
    v30 = v28 + ~(v28 / 2);
    if ( *(_QWORD *)&v26[8 * (v28 / 2)].gap0 >= 0xBu )
      v30 = v28 / 2;
    v26 += 8 * (v28 / 2) + 8;
    if ( *(_QWORD *)&v29[8 * (v28 / 2)].gap0 >= 0xBu )
      v26 = v29;
    v28 = v30;
  }
  while ( v30 );
  v31 = &stru_495510;
  v32 = (size_t *)&v26[-8];
  if ( v26 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0"
                                                            "_5list1INS0_5valueIPS5_EEEEEE" )
    v32 = (size_t *)v26;
  this->accessoriesFront.table_.bucket_count_ = *v32;
  this->accessoriesFront.table_.size_ = 0;
  this->accessoriesFront.table_.mlf_ = 1.0;
  *(_OWORD *)&this->accessoriesFront.table_.max_load_ = 0;
  this->accessoriesBack.table_.current_ = 0;
  v33 = 38;
  do
  {
    v34 = v31;
    v35 = v33 + ~(v33 / 2);
    if ( *(_QWORD *)&v31[8 * (v33 / 2)].gap0 >= 0xBu )
      v35 = v33 / 2;
    v31 += 8 * (v33 / 2) + 8;
    if ( *(_QWORD *)&v34[8 * (v33 / 2)].gap0 >= 0xBu )
      v31 = v34;
    v33 = v35;
  }
  while ( v35 );
  v36 = &stru_495510;
  v37 = (size_t *)&v31[-8];
  if ( v31 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0"
                                                            "_5list1INS0_5valueIPS5_EEEEEE" )
    v37 = (size_t *)v31;
  this->accessoriesBack.table_.bucket_count_ = *v37;
  this->accessoriesBack.table_.size_ = 0;
  this->accessoriesBack.table_.mlf_ = 1.0;
  *(_OWORD *)&this->accessoriesBack.table_.max_load_ = 0;
  this->accessoriesWaist.table_.current_ = 0;
  v38 = 38;
  do
  {
    v39 = v36;
    v40 = v38 + ~(v38 / 2);
    if ( *(_QWORD *)&v36[8 * (v38 / 2)].gap0 >= 0xBu )
      v40 = v38 / 2;
    v36 += 8 * (v38 / 2) + 8;
    if ( *(_QWORD *)&v39[8 * (v38 / 2)].gap0 >= 0xBu )
      v36 = v39;
    v38 = v40;
  }
  while ( v40 );
  v41 = (size_t *)&v36[-8];
  if ( v36 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0"
                                                            "_5list1INS0_5valueIPS5_EEEEEE" )
    v41 = (size_t *)v36;
  v42 = &stru_495510;
  this->accessoriesWaist.table_.bucket_count_ = *v41;
  this->accessoriesWaist.table_.size_ = 0;
  this->accessoriesWaist.table_.mlf_ = 1.0;
  *(_OWORD *)((char *)&this->animationClimb + 1) = 0;
  *(_OWORD *)&this->animationSwim = 0;
  *(_OWORD *)&this->animationFall = 0;
  *(_OWORD *)&this->animationWalk = 0;
  *(_OWORD *)&this->bodyPartsLeftLeg = 0;
  *(_OWORD *)&this->bodyPartsLeftArm = 0;
  *(_OWORD *)&this->bodyPartsHead = 0;
  *(_OWORD *)&this->clothesGraphicTShirt = 0;
  *(_OWORD *)&this->clothesShirt = 0;
  *(_OWORD *)&this->accessoriesWaist.table_.max_load_ = 0;
  *(_OWORD *)&this->emotesMap.table_.bucket_count_ = 0x10u;
  this->emotesMap.table_.mlf_ = 1.0;
  *(_OWORD *)&this->emotesMap.table_.max_load_ = 0;
  this->equippedEmotes.table_.current_ = 0;
  v43 = 38;
  do
  {
    v44 = v42;
    v45 = v43 + ~(v43 / 2);
    if ( *(_QWORD *)&v42[8 * (v43 / 2)].gap0 >= 0xBu )
      v45 = v43 / 2;
    v42 += 8 * (v43 / 2) + 8;
    if ( *(_QWORD *)&v44[8 * (v43 / 2)].gap0 >= 0xBu )
      v42 = v44;
    v43 = v45;
  }
  while ( v45 );
  v46 = (size_t *)&v42[-8];
  if ( v42 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0"
                                                            "_5list1INS0_5valueIPS5_EEEEEE" )
    v46 = (size_t *)v42;
  this->equippedEmotes.table_.bucket_count_ = *v46;
  this->equippedEmotes.table_.size_ = 0;
  this->equippedEmotes.table_.mlf_ = 1.0;
  *(_OWORD *)&this->equippedEmotes.table_.max_load_ = 0;
  this->numberEmotesLoaded = -1;
  strcpy((char *)&v47[2] + 1, "ion");
  BYTE5(v47[2]) = 0;
  HIWORD(v47[2]) = 0;
  strcpy((char *)v47, "&HumanoidDescrip");
  RBX::Instance::setName(this, (const std::string *)v47);
  if ( ((__int64)v47[0] & 1) != 0 )
    operator delete(v47[2]);
}


// Address: 0x10f4cc0 | Name: _ZNK3RBX19HumanoidDescription12askSetParentEPKNS_8InstanceE
bool __fastcall RBX::HumanoidDescription::askSetParent(
        const RBX::HumanoidDescription *this,
        const RBX::Instance *instance)
{
  return 1;
}


// Address: 0x10f4cd0 | Name: _ZN3RBX19HumanoidDescription17onServiceProviderEPNS_15ServiceProviderES2_
void __fastcall RBX::HumanoidDescription::onServiceProvider(
        RBX::HumanoidDescription *this,
        RBX::ServiceProvider *oldProvider,
        RBX::ServiceProvider *newProvider)
{
  RBX::CollectionService *v4; // rbx
  unsigned __int64 v5; // rdx
  boost::detail::sp_counted_base *pi; // rbx
  volatile signed __int32 *v7; // rbx
  RBX::CollectionService *v8; // rbx
  unsigned __int64 v9; // rdx
  boost::detail::sp_counted_base *v10; // rbx
  volatile signed __int32 *v11; // rbx
  boost::shared_ptr<RBX::Instance> v12; // [rsp+0h] [rbp-58h] BYREF
  boost::shared_ptr<RBX::Instance> v13; // [rsp+10h] [rbp-48h] BYREF
  boost::shared_ptr<RBX::Instance> instance; // [rsp+20h] [rbp-38h] BYREF

  if ( oldProvider )
  {
    v4 = RBX::ServiceProvider::create<RBX::CollectionService>(oldProvider);
    RBX::shared_from<RBX::HumanoidDescription>(&v12.px, this);
    instance = v12;
    v12 = 0;
    RBX::CollectionService::removeInstance(v4, (boost::shared_ptr<RBX::Instance>)__PAIR128__(v5, &instance));
    pi = instance.pn.pi_;
    if ( instance.pn.pi_ )
    {
      if ( !_InterlockedSub(&instance.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    v7 = (volatile signed __int32 *)v12.pn.pi_;
    if ( v12.pn.pi_ )
    {
      if ( !_InterlockedSub(&v12.pn.pi_->use_count_, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
        if ( !_InterlockedSub(v7 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
      }
    }
  }
  RBX::Instance::onServiceProvider(this, oldProvider, newProvider);
  if ( newProvider )
  {
    v8 = RBX::ServiceProvider::create<RBX::CollectionService>(newProvider);
    RBX::shared_from<RBX::HumanoidDescription>(&v12.px, this);
    v13 = v12;
    v12 = 0;
    RBX::CollectionService::addInstance(v8, (boost::shared_ptr<RBX::Instance>)__PAIR128__(v9, &v13));
    v10 = v13.pn.pi_;
    if ( v13.pn.pi_ )
    {
      if ( !_InterlockedSub(&v13.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
        if ( !_InterlockedSub(&v10->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
      }
    }
    v11 = (volatile signed __int32 *)v12.pn.pi_;
    if ( v12.pn.pi_ && !_InterlockedSub(&v12.pn.pi_->use_count_, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
      if ( !_InterlockedSub(v11 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
    }
  }
}


// Address: 0x10f4f20 | Name: _ZN3RBX19HumanoidDescription31forEachClothesBodyPartAssetTypeERKNSt3__18functionIFvNS_12AssetService9AssetTypeEEEE
void __fastcall RBX::HumanoidDescription::forEachClothesBodyPartAssetType(
        const std::function<void (RBX::AssetService::AssetType)>_0 *callback)
{
  boost::unordered::detail::ptr_bucket::link_pointer i; // rbx
  std::function<void (RBX::AssetService::AssetType)>::__base *f; // rdi
  _QWORD *exception; // rax
  _DWORD v5[7]; // [rsp+Ch] [rbp-1Ch] BYREF

  if ( stru_2A0A4D8.table_.size_ )
  {
    for ( i = stru_2A0A4D8.table_.buckets_[stru_2A0A4D8.table_.bucket_count_].next_; i; i = i->next_ )
    {
      v5[0] = i[2].next_;
      f = callback->__f_;
      if ( !f )
      {
        exception = __cxa_allocate_exception(8u);
        *exception = off_28852C8;
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'std::bad_function_call,
          (void (*)(void *))&std::exception::~exception);
      }
      (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType)>::__base *, _DWORD *))f->_vptr$__base
       + 6))(
        f,
        v5);
    }
  }
}


// Address: 0x10f4fc0 | Name: _ZN3RBX19HumanoidDescription21createFromAvatarFetchERKN5boost10shared_ptrIKNS1_9unordered13unordered_mapINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_10Reflection7VariantENS1_4hashISB_EENS5_8equal_toISB_EENS9_INS5_4pairIKSB_SD_EEEEEEEE
RBX::Color3 **__fastcall RBX::HumanoidDescription::createFromAvatarFetch(
        RBX::Color3 **a1,
        const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *characterAppearanceTable)
{
  std::function<void (long,RBX::AssetService::AssetType)> func; // [rsp+10h] [rbp-58h] BYREF
  unsigned __int64 v5; // [rsp+40h] [rbp-28h]

  v5 = __readfsqword(0x28u);
  RBX::Creatable<RBX::Instance>::create<RBX::HumanoidDescription>();
  RBX::AvatarFetchParser::parseScaleAll(
    characterAppearanceTable,
    &(*a1)[12].r,
    &(*a1)[12].g,
    &(*a1)[12].b,
    &(*a1)[13].r,
    &(*a1)[13].b,
    &(*a1)[13].g);
  RBX::AvatarFetchParser::parseBodyColors(
    characterAppearanceTable,
    *a1 + 14,
    *a1 + 17,
    *a1 + 16,
    *a1 + 15,
    *a1 + 19,
    *a1 + 18);
  RBX::AvatarFetchParser::parseAnimations(
    characterAppearanceTable,
    (int64_t *)&(*a1)[58].b,
    (int64_t *)&(*a1)[59].g,
    (int64_t *)&(*a1)[60],
    (int64_t *)&(*a1)[60].b,
    (int64_t *)&(*a1)[61].g,
    (int64_t *)&(*a1)[62],
    (int64_t *)&(*a1)[62].b);
  RBX::AvatarFetchParser::parseEmotes(
    characterAppearanceTable,
    (boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > *)&(*a1)[63].g,
    (boost::unordered::unordered_map<int,std::string,boost::hash<int>,std::equal_to<int>,std::allocator<std::pair<const int,std::string > > > *)&(*a1)[67].g,
    (int *)&(*a1)[71].g);
  *(_QWORD *)func.__buf_.__lx = &off_28978E8;
  *(_QWORD *)&func.__buf_.__lx[8] = a1;
  func.__f_ = (std::function<void (long,RBX::AssetService::AssetType)>::__base *)&func;
  RBX::AvatarFetchParser::parseEachAccessory(characterAppearanceTable, &func);
  if ( &func == (std::function<void (long,RBX::AssetService::AssetType)> *)func.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (long,RBX::AssetService::AssetType)>::__base *))func.__f_->_vptr$__base
     + 4))(func.__f_);
  }
  else if ( func.__f_ )
  {
    (*((void (**)(void))func.__f_->_vptr$__base + 5))();
  }
  return a1;
}


// Address: 0x10f5180 | Name: _ZN3RBX19HumanoidDescription30createFromAvatarFetchThumbnailERKN5boost10shared_ptrIKNS1_9unordered13unordered_mapINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_10Reflection7VariantENS1_4hashISB_EENS5_8equal_toISB_EENS9_INS5_4pairIKSB_SD_EEEEEEEE
RBX::Color3 **__fastcall RBX::HumanoidDescription::createFromAvatarFetchThumbnail(
        RBX::Color3 **a1,
        const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *characterAppearanceTable)
{
  RBX::Creatable<RBX::Instance>::create<RBX::HumanoidDescription>();
  RBX::AvatarFetchParser::parseThumbnailScales(
    characterAppearanceTable,
    &(*a1)[12].r,
    &(*a1)[12].g,
    &(*a1)[12].b,
    &(*a1)[13].r,
    &(*a1)[13].b,
    &(*a1)[13].g);
  RBX::AvatarFetchParser::parseThumbnailBodyColors(
    characterAppearanceTable,
    *a1 + 14,
    *a1 + 17,
    *a1 + 16,
    *a1 + 15,
    *a1 + 19,
    *a1 + 18);
  return a1;
}


// Address: 0x10f5250 | Name: _ZN3RBX19HumanoidDescription21createFromOutfitFetchERKN5boost10shared_ptrIKNS1_9unordered13unordered_mapINSt3__112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEENS_10Reflection7VariantENS1_4hashISB_EENS5_8equal_toISB_EENS9_INS5_4pairIKSB_SD_EEEEEEEE
RBX::Color3 **__fastcall RBX::HumanoidDescription::createFromOutfitFetch(
        RBX::Color3 **a1,
        const boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > > *characterAppearanceTable)
{
  std::function<void (long,RBX::AssetService::AssetType)> func; // [rsp+10h] [rbp-58h] BYREF
  unsigned __int64 v5; // [rsp+48h] [rbp-20h]

  v5 = __readfsqword(0x28u);
  RBX::Creatable<RBX::Instance>::create<RBX::HumanoidDescription>();
  RBX::OutfitFetchParser::parseScaleAll(
    characterAppearanceTable,
    &(*a1)[12].r,
    &(*a1)[12].g,
    &(*a1)[12].b,
    &(*a1)[13].r,
    &(*a1)[13].b,
    &(*a1)[13].g);
  RBX::AvatarFetchParser::parseBodyColors(
    characterAppearanceTable,
    *a1 + 14,
    *a1 + 17,
    *a1 + 16,
    *a1 + 15,
    *a1 + 19,
    *a1 + 18);
  RBX::OutfitFetchParser::parseAnimations(
    characterAppearanceTable,
    (int64_t *)&(*a1)[58].b,
    (int64_t *)&(*a1)[59].g,
    (int64_t *)&(*a1)[60],
    (int64_t *)&(*a1)[60].b,
    (int64_t *)&(*a1)[61].g,
    (int64_t *)&(*a1)[62],
    (int64_t *)&(*a1)[62].b);
  *(_QWORD *)func.__buf_.__lx = &off_2897968;
  *(_QWORD *)&func.__buf_.__lx[8] = a1;
  func.__f_ = (std::function<void (long,RBX::AssetService::AssetType)>::__base *)&func;
  RBX::OutfitFetchParser::parseEachAsset(characterAppearanceTable, &func);
  if ( &func == (std::function<void (long,RBX::AssetService::AssetType)> *)func.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (long,RBX::AssetService::AssetType)>::__base *))func.__f_->_vptr$__base
     + 4))(func.__f_);
  }
  else if ( func.__f_ )
  {
    (*((void (**)(void))func.__f_->_vptr$__base + 5))();
  }
  return a1;
}


// Address: 0x10f53f0 | Name: _ZN3RBX19HumanoidDescription21createAssetsFromFetchElNS_12AssetService9AssetTypeERS0_
void __fastcall RBX::HumanoidDescription::createAssetsFromFetch(
        int64_t asset,
        RBX::AssetService::AssetType type,
        RBX::HumanoidDescription *newInst)
{
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  boost::unordered::detail::ptr_bucket::link_pointer i; // rcx
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesHat; // r9
  int64_t v6; // [rsp+0h] [rbp-8h] BYREF

  v6 = asset;
  if ( stru_2A0A4D8.table_.size_ )
  {
    next = stru_2A0A4D8.table_.buckets_[(int)type % stru_2A0A4D8.table_.bucket_count_].next_;
    if ( next )
    {
      for ( i = next->next_; i; i = i->next_ )
      {
        if ( i[1].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)type )
        {
          if ( LODWORD(i[2].next_) == type )
          {
            RBX::HumanoidDescription::setSingleEquipAssetsByType(newInst, type, asset);
            return;
          }
        }
        else if ( (unsigned __int64)i[1].next_ % stru_2A0A4D8.table_.bucket_count_ != (int)type
                                                                                    % stru_2A0A4D8.table_.bucket_count_ )
        {
          break;
        }
      }
    }
  }
  switch ( type )
  {
    case RBX::AssetService::AssetType::HAT:
      p_accessoriesHat = &newInst->accessoriesHat;
      goto LABEL_19;
    case RBX::AssetService::AssetType::HAIR_ACCESSORY:
      p_accessoriesHat = &newInst->accessoriesHair;
      goto LABEL_19;
    case RBX::AssetService::AssetType::FACE_ACCESSORY:
      p_accessoriesHat = &newInst->accessoriesFace;
      goto LABEL_19;
    case RBX::AssetService::AssetType::NECK_ACCESSORY:
      p_accessoriesHat = &newInst->accessoriesNeck;
      goto LABEL_19;
    case RBX::AssetService::AssetType::SHOULDER_ACCESSORY:
      p_accessoriesHat = &newInst->accessoriesShoulders;
      goto LABEL_19;
    case RBX::AssetService::AssetType::FRONT_ACCESSORY:
      p_accessoriesHat = &newInst->accessoriesFront;
      goto LABEL_19;
    case RBX::AssetService::AssetType::BACK_ACCESSORY:
      p_accessoriesHat = &newInst->accessoriesBack;
      goto LABEL_19;
    case RBX::AssetService::AssetType::WAIST_ACCESSORY:
      p_accessoriesHat = &newInst->accessoriesWaist;
LABEL_19:
      boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::emplace_impl<long const&>(
        &p_accessoriesHat->table_,
        &v6,
        &v6);
      break;
    default:
      return;
  }
}


// Address: 0x10f54f0 | Name: _ZN3RBX19HumanoidDescription26setSingleEquipAssetsByTypeENS_12AssetService9AssetTypeEl
void __fastcall RBX::HumanoidDescription::setSingleEquipAssetsByType(
        RBX::HumanoidDescription *this,
        RBX::AssetService::AssetType type,
        int64_t newVal)
{
  switch ( type )
  {
    case RBX::AssetService::AssetType::TEE_SHIRT:
      if ( this->clothesGraphicTShirt != newVal )
      {
        this->clothesGraphicTShirt = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09BB0);
      }
      break;
    case RBX::AssetService::AssetType::SHIRT:
      if ( this->clothesShirt != newVal )
      {
        this->clothesShirt = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09B00);
      }
      break;
    case RBX::AssetService::AssetType::PANTS:
      if ( this->clothesPants != newVal )
      {
        this->clothesPants = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09B58);
      }
      break;
    case RBX::AssetService::AssetType::HEAD:
      if ( this->bodyPartsHead != newVal )
      {
        this->bodyPartsHead = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09C60);
      }
      break;
    case RBX::AssetService::AssetType::FACE:
      if ( this->bodyPartsFace != newVal )
      {
        this->bodyPartsFace = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09C08);
      }
      break;
    case RBX::AssetService::AssetType::TORSO:
      if ( this->bodyPartsTorso != newVal )
      {
        this->bodyPartsTorso = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09CB8);
      }
      break;
    case RBX::AssetService::AssetType::RIGHT_ARM:
      if ( this->bodyPartsRightArm != newVal )
      {
        this->bodyPartsRightArm = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09D68);
      }
      break;
    case RBX::AssetService::AssetType::LEFT_ARM:
      if ( this->bodyPartsLeftArm != newVal )
      {
        this->bodyPartsLeftArm = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09D10);
      }
      break;
    case RBX::AssetService::AssetType::LEFT_LEG:
      if ( this->bodyPartsLeftLeg != newVal )
      {
        this->bodyPartsLeftLeg = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09DC0);
      }
      break;
    case RBX::AssetService::AssetType::RIGHT_LEG:
      if ( this->bodyPartsRightLeg != newVal )
      {
        this->bodyPartsRightLeg = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09E18);
      }
      break;
    case RBX::AssetService::AssetType::CLIMB_ANIMATION:
      if ( this->animationClimb != newVal )
      {
        this->animationClimb = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A0A028);
      }
      break;
    case RBX::AssetService::AssetType::FALL_ANIMATION:
      if ( this->animationFall != newVal )
      {
        this->animationFall = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09F20);
      }
      break;
    case RBX::AssetService::AssetType::IDLE_ANIMATION:
      if ( this->animationIdle != newVal )
      {
        this->animationIdle = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A0A080);
      }
      break;
    case RBX::AssetService::AssetType::JUMP_ANIMATION:
      if ( this->animationJump != newVal )
      {
        this->animationJump = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09F78);
      }
      break;
    case RBX::AssetService::AssetType::RUN_ANIMATION:
      if ( this->animationRun != newVal )
      {
        this->animationRun = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09EC8);
      }
      break;
    case RBX::AssetService::AssetType::SWIM_ANIMATION:
      if ( this->animationSwim != newVal )
      {
        this->animationSwim = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09FD0);
      }
      break;
    case RBX::AssetService::AssetType::WALK_ANIMATION:
      if ( this->animationWalk != newVal )
      {
        this->animationWalk = newVal;
        RBX::Instance::raisePropertyChanged(this, &stru_2A09E70);
      }
      break;
    default:
      return;
  }
}


// Address: 0x10f5720 | Name: _ZNK3RBX19HumanoidDescription21forEachAnimationAssetERKNSt3__18functionIFvNS_12AssetService9AssetTypeElEEE
void __fastcall RBX::HumanoidDescription::forEachAnimationAsset(
        const RBX::HumanoidDescription *this,
        const std::function<void (RBX::AssetService::AssetType,long)> *func)
{
  int64_t animationWalk; // rax
  int64_t animationRun; // rbx
  int64_t animationFall; // r12
  int64_t animationJump; // r15
  std::function<void (RBX::AssetService::AssetType,long)>::__base *f; // rdi
  std::function<void (RBX::AssetService::AssetType,long)>::__base *v7; // rdi
  std::function<void (RBX::AssetService::AssetType,long)>::__base *v8; // rdi
  std::function<void (RBX::AssetService::AssetType,long)>::__base *v9; // rdi
  std::function<void (RBX::AssetService::AssetType,long)>::__base *v10; // rdi
  std::function<void (RBX::AssetService::AssetType,long)>::__base *v11; // rdi
  std::function<void (RBX::AssetService::AssetType,long)>::__base *v12; // rdi
  _QWORD *exception; // rax
  int v14; // [rsp+4h] [rbp-A4h] BYREF
  int64_t v15; // [rsp+8h] [rbp-A0h] BYREF
  int v16; // [rsp+10h] [rbp-98h]
  int64_t v17; // [rsp+18h] [rbp-90h]
  int v18; // [rsp+20h] [rbp-88h]
  int64_t v19; // [rsp+28h] [rbp-80h]
  int v20; // [rsp+30h] [rbp-78h]
  int64_t v21; // [rsp+38h] [rbp-70h]
  int v22; // [rsp+40h] [rbp-68h]
  int64_t v23; // [rsp+48h] [rbp-60h]
  int v24; // [rsp+50h] [rbp-58h]
  int64_t animationSwim; // [rsp+58h] [rbp-50h]
  int v26; // [rsp+60h] [rbp-48h]
  int64_t animationClimb; // [rsp+68h] [rbp-40h]
  int v28; // [rsp+70h] [rbp-38h]
  int64_t animationIdle; // [rsp+78h] [rbp-30h]

  v16 = 55;
  animationWalk = this->animationWalk;
  v17 = animationWalk;
  v18 = 53;
  animationRun = this->animationRun;
  v19 = animationRun;
  v20 = 50;
  animationFall = this->animationFall;
  v21 = animationFall;
  v22 = 52;
  animationJump = this->animationJump;
  v23 = animationJump;
  v24 = 54;
  animationSwim = this->animationSwim;
  v26 = 48;
  animationClimb = this->animationClimb;
  v28 = 51;
  animationIdle = this->animationIdle;
  if ( animationWalk > 0 )
  {
    v14 = 55;
    v15 = animationWalk;
    f = func->__f_;
    if ( !f )
      goto LABEL_23;
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *, int *, int64_t *))f->_vptr$__base
     + 6))(
      f,
      &v14,
      &v15);
  }
  if ( animationRun > 0 )
  {
    v14 = 53;
    v15 = animationRun;
    v7 = func->__f_;
    if ( !v7 )
      goto LABEL_23;
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *, int *, int64_t *))v7->_vptr$__base
     + 6))(
      v7,
      &v14,
      &v15);
  }
  if ( animationFall > 0 )
  {
    v14 = 50;
    v15 = animationFall;
    v8 = func->__f_;
    if ( !v8 )
      goto LABEL_23;
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *, int *, int64_t *))v8->_vptr$__base
     + 6))(
      v8,
      &v14,
      &v15);
  }
  if ( animationJump > 0 )
  {
    v14 = 52;
    v15 = animationJump;
    v9 = func->__f_;
    if ( !v9 )
      goto LABEL_23;
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *, int *, int64_t *))v9->_vptr$__base
     + 6))(
      v9,
      &v14,
      &v15);
  }
  if ( animationSwim > 0 )
  {
    v14 = 54;
    v15 = animationSwim;
    v10 = func->__f_;
    if ( !v10 )
      goto LABEL_23;
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *, int *, int64_t *))v10->_vptr$__base
     + 6))(
      v10,
      &v14,
      &v15);
  }
  if ( animationClimb > 0 )
  {
    v14 = v26;
    v15 = animationClimb;
    v11 = func->__f_;
    if ( !v11 )
      goto LABEL_23;
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *, int *, int64_t *))v11->_vptr$__base
     + 6))(
      v11,
      &v14,
      &v15);
  }
  if ( animationIdle <= 0 )
    return;
  v14 = v28;
  v15 = animationIdle;
  v12 = func->__f_;
  if ( !v12 )
  {
LABEL_23:
    exception = __cxa_allocate_exception(8u);
    *exception = off_28852C8;
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::bad_function_call,
      (void (*)(void *))&std::exception::~exception);
  }
  (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *, int *, int64_t *))v12->_vptr$__base
   + 6))(
    v12,
    &v14,
    &v15);
}


// Address: 0x10f5950 | Name: _ZN3RBX19HumanoidDescription10isAssetSetEl
bool __fastcall RBX::HumanoidDescription::isAssetSet(int64_t assetId)
{
  return assetId > 0;
}


// Address: 0x10f5960 | Name: _ZNK3RBX19HumanoidDescription21forEachAccessoryAssetERKNSt3__18functionIFvNS_12AssetService9AssetTypeElEEE
void __fastcall RBX::HumanoidDescription::forEachAccessoryAsset(
        const RBX::HumanoidDescription *this,
        const std::function<void (RBX::AssetService::AssetType,long)> *func)
{
  int *v2; // rbx
  _QWORD *v3; // rax
  _QWORD *i; // rbp
  __int64 v5; // rax
  std::function<void (RBX::AssetService::AssetType,long)>::__base *f; // rdi
  _QWORD *exception; // rax
  int v8; // [rsp+4h] [rbp-C4h] BYREF
  __int64 v9; // [rsp+8h] [rbp-C0h] BYREF
  int v10; // [rsp+10h] [rbp-B8h] BYREF
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesHat; // [rsp+18h] [rbp-B0h]
  int v12; // [rsp+20h] [rbp-A8h]
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesHair; // [rsp+28h] [rbp-A0h]
  int v14; // [rsp+30h] [rbp-98h]
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesFace; // [rsp+38h] [rbp-90h]
  int v16; // [rsp+40h] [rbp-88h]
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesNeck; // [rsp+48h] [rbp-80h]
  int v18; // [rsp+50h] [rbp-78h]
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesShoulders; // [rsp+58h] [rbp-70h]
  int v20; // [rsp+60h] [rbp-68h]
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesFront; // [rsp+68h] [rbp-60h]
  int v22; // [rsp+70h] [rbp-58h]
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesBack; // [rsp+78h] [rbp-50h]
  int v24; // [rsp+80h] [rbp-48h]
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesWaist; // [rsp+88h] [rbp-40h]
  char v26; // [rsp+90h] [rbp-38h] BYREF

  v2 = &v10;
  v10 = 8;
  p_accessoriesHat = &this->accessoriesHat;
  v12 = 41;
  p_accessoriesHair = &this->accessoriesHair;
  v14 = 42;
  p_accessoriesFace = &this->accessoriesFace;
  v16 = 43;
  p_accessoriesNeck = &this->accessoriesNeck;
  v18 = 44;
  p_accessoriesShoulders = &this->accessoriesShoulders;
  v20 = 45;
  p_accessoriesFront = &this->accessoriesFront;
  v22 = 46;
  p_accessoriesBack = &this->accessoriesBack;
  v24 = 47;
  p_accessoriesWaist = &this->accessoriesWaist;
  do
  {
    v3 = (_QWORD *)*((_QWORD *)v2 + 1);
    if ( v3[2] )
    {
      for ( i = *(_QWORD **)(v3[5] + 8LL * v3[1]); i; i = (_QWORD *)*i )
      {
        v5 = i[2];
        if ( v5 > 0 )
        {
          v8 = *v2;
          v9 = v5;
          f = func->__f_;
          if ( !f )
          {
            exception = __cxa_allocate_exception(8u);
            *exception = off_28852C8;
            __cxa_throw(
              exception,
              (struct type_info *)&`typeinfo for'std::bad_function_call,
              (void (*)(void *))&std::exception::~exception);
          }
          (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *, int *, __int64 *))f->_vptr$__base
           + 6))(
            f,
            &v8,
            &v9);
        }
      }
    }
    v2 += 4;
  }
  while ( v2 != (int *)&v26 );
}


// Address: 0x10f5af0 | Name: _ZNK3RBX19HumanoidDescription19forEachCostumeAssetERKNSt3__18functionIFvNS_12AssetService9AssetTypeElEEE
void __fastcall RBX::HumanoidDescription::forEachCostumeAsset(
        const RBX::HumanoidDescription *this,
        const std::function<void (RBX::AssetService::AssetType,long)> *func)
{
  _QWORD *v3; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx
  _QWORD *exception; // rax
  int v6; // [rsp+Ch] [rbp-6Ch] BYREF
  _QWORD v7[4]; // [rsp+10h] [rbp-68h] BYREF
  _QWORD *v8; // [rsp+30h] [rbp-48h]
  unsigned __int64 v9; // [rsp+48h] [rbp-30h]

  v9 = __readfsqword(0x28u);
  v7[0] = &off_28979E8;
  v7[1] = this;
  v7[2] = func;
  v8 = v7;
  v3 = v7;
  if ( stru_2A0A4D8.table_.size_ )
  {
    next = stru_2A0A4D8.table_.buckets_[stru_2A0A4D8.table_.bucket_count_].next_;
    v3 = v7;
    if ( next )
    {
      v3 = v7;
      do
      {
        v6 = (int)next[2].next_;
        if ( !v3 )
        {
          exception = __cxa_allocate_exception(8u);
          *exception = off_28852C8;
          __cxa_throw(
            exception,
            (struct type_info *)&`typeinfo for'std::bad_function_call,
            (void (*)(void *))&std::exception::~exception);
        }
        (*(void (__fastcall **)(_QWORD *, int *))(*v3 + 48LL))(v3, &v6);
        next = next->next_;
        v3 = v8;
      }
      while ( next );
    }
  }
  if ( v7 == v3 )
  {
    (*(void (__fastcall **)(_QWORD *))(*v3 + 32LL))(v3);
  }
  else if ( v3 )
  {
    (*(void (__fastcall **)(_QWORD *))(*v3 + 40LL))(v3);
  }
  RBX::HumanoidDescription::forEachAccessoryAsset(this, func);
  RBX::HumanoidDescription::forEachAnimationAsset(this, func);
}


// Address: 0x10f5c50 | Name: _ZN3RBX19HumanoidDescription11nullAssetIdEv
int64_t __cdecl RBX::HumanoidDescription::nullAssetId()
{
  return 0;
}


// Address: 0x10f5c60 | Name: _ZN3RBX19HumanoidDescription32calculateCostumeAssetsComparisonERKN5boost10shared_ptrIS0_EES5_RNS1_9unordered13unordered_setIlNS1_4hashIlEENSt3__18equal_toIlEENSA_9allocatorIlEEEE
void __fastcall RBX::HumanoidDescription::calculateCostumeAssetsComparison(
        const boost::shared_ptr<RBX::HumanoidDescription> *descriptionFrom,
        const boost::shared_ptr<RBX::HumanoidDescription> *descriptionTo,
        boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *toAssetsOnly)
{
  const boost::unordered::detail::false_type *v5; // rax
  __int64 v6; // rcx
  const boost::unordered::detail::false_type *v7; // rdx
  __int64 v8; // rsi
  const boost::unordered::detail::false_type *v9; // rdx
  boost::shared_ptr<RBX::HumanoidDescription>::element_type *px; // rdi
  size_t bucket_count; // r15
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi
  size_t v14; // rdx
  boost::shared_ptr<RBX::HumanoidDescription>::element_type *v15; // rdi
  __int64 *i; // rbx
  _QWORD *v17; // r14
  __int64 v18; // rbx
  _QWORD *v19; // rdi
  char v20; // [rsp+0h] [rbp-98h] BYREF
  __int64 v21; // [rsp+8h] [rbp-90h]
  __int64 v22; // [rsp+10h] [rbp-88h]
  int v23; // [rsp+18h] [rbp-80h]
  void *ptr[2]; // [rsp+20h] [rbp-78h]
  std::function<void (RBX::AssetService::AssetType,long)> func; // [rsp+30h] [rbp-68h] BYREF
  unsigned __int64 v26; // [rsp+68h] [rbp-30h]

  v26 = __readfsqword(0x28u);
  v20 = 0;
  v5 = &stru_495510;
  v6 = 38;
  do
  {
    v7 = v5;
    v8 = v6 + ~(v6 / 2);
    if ( *(_QWORD *)&v5[8 * (v6 / 2)].gap0 >= 0xBu )
      v8 = v6 / 2;
    v5 += 8 * (v6 / 2) + 8;
    if ( *(_QWORD *)&v7[8 * (v6 / 2)].gap0 >= 0xBu )
      v5 = v7;
    v6 = v8;
  }
  while ( v8 );
  v9 = v5 - 8;
  if ( v5 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v9 = v5;
  v21 = *(_QWORD *)&v9->gap0;
  v22 = 0;
  v23 = 1065353216;
  *(_OWORD *)ptr = 0;
  px = descriptionFrom->px;
  if ( px )
  {
    *(_QWORD *)func.__buf_.__lx = &off_2897CE8;
    *(_QWORD *)&func.__buf_.__lx[8] = &v20;
    func.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&func;
    RBX::HumanoidDescription::forEachCostumeAsset(px, &func);
    if ( &func == (std::function<void (RBX::AssetService::AssetType,long)> *)func.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
       + 4))(func.__f_);
      if ( !toAssetsOnly->table_.size_ )
        goto LABEL_18;
      goto LABEL_14;
    }
    if ( func.__f_ )
      (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
       + 5))(func.__f_);
  }
  if ( !toAssetsOnly->table_.size_ )
    goto LABEL_18;
LABEL_14:
  bucket_count = toAssetsOnly->table_.bucket_count_;
  buckets = toAssetsOnly->table_.buckets_;
  next = buckets[bucket_count].next_;
  do
  {
    buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
    operator delete(next);
    --toAssetsOnly->table_.size_;
    next = buckets[bucket_count].next_;
  }
  while ( next );
  v14 = toAssetsOnly->table_.bucket_count_;
  if ( v14 )
    memset(toAssetsOnly->table_.buckets_, 0, 8 * v14);
LABEL_18:
  v15 = descriptionTo->px;
  if ( descriptionTo->px )
  {
    *(_QWORD *)func.__buf_.__lx = &off_2897CE8;
    *(_QWORD *)&func.__buf_.__lx[8] = toAssetsOnly;
    func.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&func;
    RBX::HumanoidDescription::forEachCostumeAsset(v15, &func);
    if ( &func == (std::function<void (RBX::AssetService::AssetType,long)> *)func.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
       + 4))(func.__f_);
      if ( !v22 )
        goto LABEL_30;
      goto LABEL_23;
    }
    if ( func.__f_ )
      (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
       + 5))(func.__f_);
  }
  if ( !v22 )
    goto LABEL_30;
LABEL_23:
  for ( i = (__int64 *)*((_QWORD *)ptr[1] + v21); i; i = (__int64 *)*i )
    boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::erase_key(
      &toAssetsOnly->table_,
      i + 2);
LABEL_30:
  v17 = ptr[1];
  if ( ptr[1] )
  {
    if ( v22 )
    {
      v18 = v21;
      v19 = (_QWORD *)*((_QWORD *)ptr[1] + v21);
      do
      {
        v17[v18] = *v19;
        operator delete(v19);
        --v22;
        v19 = (_QWORD *)v17[v18];
      }
      while ( v19 );
      v17 = ptr[1];
    }
    operator delete(v17);
  }
}


// Address: 0x10f5f40 | Name: _ZNK3RBX19HumanoidDescription24getHumanoidCostumeAssetsERN5boost9unordered13unordered_setIlNS1_4hashIlEENSt3__18equal_toIlEENS6_9allocatorIlEEEE
void __fastcall RBX::HumanoidDescription::getHumanoidCostumeAssets(
        const RBX::HumanoidDescription *this,
        boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *assets)
{
  std::function<void (RBX::AssetService::AssetType,long)> v2; // [rsp+0h] [rbp-48h] BYREF
  unsigned __int64 v3; // [rsp+30h] [rbp-18h]

  v3 = __readfsqword(0x28u);
  *(_QWORD *)v2.__buf_.__lx = &off_2897CE8;
  *(_QWORD *)&v2.__buf_.__lx[8] = assets;
  v2.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&v2;
  RBX::HumanoidDescription::forEachCostumeAsset(this, &v2);
  if ( &v2 == (std::function<void (RBX::AssetService::AssetType,long)> *)v2.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))v2.__f_->_vptr$__base + 4))(v2.__f_);
  }
  else if ( v2.__f_ )
  {
    (*((void (**)(void))v2.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x10f5fe0 | Name: _ZN3RBX19HumanoidDescription38checkCommonCostumeAssetsAreTheSameTypeERKN5boost10shared_ptrIS0_EES5_
bool __fastcall RBX::HumanoidDescription::checkCommonCostumeAssetsAreTheSameType(
        const boost::shared_ptr<RBX::HumanoidDescription> *descriptionFrom,
        const boost::shared_ptr<RBX::HumanoidDescription> *descriptionTo)
{
  boost::shared_ptr<RBX::HumanoidDescription>::element_type *px; // rdi
  char v3; // r12
  const boost::unordered::detail::false_type *v5; // rax
  __int64 v6; // rcx
  const boost::unordered::detail::false_type *v7; // rdx
  __int64 v8; // rsi
  const boost::unordered::detail::false_type *v9; // rdx
  boost::shared_ptr<RBX::HumanoidDescription>::element_type *v10; // rdi
  _QWORD *v11; // rbx
  __int64 v12; // rbp
  _QWORD *v13; // rdi
  char v15; // [rsp+Fh] [rbp-99h] BYREF
  char v16; // [rsp+10h] [rbp-98h] BYREF
  __int64 v17; // [rsp+18h] [rbp-90h]
  __int64 v18; // [rsp+20h] [rbp-88h]
  int v19; // [rsp+28h] [rbp-80h]
  void *ptr[2]; // [rsp+30h] [rbp-78h]
  std::function<void (RBX::AssetService::AssetType,long)> func; // [rsp+40h] [rbp-68h] BYREF
  unsigned __int64 v22; // [rsp+78h] [rbp-30h]

  v22 = __readfsqword(0x28u);
  px = descriptionFrom->px;
  v3 = 1;
  if ( px && descriptionTo->px )
  {
    v16 = 0;
    v5 = &stru_495510;
    v6 = 38;
    do
    {
      v7 = v5;
      v8 = v6 + ~(v6 / 2);
      if ( *(_QWORD *)&v5[8 * (v6 / 2)].gap0 >= 0xBu )
        v8 = v6 / 2;
      v5 += 8 * (v6 / 2) + 8;
      if ( *(_QWORD *)&v7[8 * (v6 / 2)].gap0 >= 0xBu )
        v5 = v7;
      v6 = v8;
    }
    while ( v8 );
    v9 = v5 - 8;
    if ( v5 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS"
                                                             "0_5list1INS0_5valueIPS5_EEEEEE" )
      v9 = v5;
    v17 = *(_QWORD *)&v9->gap0;
    v18 = 0;
    v19 = 1065353216;
    *(_OWORD *)ptr = 0;
    *(_QWORD *)func.__buf_.__lx = &off_2897D68;
    *(_QWORD *)&func.__buf_.__lx[8] = &v16;
    func.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&func;
    RBX::HumanoidDescription::forEachCostumeAsset(px, &func);
    if ( &func == (std::function<void (RBX::AssetService::AssetType,long)> *)func.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
       + 4))(func.__f_);
    }
    else if ( func.__f_ )
    {
      (*((void (**)(void))func.__f_->_vptr$__base + 5))();
    }
    v15 = 1;
    v10 = descriptionTo->px;
    *(_QWORD *)func.__buf_.__lx = &off_2897A68;
    *(_QWORD *)&func.__buf_.__lx[8] = &v16;
    *(_QWORD *)&func.__buf_.__lx[16] = &v15;
    func.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&func;
    RBX::HumanoidDescription::forEachCostumeAsset(v10, &func);
    if ( &func == (std::function<void (RBX::AssetService::AssetType,long)> *)func.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
       + 4))(func.__f_);
    }
    else if ( func.__f_ )
    {
      (*((void (**)(void))func.__f_->_vptr$__base + 5))();
    }
    v3 = v15 != 0;
    v11 = ptr[1];
    if ( ptr[1] )
    {
      if ( v18 )
      {
        v12 = v17;
        v13 = (_QWORD *)*((_QWORD *)ptr[1] + v17);
        do
        {
          v11[v12] = *v13;
          operator delete(v13);
          --v18;
          v13 = (_QWORD *)v11[v12];
        }
        while ( v13 );
        v11 = ptr[1];
      }
      operator delete(v11);
      *(_OWORD *)ptr = 0;
    }
  }
  return v3;
}


// Address: 0x10f6240 | Name: _ZNK3RBX19HumanoidDescription24getHumanoidCostumeAssetsERN5boost9unordered13unordered_mapIlNS_12AssetService9AssetTypeENS1_4hashIlEENSt3__18equal_toIlEENS8_9allocatorINS8_4pairIKlS5_EEEEEE
void __fastcall RBX::HumanoidDescription::getHumanoidCostumeAssets(
        const RBX::HumanoidDescription *this,
        boost::unordered::unordered_map<long,RBX::AssetService::AssetType,boost::hash<long>,std::equal_to<long>,std::allocator<std::pair<const long,RBX::AssetService::AssetType> > > *assets)
{
  std::function<void (RBX::AssetService::AssetType,long)> v2; // [rsp+0h] [rbp-48h] BYREF
  unsigned __int64 v3; // [rsp+30h] [rbp-18h]

  v3 = __readfsqword(0x28u);
  *(_QWORD *)v2.__buf_.__lx = &off_2897D68;
  *(_QWORD *)&v2.__buf_.__lx[8] = assets;
  v2.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&v2;
  RBX::HumanoidDescription::forEachCostumeAsset(this, &v2);
  if ( &v2 == (std::function<void (RBX::AssetService::AssetType,long)> *)v2.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))v2.__f_->_vptr$__base + 4))(v2.__f_);
  }
  else if ( v2.__f_ )
  {
    (*((void (**)(void))v2.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x10f62e0 | Name: _ZNK3RBX19HumanoidDescription35checkContainsDuplicateCostumeAssetsEv
bool __fastcall RBX::HumanoidDescription::checkContainsDuplicateCostumeAssets(const RBX::HumanoidDescription *this)
{
  const boost::unordered::detail::false_type *v1; // rax
  __int64 v2; // rcx
  const boost::unordered::detail::false_type *v3; // rdx
  __int64 v4; // rsi
  size_t *v5; // rdx
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // rbx
  bool v7; // r15
  size_t bucket_count; // rbp
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdi
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > assetsAppearingMoreThanOnce; // [rsp+8h] [rbp-50h] BYREF

  assetsAppearingMoreThanOnce.table_.current_ = 0;
  v1 = &stru_495510;
  v2 = 38;
  do
  {
    v3 = v1;
    v4 = v2 + ~(v2 / 2);
    if ( *(_QWORD *)&v1[8 * (v2 / 2)].gap0 >= 0xBu )
      v4 = v2 / 2;
    v1 += 8 * (v2 / 2) + 8;
    if ( *(_QWORD *)&v3[8 * (v2 / 2)].gap0 >= 0xBu )
      v1 = v3;
    v2 = v4;
  }
  while ( v4 );
  v5 = (size_t *)&v1[-8];
  if ( v1 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v5 = (size_t *)v1;
  assetsAppearingMoreThanOnce.table_.bucket_count_ = *v5;
  assetsAppearingMoreThanOnce.table_.size_ = 0;
  assetsAppearingMoreThanOnce.table_.mlf_ = 1.0;
  *(_OWORD *)&assetsAppearingMoreThanOnce.table_.max_load_ = 0;
  RBX::HumanoidDescription::getDuplicateCostumeAssets(this, &assetsAppearingMoreThanOnce);
  buckets = assetsAppearingMoreThanOnce.table_.buckets_;
  v7 = assetsAppearingMoreThanOnce.table_.size_ != 0;
  if ( assetsAppearingMoreThanOnce.table_.buckets_ )
  {
    if ( assetsAppearingMoreThanOnce.table_.size_ )
    {
      bucket_count = assetsAppearingMoreThanOnce.table_.bucket_count_;
      next = assetsAppearingMoreThanOnce.table_.buckets_[assetsAppearingMoreThanOnce.table_.bucket_count_].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --assetsAppearingMoreThanOnce.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = assetsAppearingMoreThanOnce.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&assetsAppearingMoreThanOnce.table_.max_load_ = 0;
  }
  return v7;
}


// Address: 0x10f6440 | Name: _ZNK3RBX19HumanoidDescription25getDuplicateCostumeAssetsERN5boost9unordered13unordered_setIlNS1_4hashIlEENSt3__18equal_toIlEENS6_9allocatorIlEEEE
void __fastcall RBX::HumanoidDescription::getDuplicateCostumeAssets(
        const RBX::HumanoidDescription *this,
        boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *assetsAppearingMoreThanOnce)
{
  const boost::unordered::detail::false_type *v2; // rax
  __int64 v3; // rcx
  const boost::unordered::detail::false_type *v4; // rdx
  __int64 v5; // rbx
  const boost::unordered::detail::false_type *v6; // rdx
  _QWORD *v7; // r14
  __int64 v8; // rbx
  _QWORD *v9; // rdi
  char v10; // [rsp+0h] [rbp-88h] BYREF
  __int64 v11; // [rsp+8h] [rbp-80h]
  __int64 v12; // [rsp+10h] [rbp-78h]
  int v13; // [rsp+18h] [rbp-70h]
  void *ptr[2]; // [rsp+20h] [rbp-68h]
  std::function<void (RBX::AssetService::AssetType,long)> func; // [rsp+30h] [rbp-58h] BYREF
  unsigned __int64 v16; // [rsp+60h] [rbp-28h]

  v16 = __readfsqword(0x28u);
  v10 = 0;
  v2 = &stru_495510;
  v3 = 38;
  do
  {
    v4 = v2;
    v5 = v3 + ~(v3 / 2);
    if ( *(_QWORD *)&v2[8 * (v3 / 2)].gap0 >= 0xBu )
      v5 = v3 / 2;
    v2 += 8 * (v3 / 2) + 8;
    if ( *(_QWORD *)&v4[8 * (v3 / 2)].gap0 >= 0xBu )
      v2 = v4;
    v3 = v5;
  }
  while ( v5 );
  v6 = v2 - 8;
  if ( v2 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v6 = v2;
  v11 = *(_QWORD *)&v6->gap0;
  v12 = 0;
  v13 = 1065353216;
  *(_OWORD *)ptr = 0;
  *(_QWORD *)func.__buf_.__lx = &off_2897AE8;
  *(_QWORD *)&func.__buf_.__lx[8] = &v10;
  *(_QWORD *)&func.__buf_.__lx[16] = assetsAppearingMoreThanOnce;
  func.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&func;
  RBX::HumanoidDescription::forEachCostumeAsset(this, &func);
  if ( &func == (std::function<void (RBX::AssetService::AssetType,long)> *)func.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
     + 4))(func.__f_);
  }
  else if ( func.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
     + 5))(func.__f_);
  }
  v7 = ptr[1];
  if ( ptr[1] )
  {
    if ( v12 )
    {
      v8 = v11;
      v9 = (_QWORD *)*((_QWORD *)ptr[1] + v11);
      do
      {
        v7[v8] = *v9;
        operator delete(v9);
        --v12;
        v9 = (_QWORD *)v7[v8];
      }
      while ( v9 );
      v7 = ptr[1];
    }
    operator delete(v7);
  }
}


// Address: 0x10f6610 | Name: _ZN3RBX19HumanoidDescription21setHumanoidBodyColorsERNS_8HumanoidE
void __fastcall RBX::HumanoidDescription::setHumanoidBodyColors(
        RBX::HumanoidDescription *this,
        RBX::Humanoid *humanoid)
{
  RBX::ModelInstance *CharacterFromHumanoid; // rax
  RBX::Instance *v3; // r14
  RBX::BodyColors ***v4; // rax
  RBX::BodyColors **v5; // rbx
  RBX::BodyColors **v6; // r13
  RBX::BodyColors *v7; // r12
  const RBX::Reflection::ClassDescriptor *descriptor; // rbp
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  float b; // ecx
  float v11; // ecx
  float v12; // ecx
  float v13; // ecx
  float v14; // ecx
  float v15; // ecx
  volatile signed __int32 *v16; // rbx
  float v17; // ecx
  float v18; // ecx
  float v19; // ecx
  float v20; // ecx
  float v21; // ecx
  float v22; // ecx
  RBX::CharacterAppearance *headColor; // [rsp+8h] [rbp-A0h] BYREF
  volatile signed __int32 *headColor_8; // [rsp+10h] [rbp-98h]
  RBX::Color3 rightLefColor; // [rsp+18h] [rbp-90h] BYREF
  RBX::Color3 leftLegColor; // [rsp+28h] [rbp-80h] BYREF
  RBX::Color3 torsoColor; // [rsp+38h] [rbp-70h] BYREF
  RBX::Color3 rightArmColor; // [rsp+48h] [rbp-60h] BYREF
  RBX::Color3 leftArmColor; // [rsp+58h] [rbp-50h] BYREF
  __int64 v30; // [rsp+68h] [rbp-40h]
  float v31; // [rsp+70h] [rbp-38h]

  CharacterFromHumanoid = RBX::Humanoid::getCharacterFromHumanoid(humanoid);
  if ( CharacterFromHumanoid )
  {
    v3 = (RBX::Instance *)CharacterFromHumanoid;
    v4 = (RBX::BodyColors ***)*((_QWORD *)CharacterFromHumanoid + 9);
    if ( !v4 || (v5 = *v4, v6 = v4[1], *v4 == v6) )
    {
LABEL_7:
      b = this->bodyColorHead.b;
      *(_QWORD *)&leftArmColor.r = *(_QWORD *)&this->bodyColorHead.r;
      leftArmColor.b = b;
      v11 = this->bodyColorLeftArm.b;
      *(_QWORD *)&rightArmColor.r = *(_QWORD *)&this->bodyColorLeftArm.r;
      rightArmColor.b = v11;
      v12 = this->bodyColorRightArm.b;
      *(_QWORD *)&torsoColor.r = *(_QWORD *)&this->bodyColorRightArm.r;
      torsoColor.b = v12;
      v13 = this->bodyColorTorso.b;
      *(_QWORD *)&leftLegColor.r = *(_QWORD *)&this->bodyColorTorso.r;
      leftLegColor.b = v13;
      v14 = this->bodyColorLeftLeg.b;
      *(_QWORD *)&rightLefColor.r = *(_QWORD *)&this->bodyColorLeftLeg.r;
      rightLefColor.b = v14;
      v15 = this->bodyColorRightLeg.b;
      v30 = *(_QWORD *)&this->bodyColorRightLeg.r;
      v31 = v15;
      RBX::BodyColors::create(
        (const RBX::Color3 *)&headColor,
        &leftArmColor,
        &rightArmColor,
        &torsoColor,
        &leftLegColor,
        &rightLefColor);
      RBX::Instance::setParentInternal(headColor, v3, 0);
      RBX::CharacterAppearance::apply(headColor);
      v16 = headColor_8;
      if ( headColor_8 && !_InterlockedSub(headColor_8 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
        if ( !_InterlockedSub(v16 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
      }
    }
    else
    {
      while ( 1 )
      {
        v7 = *v5;
        if ( *v5 )
        {
          descriptor = v7->descriptor;
          DescriptorPtr = Class_getDescriptorPtr(0);
          if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
            break;
        }
        v5 += 2;
        if ( v6 == v5 )
          goto LABEL_7;
      }
      v17 = this->bodyColorHead.b;
      headColor = *(RBX::CharacterAppearance **)&this->bodyColorHead.r;
      *(float *)&headColor_8 = v17;
      v18 = this->bodyColorLeftArm.b;
      *(_QWORD *)&leftArmColor.r = *(_QWORD *)&this->bodyColorLeftArm.r;
      leftArmColor.b = v18;
      v19 = this->bodyColorRightArm.b;
      *(_QWORD *)&rightArmColor.r = *(_QWORD *)&this->bodyColorRightArm.r;
      rightArmColor.b = v19;
      v20 = this->bodyColorTorso.b;
      *(_QWORD *)&torsoColor.r = *(_QWORD *)&this->bodyColorTorso.r;
      torsoColor.b = v20;
      v21 = this->bodyColorLeftLeg.b;
      *(_QWORD *)&leftLegColor.r = *(_QWORD *)&this->bodyColorLeftLeg.r;
      leftLegColor.b = v21;
      v22 = this->bodyColorRightLeg.b;
      *(_QWORD *)&rightLefColor.r = *(_QWORD *)&this->bodyColorRightLeg.r;
      rightLefColor.b = v22;
      RBX::BodyColors::set(
        v7,
        (const RBX::Color3 *)&headColor,
        &leftArmColor,
        &rightArmColor,
        &torsoColor,
        &leftLegColor,
        &rightLefColor);
      RBX::CharacterAppearance::apply(v7);
    }
  }
}


// Address: 0x10f6910 | Name: _ZN3RBX19HumanoidDescription38getHumanoidCostumeAssetRequirementURLsEPNS_9DataModelERNSt3__16vectorIN5boost10shared_ptrINS_24HumanoidAssetRequirementEEENS3_9allocatorIS8_EEEERNS4_INS_9ContentIdENS9_ISD_EEEE
void __fastcall RBX::HumanoidDescription::getHumanoidCostumeAssetRequirementURLs(
        RBX::HumanoidDescription *this,
        RBX::DataModel *dataModel,
        std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> *requirements,
        std::vector<RBX::ContentId> *URLs)
{
  std::function<void (RBX::AssetService::AssetType,long)> v5; // [rsp+0h] [rbp-58h] BYREF
  unsigned __int64 v6; // [rsp+30h] [rbp-28h]

  v6 = __readfsqword(0x28u);
  *(_QWORD *)v5.__buf_.__lx = &off_2897B68;
  *(_QWORD *)&v5.__buf_.__lx[8] = requirements;
  v5.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&v5;
  RBX::HumanoidDescription::forEachCostumeAsset(this, &v5);
  if ( &v5 == (std::function<void (RBX::AssetService::AssetType,long)> *)v5.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))v5.__f_->_vptr$__base + 4))(v5.__f_);
  }
  else if ( v5.__f_ )
  {
    (*((void (**)(void))v5.__f_->_vptr$__base + 5))();
  }
  RBX::HumanoidDescription::getHumanoidCostumeAssetURLs(this, dataModel, URLs, 0);
}


// Address: 0x10f69d0 | Name: _ZN3RBX19HumanoidDescription27getCostumeAssetRequirementsERNSt3__16vectorIN5boost10shared_ptrINS_24HumanoidAssetRequirementEEENS1_9allocatorIS6_EEEE
void __fastcall RBX::HumanoidDescription::getCostumeAssetRequirements(
        RBX::HumanoidDescription *this,
        std::vector<boost::shared_ptr<RBX::HumanoidAssetRequirement>> *requirements)
{
  std::function<void (RBX::AssetService::AssetType,long)> v2; // [rsp+0h] [rbp-48h] BYREF
  unsigned __int64 v3; // [rsp+30h] [rbp-18h]

  v3 = __readfsqword(0x28u);
  *(_QWORD *)v2.__buf_.__lx = &off_2897B68;
  *(_QWORD *)&v2.__buf_.__lx[8] = requirements;
  v2.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&v2;
  RBX::HumanoidDescription::forEachCostumeAsset(this, &v2);
  if ( &v2 == (std::function<void (RBX::AssetService::AssetType,long)> *)v2.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))v2.__f_->_vptr$__base + 4))(v2.__f_);
  }
  else if ( v2.__f_ )
  {
    (*((void (**)(void))v2.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x10f6a70 | Name: _ZN3RBX19HumanoidDescription27getHumanoidCostumeAssetURLsEPNS_9DataModelERNSt3__16vectorINS_9ContentIdENS3_9allocatorIS5_EEEEPNS4_INS_12AssetService9AssetTypeENS6_ISB_EEEE
void __fastcall RBX::HumanoidDescription::getHumanoidCostumeAssetURLs(
        RBX::HumanoidDescription *this,
        RBX::DataModel *dataModel,
        std::vector<RBX::ContentId> *URLs,
        std::vector<RBX::AssetService::AssetType> *assetTypesOut)
{
  _BYTE v6[16]; // [rsp+8h] [rbp-70h] BYREF
  void *ptr; // [rsp+18h] [rbp-60h]
  std::function<void (RBX::AssetService::AssetType,long)> func; // [rsp+20h] [rbp-58h] BYREF
  unsigned __int64 v9; // [rsp+50h] [rbp-28h]

  v9 = __readfsqword(0x28u);
  if ( dataModel && RBX::ServiceProvider::create<RBX::ContentProvider>((RBX::DataModel *)((char *)dataModel + 136)) )
  {
    RBX::format(
      (RBX *)v6,
      "&serverplaceid=%lld",
      ((unsigned __int64)(*(_DWORD *)(*((_QWORD *)dataModel + 230) + 4LL) - (unsigned int)*((_QWORD *)dataModel + 230)) << 32)
    | (**((_DWORD **)dataModel + 230) - (unsigned int)*((_QWORD *)dataModel + 230)));
    *(_QWORD *)func.__buf_.__lx = &off_2897C68;
    *(_QWORD *)&func.__buf_.__lx[8] = URLs;
    *(_QWORD *)&func.__buf_.__lx[16] = assetTypesOut;
    *(_QWORD *)&func.__buf_.__lx[24] = v6;
    func.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&func;
    RBX::HumanoidDescription::forEachCostumeAsset(this, &func);
    if ( &func == (std::function<void (RBX::AssetService::AssetType,long)> *)func.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
       + 4))(func.__f_);
      if ( (v6[0] & 1) == 0 )
        return;
      goto LABEL_7;
    }
    if ( func.__f_ )
      (*((void (**)(void))func.__f_->_vptr$__base + 5))();
    if ( (v6[0] & 1) != 0 )
LABEL_7:
      operator delete(ptr);
  }
}


// Address: 0x10f6bc0 | Name: _ZN3RBX19HumanoidDescription30getHumanoidCostumeAssetIDsURLsEPNS_9DataModelERNSt3__16vectorIlNS3_9allocatorIlEEEERNS4_INS_9ContentIdENS5_IS9_EEEEPNS4_INS_12AssetService9AssetTypeENS5_ISE_EEEE
void __fastcall RBX::HumanoidDescription::getHumanoidCostumeAssetIDsURLs(
        RBX::HumanoidDescription *this,
        RBX::DataModel *dataModel,
        std::vector<long> *assetIds,
        std::vector<RBX::ContentId> *URLs,
        std::vector<RBX::AssetService::AssetType> *assetTypesOut)
{
  std::function<void (RBX::AssetService::AssetType,long)> v7; // [rsp+0h] [rbp-68h] BYREF
  unsigned __int64 v8; // [rsp+38h] [rbp-30h]

  v8 = __readfsqword(0x28u);
  *(_QWORD *)v7.__buf_.__lx = &off_2897BE8;
  *(_QWORD *)&v7.__buf_.__lx[8] = assetIds;
  v7.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&v7;
  RBX::HumanoidDescription::forEachCostumeAsset(this, &v7);
  if ( &v7 == (std::function<void (RBX::AssetService::AssetType,long)> *)v7.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))v7.__f_->_vptr$__base + 4))(v7.__f_);
  }
  else if ( v7.__f_ )
  {
    (*((void (**)(void))v7.__f_->_vptr$__base + 5))();
  }
  RBX::HumanoidDescription::getHumanoidCostumeAssetURLs(this, dataModel, URLs, assetTypesOut);
}


// Address: 0x10f6c90 | Name: _ZN3RBX19HumanoidDescription26getHumanoidCostumeAssetIDsERNSt3__16vectorIlNS1_9allocatorIlEEEE
void __fastcall RBX::HumanoidDescription::getHumanoidCostumeAssetIDs(
        RBX::HumanoidDescription *this,
        std::vector<long> *assetIds)
{
  std::function<void (RBX::AssetService::AssetType,long)> v2; // [rsp+0h] [rbp-48h] BYREF
  unsigned __int64 v3; // [rsp+30h] [rbp-18h]

  v3 = __readfsqword(0x28u);
  *(_QWORD *)v2.__buf_.__lx = &off_2897BE8;
  *(_QWORD *)&v2.__buf_.__lx[8] = assetIds;
  v2.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&v2;
  RBX::HumanoidDescription::forEachCostumeAsset(this, &v2);
  if ( &v2 == (std::function<void (RBX::AssetService::AssetType,long)> *)v2.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))v2.__f_->_vptr$__base + 4))(v2.__f_);
  }
  else if ( v2.__f_ )
  {
    (*((void (**)(void))v2.__f_->_vptr$__base + 5))();
  }
}


// Address: 0x10f6d30 | Name: _ZNK3RBX19HumanoidDescription26getSingleEquipAssetsByTypeENS_12AssetService9AssetTypeE
int64_t __fastcall RBX::HumanoidDescription::getSingleEquipAssetsByType(
        const RBX::HumanoidDescription *this,
        RBX::AssetService::AssetType type)
{
  int64_t result; // rax
  int64_t *p_clothesGraphicTShirt; // rdi

  result = 0;
  switch ( type )
  {
    case RBX::AssetService::AssetType::TEE_SHIRT:
      p_clothesGraphicTShirt = &this->clothesGraphicTShirt;
      goto LABEL_19;
    case RBX::AssetService::AssetType::SHIRT:
      p_clothesGraphicTShirt = &this->clothesShirt;
      goto LABEL_19;
    case RBX::AssetService::AssetType::PANTS:
      p_clothesGraphicTShirt = &this->clothesPants;
      goto LABEL_19;
    case RBX::AssetService::AssetType::HEAD:
      p_clothesGraphicTShirt = &this->bodyPartsHead;
      goto LABEL_19;
    case RBX::AssetService::AssetType::FACE:
      p_clothesGraphicTShirt = &this->bodyPartsFace;
      goto LABEL_19;
    case RBX::AssetService::AssetType::TORSO:
      p_clothesGraphicTShirt = &this->bodyPartsTorso;
      goto LABEL_19;
    case RBX::AssetService::AssetType::RIGHT_ARM:
      p_clothesGraphicTShirt = &this->bodyPartsRightArm;
      goto LABEL_19;
    case RBX::AssetService::AssetType::LEFT_ARM:
      p_clothesGraphicTShirt = &this->bodyPartsLeftArm;
      goto LABEL_19;
    case RBX::AssetService::AssetType::LEFT_LEG:
      p_clothesGraphicTShirt = &this->bodyPartsLeftLeg;
      goto LABEL_19;
    case RBX::AssetService::AssetType::RIGHT_LEG:
      p_clothesGraphicTShirt = &this->bodyPartsRightLeg;
      goto LABEL_19;
    case RBX::AssetService::AssetType::CLIMB_ANIMATION:
      p_clothesGraphicTShirt = &this->animationClimb;
      goto LABEL_19;
    case RBX::AssetService::AssetType::FALL_ANIMATION:
      p_clothesGraphicTShirt = &this->animationFall;
      goto LABEL_19;
    case RBX::AssetService::AssetType::IDLE_ANIMATION:
      p_clothesGraphicTShirt = &this->animationIdle;
      goto LABEL_19;
    case RBX::AssetService::AssetType::JUMP_ANIMATION:
      p_clothesGraphicTShirt = &this->animationJump;
      goto LABEL_19;
    case RBX::AssetService::AssetType::RUN_ANIMATION:
      p_clothesGraphicTShirt = &this->animationRun;
      goto LABEL_19;
    case RBX::AssetService::AssetType::SWIM_ANIMATION:
      p_clothesGraphicTShirt = &this->animationSwim;
      goto LABEL_19;
    case RBX::AssetService::AssetType::WALK_ANIMATION:
      p_clothesGraphicTShirt = &this->animationWalk;
LABEL_19:
      result = *p_clothesGraphicTShirt;
      break;
    default:
      return result;
  }
  return result;
}


// Address: 0x10f6df0 | Name: _ZN3RBX19HumanoidDescription27getMultiEquipPropertyByTypeENS_12AssetService9AssetTypeERPN5boost9unordered13unordered_setIlNS3_4hashIlEENSt3__18equal_toIlEENS8_9allocatorIlEEEERPKNS_10Reflection14PropDescriptorIS0_NS8_12basic_stringIcNS8_11char_traitsIcEENSB_IcEEEEEE
void __fastcall RBX::HumanoidDescription::getMultiEquipPropertyByType(
        RBX::HumanoidDescription *this,
        RBX::AssetService::AssetType type,
        boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > **outAccessories,
        const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > **outProp)
{
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesHat; // rdi
  const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *v5; // rax

  switch ( type )
  {
    case RBX::AssetService::AssetType::HAT:
      p_accessoriesHat = &this->accessoriesHat;
      v5 = (const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09840;
      goto LABEL_10;
    case RBX::AssetService::AssetType::HAIR_ACCESSORY:
      p_accessoriesHat = &this->accessoriesHair;
      v5 = (const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09898;
      goto LABEL_10;
    case RBX::AssetService::AssetType::FACE_ACCESSORY:
      p_accessoriesHat = &this->accessoriesFace;
      v5 = (const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A098F0;
      goto LABEL_10;
    case RBX::AssetService::AssetType::NECK_ACCESSORY:
      p_accessoriesHat = &this->accessoriesNeck;
      v5 = (const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09948;
      goto LABEL_10;
    case RBX::AssetService::AssetType::SHOULDER_ACCESSORY:
      p_accessoriesHat = &this->accessoriesShoulders;
      v5 = (const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A099A0;
      goto LABEL_10;
    case RBX::AssetService::AssetType::FRONT_ACCESSORY:
      p_accessoriesHat = &this->accessoriesFront;
      v5 = (const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A099F8;
      goto LABEL_10;
    case RBX::AssetService::AssetType::BACK_ACCESSORY:
      p_accessoriesHat = &this->accessoriesBack;
      v5 = (const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09A50;
      goto LABEL_10;
    case RBX::AssetService::AssetType::WAIST_ACCESSORY:
      p_accessoriesHat = &this->accessoriesWaist;
      v5 = (const RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09AA8;
LABEL_10:
      *outAccessories = p_accessoriesHat;
      *outProp = v5;
      break;
    default:
      return;
  }
}


// Address: 0x10f6ea0 | Name: _ZN3RBX19HumanoidDescription21isMultiEquipAssetTypeENS_12AssetService9AssetTypeE
bool __fastcall RBX::HumanoidDescription::isMultiEquipAssetType(RBX::AssetService::AssetType type)
{
  unsigned __int32 v1; // edi
  _BOOL8 v2; // rax

  v1 = type - 8;
  if ( v1 > 0x27 )
    LOBYTE(v2) = 0;
  else
    return (0xFE00000001uLL >> v1) & 1;
  return v2;
}


// Address: 0x10f6ec0 | Name: _ZN3RBX19HumanoidDescription32removeFromMultiEquipAssetsByTypeENS_12AssetService9AssetTypeEl
void __fastcall RBX::HumanoidDescription::removeFromMultiEquipAssetsByType(
        RBX::HumanoidDescription *this,
        RBX::AssetService::AssetType type,
        int64_t remove)
{
  boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *p_accessoriesHat; // rdi
  const RBX::Reflection::PropertyDescriptor *v6; // r14
  size_t bucket_count; // rbx
  unsigned __int64 v8; // rdx
  _QWORD *p_next; // rax
  _QWORD *v10; // rsi
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::key_type k[4]; // [rsp+8h] [rbp-20h] BYREF

  k[0] = remove;
  switch ( type )
  {
    case RBX::AssetService::AssetType::HAT:
      p_accessoriesHat = &this->accessoriesHat;
      v6 = &stru_2A09840;
      goto LABEL_10;
    case RBX::AssetService::AssetType::HAIR_ACCESSORY:
      p_accessoriesHat = &this->accessoriesHair;
      v6 = &stru_2A09898;
      goto LABEL_10;
    case RBX::AssetService::AssetType::FACE_ACCESSORY:
      p_accessoriesHat = &this->accessoriesFace;
      v6 = &stru_2A098F0;
      goto LABEL_10;
    case RBX::AssetService::AssetType::NECK_ACCESSORY:
      p_accessoriesHat = &this->accessoriesNeck;
      v6 = &stru_2A09948;
      goto LABEL_10;
    case RBX::AssetService::AssetType::SHOULDER_ACCESSORY:
      p_accessoriesHat = &this->accessoriesShoulders;
      v6 = &stru_2A099A0;
      goto LABEL_10;
    case RBX::AssetService::AssetType::FRONT_ACCESSORY:
      p_accessoriesHat = &this->accessoriesFront;
      v6 = &stru_2A099F8;
      goto LABEL_10;
    case RBX::AssetService::AssetType::BACK_ACCESSORY:
      p_accessoriesHat = &this->accessoriesBack;
      v6 = &stru_2A09A50;
      goto LABEL_10;
    case RBX::AssetService::AssetType::WAIST_ACCESSORY:
      p_accessoriesHat = &this->accessoriesWaist;
      v6 = &stru_2A09AA8;
LABEL_10:
      bucket_count = p_accessoriesHat->table_.bucket_count_;
      v8 = remove % bucket_count;
      if ( !p_accessoriesHat->table_.size_ )
        return;
      p_next = &p_accessoriesHat->table_.buckets_[v8].next_->next_;
      if ( !p_next )
        return;
      v10 = (_QWORD *)*p_next;
      if ( !*p_next )
        return;
      break;
    default:
      return;
  }
  while ( v10[1] != remove )
  {
    if ( v10[1] % bucket_count != remove % bucket_count )
      return;
LABEL_14:
    v10 = (_QWORD *)*v10;
    if ( !v10 )
      return;
  }
  if ( v10[2] != remove )
    goto LABEL_14;
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::erase_key(
    &p_accessoriesHat->table_,
    k);
  RBX::Instance::raisePropertyChanged(this, v6);
}


// Address: 0x10f6ff0 | Name: _ZN3RBX19HumanoidDescription19getCostumeAssetTypeEl
RBX::AssetService::AssetType __fastcall RBX::HumanoidDescription::getCostumeAssetType(
        RBX::HumanoidDescription *this,
        int64_t assetToSearchFor)
{
  RBX::AssetService::AssetType v3; // [rsp+Ch] [rbp-4Ch] BYREF
  std::function<void (RBX::AssetService::AssetType,long)> func; // [rsp+10h] [rbp-48h] BYREF
  unsigned __int64 v5; // [rsp+40h] [rbp-18h]

  v5 = __readfsqword(0x28u);
  v3 = RBX::AssetService::AssetType::UNKNOWN;
  if ( assetToSearchFor <= 0 )
    return RBX::AssetService::AssetType::UNKNOWN;
  *(_QWORD *)func.__buf_.__lx = &off_2897DE8;
  *(_QWORD *)&func.__buf_.__lx[8] = &v3;
  *(_QWORD *)&func.__buf_.__lx[16] = assetToSearchFor;
  func.__f_ = (std::function<void (RBX::AssetService::AssetType,long)>::__base *)&func;
  RBX::HumanoidDescription::forEachCostumeAsset(this, &func);
  if ( &func == (std::function<void (RBX::AssetService::AssetType,long)> *)func.__f_ )
  {
    (*((void (__fastcall **)(std::function<void (RBX::AssetService::AssetType,long)>::__base *))func.__f_->_vptr$__base
     + 4))(func.__f_);
  }
  else if ( func.__f_ )
  {
    (*((void (**)(void))func.__f_->_vptr$__base + 5))();
  }
  return v3;
}


// Address: 0x10f70b0 | Name: _ZN3RBX19HumanoidDescription19createHumanoidModelEPNS_15ContentProviderEb
RBX::Instance **__fastcall RBX::HumanoidDescription::createHumanoidModel(
        RBX::Instance **a1,
        boost::shared_ptr<RBX::ModelInstance> *contentProvider,
        bool r15_0)
{
  RBX::ContentProvider *v4; // rbp
  _BOOL4 v5; // r12d
  boost::shared_ptr<RBX::Instance> CharacterRig; // rax
  __int64 v7; // rbx
  unsigned int v8; // ecx
  int v9; // ebp
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::Instance>::element_type *px; // rbx
  boost::shared_ptr<RBX::ModelInstance> v13; // [rsp+0h] [rbp-48h]
  boost::shared_ptr<RBX::ModelInstance> character; // [rsp+10h] [rbp-38h] BYREF

  if ( !contentProvider )
    goto LABEL_10;
  v4 = (RBX::ContentProvider *)contentProvider;
  v5 = r15_0;
  CharacterRig = RBX::PlayerCharacterLoader::loadCharacterRig((RBX::ContentProvider *)contentProvider, r15_0);
  if ( v13.px
    && (v7 = *((_QWORD *)v13.px + 3),
        CharacterRig.px = (boost::shared_ptr<RBX::Instance>::element_type *)Class_getDescriptorPtr(0),
        CharacterRig.pn.pi_ = (boost::detail::sp_counted_base *)HIWORD(CharacterRig.px[5].children.object.pn.pi_),
        v8 = *(unsigned __int16 *)(v7 + 726) - LODWORD(CharacterRig.pn.pi_),
        v8 <= LOWORD(CharacterRig.px[5].parent)) )
  {
    *(boost::shared_ptr<RBX::ModelInstance> *)a1 = v13;
    if ( v13.pn.pi_ )
      _InterlockedAdd(&v13.pn.pi_->use_count_, 1u);
    character = v13;
    if ( v13.pn.pi_ )
      _InterlockedAdd(&v13.pn.pi_->use_count_, 1u);
    contentProvider = &character;
    RBX::PlayerCharacterLoader::loadHumanoidAnimationScripts(
      v4,
      (boost::shared_ptr<RBX::ModelInstance>)__PAIR128__(v5, &character),
      v8);
    pi = character.pn.pi_;
    if ( character.pn.pi_ )
    {
      if ( !_InterlockedSub(&character.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    CharacterRig.px = (boost::shared_ptr<RBX::Instance>::element_type *)RBX::Humanoid::modelIsCharacter(*a1);
    px = CharacterRig.px;
    v9 = 1;
    if ( CharacterRig.px )
    {
      if ( !r15_0 )
        RBX::Humanoid::buildJoints((RBX::Humanoid *)CharacterRig.px);
      RBX::Humanoid::setupAnimator((RBX::Humanoid *)px);
    }
  }
  else
  {
    *(_OWORD *)a1 = 0;
    v9 = 0;
  }
  if ( v13.pn.pi_ )
  {
    if ( !_InterlockedSub(&v13.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::shared_ptr<RBX::ModelInstance> *, boost::detail::sp_counted_base *))v13.pn.pi_->_vptr$sp_counted_base
       + 2))(
        v13.pn.pi_,
        contentProvider,
        CharacterRig.pn.pi_);
      if ( !_InterlockedSub(&v13.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)())v13.pn.pi_->_vptr$sp_counted_base + 3))();
    }
  }
  if ( !v9 )
LABEL_10:
    *(_OWORD *)a1 = 0;
  return a1;
}


// Address: 0x10f7300 | Name: _ZN3RBX19HumanoidDescription17setEquippedEmotesERKN5boost9unordered13unordered_mapIiNSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS1_4hashIiEENS4_8equal_toIiEENS8_INS4_4pairIKiSA_EEEEEE
void __fastcall RBX::HumanoidDescription::setEquippedEmotes(
        RBX::HumanoidDescription *this,
        const boost::unordered::unordered_map<int,std::string,boost::hash<int>,std::equal_to<int>,std::allocator<std::pair<const int,std::string > > > *newEquippedEmotes)
{
  boost::unordered::detail::false_type v2; // dl
  boost::unordered::unordered_map<int,std::string,boost::hash<int>,std::equal_to<int>,std::allocator<std::pair<const int,std::string > > > *p_equippedEmotes; // rdi
  unsigned __int64 v5; // rdx
  volatile signed __int32 *v6; // rbx
  std::vector<RBX::Reflection::Variant> *v7; // [rsp+0h] [rbp-28h] BYREF
  volatile signed __int32 *v8; // [rsp+8h] [rbp-20h]

  p_equippedEmotes = &this->equippedEmotes;
  if ( p_equippedEmotes != newEquippedEmotes )
    boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<int const,std::string>>,int,std::string,boost::hash<int>,std::equal_to<int>>>::assign(
      &p_equippedEmotes->table_,
      &newEquippedEmotes->table_,
      v2);
  RBX::Instance::raisePropertyChanged(this, &stru_2A0A130);
  if ( stru_2A093F0.value )
  {
    RBX::HumanoidDescription::getEquippedEmotesLua(&v7, this);
    rbx::signal<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>::operator()(
      &this->equippedEmotesChangedSignal,
      (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)__PAIR128__(v5, &v7));
    v6 = v8;
    if ( v8 )
    {
      if ( !_InterlockedSub(v8 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
  }
}


// Address: 0x10f73d0 | Name: _ZN3RBX19HumanoidDescription9setEmotesERKN5boost9unordered13unordered_mapINSt3__112basic_stringIcNS4_11char_traitsIcEENS4_9allocatorIcEEEENS4_3setIlNS4_4lessIlEENS8_IlEEEENS1_4hashISA_EENS4_8equal_toISA_EENS8_INS4_4pairIKSA_SF_EEEEEE
void __fastcall RBX::HumanoidDescription::setEmotes(
        RBX::HumanoidDescription *this,
        const boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > *newEmotes)
{
  boost::unordered::detail::false_type v2; // dl
  boost::unordered::unordered_map<std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,std::set<long> > > > *p_emotesMap; // rdi
  unsigned __int64 v5; // rdx
  volatile signed __int32 *v6; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > *v7; // [rsp+0h] [rbp-28h] BYREF
  volatile signed __int32 *v8; // [rsp+8h] [rbp-20h]

  p_emotesMap = &this->emotesMap;
  if ( p_emotesMap != newEmotes )
    boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::assign(
      &p_emotesMap->table_,
      &newEmotes->table_,
      v2);
  RBX::Instance::raisePropertyChanged(this, &stru_2A0A0D8);
  if ( stru_2A093F0.value )
  {
    RBX::HumanoidDescription::getEmotesLua(&v7, this);
    rbx::signal<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>::operator()(
      &this->emotesChangedSignal,
      (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)__PAIR128__(v5, &v7));
    v6 = v8;
    if ( v8 )
    {
      if ( !_InterlockedSub(v8 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
  }
}


// Address: 0x10f74a0 | Name: _ZN3RBX19HumanoidDescription16getEmoteAssetIdsERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
std::set<long> *__fastcall RBX::HumanoidDescription::getEmoteAssetIds(
        std::set<long> *__return_ptr retstr,
        RBX::HumanoidDescription *this,
        const std::string *emoteName)
{
  unsigned __int64 v3; // rax
  char *v4; // r11
  unsigned __int64 v5; // rax
  __int64 v6; // r9
  unsigned __int64 v7; // rbp
  unsigned __int64 v8; // rbx
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rbp
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > >::iterator v11; // rax
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v12; // rbp
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v13; // r15
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer left; // rax
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v15; // rcx
  std::__tree_end_node<std::__tree_node_base<void *> *> *p_value; // r13
  std::__tree_end_node<std::__tree_node_base<void *> *> *v17; // rcx
  __int64 v18; // rcx
  std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *p_pair1; // r14
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v20; // rax
  std::__tree_node_base<void *> *v21; // rax
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer v22; // rcx
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v23; // rax
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v24; // rcx
  __int64 v25; // rbp
  bool v26; // zf
  std::set<long> *v28; // [rsp+8h] [rbp-40h]

  v3 = *(unsigned __int8 *)emoteName;
  if ( (v3 & 1) != 0 )
  {
    v4 = (char *)*((_QWORD *)emoteName + 2);
    v5 = *((_QWORD *)emoteName + 1);
  }
  else
  {
    v4 = (char *)emoteName + 1;
    v5 = v3 >> 1;
  }
  v28 = retstr;
  if ( !v5 )
  {
    v7 = 0;
    goto LABEL_12;
  }
  v6 = v5 & 1;
  if ( v5 == 1 )
  {
    v7 = 0;
LABEL_11:
    v7 ^= (v7 << 6) + 2654435769u + (v7 >> 2) + *v4;
    goto LABEL_12;
  }
  v8 = v6 - v5;
  v7 = 0;
  do
  {
    v9 = v7 ^ (*v4 + (v7 >> 2) + (v7 << 6) + 2654435769u);
    v7 = v9 ^ (v4[1] + (v9 >> 2) + (v9 << 6) + 2654435769u);
    v4 += 2;
    v8 += 2LL;
  }
  while ( v8 );
  if ( v6 )
    goto LABEL_11;
LABEL_12:
  v10 = ~v7 + (v7 << 21);
  v11.node_ = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
                &this->emotesMap.table_,
                2147483649u
              * ((21 * ((265 * (v10 ^ (v10 >> 24))) ^ ((265 * (v10 ^ (v10 >> 24))) >> 14)))
               ^ ((21 * ((265 * (v10 ^ (v10 >> 24))) ^ ((265 * (v10 ^ (v10 >> 24))) >> 14))) >> 28)),
                emoteName,
                (const std::equal_to<std::string > *)&this->emotesMap.table_.funcs_[(unsigned __int8)this->emotesMap.table_.current_]).node_;
  if ( v11.node_ )
  {
    *(_OWORD *)&retstr->__tree_.__pair1_.__value_.__left_ = 0;
    retstr->__tree_.__begin_node_ = &retstr->__tree_.__pair1_.__value_;
    v12 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)*((_QWORD *)&v11.node_->value_base_.data_.data_.align_ + 3);
    v13 = &v11.node_->value_base_.data_.data_.align_ + 4;
    if ( v12 != &v11.node_->value_base_.data_.data_.align_ + 4 )
    {
      left = 0;
LABEL_29:
      p_value = &v28->__tree_.__pair1_.__value_;
      do
      {
        if ( left )
        {
          p_pair1 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)&p_value[1];
        }
        else
        {
          p_value = &v28->__tree_.__pair1_.__value_;
          p_pair1 = &v28->__tree_.__pair1_;
        }
LABEL_33:
        if ( !p_pair1->__value_.__left_ )
          goto LABEL_36;
LABEL_39:
        v23 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)v12[1];
        if ( v23 )
        {
          do
          {
            v24 = v23;
            v23 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)*v23;
          }
          while ( v23 );
        }
        else
        {
          v24 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)v12[2];
          if ( (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)*v24 != v12 )
          {
            v25 = (__int64)&v12[2];
            do
            {
              v24 = *(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type **)(*(_QWORD *)v25 + 16LL);
              v26 = *v24 == *(_QWORD *)v25;
              v25 = *(_QWORD *)v25 + 16LL;
            }
            while ( !v26 );
          }
        }
        if ( v24 == v13 )
          return retstr;
        left = retstr->__tree_.__pair1_.__value_.__left_;
        v12 = v24;
        if ( (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)retstr->__tree_.__begin_node_ == &v28->__tree_.__pair1_ )
          goto LABEL_29;
        v15 = retstr->__tree_.__pair1_.__value_.__left_;
        p_value = &v28->__tree_.__pair1_.__value_;
        if ( left )
        {
          do
          {
            p_value = v15;
            v15 = v15->__right_;
          }
          while ( v15 );
        }
        else
        {
          do
          {
            v17 = p_value;
            p_value = p_value[2].__left_;
          }
          while ( p_value->__left_ == v17 );
        }
        v18 = (__int64)v12[4];
      }
      while ( (__int64)p_value[4].__left_ < v18 );
      if ( left )
      {
        p_pair1 = &v28->__tree_.__pair1_;
        do
        {
          while ( 1 )
          {
            p_value = left;
            v20 = left[1].__left_;
            if ( v18 < (__int64)v20 )
              break;
            if ( (__int64)v20 >= v18 )
              goto LABEL_33;
            p_pair1 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)&p_value[1];
            left = p_value[1].__left_;
            if ( !left )
              goto LABEL_36;
          }
          left = p_value->__left_;
          p_pair1 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)p_value;
        }
        while ( p_value->__left_ );
        p_pair1 = (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)p_value;
      }
      else
      {
        p_pair1 = &v28->__tree_.__pair1_;
        p_value = &v28->__tree_.__pair1_.__value_;
      }
LABEL_36:
      v21 = (std::__tree_node_base<void *> *)operator new(0x28u);
      v21[1].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v12[4];
      *(_OWORD *)&v21->__left_ = 0;
      v21->__parent_ = p_value;
      p_pair1->__value_.__left_ = v21;
      v22 = v28->__tree_.__begin_node_->__left_;
      if ( v22 )
      {
        v28->__tree_.__begin_node_ = v22;
        v21 = p_pair1->__value_.__left_;
      }
      std::__tree_balance_after_insert<std::__tree_node_base<void *> *>(v28->__tree_.__pair1_.__value_.__left_, v21);
      retstr = v28;
      ++v28->__tree_.__pair3_.__value_;
      goto LABEL_39;
    }
  }
  else
  {
    *(_OWORD *)&retstr->__tree_.__pair1_.__value_.__left_ = 0;
    retstr->__tree_.__begin_node_ = &retstr->__tree_.__pair1_.__value_;
  }
  return retstr;
}


// Address: 0x10f77f0 | Name: _ZN3RBX19HumanoidDescription15getEmoteAssetIdERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERb
int64_t __fastcall RBX::HumanoidDescription::getEmoteAssetId(
        RBX::HumanoidDescription *this,
        const std::string *emoteName,
        bool *emoteExists)
{
  unsigned __int64 v4; // rax
  char *v5; // r15
  unsigned __int64 v6; // rax
  __int64 v7; // r10
  unsigned __int64 v8; // rbx
  unsigned __int64 v9; // rdx
  unsigned __int64 v10; // rax
  unsigned __int64 v11; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,std::set<long> > >,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string > > >::iterator v12; // rax
  boost::unordered::iterator_detail::iterator<boost::unordered::detail::ptr_node<std::pair<const std::string,std::set<long> > > >::node_pointer node; // r15
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v14; // rcx
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v15; // rax
  unsigned __int64 v16; // rbx
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v17; // rsi
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v18; // rdx
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *v19; // rcx
  boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type v20; // rcx
  bool v21; // zf
  signed __int64 v22; // rdx
  _QWORD *v23; // rax
  _QWORD *v24; // rsi
  _QWORD *v25; // rcx
  __int64 *v26; // rax
  __int64 v27; // rax
  _QWORD *v30; // rdx
  _QWORD *v31; // rcx

  *emoteExists = 0;
  v4 = *(unsigned __int8 *)emoteName;
  if ( (v4 & 1) != 0 )
  {
    v5 = (char *)*((_QWORD *)emoteName + 2);
    v6 = *((_QWORD *)emoteName + 1);
  }
  else
  {
    v5 = (char *)emoteName + 1;
    v6 = v4 >> 1;
  }
  if ( !v6 )
  {
    v8 = 0;
    goto LABEL_12;
  }
  v7 = v6 & 1;
  if ( v6 == 1 )
  {
    v8 = 0;
LABEL_11:
    v8 ^= (v8 << 6) + 2654435769u + (v8 >> 2) + *v5;
    goto LABEL_12;
  }
  v9 = v7 - v6;
  v8 = 0;
  do
  {
    v10 = v8 ^ (*v5 + (v8 >> 2) + (v8 << 6) + 2654435769u);
    v8 = v10 ^ (v5[1] + (v10 >> 2) + (v10 << 6) + 2654435769u);
    v5 += 2;
    v9 += 2LL;
  }
  while ( v9 );
  if ( v7 )
    goto LABEL_11;
LABEL_12:
  v11 = ~v8 + (v8 << 21);
  v12.node_ = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::find_node_impl<std::string,std::equal_to<std::string>>(
                &this->emotesMap.table_,
                2147483649u
              * ((21 * ((265 * (v11 ^ (v11 >> 24))) ^ ((265 * (v11 ^ (v11 >> 24))) >> 14)))
               ^ ((21 * ((265 * (v11 ^ (v11 >> 24))) ^ ((265 * (v11 ^ (v11 >> 24))) >> 14))) >> 28)),
                emoteName,
                (const std::equal_to<std::string > *)&this->emotesMap.table_.funcs_[(unsigned __int8)this->emotesMap.table_.current_]).node_;
  if ( !v12.node_ )
    return 0;
  node = v12.node_;
  *emoteExists = 1;
  v14 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)*((_QWORD *)&v12.node_->value_base_.data_.data_.align_ + 3);
  v15 = &v12.node_->value_base_.data_.data_.align_ + 4;
  v16 = 0;
  if ( v14 != v15 )
  {
    do
    {
      v17 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)v14[1];
      if ( v17 )
      {
        do
        {
          v18 = v17;
          v17 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)*v17;
        }
        while ( v17 );
      }
      else
      {
        v18 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)v14[2];
        if ( (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)*v18 != v14 )
        {
          v19 = v14 + 2;
          do
          {
            v20 = *v19;
            v18 = *(boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type **)(*(_QWORD *)&v20 + 16LL);
            v21 = *v18 == v20;
            v19 = (boost::mpl::eval_if_c<false,boost::mpl::identity<boost::detail::max_align>,boost::type_with_alignment<8> >::type *)(*(_QWORD *)&v20 + 16LL);
          }
          while ( !v21 );
        }
      }
      ++v16;
      v14 = v18;
    }
    while ( v18 != v15 );
  }
  v22 = RBX::globalRand() % v16;
  v23 = (_QWORD *)*((_QWORD *)&node->value_base_.data_.data_.align_ + 3);
  if ( v22 < 0 )
  {
    v30 = (_QWORD *)*v23;
    if ( *v23 )
    {
      do
      {
        v25 = v30;
        v30 = (_QWORD *)v30[1];
      }
      while ( v30 );
      return v25[4];
    }
    do
    {
      v31 = v23;
      v23 = (_QWORD *)v23[2];
    }
    while ( (_QWORD *)*v23 == v31 );
  }
  else if ( v22 )
  {
    do
    {
      v24 = (_QWORD *)v23[1];
      if ( v24 )
      {
        do
        {
          v25 = v24;
          v24 = (_QWORD *)*v24;
        }
        while ( v24 );
      }
      else
      {
        v25 = (_QWORD *)v23[2];
        if ( (_QWORD *)*v25 != v23 )
        {
          v26 = v23 + 2;
          do
          {
            v27 = *v26;
            v25 = *(_QWORD **)(v27 + 16);
            v21 = *v25 == v27;
            v26 = (__int64 *)(v27 + 16);
          }
          while ( !v21 );
        }
      }
      v23 = v25;
    }
    while ( v22-- > 1 );
    return v25[4];
  }
  v25 = v23;
  return v25[4];
}


// Address: 0x10f7a40 | Name: _ZN3RBX22toCommaSeparatedAssetsERKN5boost9unordered13unordered_setIlNS0_4hashIlEENSt3__18equal_toIlEENS5_9allocatorIlEEEE
char *__fastcall RBX::toCommaSeparatedAssets(char *a1, _QWORD *a2)
{
  _QWORD *v2; // rbx
  __int64 v3; // rax
  unsigned __int8 v4; // cl
  bool v5; // zf
  __int64 v6; // rcx
  char *v7; // rsi
  unsigned __int64 v8; // rdx
  unsigned __int8 v10; // [rsp+8h] [rbp-40h] BYREF
  char v11; // [rsp+9h] [rbp-3Fh] BYREF
  unsigned __int64 v12; // [rsp+10h] [rbp-38h]
  void *ptr; // [rsp+18h] [rbp-30h]

  *(_OWORD *)a1 = 0;
  *((_QWORD *)a1 + 2) = 0;
  if ( a2[2] )
  {
    v2 = *(_QWORD **)(a2[5] + 8LL * a2[1]);
    if ( v2 )
    {
      v3 = 0;
      v4 = 0;
      while ( 1 )
      {
        v5 = (v4 & 1) == 0;
        v6 = v4 >> 1;
        if ( !v5 )
          v6 = v3;
        if ( v6 )
          std::string::append(a1, ",");
        RBX::StringConverter<long>::convertToString(&v10, v2 + 2);
        if ( (v10 & 1) != 0 )
        {
          v7 = (char *)ptr;
          v8 = v12;
        }
        else
        {
          v8 = (unsigned __int64)v10 >> 1;
          v7 = &v11;
        }
        std::string::append(a1, v7, v8);
        if ( (v10 & 1) != 0 )
          operator delete(ptr);
        v2 = (_QWORD *)*v2;
        if ( !v2 )
          break;
        v4 = *a1;
        v3 = *((_QWORD *)a1 + 1);
      }
    }
  }
  return a1;
}


// Address: 0x10f7b80 | Name: _ZN3RBXL20toUnorderedSetAssetsERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE
boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *__fastcall RBX::toUnorderedSetAssets(
        boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *__return_ptr retstr,
        const std::string *commaSeparatedAssets)
{
  const boost::unordered::detail::false_type *v4; // rax
  __int64 v5; // rcx
  const boost::unordered::detail::false_type *v6; // rdx
  __int64 v7; // rsi
  size_t *v8; // rdx
  std::istream *v9; // rax
  char *v10; // rdi
  __int128 v12; // [rsp+0h] [rbp-168h] BYREF
  char *nptr; // [rsp+10h] [rbp-158h]
  __int64 args; // [rsp+18h] [rbp-150h] BYREF
  __int128 v15; // [rsp+20h] [rbp-148h] BYREF
  _QWORD v16[8]; // [rsp+30h] [rbp-138h] BYREF
  __int128 v17; // [rsp+70h] [rbp-F8h]
  void *ptr[2]; // [rsp+80h] [rbp-E8h]
  int v19; // [rsp+90h] [rbp-D8h]
  _QWORD v20[18]; // [rsp+98h] [rbp-D0h] BYREF
  int v21; // [rsp+128h] [rbp-40h]

  retstr->table_.current_ = 0;
  v4 = &stru_495510;
  v5 = 38;
  do
  {
    v6 = v4;
    v7 = v5 + ~(v5 / 2);
    if ( *(_QWORD *)&v4[8 * (v5 / 2)].gap0 >= 0xBu )
      v7 = v5 / 2;
    v4 += 8 * (v5 / 2) + 8;
    if ( *(_QWORD *)&v6[8 * (v5 / 2)].gap0 >= 0xBu )
      v4 = v6;
    v5 = v7;
  }
  while ( v7 );
  v8 = (size_t *)&v4[-8];
  if ( v4 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v8 = (size_t *)v4;
  retstr->table_.bucket_count_ = *v8;
  retstr->table_.size_ = 0;
  retstr->table_.mlf_ = 1.0;
  *(_OWORD *)&retstr->table_.max_load_ = 0;
  v12 = 0;
  nptr = 0;
  v20[0] = &off_2878EF0;
  v15 = (unsigned __int64)&off_2878EC8;
  std::ios_base::init((std::ios_base *)v20, v16);
  v20[17] = 0;
  v21 = -1;
  *(_QWORD *)&v15 = &off_2878E58;
  v20[0] = off_2878E80;
  std::streambuf::basic_streambuf(v16);
  v16[0] = &off_28753A8;
  *(_OWORD *)ptr = 0;
  v17 = 0;
  v19 = 8;
  std::stringbuf::str((std::stringbuf *)v16, commaSeparatedAssets);
  while ( 1 )
  {
    v9 = std::getline<char,std::char_traits<char>,std::allocator<char>>((std::istream *)&v15, (std::string *)&v12, 44);
    if ( (*((_BYTE *)v9 + *(_QWORD *)(*(_QWORD *)v9 - 24LL) + 32) & 5) != 0 )
      break;
    v10 = (char *)&v12 + 1;
    if ( (v12 & 1) != 0 )
      v10 = nptr;
    args = strtoll(v10, 0, 10);
    if ( args > 0 )
      boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long>>>::emplace_impl<long const&>(
        &retstr->table_,
        &args,
        &args);
  }
  *(_QWORD *)&v15 = &off_2878E58;
  v20[0] = off_2878E80;
  v16[0] = &off_28753A8;
  if ( (v17 & 1) != 0 )
    operator delete(ptr[0]);
  std::streambuf::~streambuf(v16);
  std::istream::~istream(&v15, off_2878E98);
  std::ios::~ios(v20);
  if ( (v12 & 1) != 0 )
    operator delete(nptr);
  return retstr;
}


// Address: 0x10f7eb0 | Name: _ZNK3RBX19HumanoidDescription24isPropertyHiddenInStudioEPKNS_10Reflection18PropertyDescriptorE
bool __fastcall RBX::HumanoidDescription::isPropertyHiddenInStudio(
        const RBX::HumanoidDescription *this,
        const RBX::Reflection::PropertyDescriptor *p)
{
  return p == &stru_2A0A0D8 || p == &stru_2A0A130;
}


// Address: 0x10f7ed0 | Name: _Z22Class_getDescriptorPtrPN3RBX19HumanoidDescriptionE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::HumanoidDescription *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A0A508;
  if ( !qword_2A0A508 )
  {
    if ( !(_BYTE)byte_2A0A850 )
    {
      if ( __cxa_guard_acquire(&byte_2A0A850) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A0A510,
          v2,
          "HumanoidDescription",
          0,
          attributes,
          RBX::Security::Permissions::None,
          0);
        stru_2A0A848._vptr$ICreator = (int (**)(void))&off_2898168;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A0A518, &stru_2A0A848);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::HumanoidDescription,true>::~ClassRegistrar,
          &unk_2A0A510,
          &dso_handle);
        __cxa_guard_release(&byte_2A0A850);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A0A510;
    qword_2A0A508 = (RBX::Reflection::ClassDescriptor *)&unk_2A0A510;
  }
  return result;
}


// Address: 0x10f8020 | Name: _Z16Class_getNamePtrPN3RBX19HumanoidDescriptionE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HumanoidDescription *a1)
{
  const RBX::Name *result; // rax

  result = (const RBX::Name *)qword_2A0A858;
  if ( !qword_2A0A858 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A0A858 = (RBX::HumanoidDescription *)result;
  }
  return result;
}


// Address: 0x10f8c70 | Name: _ZNSt3__110__function6__funcIZN3RBX19HumanoidDescription19getCostumeAssetTypeElE4$_10NS_9allocatorIS4_EEFvNS2_12AssetService9AssetTypeElEEclEOS8_Ol
void __fastcall std::__function::__func<RBX::HumanoidDescription::getCostumeAssetType(long)::$_10,std::allocator<RBX::HumanoidDescription::getCostumeAssetType(long)::$_10>,void ()(RBX::AssetService::AssetType,long)>::operator()(
        std::__function::__func<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_humanoid_HumanoidDescription_cpp:585:29),std::allocator<(lambda at _opt_buildagent_work_trunk_deploy_nbsninja_rcc_Client_App_humanoid_HumanoidDescription_cpp:585:29)>,void (RBX::AssetService::AssetType,long)> *this,
        RBX::AssetService::AssetType *__arg,
        __int64 *a3)
{
  if ( this->__f_.__value_.assetToSearchFor == *a3 )
    *this->__f_.__value_.result = *__arg;
}


// Address: 0x10ffbb0 | Name: _GLOBAL__sub_I_HumanoidDescription.cpp
void __cdecl GLOBAL__sub_I_HumanoidDescription_cpp()
{
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v1; // r9
  RBX::Reflection::ClassDescriptor *v2; // rax
  __int64 v3; // r9
  RBX::Reflection::ClassDescriptor *v4; // r14
  char *v5; // rbx
  const RBX::Reflection::Type *v6; // rax
  RBX::Reflection::PropertyDescriptor::Attributes flags; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsa; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsb; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsc; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsd; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagse; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsf; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsg; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsh; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsi; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsj; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsk; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsl; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsm; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsn; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagso; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsp; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsq; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsr; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagss; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagst; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsu; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsv; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsw; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsx; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsy; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsz; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsba; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbb; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbc; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbd; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbe; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbf; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbg; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbh; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbi; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbj; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbk; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbl; // [rsp+0h] [rbp-78h]
  RBX::Reflection::Descriptor::Attributes flagsbm; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes flagsbn; // [rsp+0h] [rbp-78h]
  RBX::Reflection::Descriptor::Attributes attributes; // [rsp+28h] [rbp-50h] BYREF
  __int64 v49; // [rsp+38h] [rbp-40h]
  RBX::Reflection::PropertyDescriptor::Attributes v50; // [rsp+40h] [rbp-38h]
  RBX::Reflection::Descriptor::Attributes v51; // 0:r8.1,8:r9.8
  RBX::Reflection::Descriptor::Attributes v52; // 0:r8.1,8:r9.8

  qword_2A093D8 = (__int64)boost::system::generic_category();
  qword_2A093E0 = (__int64)boost::system::generic_category();
  qword_2A093E8 = (__int64)boost::system::system_category();
  stru_2A093F0.value = 0;
  stru_2A093F0.name = "EmotesApiEnabled";
  dword_2A09400 = FLog::RegisterFlag("EmotesApiEnabled", &stru_2A093F0, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A09408.value = 1;
  stru_2A09408.name = "EmotesPropertiesEnabled";
  dword_2A09418 = FLog::RegisterFlag("EmotesPropertiesEnabled", &stru_2A09408, FastVarType::FASTVARTYPE_DYNAMIC);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flags.flags = *(_QWORD *)&attributes.isDeprecated;
  flags.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setScaleHeight;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float>::PropDescriptor<float (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(float)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float> *)&stru_2A09420,
    "HeightScale",
    "Scale",
    RBX::HumanoidDescription::getScaleHeight,
    0,
    RBX::Security::Permissions::None,
    flags,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A09420,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsa.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsa.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setScaleWidth;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float>::PropDescriptor<float (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(float)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float> *)&stru_2A09478,
    "WidthScale",
    "Scale",
    RBX::HumanoidDescription::getScaleWidth,
    0,
    RBX::Security::Permissions::None,
    flagsa,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A09478,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsb.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsb.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setScaleHead;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float>::PropDescriptor<float (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(float)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float> *)&stru_2A094D0,
    "HeadScale",
    "Scale",
    RBX::HumanoidDescription::getScaleHead,
    0,
    RBX::Security::Permissions::None,
    flagsb,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A094D0,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsc.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsc.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setScaleDepth;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float>::PropDescriptor<float (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(float)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float> *)&stru_2A09528,
    "DepthScale",
    "Scale",
    RBX::HumanoidDescription::getScaleDepth,
    0,
    RBX::Security::Permissions::None,
    flagsc,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A09528,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsd.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsd.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setScaleProportion;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float>::PropDescriptor<float (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(float)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float> *)&stru_2A09580,
    "ProportionScale",
    "Scale",
    RBX::HumanoidDescription::getScaleProportion,
    0,
    RBX::Security::Permissions::None,
    flagsd,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A09580,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagse.flags = *(_QWORD *)&attributes.isDeprecated;
  flagse.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setScaleBodyType;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float>::PropDescriptor<float (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(float)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,float> *)&stru_2A095D8,
    "BodyTypeScale",
    "Scale",
    RBX::HumanoidDescription::getScaleBodyType,
    0,
    RBX::Security::Permissions::None,
    flagse,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A095D8,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsf.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsf.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyColorHead;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3>::PropDescriptor<G3D::Color3 (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(G3D::Color3 const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3> *)&stru_2A09630,
    "HeadColor",
    "Body Colors",
    RBX::HumanoidDescription::getBodyColorHead,
    0,
    RBX::Security::Permissions::None,
    flagsf,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<G3D::Color3>::~TypedPropertyDescriptor,
    &stru_2A09630,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsg.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsg.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyColorTorso;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3>::PropDescriptor<G3D::Color3 (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(G3D::Color3 const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3> *)&stru_2A09688,
    "TorsoColor",
    "Body Colors",
    RBX::HumanoidDescription::getBodyColorTorso,
    0,
    RBX::Security::Permissions::None,
    flagsg,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<G3D::Color3>::~TypedPropertyDescriptor,
    &stru_2A09688,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsh.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsh.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyColorRightArm;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3>::PropDescriptor<G3D::Color3 (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(G3D::Color3 const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3> *)&stru_2A096E0,
    "RightArmColor",
    "Body Colors",
    RBX::HumanoidDescription::getBodyColorRightArm,
    0,
    RBX::Security::Permissions::None,
    flagsh,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<G3D::Color3>::~TypedPropertyDescriptor,
    &stru_2A096E0,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsi.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsi.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyColorLeftArm;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3>::PropDescriptor<G3D::Color3 (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(G3D::Color3 const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3> *)&stru_2A09738,
    "LeftArmColor",
    "Body Colors",
    RBX::HumanoidDescription::getBodyColorLeftArm,
    0,
    RBX::Security::Permissions::None,
    flagsi,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<G3D::Color3>::~TypedPropertyDescriptor,
    &stru_2A09738,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsj.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsj.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyColorRightLeg;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3>::PropDescriptor<G3D::Color3 (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(G3D::Color3 const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3> *)&stru_2A09790,
    "RightLegColor",
    "Body Colors",
    RBX::HumanoidDescription::getBodyColorRightLeg,
    0,
    RBX::Security::Permissions::None,
    flagsj,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<G3D::Color3>::~TypedPropertyDescriptor,
    &stru_2A09790,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsk.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsk.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyColorLeftLeg;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3>::PropDescriptor<G3D::Color3 (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(G3D::Color3 const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,G3D::Color3> *)&stru_2A097E8,
    "LeftLegColor",
    "Body Colors",
    RBX::HumanoidDescription::getBodyColorLeftLeg,
    0,
    RBX::Security::Permissions::None,
    flagsk,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<G3D::Color3>::~TypedPropertyDescriptor,
    &stru_2A097E8,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsl.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsl.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAccessoriesHat;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09840,
    "HatAccessory",
    "Accessories",
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getAccessoriesHat,
    0,
    RBX::Security::Permissions::None,
    flagsl,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A09840,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsm.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsm.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAccessoriesHair;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09898,
    "HairAccessory",
    "Accessories",
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getAccessoriesHair,
    0,
    RBX::Security::Permissions::None,
    flagsm,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A09898,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsn.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsn.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAccessoriesFace;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A098F0,
    "FaceAccessory",
    "Accessories",
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getAccessoriesFace,
    0,
    RBX::Security::Permissions::None,
    flagsn,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A098F0,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagso.flags = *(_QWORD *)&attributes.isDeprecated;
  flagso.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAccessoriesNeck;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09948,
    "NeckAccessory",
    "Accessories",
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getAccessoriesNeck,
    0,
    RBX::Security::Permissions::None,
    flagso,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A09948,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsp.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsp.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAccessoriesShoulders;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A099A0,
    "ShouldersAccessory",
    "Accessories",
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getAccessoriesShoulders,
    0,
    RBX::Security::Permissions::None,
    flagsp,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A099A0,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsq.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsq.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAccessoriesFront;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A099F8,
    "FrontAccessory",
    "Accessories",
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getAccessoriesFront,
    0,
    RBX::Security::Permissions::None,
    flagsq,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A099F8,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsr.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsr.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAccessoriesBack;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09A50,
    "BackAccessory",
    "Accessories",
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getAccessoriesBack,
    0,
    RBX::Security::Permissions::None,
    flagsr,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A09A50,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagss.flags = *(_QWORD *)&attributes.isDeprecated;
  flagss.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAccessoriesWaist;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string const&)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A09AA8,
    "WaistAccessory",
    "Accessories",
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getAccessoriesWaist,
    0,
    RBX::Security::Permissions::None,
    flagss,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A09AA8,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagst.flags = *(_QWORD *)&attributes.isDeprecated;
  flagst.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setClothesShirt;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09B00,
    "Shirt",
    "Clothes",
    RBX::HumanoidDescription::getClothesShirt,
    0,
    RBX::Security::Permissions::None,
    flagst,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09B00,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsu.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsu.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setClothesPants;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09B58,
    "Pants",
    "Clothes",
    RBX::HumanoidDescription::getClothesPants,
    0,
    RBX::Security::Permissions::None,
    flagsu,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09B58,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsv.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsv.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setClothesGraphicTShirt;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09BB0,
    "GraphicTShirt",
    "Clothes",
    RBX::HumanoidDescription::getClothesGraphicTShirt,
    0,
    RBX::Security::Permissions::None,
    flagsv,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09BB0,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsw.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsw.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyPartsFace;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09C08,
    "Face",
    "Body Parts",
    RBX::HumanoidDescription::getBodyPartsFace,
    0,
    RBX::Security::Permissions::None,
    flagsw,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09C08,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsx.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsx.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyPartsHead;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09C60,
    "Head",
    "Body Parts",
    RBX::HumanoidDescription::getBodyPartsHead,
    0,
    RBX::Security::Permissions::None,
    flagsx,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09C60,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsy.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsy.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyPartsTorso;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09CB8,
    "Torso",
    "Body Parts",
    RBX::HumanoidDescription::getBodyPartsTorso,
    0,
    RBX::Security::Permissions::None,
    flagsy,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09CB8,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsz.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsz.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyPartsLeftArm;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09D10,
    "LeftArm",
    "Body Parts",
    RBX::HumanoidDescription::getBodyPartsLeftArm,
    0,
    RBX::Security::Permissions::None,
    flagsz,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09D10,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsba.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsba.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyPartsRightArm;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09D68,
    "RightArm",
    "Body Parts",
    RBX::HumanoidDescription::getBodyPartsRightArm,
    0,
    RBX::Security::Permissions::None,
    flagsba,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09D68,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbb.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbb.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyPartsLeftLeg;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09DC0,
    "LeftLeg",
    "Body Parts",
    RBX::HumanoidDescription::getBodyPartsLeftLeg,
    0,
    RBX::Security::Permissions::None,
    flagsbb,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09DC0,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbc.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbc.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setBodyPartsRightLeg;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09E18,
    "RightLeg",
    "Body Parts",
    RBX::HumanoidDescription::getBodyPartsRightLeg,
    0,
    RBX::Security::Permissions::None,
    flagsbc,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09E18,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbd.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbd.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAnimationWalk;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09E70,
    "WalkAnimation",
    "Animation",
    RBX::HumanoidDescription::getAnimationWalk,
    0,
    RBX::Security::Permissions::None,
    flagsbd,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09E70,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbe.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbe.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAnimationRun;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09EC8,
    "RunAnimation",
    "Animation",
    RBX::HumanoidDescription::getAnimationRun,
    0,
    RBX::Security::Permissions::None,
    flagsbe,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09EC8,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbf.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbf.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAnimationFall;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09F20,
    "FallAnimation",
    "Animation",
    RBX::HumanoidDescription::getAnimationFall,
    0,
    RBX::Security::Permissions::None,
    flagsbf,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09F20,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbg.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbg.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAnimationJump;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09F78,
    "JumpAnimation",
    "Animation",
    RBX::HumanoidDescription::getAnimationJump,
    0,
    RBX::Security::Permissions::None,
    flagsbg,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09F78,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbh.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbh.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAnimationSwim;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A09FD0,
    "SwimAnimation",
    "Animation",
    RBX::HumanoidDescription::getAnimationSwim,
    0,
    RBX::Security::Permissions::None,
    flagsbh,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A09FD0,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbi.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbi.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAnimationClimb;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A0A028,
    "ClimbAnimation",
    "Animation",
    RBX::HumanoidDescription::getAnimationClimb,
    0,
    RBX::Security::Permissions::None,
    flagsbi,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A0A028,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 31;
  *(_QWORD *)&flagsbj.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbj.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setAnimationIdle;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long>::PropDescriptor<long (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(long)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,long> *)&stru_2A0A080,
    "IdleAnimation",
    "Animation",
    RBX::HumanoidDescription::getAnimationIdle,
    0,
    RBX::Security::Permissions::None,
    flagsbj,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<long>::~TypedPropertyDescriptor,
    &stru_2A0A080,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 14;
  *(_QWORD *)&flagsbk.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbk.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setEmotesData;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A0A0D8,
    "EmotesDataInternal",
    &stru_458781.gap0,
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getEmotesData,
    0,
    RBX::Security::Permissions::None,
    flagsbk,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A0A0D8,
    &dso_handle);
  attributes.isDeprecated = 0;
  LODWORD(v49) = 14;
  v50.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setEquippedEmotesData;
  *(_QWORD *)&flagsbl.flags = *(_QWORD *)&attributes.isDeprecated;
  flagsbl.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::HumanoidDescription::setEquippedEmotesData;
  RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string>::PropDescriptor<std::string (RBX::HumanoidDescription::*)(void)const,void (RBX::HumanoidDescription::*)(std::string)>(
    (RBX::Reflection::PropDescriptor<RBX::HumanoidDescription,std::string > *)&stru_2A0A130,
    "EquippedEmotesDataInternal",
    &stru_458781.gap0,
    (std::string (*)(const RBX::HumanoidDescription *))RBX::HumanoidDescription::getEquippedEmotesData,
    0,
    RBX::Security::Permissions::None,
    flagsbl,
    0,
    v49);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<std::string>::~TypedPropertyDescriptor,
    &stru_2A0A130,
    &dso_handle);
  attributes.isDeprecated = 0;
  flagsbm.preferred = *(const RBX::Reflection::Descriptor **)&attributes.isDeprecated;
  *(_DWORD *)&flagsbm.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(std::string,long),2>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void (std::string,long),2> *)&unk_2A0A188,
    (RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void (std::string,long),2>::FunctionPtr)RBX::HumanoidDescription::addEmoteLua,
    0,
    "AddEmote",
    "name",
    "assetId",
    flagsbm,
    0);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(std::string,long),2>::~BoundFuncDesc,
    &unk_2A0A188,
    &dso_handle);
  attributes.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(std::string),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void (std::string),1> *)&unk_2A0A210,
    (RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void (std::string),1>::FunctionPtr)RBX::HumanoidDescription::removeEmoteLua,
    0,
    "RemoveEmote",
    (RBX::Security::Permissions)"name",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&attributes.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(std::string),1>::~BoundFuncDesc,
    &unk_2A0A210,
    &dso_handle);
  DescriptorPtr = Class_getDescriptorPtr((RBX::HumanoidDescription *)RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(std::string),1>::~BoundFuncDesc);
  v51.isDeprecated = 0;
  v51.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A0A290,
    DescriptorPtr,
    "GetEmotes",
    RBX::Security::Permissions::None,
    v51);
  qword_2A0A290[0] = &off_2898698;
  xmmword_2A0A2F8 = (unsigned __int64)RBX::HumanoidDescription::getEmotesLua;
  qword_2A0A2D0 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A0A290, &dso_handle);
  attributes.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >),1> *)&unk_2A0A308,
    RBX::HumanoidDescription::setEmotesLua,
    0,
    "SetEmotes",
    (RBX::Security::Permissions)"emotes",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&attributes.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>),1>::~BoundFuncDesc,
    &unk_2A0A308,
    &dso_handle);
  attributes.isDeprecated = 0;
  RBX::Reflection::EventDesc<RBX::HumanoidDescription,void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>),rbx::signal<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)>,rbx::signal<void ()(boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>)> RBX::HumanoidDescription::*>::EventDesc(
    (RBX::HumanoidDescription *)&unk_28597D0,
    (rbx::signal<void (boost::shared_ptr<const boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string >,std::allocator<std::pair<const std::string,RBX::Reflection::Variant> > > >)> *)&inputbuff.encodingTable[5].bitLength,
    "EmotesChanged",
    "newEmotes",
    RBX::Security::Permissions::None,
    v1,
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&attributes.isDeprecated);
  __cxa_atexit((void (*)(void *))RBX::Reflection::EventDescriptor::~EventDescriptor, &unk_28597D0, &dso_handle);
  v2 = Class_getDescriptorPtr((RBX::HumanoidDescription *)RBX::Reflection::EventDescriptor::~EventDescriptor);
  v52.isDeprecated = 0;
  v52.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A0A388,
    v2,
    "GetEquippedEmotes",
    RBX::Security::Permissions::None,
    v52);
  qword_2A0A388[0] = &off_2898778;
  xmmword_2A0A3F0 = (unsigned __int64)RBX::HumanoidDescription::getEquippedEmotesLua;
  qword_2A0A3C8 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A0A388, &dso_handle);
  attributes.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >),1> *)&unk_2A0A400,
    RBX::HumanoidDescription::setEquippedEmotesLua,
    0,
    "SetEquippedEmotes",
    (RBX::Security::Permissions)"equippedEmotes",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&attributes.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::HumanoidDescription,void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>),1>::~BoundFuncDesc,
    &unk_2A0A400,
    &dso_handle);
  attributes.isDeprecated = 0;
  RBX::Reflection::EventDesc<RBX::HumanoidDescription,void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>),rbx::signal<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)>,rbx::signal<void ()(boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>)> RBX::HumanoidDescription::*>::EventDesc(
    (RBX::HumanoidDescription *)&unk_2859838,
    (rbx::signal<void (boost::shared_ptr<const std::vector<RBX::Reflection::Variant> >)> *)&inputbuff.encodingTable[6],
    "EquippedEmotesChanged",
    "newEquippedEmotes",
    RBX::Security::Permissions::None,
    v3,
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&attributes.isDeprecated);
  __cxa_atexit((void (*)(void *))RBX::Reflection::EventDescriptor::~EventDescriptor, &unk_2859838, &dso_handle);
  v4 = Class_getDescriptorPtr((RBX::HumanoidDescription *)RBX::Reflection::EventDescriptor::~EventDescriptor);
  v5 = (char *)operator new(0x28u);
  *(_QWORD *)v5 = &off_2898918;
  *(_OWORD *)(v5 + 8) = (unsigned __int64)RBX::HumanoidDescription::getNumberEmotesLoaded;
  *(_OWORD *)(v5 + 24) = (unsigned __int64)RBX::HumanoidDescription::setNumberEmotesLoaded;
  attributes.isDeprecated = 0;
  attributes.preferred = 0;
  LODWORD(v49) = 18;
  v6 = RBX::Reflection::Type::getSingleton<int>();
  *(_QWORD *)&flagsbn.flags = v49;
  flagsbn.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&attributes);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A0A480,
    v4,
    v6,
    "NumberEmotesLoaded",
    "Animation",
    flagsbn,
    RBX::Security::Permissions::RobloxScript,
    RBX::Security::Permissions::RobloxScript,
    0);
  stru_2A0A480._vptr$Descriptor = (int (**)(void))&off_287C6B8;
  qword_2A0A4D0 = (__int64)v5;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v5 + 24LL))(v5) )
    *((_BYTE *)&stru_2A0A480.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A0A480._vptr$Descriptor + 3))(&stru_2A0A480) )
    *((_BYTE *)&stru_2A0A480.security + 4) &= 0xF3u;
  stru_2A0A480._vptr$Descriptor = (int (**)(void))&off_2898858;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<int>::~TypedPropertyDescriptor,
    &stru_2A0A480,
    &dso_handle);
  boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::unordered_set<int const*>(
    &stru_2A0A4D8,
    &dword_4AEC30,
    &dword_4AEC58);
  __cxa_atexit(
    (void (*)(void *))boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::~unordered_set,
    &stru_2A0A4D8,
    &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_1);
}


