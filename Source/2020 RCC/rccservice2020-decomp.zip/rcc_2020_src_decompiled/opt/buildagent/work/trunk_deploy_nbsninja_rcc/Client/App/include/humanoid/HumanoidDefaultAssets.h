// Address: 0x10dbb20 | Name: _ZN3RBX24HumanoidDefaultBodyPartsD0Ev
void __fastcall RBX::HumanoidDefaultBodyParts::~HumanoidDefaultBodyParts(RBX::HumanoidDefaultBodyParts *this)
{
  *(_QWORD *)this = &off_28952E8;
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    operator delete(*((void **)this + 3));
  operator delete(this);
}


// Address: 0x10dbb50 | Name: _ZN3RBX24HumanoidDefaultInstancesD2Ev
void __fastcall RBX::HumanoidDefaultInstances::~HumanoidDefaultInstances(RBX::HumanoidDefaultInstances *this)
{
  *(_QWORD *)this = &off_28952E8;
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    operator delete(*((void **)this + 3));
}


// Address: 0x10dbb70 | Name: _ZN3RBX27HumanoidDefaultBodyPartsR15D0Ev
void __fastcall RBX::HumanoidDefaultBodyPartsR15::~HumanoidDefaultBodyPartsR15(RBX::HumanoidDefaultBodyPartsR15 *this)
{
  *(_QWORD *)this = &off_28952E8;
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    operator delete(*((void **)this + 3));
  operator delete(this);
}


