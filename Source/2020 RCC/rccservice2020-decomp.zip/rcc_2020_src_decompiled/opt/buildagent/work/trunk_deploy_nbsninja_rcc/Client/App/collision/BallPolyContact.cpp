// Address: 0x1deb250 | Name: _ZN3RBX9Collision15BallPolyContact25updateBallVertexCollisionEfRKN3G3D7Vector3Ei
void __fastcall RBX::Collision::BallPolyContact::updateBallVertexCollision(
        RBX::Collision::BallPolyContact *this,
        float radius,
        const RBX::Vector3 *offset,
        int vertexId)
{
  RBX::CollisionConnector *collisionConnector; // rcx
  RBX::Body *bodyA; // rax
  RBX::Body *bodyB; // rcx
  __m128 x_low; // xmm1
  __m128 y_low; // xmm0
  __m128 z_low; // xmm6
  __m128 v10; // xmm1
  RBX::CollisionConnector *v11; // rax
  G3D::Vector3 v13; // [rsp+10h] [rbp-38h] BYREF
  __m128 v14; // [rsp+20h] [rbp-28h]
  __m128 v15; // [rsp+30h] [rbp-18h]

  collisionConnector = this->collisionConnector;
  bodyA = collisionConnector->bodyA;
  bodyB = collisionConnector->bodyB;
  x_low = (__m128)LODWORD(offset->x);
  y_low = (__m128)LODWORD(offset->y);
  z_low = (__m128)LODWORD(offset->z);
  v15 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(z_low, z_low, 224),
              _mm_unpacklo_ps(
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(y_low, y_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(x_low, x_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]))))));
  z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][2])
                            + (float)((float)(y_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][1])
                                    + (float)(x_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][0])))
                    + bodyB->pv.position.translation.z;
  v14 = z_low;
  v10 = _mm_sub_ps(v15, (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.x);
  y_low.m128_f32[0] = z_low.m128_f32[0] - bodyA->pv.position.translation.z;
  _mm_storel_ps((double *)&v13.x, v10);
  LODWORD(v13.z) = y_low.m128_i32[0];
  y_low.m128_f32[0] = G3D::Vector3::unitize(&v13, v10.m128_f32[0]);
  v11 = this->collisionConnector;
  _mm_storel_ps((double *)&v11->contactPoint.x, v15);
  LODWORD(v11->contactPoint.z) = v14.m128_i32[0];
  v11->normal = v13;
  v11->depth = y_low.m128_f32[0] - radius;
}


// Address: 0x1deb380 | Name: _ZN3RBX9Collision15BallPolyContact23updateBallEdgeCollisionEfRKN3G3D7Vector3ES5_i
void __fastcall RBX::Collision::BallPolyContact::updateBallEdgeCollision(
        RBX::Collision::BallPolyContact *this,
        float radius,
        const RBX::Vector3 *offset,
        const RBX::Vector3 *normal,
        int edgeId)
{
  RBX::CollisionConnector *collisionConnector; // rcx
  RBX::Body *bodyA; // rax
  RBX::Body *bodyB; // rcx
  __m128 x_low; // xmm6
  __m128 y_low; // xmm4
  __m128 z_low; // xmm2
  __m128 v11; // xmm3
  __m128 v12; // xmm9
  __m128 v13; // xmm8
  __m128 v14; // xmm10
  float v15; // xmm5_4
  __m128 v16; // xmm0
  __m128 v17; // xmm7
  __m128 v18; // xmm1
  __m128 v19; // xmm4
  __m128 v20; // xmm4
  __m128 v21; // xmm1
  __m128 v22; // xmm10
  __m128 v23; // xmm3
  __m128 v24; // xmm10
  RBX::CollisionConnector *v25; // rax
  G3D::Vector3 v27; // [rsp+10h] [rbp-38h] BYREF
  __m128 v28; // [rsp+20h] [rbp-28h]
  __m128 v29; // [rsp+30h] [rbp-18h]

  collisionConnector = this->collisionConnector;
  bodyA = collisionConnector->bodyA;
  bodyB = collisionConnector->bodyB;
  x_low = (__m128)LODWORD(offset->x);
  y_low = (__m128)LODWORD(offset->y);
  z_low = (__m128)LODWORD(offset->z);
  v11 = _mm_unpacklo_ps(
          (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]),
          (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]));
  v12 = _mm_unpacklo_ps(
          (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]),
          (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]));
  v13 = _mm_unpacklo_ps(
          (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
          (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]));
  v14 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(z_low, z_low, 224), v13),
            _mm_add_ps(
              _mm_mul_ps(_mm_shuffle_ps(y_low, y_low, 224), v12),
              _mm_mul_ps(_mm_shuffle_ps(x_low, x_low, 224), v11))));
  v15 = bodyB->pv.position.rotation.elt[2][0];
  v16 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[2][1]);
  y_low.m128_f32[0] = (float)(y_low.m128_f32[0] * v16.m128_f32[0]) + (float)(x_low.m128_f32[0] * v15);
  x_low.m128_i32[0] = LODWORD(bodyB->pv.position.rotation.elt[2][2]);
  z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * x_low.m128_f32[0]) + y_low.m128_f32[0])
                    + bodyB->pv.position.translation.z;
  v17 = (__m128)LODWORD(normal->x);
  v18 = (__m128)LODWORD(normal->y);
  v19 = (__m128)LODWORD(normal->z);
  x_low.m128_f32[0] = x_low.m128_f32[0] * v19.m128_f32[0];
  v20 = _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(v19, v19, 224), v13),
          _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v18, v18, 224), v12), _mm_mul_ps(_mm_shuffle_ps(v17, v17, 224), v11)));
  v16.m128_f32[0] = (float)((float)(v16.m128_f32[0] * v18.m128_f32[0]) + (float)(v15 * v17.m128_f32[0]))
                  + x_low.m128_f32[0];
  v21 = (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.x;
  v22 = _mm_sub_ps(v14, v21);
  v17.m128_i32[0] = LODWORD(bodyA->pv.position.translation.z);
  z_low.m128_f32[0] = z_low.m128_f32[0] - v17.m128_f32[0];
  v23 = v16;
  v23.m128_f32[0] = (float)(v16.m128_f32[0] * z_low.m128_f32[0])
                  + (float)((float)(_mm_shuffle_ps(v20, v20, 229).m128_f32[0] * _mm_shuffle_ps(v22, v22, 229).m128_f32[0])
                          + (float)(v20.m128_f32[0] * v22.m128_f32[0]));
  v24 = _mm_sub_ps(v22, _mm_mul_ps(_mm_shuffle_ps(v23, v23, 224), v20));
  _mm_storel_ps((double *)&v27.x, v24);
  v27.z = z_low.m128_f32[0] - (float)(v16.m128_f32[0] * v23.m128_f32[0]);
  v29 = _mm_add_ps(v24, v21);
  z_low.m128_f32[0] = v27.z + v17.m128_f32[0];
  v28 = z_low;
  v16.m128_f32[0] = G3D::Vector3::unitize(&v27, v21.m128_f32[0]);
  v25 = this->collisionConnector;
  _mm_storel_ps((double *)&v25->contactPoint.x, v29);
  LODWORD(v25->contactPoint.z) = v28.m128_i32[0];
  v25->normal = v27;
  v25->depth = v16.m128_f32[0] - radius;
}


// Address: 0x1deb550 | Name: _ZN3RBX9Collision15BallPolyContact24updateBallPlaneCollisionEfRKN3G3D7Vector3ES5_i
void __fastcall RBX::Collision::BallPolyContact::updateBallPlaneCollision(
        RBX::Collision::BallPolyContact *this,
        float radius,
        const RBX::Vector3 *offset,
        const RBX::Vector3 *normal,
        int faceId)
{
  RBX::CollisionConnector *collisionConnector; // rax
  RBX::Body *bodyB; // rdi
  float y; // xmm4_4
  float z; // xmm2_4
  float v9; // xmm3_4
  __m128 v10; // xmm13
  __m128 v11; // xmm12
  __m128 v12; // xmm10
  __m128 v13; // xmm1
  float v14; // xmm14_4
  float v15; // xmm5_4
  float v16; // xmm15_4
  float v17; // xmm2_4
  __m128 x_low; // xmm7
  __m128 y_low; // xmm6
  __m128 z_low; // xmm4
  float v21; // xmm5_4
  __m128 v22; // xmm4
  __m128 v23; // xmm7
  __m128 v24; // xmm2
  __m128 v25; // xmm7
  float v26; // xmm3_4

  collisionConnector = this->collisionConnector;
  bodyB = collisionConnector->bodyB;
  y = offset->y;
  z = offset->z;
  v9 = (float)((float)(bodyB->pv.position.rotation.elt[0][2] * z)
             + (float)((float)(bodyB->pv.position.rotation.elt[0][1] * y)
                     + (float)(bodyB->pv.position.rotation.elt[0][0] * offset->x)))
     + bodyB->pv.position.translation.x;
  v10 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]);
  v11 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]);
  v12 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]);
  v13 = (__m128)LODWORD(z);
  v14 = bodyB->pv.position.rotation.elt[2][0];
  v15 = bodyB->pv.position.rotation.elt[2][1];
  v16 = bodyB->pv.position.rotation.elt[2][2];
  v17 = (float)((float)(z * v16) + (float)((float)(y * v15) + (float)(offset->x * v14)))
      + bodyB->pv.position.translation.z;
  x_low = (__m128)LODWORD(normal->x);
  y_low = (__m128)LODWORD(normal->y);
  z_low = (__m128)LODWORD(normal->z);
  v21 = (float)((float)(v15 * y_low.m128_f32[0]) + (float)(v14 * x_low.m128_f32[0])) + (float)(v16 * z_low.m128_f32[0]);
  v22 = _mm_xor_ps(
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(z_low, z_low, 224),
              _mm_unpacklo_ps((__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]), v12)),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(y_low, y_low, 224),
                _mm_unpacklo_ps((__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]), v11)),
              _mm_mul_ps(
                _mm_shuffle_ps(x_low, x_low, 224),
                _mm_unpacklo_ps((__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]), v10)))),
          *(__m128 *)&stru_3E4970.x);
  v23 = (__m128)*(unsigned __int64 *)&collisionConnector->bodyA->pv.position.translation.x;
  y_low.m128_i32[0] = LODWORD(collisionConnector->bodyA->pv.position.translation.z);
  v13.m128_f32[0] = (float)((float)((float)((float)((float)((float)(v13.m128_f32[0] * v12.m128_f32[0])
                                                          + (float)((float)(offset->y * v11.m128_f32[0])
                                                                  + (float)(offset->x * v10.m128_f32[0])))
                                                  + bodyB->pv.position.translation.y)
                                          - *(float *)_mm_shuffle_epi32((__m128i)v23, 229).m128i_i32)
                                  * *(float *)_mm_shuffle_epi32((__m128i)v22, 229).m128i_i32)
                          + (float)((float)(v9 - v23.m128_f32[0]) * v22.m128_f32[0]))
                  - (float)((float)(v17 - y_low.m128_f32[0]) * v21);
  v24 = _mm_mul_ps(_mm_shuffle_ps(v13, v13, 224), v22);
  v13.m128_f32[0] = v13.m128_f32[0] * (float)-v21;
  v25 = _mm_add_ps(v23, v24);
  v26 = v24.m128_f32[0] * v24.m128_f32[0];
  v24.m128_f32[0] = _mm_shuffle_ps(v24, v24, 229).m128_f32[0];
  _mm_storel_ps((double *)&collisionConnector->contactPoint.x, v25);
  collisionConnector->contactPoint.z = y_low.m128_f32[0] + v13.m128_f32[0];
  *(_QWORD *)&collisionConnector->normal.x = v22.m128_u64[0];
  collisionConnector->normal.z = -v21;
  collisionConnector->depth = fsqrt(
                                (float)(v13.m128_f32[0] * v13.m128_f32[0])
                              + (float)((float)(v24.m128_f32[0] * v24.m128_f32[0]) + v26))
                            - radius;
}


// Address: 0x1deb740 | Name: _ZN3RBX9Collision15BallPolyContact16getFarthestPlaneERfRKN3G3D7Vector3E
const RBX::POLY::Face *__fastcall RBX::Collision::BallPolyContact::getFarthestPlane(
        RBX::Collision::BallPolyContact *this,
        float *planeToCenter,
        const RBX::Vector3 *ballInPoly)
{
  __int64 v3; // rax
  __int64 v4; // r10
  __int64 v5; // rax
  const RBX::POLY::Face *result; // rax
  unsigned __int64 v7; // r8
  float v8; // xmm0_4
  __int64 v9; // r11
  unsigned __int64 v10; // rcx
  __int64 v11; // rdi
  __m128 v12; // xmm1
  float v13; // xmm1_4

  *planeToCenter = -3.4028235e38;
  v3 = *(_QWORD *)(*((_QWORD *)this->prim1 + 18) + 40LL);
  v4 = *(_QWORD *)(v3 + 48);
  v5 = *(_QWORD *)(v3 + 56) - v4;
  if ( !v5 )
    return 0;
  v7 = 0xAAAAAAAAAAAAAAABLL * (v5 >> 4);
  v8 = -3.4028235e38;
  v9 = 0;
  result = 0;
  v10 = 0;
  do
  {
    v11 = 48 * (v9 >> 32);
    v12 = _mm_mul_ps((__m128)*(unsigned __int64 *)&ballInPoly->y, (__m128)*(unsigned __int64 *)(v4 + v11 + 36));
    v13 = (float)(_mm_shuffle_ps(v12, v12, 229).m128_f32[0]
                + (float)((float)(*(float *)(v4 + v11 + 32) * ballInPoly->x) + v12.m128_f32[0]))
        - *(float *)(v4 + v11 + 44);
    if ( v13 > v8 )
    {
      *planeToCenter = v13;
      v8 = v13;
      result = (const RBX::POLY::Face *)(v4 + v11);
    }
    ++v10;
    v9 += 0x100000000LL;
  }
  while ( v10 < v7 );
  return result;
}


// Address: 0x1deb7f0 | Name: _ZN3RBX9Collision15BallPolyContact14getClosestEdgeEPKNS_4POLY4FaceERfRKN3G3D7Vector3E
const RBX::POLY::Edge *__fastcall RBX::Collision::BallPolyContact::getClosestEdge(
        RBX::Collision::BallPolyContact *this,
        const RBX::POLY::Face *face,
        float *edgeToCenter,
        const RBX::Vector3 *ballInPoly)
{
  __int64 v4; // rax
  unsigned __int64 v7; // r13
  const RBX::POLY::Edge *v8; // r12
  const RBX::POLY::Vertex *v9; // rax
  const RBX::POLY::Vertex *v10; // rcx
  __m128 v11; // xmm2
  __m128 v12; // xmm0
  float v13; // xmm3_4
  __m128 v14; // xmm1
  __m128 v15; // xmm1
  float v16; // xmm3_4
  __m128 v17; // xmm3
  __m128 v18; // xmm1
  __m128 v19; // xmm1
  float v20; // xmm0_4
  const RBX::POLY::Edge *v22; // [rsp+0h] [rbp-58h]
  G3D::Line v23; // [rsp+8h] [rbp-50h] BYREF
  G3D::Vector3 v24; // 0:kr00_12.12

  *edgeToCenter = 3.4028235e38;
  v4 = *((_QWORD *)face + 1);
  if ( *((_QWORD *)face + 2) == v4 )
    return 0;
  v22 = 0;
  v7 = 0;
  do
  {
    v8 = *(const RBX::POLY::Edge **)(v4 + 8 * v7);
    v9 = v8->vertex[0];
    v10 = v8->vertex[1];
    v11 = _mm_sub_ps((__m128)*((unsigned __int64 *)v10 + 1), (__m128)*((unsigned __int64 *)v9 + 1));
    v12 = (__m128)*((unsigned int *)v10 + 4);
    v12.m128_f32[0] = v12.m128_f32[0] - *((float *)v9 + 4);
    v13 = _mm_shuffle_ps(v11, v11, 229).m128_f32[0];
    v14 = (__m128)0x3F800000u;
    v14.m128_f32[0] = 1.0
                    / fsqrt(
                        (float)(v12.m128_f32[0] * v12.m128_f32[0])
                      + (float)((float)(v13 * v13) + (float)(v11.m128_f32[0] * v11.m128_f32[0])));
    v12.m128_f32[0] = v12.m128_f32[0] * v14.m128_f32[0];
    v15 = _mm_mul_ps(_mm_shuffle_ps(v14, v14, 224), v11);
    v23._vptr$Line = (int (**)(void))&edgeLine1;
    v23._point = *(G3D::Vector3 *)((char *)v9 + 8);
    v16 = _mm_shuffle_ps(v15, v15, 229).m128_f32[0];
    v11.m128_f32[0] = fsqrt(
                        (float)(v12.m128_f32[0] * v12.m128_f32[0])
                      + (float)((float)(v16 * v16) + (float)(v15.m128_f32[0] * v15.m128_f32[0])));
    v17 = (__m128)0x3F800000u;
    v17.m128_f32[0] = 1.0 / v11.m128_f32[0];
    _mm_storel_ps((double *)&v23._direction.x, _mm_mul_ps(_mm_shuffle_ps(v17, v17, 224), v15));
    v23._direction.z = v12.m128_f32[0] * (float)(1.0 / v11.m128_f32[0]);
    v24 = G3D::Line::closestPoint(&v23, ballInPoly);
    v12.m128_i32[0] = LODWORD(v24.x);
    v12.m128_i32[1] = LODWORD(v24.y);
    v15.m128_i32[0] = LODWORD(v24.z);
    v11.m128_f32[0] = _mm_shuffle_ps(v12, v12, 229).m128_f32[0];
    v18 = _mm_sub_ps(
            _mm_shuffle_ps(_mm_shuffle_ps(v15, v12, 0), v12, 226),
            _mm_unpacklo_ps((__m128)LODWORD(ballInPoly->x), (__m128)LODWORD(ballInPoly->z)));
    v19 = _mm_mul_ps(v18, v18);
    v20 = fsqrt(
            _mm_shuffle_ps(v19, v19, 229).m128_f32[0]
          + (float)((float)((float)(v11.m128_f32[0] - ballInPoly->y) * (float)(v11.m128_f32[0] - ballInPoly->y))
                  + v19.m128_f32[0]));
    if ( *edgeToCenter > v20 )
    {
      *edgeToCenter = v20;
      v22 = v8;
    }
    ++v7;
    v4 = *((_QWORD *)face + 1);
  }
  while ( v7 < (*((_QWORD *)face + 2) - v4) >> 3 );
  return v22;
}


// Address: 0x1deb990 | Name: _ZN3RBX9Collision15BallPolyContact23getClosestInVoronoiEdgeEPKNS_4POLY4FaceERfRKN3G3D7Vector3E
const RBX::POLY::Edge *__fastcall RBX::Collision::BallPolyContact::getClosestInVoronoiEdge(
        RBX::Collision::BallPolyContact *this,
        const RBX::POLY::Face *face,
        float *edgeToCenter,
        const RBX::Vector3 *ballInPoly)
{
  __int64 v4; // rax
  unsigned __int64 v7; // r13
  const RBX::POLY::Edge *v8; // rbp
  const RBX::POLY::Vertex *v9; // rax
  const RBX::POLY::Vertex *v10; // rcx
  __m128 v11; // xmm2
  __m128 v12; // xmm0
  float v13; // xmm3_4
  __m128 v14; // xmm1
  __m128 v15; // xmm1
  float v16; // xmm3_4
  __m128 v17; // xmm3
  __m128 v18; // xmm1
  __m128 v19; // xmm1
  float v20; // xmm1_4
  const RBX::POLY::Edge *v22; // [rsp+8h] [rbp-60h]
  G3D::Line v23; // [rsp+18h] [rbp-50h] BYREF
  G3D::Vector3 v24; // 0:kr00_12.12

  *edgeToCenter = 3.4028235e38;
  v4 = *((_QWORD *)face + 1);
  if ( *((_QWORD *)face + 2) == v4 )
    return 0;
  v22 = 0;
  v7 = 0;
  do
  {
    v8 = *(const RBX::POLY::Edge **)(v4 + 8 * v7);
    v9 = v8->vertex[0];
    v10 = v8->vertex[1];
    v11 = _mm_sub_ps((__m128)*((unsigned __int64 *)v10 + 1), (__m128)*((unsigned __int64 *)v9 + 1));
    v12 = (__m128)*((unsigned int *)v10 + 4);
    v12.m128_f32[0] = v12.m128_f32[0] - *((float *)v9 + 4);
    v13 = _mm_shuffle_ps(v11, v11, 229).m128_f32[0];
    v14 = (__m128)0x3F800000u;
    v14.m128_f32[0] = 1.0
                    / fsqrt(
                        (float)(v12.m128_f32[0] * v12.m128_f32[0])
                      + (float)((float)(v13 * v13) + (float)(v11.m128_f32[0] * v11.m128_f32[0])));
    v12.m128_f32[0] = v12.m128_f32[0] * v14.m128_f32[0];
    v15 = _mm_mul_ps(_mm_shuffle_ps(v14, v14, 224), v11);
    v23._vptr$Line = (int (**)(void))&edgeLine1;
    v23._point = *(G3D::Vector3 *)((char *)v9 + 8);
    v16 = _mm_shuffle_ps(v15, v15, 229).m128_f32[0];
    v11.m128_f32[0] = fsqrt(
                        (float)(v12.m128_f32[0] * v12.m128_f32[0])
                      + (float)((float)(v16 * v16) + (float)(v15.m128_f32[0] * v15.m128_f32[0])));
    v17 = (__m128)0x3F800000u;
    v17.m128_f32[0] = 1.0 / v11.m128_f32[0];
    _mm_storel_ps((double *)&v23._direction.x, _mm_mul_ps(_mm_shuffle_ps(v17, v17, 224), v15));
    v23._direction.z = v12.m128_f32[0] * (float)(1.0 / v11.m128_f32[0]);
    v24 = G3D::Line::closestPoint(&v23, ballInPoly);
    v12.m128_i32[0] = LODWORD(v24.x);
    v12.m128_i32[1] = LODWORD(v24.y);
    v15.m128_i32[0] = LODWORD(v24.z);
    v11.m128_f32[0] = _mm_shuffle_ps(v12, v12, 229).m128_f32[0];
    v18 = _mm_sub_ps(
            _mm_shuffle_ps(_mm_shuffle_ps(v15, v12, 0), v12, 226),
            _mm_unpacklo_ps((__m128)LODWORD(ballInPoly->x), (__m128)LODWORD(ballInPoly->z)));
    v19 = _mm_mul_ps(v18, v18);
    v20 = fsqrt(
            _mm_shuffle_ps(v19, v19, 229).m128_f32[0]
          + (float)((float)((float)(v11.m128_f32[0] - ballInPoly->y) * (float)(v11.m128_f32[0] - ballInPoly->y))
                  + v19.m128_f32[0]));
    if ( *edgeToCenter > v20 && RBX::POLY::Edge::pointInVaronoi(v8, ballInPoly) )
    {
      *edgeToCenter = v20;
      v22 = v8;
    }
    ++v7;
    v4 = *((_QWORD *)face + 1);
  }
  while ( v7 < (*((_QWORD *)face + 2) - v4) >> 3 );
  return v22;
}


// Address: 0x1debb60 | Name: _ZN3RBX9Collision15BallPolyContact16getClosestVertexEPKNS_4POLY4EdgeERfRKN3G3D7Vector3E
const RBX::POLY::Vertex *__fastcall RBX::Collision::BallPolyContact::getClosestVertex(
        RBX::Collision::BallPolyContact *this,
        const RBX::POLY::Edge *edge,
        float *vertexToCenter,
        const RBX::Vector3 *ballInPoly)
{
  const RBX::POLY::Vertex *result; // rax
  float x; // xmm0_4
  __m128 v6; // xmm1
  float v7; // xmm3_4
  __m128 v8; // xmm4
  __m128 v9; // xmm4
  __m128 v10; // xmm4
  float v11; // xmm3_4
  float v12; // xmm2_4
  const RBX::POLY::Vertex *v13; // rcx
  __m128 v14; // xmm1
  __m128 v15; // xmm1
  float v16; // xmm0_4

  *vertexToCenter = 3.4028235e38;
  result = edge->vertex[0];
  x = ballInPoly->x;
  v6 = (__m128)*(unsigned __int64 *)&ballInPoly->y;
  v7 = COERCE_FLOAT(*(_QWORD *)&ballInPoly->y) - *((float *)result + 3);
  v8 = v6;
  v8.m128_f32[0] = ballInPoly->x;
  v9 = _mm_sub_ps(v8, _mm_unpacklo_ps((__m128)*((unsigned int *)result + 2), (__m128)*((unsigned int *)result + 4)));
  v10 = _mm_mul_ps(v9, v9);
  v11 = fsqrt(_mm_shuffle_ps(v10, v10, 229).m128_f32[0] + (float)((float)(v7 * v7) + v10.m128_f32[0]));
  v12 = 3.4028235e38;
  if ( v11 >= 3.4028235e38 )
  {
    result = 0;
  }
  else
  {
    *vertexToCenter = v11;
    x = ballInPoly->x;
    v6 = (__m128)*(unsigned __int64 *)&ballInPoly->y;
    v12 = v11;
  }
  v13 = edge->vertex[1];
  v14 = _mm_sub_ps(v6, (__m128)*(unsigned __int64 *)((char *)v13 + 12));
  v15 = _mm_mul_ps(v14, v14);
  v16 = fsqrt(
          _mm_shuffle_ps(v15, v15, 229).m128_f32[0]
        + (float)((float)((float)(x - *((float *)v13 + 2)) * (float)(x - *((float *)v13 + 2))) + v15.m128_f32[0]));
  if ( v12 > v16 )
  {
    *vertexToCenter = v16;
    return v13;
  }
  return result;
}


// Address: 0x1debc10 | Name: _ZN3RBX9Collision15BallPolyContact20findCollidingFeatureEv
bool __fastcall RBX::Collision::BallPolyContact::findCollidingFeature(RBX::Collision::BallPolyContact *this)
{
  const RBX::CoordinateFrame *CoordinateFrame; // rbx
  unsigned int *v3; // rax
  __m128 v4; // xmm1
  __m128 v5; // xmm0
  __m128 v6; // xmm5
  __m128 v7; // xmm3
  float v8; // xmm0_4
  RBX::Primitive *prim1; // r15
  __int64 v10; // rcx
  __int64 v11; // rax
  __int64 v12; // rdx
  bool result; // al
  __m128 v14; // xmm9
  unsigned __int64 v15; // rcx
  __m128 v16; // xmm1
  __m128 v17; // xmm3
  __int64 v18; // rsi
  __m128 v19; // xmm2
  __int64 v20; // rbx
  unsigned __int64 v21; // rdi
  __int64 v22; // rdx
  __m128 v23; // xmm5
  float v24; // xmm4_4
  __m128 v25; // xmm5
  __int64 v26; // rdx
  __m128 v27; // xmm4
  __m128 v28; // xmm4
  __m128 v29; // xmm1
  __m128 v30; // xmm2
  float v31; // xmm8_4
  char *v32; // r15
  __int64 v33; // rax
  char *v34; // r12
  __int64 v35; // rax
  const RBX::POLY::Edge *ClosestInVoronoiEdge; // rax
  const RBX::POLY::Edge *v37; // r15
  char *v38; // rbx
  __int64 v39; // rax
  const RBX::POLY::Vertex *v40; // rax
  const RBX::POLY::Vertex *v41; // rcx
  float v42; // xmm2_4
  __m128 v43; // xmm4
  float v44; // xmm3_4
  float v45; // xmm1_4
  __m128 v46; // xmm3
  const RBX::POLY::Edge *ClosestEdge; // rax
  const RBX::POLY::Vertex *v48; // rcx
  __m128 v49; // xmm0
  __m128 v50; // xmm4
  __m128 v51; // xmm4
  float v52; // xmm2_4
  unsigned int *v53; // rbx
  const RBX::POLY::Vertex *v54; // rax
  float v55; // xmm2_4
  __m128 v56; // xmm0
  __m128 v57; // xmm0
  float v58; // xmm0_4
  char *collisionConnector; // r15
  __int64 v60; // rax
  __int64 v61; // rax
  __int64 v62; // rcx
  __m128 v63; // xmm1
  __m128 v64; // xmm0
  __m128 v65; // xmm6
  __m128 v66; // xmm1
  RBX::CollisionConnector *v67; // rax
  float v68; // [rsp+Ch] [rbp-7Ch]
  RBX::CollisionParams point; // [rsp+10h] [rbp-78h] BYREF
  float v70; // [rsp+2Ch] [rbp-5Ch] BYREF
  RBX::Vector3 ballInPoly; // [rsp+30h] [rbp-58h] BYREF
  __m128 v72; // [rsp+40h] [rbp-48h]
  __m128 v73; // [rsp+50h] [rbp-38h]

  CoordinateFrame = RBX::Primitive::getCoordinateFrame(this->prim1);
  v3 = (unsigned int *)RBX::Primitive::getCoordinateFrame(this->prim0);
  v4 = (__m128)v3[9];
  v5 = (__m128)v3[10];
  v4.m128_f32[0] = v4.m128_f32[0] - CoordinateFrame->translation.x;
  v5.m128_f32[0] = v5.m128_f32[0] - CoordinateFrame->translation.y;
  v6 = (__m128)v3[11];
  v6.m128_f32[0] = v6.m128_f32[0] - CoordinateFrame->translation.z;
  v7 = _mm_add_ps(
         _mm_mul_ps(_mm_shuffle_ps(v6, v6, 224), (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[2][0]),
         _mm_add_ps(
           _mm_mul_ps(_mm_shuffle_ps(v5, v5, 224), (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[1][0]),
           _mm_mul_ps(_mm_shuffle_ps(v4, v4, 224), (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[0][0])));
  v8 = (float)(v5.m128_f32[0] * CoordinateFrame->rotation.elt[1][2])
     + (float)(v4.m128_f32[0] * CoordinateFrame->rotation.elt[0][2]);
  v6.m128_f32[0] = (float)(v6.m128_f32[0] * CoordinateFrame->rotation.elt[2][2]) + v8;
  v72 = v7;
  _mm_storel_ps((double *)&ballInPoly.x, v7);
  v73 = v6;
  LODWORD(ballInPoly.z) = v6.m128_i32[0];
  (*(void (__fastcall **)(_QWORD))(**((_QWORD **)this->prim0 + 18) + 56LL))(*((_QWORD *)this->prim0 + 18));
  prim1 = this->prim1;
  v10 = *(_QWORD *)(*((_QWORD *)prim1 + 18) + 40LL);
  v11 = *(_QWORD *)(v10 + 48);
  v12 = *(_QWORD *)(v10 + 56) - v11;
  if ( !v12 )
    return 0;
  v14 = _mm_shuffle_ps(v72, v72, 229);
  v15 = 0xAAAAAAAAAAAAAAABLL * (v12 >> 4);
  v16 = _mm_unpacklo_ps(v14, v73);
  v17 = (__m128)0xFF7FFFFF;
  v18 = 0;
  v19 = (__m128)0xFF7FFFFF;
  v20 = 0;
  v21 = 0;
  do
  {
    v22 = 48 * (v18 >> 32);
    v23 = _mm_mul_ps((__m128)*(unsigned __int64 *)(v11 + v22 + 36), v16);
    v24 = (float)(*(float *)(v11 + v22 + 32) * v72.m128_f32[0]) + v23.m128_f32[0];
    v25 = _mm_shuffle_ps(v23, v23, 229);
    v25.m128_f32[0] = (float)(v25.m128_f32[0] + v24) - *(float *)(v11 + v22 + 44);
    v26 = v11 + v22;
    v27 = _mm_cmplt_ss(v19, v25);
    v28 = _mm_or_ps(_mm_andnot_ps(v27, v17), _mm_and_ps(v27, v25));
    if ( v25.m128_f32[0] > v19.m128_f32[0] )
      v20 = v26;
    v25.m128_f32[0] = fmaxf(v25.m128_f32[0], v19.m128_f32[0]);
    ++v21;
    v18 += 0x100000000LL;
    v17 = v28;
    v19 = v25;
  }
  while ( v21 < v15 );
  result = 0;
  if ( v20 && v28.m128_f32[0] <= v8 )
  {
    if ( v28.m128_f32[0] <= 0.0 )
    {
      if ( !this->collisionConnector )
      {
        v68 = v8;
        v34 = (char *)operator new(0x40u);
        RBX::Collision::Contact::computeCollisionParams(&point, this->prim0, prim1);
        v35 = *(_QWORD *)&point.friction;
        *(_OWORD *)v34 = *(_OWORD *)&point.b0;
        *((_QWORD *)v34 + 2) = v35;
        *(_OWORD *)(v34 + 36) = 0;
        *(_OWORD *)(v34 + 24) = 0;
        *((_DWORD *)v34 + 13) = -1;
        v34[56] = 1;
        this->collisionConnector = (RBX::CollisionConnector *)v34;
        goto LABEL_15;
      }
    }
    else
    {
      v68 = v8;
      v29 = (__m128)*(unsigned __int64 *)(v20 + 32);
      v30 = (__m128)*(unsigned int *)(v20 + 40);
      v30.m128_f32[0] = (float)((float)(v30.m128_f32[0] * v73.m128_f32[0])
                              + (float)((float)(*(float *)_mm_shuffle_epi32((__m128i)v29, 229).m128i_i32
                                              * v14.m128_f32[0])
                                      + (float)(COERCE_FLOAT(*(_QWORD *)(v20 + 32)) * v72.m128_f32[0])))
                      - *(float *)(v20 + 44);
      v31 = v73.m128_f32[0] - (float)(v30.m128_f32[0] * *(float *)(v20 + 40));
      _mm_storel_ps(
        (double *)&point,
        _mm_add_ps(
          _mm_mul_ps((__m128)_mm_shuffle_epi32((__m128i)_mm_xor_ps(*(__m128 *)&stru_3E4970.x, v30), 80), v29),
          v72));
      *(float *)&point.b1 = v31;
      if ( !RBX::POLY::Face::pointInFaceBorders((const RBX::POLY::Face *)v20, (const RBX::Vector3 *)&point) )
      {
        ClosestInVoronoiEdge = RBX::Collision::BallPolyContact::getClosestInVoronoiEdge(
                                 (RBX::Collision::BallPolyContact *)v20,
                                 (const RBX::POLY::Face *)v20,
                                 &v70,
                                 &ballInPoly);
        if ( ClosestInVoronoiEdge )
        {
          if ( v70 > v8 )
            return 0;
          v37 = ClosestInVoronoiEdge;
          if ( !this->collisionConnector )
          {
            v38 = (char *)operator new(0x40u);
            RBX::Collision::Contact::computeCollisionParams(&point, this->prim0, this->prim1);
            v39 = *(_QWORD *)&point.friction;
            *(_OWORD *)v38 = *(_OWORD *)&point.b0;
            *((_QWORD *)v38 + 2) = v39;
            *(_OWORD *)(v38 + 36) = 0;
            *(_OWORD *)(v38 + 24) = 0;
            *((_DWORD *)v38 + 13) = -1;
            v38[56] = 1;
            this->collisionConnector = (RBX::CollisionConnector *)v38;
          }
          v40 = v37->vertex[0];
          v41 = v37->vertex[1];
          v42 = *((float *)v41 + 4) - *((float *)v40 + 4);
          v43 = _mm_sub_ps((__m128)*((unsigned __int64 *)v41 + 1), (__m128)*((unsigned __int64 *)v40 + 1));
          v44 = _mm_shuffle_ps(v43, v43, 229).m128_f32[0];
          v45 = fsqrt((float)(v42 * v42) + (float)((float)(v44 * v44) + (float)(v43.m128_f32[0] * v43.m128_f32[0])));
          v46 = (__m128)0x3F800000u;
          v46.m128_f32[0] = 1.0 / v45;
          _mm_storel_ps((double *)&point, _mm_mul_ps(_mm_shuffle_ps(v46, v46, 224), v43));
          *(float *)&point.b1 = v42 * (float)(1.0 / v45);
          RBX::Collision::BallPolyContact::updateBallEdgeCollision(
            this,
            v8,
            (const RBX::Vector3 *)((char *)v40 + 8),
            (const RBX::Vector3 *)&point,
            (int)v41);
        }
        else
        {
          ClosestEdge = RBX::Collision::BallPolyContact::getClosestEdge(
                          (RBX::Collision::BallPolyContact *)v20,
                          (const RBX::POLY::Face *)v20,
                          &v70,
                          &ballInPoly);
          v48 = ClosestEdge->vertex[0];
          v49 = _mm_unpacklo_ps((__m128)LODWORD(ballInPoly.x), (__m128)LODWORD(ballInPoly.z));
          v50 = _mm_sub_ps(v49, _mm_unpacklo_ps((__m128)*((unsigned int *)v48 + 2), (__m128)*((unsigned int *)v48 + 4)));
          v51 = _mm_mul_ps(v50, v50);
          v52 = fsqrt(
                  _mm_shuffle_ps(v51, v51, 229).m128_f32[0]
                + (float)((float)((float)(ballInPoly.y - *((float *)v48 + 3))
                                * (float)(ballInPoly.y - *((float *)v48 + 3)))
                        + v51.m128_f32[0]));
          v53 = 0;
          if ( v52 < 3.4028235e38 )
            v53 = (unsigned int *)ClosestEdge->vertex[0];
          v54 = ClosestEdge->vertex[1];
          v55 = fminf(v52, 3.4028235e38);
          v56 = _mm_sub_ps(v49, _mm_unpacklo_ps((__m128)*((unsigned int *)v54 + 2), (__m128)*((unsigned int *)v54 + 4)));
          v57 = _mm_mul_ps(v56, v56);
          v58 = fsqrt(
                  _mm_shuffle_ps(v57, v57, 229).m128_f32[0]
                + (float)((float)((float)(ballInPoly.y - *((float *)v54 + 3))
                                * (float)(ballInPoly.y - *((float *)v54 + 3)))
                        + v57.m128_f32[0]));
          if ( v55 > v58 )
            v53 = (unsigned int *)v54;
          if ( fminf(v58, v55) > v68 )
            return 0;
          collisionConnector = (char *)this->collisionConnector;
          if ( !collisionConnector )
          {
            collisionConnector = (char *)operator new(0x40u);
            RBX::Collision::Contact::computeCollisionParams(&point, this->prim0, this->prim1);
            v60 = *(_QWORD *)&point.friction;
            *(_OWORD *)collisionConnector = *(_OWORD *)&point.b0;
            *((_QWORD *)collisionConnector + 2) = v60;
            *(_OWORD *)(collisionConnector + 36) = 0;
            *(_OWORD *)(collisionConnector + 24) = 0;
            *((_DWORD *)collisionConnector + 13) = -1;
            collisionConnector[56] = 1;
            this->collisionConnector = (RBX::CollisionConnector *)collisionConnector;
          }
          v61 = *(_QWORD *)collisionConnector;
          v62 = *((_QWORD *)collisionConnector + 1);
          v63 = (__m128)v53[2];
          v64 = (__m128)v53[3];
          v65 = (__m128)v53[4];
          v73 = _mm_add_ps(
                  (__m128)*(unsigned __int64 *)(v62 + 244),
                  _mm_add_ps(
                    _mm_mul_ps(
                      _mm_shuffle_ps(v65, v65, 224),
                      _mm_unpacklo_ps((__m128)*(unsigned int *)(v62 + 216), (__m128)*(unsigned int *)(v62 + 228))),
                    _mm_add_ps(
                      _mm_mul_ps(
                        _mm_shuffle_ps(v64, v64, 224),
                        _mm_unpacklo_ps((__m128)*(unsigned int *)(v62 + 212), (__m128)*(unsigned int *)(v62 + 224))),
                      _mm_mul_ps(
                        _mm_shuffle_ps(v63, v63, 224),
                        _mm_unpacklo_ps((__m128)*(unsigned int *)(v62 + 208), (__m128)*(unsigned int *)(v62 + 220))))));
          v65.m128_f32[0] = (float)((float)(v65.m128_f32[0] * *(float *)(v62 + 240))
                                  + (float)((float)(v64.m128_f32[0] * *(float *)(v62 + 236))
                                          + (float)(v63.m128_f32[0] * *(float *)(v62 + 232))))
                          + *(float *)(v62 + 252);
          v72 = v65;
          v66 = _mm_sub_ps(v73, (__m128)*(unsigned __int64 *)(v61 + 244));
          v64.m128_f32[0] = v65.m128_f32[0] - *(float *)(v61 + 252);
          _mm_storel_ps((double *)&point, v66);
          LODWORD(point.b1) = v64.m128_i32[0];
          v64.m128_f32[0] = G3D::Vector3::unitize((G3D::Vector3 *)&point, v66.m128_f32[0]);
          v67 = this->collisionConnector;
          _mm_storel_ps((double *)&v67->contactPoint.x, v73);
          LODWORD(v67->contactPoint.z) = v72.m128_i32[0];
          v67->normal.z = *(float *)&point.b1;
          *(_QWORD *)&v67->normal.x = point.b0;
          v67->depth = v64.m128_f32[0] - v68;
        }
        return 1;
      }
      if ( !this->collisionConnector )
      {
        v32 = (char *)operator new(0x40u);
        RBX::Collision::Contact::computeCollisionParams(&point, this->prim0, this->prim1);
        v33 = *(_QWORD *)&point.friction;
        *(_OWORD *)v32 = *(_OWORD *)&point.b0;
        *((_QWORD *)v32 + 2) = v33;
        *(_OWORD *)(v32 + 36) = 0;
        *(_OWORD *)(v32 + 24) = 0;
        *((_DWORD *)v32 + 13) = -1;
        v32[56] = 1;
        this->collisionConnector = (RBX::CollisionConnector *)v32;
LABEL_15:
        v8 = v68;
      }
    }
    RBX::Collision::BallPolyContact::updateBallPlaneCollision(
      this,
      v8,
      (const RBX::Vector3 *)(*(_QWORD *)(**(_QWORD **)(v20 + 8)
                                       + 8LL * (*(_QWORD *)(**(_QWORD **)(v20 + 8) + 24LL) != v20)
                                       + 8)
                           + 8LL),
      (const RBX::Vector3 *)(v20 + 32),
      *(_QWORD *)(**(_QWORD **)(v20 + 8) + 24LL) != v20);
    return 1;
  }
  return result;
}


// Address: 0x1dec2a0 | Name: _ZN3RBX9Collision15BallPolyContact29getOrCreateCollisionConnectorEv
RBX::CollisionConnector *__fastcall RBX::Collision::BallPolyContact::getOrCreateCollisionConnector(
        RBX::Collision::BallPolyContact *this)
{
  char *collisionConnector; // rbx
  __int64 v2; // rax
  RBX::CollisionParams v4; // [rsp+0h] [rbp-28h] BYREF

  collisionConnector = (char *)this->collisionConnector;
  if ( !collisionConnector )
  {
    collisionConnector = (char *)operator new(0x40u);
    RBX::Collision::Contact::computeCollisionParams(&v4, this->prim0, this->prim1);
    v2 = *(_QWORD *)&v4.friction;
    *(_OWORD *)collisionConnector = *(_OWORD *)&v4.b0;
    *((_QWORD *)collisionConnector + 2) = v2;
    *(_OWORD *)(collisionConnector + 36) = 0;
    *(_OWORD *)(collisionConnector + 24) = 0;
    *((_DWORD *)collisionConnector + 13) = -1;
    collisionConnector[56] = 1;
    this->collisionConnector = (RBX::CollisionConnector *)collisionConnector;
  }
  return (RBX::CollisionConnector *)collisionConnector;
}


// Address: 0x1dec320 | Name: _ZN3RBX9Collision15BallPolyContact16getNumCollisionsEv
unsigned int __fastcall RBX::Collision::BallPolyContact::getNumCollisions(RBX::Collision::BallPolyContact *this)
{
  return this->collisionConnector != 0;
}


// Address: 0x1dec330 | Name: _ZN3RBX9Collision15BallPolyContact21getCollisionConnectorEj
RBX::CollisionConnector *__fastcall RBX::Collision::BallPolyContact::getCollisionConnector(
        RBX::Collision::BallPolyContact *this,
        unsigned int i)
{
  return this->collisionConnector;
}


// Address: 0x1dec340 | Name: _ZN3RBX9Collision15BallPolyContact18computeIsCollidingEf
char __fastcall RBX::Collision::BallPolyContact::computeIsColliding(
        RBX::Collision::BallPolyContact *this,
        float a2,
        float overlapIgnored)
{
  RBX::Primitive *prim1; // rbx
  const RBX::Extents *FastFuzzyExtents; // r15
  const RBX::Extents *v5; // rax
  RBX::CollisionConnector *collisionConnector; // rcx
  char result; // al

  prim1 = this->prim1;
  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(this->prim0);
  v5 = RBX::Primitive::getFastFuzzyExtents(prim1);
  if ( FastFuzzyExtents->low.x <= v5->high.x
    && FastFuzzyExtents->low.y <= v5->high.y
    && FastFuzzyExtents->low.z <= v5->high.z
    && v5->low.y <= FastFuzzyExtents->high.y
    && v5->low.x <= FastFuzzyExtents->high.x
    && v5->low.z <= FastFuzzyExtents->high.z
    && RBX::Collision::BallPolyContact::findCollidingFeature(this) )
  {
    collisionConnector = this->collisionConnector;
    result = 1;
    if ( collisionConnector->depth < (float)-a2 )
      return result;
    *(_QWORD *)&collisionConnector->normal.x = 0;
    collisionConnector->normal.z = 0.0;
  }
  return 0;
}


// Address: 0x1dec3f0 | Name: _ZN3RBX9Collision15BallPolyContact24deleteCollisionConnectorEj
void __fastcall RBX::Collision::BallPolyContact::deleteCollisionConnector(
        RBX::Collision::BallPolyContact *this,
        unsigned int i)
{
  RBX::CollisionConnector *collisionConnector; // rdi

  collisionConnector = this->collisionConnector;
  if ( collisionConnector )
  {
    operator delete(collisionConnector);
    this->collisionConnector = 0;
  }
}


// Address: 0x1dec410 | Name: _ZN3RBX9Collision15BallPolyContactC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::BallPolyContact::BallPolyContact(
        RBX::Collision::BallPolyContact *this,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  RBX::Collision::Contact::Contact(this, p0, p1);
  this->_vptr$Contact = (int (**)(void))&off_299DC70;
  this->collisionConnector = 0;
}


// Address: 0x1dec430 | Name: _ZN3RBX9Collision15BallPolyContactD2Ev
void __fastcall RBX::Collision::BallPolyContact::~BallPolyContact(RBX::Collision::BallPolyContact *this)
{
  this->_vptr$Contact = (int (**)(void))&off_299DC70;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
}


// Address: 0x1dec450 | Name: _ZN3RBX9Collision15BallPolyContactD0Ev
void __fastcall RBX::Collision::BallPolyContact::~BallPolyContact(RBX::Collision::BallPolyContact *this)
{
  this->_vptr$Contact = (int (**)(void))&off_299DC70;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
  operator delete(this);
}


// Address: 0x1dec480 | Name: _GLOBAL__sub_I_BallPolyContact.cpp
void __cdecl GLOBAL__sub_I_BallPolyContact_cpp()
{
  qword_2AAF528 = (__int64)boost::system::generic_category();
  qword_2AAF530 = (__int64)boost::system::generic_category();
  qword_2AAF538 = (__int64)boost::system::system_category();
}


