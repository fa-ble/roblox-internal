// Address: 0x104c150 | Name: _ZN3RBX8Keyframe8getPosesEv
boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **__fastcall RBX::Keyframe::getPoses(
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type **a1,
        RBX::Keyframe *this)
{
  boost::detail::sp_counted_base *pi; // rax

  if ( stru_2A03600.value )
  {
    RBX::Keyframe::getKeyframeChildrenOfType<RBX::Pose>(this);
  }
  else
  {
    *a1 = this->children.object.px;
    pi = this->children.object.pn.pi_;
    a1[1] = pi;
    if ( pi )
      _InterlockedAdd(&pi->use_count_, 1u);
  }
  return a1;
}


// Address: 0x104c190 | Name: _ZN3RBX8Keyframe7addPoseEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Keyframe::addPose(RBX::Keyframe *this, boost::shared_ptr<RBX::Instance> pose)
{
  if ( pose.px->_vptr$EventSource )
    RBX::Instance::setParentWithScriptSecurityChecks((RBX::Instance *)pose.px->_vptr$EventSource, this);
}


// Address: 0x104c1b0 | Name: _ZN3RBX8Keyframe10removePoseEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Keyframe::removePose(RBX::Keyframe *this, boost::shared_ptr<RBX::Instance> pose)
{
  int (**v3)(void); // rdi

  v3 = pose.px->_vptr$EventSource;
  if ( pose.px->_vptr$EventSource )
  {
    if ( (char *)v3[11] == (char *)this )
      RBX::Instance::setParentWithScriptSecurityChecks((RBX::Instance *)v3, 0);
  }
}


// Address: 0x104c1d0 | Name: _ZN3RBX8Keyframe10getMarkersEv
__int64 __fastcall RBX::Keyframe::getMarkers(__int64 a1, RBX::Keyframe *this)
{
  RBX::Keyframe::getKeyframeChildrenOfType<RBX::KeyframeMarker>(this);
  return a1;
}


// Address: 0x104c1e0 | Name: _ZN3RBX8Keyframe9addMarkerEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Keyframe::addMarker(RBX::Keyframe *this, boost::shared_ptr<RBX::Instance> marker)
{
  int (**v3)(void); // rdi
  volatile signed __int32 *px; // rbx

  v3 = marker.px->_vptr$EventSource;
  px = (volatile signed __int32 *)marker.px->weak_this_.px;
  if ( px )
    _InterlockedAdd(px + 2, 1u);
  if ( v3 )
  {
    marker.px = this;
    RBX::Instance::setParentWithScriptSecurityChecks((RBX::Instance *)v3, this);
  }
  if ( px && !_InterlockedSub(px + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, boost::shared_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *))(*(_QWORD *)px + 16LL))(
      px,
      marker.px,
      marker.pn.pi_);
    if ( !_InterlockedSub(px + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)px + 24LL))(px);
  }
}


// Address: 0x104c280 | Name: _ZN3RBX8Keyframe12removeMarkerEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Keyframe::removeMarker(RBX::Keyframe *this, boost::shared_ptr<RBX::Instance> marker)
{
  int (**v3)(void); // rdi
  volatile signed __int32 *px; // rbx

  v3 = marker.px->_vptr$EventSource;
  px = (volatile signed __int32 *)marker.px->weak_this_.px;
  if ( px )
    _InterlockedAdd(px + 2, 1u);
  if ( v3 && (char *)v3[11] == (char *)this )
  {
    marker.px = 0;
    RBX::Instance::setParentWithScriptSecurityChecks((RBX::Instance *)v3, 0);
  }
  if ( px && !_InterlockedSub(px + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, boost::shared_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *))(*(_QWORD *)px + 16LL))(
      px,
      marker.px,
      marker.pn.pi_);
    if ( !_InterlockedSub(px + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)px + 24LL))(px);
  }
}


// Address: 0x104c320 | Name: _ZN3RBX8Keyframe7setTimeEf
void __fastcall RBX::Keyframe::setTime(RBX::Keyframe *this, float a2, float value)
{
  RBX::KeyframeSequence *parent; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  if ( this->time != a2 )
  {
    this->time = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A031E8);
    parent = (RBX::KeyframeSequence *)this->parent;
    if ( parent )
    {
      descriptor = parent->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
        RBX::KeyframeSequence::invalidateCache(parent);
    }
  }
}


// Address: 0x104c3a0 | Name: _ZN3RBX8KeyframeC2Ev
void __fastcall RBX::Keyframe::Keyframe(RBX::Keyframe *this)
{
  char v1; // [rsp+0h] [rbp-28h] BYREF
  char v2[9]; // [rsp+1h] [rbp-27h] BYREF
  __int16 v3; // [rsp+Ah] [rbp-1Eh]
  int v4; // [rsp+Ch] [rbp-1Ch]
  void *ptr; // [rsp+10h] [rbp-18h]

  RBX::Instance::Instance(this);
  this->_vptr$EventSource = (int (**)(void))&off_288F448;
  this->descriptor = Class_getDescriptorPtr(this);
  this->_vptr$EventSource = (int (**)(void))&off_288F060;
  this->time = 0.0;
  v2[8] = 0;
  v3 = 0;
  v4 = 0;
  ptr = 0;
  v1 = 16;
  strcpy(v2, "Keyfram");
  RBX::Instance::setName(this, (const std::string *)&v1);
  if ( (v1 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x104c450 | Name: _ZN3RBX8Keyframe10invalidateEv
void __fastcall RBX::Keyframe::invalidate(RBX::Keyframe *this)
{
  RBX::KeyframeSequence *parent; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  parent = (RBX::KeyframeSequence *)this->parent;
  if ( parent )
  {
    descriptor = parent->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      RBX::KeyframeSequence::invalidateCache(parent);
  }
}


// Address: 0x104c4a0 | Name: _Z22Class_getDescriptorPtrPN3RBX8KeyframeE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::Keyframe *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A03240;
  if ( !qword_2A03240 )
  {
    if ( !(_BYTE)byte_2A03588 )
    {
      if ( __cxa_guard_acquire(&byte_2A03588) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A03248,
          v2,
          "Keyframe",
          0,
          attributes,
          RBX::Security::Permissions::None,
          &dword_2A04350);
        stru_2A03580._vptr$ICreator = (int (**)(void))&off_288F248;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A03250, &stru_2A03580);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::Keyframe,true>::~ClassRegistrar,
          &unk_2A03248,
          &dso_handle);
        __cxa_guard_release(&byte_2A03588);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A03248;
    qword_2A03240 = (RBX::Reflection::ClassDescriptor *)&unk_2A03248;
  }
  return result;
}


// Address: 0x104c600 | Name: _Z16Class_getNamePtrPN3RBX8KeyframeE
const RBX::Name *__fastcall Class_getNamePtr(RBX::Keyframe *a1)
{
  const RBX::Name *result; // rax

  result = (const RBX::Name *)qword_2A03590;
  if ( !qword_2A03590 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A03590 = (RBX::Keyframe *)result;
  }
  return result;
}


// Address: 0x104d730 | Name: _GLOBAL__sub_I_Keyframe.cpp
void __cdecl GLOBAL__sub_I_Keyframe_cpp()
{
  RBX::Keyframe *v0; // rdi
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor *v3; // r14
  char *v4; // rbx
  const RBX::Reflection::Type *v5; // rax
  RBX::Reflection::PropertyDescriptor::Attributes attributes; // [rsp+0h] [rbp-68h]
  RBX::Reflection::Descriptor::Attributes v7; // [rsp+28h] [rbp-40h] BYREF
  __int64 v8; // [rsp+38h] [rbp-30h]
  RBX::Reflection::Descriptor::Attributes v9; // 0:r8.1,8:r9.8
  RBX::Reflection::Descriptor::Attributes v10; // 0:r8.1,8:r9.8

  qword_2A02EE0 = (__int64)boost::system::generic_category();
  qword_2A02EE8 = (__int64)boost::system::generic_category();
  qword_2A02EF0 = (__int64)boost::system::system_category();
  DescriptorPtr = Class_getDescriptorPtr(v0);
  v9.isDeprecated = 0;
  v9.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A02EF8,
    DescriptorPtr,
    "GetPoses",
    RBX::Security::Permissions::None,
    v9);
  qword_2A02EF8[0] = &off_288F2D8;
  xmmword_2A02F60 = (unsigned __int64)RBX::Keyframe::getPoses;
  qword_2A02F38 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A02EF8, &dso_handle);
  v7.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A02F70,
    RBX::Keyframe::addPose,
    0,
    "AddPose",
    (RBX::Security::Permissions)"pose",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v7.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A02F70,
    &dso_handle);
  v7.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A02FF0,
    RBX::Keyframe::removePose,
    0,
    "RemovePose",
    (RBX::Security::Permissions)"pose",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v7.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A02FF0,
    &dso_handle);
  v2 = Class_getDescriptorPtr((RBX::Keyframe *)RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc);
  v10.isDeprecated = 0;
  v10.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A03070,
    v2,
    "GetMarkers",
    RBX::Security::Permissions::None,
    v10);
  qword_2A03070[0] = &off_288F2D8;
  xmmword_2A030D8 = (unsigned __int64)RBX::Keyframe::getMarkers;
  qword_2A030B0 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A03070, &dso_handle);
  v7.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A030E8,
    RBX::Keyframe::addMarker,
    0,
    "AddMarker",
    (RBX::Security::Permissions)"marker",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v7.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A030E8,
    &dso_handle);
  v7.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A03168,
    RBX::Keyframe::removeMarker,
    0,
    "RemoveMarker",
    (RBX::Security::Permissions)"marker",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v7.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A03168,
    &dso_handle);
  v3 = Class_getDescriptorPtr((RBX::Keyframe *)RBX::Reflection::BoundFuncDesc<RBX::Keyframe,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc);
  v4 = (char *)operator new(0x28u);
  *(_QWORD *)v4 = &off_288F3E8;
  *(_OWORD *)(v4 + 8) = (unsigned __int64)RBX::Keyframe::getTime;
  *(_OWORD *)(v4 + 24) = (unsigned __int64)RBX::Keyframe::setTime;
  v7.isDeprecated = 0;
  v7.preferred = 0;
  LODWORD(v8) = 31;
  v5 = RBX::Reflection::Type::getSingleton<float>();
  *(_QWORD *)&attributes.flags = v8;
  attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v7);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A031E8,
    v3,
    v5,
    "Time",
    &stru_458781.gap0,
    attributes,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A031E8._vptr$Descriptor = (int (**)(void))&off_2882B48;
  qword_2A03238 = (__int64)v4;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4) )
    *((_BYTE *)&stru_2A031E8.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A031E8._vptr$Descriptor + 3))(&stru_2A031E8) )
    *((_BYTE *)&stru_2A031E8.security + 4) &= 0xF3u;
  stru_2A031E8._vptr$Descriptor = (int (**)(void))&off_288F328;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A031E8,
    &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_0);
}


