// Address: 0x1defd40 | Name: _ZNK3RBX9Collision15BuoyancyContact14getContactTypeEv
RBX::Collision::Contact::ContactType __fastcall RBX::Collision::BuoyancyContact::getContactType(
        const RBX::Collision::BuoyancyContact *this)
{
  return RBX::Collision::Contact::ContactType::Contact_Buoyancy;
}


// Address: 0x1defd50 | Name: _ZN3RBX9Collision19BuoyancyBallContactD0Ev
void __fastcall RBX::Collision::BuoyancyBallContact::~BuoyancyBallContact(RBX::Collision::BuoyancyBallContact *this)
{
  size_t num; // rax
  unsigned int v3; // ebp
  size_t i; // rcx
  RBX::BuoyancyAccumulator *v5; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299DD10;
  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v3 = 1;
    for ( i = 0; i < num; i = v3++ )
    {
      v5 = this->buoyancyAccumulators.data.elems[i];
      if ( v5 )
      {
        operator delete(v5);
        num = this->buoyancyAccumulators.num;
      }
    }
  }
  this->buoyancyAccumulators.num = 0;
  RBX::Primitive::onBuoyancyChanged(this->prim1, 0);
  operator delete(this);
}


// Address: 0x1defdd0 | Name: _ZN3RBX9Collision18BuoyancyBoxContactD0Ev
void __fastcall RBX::Collision::BuoyancyBoxContact::~BuoyancyBoxContact(RBX::Collision::BuoyancyBoxContact *this)
{
  size_t num; // rax
  unsigned int v3; // ebp
  size_t i; // rcx
  RBX::BuoyancyAccumulator *v5; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299DD10;
  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v3 = 1;
    for ( i = 0; i < num; i = v3++ )
    {
      v5 = this->buoyancyAccumulators.data.elems[i];
      if ( v5 )
      {
        operator delete(v5);
        num = this->buoyancyAccumulators.num;
      }
    }
  }
  this->buoyancyAccumulators.num = 0;
  RBX::Primitive::onBuoyancyChanged(this->prim1, 0);
  operator delete(this);
}


// Address: 0x1defe50 | Name: _ZN3RBX9Collision23BuoyancyCylinderContactD0Ev
void __fastcall RBX::Collision::BuoyancyCylinderContact::~BuoyancyCylinderContact(
        RBX::Collision::BuoyancyCylinderContact *this)
{
  size_t num; // rax
  unsigned int v3; // ebp
  size_t i; // rcx
  RBX::BuoyancyAccumulator *v5; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299DD10;
  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v3 = 1;
    for ( i = 0; i < num; i = v3++ )
    {
      v5 = this->buoyancyAccumulators.data.elems[i];
      if ( v5 )
      {
        operator delete(v5);
        num = this->buoyancyAccumulators.num;
      }
    }
  }
  this->buoyancyAccumulators.num = 0;
  RBX::Primitive::onBuoyancyChanged(this->prim1, 0);
  operator delete(this);
}


// Address: 0x1defed0 | Name: _ZN3RBX9Collision20BuoyancyWedgeContactD0Ev
void __fastcall RBX::Collision::BuoyancyWedgeContact::~BuoyancyWedgeContact(RBX::Collision::BuoyancyWedgeContact *this)
{
  size_t num; // rax
  unsigned int v3; // ebp
  size_t i; // rcx
  RBX::BuoyancyAccumulator *v5; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299DD10;
  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v3 = 1;
    for ( i = 0; i < num; i = v3++ )
    {
      v5 = this->buoyancyAccumulators.data.elems[i];
      if ( v5 )
      {
        operator delete(v5);
        num = this->buoyancyAccumulators.num;
      }
    }
  }
  this->buoyancyAccumulators.num = 0;
  RBX::Primitive::onBuoyancyChanged(this->prim1, 0);
  operator delete(this);
}


// Address: 0x1deff50 | Name: _ZN3RBX9Collision26BuoyancyCornerWedgeContactD0Ev
void __fastcall RBX::Collision::BuoyancyCornerWedgeContact::~BuoyancyCornerWedgeContact(
        RBX::Collision::BuoyancyCornerWedgeContact *this)
{
  size_t num; // rax
  unsigned int v3; // ebp
  size_t i; // rcx
  RBX::BuoyancyAccumulator *v5; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299DD10;
  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v3 = 1;
    for ( i = 0; i < num; i = v3++ )
    {
      v5 = this->buoyancyAccumulators.data.elems[i];
      if ( v5 )
      {
        operator delete(v5);
        num = this->buoyancyAccumulators.num;
      }
    }
  }
  this->buoyancyAccumulators.num = 0;
  RBX::Primitive::onBuoyancyChanged(this->prim1, 0);
  operator delete(this);
}


