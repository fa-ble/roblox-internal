// Address: 0x10ee270 | Name: _ZN3RBX14StatusInstanceC2Ev
void __fastcall RBX::StatusInstance::StatusInstance(RBX::StatusInstance *this, void **vtt)
{
  _QWORD *v2; // rax
  _QWORD *v3; // rax
  char v4; // [rsp+8h] [rbp-30h] BYREF
  char v5[7]; // [rsp+9h] [rbp-2Fh] BYREF
  void *ptr[2]; // [rsp+10h] [rbp-28h]

  RBX::ModelInstance::ModelInstance(this, vtt + 2);
  v2 = vtt[1];
  *(_QWORD *)this = v2;
  *(_QWORD *)((char *)this + *(v2 - 3)) = vtt[11];
  *((_QWORD *)this + 16) = &off_2896F50;
  *((_QWORD *)this + 21) = vtt[12];
  *((_QWORD *)this + 3) = Class_getDescriptorPtr(this);
  v3 = *vtt;
  *(_QWORD *)this = *vtt;
  *(_QWORD *)((char *)this + *(v3 - 3)) = vtt[13];
  *((_QWORD *)this + 16) = &off_2896438;
  *((_QWORD *)this + 21) = vtt[14];
  *(_OWORD *)ptr = 0;
  v4 = 12;
  strcpy(v5, "Status");
  (*(void (__fastcall **)(RBX::StatusInstance *, char *))(*(_QWORD *)this + 112LL))(this, &v4);
  if ( (v4 & 1) != 0 )
    operator delete(ptr[1]);
  *((_BYTE *)this + 304) = 1;
}


// Address: 0x10ee370 | Name: _ZN3RBX14StatusInstanceC1Ev
void __fastcall RBX::StatusInstance::StatusInstance(RBX::StatusInstance *this)
{
  char v1; // [rsp+0h] [rbp-28h] BYREF
  char v2[7]; // [rsp+1h] [rbp-27h] BYREF
  void *ptr[2]; // [rsp+8h] [rbp-20h]

  *((_QWORD *)this + 21) = &off_2893238;
  RBX::ModelInstance::ModelInstance(this, &off_2896500);
  *(_QWORD *)this = &off_2896588;
  *((_QWORD *)this + 16) = &off_2896F50;
  *((_QWORD *)this + 21) = &off_2896730;
  *((_QWORD *)this + 3) = Class_getDescriptorPtr(this);
  *(_QWORD *)this = off_28962A8;
  *((_QWORD *)this + 16) = &off_2896438;
  *((_QWORD *)this + 21) = &off_28964A0;
  *(_OWORD *)ptr = 0;
  v1 = 12;
  strcpy(v2, "Status");
  RBX::ModelInstance::setName(this, (const std::string *)&v1);
  if ( (v1 & 1) != 0 )
    operator delete(ptr[1]);
  *((_BYTE *)this + 304) = 1;
}


// Address: 0x10ee470 | Name: _ZNK3RBX14StatusInstance12askSetParentEPKNS_8InstanceE
bool __fastcall RBX::StatusInstance::askSetParent(const RBX::StatusInstance *this, const RBX::Instance *instance)
{
  return 0;
}


// Address: 0x10ee480 | Name: _Z22Class_getDescriptorPtrPN3RBX14StatusInstanceE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::StatusInstance *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A09038;
  if ( !qword_2A09038 )
  {
    if ( !(_BYTE)byte_2A09380 )
    {
      if ( __cxa_guard_acquire(&byte_2A09380) )
      {
        DescriptorPtr = Class_getDescriptorPtr(0);
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 3;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A09040,
          DescriptorPtr,
          "Status",
          0,
          attributes,
          RBX::Security::Permissions::None,
          0);
        stru_2A09378._vptr$ICreator = (int (**)(void))&off_2896D88;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A09048, &stru_2A09378);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::StatusInstance,true>::~ClassRegistrar,
          &unk_2A09040,
          &dso_handle);
        __cxa_guard_release(&byte_2A09380);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A09040;
    qword_2A09038 = (RBX::Reflection::ClassDescriptor *)&unk_2A09040;
  }
  return result;
}


// Address: 0x10ee5e0 | Name: _Z16Class_getNamePtrPN3RBX14StatusInstanceE
const RBX::Name *__fastcall Class_getNamePtr(RBX::StatusInstance *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A09388;
  if ( !qword_2A09388 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A09388 = result;
  }
  return result;
}


// Address: 0x10ee880 | Name: _GLOBAL__sub_I_StatusInstance.cpp
void __cdecl GLOBAL__sub_I_StatusInstance_cpp()
{
  qword_2A09020 = (__int64)boost::system::generic_category();
  qword_2A09028 = (__int64)boost::system::generic_category();
  qword_2A09030 = (__int64)boost::system::system_category();
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_0);
}


