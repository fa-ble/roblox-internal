// Address: 0x106aa60 | Name: _ZNK3RBX4Pose18getCoordinateFrameEv
const RBX::CoordinateFrame *__fastcall RBX::Pose::getCoordinateFrame(const RBX::Pose *this)
{
  return &this->coordinateFrame;
}


// Address: 0x106aaa0 | Name: _ZNK3RBX4Pose9getWeightEv
float __fastcall RBX::Pose::getWeight(const RBX::Pose *this)
{
  return this->weight;
}


// Address: 0x106ac00 | Name: _ZNK3RBX4Pose14getEasingStyleEv
RBX::Pose::PoseEasingStyle __fastcall RBX::Pose::getEasingStyle(const RBX::Pose *this)
{
  return this->easingStyle;
}


// Address: 0x106ad70 | Name: _ZNK3RBX4Pose18getEasingDirectionEv
RBX::Pose::PoseEasingDirection __fastcall RBX::Pose::getEasingDirection(const RBX::Pose *this)
{
  return this->easingDirection;
}


// Address: 0x106b400 | Name: _ZN3RBX4PoseD0Ev
void __fastcall RBX::Pose::~Pose(RBX::Pose *this)
{
  RBX::Instance::~Instance(this);
  operator delete(this);
}


// Address: 0x106b450 | Name: _ZNK3RBX4Pose11askAddChildEPKNS_8InstanceE
bool __fastcall RBX::Pose::askAddChild(const RBX::Pose *this, const RBX::Instance *instance)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  if ( !instance )
    return 0;
  descriptor = instance->descriptor;
  DescriptorPtr = Class_getDescriptorPtr((RBX::Pose *)this);
  return *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364);
}


// Address: 0x106b490 | Name: _ZN3RBX4Pose12onChildAddedEPNS_8InstanceE
void __fastcall RBX::Pose::onChildAdded(RBX::Pose *this, RBX::Instance *child)
{
  RBX::Keyframe *parent; // r14
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v6; // r14
  RBX::Reflection::ClassDescriptor *v7; // rax

  while ( 1 )
  {
    parent = (RBX::Keyframe *)this->parent;
    if ( !parent )
      break;
    descriptor = parent->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      RBX::Keyframe::invalidate(parent);
      return;
    }
    this = (RBX::Pose *)this->parent;
    if ( this )
    {
      v6 = this->descriptor;
      v7 = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)v6 + 363) - (unsigned int)*((unsigned __int16 *)v7 + 363) <= *((unsigned __int16 *)v7
                                                                                              + 364) )
        continue;
    }
    return;
  }
}


// Address: 0x106b520 | Name: _ZN3RBX4Pose14onChildRemovedEPNS_8InstanceE
void __fastcall RBX::Pose::onChildRemoved(RBX::Pose *this, RBX::Instance *child)
{
  RBX::Keyframe *parent; // r14
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v6; // r14
  RBX::Reflection::ClassDescriptor *v7; // rax

  while ( 1 )
  {
    parent = (RBX::Keyframe *)this->parent;
    if ( !parent )
      break;
    descriptor = parent->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      RBX::Keyframe::invalidate(parent);
      return;
    }
    this = (RBX::Pose *)this->parent;
    if ( this )
    {
      v6 = this->descriptor;
      v7 = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)v6 + 363) - (unsigned int)*((unsigned __int16 *)v7 + 363) <= *((unsigned __int16 *)v7
                                                                                              + 364) )
        continue;
    }
    return;
  }
}


