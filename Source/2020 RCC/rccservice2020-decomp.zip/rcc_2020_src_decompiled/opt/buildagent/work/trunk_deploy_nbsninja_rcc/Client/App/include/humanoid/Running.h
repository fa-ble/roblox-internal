// Address: 0x10e9850 | Name: _ZN3RBX5HUMAN8ClimbingD0Ev
void __fastcall RBX::HUMAN::Climbing::~Climbing(RBX::HUMAN::Climbing *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // rdi
  void *v5; // rdi

  *(_QWORD *)this = &off_2895850;
  v2 = *((_QWORD *)this + 44);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 45);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 44);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 && !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)this + 44);
    }
    *((_QWORD *)this + 45) = v2;
    operator delete(v5);
  }
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e98e0 | Name: _ZN3RBX5HUMAN8Climbing15ladderCheckRateEv
int __fastcall RBX::HUMAN::Climbing::ladderCheckRate(RBX::HUMAN::Climbing *this)
{
  return 0;
}


// Address: 0x10e9910 | Name: _ZNK3RBX5HUMAN8Climbing14enableAutoJumpEv
bool __fastcall RBX::HUMAN::Climbing::enableAutoJump(const RBX::HUMAN::Climbing *this)
{
  return 0;
}


// Address: 0x10e9930 | Name: _ZNK3RBX5HUMAN8Climbing12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::Climbing::getStateType(const RBX::HUMAN::Climbing *this)
{
  return RBX::HUMAN::StateType::CLIMBING;
}


// Address: 0x10e9940 | Name: _ZN3RBX5HUMAN12RunningSlaveD0Ev
void __fastcall RBX::HUMAN::RunningSlave::~RunningSlave(RBX::HUMAN::RunningSlave *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // rdi
  void *v5; // rdi

  *(_QWORD *)this = &off_2895850;
  v2 = *((_QWORD *)this + 44);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 45);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 44);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 && !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)this + 44);
    }
    *((_QWORD *)this + 45) = v2;
    operator delete(v5);
  }
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e99d0 | Name: _ZNK3RBX5HUMAN7Running12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::Running::getStateType(const RBX::HUMAN::Running *this)
{
  return RBX::HUMAN::StateType::RUNNING;
}


// Address: 0x10e99e0 | Name: _ZN3RBX5HUMAN7RunningD0Ev
void __fastcall RBX::HUMAN::Running::~Running(RBX::HUMAN::Running *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // rdi
  void *v5; // rdi

  *(_QWORD *)this = &off_2895850;
  v2 = *((_QWORD *)this + 44);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 45);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 44);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 && !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)this + 44);
    }
    *((_QWORD *)this + 45) = v2;
    operator delete(v5);
  }
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e9a70 | Name: _ZN3RBX5HUMAN6LandedD0Ev
void __fastcall RBX::HUMAN::Landed::~Landed(RBX::HUMAN::Landed *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // rdi
  void *v5; // rdi

  *(_QWORD *)this = &off_2895850;
  v2 = *((_QWORD *)this + 44);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 45);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 44);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 && !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)this + 44);
    }
    *((_QWORD *)this + 45) = v2;
    operator delete(v5);
  }
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e9b00 | Name: _ZNK3RBX5HUMAN6Landed12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::Landed::getStateType(const RBX::HUMAN::Landed *this)
{
  return RBX::HUMAN::StateType::LANDED;
}


