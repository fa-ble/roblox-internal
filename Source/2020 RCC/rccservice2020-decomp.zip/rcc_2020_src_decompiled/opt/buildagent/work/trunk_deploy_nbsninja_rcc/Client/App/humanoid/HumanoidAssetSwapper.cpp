// Address: 0x10d2690 | Name: _ZN3RBX20HumanoidAssetSwapper12AssetTracker6filterERKN5boost9unordered13unordered_setIlNS2_4hashIlEENSt3__18equal_toIlEENS7_9allocatorIlEEEE
void __fastcall RBX::HumanoidAssetSwapper::AssetTracker::filter(
        RBX::HumanoidAssetSwapper::AssetTracker *this,
        const boost::unordered::unordered_set<long,boost::hash<long>,std::equal_to<long>,std::allocator<long> > *assetsToKeep)
{
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v5; // rcx
  size_t bucket_count; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rax
  _QWORD *p_next; // rsi
  char *v9; // rax
  int64_t *v10; // rbx
  int64_t *v11; // r15
  void *ptr[2]; // [rsp+0h] [rbp-38h] BYREF
  void *v13; // [rsp+10h] [rbp-28h]

  *(_OWORD *)ptr = 0;
  v13 = 0;
  if ( this->assetToInstances.table_.size_ )
  {
    next = this->assetToInstances.table_.buckets_[this->assetToInstances.table_.bucket_count_].next_;
    if ( next )
    {
      do
      {
        v5 = next[2].next_;
        bucket_count = assetsToKeep->table_.bucket_count_;
        if ( assetsToKeep->table_.size_ )
        {
          v7 = assetsToKeep->table_.buckets_[(size_t)next[2].next_ % bucket_count].next_;
          if ( v7 )
          {
            p_next = &v7->next_->next_;
            if ( v7->next_ )
            {
              do
              {
                if ( (boost::unordered::detail::ptr_bucket::link_pointer)p_next[1] == v5 )
                {
                  if ( v5 == (boost::unordered::detail::ptr_bucket::link_pointer)p_next[2] )
                    goto LABEL_15;
                }
                else if ( p_next[1] % bucket_count != (size_t)next[2].next_ % bucket_count )
                {
                  break;
                }
                p_next = (_QWORD *)*p_next;
              }
              while ( p_next );
            }
          }
        }
        v9 = (char *)ptr[1];
        if ( ptr[1] == v13 )
        {
          std::vector<long>::__push_back_slow_path<long const&>((std::vector<long> *)ptr, (const __int64 *)&next[2]);
        }
        else
        {
          *(_QWORD *)ptr[1] = v5;
          ptr[1] = v9 + 8;
        }
LABEL_15:
        next = next->next_;
      }
      while ( next );
      v10 = (int64_t *)ptr[0];
      v11 = (int64_t *)ptr[1];
      if ( ptr[0] != ptr[1] )
      {
        do
          RBX::HumanoidAssetSwapper::AssetTracker::removeAsset(this, *v10++);
        while ( v11 != v10 );
        v11 = (int64_t *)ptr[0];
      }
      if ( v11 )
      {
        ptr[1] = v11;
        operator delete(v11);
      }
    }
  }
}


// Address: 0x10d2800 | Name: _ZN3RBX20HumanoidAssetSwapper12AssetTracker11removeAssetEl
void __fastcall RBX::HumanoidAssetSwapper::AssetTracker::removeAsset(
        RBX::HumanoidAssetSwapper::AssetTracker *this,
        int64_t assetId)
{
  size_t bucket_count; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  _QWORD *p_next; // rbx
  _QWORD *i; // r15
  RBX::Instance *v7; // rax
  unsigned __int64 v8; // rdx
  __int64 v9; // rcx
  size_t v10; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer v11; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer j; // r13
  boost::unordered::detail::ptr_bucket::link_pointer v13; // rdi
  volatile signed __int32 *v14; // rbp
  signed __int32 v15; // eax
  signed __int32 v16; // ett
  RBX::Instance *v17; // rdi
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,long> >,RBX::Instance *,long,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::key_type k; // [rsp+10h] [rbp-38h] BYREF

  bucket_count = this->assetToInstances.table_.bucket_count_;
  if ( !this->assetToInstances.table_.size_ )
    return;
  next = this->assetToInstances.table_.buckets_[assetId % bucket_count].next_;
  if ( !next )
    return;
  p_next = &next->next_->next_;
  if ( !next->next_ )
    return;
  while ( 1 )
  {
    if ( p_next[1] != assetId )
    {
      if ( p_next[1] % bucket_count != assetId % bucket_count )
        return;
      goto LABEL_8;
    }
    if ( p_next[2] == assetId )
      break;
LABEL_8:
    p_next = (_QWORD *)*p_next;
    if ( !p_next )
      return;
  }
  if ( p_next[5] )
  {
    for ( i = *(_QWORD **)(p_next[8] + 8LL * p_next[4]); i; i = (_QWORD *)*i )
    {
      v7 = (RBX::Instance *)i[2];
      k = v7;
      if ( this->instanceToWeakPointer.table_.size_ )
      {
        v8 = (21
            * ((265
              * ((~((unsigned __int64)v7 + ((unsigned __int64)v7 >> 3))
                + (((_QWORD)v7 + ((unsigned __int64)v7 >> 3)) << 21))
               ^ ((~((unsigned __int64)v7 + ((unsigned __int64)v7 >> 3))
                 + (((_QWORD)v7 + ((unsigned __int64)v7 >> 3)) << 21)) >> 24)))
             ^ ((265
               * ((~((unsigned __int64)v7 + ((unsigned __int64)v7 >> 3))
                 + (((_QWORD)v7 + ((unsigned __int64)v7 >> 3)) << 21))
                ^ ((~((unsigned __int64)v7 + ((unsigned __int64)v7 >> 3))
                  + (((_QWORD)v7 + ((unsigned __int64)v7 >> 3)) << 21)) >> 24))) >> 14)))
           ^ ((21
             * ((265
               * ((~((unsigned __int64)v7 + ((unsigned __int64)v7 >> 3))
                 + (((_QWORD)v7 + ((unsigned __int64)v7 >> 3)) << 21))
                ^ ((~((unsigned __int64)v7 + ((unsigned __int64)v7 >> 3))
                  + (((_QWORD)v7 + ((unsigned __int64)v7 >> 3)) << 21)) >> 24)))
              ^ ((265
                * ((~((unsigned __int64)v7 + ((unsigned __int64)v7 >> 3))
                  + (((_QWORD)v7 + ((unsigned __int64)v7 >> 3)) << 21))
                 ^ ((~((unsigned __int64)v7 + ((unsigned __int64)v7 >> 3))
                   + (((_QWORD)v7 + ((unsigned __int64)v7 >> 3)) << 21)) >> 24))) >> 14))) >> 28);
        v9 = 2147483649u * v8;
        v10 = this->instanceToWeakPointer.table_.bucket_count_ - 1;
        v11 = this->instanceToWeakPointer.table_.buckets_[v10 & v9].next_;
        if ( v11 )
        {
          for ( j = v11->next_; j; j = j->next_ )
          {
            v13 = j[1].next_;
            if ( v13 == (boost::unordered::detail::ptr_bucket::link_pointer)v9 )
            {
              if ( (RBX::Instance *)j[2].next_ == v7 )
                goto LABEL_21;
            }
            else if ( (v10 & (unsigned __int64)v13) != (v10 & v9) )
            {
              break;
            }
          }
        }
      }
      j = 0;
LABEL_21:
      v14 = (volatile signed __int32 *)j[4].next_;
      if ( v14 )
      {
        v15 = *((_DWORD *)v14 + 2);
        while ( v15 )
        {
          v16 = v15;
          v15 = _InterlockedCompareExchange(v14 + 2, v15 + 1, v15);
          if ( v16 == v15 )
          {
            v17 = (RBX::Instance *)j[3].next_;
            if ( v17 )
              RBX::Instance::setParentInternal(v17, 0, 0);
            goto LABEL_28;
          }
        }
      }
      v14 = 0;
LABEL_28:
      boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance * const,boost::weak_ptr<RBX::Instance>>>,RBX::Instance *,boost::weak_ptr<RBX::Instance>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>>>::erase_nodes(
        &this->instanceToWeakPointer.table_,
        (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,boost::weak_ptr<RBX::Instance> > >,RBX::Instance *,boost::weak_ptr<RBX::Instance>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::node_pointer)j,
        (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,boost::weak_ptr<RBX::Instance> > >,RBX::Instance *,boost::weak_ptr<RBX::Instance>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::node_pointer)j->next_);
      boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance * const,long>>,RBX::Instance *,long,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>>>::erase_key(
        &this->instanceToAsset.table_,
        &k);
      if ( v14 && !_InterlockedSub(v14 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
        if ( !_InterlockedSub(v14 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
      }
    }
  }
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long const,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *>>>>,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *>>,boost::hash<long>,std::equal_to<long>>>::erase(
    &this->assetToInstances.table_,
    (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> > > >,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> >,boost::hash<long>,std::equal_to<long> > >::c_iterator)p_next);
}


// Address: 0x10d2a80 | Name: _ZN3RBX20HumanoidAssetSwapper12AssetTracker9removeAllEv
void __fastcall RBX::HumanoidAssetSwapper::AssetTracker::removeAll(RBX::HumanoidAssetSwapper::AssetTracker *this)
{
  size_t bucket_count; // r12
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> > > >,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> >,boost::hash<long>,std::equal_to<long> > >::bucket_pointer buckets; // r13
  boost::unordered::detail::ptr_bucket *next; // r15
  _QWORD *p_next; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v6; // rbp
  _QWORD *v7; // rdi
  size_t v8; // rdx
  size_t v9; // r15
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,boost::weak_ptr<RBX::Instance> > >,RBX::Instance *,boost::weak_ptr<RBX::Instance>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::bucket_pointer v10; // r12
  boost::unordered::detail::ptr_bucket *v11; // rbx
  volatile signed __int32 *v12; // rdi
  size_t v13; // rdx
  size_t v14; // rbx
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,long> >,RBX::Instance *,long,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::bucket_pointer v15; // rbp
  boost::unordered::detail::ptr_bucket *v16; // rdi
  size_t v17; // rdx

  if ( this->assetToInstances.table_.size_ )
  {
    bucket_count = this->assetToInstances.table_.bucket_count_;
    buckets = this->assetToInstances.table_.buckets_;
    next = buckets[bucket_count].next_;
    do
    {
      buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
      p_next = &next[8].next_->next_;
      if ( p_next )
      {
        if ( next[5].next_ )
        {
          v6 = next[4].next_;
          v7 = (_QWORD *)p_next[(_QWORD)v6];
          do
          {
            p_next[(_QWORD)v6] = *v7;
            operator delete(v7);
            --next[5].next_;
            v7 = (_QWORD *)p_next[(_QWORD)v6];
          }
          while ( v7 );
          p_next = &next[8].next_->next_;
        }
        operator delete(p_next);
      }
      operator delete(next);
      --this->assetToInstances.table_.size_;
      next = buckets[bucket_count].next_;
    }
    while ( next );
    v8 = this->assetToInstances.table_.bucket_count_;
    if ( v8 )
      memset(this->assetToInstances.table_.buckets_, 0, 8 * v8);
  }
  if ( this->instanceToWeakPointer.table_.size_ )
  {
    v9 = this->instanceToWeakPointer.table_.bucket_count_;
    v10 = this->instanceToWeakPointer.table_.buckets_;
    v11 = v10[v9].next_;
    do
    {
      v10[v9] = (boost::unordered::detail::ptr_bucket)v11->next_;
      v12 = (volatile signed __int32 *)v11[4].next_;
      if ( v12 && !_InterlockedSub(v12 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
      operator delete(v11);
      --this->instanceToWeakPointer.table_.size_;
      v11 = v10[v9].next_;
    }
    while ( v11 );
    v13 = this->instanceToWeakPointer.table_.bucket_count_;
    if ( v13 )
      memset(this->instanceToWeakPointer.table_.buckets_, 0, 8 * v13);
  }
  if ( this->instanceToAsset.table_.size_ )
  {
    v14 = this->instanceToAsset.table_.bucket_count_;
    v15 = this->instanceToAsset.table_.buckets_;
    v16 = v15[v14].next_;
    do
    {
      v15[v14] = (boost::unordered::detail::ptr_bucket)v16->next_;
      operator delete(v16);
      --this->instanceToAsset.table_.size_;
      v16 = v15[v14].next_;
    }
    while ( v16 );
    v17 = this->instanceToAsset.table_.bucket_count_;
    if ( v17 )
      memset(this->instanceToAsset.table_.buckets_, 0, 8 * v17);
  }
}


// Address: 0x10d2c10 | Name: _ZN3RBX20HumanoidAssetSwapper12AssetTracker11addInstanceElN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidAssetSwapper::AssetTracker::addInstance(
        RBX::HumanoidAssetSwapper::AssetTracker *this,
        int64_t assetId,
        boost::shared_ptr<RBX::Instance> inst)
{
  const boost::shared_ptr<RBX::Instance> *px; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> > > >,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> >,boost::hash<long>,std::equal_to<long> > >::value_type *v5; // rax
  boost::shared_ptr<RBX::Instance>::element_type *v6; // r12
  boost::detail::sp_counted_base *pi; // r15
  RBX::Instance *v8; // rax
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance *const,boost::weak_ptr<RBX::Instance> > >,RBX::Instance *,boost::weak_ptr<RBX::Instance>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::value_type *v9; // rax
  volatile signed __int32 *v10; // rdi
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> > > >,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> >,boost::hash<long>,std::equal_to<long> > >::key_type v11; // r15
  RBX::Instance *args; // [rsp+8h] [rbp-30h] BYREF
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> > > >,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> >,boost::hash<long>,std::equal_to<long> > >::key_type k[5]; // [rsp+10h] [rbp-28h] BYREF

  px = (const boost::shared_ptr<RBX::Instance> *)inst.px;
  k[0] = assetId;
  if ( RBX::HumanoidDescription::isAssetSet(assetId) && px->px )
  {
    RBX::HumanoidAssetSwapper::AssetTracker::removeInstance(this, px);
    v5 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long const,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *>>>>,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *>>,boost::hash<long>,std::equal_to<long>>>::operator[](
           &this->assetToInstances.table_,
           k);
    args = px->px;
    boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Instance *>,RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>>>::emplace_impl<RBX::Instance *>(
      &v5->second.table_,
      &args,
      &args);
    v6 = px->px;
    pi = px->pn.pi_;
    v8 = px->px;
    if ( pi )
    {
      _InterlockedAdd(&pi->weak_count_, 1u);
      v8 = px->px;
    }
    args = v8;
    v9 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance * const,boost::weak_ptr<RBX::Instance>>>,RBX::Instance *,boost::weak_ptr<RBX::Instance>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>>>::operator[](
           &this->instanceToWeakPointer.table_,
           &args);
    v9->second.px = v6;
    v10 = (volatile signed __int32 *)v9->second.pn.pi_;
    v9->second.pn.pi_ = pi;
    if ( v10 )
    {
      if ( !_InterlockedSub(v10 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
    }
    v11 = k[0];
    args = px->px;
    boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance * const,long>>,RBX::Instance *,long,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>>>::operator[](
      &this->instanceToAsset.table_,
      &args)->second = v11;
  }
}


// Address: 0x10d2d20 | Name: _ZN3RBX20HumanoidAssetSwapper12AssetTracker14removeInstanceERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidAssetSwapper::AssetTracker::removeInstance(
        RBX::HumanoidAssetSwapper::AssetTracker *this,
        const boost::shared_ptr<RBX::Instance> *inst)
{
  RBX::Instance *px; // rsi
  unsigned __int64 v5; // rcx
  size_t v6; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer v8; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer v9; // rcx
  size_t bucket_count; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer v11; // rax
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> > > >,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> >,boost::hash<long>,std::equal_to<long> > >::c_iterator v12; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Instance *>,RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > >::key_type k[4]; // [rsp+8h] [rbp-20h] BYREF

  px = inst->px;
  if ( px )
  {
    if ( this->instanceToAsset.table_.size_ )
    {
      v5 = (21
          * ((265
            * ((~((unsigned __int64)px + ((unsigned __int64)px >> 3))
              + (((_QWORD)px + ((unsigned __int64)px >> 3)) << 21))
             ^ ((~((unsigned __int64)px + ((unsigned __int64)px >> 3))
               + (((_QWORD)px + ((unsigned __int64)px >> 3)) << 21)) >> 24)))
           ^ ((265
             * ((~((unsigned __int64)px + ((unsigned __int64)px >> 3))
               + (((_QWORD)px + ((unsigned __int64)px >> 3)) << 21))
              ^ ((~((unsigned __int64)px + ((unsigned __int64)px >> 3))
                + (((_QWORD)px + ((unsigned __int64)px >> 3)) << 21)) >> 24))) >> 14)))
         ^ ((21
           * ((265
             * ((~((unsigned __int64)px + ((unsigned __int64)px >> 3))
               + (((_QWORD)px + ((unsigned __int64)px >> 3)) << 21))
              ^ ((~((unsigned __int64)px + ((unsigned __int64)px >> 3))
                + (((_QWORD)px + ((unsigned __int64)px >> 3)) << 21)) >> 24)))
            ^ ((265
              * ((~((unsigned __int64)px + ((unsigned __int64)px >> 3))
                + (((_QWORD)px + ((unsigned __int64)px >> 3)) << 21))
               ^ ((~((unsigned __int64)px + ((unsigned __int64)px >> 3))
                 + (((_QWORD)px + ((unsigned __int64)px >> 3)) << 21)) >> 24))) >> 14))) >> 28);
      v6 = (2147483649u * v5) & (this->instanceToAsset.table_.bucket_count_ - 1);
      next = this->instanceToAsset.table_.buckets_[v6].next_;
      if ( next )
      {
        while ( 1 )
        {
          next = next->next_;
          if ( !next )
            break;
          v8 = next[1].next_;
          if ( v8 == (boost::unordered::detail::ptr_bucket::link_pointer)(2147483649u * v5) )
          {
            if ( (RBX::Instance *)next[2].next_ == px )
            {
              v9 = next[3].next_;
              bucket_count = this->assetToInstances.table_.bucket_count_;
              if ( this->assetToInstances.table_.size_ )
              {
                v11 = this->assetToInstances.table_.buckets_[(unsigned __int64)v9 % bucket_count].next_;
                if ( v11 )
                {
                  v12.node_ = (boost::unordered::iterator_detail::c_iterator<boost::unordered::detail::ptr_node<std::pair<const long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> > > > >::node_pointer)v11->next_;
                  if ( v11->next_ )
                  {
                    do
                    {
                      if ( (boost::unordered::detail::ptr_bucket::link_pointer)v12.node_->hash_ == v9 )
                      {
                        if ( v9 == *(boost::unordered::detail::ptr_bucket::link_pointer *)v12.node_->value_base_.data_.data_.buf )
                        {
                          k[0] = px;
                          boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Instance *>,RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>>>::erase_key(
                            (boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Instance *>,RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *> > > *)(&v12.node_->value_base_.data_.data_.align_ + 1),
                            k);
                          if ( !*((_QWORD *)&v12.node_->value_base_.data_.data_.align_ + 3) )
                            boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<long const,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *>>>>,long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *>>,boost::hash<long>,std::equal_to<long>>>::erase(
                              &this->assetToInstances.table_,
                              v12);
                          break;
                        }
                      }
                      else if ( v12.node_->hash_ % bucket_count != (unsigned __int64)v9 % bucket_count )
                      {
                        break;
                      }
                      v12.node_ = (boost::unordered::iterator_detail::c_iterator<boost::unordered::detail::ptr_node<std::pair<const long,boost::unordered::unordered_set<RBX::Instance *,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>,std::allocator<RBX::Instance *> > > > >::node_pointer)v12.node_->next_;
                    }
                    while ( v12.node_ );
                  }
                }
              }
              k[0] = inst->px;
              boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance * const,long>>,RBX::Instance *,long,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>>>::erase_key(
                &this->instanceToAsset.table_,
                k);
              k[0] = inst->px;
              boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<RBX::Instance * const,boost::weak_ptr<RBX::Instance>>>,RBX::Instance *,boost::weak_ptr<RBX::Instance>,boost::hash<RBX::Instance *>,std::equal_to<RBX::Instance *>>>::erase_key(
                &this->instanceToWeakPointer.table_,
                k);
              return;
            }
          }
          else if ( ((this->instanceToAsset.table_.bucket_count_ - 1) & (unsigned __int64)v8) != v6 )
          {
            return;
          }
        }
      }
    }
  }
}


// Address: 0x10d2eb0 | Name: _ZN3RBX20HumanoidAssetSwapper18setAnimationParentERKN5boost8weak_ptrINS_13ModelInstanceEEENS1_10shared_ptrINS_8InstanceEEEl
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::HumanoidAssetSwapper::setAnimationParent(
        const boost::weak_ptr<RBX::ModelInstance> *weakCharacter,
        boost::shared_ptr<RBX::Instance> i,
        int64_t assetId)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::detail::sp_counted_base *v4; // rbp
  signed __int32 use_count; // eax
  signed __int32 v6; // ett
  const RBX::Instance *px; // r14
  RBX::Instance *ConstFirstChildByName; // r13
  const RBX::Reflection::ClassDescriptor *descriptor; // r12
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  unsigned int v11; // ecx
  unsigned int v12; // edx
  RBX::Instance *v13; // rax
  RBX::Reflection::ClassDescriptor *v14; // rax
  bool v15; // cc
  __int64 **v16; // rax
  __int64 *v17; // rbp
  __int64 *v18; // r12
  __int64 v19; // r13
  __int64 v20; // r14
  RBX::Reflection::ClassDescriptor *v21; // rax
  const RBX::Instance *v22; // rax
  RBX::Instance *v23; // r12
  const RBX::Reflection::ClassDescriptor *v24; // rbp
  RBX::Reflection::ClassDescriptor *v25; // rax
  __int64 v26; // rbp
  RBX::Reflection::ClassDescriptor *v27; // rax
  boost::detail::sp_counted_base *v28; // rbp
  __int64 v29; // rcx OVERLAPPED
  int (**v30)(void); // rax
  boost::detail::sp_counted_base *v31; // r15
  RBX::HumanoidAssetSwapper::AssetTracker *v32; // r13
  boost::shared_ptr<RBX::Instance> *v33; // rdx
  boost::shared_ptr<RBX::Instance> v34; // [rsp+0h] [rbp-58h] BYREF
  void *ptr; // [rsp+10h] [rbp-48h]
  RBX::Instance *newParent; // [rsp+18h] [rbp-40h]
  int64_t v37; // [rsp+20h] [rbp-38h]

  pi = weakCharacter->pn.pi_;
  if ( pi )
  {
    v4 = i.pn.pi_;
    use_count = pi->use_count_;
    do
    {
      if ( !use_count )
        return;
      v6 = use_count;
      use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
    }
    while ( v6 != use_count );
    px = (const RBX::Instance *)weakCharacter->px;
    if ( weakCharacter->px && i.px->_vptr$EventSource )
    {
      v34.pn.pi_ = 0;
      ptr = 0;
      LOBYTE(v34.px) = 14;
      *(boost::shared_ptr<RBX::Instance>::element_type **)((char *)&v34.px + 1) = (boost::shared_ptr<RBX::Instance>::element_type *)0x6574616D696E41LL;
      ConstFirstChildByName = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(px, (const std::string *)&v34);
      if ( ((__int64)v34.px & 1) != 0 )
        operator delete(ptr);
      if ( ConstFirstChildByName )
      {
        descriptor = ConstFirstChildByName->descriptor;
        if ( stru_2A08BD0.value )
        {
          DescriptorPtr = Class_getDescriptorPtr(0);
          v11 = *((unsigned __int16 *)descriptor + 363) - *((unsigned __int16 *)DescriptorPtr + 363);
          v12 = *((unsigned __int16 *)DescriptorPtr + 364);
          v13 = ConstFirstChildByName;
          if ( v11 > v12 )
            goto LABEL_45;
        }
        else
        {
          v14 = Class_getDescriptorPtr(0);
          v15 = *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)v14 + 363) <= *((unsigned __int16 *)v14 + 364);
          v13 = ConstFirstChildByName;
          if ( !v15 )
            v13 = 0;
        }
        if ( !v13 )
          goto LABEL_45;
        v16 = (__int64 **)px->children.object.px;
        v37 = (int64_t)v4;
        newParent = ConstFirstChildByName;
        if ( !v16 || (v17 = *v16, v18 = v16[1], *v16 == v18) )
        {
LABEL_21:
          v19 = 0;
        }
        else
        {
          while ( 1 )
          {
            v19 = *v17;
            if ( *v17 )
            {
              v20 = *(_QWORD *)(v19 + 24);
              v21 = Class_getDescriptorPtr(0);
              if ( *(unsigned __int16 *)(v20 + 726) - (unsigned int)*((unsigned __int16 *)v21 + 363) <= *((unsigned __int16 *)v21 + 364) )
                break;
            }
            v17 += 2;
            if ( v18 == v17 )
              goto LABEL_21;
          }
        }
        v22 = RBX::Instance::findConstFirstChildByName(newParent, *((const std::string **)i.px->_vptr$EventSource + 8));
        v23 = (RBX::Instance *)v22;
        if ( v22 )
        {
          v24 = v22->descriptor;
          v25 = Class_getDescriptorPtr(0);
          if ( *((unsigned __int16 *)v24 + 363) - (unsigned int)*((unsigned __int16 *)v25 + 363) <= *((unsigned __int16 *)v25 + 364) )
          {
            v26 = *((_QWORD *)i.px->_vptr$EventSource + 3);
            v27 = Class_getDescriptorPtr(0);
            if ( *(unsigned __int16 *)(v26 + 726) - (unsigned int)*((unsigned __int16 *)v27 + 363) <= *((unsigned __int16 *)v27 + 364) )
            {
              RBX::shared_from<RBX::Instance>(&v34.px, v23);
              if ( v19 )
                RBX::HumanoidAssetSwapper::AssetTracker::removeInstance(
                  (RBX::HumanoidAssetSwapper::AssetTracker *)(v19 + 2776),
                  &v34);
              v28 = v34.pn.pi_;
              if ( v34.pn.pi_ )
              {
                if ( !_InterlockedSub(&v34.pn.pi_->use_count_, 1u) )
                {
                  (*((void (__fastcall **)(boost::detail::sp_counted_base *))v28->_vptr$sp_counted_base + 2))(v28);
                  if ( !_InterlockedSub(&v28->weak_count_, 1u) )
                    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v28->_vptr$sp_counted_base + 3))(v28);
                }
              }
              RBX::Instance::setParentInternal(v23, 0, 0);
            }
          }
        }
        RBX::Instance::setParentInternal((RBX::Instance *)i.px->_vptr$EventSource, newParent, 0);
        v30 = i.px->_vptr$EventSource;
        v31 = (boost::detail::sp_counted_base *)i.px->weak_this_.px;
        if ( v31 )
          _InterlockedAdd(&v31->use_count_, 1u);
        if ( v19 )
        {
          v32 = (RBX::HumanoidAssetSwapper::AssetTracker *)(v19 + 2776);
          v34.px = (boost::shared_ptr<RBX::Instance>::element_type *)v30;
          v34.pn.pi_ = v31;
          if ( v31 )
            _InterlockedAdd(&v31->use_count_, 1u);
          v33 = &v34;
          RBX::HumanoidAssetSwapper::AssetTracker::addInstance(
            v32,
            v37,
            *(boost::shared_ptr<RBX::Instance> *)(&v29 - 1));
          if ( !v31 )
            goto LABEL_45;
          if ( !_InterlockedSub(&v31->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v31->_vptr$sp_counted_base + 2))(v31);
            if ( !_InterlockedSub(&v31->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))v31->_vptr$sp_counted_base + 3))(v31);
          }
        }
        else if ( !v31 )
        {
          goto LABEL_45;
        }
        if ( !_InterlockedSub(&v31->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v31->_vptr$sp_counted_base + 2))(v31);
          if ( !_InterlockedSub(&v31->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v31->_vptr$sp_counted_base + 3))(v31);
        }
      }
    }
LABEL_45:
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
}


// Address: 0x10d32e0 | Name: _ZN3RBX20HumanoidAssetSwapper19setAppearanceParentERKN5boost8weak_ptrINS_13ModelInstanceEEENS1_10shared_ptrINS_8InstanceEEEl
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::HumanoidAssetSwapper::setAppearanceParent(
        const boost::weak_ptr<RBX::ModelInstance> *weakCharacter,
        boost::shared_ptr<RBX::Instance> i,
        int64_t assetId)
{
  boost::detail::sp_counted_base *pi; // r13
  signed __int32 use_count; // eax
  signed __int32 v5; // ett
  _QWORD *px; // rax
  __int64 **v7; // rax
  __int64 *v8; // rbp
  __int64 *v9; // r14
  __int64 v10; // r15
  __int64 v11; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  int (**v13)(void); // r14
  __int64 v14; // rbx
  RBX::Reflection::ClassDescriptor *v15; // rax
  RBX::DataModelMesh *HeadMesh; // rax
  volatile signed __int32 *v17; // xmm0_8
  volatile signed __int32 *v18; // rbp
  __int64 v19; // rcx OVERLAPPED
  int (**v20)(void); // rax
  boost::detail::sp_counted_base *v21; // rbp
  int (**v22)(void); // r14
  __int64 v23; // rbx
  RBX::Reflection::ClassDescriptor *v24; // rax
  RBX::Decal *HeadDecal; // rax
  volatile signed __int32 *v26; // xmm0_8
  volatile signed __int32 *v27; // rbp
  __int64 v28; // rcx OVERLAPPED
  int (**v29)(void); // rax
  int (**v30)(void); // rbp
  __int64 v31; // rbx
  RBX::Reflection::ClassDescriptor *v32; // rax
  int (**v33)(void); // rbp
  __int64 v34; // rbx
  RBX::Reflection::ClassDescriptor *v35; // rax
  RBX::Instance *v36; // r14
  unsigned __int8 *v37; // rdi
  unsigned __int64 v38; // rax
  __m128i *p_si128; // rdx
  __int64 v40; // rbx
  RBX::Reflection::ClassDescriptor *v41; // rax
  __int64 v42; // rcx OVERLAPPED
  int (**v43)(void); // rax
  boost::detail::sp_counted_base *v44; // r12
  RBX::HumanoidAssetSwapper::AssetTracker *v45; // r15
  __m128i *v46; // rdx
  int v47; // eax
  RBX::Decal *v48; // rax
  const RBX::Instance *ConstFirstChildByName; // rax
  RBX::Instance *v50; // rbp
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *v52; // rax
  __int64 v53; // rbx
  RBX::Reflection::ClassDescriptor *v54; // rax
  boost::detail::sp_counted_base *v55; // r14
  int (**v56)(void); // rbp
  __int64 v57; // rbx
  RBX::Reflection::ClassDescriptor *v58; // rax
  __int64 v59; // rcx OVERLAPPED
  int (**v60)(void); // rax
  boost::detail::sp_counted_base *v61; // r12
  __m128i *v62; // rdx
  __m128i *v63; // rdx
  __m128i si128; // [rsp+0h] [rbp-68h] BYREF
  RBX::HumanoidAssetSwapper::AssetTracker *v65; // [rsp+18h] [rbp-50h]
  RBX::Decal *val[2]; // [rsp+20h] [rbp-48h] BYREF
  int64_t v67; // [rsp+30h] [rbp-38h]

  pi = weakCharacter->pn.pi_;
  if ( pi )
  {
    use_count = pi->use_count_;
    do
    {
      if ( !use_count )
        return;
      v5 = use_count;
      use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
    }
    while ( v5 != use_count );
    v67 = (int64_t)i.pn.pi_;
    px = weakCharacter->px;
    if ( weakCharacter->px && i.px->_vptr$EventSource )
    {
      v65 = (RBX::HumanoidAssetSwapper::AssetTracker *)weakCharacter->px;
      v7 = (__int64 **)px[9];
      if ( !v7 || (v8 = *v7, v9 = v7[1], *v7 == v9) )
      {
LABEL_12:
        v10 = 0;
      }
      else
      {
        while ( 1 )
        {
          v10 = *v8;
          if ( *v8 )
          {
            v11 = *(_QWORD *)(v10 + 24);
            DescriptorPtr = Class_getDescriptorPtr(0);
            if ( *(unsigned __int16 *)(v11 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
              break;
          }
          v8 += 2;
          if ( v9 == v8 )
            goto LABEL_12;
        }
      }
      v13 = i.px->_vptr$EventSource;
      v14 = *((_QWORD *)i.px->_vptr$EventSource + 3);
      v15 = Class_getDescriptorPtr(0);
      if ( v13
        && *(unsigned __int16 *)(v14 + 726) - (unsigned int)*((unsigned __int16 *)v15 + 363) <= *((unsigned __int16 *)v15
                                                                                                + 364) )
      {
        if ( !v10 )
          goto LABEL_116;
        HeadMesh = RBX::Humanoid::getHeadMesh((RBX::Humanoid *)v10);
        RBX::shared_from<RBX::DataModelMesh>(HeadMesh);
        si128 = _mm_load_si128((const __m128i *)val);
        *(_OWORD *)val = 0;
        v17 = (volatile signed __int32 *)_mm_shuffle_epi32(si128, 78).m128i_u64[0];
        RBX::HumanoidAssetSwapper::AssetTracker::removeInstance(
          (RBX::HumanoidAssetSwapper::AssetTracker *)(v10 + 2776),
          (const boost::shared_ptr<RBX::Instance> *)&si128);
        v65 = (RBX::HumanoidAssetSwapper::AssetTracker *)(v10 + 2776);
        if ( v17 )
        {
          if ( !_InterlockedSub(v17 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v17 + 16LL))(v17, *(double *)&v17);
            if ( !_InterlockedSub(v17 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v17 + 24LL))(v17);
          }
        }
        v18 = (volatile signed __int32 *)val[1];
        if ( val[1] )
        {
          if ( !_InterlockedSub((volatile signed __int32 *)val[1] + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 16LL))(v18);
            if ( !_InterlockedSub(v18 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v18 + 24LL))(v18);
          }
        }
        RBX::Humanoid::setHeadMesh((RBX::Humanoid *)v10, (RBX::DataModelMesh *)v13);
        v20 = i.px->_vptr$EventSource;
        v21 = (boost::detail::sp_counted_base *)i.px->weak_this_.px;
        if ( v21 )
        {
          _InterlockedAdd(&v21->use_count_, 1u);
          si128.m128i_i64[0] = (__int64)v20;
          _InterlockedAdd(&v21->use_count_, 1u);
        }
        else
        {
          si128.m128i_i64[0] = (__int64)i.px->_vptr$EventSource;
        }
        si128.m128i_i64[1] = (__int64)v21;
        p_si128 = &si128;
        RBX::HumanoidAssetSwapper::AssetTracker::addInstance(v65, v67, *(boost::shared_ptr<RBX::Instance> *)(&v19 - 1));
        if ( !v21 )
          goto LABEL_116;
        if ( !_InterlockedSub(&v21->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 2))(v21);
          if ( !_InterlockedSub(&v21->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 3))(v21);
        }
        if ( _InterlockedSub(&v21->use_count_, 1u) )
          goto LABEL_116;
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 2))(v21);
        if ( _InterlockedSub(&v21->weak_count_, 1u) )
          goto LABEL_116;
        goto LABEL_111;
      }
      v22 = i.px->_vptr$EventSource;
      v23 = *((_QWORD *)i.px->_vptr$EventSource + 3);
      v24 = Class_getDescriptorPtr(0);
      if ( v22
        && *(unsigned __int16 *)(v23 + 726) - (unsigned int)*((unsigned __int16 *)v24 + 363) <= *((unsigned __int16 *)v24
                                                                                                + 364) )
      {
        if ( !v10 )
          goto LABEL_116;
        HeadDecal = RBX::Humanoid::getHeadDecal((RBX::Humanoid *)v10);
        RBX::shared_from<RBX::Decal>(HeadDecal);
        si128 = _mm_load_si128((const __m128i *)val);
        *(_OWORD *)val = 0;
        v26 = (volatile signed __int32 *)_mm_shuffle_epi32(si128, 78).m128i_u64[0];
        RBX::HumanoidAssetSwapper::AssetTracker::removeInstance(
          (RBX::HumanoidAssetSwapper::AssetTracker *)(v10 + 2776),
          (const boost::shared_ptr<RBX::Instance> *)&si128);
        v65 = (RBX::HumanoidAssetSwapper::AssetTracker *)(v10 + 2776);
        if ( v26 )
        {
          if ( !_InterlockedSub(v26 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v26 + 16LL))(v26, *(double *)&v26);
            if ( !_InterlockedSub(v26 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 24LL))(v26);
          }
        }
        v27 = (volatile signed __int32 *)val[1];
        if ( val[1] )
        {
          if ( !_InterlockedSub((volatile signed __int32 *)val[1] + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 16LL))(v27);
            if ( !_InterlockedSub(v27 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v27 + 24LL))(v27);
          }
        }
        RBX::Humanoid::setHeadDecal((RBX::Humanoid *)v10, (RBX::Decal *)v22);
        v29 = i.px->_vptr$EventSource;
        v21 = (boost::detail::sp_counted_base *)i.px->weak_this_.px;
        if ( v21 )
        {
          _InterlockedAdd(&v21->use_count_, 1u);
          si128.m128i_i64[0] = (__int64)v29;
          _InterlockedAdd(&v21->use_count_, 1u);
        }
        else
        {
          si128.m128i_i64[0] = (__int64)i.px->_vptr$EventSource;
        }
        si128.m128i_i64[1] = (__int64)v21;
        v63 = &si128;
        RBX::HumanoidAssetSwapper::AssetTracker::addInstance(v65, v67, *(boost::shared_ptr<RBX::Instance> *)(&v28 - 1));
        if ( !v21 )
          goto LABEL_116;
        if ( !_InterlockedSub(&v21->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 2))(v21);
          if ( !_InterlockedSub(&v21->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 3))(v21);
        }
        if ( _InterlockedSub(&v21->use_count_, 1u) )
          goto LABEL_116;
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 2))(v21);
        if ( _InterlockedSub(&v21->weak_count_, 1u) )
          goto LABEL_116;
        goto LABEL_111;
      }
      v30 = i.px->_vptr$EventSource;
      v31 = *((_QWORD *)i.px->_vptr$EventSource + 3);
      v32 = Class_getDescriptorPtr(0);
      if ( v30
        && *(unsigned __int16 *)(v31 + 726) - (unsigned int)*((unsigned __int16 *)v32 + 363) <= *((unsigned __int16 *)v32
                                                                                                + 364)
        || (v33 = i.px->_vptr$EventSource,
            v34 = *((_QWORD *)i.px->_vptr$EventSource + 3),
            v35 = Class_getDescriptorPtr(0),
            v33)
        && *(unsigned __int16 *)(v34 + 726) - (unsigned int)*((unsigned __int16 *)v35 + 363) <= *((unsigned __int16 *)v35
                                                                                                + 364) )
      {
        v36 = (RBX::Instance *)v65;
        if ( stru_2A630F0.value )
        {
          v37 = (unsigned __int8 *)*((_QWORD *)i.px->_vptr$EventSource + 8);
          v38 = *v37;
          if ( (v38 & 1) != 0 )
          {
            if ( *((_QWORD *)v37 + 1) != 4 )
              goto LABEL_69;
          }
          else if ( v38 >> 1 != 4 )
          {
            goto LABEL_69;
          }
          v47 = std::string::compare(v37, 0, -1, "Head", 4);
          if ( v10 && !v47 )
          {
            v48 = RBX::Humanoid::getHeadDecal((RBX::Humanoid *)v10);
            RBX::shared_from<RBX::Decal>(v48);
LABEL_70:
            ConstFirstChildByName = RBX::Instance::findConstFirstChildByName(
                                      (const RBX::Instance *)v65,
                                      *((const std::string **)i.px->_vptr$EventSource + 8));
            v50 = (RBX::Instance *)ConstFirstChildByName;
            if ( ConstFirstChildByName )
            {
              descriptor = ConstFirstChildByName->descriptor;
              v52 = Class_getDescriptorPtr(0);
              if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)v52 + 363) <= *((unsigned __int16 *)v52 + 364) )
              {
                v53 = *((_QWORD *)i.px->_vptr$EventSource + 3);
                v54 = Class_getDescriptorPtr(0);
                if ( *(unsigned __int16 *)(v53 + 726) - (unsigned int)*((unsigned __int16 *)v54 + 363) <= *((unsigned __int16 *)v54 + 364) )
                {
                  RBX::shared_from<RBX::Instance>(
                    (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)&si128,
                    v50);
                  if ( v10 )
                    RBX::HumanoidAssetSwapper::AssetTracker::removeInstance(
                      (RBX::HumanoidAssetSwapper::AssetTracker *)(v10 + 2776),
                      (const boost::shared_ptr<RBX::Instance> *)&si128);
                  v55 = (boost::detail::sp_counted_base *)si128.m128i_i64[1];
                  if ( si128.m128i_i64[1] )
                  {
                    if ( !_InterlockedSub((volatile signed __int32 *)(si128.m128i_i64[1] + 8), 1u) )
                    {
                      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v55->_vptr$sp_counted_base + 2))(v55);
                      if ( !_InterlockedSub(&v55->weak_count_, 1u) )
                        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v55->_vptr$sp_counted_base + 3))(v55);
                    }
                  }
                  RBX::Instance::setParentInternal(v50, 0, 0);
                  v36 = (RBX::Instance *)v65;
                }
              }
            }
            v56 = i.px->_vptr$EventSource;
            v57 = *((_QWORD *)i.px->_vptr$EventSource + 3);
            v58 = Class_getDescriptorPtr(0);
            if ( v56
              && *(unsigned __int16 *)(v57 + 726) - (unsigned int)*((unsigned __int16 *)v58 + 363) <= *((unsigned __int16 *)v58 + 364) )
            {
              (*((void (__fastcall **)(int (**)(void), __int64))*v56 + 80))(v56, 1);
            }
            RBX::Instance::setParentInternal((RBX::Instance *)i.px->_vptr$EventSource, v36, 0);
            v60 = i.px->_vptr$EventSource;
            v61 = (boost::detail::sp_counted_base *)i.px->weak_this_.px;
            if ( v61 )
              _InterlockedAdd(&v61->use_count_, 1u);
            if ( v10 )
            {
              si128.m128i_i64[0] = (__int64)v60;
              si128.m128i_i64[1] = (__int64)v61;
              if ( v61 )
                _InterlockedAdd(&v61->use_count_, 1u);
              v62 = &si128;
              RBX::HumanoidAssetSwapper::AssetTracker::addInstance(
                (RBX::HumanoidAssetSwapper::AssetTracker *)(v10 + 2776),
                v67,
                *(boost::shared_ptr<RBX::Instance> *)(&v59 - 1));
              if ( !v61 )
              {
LABEL_96:
                if ( stru_2A630F0.value && v10 && val[0] )
                  RBX::Humanoid::setHeadDecal((RBX::Humanoid *)v10, val[0]);
                v21 = (boost::detail::sp_counted_base *)val[1];
                if ( !val[1] )
                  goto LABEL_116;
                if ( _InterlockedSub((volatile signed __int32 *)val[1] + 2, 1u) )
                  goto LABEL_116;
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 2))(v21);
                if ( _InterlockedSub(&v21->weak_count_, 1u) )
                  goto LABEL_116;
LABEL_111:
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 3))(v21);
                goto LABEL_116;
              }
              if ( !_InterlockedSub(&v61->use_count_, 1u) )
              {
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))v61->_vptr$sp_counted_base + 2))(v61);
                if ( !_InterlockedSub(&v61->weak_count_, 1u) )
                  (*((void (__fastcall **)(boost::detail::sp_counted_base *))v61->_vptr$sp_counted_base + 3))(v61);
              }
            }
            else if ( !v61 )
            {
              goto LABEL_96;
            }
            if ( !_InterlockedSub(&v61->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))v61->_vptr$sp_counted_base + 2))(v61);
              if ( !_InterlockedSub(&v61->weak_count_, 1u) )
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))v61->_vptr$sp_counted_base + 3))(v61);
            }
            goto LABEL_96;
          }
        }
LABEL_69:
        *(_OWORD *)val = 0;
        goto LABEL_70;
      }
      v40 = *((_QWORD *)i.px->_vptr$EventSource + 3);
      v41 = Class_getDescriptorPtr(0);
      if ( *(unsigned __int16 *)(v40 + 726) - (unsigned int)*((unsigned __int16 *)v41 + 363) > *((unsigned __int16 *)v41
                                                                                               + 364) )
        goto LABEL_116;
      RBX::Instance::setParentInternal((RBX::Instance *)i.px->_vptr$EventSource, (RBX::Instance *)v65, 0);
      v43 = i.px->_vptr$EventSource;
      v44 = (boost::detail::sp_counted_base *)i.px->weak_this_.px;
      if ( v44 )
        _InterlockedAdd(&v44->use_count_, 1u);
      if ( v10 )
      {
        v45 = (RBX::HumanoidAssetSwapper::AssetTracker *)(v10 + 2776);
        si128.m128i_i64[0] = (__int64)v43;
        si128.m128i_i64[1] = (__int64)v44;
        if ( v44 )
          _InterlockedAdd(&v44->use_count_, 1u);
        v46 = &si128;
        RBX::HumanoidAssetSwapper::AssetTracker::addInstance(v45, v67, *(boost::shared_ptr<RBX::Instance> *)(&v42 - 1));
        if ( !v44 )
          goto LABEL_116;
        if ( !_InterlockedSub(&v44->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v44->_vptr$sp_counted_base + 2))(v44);
          if ( !_InterlockedSub(&v44->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v44->_vptr$sp_counted_base + 3))(v44);
        }
        goto LABEL_113;
      }
      if ( v44 )
      {
LABEL_113:
        if ( !_InterlockedSub(&v44->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v44->_vptr$sp_counted_base + 2))(v44);
          if ( !_InterlockedSub(&v44->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v44->_vptr$sp_counted_base + 3))(v44);
        }
      }
    }
LABEL_116:
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
}


// Address: 0x10d3eb0 | Name: _ZN3RBX20HumanoidAssetSwapper20applyAppearanceAssetERKN5boost8weak_ptrINS_13ModelInstanceEEENS1_10shared_ptrINSt3__16vectorINS7_INS_8InstanceEEENS8_9allocatorISB_EEEEEEblRKNS8_8functionIFvSB_EEE
void __fastcall RBX::HumanoidAssetSwapper::applyAppearanceAsset(
        const boost::weak_ptr<RBX::ModelInstance> *weakCharacter,
        boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > instances,
        boost::detail::sp_counted_base *useR15,
        const std::function<void (boost::shared_ptr<RBX::Instance>)> *assetId,
        const std::function<void (boost::shared_ptr<RBX::Instance>)> *callbackForInstanceApplied)
{
  __int64 v5; // rax
  unsigned __int64 v6; // rbp
  __int64 v7; // r12
  unsigned __int64 v8; // rcx
  RBX::Instance *v9; // r13
  boost::detail::sp_counted_base *v10; // r15
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v13; // rbx
  RBX::Reflection::ClassDescriptor *v14; // rax
  __int64 v15; // rdx
  __int64 v16; // r9
  const RBX::Reflection::ClassDescriptor *v17; // rbx
  RBX::Reflection::ClassDescriptor *v18; // rax
  boost::detail::sp_counted_base *v19; // rax
  std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *v20; // rdi
  boost::detail::sp_counted_base *v21; // rax
  std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *f; // rdi
  boost::weak_ptr<RBX::ModelInstance> v23; // rdx
  boost::detail::sp_counted_base *v24; // rdi
  boost::detail::sp_counted_base *v25; // rdi
  boost::weak_ptr<RBX::ModelInstance> v26; // rdx
  boost::detail::sp_counted_base *v27; // rdi
  const RBX::Instance *v28; // rbp
  boost::detail::sp_counted_base *v29; // rax
  std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *v30; // rdi
  const RBX::Instance *v31; // rbp
  boost::detail::sp_counted_base *v32; // rax
  std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *v33; // rdi
  boost::weak_ptr<RBX::ModelInstance> v34; // rdx
  boost::detail::sp_counted_base *v35; // rdi
  boost::detail::sp_counted_base *v36; // rdi
  boost::weak_ptr<RBX::ModelInstance> v37; // rdx
  boost::detail::sp_counted_base *v38; // rdi
  std::function<void (boost::shared_ptr<RBX::Instance>)> v39; // [rsp+0h] [rbp-218h]
  char pi; // [rsp+4Ch] [rbp-1CCh]
  _BYTE v44[16]; // [rsp+50h] [rbp-1C8h] BYREF
  void *ptr; // [rsp+60h] [rbp-1B8h]
  boost::weak_ptr<RBX::ModelInstance> v46; // [rsp+68h] [rbp-1B0h] BYREF
  boost::weak_ptr<RBX::ModelInstance> v47; // [rsp+78h] [rbp-1A0h] BYREF
  boost::weak_ptr<RBX::ModelInstance> v48; // [rsp+88h] [rbp-190h] BYREF
  boost::weak_ptr<RBX::ModelInstance> a1; // [rsp+98h] [rbp-180h] BYREF
  __int64 **px; // [rsp+A8h] [rbp-170h]
  boost::weak_ptr<RBX::Instance> v51; // [rsp+B0h] [rbp-168h] BYREF
  boost::arg<1> v52; // [rsp+C0h] [rbp-158h] BYREF
  boost::arg<1> *v53; // [rsp+E0h] [rbp-138h]
  boost::arg<1> v54; // [rsp+F0h] [rbp-128h] BYREF
  boost::arg<1> *v55; // [rsp+110h] [rbp-108h]
  boost::arg<1> v56; // [rsp+120h] [rbp-F8h] BYREF
  boost::arg<1> *v57; // [rsp+140h] [rbp-D8h]
  boost::arg<1> a2; // [rsp+150h] [rbp-C8h] BYREF
  boost::arg<1> *p_a2; // [rsp+170h] [rbp-A8h]
  boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::ModelInstance> &,boost::weak_ptr<RBX::Instance>,long,const std::function<void (boost::shared_ptr<RBX::Instance>)> &),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > > > func; // [rsp+180h] [rbp-98h] BYREF
  unsigned __int64 v61; // [rsp+1E0h] [rbp-38h]

  v61 = __readfsqword(0x28u);
  px = (__int64 **)instances.px;
  v5 = **(_QWORD **)instances.px;
  if ( *(_QWORD *)(*(_QWORD *)instances.px + 8LL) == v5 )
    return;
  pi = (char)instances.pn.pi_;
  v39.__buf_.__lx[31] = LOBYTE(instances.pn.pi_) ^ 1;
  v6 = 0;
  v7 = 8;
  *(_QWORD *)&v39.__buf_.__lx[16] = 0;
  (&v39.__f_)[1] = 0;
  v39.__f_ = 0;
  v8 = 0;
  *(_QWORD *)&v39.__buf_.__lx[8] = 0;
  do
  {
    v9 = *(RBX::Instance **)(v5 + v7 - 8);
    v10 = *(boost::detail::sp_counted_base **)(v5 + v7);
    if ( v10 )
      _InterlockedAdd(&v10->use_count_, 1u);
    if ( !v9 )
      goto LABEL_81;
    std::string::basic_string(v44, v9->name.h.h);
    descriptor = v9->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364)
      || ((unsigned int)std::string::compare(v44, "R6") || pi)
      && v39.__buf_.__lx[31] | ((unsigned int)std::string::compare(v44, "R15") != 0) )
    {
      if ( !pi )
        goto LABEL_12;
      v13 = v9->descriptor;
      v14 = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)v13 + 363) - (unsigned int)*((unsigned __int16 *)v14 + 363) > *((unsigned __int16 *)v14
                                                                                               + 364)
        || (unsigned int)std::string::compare(v44, "R15Anim") )
      {
        v17 = v9->descriptor;
        v18 = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)v17 + 363) - (unsigned int)*((unsigned __int16 *)v18 + 363) <= *((unsigned __int16 *)v18
                                                                                                  + 364) )
        {
          instances.px = "R15ArtistIntent";
          if ( !(unsigned int)std::string::compare(v44, "R15ArtistIntent") )
          {
            if ( v10 )
              _InterlockedAdd(&v10->use_count_, 1u);
            if ( !*(_QWORD *)&v39.__buf_.__lx[8]
              || _InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v39.__buf_.__lx[8] + 8LL), 1u)
              || ((*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v39.__buf_.__lx[8] + 16LL))(*(_QWORD *)&v39.__buf_.__lx[8]),
                  _InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v39.__buf_.__lx[8] + 12LL), 1u)) )
            {
              *(_QWORD *)&v39.__buf_.__lx[8] = v10;
              v39.__f_ = (std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *)v9;
              if ( (v44[0] & 1) == 0 )
                goto LABEL_81;
LABEL_80:
              operator delete(ptr);
              goto LABEL_81;
            }
            (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v39.__buf_.__lx[8] + 24LL))(*(_QWORD *)&v39.__buf_.__lx[8]);
            *(_QWORD *)&v39.__buf_.__lx[8] = v10;
            v39.__f_ = (std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *)v9;
            goto LABEL_79;
          }
        }
LABEL_12:
        v51.px = v9;
        v51.pn.pi_ = v10;
        if ( v10 )
          _InterlockedAdd(&v10->weak_count_, 1u);
        instances.px = &v51;
        RBX::setAppearanceParentInternal(
          weakCharacter,
          (boost::weak_ptr<RBX::Instance>)__PAIR128__((unsigned __int64)useR15, &v51),
          (int64_t)assetId,
          assetId);
        if ( v10 && !_InterlockedSub(&v10->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
        goto LABEL_79;
      }
      v48.px = weakCharacter->px;
      v21 = weakCharacter->pn.pi_;
      v48.pn.pi_ = v21;
      if ( v21 )
        _InterlockedAdd(&v21->weak_count_, 1u);
      f = assetId->__f_;
      if ( f )
      {
        if ( assetId == (const std::function<void (boost::shared_ptr<RBX::Instance>)> *)f )
        {
          v57 = &v56;
          (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *, boost::arg<1> *, __int64, boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::ModelInstance> &,boost::weak_ptr<RBX::Instance>,long,const std::function<void (boost::shared_ptr<RBX::Instance>)> &),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > > > *))f->_vptr$__base
           + 3))(
            f,
            &v56,
            v15,
            &func);
        }
        else
        {
          v57 = (boost::arg<1> *)(*((__int64 (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *, const char *, __int64, boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::ModelInstance> &,boost::weak_ptr<RBX::Instance>,long,const std::function<void (boost::shared_ptr<RBX::Instance>)> &),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > > > *))f->_vptr$__base
                                  + 2))(
                                   f,
                                   "R15Anim",
                                   v15,
                                   &func);
        }
      }
      else
      {
        v57 = 0;
      }
      v26.px = &v48;
      v26.pn.pi_ = useR15;
      boost::bind<void,boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&,boost::weak_ptr<RBX::ModelInstance>,boost::arg<1>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)>>(
        &func,
        RBX::setAnimationParentInternal,
        v26,
        (boost::arg<1>)&v56,
        v16,
        v39);
      instances.px = &func;
      RBX::Instance::visitChildren<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance>>,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void ()(boost::shared_ptr<RBX::Instance>)>>>>>(
        v9,
        &func);
      if ( &func.l_.a4_ == (boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *)func.l_.a4_.t_.__f_ )
      {
        (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *))func.l_.a4_.t_.__f_->_vptr$__base
         + 4))(func.l_.a4_.t_.__f_);
      }
      else if ( func.l_.a4_.t_.__f_ )
      {
        (*((void (**)(void))func.l_.a4_.t_.__f_->_vptr$__base + 5))();
      }
      v27 = func.l_.a1_.t_.pn.pi_;
      if ( func.l_.a1_.t_.pn.pi_ && !_InterlockedSub(&func.l_.a1_.t_.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v27->_vptr$sp_counted_base + 3))(v27);
      if ( &v56 == v57 )
      {
        (*(void (__fastcall **)(boost::arg<1> *))(*(_QWORD *)&v57->gap0 + 32LL))(v57);
      }
      else if ( v57 )
      {
        (*(void (**)(void))(*(_QWORD *)&v57->gap0 + 40LL))();
      }
      v25 = v48.pn.pi_;
      if ( v48.pn.pi_ && !_InterlockedSub(&v48.pn.pi_->weak_count_, 1u) )
        goto LABEL_78;
    }
    else
    {
      instances.px = "R15";
      if ( !(unsigned int)std::string::compare(v44, "R15") )
      {
        if ( v10 )
          _InterlockedAdd(&v10->use_count_, 1u);
        if ( !*(_QWORD *)&v39.__buf_.__lx[16]
          || _InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v39.__buf_.__lx[16] + 8LL), 1u)
          || ((*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v39.__buf_.__lx[16] + 16LL))(*(_QWORD *)&v39.__buf_.__lx[16]),
              _InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v39.__buf_.__lx[16] + 12LL), 1u)) )
        {
          (&v39.__f_)[1] = (std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *)v9;
          *(_QWORD *)&v39.__buf_.__lx[16] = v10;
          if ( (v44[0] & 1) == 0 )
            goto LABEL_81;
          goto LABEL_80;
        }
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v39.__buf_.__lx[16] + 24LL))(*(_QWORD *)&v39.__buf_.__lx[16]);
        (&v39.__f_)[1] = (std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *)v9;
        *(_QWORD *)&v39.__buf_.__lx[16] = v10;
        goto LABEL_79;
      }
      a1.px = weakCharacter->px;
      v19 = weakCharacter->pn.pi_;
      a1.pn.pi_ = v19;
      if ( v19 )
        _InterlockedAdd(&v19->weak_count_, 1u);
      v20 = assetId->__f_;
      if ( v20 )
      {
        if ( assetId == (const std::function<void (boost::shared_ptr<RBX::Instance>)> *)v20 )
        {
          p_a2 = &a2;
          (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *, boost::arg<1> *, boost::detail::sp_counted_base *, boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::ModelInstance> &,boost::weak_ptr<RBX::Instance>,long,const std::function<void (boost::shared_ptr<RBX::Instance>)> &),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > > > *))v20->_vptr$__base
           + 3))(
            v20,
            &a2,
            instances.pn.pi_,
            &func);
        }
        else
        {
          p_a2 = (boost::arg<1> *)(*((__int64 (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *, const char *, boost::detail::sp_counted_base *, boost::_bi::bind_t<void,void (*)(const boost::weak_ptr<RBX::ModelInstance> &,boost::weak_ptr<RBX::Instance>,long,const std::function<void (boost::shared_ptr<RBX::Instance>)> &),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance> >,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > > > *))v20->_vptr$__base
                                   + 2))(
                                    v20,
                                    "R15",
                                    instances.pn.pi_,
                                    &func);
        }
      }
      else
      {
        p_a2 = 0;
      }
      v23.px = &a1;
      v23.pn.pi_ = useR15;
      boost::bind<void,boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&,boost::weak_ptr<RBX::ModelInstance>,boost::arg<1>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)>>(
        &func,
        RBX::setAppearanceParentInternal,
        v23,
        (boost::arg<1>)&a2,
        (__int64)callbackForInstanceApplied,
        v39);
      instances.px = &func;
      RBX::Instance::visitChildren<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance>>,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void ()(boost::shared_ptr<RBX::Instance>)>>>>>(
        v9,
        &func);
      if ( &func.l_.a4_ == (boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *)func.l_.a4_.t_.__f_ )
      {
        (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *))func.l_.a4_.t_.__f_->_vptr$__base
         + 4))(func.l_.a4_.t_.__f_);
      }
      else if ( func.l_.a4_.t_.__f_ )
      {
        (*((void (**)(void))func.l_.a4_.t_.__f_->_vptr$__base + 5))();
      }
      v24 = func.l_.a1_.t_.pn.pi_;
      if ( func.l_.a1_.t_.pn.pi_ && !_InterlockedSub(&func.l_.a1_.t_.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v24->_vptr$sp_counted_base + 3))(v24);
      if ( &a2 == p_a2 )
      {
        (*(void (__fastcall **)(boost::arg<1> *))(*(_QWORD *)&p_a2->gap0 + 32LL))(p_a2);
      }
      else if ( p_a2 )
      {
        (*(void (**)(void))(*(_QWORD *)&p_a2->gap0 + 40LL))();
      }
      v25 = a1.pn.pi_;
      if ( a1.pn.pi_ && !_InterlockedSub(&a1.pn.pi_->weak_count_, 1u) )
LABEL_78:
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v25->_vptr$sp_counted_base + 3))(v25);
    }
LABEL_79:
    if ( (v44[0] & 1) != 0 )
      goto LABEL_80;
LABEL_81:
    if ( v10 )
    {
      if ( !_InterlockedSub(&v10->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *, unsigned __int64, const std::function<void (boost::shared_ptr<RBX::Instance>)> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))v10->_vptr$sp_counted_base
         + 2))(
          v10,
          instances.px,
          instances.pn.pi_,
          v8,
          assetId,
          callbackForInstanceApplied);
        if ( !_InterlockedSub(&v10->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
      }
    }
    ++v6;
    v5 = **px;
    v8 = ((*px)[1] - v5) >> 4;
    v7 += 16;
  }
  while ( v6 < v8 );
  v28 = (const RBX::Instance *)v39.__f_;
  if ( v39.__f_ )
  {
    v47.px = weakCharacter->px;
    v29 = weakCharacter->pn.pi_;
    v47.pn.pi_ = v29;
    if ( v29 )
      _InterlockedAdd(&v29->weak_count_, 1u);
    v30 = assetId->__f_;
    if ( v30 )
    {
      if ( assetId == (const std::function<void (boost::shared_ptr<RBX::Instance>)> *)v30 )
      {
        v55 = &v54;
        (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *, boost::arg<1> *, boost::detail::sp_counted_base *, const boost::weak_ptr<RBX::ModelInstance> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))v30->_vptr$__base
         + 3))(
          v30,
          &v54,
          instances.pn.pi_,
          weakCharacter,
          assetId,
          callbackForInstanceApplied);
      }
      else
      {
        v55 = (boost::arg<1> *)(*((__int64 (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *, const boost::weak_ptr<RBX::ModelInstance> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))v30->_vptr$__base
                                + 2))(
                                 v30,
                                 instances.px,
                                 instances.pn.pi_,
                                 weakCharacter,
                                 assetId,
                                 callbackForInstanceApplied);
      }
    }
    else
    {
      v55 = 0;
    }
    v34.px = &v47;
    v34.pn.pi_ = useR15;
    boost::bind<void,boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&,boost::weak_ptr<RBX::ModelInstance>,boost::arg<1>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)>>(
      &func,
      RBX::setAppearanceParentInternal,
      v34,
      (boost::arg<1>)&v54,
      (__int64)callbackForInstanceApplied,
      v39);
    instances.px = &func;
    RBX::Instance::visitChildren<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance>>,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void ()(boost::shared_ptr<RBX::Instance>)>>>>>(
      v28,
      &func);
    if ( &func.l_.a4_ == (boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *)func.l_.a4_.t_.__f_ )
    {
      (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *))func.l_.a4_.t_.__f_->_vptr$__base
       + 4))(func.l_.a4_.t_.__f_);
    }
    else if ( func.l_.a4_.t_.__f_ )
    {
      (*((void (**)(void))func.l_.a4_.t_.__f_->_vptr$__base + 5))();
    }
    v35 = func.l_.a1_.t_.pn.pi_;
    if ( func.l_.a1_.t_.pn.pi_ && !_InterlockedSub(&func.l_.a1_.t_.pn.pi_->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v35->_vptr$sp_counted_base + 3))(v35);
    if ( &v54 == v55 )
    {
      (*(void (__fastcall **)(boost::arg<1> *))(*(_QWORD *)&v55->gap0 + 32LL))(v55);
    }
    else if ( v55 )
    {
      (*(void (**)(void))(*(_QWORD *)&v55->gap0 + 40LL))();
    }
    v36 = v47.pn.pi_;
    if ( v47.pn.pi_ && !_InterlockedSub(&v47.pn.pi_->weak_count_, 1u) )
      goto LABEL_129;
  }
  else
  {
    v31 = (const RBX::Instance *)(&v39.__f_)[1];
    if ( (&v39.__f_)[1] )
    {
      v46.px = weakCharacter->px;
      v32 = weakCharacter->pn.pi_;
      v46.pn.pi_ = v32;
      if ( v32 )
        _InterlockedAdd(&v32->weak_count_, 1u);
      v33 = assetId->__f_;
      if ( v33 )
      {
        if ( assetId == (const std::function<void (boost::shared_ptr<RBX::Instance>)> *)v33 )
        {
          v53 = &v52;
          (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *, boost::arg<1> *, boost::detail::sp_counted_base *, const boost::weak_ptr<RBX::ModelInstance> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))v33->_vptr$__base
           + 3))(
            v33,
            &v52,
            instances.pn.pi_,
            weakCharacter,
            assetId,
            callbackForInstanceApplied);
        }
        else
        {
          v53 = (boost::arg<1> *)(*((__int64 (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *, const boost::weak_ptr<RBX::ModelInstance> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))v33->_vptr$__base
                                  + 2))(
                                   v33,
                                   instances.px,
                                   instances.pn.pi_,
                                   weakCharacter,
                                   assetId,
                                   callbackForInstanceApplied);
        }
      }
      else
      {
        v53 = 0;
      }
      v37.px = &v46;
      v37.pn.pi_ = useR15;
      boost::bind<void,boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&,boost::weak_ptr<RBX::ModelInstance>,boost::arg<1>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)>>(
        &func,
        RBX::setAppearanceParentInternal,
        v37,
        (boost::arg<1>)&v52,
        (__int64)callbackForInstanceApplied,
        v39);
      instances.px = &func;
      RBX::Instance::visitChildren<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::ModelInstance> const&,boost::weak_ptr<RBX::Instance>,long,std::function<void ()(boost::shared_ptr<RBX::Instance>)> const&),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::ModelInstance>>,boost::arg<1>,boost::_bi::value<long>,boost::_bi::value<std::function<void ()(boost::shared_ptr<RBX::Instance>)>>>>>(
        v31,
        &func);
      if ( &func.l_.a4_ == (boost::_bi::value<std::function<void (boost::shared_ptr<RBX::Instance>)> > *)func.l_.a4_.t_.__f_ )
      {
        (*((void (__fastcall **)(std::function<void (boost::shared_ptr<RBX::Instance>)>::__base *))func.l_.a4_.t_.__f_->_vptr$__base
         + 4))(func.l_.a4_.t_.__f_);
      }
      else if ( func.l_.a4_.t_.__f_ )
      {
        (*((void (**)(void))func.l_.a4_.t_.__f_->_vptr$__base + 5))();
      }
      v38 = func.l_.a1_.t_.pn.pi_;
      if ( func.l_.a1_.t_.pn.pi_ && !_InterlockedSub(&func.l_.a1_.t_.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v38->_vptr$sp_counted_base + 3))(v38);
      if ( &v52 == v53 )
      {
        (*(void (__fastcall **)(boost::arg<1> *))(*(_QWORD *)&v53->gap0 + 32LL))(v53);
      }
      else if ( v53 )
      {
        (*(void (**)(void))(*(_QWORD *)&v53->gap0 + 40LL))();
      }
      v36 = v46.pn.pi_;
      if ( v46.pn.pi_ )
      {
        if ( !_InterlockedSub(&v46.pn.pi_->weak_count_, 1u) )
LABEL_129:
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v36->_vptr$sp_counted_base + 3))(v36);
      }
    }
  }
  if ( *(_QWORD *)&v39.__buf_.__lx[8] )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v39.__buf_.__lx[8] + 8LL), 1u) )
    {
      (*(void (__fastcall **)(_QWORD, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *, unsigned __int64, const std::function<void (boost::shared_ptr<RBX::Instance>)> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))(**(_QWORD **)&v39.__buf_.__lx[8] + 16LL))(
        *(_QWORD *)&v39.__buf_.__lx[8],
        instances.px,
        instances.pn.pi_,
        v8,
        assetId,
        callbackForInstanceApplied);
      if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v39.__buf_.__lx[8] + 12LL), 1u) )
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v39.__buf_.__lx[8] + 24LL))(*(_QWORD *)&v39.__buf_.__lx[8]);
    }
  }
  if ( *(_QWORD *)&v39.__buf_.__lx[16]
    && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v39.__buf_.__lx[16] + 8LL), 1u) )
  {
    (*(void (__fastcall **)(_QWORD, boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> >::element_type *, boost::detail::sp_counted_base *, unsigned __int64, const std::function<void (boost::shared_ptr<RBX::Instance>)> *, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))(**(_QWORD **)&v39.__buf_.__lx[16] + 16LL))(
      *(_QWORD *)&v39.__buf_.__lx[16],
      instances.px,
      instances.pn.pi_,
      v8,
      assetId,
      callbackForInstanceApplied);
    if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v39.__buf_.__lx[16] + 12LL), 1u) )
      (*(void (__fastcall **)(_QWORD))(**(_QWORD **)&v39.__buf_.__lx[16] + 24LL))(*(_QWORD *)&v39.__buf_.__lx[16]);
  }
}


// Address: 0x10d4bb0 | Name: _ZN3RBXL27setAppearanceParentInternalERKN5boost8weak_ptrINS_13ModelInstanceEEENS1_INS_8InstanceEEElRKNSt3__18functionIFvNS0_10shared_ptrIS6_EEEEE
void __fastcall RBX::setAppearanceParentInternal(
        const boost::weak_ptr<RBX::ModelInstance> *weakCharacter,
        boost::weak_ptr<RBX::Instance> instance,
        int64_t assetId,
        const std::function<void (boost::shared_ptr<RBX::Instance>)> *callbackForInstanceApplied)
{
  boost::detail::sp_counted_base *px; // rbx
  signed __int32 use_count; // eax
  int64_t v7; // rcx
  signed __int32 v8; // ett
  int (**v9)(void); // r15
  __int64 v10; // rdi
  volatile signed __int32 *v11; // r14
  _QWORD *exception; // rax
  int (**v13)(void); // [rsp+0h] [rbp-38h] BYREF
  volatile signed __int32 *v14; // [rsp+8h] [rbp-30h]
  boost::shared_ptr<RBX::Instance> i; // [rsp+10h] [rbp-28h] BYREF

  px = (boost::detail::sp_counted_base *)instance.px->weak_this_.px;
  if ( px )
  {
    use_count = px->use_count_;
    while ( use_count )
    {
      v7 = (unsigned int)(use_count + 1);
      v8 = use_count;
      use_count = _InterlockedCompareExchange(&px->use_count_, v7, use_count);
      if ( v8 == use_count )
      {
        v9 = instance.px->_vptr$EventSource;
        if ( instance.px->_vptr$EventSource )
        {
          i.px = (boost::shared_ptr<RBX::Instance>::element_type *)instance.px->_vptr$EventSource;
          i.pn.pi_ = px;
          _InterlockedAdd(&px->use_count_, 1u);
          instance.px = (boost::weak_ptr<RBX::Instance>::element_type *)&i;
          RBX::HumanoidAssetSwapper::setAppearanceParent(
            weakCharacter,
            (boost::shared_ptr<RBX::Instance>)__PAIR128__((unsigned __int64)instance.pn.pi_, &i),
            v7);
          if ( !_InterlockedSub(&px->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 2))(px);
            if ( !_InterlockedSub(&px->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 3))(px);
          }
          if ( *(_QWORD *)(assetId + 32) )
          {
            v13 = v9;
            v14 = (volatile signed __int32 *)px;
            _InterlockedAdd(&px->use_count_, 1u);
            v10 = *(_QWORD *)(assetId + 32);
            if ( !v10 )
            {
              exception = __cxa_allocate_exception(8u);
              *exception = off_28852C8;
              __cxa_throw(
                exception,
                (struct type_info *)&`typeinfo for'std::bad_function_call,
                (void (*)(void *))&std::exception::~exception);
            }
            instance.px = (boost::weak_ptr<RBX::Instance>::element_type *)&v13;
            (*(void (__fastcall **)(__int64, int (***)(void)))(*(_QWORD *)v10 + 48LL))(v10, &v13);
            v11 = v14;
            if ( v14 )
            {
              if ( !_InterlockedSub(v14 + 2, 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
                if ( !_InterlockedSub(v11 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
              }
            }
          }
        }
        if ( !_InterlockedSub(&px->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::weak_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *, int64_t, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))px->_vptr$sp_counted_base
           + 2))(
            px,
            instance.px,
            instance.pn.pi_,
            v7,
            callbackForInstanceApplied);
          if ( !_InterlockedSub(&px->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 3))(px);
        }
        return;
      }
    }
  }
}


// Address: 0x10d4d80 | Name: _ZN3RBXL26setAnimationParentInternalERKN5boost8weak_ptrINS_13ModelInstanceEEENS1_INS_8InstanceEEElRKNSt3__18functionIFvNS0_10shared_ptrIS6_EEEEE
void __fastcall RBX::setAnimationParentInternal(
        const boost::weak_ptr<RBX::ModelInstance> *weakCharacter,
        boost::weak_ptr<RBX::Instance> instance,
        int64_t assetId,
        const std::function<void (boost::shared_ptr<RBX::Instance>)> *callbackForInstanceApplied)
{
  boost::detail::sp_counted_base *px; // rbx
  signed __int32 use_count; // eax
  int64_t v7; // rcx
  signed __int32 v8; // ett
  int (**v9)(void); // r15
  __int64 v10; // rdi
  volatile signed __int32 *v11; // r14
  _QWORD *exception; // rax
  int (**v13)(void); // [rsp+0h] [rbp-38h] BYREF
  volatile signed __int32 *v14; // [rsp+8h] [rbp-30h]
  boost::shared_ptr<RBX::Instance> i; // [rsp+10h] [rbp-28h] BYREF

  px = (boost::detail::sp_counted_base *)instance.px->weak_this_.px;
  if ( px )
  {
    use_count = px->use_count_;
    while ( use_count )
    {
      v7 = (unsigned int)(use_count + 1);
      v8 = use_count;
      use_count = _InterlockedCompareExchange(&px->use_count_, v7, use_count);
      if ( v8 == use_count )
      {
        v9 = instance.px->_vptr$EventSource;
        if ( instance.px->_vptr$EventSource )
        {
          i.px = (boost::shared_ptr<RBX::Instance>::element_type *)instance.px->_vptr$EventSource;
          i.pn.pi_ = px;
          _InterlockedAdd(&px->use_count_, 1u);
          instance.px = (boost::weak_ptr<RBX::Instance>::element_type *)&i;
          RBX::HumanoidAssetSwapper::setAnimationParent(
            weakCharacter,
            (boost::shared_ptr<RBX::Instance>)__PAIR128__((unsigned __int64)instance.pn.pi_, &i),
            v7);
          if ( !_InterlockedSub(&px->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 2))(px);
            if ( !_InterlockedSub(&px->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 3))(px);
          }
          if ( *(_QWORD *)(assetId + 32) )
          {
            v13 = v9;
            v14 = (volatile signed __int32 *)px;
            _InterlockedAdd(&px->use_count_, 1u);
            v10 = *(_QWORD *)(assetId + 32);
            if ( !v10 )
            {
              exception = __cxa_allocate_exception(8u);
              *exception = off_28852C8;
              __cxa_throw(
                exception,
                (struct type_info *)&`typeinfo for'std::bad_function_call,
                (void (*)(void *))&std::exception::~exception);
            }
            instance.px = (boost::weak_ptr<RBX::Instance>::element_type *)&v13;
            (*(void (__fastcall **)(__int64, int (***)(void)))(*(_QWORD *)v10 + 48LL))(v10, &v13);
            v11 = v14;
            if ( v14 )
            {
              if ( !_InterlockedSub(v14 + 2, 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
                if ( !_InterlockedSub(v11 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
              }
            }
          }
        }
        if ( !_InterlockedSub(&px->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::weak_ptr<RBX::Instance>::element_type *, boost::detail::sp_counted_base *, int64_t, const std::function<void (boost::shared_ptr<RBX::Instance>)> *))px->_vptr$sp_counted_base
           + 2))(
            px,
            instance.px,
            instance.pn.pi_,
            v7,
            callbackForInstanceApplied);
          if ( !_InterlockedSub(&px->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 3))(px);
        }
        return;
      }
    }
  }
}


// Address: 0x10d7250 | Name: _GLOBAL__sub_I_HumanoidAssetSwapper.cpp
void __cdecl GLOBAL__sub_I_HumanoidAssetSwapper_cpp()
{
  qword_2A08BB8 = (__int64)boost::system::generic_category();
  qword_2A08BC0 = (__int64)boost::system::generic_category();
  qword_2A08BC8 = (__int64)boost::system::system_category();
  stru_2A08BD0.value = 0;
  stru_2A08BD0.name = "AllowAnimateScripts";
  dword_2A08BE0 = FLog::RegisterFlag("AllowAnimateScripts", &stru_2A08BD0, FastVarType::FASTVARTYPE_DYNAMIC);
}


