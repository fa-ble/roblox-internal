// Address: 0x10e55f0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN7PhysicsE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Physics *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08DE8;
  if ( !qword_2A08DE8 )
  {
    result = RBX::Name::declare("Physics");
    qword_2A08DE8 = result;
  }
  return result;
}


// Address: 0x10e5620 | Name: _ZNK3RBX5HUMAN7Physics7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Physics::getName(const RBX::HUMAN::Physics *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08DE8;
  if ( !qword_2A08DE8 )
  {
    result = RBX::Name::declare("Physics");
    qword_2A08DE8 = result;
  }
  return result;
}


// Address: 0x10e5650 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN11FallingDownE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::FallingDown *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08DF0;
  if ( !qword_2A08DF0 )
  {
    result = RBX::Name::declare("FallingDown");
    qword_2A08DF0 = result;
  }
  return result;
}


// Address: 0x10e5680 | Name: _ZNK3RBX5HUMAN11FallingDown7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::FallingDown::getName(const RBX::HUMAN::FallingDown *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08DF0;
  if ( !qword_2A08DF0 )
  {
    result = RBX::Name::declare("FallingDown");
    qword_2A08DF0 = result;
  }
  return result;
}


// Address: 0x10e56b0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN4DeadE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Dead *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08DF8;
  if ( !qword_2A08DF8 )
  {
    result = RBX::Name::declare("Dead");
    qword_2A08DF8 = result;
  }
  return result;
}


// Address: 0x10e56e0 | Name: _ZNK3RBX5HUMAN4Dead7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Dead::getName(const RBX::HUMAN::Dead *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08DF8;
  if ( !qword_2A08DF8 )
  {
    result = RBX::Name::declare("Dead");
    qword_2A08DF8 = result;
  }
  return result;
}


// Address: 0x10e5710 | Name: _ZN3RBX5HUMAN4DeadC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Dead::Dead(
        RBX::HUMAN::Dead *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  float v3; // xmm1_4
  RBX::PartInstance *TorsoSlow; // rbx

  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895560;
  if ( stru_2A050E0.value )
  {
    if ( humanoid )
    {
      if ( *((_BYTE *)humanoid + 733) )
      {
        TorsoSlow = RBX::Humanoid::getTorsoSlow(humanoid);
        if ( TorsoSlow )
        {
LABEL_8:
          (*((void (__fastcall **)(RBX::PartInstance *, __int64))TorsoSlow->_vptr$EventSource + 69))(TorsoSlow, 1);
          RBX::Primitive::setMassInertia(TorsoSlow->primitive.px, v3);
        }
      }
    }
  }
  else if ( humanoid )
  {
    TorsoSlow = RBX::Humanoid::getTorsoSlow(humanoid);
    if ( TorsoSlow )
      goto LABEL_8;
  }
}


// Address: 0x10e57e0 | Name: _ZN3RBX5HUMAN4Dead10onStepImplEv
void __fastcall RBX::HUMAN::Dead::onStepImpl(RBX::HUMAN::Dead *this)
{
  float v1; // xmm1_4
  const RBX::Instance *HumanoidConst; // rax
  RBX::Humanoid *v3; // rax

  HumanoidConst = (const RBX::Instance *)RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  if ( RBX::Players::backendProcessing(HumanoidConst, 0) )
  {
    v3 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    RBX::Humanoid::setHealth(v3, (__m128i)0LL, v1);
  }
}


// Address: 0x10e5810 | Name: _ZN3RBX5HUMAN4Dead19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::Dead::onSimulatorStepImpl(RBX::HUMAN::Dead *this, double a2, float stepDt)
{
  const RBX::Humanoid *HumanoidConst; // rax
  RBX::Humanoid *v4; // rax
  RBX::ModelInstance *CharacterFromHumanoid; // rax

  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  if ( RBX::Humanoid::shouldBreakCharacter(HumanoidConst) )
  {
    v4 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    CharacterFromHumanoid = RBX::Humanoid::getCharacterFromHumanoid(v4);
    if ( CharacterFromHumanoid )
      RBX::ModelInstance::breakJoints(CharacterFromHumanoid);
  }
}


// Address: 0x10e5850 | Name: _ZN3RBX5HUMAN11FallingDownC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::FallingDown::FallingDown(
        RBX::HUMAN::FallingDown *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_28955F8;
  *((_DWORD *)this + 4) = 1077936128;
}


// Address: 0x10e5870 | Name: _ZN3RBX5HUMAN7PhysicsC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Physics::Physics(
        RBX::HUMAN::Physics *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895690;
}


// Address: 0x10e59e0 | Name: _GLOBAL__sub_I_FallingDown.cpp
void __cdecl GLOBAL__sub_I_FallingDown_cpp()
{
  qword_2A08DD0 = (__int64)boost::system::generic_category();
  qword_2A08DD8 = (__int64)boost::system::generic_category();
  qword_2A08DE0 = (__int64)boost::system::system_category();
}


