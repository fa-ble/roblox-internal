// Address: 0x10ecbb0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN16RunningNoPhysicsE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::RunningNoPhysics *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08FD0;
  if ( !qword_2A08FD0 )
  {
    result = RBX::Name::declare("RunningNoPhysics");
    qword_2A08FD0 = result;
  }
  return result;
}


// Address: 0x10ecbe0 | Name: _ZNK3RBX5HUMAN16RunningNoPhysics7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::RunningNoPhysics::getName(const RBX::HUMAN::RunningNoPhysics *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08FD0;
  if ( !qword_2A08FD0 )
  {
    result = RBX::Name::declare("RunningNoPhysics");
    qword_2A08FD0 = result;
  }
  return result;
}


// Address: 0x10ecc10 | Name: _ZN3RBX5HUMAN16RunningNoPhysicsC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::RunningNoPhysics::RunningNoPhysics(
        RBX::HUMAN::RunningNoPhysics *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  __m128 v3; // xmm0
  __m128 v4; // xmm0
  double v5; // xmm1_8
  G3D::Vector3 v6; // [rsp+8h] [rbp-20h] BYREF
  RBX::Vector3 RelativeMovementVelocity; // 0:kr00_12.12

  RBX::HUMAN::MovingNoPhysicsBase::MovingNoPhysicsBase(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895FB0;
  RelativeMovementVelocity = RBX::HUMAN::HumanoidState::getRelativeMovementVelocity(this);
  v3.m128_i32[0] = LODWORD(RelativeMovementVelocity.x);
  v3.m128_i32[1] = LODWORD(RelativeMovementVelocity.y);
  _mm_storel_ps((double *)&v6.x, v3);
  v6.z = RelativeMovementVelocity.z;
  *(G3D::Vector2 *)v3.m128_f32 = G3D::Vector3::xz(&v6);
  v4 = _mm_mul_ps(v3, v3);
  *(_QWORD *)&v5 = _mm_shuffle_ps(v4, v4, 229).m128_u64[0];
  *(float *)&v5 = *(float *)&v5 + v4.m128_f32[0];
  rbx::signal<void ()(float)>::operator()((rbx::signal<void (float)> *)humanoid + 329, fsqrt(*(float *)&v5), v5);
}


// Address: 0x10ecce0 | Name: _GLOBAL__sub_I_RunningNoPhysics.cpp
void __cdecl GLOBAL__sub_I_RunningNoPhysics_cpp()
{
  qword_2A08FB8 = (__int64)boost::system::generic_category();
  qword_2A08FC0 = (__int64)boost::system::generic_category();
  qword_2A08FC8 = (__int64)boost::system::system_category();
}


