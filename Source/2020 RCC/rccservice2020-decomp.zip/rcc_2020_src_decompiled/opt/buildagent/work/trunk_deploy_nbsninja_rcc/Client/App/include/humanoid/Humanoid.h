// Address: 0x106e280 | Name: _ZNK3RBX8Humanoid17getTorsoDangerousEv
RBX::PartInstance *__fastcall RBX::Humanoid::getTorsoDangerous(const RBX::Humanoid *this)
{
  int v1; // ecx
  __int64 v2; // rdx
  RBX::PartInstance *result; // rax

  v1 = *((_DWORD *)this + 177);
  v2 = 1384;
  if ( !v1 )
    v2 = 1032;
  result = *(RBX::PartInstance **)((char *)this + v2);
  if ( !result )
    return (RBX::PartInstance *)*((_QWORD *)this + 4 * (v1 != 0) + 141);
  return result;
}


// Address: 0x106e2d0 | Name: _ZNK3RBX8Humanoid19getLeftLegDangerousEv
RBX::PartInstance *__fastcall RBX::Humanoid::getLeftLegDangerous(const RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1224;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1112;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x106e300 | Name: _ZNK3RBX8Humanoid20getRightLegDangerousEv
RBX::PartInstance *__fastcall RBX::Humanoid::getRightLegDangerous(const RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1272;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1096;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x10779c0 | Name: _ZN3RBX8Humanoid12getTorsoFastEv
RBX::PartInstance *__fastcall RBX::Humanoid::getTorsoFast(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1384;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1032;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x1078500 | Name: _ZN3RBX8Humanoid12getTorsoSlowEv
RBX::PartInstance *__fastcall RBX::Humanoid::getTorsoSlow(RBX::Humanoid *this)
{
  int v1; // ecx
  __int64 v2; // rdx
  RBX::PartInstance *result; // rax

  v1 = *((_DWORD *)this + 177);
  v2 = 1384;
  if ( !v1 )
    v2 = 1032;
  result = *(RBX::PartInstance **)((char *)this + v2);
  if ( !result )
    return (RBX::PartInstance *)*((_QWORD *)this + 4 * (v1 != 0) + 141);
  return result;
}


// Address: 0x1078a30 | Name: _ZN3RBX8Humanoid15getRightArmSlowEv
RBX::PartInstance *__fastcall RBX::Humanoid::getRightArmSlow(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1368;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1064;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x108d9d0 | Name: _ZN3RBX8Humanoid11getHeadSlowEv
RBX::PartInstance *__fastcall RBX::Humanoid::getHeadSlow(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1144;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1048;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x108d9f0 | Name: _ZN3RBX8Humanoid16getAppendageSlowENS0_13AppendageTypeE
RBX::PartInstance *__fastcall RBX::Humanoid::getAppendageSlow(
        RBX::Humanoid *this,
        RBX::Humanoid::AppendageType appendage)
{
  __int64 v2; // rax

  if ( !*((_DWORD *)this + 177) )
    return (RBX::PartInstance *)*((_QWORD *)this + 2 * (unsigned int)appendage + 129);
  if ( (unsigned int)appendage > RBX::Humanoid::AppendageType::VISIBLE_TORSO )
    v2 = 15;
  else
    v2 = qword_4AA670[appendage];
  return (RBX::PartInstance *)*((_QWORD *)this + 2 * v2 + 143);
}


// Address: 0x108da40 | Name: _ZN3RBX8Humanoid14getLeftArmSlowEv
RBX::PartInstance *__fastcall RBX::Humanoid::getLeftArmSlow(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1320;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1080;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x108da60 | Name: _ZN3RBX8Humanoid15getRightLegSlowEv
RBX::PartInstance *__fastcall RBX::Humanoid::getRightLegSlow(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1272;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1096;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x108da80 | Name: _ZN3RBX8Humanoid14getLeftLegSlowEv
RBX::PartInstance *__fastcall RBX::Humanoid::getLeftLegSlow(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1224;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1112;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x108f060 | Name: _ZNK3RBX8Humanoid12getTorsoSlowEv
const RBX::PartInstance *__fastcall RBX::Humanoid::getTorsoSlow(const RBX::Humanoid *this)
{
  int v1; // ecx
  __int64 v2; // rdx
  const RBX::PartInstance *result; // rax

  v1 = *((_DWORD *)this + 177);
  v2 = 1384;
  if ( !v1 )
    v2 = 1032;
  result = *(const RBX::PartInstance **)((char *)this + v2);
  if ( !result )
    return (const RBX::PartInstance *)*((_QWORD *)this + 4 * (v1 != 0) + 141);
  return result;
}


// Address: 0x1090300 | Name: _ZN3RBX8Humanoid19getVisibleTorsoFastEv
RBX::PartInstance *__fastcall RBX::Humanoid::getVisibleTorsoFast(RBX::Humanoid *this)
{
  return (RBX::PartInstance *)*((_QWORD *)this + 4 * (*((_DWORD *)this + 177) != 0) + 141);
}


// Address: 0x1090320 | Name: _ZNK3RBX8Humanoid21getConstAppendageSlowENS0_13AppendageTypeE
const RBX::PartInstance *__fastcall RBX::Humanoid::getConstAppendageSlow(
        const RBX::Humanoid *this,
        RBX::Humanoid::AppendageType appendage)
{
  __int64 v2; // rax

  if ( !*((_DWORD *)this + 177) )
    return (const RBX::PartInstance *)*((_QWORD *)this + 2 * (unsigned int)appendage + 129);
  if ( (unsigned int)appendage > RBX::Humanoid::AppendageType::VISIBLE_TORSO )
    v2 = 15;
  else
    v2 = qword_4AA670[appendage];
  return (const RBX::PartInstance *)*((_QWORD *)this + 2 * v2 + 143);
}


// Address: 0x10903b0 | Name: _ZN3RBX8Humanoid16getAppendageFastENS0_13AppendageTypeE
RBX::PartInstance *__fastcall RBX::Humanoid::getAppendageFast(
        RBX::Humanoid *this,
        RBX::Humanoid::AppendageType appendage)
{
  __int64 v2; // rax

  if ( !*((_DWORD *)this + 177) )
    return (RBX::PartInstance *)*((_QWORD *)this + 2 * (unsigned int)appendage + 129);
  if ( (unsigned int)appendage > RBX::Humanoid::AppendageType::VISIBLE_TORSO )
    v2 = 15;
  else
    v2 = qword_4AA670[appendage];
  return (RBX::PartInstance *)*((_QWORD *)this + 2 * v2 + 143);
}


// Address: 0x1090660 | Name: _ZNK3RBX8Humanoid14getLeftLegSlowEv
const RBX::PartInstance *__fastcall RBX::Humanoid::getLeftLegSlow(const RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1224;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1112;
  return *(const RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x1090680 | Name: _ZNK3RBX8Humanoid15getRightLegSlowEv
const RBX::PartInstance *__fastcall RBX::Humanoid::getRightLegSlow(const RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1272;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1096;
  return *(const RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x10906a0 | Name: _ZN3RBX8Humanoid19getVisibleTorsoSlowEv
RBX::PartInstance *__fastcall RBX::Humanoid::getVisibleTorsoSlow(RBX::Humanoid *this)
{
  return (RBX::PartInstance *)*((_QWORD *)this + 4 * (*((_DWORD *)this + 177) != 0) + 141);
}


// Address: 0x10906c0 | Name: _ZNK3RBX8Humanoid19getVisibleTorsoSlowEv
const RBX::PartInstance *__fastcall RBX::Humanoid::getVisibleTorsoSlow(const RBX::Humanoid *this)
{
  return (const RBX::PartInstance *)*((_QWORD *)this + 4 * (*((_DWORD *)this + 177) != 0) + 141);
}


// Address: 0x10906e0 | Name: _ZNK3RBX8Humanoid11getHeadSlowEv
const RBX::PartInstance *__fastcall RBX::Humanoid::getHeadSlow(const RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1144;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1048;
  return *(const RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x1090700 | Name: _ZNK3RBX8Humanoid15getRightArmSlowEv
const RBX::PartInstance *__fastcall RBX::Humanoid::getRightArmSlow(const RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1368;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1064;
  return *(const RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x1090720 | Name: _ZNK3RBX8Humanoid14getLeftArmSlowEv
const RBX::PartInstance *__fastcall RBX::Humanoid::getLeftArmSlow(const RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1320;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1080;
  return *(const RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x1090740 | Name: _ZN3RBX8Humanoid11getHeadFastEv
RBX::PartInstance *__fastcall RBX::Humanoid::getHeadFast(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1144;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1048;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x1090760 | Name: _ZN3RBX8Humanoid15getRightArmFastEv
RBX::PartInstance *__fastcall RBX::Humanoid::getRightArmFast(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1368;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1064;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x1090780 | Name: _ZN3RBX8Humanoid14getLeftArmFastEv
RBX::PartInstance *__fastcall RBX::Humanoid::getLeftArmFast(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1320;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1080;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x10907a0 | Name: _ZN3RBX8Humanoid15getRightLegFastEv
RBX::PartInstance *__fastcall RBX::Humanoid::getRightLegFast(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1272;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1096;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x10907c0 | Name: _ZN3RBX8Humanoid14getLeftLegFastEv
RBX::PartInstance *__fastcall RBX::Humanoid::getLeftLegFast(RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1224;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1112;
  return *(RBX::PartInstance **)((char *)this + v1);
}


// Address: 0x1090940 | Name: _ZN3RBX8Humanoid21getTorsoPrimitiveSlowEv
RBX::Primitive *__fastcall RBX::Humanoid::getTorsoPrimitiveSlow(RBX::Humanoid *this)
{
  int v1; // eax
  __int64 v2; // rdx
  __int64 v3; // rcx

  v1 = *((_DWORD *)this + 177);
  v2 = 1384;
  if ( !v1 )
    v2 = 1032;
  v3 = *(_QWORD *)((char *)this + v2);
  if ( v3 )
    return *(RBX::Primitive **)(v3 + 232);
  v3 = *((_QWORD *)this + 4 * (v1 != 0) + 141);
  if ( v3 )
    return *(RBX::Primitive **)(v3 + 232);
  else
    return 0;
}


// Address: 0x1090990 | Name: _ZN3RBX8Humanoid20getHeadPrimitiveSlowEv
RBX::Primitive *__fastcall RBX::Humanoid::getHeadPrimitiveSlow(RBX::Humanoid *this)
{
  __int64 v1; // rcx
  __int64 v2; // rax

  v1 = 1144;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1048;
  v2 = *(_QWORD *)((char *)this + v1);
  if ( v2 )
    return *(RBX::Primitive **)(v2 + 232);
  else
    return 0;
}


// Address: 0x10a2e90 | Name: _ZNK3RBX8Humanoid18getAutoJumpEnabledEv
bool __fastcall RBX::Humanoid::getAutoJumpEnabled(const RBX::Humanoid *this)
{
  return *((_BYTE *)this + 732);
}


// Address: 0x10a3000 | Name: _ZNK3RBX8Humanoid15getUseJumpPowerEv
bool __fastcall RBX::Humanoid::getUseJumpPower(const RBX::Humanoid *this)
{
  return *((_BYTE *)this + 664);
}


// Address: 0x10a3050 | Name: _ZNK3RBX8Humanoid12getBodyScaleEv
RBX::Vector3 __fastcall RBX::Humanoid::getBodyScale(const RBX::Humanoid *this)
{
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.x = *((_QWORD *)this + 126);
  result.z = *((float *)this + 254);
  return result;
}


// Address: 0x10a30a0 | Name: _ZNK3RBX8Humanoid12getHeadScaleEv
float __fastcall RBX::Humanoid::getHeadScale(const RBX::Humanoid *this)
{
  return *((float *)this + 255);
}


// Address: 0x10a30b0 | Name: _ZNK3RBX8Humanoid20getOriginalHipHeightEv
float __fastcall RBX::Humanoid::getOriginalHipHeight(const RBX::Humanoid *this)
{
  return *((float *)this + 256);
}


// Address: 0x10a31f0 | Name: _ZNK3RBX8Humanoid19getLuaMoveDirectionEv
RBX::Vector3 __fastcall RBX::Humanoid::getLuaMoveDirection(const RBX::Humanoid *this)
{
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.x = *((_QWORD *)this + 69);
  result.z = *((float *)this + 140);
  return result;
}


// Address: 0x10a3220 | Name: _ZNK3RBX8Humanoid14getWalkToPointEv
const RBX::Vector3 *__fastcall RBX::Humanoid::getWalkToPoint(const RBX::Humanoid *this)
{
  return (const RBX::Vector3 *)((char *)this + 528);
}


// Address: 0x10a3380 | Name: _ZNK3RBX8Humanoid14getTargetPointEv
const RBX::Vector3 *__fastcall RBX::Humanoid::getTargetPoint(const RBX::Humanoid *this)
{
  return (const RBX::Vector3 *)((char *)this + 576);
}


// Address: 0x10a33d0 | Name: _ZNK3RBX8Humanoid21getBreakJointsOnDeathEv
bool __fastcall RBX::Humanoid::getBreakJointsOnDeath(const RBX::Humanoid *this)
{
  return *((_BYTE *)this + 733);
}


// Address: 0x10a33e0 | Name: _ZNK3RBX8Humanoid16getFloorMaterialEv
RBX::PartMaterial __fastcall RBX::Humanoid::getFloorMaterial(const RBX::Humanoid *this)
{
  return *((_DWORD *)this + 234);
}


// Address: 0x10a3800 | Name: _ZNK3RBX8Humanoid16getWalkDirectionEv
RBX::Vector3 __fastcall RBX::Humanoid::getWalkDirection(const RBX::Humanoid *this)
{
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.x = *(_QWORD *)((char *)this + 540);
  result.z = *((float *)this + 137);
  return result;
}


// Address: 0x10a3970 | Name: _ZNK3RBX8Humanoid17getWalkAngleErrorEv
float __fastcall RBX::Humanoid::getWalkAngleError(const RBX::Humanoid *this)
{
  return *((float *)this + 150);
}


// Address: 0x10a3990 | Name: _ZNK3RBX8Humanoid10getRigTypeEv
RBX::HumanoidRigType __fastcall RBX::Humanoid::getRigType(const RBX::Humanoid *this)
{
  return *((_DWORD *)this + 177);
}


// Address: 0x10a3c70 | Name: _ZNK3RBX8Humanoid16getCamearaOffsetEv
const RBX::Vector3 *__fastcall RBX::Humanoid::getCamearaOffset(const RBX::Humanoid *this)
{
  return (const RBX::Vector3 *)((char *)this + 780);
}


// Address: 0x10a3ec0 | Name: _ZNK3RBX8Humanoid16getCollisionTypeEv
RBX::Humanoid::CollisionType __fastcall RBX::Humanoid::getCollisionType(const RBX::Humanoid *this)
{
  return *((_DWORD *)this + 182);
}


// Address: 0x10a4060 | Name: _ZN3RBX8Humanoid21setClickToWalkEnabledEb
void __fastcall RBX::Humanoid::setClickToWalkEnabled(RBX::Humanoid *this, bool value)
{
  *((_BYTE *)this + 856) = value;
}


// Address: 0x10a4680 | Name: _ZNK3RBX8Humanoid16getNameOcclusionEv
RBX::Humanoid::NameOcclusion __fastcall RBX::Humanoid::getNameOcclusion(const RBX::Humanoid *this)
{
  return *((_DWORD *)this + 190);
}


// Address: 0x10a47f0 | Name: _ZNK3RBX8Humanoid22getDisplayDistanceTypeEv
RBX::Humanoid::HumanoidDisplayDistanceType __fastcall RBX::Humanoid::getDisplayDistanceType(const RBX::Humanoid *this)
{
  return *((_DWORD *)this + 191);
}


// Address: 0x10a4960 | Name: _ZNK3RBX8Humanoid20getHealthDisplayTypeEv
RBX::Humanoid::HumanoidHealthDisplayType __fastcall RBX::Humanoid::getHealthDisplayType(const RBX::Humanoid *this)
{
  return *((_DWORD *)this + 192);
}


// Address: 0x10a4ad0 | Name: _ZNK3RBX8Humanoid22getNameDisplayDistanceEv
float __fastcall RBX::Humanoid::getNameDisplayDistance(const RBX::Humanoid *this)
{
  return *((float *)this + 193);
}


// Address: 0x10a4ae0 | Name: _ZNK3RBX8Humanoid24getHealthDisplayDistanceEv
float __fastcall RBX::Humanoid::getHealthDisplayDistance(const RBX::Humanoid *this)
{
  return *((float *)this + 194);
}


// Address: 0x10ae040 | Name: _ZN3RBX8Humanoid17fireTouchedSignalEN5boost10shared_ptrINS_8InstanceEEES4_
void __fastcall RBX::Humanoid::fireTouchedSignal(
        RBX::Humanoid *this,
        boost::shared_ptr<RBX::Instance> touchingPart,
        boost::shared_ptr<RBX::Instance> hPart)
{
  boost::detail::sp_counted_base *px; // rax
  rbx::signal<void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>)> *v4; // rdi
  volatile signed __int32 *v5; // rax
  volatile signed __int32 *v6; // rbx
  boost::detail::sp_counted_base *pi; // rbx
  int (**args)(void); // [rsp+8h] [rbp-30h] BYREF
  volatile signed __int32 *v9; // [rsp+10h] [rbp-28h]
  boost::shared_ptr<RBX::Instance> v10; // [rsp+18h] [rbp-20h] BYREF

  v10.px = (boost::shared_ptr<RBX::Instance>::element_type *)touchingPart.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)touchingPart.px->weak_this_.px;
  v10.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->use_count_, 1u);
  v4 = (rbx::signal<void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>)> *)((char *)this + 2728);
  args = touchingPart.pn.pi_->_vptr$sp_counted_base;
  v5 = *(volatile signed __int32 **)&touchingPart.pn.pi_->use_count_;
  v9 = v5;
  if ( v5 )
    _InterlockedAdd(v5 + 2, 1u);
  rbx::signal<void ()(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>)>::operator()(
    v4,
    (boost::shared_ptr<RBX::Instance>)__PAIR128__(&args, &v10),
    hPart);
  v6 = v9;
  if ( v9 )
  {
    if ( !_InterlockedSub(v9 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  pi = v10.pn.pi_;
  if ( v10.pn.pi_ && !_InterlockedSub(&v10.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10b08f0 | Name: _ZNK3RBX8Humanoid19shouldRender3dAdornEv
bool __fastcall RBX::Humanoid::shouldRender3dAdorn(const RBX::Humanoid *this)
{
  return 1;
}


// Address: 0x10b0930 | Name: _ZNK3RBX8Humanoid22getConnectorKernelTypeEv
void __fastcall RBX::Humanoid::getConnectorKernelType(const RBX::Humanoid *this)
{
  ;
}


// Address: 0x10b0940 | Name: _ZNK3RBX8Humanoid13hasFocusCoordEv
bool __fastcall RBX::Humanoid::hasFocusCoord(const RBX::Humanoid *this)
{
  __int64 v1; // rcx

  v1 = 1144;
  if ( !*((_DWORD *)this + 177) )
    v1 = 1048;
  return *(_QWORD *)((char *)this + v1) != 0;
}


// Address: 0x10b0aa0 | Name: _ZThn128_NK3RBX8Humanoid22getConnectorKernelTypeEv
void __fastcall `non-virtual thunk to'RBX::Humanoid::getConnectorKernelType(const RBX::Humanoid *this)
{
  ;
}


// Address: 0x10b0ab0 | Name: _ZThn336_NK3RBX8Humanoid22getConnectorKernelTypeEv
void __fastcall `non-virtual thunk to'RBX::Humanoid::getConnectorKernelType(const RBX::Humanoid *this)
{
  ;
}


// Address: 0x10b0b30 | Name: _ZThn400_NK3RBX8Humanoid19shouldRender3dAdornEv
void __fastcall `non-virtual thunk to'RBX::Humanoid::shouldRender3dAdorn(const RBX::Humanoid *this)
{
  ;
}


// Address: 0x10b0b80 | Name: _ZThn440_NK3RBX8Humanoid13hasFocusCoordEv
void __fastcall `non-virtual thunk to'RBX::Humanoid::hasFocusCoord(const RBX::Humanoid *this)
{
  ;
}


// Address: 0x10dabd0 | Name: _ZN3RBX21HumanoidDefaultAssets9hasCachedERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEE
bool __fastcall RBX::HumanoidDefaultAssets::hasCached(
        RBX::HumanoidDefaultAssets *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  return RBX::HumanoidDefaultAssets::hasCached(this, *((_DWORD *)humanoid + 177) != 0, parent);
}


// Address: 0x10f68b0 | Name: _ZN3RBX19HumanoidDescription16setHumanoidScaleERNS_8HumanoidE
void __fastcall RBX::HumanoidDescription::setHumanoidScale(RBX::HumanoidDescription *this, RBX::Humanoid *humanoid)
{
  float v2; // xmm3_4
  float v3; // xmm4_4
  float v4; // xmm5_4
  __m128 v5; // xmm0
  double v6; // xmm1_8
  __m128 scaleHead_low; // xmm2

  if ( *((_DWORD *)humanoid + 177) )
  {
    v5 = _mm_unpacklo_ps((__m128)LODWORD(this->scaleWidth), (__m128)LODWORD(this->scaleHeight));
    *(_QWORD *)&v6 = LODWORD(this->scaleDepth);
    scaleHead_low = (__m128)LODWORD(this->scaleHead);
    if ( stru_2A63140.value )
      RBX::Humanoid::createOrSetScaleValuesAnthro(
        humanoid,
        v5,
        *(float *)&v6,
        scaleHead_low,
        this->scaleBodyType,
        this->scaleProportion,
        v4);
    else
      RBX::Humanoid::createOrSetScaleValues(humanoid, *(double *)v5.m128_u64, v6, scaleHead_low, v2, v3);
  }
}


