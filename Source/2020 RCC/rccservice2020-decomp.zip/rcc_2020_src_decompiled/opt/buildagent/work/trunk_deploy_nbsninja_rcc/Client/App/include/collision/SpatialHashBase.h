// Address: 0x1dff300 | Name: _ZN3RBX9Collision15SpatialHashBase16MovementCallback10UpdateInfoC2Ev
void __fastcall RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateInfo(
        RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo *this)
{
  if ( !(_BYTE)byte_29FEDE8 && __cxa_guard_acquire(&byte_29FEDE8) )
  {
    *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
    *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
    __cxa_guard_release(&byte_29FEDE8);
  }
  this->oldSpatialExtents.low = *(RBX::Vector3int32 *)byte_29FEDD8;
  if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
  {
    *(_QWORD *)byte_29FEE08 = 0x8000000080000000LL;
    *(_DWORD *)&byte_29FEE08[8] = 0x80000000;
    __cxa_guard_release(&byte_29FEE18);
  }
  this->oldSpatialExtents.high = *(RBX::Vector3int32 *)byte_29FEE08;
  if ( !(_BYTE)byte_29FEDE8 && __cxa_guard_acquire(&byte_29FEDE8) )
  {
    *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
    *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
    __cxa_guard_release(&byte_29FEDE8);
  }
  this->newSpatialExtents.low = *(RBX::Vector3int32 *)byte_29FEDD8;
  if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
  {
    *(_QWORD *)byte_29FEE08 = 0x8000000080000000LL;
    *(_DWORD *)&byte_29FEE08[8] = 0x80000000;
    __cxa_guard_release(&byte_29FEE18);
  }
  this->newSpatialExtents.high = *(RBX::Vector3int32 *)byte_29FEE08;
}


