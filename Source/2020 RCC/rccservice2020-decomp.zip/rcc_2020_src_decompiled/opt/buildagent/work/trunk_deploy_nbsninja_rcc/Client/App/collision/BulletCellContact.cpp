// Address: 0x1df0c20 | Name: _ZN3RBX9Collision17BulletCellContact21getCollisionConnectorEj
RBX::CollisionConnector *__fastcall RBX::Collision::BulletCellContact::getCollisionConnector(
        RBX::Collision::BulletCellContact *this,
        unsigned int i)
{
  return this->collisionConnectors.data.elems[i];
}


// Address: 0x1df0c30 | Name: _ZN3RBX9Collision17BulletCellContact24deleteCollisionConnectorEj
void __fastcall RBX::Collision::BulletCellContact::deleteCollisionConnector(
        RBX::Collision::BulletCellContact *this,
        unsigned int i)
{
  RBX::Collision::BulletCollisionConnector *v3; // rdi
  size_t num; // rax

  RBX::Collision::BulletCollisionInterface::clearManifoldPoint(
    this->collisionConnectors.data.elems[i],
    &this->manifoldArray);
  v3 = this->collisionConnectors.data.elems[i];
  if ( v3 )
    operator delete(v3);
  num = this->collisionConnectors.num;
  this->collisionConnectors.data.elems[i] = (RBX::Collision::BulletCollisionConnector *)*((_QWORD *)&this->contactManagerTransitionIndex
                                                                                        + num);
  this->collisionConnectors.num = num - 1;
}


// Address: 0x1df0c80 | Name: _ZN3RBX9Collision17BulletCellContact18computeIsCollidingEf
__int64 __fastcall RBX::Collision::BulletCellContact::computeIsColliding(
        RBX::Collision::BulletCellContact *this,
        __m128i a2,
        float overlapIgnored)
{
  RBX::Primitive *prim0; // r15
  RBX::Primitive *prim1; // r12
  char *v6; // rax
  __m128i v7; // xmm0
  RBX::World *world; // r13
  bool v9; // al
  btManifoldArray *p_manifoldArray; // r14
  size_t i; // rbx
  bool v12; // al
  size_t num; // rax
  RBX::Collision::BulletCollisionConnector *v14; // rdi
  __m128i v15; // xmm1
  int v16; // eax
  float v18; // [rsp+Ch] [rbp-BCh]
  void *ptr[2]; // [rsp+10h] [rbp-B8h] BYREF
  char *v20; // [rsp+20h] [rbp-A8h]
  btVector3 obj1Scale; // [rsp+30h] [rbp-98h] BYREF
  __m128i distance; // [rsp+40h] [rbp-88h] BYREF
  btVector3 obj0Scale; // [rsp+50h] [rbp-78h] BYREF
  btManifoldResult resultOut; // [rsp+68h] [rbp-60h] BYREF

  distance = a2;
  prim0 = this->prim0;
  prim1 = this->prim1;
  RBX::Primitive::updateBulletCollisionObject(prim1);
  v6 = (char *)operator new(0x20u);
  v7 = _mm_shuffle_epi32((__m128i)(unsigned __int64)v6, 68);
  *(__m128i *)ptr = v7;
  v20 = v6 + 32;
  resultOut._vptr$Result = (int (**)(void))&off_299AC68;
  world = this->world;
  if ( stru_2AAF458.value )
  {
    v9 = RBX::Collision::Contact::getInContact(this);
    p_manifoldArray = &this->manifoldArray;
    i = *(_QWORD *)(*((_QWORD *)prim1 + 18) + 24LL);
    v7 = 0;
    obj0Scale = 0;
    obj1Scale.m_floats[0] = this->bScale.x;
    obj1Scale.m_floats[1] = this->bScale.y;
    obj1Scale.m_floats[2] = this->bScale.z;
    obj1Scale.m_floats[3] = 0.0;
    RBX::Collision::BulletCollisionInterface::computeManifolds(
      world,
      v9,
      &this->algorithm,
      &this->manifoldArray,
      &resultOut,
      &this->cellCollisionObject,
      (btCollisionObject *)i,
      &obj0Scale,
      &obj1Scale,
      0,
      this->bBoxSet.bvh);
  }
  else
  {
    v12 = RBX::Collision::Contact::getInContact(this);
    p_manifoldArray = &this->manifoldArray;
    i = *((_QWORD *)prim1 + 18);
    RBX::Collision::BulletCollisionInterface::computeManifolds(
      world,
      v12,
      &this->algorithm,
      &this->manifoldArray,
      &resultOut,
      &this->cellCollisionObject,
      *(btCollisionObject **)(i + 24));
  }
  RBX::Collision::BulletCollisionInterface::matchCollisionConnectors(
    this->world,
    p_manifoldArray,
    &this->collisionConnectors,
    (std::vector<unsigned long> *)ptr);
  RBX::Collision::BulletCollisionInterface::createCollisionConnectors(
    p_manifoldArray,
    &this->collisionConnectors,
    prim0,
    prim1,
    (std::vector<unsigned long> *)ptr);
  *(float *)v7.m128i_i32 = RBX::Collision::BulletCollisionInterface::updateContactPoints(
                             p_manifoldArray,
                             &this->collisionConnectors,
                             &this->cellCollisionObject);
  v18 = COERCE_FLOAT(_mm_cvtsi128_si32(v7));
  num = this->collisionConnectors.num;
  if ( num )
  {
    for ( i = 0; i < num; ++i )
    {
      v14 = this->collisionConnectors.data.elems[i];
      if ( !stru_2AAF230.value || v14->bulletManifoldIndex != -1 && v14->bulletPointCacheIndex != -1 )
      {
        RBX::Collision::BulletCellContact::updateCollisionContactParameters(
          v14,
          p_manifoldArray,
          &this->cellCollisionObject,
          this->prim0,
          this->prim1);
        num = this->collisionConnectors.num;
      }
    }
  }
  v15 = _mm_load_si128(&distance);
  if ( *(float *)v15.m128i_i32 >= 0.0 )
  {
    LOBYTE(i) = v18 > *(float *)v15.m128i_i32;
  }
  else
  {
    LOBYTE(v16) = RBX::Collision::BulletCollisionInterface::areContactPointsCloserThan(
                    p_manifoldArray,
                    *(float *)_mm_xor_si128(v15, *(__m128i *)&stru_3E4970.x).m128i_i32,
                    *(float *)v15.m128i_i32);
    LODWORD(i) = v16;
  }
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  return (unsigned int)i;
}


// Address: 0x1df0ee0 | Name: _ZN3RBX9Collision17BulletCellContact23updateContactParemetersEP17btCollisionObject
void __fastcall RBX::Collision::BulletCellContact::updateContactParemeters(
        RBX::Collision::BulletCellContact *this,
        btCollisionObject *cellObj)
{
  size_t num; // rax
  btManifoldArray *p_manifoldArray; // r15
  size_t i; // rbx
  RBX::Collision::BulletCollisionConnector *v6; // rdi

  num = this->collisionConnectors.num;
  if ( num )
  {
    p_manifoldArray = &this->manifoldArray;
    for ( i = 0; i < num; ++i )
    {
      v6 = this->collisionConnectors.data.elems[i];
      if ( !stru_2AAF230.value || v6->bulletManifoldIndex != -1 && v6->bulletPointCacheIndex != -1 )
      {
        RBX::Collision::BulletCellContact::updateCollisionContactParameters(
          v6,
          p_manifoldArray,
          cellObj,
          this->prim0,
          this->prim1);
        num = this->collisionConnectors.num;
      }
    }
  }
}


// Address: 0x1df0f60 | Name: _ZN3RBX9Collision17BulletCellContact32updateCollisionContactParametersEPNS0_24BulletCollisionConnectorER20btAlignedObjectArrayIP20btPersistentManifoldEP17btCollisionObjectPNS_9PrimitiveESC_
void __fastcall RBX::Collision::BulletCellContact::updateCollisionContactParameters(
        RBX::Collision::BulletCollisionConnector *conn,
        btManifoldArray *manifoldArray,
        btCollisionObject *colObj0,
        RBX::Primitive *prim0,
        RBX::Primitive *prim1)
{
  __int64 v5; // rax
  btPersistentManifold *v7; // rax
  __int64 bulletPointCacheIndex; // rcx
  bool v9; // zf
  __int64 p_m_index0; // rsi
  unsigned int *p_m_index1; // rax
  RBX::PartMaterial TriangleMaterial; // eax
  float v13; // ecx
  _QWORD v14[3]; // [rsp+0h] [rbp-18h] BYREF

  v14[0] = v5;
  if ( **((_BYTE **)prim0 + 73) )
  {
    RBX::MaterialProperties::updateFricRestPrims((float *)v14 + 1, (float *)v14, prim0, prim1);
  }
  else
  {
    v7 = manifoldArray->m_data[conn->bulletManifoldIndex];
    bulletPointCacheIndex = conn->bulletPointCacheIndex;
    v9 = v7->m_body0 == colObj0;
    p_m_index0 = (__int64)&v7->m_pointCache[bulletPointCacheIndex].m_index0;
    p_m_index1 = (unsigned int *)&v7->m_pointCache[bulletPointCacheIndex].m_index1;
    if ( v9 )
      p_m_index1 = (unsigned int *)p_m_index0;
    TriangleMaterial = RBX::SmoothClusterGeometry::getTriangleMaterial(
                         colObj0->m_collisionShape,
                         *p_m_index1,
                         &conn->contactPoint);
    RBX::MaterialProperties::updateFricRestPrimMaterial((float *)v14 + 1, (float *)v14, prim1, TriangleMaterial);
  }
  v13 = *(float *)v14;
  conn->friction = *((float *)v14 + 1);
  conn->restitution = v13;
}


// Address: 0x1df1000 | Name: _ZN3RBX9Collision17BulletCellContactC2EPNS_5WorldEPNS_9PrimitiveES5_RKNS_12Vector3int32ERKN5boost10shared_ptrI16btCollisionShapeEE
void __fastcall RBX::Collision::BulletCellContact::BulletCellContact(
        RBX::Collision::BulletCellContact *this,
        RBX::World *world,
        RBX::Primitive *p0,
        RBX::Primitive *p1,
        const RBX::Vector3int32 *feature,
        const boost::shared_ptr<btCollisionShape> *cellShape)
{
  boost::detail::sp_counted_base *pi; // rax
  btCollisionShape *px; // rax
  __int64 v12; // rcx
  const btGImpactConvexDecompositionShape *v13; // rdi
  _QWORD v14[11]; // [rsp+0h] [rbp-58h] BYREF

  v14[5] = __readfsqword(0x28u);
  RBX::Collision::Contact::Contact(this, p0, p1);
  this->_vptr$Contact = (int (**)(void))&off_299E2B0;
  this->collisionConnectors.num = 0;
  this->world = world;
  this->algorithm = 0;
  this->bBoxSet.key = -1;
  *(_OWORD *)&this->bBoxSet.bvh = 0;
  this->bScale.z = 0.0;
  this->manifoldArray.m_ownsMemory = 1;
  this->manifoldArray.m_data = 0;
  *(_QWORD *)&this->manifoldArray.m_size = 0;
  btCollisionObject::btCollisionObject(&this->cellCollisionObject);
  this->cellShape.px = cellShape->px;
  pi = cellShape->pn.pi_;
  this->cellShape.pn.pi_ = pi;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  this->gridFeature = *feature;
  memset(&v14[2], 0, 20);
  this->cellCollisionObject.m_worldTransform.m_basis.m_el[0].m_floats[0] = 1.0;
  *(btVector3 *)((char *)this->cellCollisionObject.m_worldTransform.m_basis.m_el + 4) = 0;
  this->cellCollisionObject.m_worldTransform.m_basis.m_el[1].m_floats[1] = 1.0;
  *(btVector3 *)((char *)&this->cellCollisionObject.m_worldTransform.m_basis.m_el[1] + 8) = 0;
  *(_QWORD *)&this->cellCollisionObject.m_worldTransform.m_basis.m_el[2].m_floats[2] = 1065353216;
  this->cellCollisionObject.m_worldTransform.m_origin = *(btVector3 *)((char *)&v14[2] + 4);
  px = cellShape->px;
  this->cellCollisionObject.m_updateRevision += 2;
  this->cellCollisionObject.m_collisionShape = px;
  this->cellCollisionObject.m_rootCollisionShape = px;
  if ( stru_2AAF458.value && !this->bBoxSet.bvh && RBX::Primitive::getGeometryType(p1) == GEOMETRY_TRI_MESH )
  {
    v12 = *((_QWORD *)p1 + 18);
    this->bScale = *(RBX::Vector3 *)(v12 + 84);
    v13 = **(const btGImpactConvexDecompositionShape ***)(v12 + 56);
    v14[0] = *(_QWORD *)&this->bScale.x;
    v14[1] = LODWORD(this->bScale.z);
    this->bBoxSet = RBX::Collision::BulletCollisionBoxSetPool::requestBoxSet(v13, (const btVector3 *)v14);
  }
}


// Address: 0x1df1280 | Name: _ZN3RBX9Collision17BulletCellContactD2Ev
void __fastcall RBX::Collision::BulletCellContact::~BulletCellContact(RBX::Collision::BulletCellContact *this)
{
  boost::detail::sp_counted_base *pi; // r14
  btPersistentManifold **m_data; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299E2B0;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
  RBX::Collision::BulletCollisionInterface::deleteAlgorithm(this->world, this->algorithm);
  if ( stru_2AAF458.value && this->bBoxSet.bvh )
    RBX::Collision::BulletCollisionBoxSetPool::returnBoxSet(&this->bBoxSet);
  pi = this->cellShape.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  btCollisionObject::~btCollisionObject(&this->cellCollisionObject);
  m_data = this->manifoldArray.m_data;
  if ( m_data )
  {
    if ( this->manifoldArray.m_ownsMemory )
      btAlignedFreeInternal(m_data);
    this->manifoldArray.m_data = 0;
  }
  this->manifoldArray.m_ownsMemory = 1;
  this->manifoldArray.m_data = 0;
  *(_QWORD *)&this->manifoldArray.m_size = 0;
}


// Address: 0x1df1390 | Name: _ZN3RBX9Collision17BulletCellContactD0Ev
void __fastcall RBX::Collision::BulletCellContact::~BulletCellContact(RBX::Collision::BulletCellContact *this)
{
  RBX::Collision::BulletCellContact::~BulletCellContact(this);
  btAlignedFreeInternal(this);
}


// Address: 0x1df13b0 | Name: _ZN3RBX9Collision17BulletCellContact22invalidateContactCacheEv
void __fastcall RBX::Collision::BulletCellContact::invalidateContactCache(RBX::Collision::BulletCellContact *this)
{
  RBX::Collision::BulletCollisionInterface::clearCache(&this->manifoldArray);
}


// Address: 0x1df13c0 | Name: _ZN3RBX9Collision17BulletCellContact35onPrimitiveContactParamatersChangedEv
void __fastcall RBX::Collision::BulletCellContact::onPrimitiveContactParamatersChanged(
        RBX::Collision::BulletCellContact *this)
{
  ;
}


// Address: 0x1df1420 | Name: _GLOBAL__sub_I_BulletCellContact.cpp
void __cdecl GLOBAL__sub_I_BulletCellContact_cpp()
{
  qword_2AAF5A0 = (__int64)boost::system::generic_category();
  qword_2AAF5A8 = (__int64)boost::system::generic_category();
  qword_2AAF5B0 = (__int64)boost::system::system_category();
}


