// Address: 0x10e5b30 | Name: _ZN3RBX5HUMAN6FlyingD0Ev
void __fastcall RBX::HUMAN::Flying::~Flying(RBX::HUMAN::Flying *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // rdi
  void *v5; // rdi

  *(_QWORD *)this = &off_2895850;
  v2 = *((_QWORD *)this + 44);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 45);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 44);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 && !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)this + 44);
    }
    *((_QWORD *)this + 45) = v2;
    operator delete(v5);
  }
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e5bc0 | Name: _ZNK3RBX5HUMAN6Flying17armsShouldCollideEv
bool __fastcall RBX::HUMAN::Flying::armsShouldCollide(const RBX::HUMAN::Flying *this)
{
  return 1;
}


// Address: 0x10e5bd0 | Name: _ZNK3RBX5HUMAN6Flying17legsShouldCollideEv
bool __fastcall RBX::HUMAN::Flying::legsShouldCollide(const RBX::HUMAN::Flying *this)
{
  return 1;
}


// Address: 0x10e5be0 | Name: _ZNK3RBX5HUMAN6Flying14enableAutoJumpEv
bool __fastcall RBX::HUMAN::Flying::enableAutoJump(const RBX::HUMAN::Flying *this)
{
  return 0;
}


// Address: 0x10e5bf0 | Name: _ZNK3RBX5HUMAN6Flying12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::Flying::getStateType(const RBX::HUMAN::Flying *this)
{
  return RBX::HUMAN::StateType::FLYING;
}


