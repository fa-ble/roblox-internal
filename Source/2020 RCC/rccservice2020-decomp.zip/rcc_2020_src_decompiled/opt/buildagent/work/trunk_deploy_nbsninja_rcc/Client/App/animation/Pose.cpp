// Address: 0x106a120 | Name: _ZN3RBX4Pose10addSubPoseEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Pose::addSubPose(RBX::Pose *this, boost::shared_ptr<RBX::Instance> pose)
{
  if ( pose.px->_vptr$EventSource )
    RBX::Instance::setParentWithScriptSecurityChecks((RBX::Instance *)pose.px->_vptr$EventSource, this);
}


// Address: 0x106a140 | Name: _ZN3RBX4Pose13removeSubPoseEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Pose::removeSubPose(RBX::Pose *this, boost::shared_ptr<RBX::Instance> pose)
{
  int (**v3)(void); // rdi

  v3 = pose.px->_vptr$EventSource;
  if ( pose.px->_vptr$EventSource )
  {
    if ( (char *)v3[11] == (char *)this )
      RBX::Instance::setParentWithScriptSecurityChecks((RBX::Instance *)v3, 0);
  }
}


// Address: 0x106a160 | Name: _ZN3RBX4Pose18setCoordinateFrameERKN3G3D15CoordinateFrameE
void __fastcall RBX::Pose::setCoordinateFrame(RBX::Pose *this, const RBX::CoordinateFrame *value)
{
  RBX::Pose *v2; // r12
  __int128 v3; // xmm0
  RBX::Keyframe *parent; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v7; // rbx
  RBX::Reflection::ClassDescriptor *v8; // rax

  v2 = this;
  if ( this->coordinateFrame.translation.x != value->translation.x
    || this->coordinateFrame.translation.y != value->translation.y
    || this->coordinateFrame.translation.z != value->translation.z
    || !G3D::Matrix3::operator==(&this->coordinateFrame.rotation, &value->rotation) )
  {
    this->coordinateFrame.rotation.elt[2][2] = value->rotation.elt[2][2];
    v3 = *(_OWORD *)&value->rotation.elt[0][0];
    *(_OWORD *)&this->coordinateFrame.rotation.elt[1][1] = *(_OWORD *)&value->rotation.elt[1][1];
    *(_OWORD *)&this->coordinateFrame.rotation.elt[0][0] = v3;
    this->coordinateFrame.translation = value->translation;
    RBX::Instance::raisePropertyChanged(this, &stru_2A044D0);
    while ( 1 )
    {
      parent = (RBX::Keyframe *)v2->parent;
      if ( !parent )
        break;
      descriptor = parent->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        RBX::Keyframe::invalidate(parent);
        return;
      }
      v2 = (RBX::Pose *)v2->parent;
      if ( v2 )
      {
        v7 = v2->descriptor;
        v8 = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)v7 + 363) - (unsigned int)*((unsigned __int16 *)v8 + 363) <= *((unsigned __int16 *)v8
                                                                                                + 364) )
          continue;
      }
      return;
    }
  }
}


// Address: 0x106a280 | Name: _ZN3RBX4Pose9setWeightEf
void __fastcall RBX::Pose::setWeight(RBX::Pose *this, float a2, float value)
{
  RBX::Pose *v3; // r14
  RBX::Keyframe *parent; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v7; // rbx
  RBX::Reflection::ClassDescriptor *v8; // rax

  if ( this->weight != a2 )
  {
    v3 = this;
    this->weight = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A04528);
    while ( 1 )
    {
      parent = (RBX::Keyframe *)v3->parent;
      if ( !parent )
        break;
      descriptor = parent->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        RBX::Keyframe::invalidate(parent);
        return;
      }
      v3 = (RBX::Pose *)v3->parent;
      if ( v3 )
      {
        v7 = v3->descriptor;
        v8 = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)v7 + 363) - (unsigned int)*((unsigned __int16 *)v8 + 363) <= *((unsigned __int16 *)v8
                                                                                                + 364) )
          continue;
      }
      return;
    }
  }
}


// Address: 0x106a320 | Name: _ZNK3RBX4Pose13getMaskWeightEv
float __fastcall RBX::Pose::getMaskWeight(const RBX::Pose *this)
{
  return 0.0;
}


// Address: 0x106a330 | Name: _ZN3RBX4Pose13setMaskWeightEf
void __fastcall RBX::Pose::setMaskWeight(RBX::Pose *this, double a2, float value)
{
  ;
}


// Address: 0x106a340 | Name: _ZN3RBX4Pose14setEasingStyleENS0_15PoseEasingStyleE
void __fastcall RBX::Pose::setEasingStyle(RBX::Pose *this, RBX::Pose::PoseEasingStyle value)
{
  RBX::Pose *v2; // rbx
  RBX::Keyframe *parent; // r14
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v6; // r14
  RBX::Reflection::ClassDescriptor *v7; // rax

  if ( this->easingStyle != value )
  {
    v2 = this;
    this->easingStyle = value;
    RBX::Instance::raisePropertyChanged(this, &stru_2A045D8);
    while ( 1 )
    {
      parent = (RBX::Keyframe *)v2->parent;
      if ( !parent )
        break;
      descriptor = parent->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        RBX::Keyframe::invalidate(parent);
        return;
      }
      v2 = (RBX::Pose *)v2->parent;
      if ( v2 )
      {
        v6 = v2->descriptor;
        v7 = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)v6 + 363) - (unsigned int)*((unsigned __int16 *)v7 + 363) <= *((unsigned __int16 *)v7
                                                                                                + 364) )
          continue;
      }
      return;
    }
  }
}


// Address: 0x106a3f0 | Name: _ZN3RBX4Pose18setEasingDirectionENS0_19PoseEasingDirectionE
void __fastcall RBX::Pose::setEasingDirection(RBX::Pose *this, RBX::Pose::PoseEasingDirection value)
{
  RBX::Pose *v2; // rbx
  RBX::Keyframe *parent; // r14
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v6; // r14
  RBX::Reflection::ClassDescriptor *v7; // rax

  if ( this->easingDirection != value )
  {
    v2 = this;
    this->easingDirection = value;
    RBX::Instance::raisePropertyChanged(this, &stru_2A04640);
    while ( 1 )
    {
      parent = (RBX::Keyframe *)v2->parent;
      if ( !parent )
        break;
      descriptor = parent->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        RBX::Keyframe::invalidate(parent);
        return;
      }
      v2 = (RBX::Pose *)v2->parent;
      if ( v2 )
      {
        v6 = v2->descriptor;
        v7 = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)v6 + 363) - (unsigned int)*((unsigned __int16 *)v7 + 363) <= *((unsigned __int16 *)v7
                                                                                                + 364) )
          continue;
      }
      return;
    }
  }
}


// Address: 0x106a4a0 | Name: _ZN3RBX10Reflection8EnumDescINS_4Pose15PoseEasingStyleEEC2Ev
void __fastcall RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingStyle>::EnumDesc(
        RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingStyle> *this)
{
  RBX::Reflection::EnumDescriptor::EnumDescriptor(this, "PoseEasingStyle");
  *(_QWORD *)this = &off_28907A8;
  RBX::Reflection::EnumDescriptor::_addPairs(this, &stru_28907E0, 5);
}


// Address: 0x106a4f0 | Name: _ZN3RBX10Reflection8EnumDescINS_4Pose19PoseEasingDirectionEEC2Ev
void __fastcall RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingDirection>::EnumDesc(
        RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingDirection> *this)
{
  RBX::Reflection::EnumDescriptor::EnumDescriptor(this, "PoseEasingDirection");
  *(_QWORD *)this = &off_2890870;
  RBX::Reflection::EnumDescriptor::_addPairs(this, &stru_2890830, 3);
}


// Address: 0x106a540 | Name: _ZN3RBX4PoseC2Ev
void __fastcall RBX::Pose::Pose(RBX::Pose *this)
{
  __int128 v1; // [rsp+0h] [rbp-28h] BYREF
  void *ptr; // [rsp+10h] [rbp-18h]

  RBX::Instance::Instance(this);
  this->_vptr$EventSource = (int (**)(void))&off_2891168;
  this->descriptor = Class_getDescriptorPtr(this);
  this->_vptr$EventSource = (int (**)(void))&off_28908B0;
  *(_OWORD *)&this->coordinateFrame.rotation.elt[0][0] = 0x3F800000u;
  *(_OWORD *)&this->coordinateFrame.rotation.elt[1][1] = 0x3F800000u;
  this->coordinateFrame.rotation.elt[2][2] = 1.0;
  _mm_storel_ps((double *)&this->coordinateFrame.translation.x, (__m128)0LL);
  *(_QWORD *)&this->coordinateFrame.translation.z = 0x3F80000000000000LL;
  *(_QWORD *)&this->easingStyle = 0;
  v1 = 0;
  ptr = 0;
  LOBYTE(v1) = 8;
  *(_DWORD *)((char *)&v1 + 1) = 1702063952;
  BYTE5(v1) = 0;
  RBX::Instance::setName(this, (const std::string *)&v1);
  if ( (v1 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x106a620 | Name: _ZN3RBX4Pose18findKeyframeParentEv
RBX::Keyframe *__fastcall RBX::Pose::findKeyframeParent(__int64 a1)
{
  __int64 v2; // r14
  __int64 v3; // r15
  __int64 v4; // r12
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v6; // r15
  RBX::Reflection::ClassDescriptor *v7; // rax

  v2 = 0;
  while ( 1 )
  {
    v3 = *(_QWORD *)(a1 + 88);
    if ( !v3 )
      break;
    v4 = *(_QWORD *)(v3 + 24);
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *(unsigned __int16 *)(v4 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      return (RBX::Keyframe *)v3;
    a1 = *(_QWORD *)(a1 + 88);
    if ( a1 )
    {
      v6 = *(_QWORD *)(a1 + 24);
      v7 = Class_getDescriptorPtr(0);
      if ( *(unsigned __int16 *)(v6 + 726) - (unsigned int)*((unsigned __int16 *)v7 + 363) <= *((unsigned __int16 *)v7
                                                                                              + 364) )
        continue;
    }
    return (RBX::Keyframe *)v2;
  }
  return (RBX::Keyframe *)v2;
}


// Address: 0x106a6b0 | Name: _ZN3RBX4Pose10invalidateEv
void __fastcall RBX::Pose::invalidate(RBX::Pose *this)
{
  RBX::Keyframe *parent; // r14
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v5; // r14
  RBX::Reflection::ClassDescriptor *v6; // rax

  while ( 1 )
  {
    parent = (RBX::Keyframe *)this->parent;
    if ( !parent )
      break;
    descriptor = parent->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      RBX::Keyframe::invalidate(parent);
      return;
    }
    this = (RBX::Pose *)this->parent;
    if ( this )
    {
      v5 = this->descriptor;
      v6 = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)v5 + 363) - (unsigned int)*((unsigned __int16 *)v6 + 363) <= *((unsigned __int16 *)v6
                                                                                              + 364) )
        continue;
    }
    return;
  }
}


// Address: 0x106a740 | Name: _Z22Class_getDescriptorPtrPN3RBX4PoseE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::Pose *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A046A8;
  if ( !qword_2A046A8 )
  {
    if ( !(_BYTE)byte_2A049F0 )
    {
      if ( __cxa_guard_acquire(&byte_2A049F0) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A046B0,
          v2,
          "Pose",
          0,
          attributes,
          RBX::Security::Permissions::None,
          &dword_2A04350);
        stru_2A049E8._vptr$ICreator = (int (**)(void))&off_2890D58;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A046B8, &stru_2A049E8);
        __cxa_atexit((void (*)(void *))RBX::ClassRegistrar<RBX::Pose,true>::~ClassRegistrar, &unk_2A046B0, &dso_handle);
        __cxa_guard_release(&byte_2A049F0);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A046B0;
    qword_2A046A8 = (RBX::Reflection::ClassDescriptor *)&unk_2A046B0;
  }
  return result;
}


// Address: 0x106a8a0 | Name: _Z16Class_getNamePtrPN3RBX4PoseE
const RBX::Name *__fastcall Class_getNamePtr(RBX::Pose *a1)
{
  const RBX::Name *result; // rax

  result = (const RBX::Name *)qword_2A049F8;
  if ( !qword_2A049F8 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A049F8 = (RBX::Pose *)result;
  }
  return result;
}


// Address: 0x106a8d0 | Name: _ZN3RBX10Reflection4Type12getSingletonINS_4Pose15PoseEasingStyleEEERKS1_v
const RBX::Reflection::Type *__cdecl RBX::Reflection::Type::getSingleton<RBX::Pose::PoseEasingStyle>()
{
  return (const RBX::Reflection::Type *)RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingStyle>::singleton();
}


// Address: 0x106a8e0 | Name: j__ZN3RBX10Reflection8EnumDescINS_4Pose15PoseEasingStyleEE9singletonEv
// attributes: thunk
void __cdecl RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingStyle>::singleton()
{
  _ZN3RBX10Reflection8EnumDescINS_4Pose15PoseEasingStyleEE9singletonEv();
}


// Address: 0x106a8f0 | Name: _ZN3RBX10Reflection4Type12getSingletonINS_4Pose19PoseEasingDirectionEEERKS1_v
const RBX::Reflection::Type *__cdecl RBX::Reflection::Type::getSingleton<RBX::Pose::PoseEasingDirection>()
{
  return (const RBX::Reflection::Type *)RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingDirection>::singleton();
}


// Address: 0x106a900 | Name: j__ZN3RBX10Reflection8EnumDescINS_4Pose19PoseEasingDirectionEE9singletonEv
// attributes: thunk
void __cdecl RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingDirection>::singleton()
{
  _ZN3RBX10Reflection8EnumDescINS_4Pose19PoseEasingDirectionEE9singletonEv();
}


// Address: 0x106cf80 | Name: _GLOBAL__sub_I_Pose.cpp
void __cdecl GLOBAL__sub_I_Pose_cpp()
{
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::Reflection::ClassDescriptor *v1; // r14
  char *v2; // rbx
  const RBX::Reflection::Type *v3; // rax
  RBX::Reflection::PropertyDescriptor::Attributes attributes; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesa; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesb; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesc; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesd; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes v9; // [rsp+28h] [rbp-50h] BYREF
  RBX::Reflection::PropertyDescriptor::Attributes flags; // [rsp+40h] [rbp-38h]
  RBX::Reflection::Descriptor::Attributes v11; // 0:r8.1,8:r9.8

  qword_2A04338 = (__int64)boost::system::generic_category();
  qword_2A04340 = (__int64)boost::system::generic_category();
  qword_2A04348 = (__int64)boost::system::system_category();
  dword_2A04350 = RBX::Memory::registerCategory(
                    (const char *)&stru_3FD3B6,
                    RBX::Memory::DeveloperTag::DeveloperTag_Animation);
  DescriptorPtr = Class_getDescriptorPtr((RBX::Pose *)&stru_3FD3B6);
  v11.isDeprecated = 0;
  v11.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A04358,
    DescriptorPtr,
    "GetSubPoses",
    RBX::Security::Permissions::None,
    v11);
  qword_2A04358[0] = &off_2890DE8;
  xmmword_2A043C0 = (unsigned __int64)RBX::Pose::getSubPoses;
  qword_2A04398 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A04358, &dso_handle);
  v9.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::Pose,void ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::Pose,void (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A043D0,
    RBX::Pose::addSubPose,
    0,
    "AddSubPose",
    (RBX::Security::Permissions)"pose",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v9.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::Pose,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A043D0,
    &dso_handle);
  v9.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::Pose,void ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::Pose,void (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A04450,
    RBX::Pose::removeSubPose,
    0,
    "RemoveSubPose",
    (RBX::Security::Permissions)"pose",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v9.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::Pose,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A04450,
    &dso_handle);
  v1 = Class_getDescriptorPtr((RBX::Pose *)RBX::Reflection::BoundFuncDesc<RBX::Pose,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc);
  v2 = (char *)operator new(0x28u);
  *(_QWORD *)v2 = &off_2890EF8;
  *(_OWORD *)(v2 + 8) = (unsigned __int64)RBX::Pose::getCoordinateFrame;
  *(_OWORD *)(v2 + 24) = (unsigned __int64)RBX::Pose::setCoordinateFrame;
  v9.isDeprecated = 0;
  v9.preferred = 0;
  v9.flags = RBX::Reflection::PropertyDescriptor::Functionality::STANDARD;
  v3 = RBX::Reflection::Type::getSingleton<G3D::CoordinateFrame>();
  *(_QWORD *)&attributes.flags = *(_QWORD *)&v9.flags;
  attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v9);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A044D0,
    v1,
    v3,
    "CFrame",
    &stru_458781.gap0,
    attributes,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A044D0._vptr$Descriptor = (int (**)(void))&off_2890AD8;
  qword_2A04520 = (__int64)v2;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2) )
    *((_BYTE *)&stru_2A044D0.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A044D0._vptr$Descriptor + 3))(&stru_2A044D0) )
    *((_BYTE *)&stru_2A044D0.security + 4) &= 0xF3u;
  stru_2A044D0._vptr$Descriptor = (int (**)(void))&off_2890E38;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<G3D::CoordinateFrame>::~TypedPropertyDescriptor,
    &stru_2A044D0,
    &dso_handle);
  v9.isDeprecated = 0;
  v9.preferred = 0;
  v9.flags = RBX::Reflection::PropertyDescriptor::Functionality::STANDARD;
  flags.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::Pose::setWeight;
  *(_QWORD *)&attributesa.flags = *(_QWORD *)&v9.isDeprecated;
  attributesa.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::Pose::setWeight;
  RBX::Reflection::PropDescriptor<RBX::Pose,float>::PropDescriptor<float (RBX::Pose::*)(void)const,void (RBX::Pose::*)(float)>(
    (RBX::Reflection::PropDescriptor<RBX::Pose,float> *)&stru_2A04528,
    "Weight",
    &stru_458781.gap0,
    RBX::Pose::getWeight,
    0,
    RBX::Security::Permissions::None,
    attributesa,
    0,
    *(__int64 *)&v9.flags);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A04528,
    &dso_handle);
  RBX::Reflection::PropertyDescriptor::Attributes::deprecated(
    &v9,
    RBX::Reflection::PropertyDescriptor::Functionality::UI);
  flags.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::Pose::setMaskWeight;
  *(_QWORD *)&attributesb.flags = *(_QWORD *)&v9.isDeprecated;
  attributesb.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::Pose::setMaskWeight;
  RBX::Reflection::PropDescriptor<RBX::Pose,float>::PropDescriptor<float (RBX::Pose::*)(void)const,void (RBX::Pose::*)(float)>(
    &stru_2A04580,
    "MaskWeight",
    &stru_458781.gap0,
    RBX::Pose::getMaskWeight,
    0,
    RBX::Security::Permissions::None,
    attributesb,
    (__int64)v9.preferred,
    *(__int64 *)&v9.flags);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A04580,
    &dso_handle);
  v9.isDeprecated = 0;
  v9.preferred = 0;
  v9.flags = RBX::Reflection::PropertyDescriptor::Functionality::STANDARD;
  flags.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::Pose::setEasingStyle;
  *(_QWORD *)&attributesc.flags = *(_QWORD *)&v9.isDeprecated;
  attributesc.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::Pose::setEasingStyle;
  RBX::Reflection::EnumPropDescriptor<RBX::Pose,RBX::Pose::PoseEasingStyle>::EnumPropDescriptor<RBX::Pose::PoseEasingStyle (RBX::Pose::*)(void)const,void (RBX::Pose::*)(RBX::Pose::PoseEasingStyle)>(
    (RBX::Reflection::EnumPropDescriptor<RBX::Pose,RBX::Pose::PoseEasingStyle> *)&stru_2A045D8,
    "EasingStyle",
    &stru_458781.gap0,
    RBX::Pose::getEasingStyle,
    0,
    RBX::Security::Permissions::None,
    attributesc,
    0,
    *(__int64 *)&v9.flags);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::EnumPropDescriptor<RBX::Pose,RBX::Pose::PoseEasingStyle>::~EnumPropDescriptor,
    &stru_2A045D8,
    &dso_handle);
  v9.isDeprecated = 0;
  v9.preferred = 0;
  v9.flags = RBX::Reflection::PropertyDescriptor::Functionality::STANDARD;
  flags.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::Pose::setEasingDirection;
  *(_QWORD *)&attributesd.flags = *(_QWORD *)&v9.isDeprecated;
  attributesd.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::Pose::setEasingDirection;
  RBX::Reflection::EnumPropDescriptor<RBX::Pose,RBX::Pose::PoseEasingDirection>::EnumPropDescriptor<RBX::Pose::PoseEasingDirection (RBX::Pose::*)(void)const,void (RBX::Pose::*)(RBX::Pose::PoseEasingDirection)>(
    (RBX::Reflection::EnumPropDescriptor<RBX::Pose,RBX::Pose::PoseEasingDirection> *)&stru_2A04640,
    "EasingDirection",
    &stru_458781.gap0,
    RBX::Pose::getEasingDirection,
    0,
    RBX::Security::Permissions::None,
    attributesd,
    0,
    *(__int64 *)&v9.flags);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::EnumPropDescriptor<RBX::Pose,RBX::Pose::PoseEasingDirection>::~EnumPropDescriptor,
    &stru_2A04640,
    &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_0);
  dword_2A04A04 = 0;
  RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingStyle>::singleton();
  dword_2A04A08 = 0;
  RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingStyle>::singleton();
  dword_2A04A0C = 0;
  RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingDirection>::singleton();
  dword_2A04A10 = 0;
  RBX::Reflection::EnumDesc<RBX::Pose::PoseEasingDirection>::singleton();
}


