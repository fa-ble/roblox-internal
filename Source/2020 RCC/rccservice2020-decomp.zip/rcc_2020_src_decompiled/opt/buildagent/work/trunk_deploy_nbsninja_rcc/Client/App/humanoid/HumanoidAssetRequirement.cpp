// Address: 0x10d0570 | Name: _ZN3RBX24HumanoidAssetRequirement13factoryCreateENS_12AssetService9AssetTypeEl
boost::shared_ptr<RBX::HumanoidAssetRequirement> *__fastcall RBX::HumanoidAssetRequirement::factoryCreate(
        boost::shared_ptr<RBX::HumanoidAssetRequirement> *a1,
        int type,
        int64_t assetId)
{
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  boost::unordered::detail::ptr_bucket::link_pointer i; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer v7; // rax
  boost::unordered::detail::ptr_bucket::link_pointer v8; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer v9; // rax
  boost::unordered::detail::ptr_bucket::link_pointer v10; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer v11; // rax
  boost::unordered::detail::ptr_bucket::link_pointer v12; // rdi
  RBX::HumanoidAssetRequirement *v14; // rbp
  __int64 (__fastcall **v15)(); // rax

  if ( !(_BYTE)byte_2A08B08 && __cxa_guard_acquire(&byte_2A08B08) )
  {
    boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::unordered_set<int const*>(
      &stru_2A08AD8,
      &dword_4ADAAC,
      &l);
    __cxa_atexit(
      (void (*)(void *))boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::~unordered_set,
      &stru_2A08AD8,
      &dso_handle);
    __cxa_guard_release(&byte_2A08B08);
  }
  if ( stru_2A08AD8.table_.size_ )
  {
    next = stru_2A08AD8.table_.buckets_[type % stru_2A08AD8.table_.bucket_count_].next_;
    if ( next )
    {
      for ( i = next->next_; i; i = i->next_ )
      {
        if ( i[1].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)type )
        {
          if ( LODWORD(i[2].next_) == type )
          {
            v14 = (RBX::HumanoidAssetRequirement *)operator new(0x10u);
            v14->assetId = assetId;
            v15 = &off_28950A8;
            goto LABEL_46;
          }
        }
        else if ( (unsigned __int64)i[1].next_ % stru_2A08AD8.table_.bucket_count_ != type
                                                                                    % stru_2A08AD8.table_.bucket_count_ )
        {
          break;
        }
      }
    }
  }
  if ( type == 18 )
  {
    v14 = (RBX::HumanoidAssetRequirement *)operator new(0x10u);
    v14->assetId = assetId;
    v15 = &off_28950D0;
  }
  else
  {
    if ( type != 17 )
    {
      if ( !(_BYTE)byte_2A08B40 && __cxa_guard_acquire(&byte_2A08B40) )
      {
        boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::unordered_set<int const*>(
          &stru_2A08B10,
          &dword_4ADAC0,
          &dword_4ADAD4);
        __cxa_atexit(
          (void (*)(void *))boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::~unordered_set,
          &stru_2A08B10,
          &dso_handle);
        __cxa_guard_release(&byte_2A08B40);
      }
      if ( !stru_2A08B10.table_.size_
        || (v7 = stru_2A08B10.table_.buckets_[type % stru_2A08B10.table_.bucket_count_].next_) == 0
        || (v8 = v7->next_) == 0 )
      {
LABEL_25:
        if ( !(_BYTE)byte_2A08B78 && __cxa_guard_acquire(&byte_2A08B78) )
        {
          boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::unordered_set<int const*>(
            &stru_2A08B48,
            &dword_4ADAE0,
            &dword_4ADB00);
          __cxa_atexit(
            (void (*)(void *))boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::~unordered_set,
            &stru_2A08B48,
            &dso_handle);
          __cxa_guard_release(&byte_2A08B78);
        }
        if ( !stru_2A08B48.table_.size_
          || (v9 = stru_2A08B48.table_.buckets_[type % stru_2A08B48.table_.bucket_count_].next_) == 0
          || (v10 = v9->next_) == 0 )
        {
LABEL_35:
          if ( !(_BYTE)byte_2A08BB0 && __cxa_guard_acquire(&byte_2A08BB0) )
          {
            boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::unordered_set<int const*>(
              &stru_2A08B80,
              &dword_4ADB00,
              &dword_4ADB1C);
            __cxa_atexit(
              (void (*)(void *))boost::unordered::unordered_set<int,boost::hash<int>,std::equal_to<int>,std::allocator<int>>::~unordered_set,
              &stru_2A08B80,
              &dso_handle);
            __cxa_guard_release(&byte_2A08BB0);
          }
          if ( !stru_2A08B80.table_.size_
            || (v11 = stru_2A08B80.table_.buckets_[type % stru_2A08B80.table_.bucket_count_].next_) == 0
            || (v12 = v11->next_) == 0 )
          {
LABEL_45:
            v14 = (RBX::HumanoidAssetRequirement *)operator new(0x10u);
            v14->assetId = RBX::HumanoidDescription::nullAssetId();
            v15 = &off_2895080;
            goto LABEL_46;
          }
          while ( 1 )
          {
            if ( v12[1].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)type )
            {
              if ( LODWORD(v12[2].next_) == type )
              {
                v14 = (RBX::HumanoidAssetRequirement *)operator new(0x10u);
                v14->assetId = assetId;
                v15 = &off_2895170;
                goto LABEL_46;
              }
            }
            else if ( (unsigned __int64)v12[1].next_ % stru_2A08B80.table_.bucket_count_ != type
                                                                                          % stru_2A08B80.table_.bucket_count_ )
            {
              goto LABEL_45;
            }
            v12 = v12->next_;
            if ( !v12 )
              goto LABEL_45;
          }
        }
        while ( 1 )
        {
          if ( v10[1].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)type )
          {
            if ( LODWORD(v10[2].next_) == type )
            {
              v14 = (RBX::HumanoidAssetRequirement *)operator new(0x10u);
              v14->assetId = assetId;
              v15 = &off_2895148;
              goto LABEL_46;
            }
          }
          else if ( (unsigned __int64)v10[1].next_ % stru_2A08B48.table_.bucket_count_ != type
                                                                                        % stru_2A08B48.table_.bucket_count_ )
          {
            goto LABEL_35;
          }
          v10 = v10->next_;
          if ( !v10 )
            goto LABEL_35;
        }
      }
      while ( 1 )
      {
        if ( v8[1].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)type )
        {
          if ( LODWORD(v8[2].next_) == type )
          {
            v14 = (RBX::HumanoidAssetRequirement *)operator new(0x10u);
            v14->assetId = assetId;
            v15 = &off_28950F8;
            goto LABEL_46;
          }
        }
        else if ( (unsigned __int64)v8[1].next_ % stru_2A08B10.table_.bucket_count_ != type
                                                                                     % stru_2A08B10.table_.bucket_count_ )
        {
          goto LABEL_25;
        }
        v8 = v8->next_;
        if ( !v8 )
          goto LABEL_25;
      }
    }
    v14 = (RBX::HumanoidAssetRequirement *)operator new(0x10u);
    v14->assetId = assetId;
    v15 = (__int64 (__fastcall **)())&off_2895120;
  }
LABEL_46:
  v14->_vptr$HumanoidAssetRequirement = (int (**)(void))v15;
  a1->px = v14;
  a1->pn.pi_ = 0;
  boost::detail::sp_pointer_construct<RBX::HumanoidAssetRequirement,RBX::HumanoidAssetRequirement>(a1, v14, &a1->pn);
  return a1;
}


// Address: 0x10d0a40 | Name: _ZN3RBX24HumanoidAssetRequirementC2El
void __fastcall RBX::HumanoidAssetRequirement::HumanoidAssetRequirement(
        RBX::HumanoidAssetRequirement *this,
        int64_t id)
{
  this->_vptr$HumanoidAssetRequirement = (int (**)(void))&off_2895058;
  this->assetId = id;
}


// Address: 0x10d0a50 | Name: _ZNK3RBX24HumanoidAssetRequirement10getAssetIdEv
int64_t __fastcall RBX::HumanoidAssetRequirement::getAssetId(const RBX::HumanoidAssetRequirement *this)
{
  return this->assetId;
}


// Address: 0x10d0a60 | Name: _ZN3RBX28HumanoidNullAssetRequirementC2Ev
void __fastcall RBX::HumanoidNullAssetRequirement::HumanoidNullAssetRequirement(
        RBX::HumanoidNullAssetRequirement *this)
{
  this->assetId = RBX::HumanoidDescription::nullAssetId();
  this->_vptr$HumanoidAssetRequirement = (int (**)(void))&off_2895080;
}


// Address: 0x10d0a80 | Name: _ZNK3RBX28HumanoidNullAssetRequirement14CheckInstancesERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
bool __fastcall RBX::HumanoidNullAssetRequirement::CheckInstances(
        const RBX::HumanoidNullAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  return 0;
}


// Address: 0x10d0a90 | Name: _ZN3RBX31HumanoidClothesAssetRequirementC2El
void __fastcall RBX::HumanoidClothesAssetRequirement::HumanoidClothesAssetRequirement(
        RBX::HumanoidClothesAssetRequirement *this,
        int64_t id)
{
  this->assetId = id;
  this->_vptr$HumanoidAssetRequirement = (int (**)(void))&off_28950A8;
}


// Address: 0x10d0aa0 | Name: _ZNK3RBX31HumanoidClothesAssetRequirement14CheckInstancesERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
// local variable allocation has failed, the output may be wrong!
bool __fastcall RBX::HumanoidClothesAssetRequirement::CheckInstances(
        const RBX::HumanoidClothesAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  __int64 **px; // rax
  __int64 *v4; // rcx
  __int64 v5; // rax
  volatile signed __int32 *v6; // r14
  __int64 v7; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool v9; // bl

  px = (__int64 **)resultantInstances->px;
  if ( !resultantInstances->px || (v4 = *px, (char *)px[1] - (char *)*px != 16) )
  {
LABEL_11:
    v9 = 0;
    RBX::StandardOut::printf(
      MESSAGE_ERROR,
      "Asset id %lld should reference a CharacterAppearance Instance",
      this->assetId);
    return v9;
  }
  v5 = *v4;
  v6 = (volatile signed __int32 *)v4[1];
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  if ( !v5
    || (v7 = *(_QWORD *)(v5 + 24),
        DescriptorPtr = Class_getDescriptorPtr(0),
        *(_QWORD *)&isR15 = *((unsigned __int16 *)DescriptorPtr + 363),
        (unsigned int)*(unsigned __int16 *)(v7 + 726) - isR15 > *((unsigned __int16 *)DescriptorPtr + 364)) )
  {
    if ( v6 )
    {
      if ( !_InterlockedSub(v6 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *, bool))(*(_QWORD *)v6 + 16LL))(
          v6,
          resultantInstances,
          isR15);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
    goto LABEL_11;
  }
  v9 = 1;
  if ( v6 )
  {
    if ( !_InterlockedSub(v6 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  return v9;
}


// Address: 0x10d0bc0 | Name: _ZN3RBX28HumanoidFaceAssetRequirementC2El
void __fastcall RBX::HumanoidFaceAssetRequirement::HumanoidFaceAssetRequirement(
        RBX::HumanoidFaceAssetRequirement *this,
        int64_t id)
{
  this->assetId = id;
  this->_vptr$HumanoidAssetRequirement = (int (**)(void))&off_28950D0;
}


// Address: 0x10d0bd0 | Name: _ZNK3RBX28HumanoidFaceAssetRequirement14CheckInstancesERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
// local variable allocation has failed, the output may be wrong!
bool __fastcall RBX::HumanoidFaceAssetRequirement::CheckInstances(
        const RBX::HumanoidFaceAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  __int64 **px; // rax
  __int64 *v4; // rcx
  __int64 v5; // rax
  volatile signed __int32 *v6; // r14
  __int64 v7; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool v9; // bl

  px = (__int64 **)resultantInstances->px;
  if ( !resultantInstances->px || (v4 = *px, (char *)px[1] - (char *)*px != 16) )
  {
LABEL_11:
    v9 = 0;
    RBX::StandardOut::printf(MESSAGE_ERROR, "Asset id %lld should reference a Decal Instance", this->assetId);
    return v9;
  }
  v5 = *v4;
  v6 = (volatile signed __int32 *)v4[1];
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  if ( !v5
    || (v7 = *(_QWORD *)(v5 + 24),
        DescriptorPtr = Class_getDescriptorPtr(0),
        *(_QWORD *)&isR15 = *((unsigned __int16 *)DescriptorPtr + 363),
        (unsigned int)*(unsigned __int16 *)(v7 + 726) - isR15 > *((unsigned __int16 *)DescriptorPtr + 364)) )
  {
    if ( v6 )
    {
      if ( !_InterlockedSub(v6 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *, bool))(*(_QWORD *)v6 + 16LL))(
          v6,
          resultantInstances,
          isR15);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
    goto LABEL_11;
  }
  v9 = 1;
  if ( v6 )
  {
    if ( !_InterlockedSub(v6 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  return v9;
}


// Address: 0x10d0cf0 | Name: _ZN3RBX32HumanoidBodyPartAssetRequirementC2El
void __fastcall RBX::HumanoidBodyPartAssetRequirement::HumanoidBodyPartAssetRequirement(
        RBX::HumanoidBodyPartAssetRequirement *this,
        int64_t id)
{
  this->assetId = id;
  this->_vptr$HumanoidAssetRequirement = (int (**)(void))&off_28950F8;
}


// Address: 0x10d0d00 | Name: _ZNK3RBX32HumanoidBodyPartAssetRequirement14CheckInstancesERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
bool __fastcall RBX::HumanoidBodyPartAssetRequirement::CheckInstances(
        const RBX::HumanoidBodyPartAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  bool v4; // bl
  const char *v5; // rsi

  v4 = 1;
  if ( !RBX::HumanoidBodyPartAssetRequirement::IsInstanceCorrectForBodyParts(this, resultantInstances, 0) )
  {
    if ( isR15 )
      v5 = "Asset id %lld should reference a PartInstance Instance";
    else
      v5 = "Asset id %lld should reference a CharacterAppearance Instance";
    v4 = 0;
    RBX::StandardOut::printf(MESSAGE_ERROR, v5, this->assetId);
  }
  return v4;
}


// Address: 0x10d0d50 | Name: _ZNK3RBX32HumanoidBodyPartAssetRequirement29IsInstanceCorrectForBodyPartsERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
bool __fastcall RBX::HumanoidBodyPartAssetRequirement::IsInstanceCorrectForBodyParts(
        const RBX::HumanoidBodyPartAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  __int64 *px; // rax
  __int64 v4; // rbp
  __int64 v5; // r15
  __int64 v6; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  std::__hash_table<std::__hash_value_type<std::string,bool>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,bool>,std::hash<std::string >,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,bool>,std::equal_to<std::string >,true>,std::allocator<std::__hash_value_type<std::string,bool> > >::iterator v8; // rax
  std::__hash_node_base<std::__hash_node<std::__hash_value_type<std::string,bool>,void *> *>::__next_pointer next; // rbp
  bool v10; // r14
  char v11; // bl
  __int128 v13; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  char v15; // [rsp+18h] [rbp-30h]

  if ( !(_BYTE)byte_2A08AD0 && __cxa_guard_acquire(&byte_2A08AD0) )
  {
    *(_OWORD *)&stru_2A08AA8.__table_.__p1_.__value_.__next_ = 0;
    stru_2A08AA8.__table_.__bucket_list_ = 0;
    stru_2A08AA8.__table_.__p3_.__value_ = 1.0;
    __cxa_atexit((void (*)(void *))std::unordered_map<std::string,bool>::~unordered_map, &stru_2A08AA8, &dso_handle);
    __cxa_guard_release(&byte_2A08AD0);
  }
  v13 = 0;
  ptr = 0;
  LOBYTE(v13) = 4;
  *(_WORD *)((char *)&v13 + 1) = 13906;
  BYTE3(v13) = 0;
  *std::unordered_map<std::string,bool>::operator[](
     &stru_2A08AA8,
     (std::unordered_map<std::string,bool>::key_type *)&v13) = 0;
  if ( (v13 & 1) != 0 )
    operator delete(ptr);
  ptr = 0;
  LOBYTE(v13) = 30;
  *((_QWORD *)&v13 + 1) = 0x746E65746E497473LL;
  *(_QWORD *)((char *)&v13 + 1) = 0x7369747241353152LL;
  *std::unordered_map<std::string,bool>::operator[](
     &stru_2A08AA8,
     (std::unordered_map<std::string,bool>::key_type *)&v13) = 0;
  if ( (v13 & 1) != 0 )
    operator delete(ptr);
  px = (__int64 *)resultantInstances->px;
  if ( !resultantInstances->px )
    return 0;
  v4 = *px;
  v5 = px[1];
  if ( (v5 - *px) >> 4 < stru_2A08AA8.__table_.__p2_.__value_ )
    return 0;
  for ( ; v5 != v4; v4 += 16 )
  {
    if ( *(_QWORD *)v4 )
    {
      v6 = *(_QWORD *)(*(_QWORD *)v4 + 24LL);
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *(unsigned __int16 *)(v6 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        v8.__node_ = std::__hash_table<std::__hash_value_type<std::string,bool>,std::__unordered_map_hasher<std::string,std::__hash_value_type<std::string,bool>,std::hash<std::string>,true>,std::__unordered_map_equal<std::string,std::__hash_value_type<std::string,bool>,std::equal_to<std::string>,true>,std::allocator<std::__hash_value_type<std::string,bool>>>::find<std::string>(
                       &stru_2A08AA8.__table_,
                       *(const std::string **)(*(_QWORD *)v4 + 64LL)).__node_;
        if ( v8.__node_ )
        {
          if ( !LOBYTE(v8.__node_[5].__next_) )
            LOBYTE(v8.__node_[5].__next_) = 1;
        }
      }
    }
  }
  next = stru_2A08AA8.__table_.__p1_.__value_.__next_;
  v10 = 1;
  if ( stru_2A08AA8.__table_.__p1_.__value_.__next_ )
  {
    while ( 1 )
    {
      std::string::basic_string(&v13, &next[2]);
      v11 = (char)next[5].__next_;
      v15 = v11;
      if ( (v13 & 1) != 0 )
        operator delete(ptr);
      if ( !v11 )
        break;
      next = next->__next_;
      if ( !next )
        return v10;
    }
    return 0;
  }
  return v10;
}


// Address: 0x10d0f70 | Name: _ZN3RBX28HumanoidHeadAssetRequirementC2El
void __fastcall RBX::HumanoidHeadAssetRequirement::HumanoidHeadAssetRequirement(
        RBX::HumanoidHeadAssetRequirement *this,
        int64_t id)
{
  this->assetId = id;
  this->_vptr$HumanoidAssetRequirement = (int (**)(void))&off_2895120;
}


// Address: 0x10d0f80 | Name: _ZNK3RBX28HumanoidHeadAssetRequirement14CheckInstancesERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
bool __fastcall RBX::HumanoidHeadAssetRequirement::CheckInstances(
        const RBX::HumanoidHeadAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  bool v4; // bl
  const char *v5; // rsi

  v4 = 1;
  if ( !RBX::HumanoidHeadAssetRequirement::IsInstanceCorrectForHeads(this, resultantInstances, 0)
    && !RBX::HumanoidBodyPartAssetRequirement::IsInstanceCorrectForBodyParts(this, resultantInstances, 0) )
  {
    if ( isR15 )
      v5 = "Asset id %lld should reference a single DataModelMesh or PartInstance Instance";
    else
      v5 = "Asset id %lld should reference a single DataModelMesh or CharacterAppearance Instance";
    v4 = 0;
    RBX::StandardOut::printf(MESSAGE_ERROR, v5, this->assetId);
  }
  return v4;
}


// Address: 0x10d0fe0 | Name: _ZNK3RBX28HumanoidHeadAssetRequirement25IsInstanceCorrectForHeadsERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
// local variable allocation has failed, the output may be wrong!
bool __fastcall RBX::HumanoidHeadAssetRequirement::IsInstanceCorrectForHeads(
        const RBX::HumanoidHeadAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  __int64 **px; // rax
  __int64 *v4; // rcx
  __int64 v5; // rax
  volatile signed __int32 *v6; // rbx
  __int64 v7; // rbp
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool v9; // bp

  px = (__int64 **)resultantInstances->px;
  if ( !resultantInstances->px )
    return 0;
  v4 = *px;
  if ( (char *)px[1] - (char *)*px != 16 )
    return 0;
  v5 = *v4;
  v6 = (volatile signed __int32 *)v4[1];
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  if ( !v5
    || (v7 = *(_QWORD *)(v5 + 24),
        DescriptorPtr = Class_getDescriptorPtr(0),
        *(_QWORD *)&isR15 = *((unsigned __int16 *)DescriptorPtr + 363),
        (unsigned int)*(unsigned __int16 *)(v7 + 726) - isR15 > *((unsigned __int16 *)DescriptorPtr + 364)) )
  {
    if ( v6 )
    {
      if ( !_InterlockedSub(v6 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *, bool))(*(_QWORD *)v6 + 16LL))(
          v6,
          resultantInstances,
          isR15);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
    return 0;
  }
  v9 = 1;
  if ( v6 )
  {
    if ( !_InterlockedSub(v6 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  return v9;
}


// Address: 0x10d10e0 | Name: _ZN3RBX33HumanoidAccessoryAssetRequirementC2El
void __fastcall RBX::HumanoidAccessoryAssetRequirement::HumanoidAccessoryAssetRequirement(
        RBX::HumanoidAccessoryAssetRequirement *this,
        int64_t id)
{
  this->assetId = id;
  this->_vptr$HumanoidAssetRequirement = (int (**)(void))&off_2895148;
}


// Address: 0x10d10f0 | Name: _ZNK3RBX33HumanoidAccessoryAssetRequirement14CheckInstancesERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
// local variable allocation has failed, the output may be wrong!
bool __fastcall RBX::HumanoidAccessoryAssetRequirement::CheckInstances(
        const RBX::HumanoidAccessoryAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  __int64 **px; // rax
  __int64 *v4; // rcx
  __int64 v5; // rax
  volatile signed __int32 *v6; // r14
  __int64 v7; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool v9; // bl

  px = (__int64 **)resultantInstances->px;
  if ( !resultantInstances->px || (v4 = *px, (char *)px[1] - (char *)*px != 16) )
  {
LABEL_11:
    v9 = 0;
    RBX::StandardOut::printf(MESSAGE_ERROR, "Asset id %lld should reference a Accoutrement Instance", this->assetId);
    return v9;
  }
  v5 = *v4;
  v6 = (volatile signed __int32 *)v4[1];
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  if ( !v5
    || (v7 = *(_QWORD *)(v5 + 24),
        DescriptorPtr = Class_getDescriptorPtr(0),
        *(_QWORD *)&isR15 = *((unsigned __int16 *)DescriptorPtr + 363),
        (unsigned int)*(unsigned __int16 *)(v7 + 726) - isR15 > *((unsigned __int16 *)DescriptorPtr + 364)) )
  {
    if ( v6 )
    {
      if ( !_InterlockedSub(v6 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *, bool))(*(_QWORD *)v6 + 16LL))(
          v6,
          resultantInstances,
          isR15);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
    goto LABEL_11;
  }
  v9 = 1;
  if ( v6 )
  {
    if ( !_InterlockedSub(v6 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  return v9;
}


// Address: 0x10d1210 | Name: _ZN3RBX33HumanoidAnimationAssetRequirementC2El
void __fastcall RBX::HumanoidAnimationAssetRequirement::HumanoidAnimationAssetRequirement(
        RBX::HumanoidAnimationAssetRequirement *this,
        int64_t id)
{
  this->assetId = id;
  this->_vptr$HumanoidAssetRequirement = (int (**)(void))&off_2895170;
}


// Address: 0x10d1220 | Name: _ZNK3RBX33HumanoidAnimationAssetRequirement14CheckInstancesERKN5boost10shared_ptrINSt3__16vectorINS2_INS_8InstanceEEENS3_9allocatorIS6_EEEEEEb
// local variable allocation has failed, the output may be wrong!
bool __fastcall RBX::HumanoidAnimationAssetRequirement::CheckInstances(
        const RBX::HumanoidAnimationAssetRequirement *this,
        const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *resultantInstances,
        bool isR15)
{
  __int64 **px; // rcx
  __int64 *v4; // rax
  __int64 v5; // r15
  volatile signed __int32 *v6; // r14
  __int64 v7; // r12
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool v9; // bl

  px = (__int64 **)resultantInstances->px;
  if ( !resultantInstances->px || (v4 = *px, (char *)px[1] - (char *)*px != 16) )
  {
LABEL_12:
    v9 = 0;
    RBX::StandardOut::printf(
      MESSAGE_ERROR,
      "Asset id %lld should reference a Folder Instance named %s",
      this->assetId,
      "R15Anim");
    return v9;
  }
  v5 = *v4;
  v6 = (volatile signed __int32 *)v4[1];
  if ( v6 )
    _InterlockedAdd(v6 + 2, 1u);
  if ( !v5
    || (v7 = *(_QWORD *)(v5 + 24),
        DescriptorPtr = Class_getDescriptorPtr(0),
        *(_QWORD *)&isR15 = *((unsigned __int16 *)DescriptorPtr + 363),
        (unsigned int)*(unsigned __int16 *)(v7 + 726) - isR15 > *((unsigned __int16 *)DescriptorPtr + 364))
    || (resultantInstances = (const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *)"R15Anim",
        (unsigned int)std::string::compare(*(_QWORD *)(v5 + 64), "R15Anim")) )
  {
    if ( v6 )
    {
      if ( !_InterlockedSub(v6 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, const boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> > *, bool))(*(_QWORD *)v6 + 16LL))(
          v6,
          resultantInstances,
          isR15);
        if ( !_InterlockedSub(v6 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
      }
    }
    goto LABEL_12;
  }
  v9 = 1;
  if ( v6 )
  {
    if ( !_InterlockedSub(v6 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  return v9;
}


// Address: 0x10d25f0 | Name: _GLOBAL__sub_I_HumanoidAssetRequirement.cpp
void __cdecl GLOBAL__sub_I_HumanoidAssetRequirement_cpp()
{
  qword_2A08A90 = (__int64)boost::system::generic_category();
  qword_2A08A98 = (__int64)boost::system::generic_category();
  qword_2A08AA0 = (__int64)boost::system::system_category();
}


