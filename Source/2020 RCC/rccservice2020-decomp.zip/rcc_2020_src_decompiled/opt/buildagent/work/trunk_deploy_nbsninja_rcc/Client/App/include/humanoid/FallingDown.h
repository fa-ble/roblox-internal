// Address: 0x10e5890 | Name: _ZN3RBX5HUMAN7PhysicsD0Ev
void __fastcall RBX::HUMAN::Physics::~Physics(RBX::HUMAN::Physics *this)
{
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e58b0 | Name: _ZN3RBX5HUMAN7Physics18onComputeForceImplEv
void __fastcall RBX::HUMAN::Physics::onComputeForceImpl(RBX::HUMAN::Physics *this)
{
  ;
}


// Address: 0x10e58c0 | Name: _ZNK3RBX5HUMAN7Physics17armsShouldCollideEv
bool __fastcall RBX::HUMAN::Physics::armsShouldCollide(const RBX::HUMAN::Physics *this)
{
  return 1;
}


// Address: 0x10e58d0 | Name: _ZNK3RBX5HUMAN7Physics17legsShouldCollideEv
bool __fastcall RBX::HUMAN::Physics::legsShouldCollide(const RBX::HUMAN::Physics *this)
{
  return 1;
}


// Address: 0x10e58e0 | Name: _ZNK3RBX5HUMAN7Physics14enableAutoJumpEv
bool __fastcall RBX::HUMAN::Physics::enableAutoJump(const RBX::HUMAN::Physics *this)
{
  return 0;
}


// Address: 0x10e58f0 | Name: _ZNK3RBX5HUMAN7Physics12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::Physics::getStateType(const RBX::HUMAN::Physics *this)
{
  return RBX::HUMAN::StateType::PHYSICS;
}


// Address: 0x10e5900 | Name: _ZN3RBX5HUMAN11FallingDownD0Ev
void __fastcall RBX::HUMAN::FallingDown::~FallingDown(RBX::HUMAN::FallingDown *this)
{
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e5920 | Name: _ZN3RBX5HUMAN11FallingDown18onComputeForceImplEv
void __fastcall RBX::HUMAN::FallingDown::onComputeForceImpl(RBX::HUMAN::FallingDown *this)
{
  ;
}


// Address: 0x10e5930 | Name: _ZNK3RBX5HUMAN11FallingDown17armsShouldCollideEv
bool __fastcall RBX::HUMAN::FallingDown::armsShouldCollide(const RBX::HUMAN::FallingDown *this)
{
  return 1;
}


// Address: 0x10e5940 | Name: _ZNK3RBX5HUMAN11FallingDown17legsShouldCollideEv
bool __fastcall RBX::HUMAN::FallingDown::legsShouldCollide(const RBX::HUMAN::FallingDown *this)
{
  return 1;
}


// Address: 0x10e5950 | Name: _ZNK3RBX5HUMAN11FallingDown14enableAutoJumpEv
bool __fastcall RBX::HUMAN::FallingDown::enableAutoJump(const RBX::HUMAN::FallingDown *this)
{
  return 0;
}


// Address: 0x10e5960 | Name: _ZNK3RBX5HUMAN11FallingDown12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::FallingDown::getStateType(const RBX::HUMAN::FallingDown *this)
{
  return RBX::HUMAN::StateType::FALLING_DWN;
}


// Address: 0x10e5970 | Name: _ZN3RBX5HUMAN4DeadD0Ev
void __fastcall RBX::HUMAN::Dead::~Dead(RBX::HUMAN::Dead *this)
{
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
  operator delete(this);
}


// Address: 0x10e5990 | Name: _ZN3RBX5HUMAN4Dead18onComputeForceImplEv
void __fastcall RBX::HUMAN::Dead::onComputeForceImpl(RBX::HUMAN::Dead *this)
{
  ;
}


// Address: 0x10e59a0 | Name: _ZNK3RBX5HUMAN4Dead17armsShouldCollideEv
bool __fastcall RBX::HUMAN::Dead::armsShouldCollide(const RBX::HUMAN::Dead *this)
{
  return 1;
}


// Address: 0x10e59b0 | Name: _ZNK3RBX5HUMAN4Dead17legsShouldCollideEv
bool __fastcall RBX::HUMAN::Dead::legsShouldCollide(const RBX::HUMAN::Dead *this)
{
  return 1;
}


// Address: 0x10e59c0 | Name: _ZNK3RBX5HUMAN4Dead14enableAutoJumpEv
bool __fastcall RBX::HUMAN::Dead::enableAutoJump(const RBX::HUMAN::Dead *this)
{
  return 0;
}


// Address: 0x10e59d0 | Name: _ZNK3RBX5HUMAN4Dead12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::Dead::getStateType(const RBX::HUMAN::Dead *this)
{
  return RBX::HUMAN::StateType::DEAD;
}


