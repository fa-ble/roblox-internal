// Address: 0x10d72b0 | Name: _ZN3RBX24HumanoidDefaultInstancesC2ERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDefaultInstances::HumanoidDefaultInstances(
        RBX::HumanoidDefaultInstances *this,
        const std::string *folder)
{
  *(_QWORD *)this = &off_28952E8;
  std::string::basic_string((char *)this + 8, folder);
}


// Address: 0x10d72d0 | Name: _ZN3RBX24HumanoidDefaultInstances9hasCachedERKN5boost10shared_ptrINS_8InstanceEEE
bool __fastcall RBX::HumanoidDefaultInstances::hasCached(
        RBX::HumanoidDefaultInstances *this,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  return RBX::Instance::findConstFirstChildByName(parent->px, (RBX::HumanoidDefaultInstances *)((char *)this + 8)) != 0;
}


// Address: 0x10d72f0 | Name: _ZN3RBX24HumanoidDefaultInstances11addInstanceEPNS_8InstanceERKN5boost10shared_ptrIS1_EE
void __fastcall RBX::HumanoidDefaultInstances::addInstance(
        RBX::HumanoidDefaultInstances *this,
        RBX::Instance *inst,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  RBX::Instance *Folder; // r14
  RBX::Instance *v4; // [rsp+8h] [rbp-20h]
  volatile signed __int32 *v5; // [rsp+10h] [rbp-18h]

  if ( inst )
  {
    if ( parent->px )
    {
      Folder = RBX::lazyCreateFolder(parent, (RBX::HumanoidDefaultInstances *)((char *)this + 8));
      RBX::Instance::clone(inst, RBX::CreatorRole::EngineCreator);
      RBX::Instance::setParentInternal(v4, Folder, 0);
      if ( v5 )
      {
        if ( !_InterlockedSub(v5 + 2, 1u) )
        {
          (*(void (__fastcall **)())(*(_QWORD *)v5 + 16LL))();
          if ( !_InterlockedSub(v5 + 3, 1u) )
            (*(void (__fastcall **)())(*(_QWORD *)v5 + 24LL))();
        }
      }
    }
  }
}


// Address: 0x10d73c0 | Name: _ZN3RBXL16lazyCreateFolderERKN5boost10shared_ptrINS_8InstanceEEERKNSt3__112basic_stringIcNS6_11char_traitsIcEENS6_9allocatorIcEEEE
RBX::Instance *__fastcall RBX::lazyCreateFolder(
        const boost::shared_ptr<RBX::Instance> *parent,
        const std::string *folderInstanceName)
{
  RBX::Instance *ConstFirstChildByName; // rbx
  boost::shared_ptr<RBX::Folder> v4; // rax
  RBX::Instance *px; // rsi
  boost::detail::sp_counted_base *pi; // rbx
  RBX::Instance *v7; // [rsp+0h] [rbp-28h]
  volatile signed __int32 *v8; // [rsp+8h] [rbp-20h]

  ConstFirstChildByName = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(parent->px, folderInstanceName);
  if ( !ConstFirstChildByName )
  {
    v4 = RBX::Creatable<RBX::Instance>::create<RBX::Folder>();
    (*((void (__fastcall **)(RBX::Instance *, const std::string *, boost::detail::sp_counted_base *))v7->_vptr$EventSource
     + 14))(
      v7,
      folderInstanceName,
      v4.pn.pi_);
    px = parent->px;
    pi = parent->pn.pi_;
    if ( pi )
      _InterlockedAdd(&pi->use_count_, 1u);
    RBX::Instance::setParentInternal(v7, px, 0);
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    (*((void (__fastcall **)(RBX::Instance *, _QWORD))v7->_vptr$EventSource + 8))(v7, 0);
    ConstFirstChildByName = v7;
    if ( v8 )
    {
      if ( !_InterlockedSub(v8 + 2, 1u) )
      {
        (*(void (__fastcall **)())(*(_QWORD *)v8 + 16LL))();
        if ( !_InterlockedSub(v8 + 3, 1u) )
          (*(void (__fastcall **)())(*(_QWORD *)v8 + 24LL))();
      }
    }
  }
  return ConstFirstChildByName;
}


// Address: 0x10d7510 | Name: _ZN3RBX24HumanoidDefaultInstances8getCloneERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEERKN5boost10shared_ptrINS_8InstanceEEE
_OWORD *__fastcall RBX::HumanoidDefaultInstances::getClone(
        _OWORD *a1,
        RBX::HumanoidDefaultInstances *this,
        const std::string *type,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  const RBX::Instance *ConstFirstChildByName; // rax
  RBX::Instance *v6; // rax

  if ( parent->px
    && (ConstFirstChildByName = RBX::Instance::findConstFirstChildByName(
                                  parent->px,
                                  (RBX::HumanoidDefaultInstances *)((char *)this + 8))) != 0
    && (v6 = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(ConstFirstChildByName, type)) != 0 )
  {
    RBX::Instance::clone(v6, RBX::CreatorRole::EngineCreator);
  }
  else
  {
    *a1 = 0;
  }
  return a1;
}


// Address: 0x10d7570 | Name: _ZN3RBX24HumanoidDefaultInstances13applyInternalERNS_8HumanoidERKNSt3__16vectorINS3_4pairINS_12AssetService9AssetTypeEKNS4_INS3_12basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEENSB_ISD_EEEEEENSB_ISH_EEEERKN5boost10shared_ptrINS_8InstanceEEERKNSN_INS_19HumanoidDescriptionEEESV_
void __fastcall RBX::HumanoidDefaultInstances::applyInternal(
        RBX::HumanoidDefaultInstances *this,
        RBX::Humanoid *humanoid,
        RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *allAssetsToParts,
        const boost::shared_ptr<RBX::Instance> *parent,
        const boost::shared_ptr<RBX::HumanoidDescription> *prev,
        const boost::shared_ptr<RBX::HumanoidDescription> *next)
{
  boost::shared_ptr<RBX::Instance>::element_type *px; // rdi
  const std::string *v10; // r13
  RBX::ModelInstance *CharacterFromHumanoid; // rsi
  __int64 v12; // r15
  RBX::AssetService::AssetType v13; // ebp
  int64_t SingleEquipAssetsByType; // rax
  unsigned __int64 v15; // rsi
  int64_t v16; // rax
  boost::shared_ptr<RBX::Instance> v17; // rax
  const std::string *v18; // r14
  const std::string *j; // r12
  volatile signed __int32 *v20; // rbp
  __int64 v21; // rdi
  __int128 v22; // [rsp+0h] [rbp-88h]
  __int128 v23; // [rsp+18h] [rbp-70h] BYREF
  const boost::shared_ptr<RBX::HumanoidDescription> *v24; // [rsp+28h] [rbp-60h]
  RBX::HumanoidDefaultInstances *v25; // [rsp+30h] [rbp-58h]
  __int64 i; // [rsp+38h] [rbp-50h]
  const boost::shared_ptr<RBX::HumanoidDescription> *v27; // [rsp+40h] [rbp-48h]
  __int64 v28; // [rsp+48h] [rbp-40h] BYREF
  __int64 v29; // [rsp+50h] [rbp-38h]

  v24 = next;
  v27 = prev;
  px = parent->px;
  v25 = this;
  v10 = (RBX::HumanoidDefaultInstances *)((char *)this + 8);
  if ( RBX::Instance::findConstFirstChildByName(px, (RBX::HumanoidDefaultInstances *)((char *)this + 8)) )
  {
    CharacterFromHumanoid = RBX::Humanoid::getCharacterFromHumanoid(humanoid);
    RBX::weak_from<RBX::ModelInstance>(&v28, CharacterFromHumanoid);
    v12 = *(_QWORD *)allAssetsToParts;
    for ( i = *((_QWORD *)allAssetsToParts + 1); v12 != i; v12 += 32 )
    {
      if ( v27->px )
      {
        v13 = *(_DWORD *)v12;
        SingleEquipAssetsByType = RBX::HumanoidDescription::getSingleEquipAssetsByType(
                                    v27->px,
                                    (RBX::AssetService::AssetType)*(_DWORD *)v12);
        if ( RBX::HumanoidDescription::isAssetSet(SingleEquipAssetsByType) )
        {
          v15 = (unsigned int)v13;
          v16 = RBX::HumanoidDescription::getSingleEquipAssetsByType(v24->px, v13);
          if ( !RBX::HumanoidDescription::isAssetSet(v16) )
          {
            v18 = *(const std::string **)(v12 + 8);
            for ( j = *(const std::string **)(v12 + 16); j != v18; v18 = (const std::string *)((char *)v18 + 24) )
            {
              if ( parent->px
                && (v15 = (unsigned __int64)v10,
                    (v17.px = (boost::shared_ptr<RBX::Instance>::element_type *)RBX::Instance::findConstFirstChildByName(
                                                                                  parent->px,
                                                                                  v10)) != 0)
                && (v15 = (unsigned __int64)v18,
                    (v17.px = (boost::shared_ptr<RBX::Instance>::element_type *)RBX::Instance::findConstFirstChildByName(
                                                                                  v17.px,
                                                                                  v18)) != 0) )
              {
                v15 = (unsigned __int64)v17.px;
                v17 = RBX::Instance::clone(v17.px, RBX::CreatorRole::EngineCreator);
                if ( (_QWORD)v22 )
                {
                  v23 = v22;
                  if ( *((_QWORD *)&v22 + 1) )
                    _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u);
                  v15 = (unsigned __int64)&v28;
                  (**(void (__fastcall ***)(RBX::HumanoidDefaultInstances *, __int64 *, __int128 *))v25)(
                    v25,
                    &v28,
                    &v23);
                  v20 = (volatile signed __int32 *)*((_QWORD *)&v23 + 1);
                  if ( *((_QWORD *)&v23 + 1) )
                  {
                    if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v23 + 1) + 8LL), 1u) )
                    {
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 16LL))(v20);
                      if ( !_InterlockedSub(v20 + 3, 1u) )
                        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 24LL))(v20);
                    }
                  }
                }
              }
              else
              {
                v22 = 0;
              }
              if ( *((_QWORD *)&v22 + 1) )
              {
                if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 8LL), 1u) )
                {
                  (*(void (__fastcall **)(_QWORD, unsigned __int64, boost::detail::sp_counted_base *))(**((_QWORD **)&v22 + 1) + 16LL))(
                    *((_QWORD *)&v22 + 1),
                    v15,
                    v17.pn.pi_);
                  if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v22 + 1) + 12LL), 1u) )
                    (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v22 + 1) + 24LL))(*((_QWORD *)&v22 + 1));
                }
              }
            }
          }
        }
      }
    }
    v21 = v29;
    if ( v29 )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(v29 + 12), 1u) )
        (*(void (__fastcall **)(__int64))(*(_QWORD *)v21 + 24LL))(v21);
    }
  }
}


// Address: 0x10d7830 | Name: _ZN3RBX24HumanoidDefaultBodyPartsC2Ev
void __fastcall RBX::HumanoidDefaultBodyParts::HumanoidDefaultBodyParts(RBX::HumanoidDefaultBodyParts *this)
{
  __int128 v1; // [rsp+0h] [rbp-28h] BYREF
  void *ptr; // [rsp+10h] [rbp-18h]

  ptr = operator new(0x20u);
  v1 = *(_OWORD *)&userJoinData.vtable;
  strcpy((char *)ptr, "HumanoidDefaultBodyParts");
  *(_QWORD *)this = &off_28952E8;
  std::string::basic_string((char *)this + 8, &v1);
  if ( (v1 & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)this = &off_2895300;
}


// Address: 0x10d78c0 | Name: _ZN3RBX24HumanoidDefaultBodyPartsC2ERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
void __fastcall RBX::HumanoidDefaultBodyParts::HumanoidDefaultBodyParts(
        RBX::HumanoidDefaultBodyParts *this,
        const std::string *folder)
{
  *(_QWORD *)this = &off_28952E8;
  std::string::basic_string((char *)this + 8, folder);
  *(_QWORD *)this = &off_2895300;
}


// Address: 0x10d78f0 | Name: _ZN3RBX24HumanoidDefaultBodyParts5cacheERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidDefaultBodyParts::cache(
        RBX::HumanoidDefaultBodyParts *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  RBX::DataModelMesh *HeadMesh; // rax
  RBX::Instance *HeadDecal; // rax

  if ( !RBX::Instance::findConstFirstChildByName(parent->px, (RBX::HumanoidDefaultBodyParts *)((char *)this + 8)) )
  {
    HeadMesh = RBX::Humanoid::getHeadMesh(humanoid);
    RBX::HumanoidDefaultInstances::addInstance(this, HeadMesh, parent);
    HeadDecal = (RBX::Instance *)RBX::Humanoid::getHeadDecal(humanoid);
    RBX::HumanoidDefaultInstances::addInstance(this, HeadDecal, parent);
  }
}


// Address: 0x10d7950 | Name: _ZN3RBX24HumanoidDefaultBodyParts19getAllBodyPartNamesEv
RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *__cdecl RBX::HumanoidDefaultBodyParts::getAllBodyPartNames()
{
  _DWORD *v1; // rax
  __int64 v2; // rdi
  void **v3; // rbx
  void **v4; // rax
  void **v5; // rbp
  void *v6; // rdi
  void **v7; // rbx
  void **v8; // rax
  void **v9; // rbp
  void *v10; // rdi
  void **v11; // rbx
  void **v12; // rax
  void **v13; // rbp
  void *v14; // rdi
  void **v15; // rbx
  void **v16; // rax
  void **v17; // rbp
  void *v18; // rdi
  void *v19[2]; // [rsp+0h] [rbp-E8h] BYREF
  char *v20; // [rsp+10h] [rbp-D8h]
  void *v21[2]; // [rsp+20h] [rbp-C8h] BYREF
  char *v22; // [rsp+30h] [rbp-B8h]
  __int128 v23; // [rsp+40h] [rbp-A8h] BYREF
  void *v24; // [rsp+50h] [rbp-98h]
  __int128 v25; // [rsp+60h] [rbp-88h] BYREF
  void *v26; // [rsp+70h] [rbp-78h]
  int v27; // [rsp+78h] [rbp-70h]
  void *v28; // [rsp+80h] [rbp-68h] BYREF
  void **v29; // [rsp+88h] [rbp-60h]
  int v30; // [rsp+98h] [rbp-50h]
  void *ptr; // [rsp+A0h] [rbp-48h] BYREF
  void **v32; // [rsp+A8h] [rbp-40h]

  if ( !(_BYTE)byte_2A08C18 && __cxa_guard_acquire(&byte_2A08C18) )
  {
    v25 = 0;
    v26 = 0;
    LOBYTE(v25) = 8;
    *(_DWORD *)((char *)&v25 + 1) = 1752393037;
    BYTE5(v25) = 0;
    v21[1] = operator new(0x18u);
    v21[0] = v21[1];
    v22 = (char *)v21[1] + 24;
    std::string::basic_string(v21[1], &v25);
    v21[1] = (char *)v21[1] + 24;
    v27 = 17;
    std::vector<std::string>::vector((std::vector<std::string> *)&v28, (const std::vector<std::string> *)v21);
    v23 = 0;
    v24 = 0;
    LOBYTE(v23) = 8;
    *(_DWORD *)((char *)&v23 + 1) = 1701011814;
    BYTE5(v23) = 0;
    v19[1] = operator new(0x18u);
    v19[0] = v19[1];
    v20 = (char *)v19[1] + 24;
    std::string::basic_string(v19[1], &v23);
    v19[1] = (char *)v19[1] + 24;
    v30 = 18;
    std::vector<std::string>::vector((std::vector<std::string> *)&ptr, (const std::vector<std::string> *)v19);
    allAssetsToParts = 0;
    qword_2A08C10 = 0;
    v1 = operator new(0x40u);
    *(&allAssetsToParts + 1) = v1;
    allAssetsToParts = v1;
    qword_2A08C10 = (__int64)(v1 + 16);
    *v1 = v27;
    std::vector<std::string>::vector((std::vector<std::string> *)(v1 + 2), (const std::vector<std::string> *)&v28);
    v2 = *(&allAssetsToParts + 1);
    *(&allAssetsToParts + 1) += 32LL;
    *(_DWORD *)(v2 + 32) = v30;
    std::vector<std::string>::vector((std::vector<std::string> *)(v2 + 40), (const std::vector<std::string> *)&ptr);
    *(&allAssetsToParts + 1) += 32LL;
    v3 = (void **)ptr;
    if ( ptr )
    {
      v4 = v32;
      if ( v32 == ptr )
      {
        v6 = ptr;
      }
      else
      {
        do
        {
          v5 = v4 - 3;
          if ( (*(_BYTE *)(v4 - 3) & 1) != 0 )
            operator delete(*(v4 - 1));
          v4 = v5;
        }
        while ( v3 != v5 );
        v6 = ptr;
      }
      v32 = v3;
      operator delete(v6);
    }
    v7 = (void **)v28;
    if ( v28 )
    {
      v8 = v29;
      if ( v29 == v28 )
      {
        v10 = v28;
      }
      else
      {
        do
        {
          v9 = v8 - 3;
          if ( (*(_BYTE *)(v8 - 3) & 1) != 0 )
            operator delete(*(v8 - 1));
          v8 = v9;
        }
        while ( v7 != v9 );
        v10 = v28;
      }
      v29 = v7;
      operator delete(v10);
    }
    v11 = (void **)v19[0];
    if ( v19[0] )
    {
      v12 = (void **)v19[1];
      if ( v19[1] == v19[0] )
      {
        v14 = v19[0];
      }
      else
      {
        do
        {
          v13 = v12 - 3;
          if ( (*(_BYTE *)(v12 - 3) & 1) != 0 )
            operator delete(*(v12 - 1));
          v12 = v13;
        }
        while ( v11 != v13 );
        v14 = v19[0];
      }
      v19[1] = v11;
      operator delete(v14);
    }
    if ( (v23 & 1) != 0 )
      operator delete(v24);
    v15 = (void **)v21[0];
    if ( v21[0] )
    {
      v16 = (void **)v21[1];
      if ( v21[1] == v21[0] )
      {
        v18 = v21[0];
      }
      else
      {
        do
        {
          v17 = v16 - 3;
          if ( (*(_BYTE *)(v16 - 3) & 1) != 0 )
            operator delete(*(v16 - 1));
          v16 = v17;
        }
        while ( v15 != v17 );
        v18 = v21[0];
      }
      v21[1] = v15;
      operator delete(v18);
    }
    if ( (v25 & 1) != 0 )
      operator delete(v26);
    __cxa_atexit(
      (void (*)(void *))std::__vector_base<std::pair<RBX::AssetService::AssetType,std::vector<std::string> const>>::~__vector_base,
      &allAssetsToParts,
      &dso_handle);
    __cxa_guard_release(&byte_2A08C18);
  }
  return (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&allAssetsToParts;
}


// Address: 0x10d7fb0 | Name: _ZN3RBX24HumanoidDefaultBodyParts5applyERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEERKNS4_INS_19HumanoidDescriptionEEESC_
void __fastcall RBX::HumanoidDefaultBodyParts::apply(
        RBX::HumanoidDefaultBodyParts *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent,
        const boost::shared_ptr<RBX::HumanoidDescription> *prev,
        const boost::shared_ptr<RBX::HumanoidDescription> *next)
{
  RBX::HumanoidDefaultBodyParts::getAllBodyPartNames();
  RBX::HumanoidDefaultInstances::applyInternal(
    this,
    humanoid,
    (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&allAssetsToParts,
    parent,
    prev,
    next);
}


// Address: 0x10d8000 | Name: _ZN3RBX24HumanoidDefaultBodyParts9setParentERKN5boost8weak_ptrINS_13ModelInstanceEEENS1_10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidDefaultBodyParts::setParent(
        RBX::HumanoidDefaultBodyParts *this,
        const boost::weak_ptr<RBX::ModelInstance> *character,
        boost::shared_ptr<RBX::Instance> instance)
{
  boost::detail::sp_counted_base *px; // rax
  int64_t v4; // rax
  int64_t v5; // rcx
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::Instance> i; // [rsp+8h] [rbp-20h] BYREF

  i.px = (boost::shared_ptr<RBX::Instance>::element_type *)instance.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)instance.px->weak_this_.px;
  i.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->use_count_, 1u);
  v4 = RBX::HumanoidDescription::nullAssetId();
  RBX::HumanoidAssetSwapper::setAppearanceParent(character, (boost::shared_ptr<RBX::Instance>)__PAIR128__(v4, &i), v5);
  pi = i.pn.pi_;
  if ( i.pn.pi_ && !_InterlockedSub(&i.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10d80c0 | Name: _ZN3RBX27HumanoidDefaultBodyPartsR15C2Ev
void __fastcall RBX::HumanoidDefaultBodyPartsR15::HumanoidDefaultBodyPartsR15(RBX::HumanoidDefaultBodyPartsR15 *this)
{
  __int128 v1; // [rsp+0h] [rbp-28h] BYREF
  void *ptr; // [rsp+10h] [rbp-18h]

  ptr = operator new(0x20u);
  v1 = xmmword_3E5420;
  strcpy((char *)ptr, "HumanoidDefaultBodyPartsR15");
  *(_QWORD *)this = &off_28952E8;
  std::string::basic_string((char *)this + 8, &v1);
  *(_QWORD *)this = &off_2895300;
  if ( (v1 & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)this = &off_2895338;
}


// Address: 0x10d8160 | Name: _ZN3RBX27HumanoidDefaultBodyPartsR1519getAllBodyPartNamesEv
RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *__cdecl RBX::HumanoidDefaultBodyPartsR15::getAllBodyPartNames()
{
  _DWORD *v1; // rax
  __int64 v2; // rdi
  __int64 v3; // rdi
  __int64 v4; // rdi
  __int64 v5; // rdi
  void **v6; // rbx
  void **v7; // rax
  void **v8; // rbp
  void *v9; // rdi
  void **v10; // rbx
  void **v11; // rax
  void **v12; // rbp
  void *v13; // rdi
  void **v14; // rbx
  void **v15; // rax
  void **v16; // rbp
  void *v17; // rdi
  void **v18; // rbx
  void **v19; // rax
  void **v20; // rbp
  void *v21; // rdi
  void **v22; // rbx
  void **v23; // rax
  void **v24; // rbp
  void *v25; // rdi
  void **v26; // rbx
  void **v27; // rax
  void **v28; // rbp
  void *v29; // rdi
  void **v30; // rbx
  void **v31; // rax
  void **v32; // rbp
  void *v33; // rdi
  void **v34; // rbx
  void **v35; // rax
  void **v36; // rbp
  void *v37; // rdi
  void **v38; // rbx
  void **v39; // rax
  void **v40; // rbp
  void *v41; // rdi
  void **v42; // rbx
  void **v43; // rax
  void **v44; // rbp
  void *v45; // rdi
  void *v46[2]; // [rsp+0h] [rbp-2B8h] BYREF
  char *v47; // [rsp+10h] [rbp-2A8h]
  void *v48[2]; // [rsp+20h] [rbp-298h] BYREF
  char *v49; // [rsp+30h] [rbp-288h]
  void *v50[2]; // [rsp+40h] [rbp-278h] BYREF
  char *v51; // [rsp+50h] [rbp-268h]
  void *v52[2]; // [rsp+60h] [rbp-258h] BYREF
  char *v53; // [rsp+70h] [rbp-248h]
  void *v54[2]; // [rsp+80h] [rbp-238h] BYREF
  char *v55; // [rsp+90h] [rbp-228h]
  int v56; // [rsp+98h] [rbp-220h]
  void *v57; // [rsp+A0h] [rbp-218h] BYREF
  void **v58; // [rsp+A8h] [rbp-210h]
  int v59; // [rsp+B8h] [rbp-200h]
  void *v60; // [rsp+C0h] [rbp-1F8h] BYREF
  void **v61; // [rsp+C8h] [rbp-1F0h]
  int v62; // [rsp+D8h] [rbp-1E0h]
  void *v63; // [rsp+E0h] [rbp-1D8h] BYREF
  void **v64; // [rsp+E8h] [rbp-1D0h]
  int v65; // [rsp+F8h] [rbp-1C0h]
  void *v66; // [rsp+100h] [rbp-1B8h] BYREF
  void **v67; // [rsp+108h] [rbp-1B0h]
  int v68; // [rsp+118h] [rbp-1A0h]
  void *ptr; // [rsp+120h] [rbp-198h] BYREF
  void **v70; // [rsp+128h] [rbp-190h]
  _BYTE v71[16]; // [rsp+138h] [rbp-180h] BYREF
  void *v72; // [rsp+148h] [rbp-170h]
  _BYTE v73[16]; // [rsp+150h] [rbp-168h] BYREF
  void *v74; // [rsp+160h] [rbp-158h]
  _BYTE v75[16]; // [rsp+168h] [rbp-150h] BYREF
  void *v76; // [rsp+178h] [rbp-140h]
  _BYTE v77[16]; // [rsp+180h] [rbp-138h] BYREF
  void *v78; // [rsp+190h] [rbp-128h]
  _BYTE v79[16]; // [rsp+198h] [rbp-120h] BYREF
  void *v80; // [rsp+1A8h] [rbp-110h]
  _BYTE v81[16]; // [rsp+1B0h] [rbp-108h] BYREF
  void *v82; // [rsp+1C0h] [rbp-F8h]
  _BYTE v83[16]; // [rsp+1C8h] [rbp-F0h] BYREF
  void *v84; // [rsp+1D8h] [rbp-E0h]
  _BYTE v85[16]; // [rsp+1E0h] [rbp-D8h] BYREF
  void *v86; // [rsp+1F0h] [rbp-C8h]
  _BYTE v87[16]; // [rsp+1F8h] [rbp-C0h] BYREF
  void *v88; // [rsp+208h] [rbp-B0h]
  _BYTE v89[16]; // [rsp+210h] [rbp-A8h] BYREF
  void *v90; // [rsp+220h] [rbp-98h]
  _BYTE v91[16]; // [rsp+228h] [rbp-90h] BYREF
  void *v92; // [rsp+238h] [rbp-80h]
  _BYTE v93[16]; // [rsp+240h] [rbp-78h] BYREF
  void *v94; // [rsp+250h] [rbp-68h]
  _BYTE v95[16]; // [rsp+258h] [rbp-60h] BYREF
  void *v96; // [rsp+268h] [rbp-50h]
  _BYTE v97[16]; // [rsp+270h] [rbp-48h] BYREF
  void *v98; // [rsp+280h] [rbp-38h]

  if ( (_BYTE)byte_2A08C38 || !__cxa_guard_acquire(&byte_2A08C38) )
    return (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&xmmword_2A08C20;
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v71, RBX::Humanoid::R15PartType::R15_LOWER_TORSO);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v73, RBX::Humanoid::R15PartType::R15_UPPER_TORSO);
  v54[1] = operator new(0x30u);
  v54[0] = v54[1];
  v55 = (char *)v54[1] + 48;
  std::string::basic_string(v54[1], v71);
  v54[1] = (char *)v54[1] + 24;
  std::string::basic_string(v54[1], v73);
  v54[1] = (char *)v54[1] + 24;
  v56 = 27;
  std::vector<std::string>::vector((std::vector<std::string> *)&v57, (const std::vector<std::string> *)v54);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v93, RBX::Humanoid::R15PartType::R15_LEFT_UPPER_ARM);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v95, RBX::Humanoid::R15PartType::R15_LEFT_LOWER_ARM);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v97, RBX::Humanoid::R15PartType::R15_LEFT_HAND);
  v52[1] = operator new(0x48u);
  v52[0] = v52[1];
  v53 = (char *)v52[1] + 72;
  std::string::basic_string(v52[1], v93);
  v52[1] = (char *)v52[1] + 24;
  std::string::basic_string(v52[1], v95);
  v52[1] = (char *)v52[1] + 24;
  std::string::basic_string(v52[1], v97);
  v52[1] = (char *)v52[1] + 24;
  v59 = 29;
  std::vector<std::string>::vector((std::vector<std::string> *)&v60, (const std::vector<std::string> *)v52);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v87, RBX::Humanoid::R15PartType::R15_RIGHT_UPPER_ARM);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v89, RBX::Humanoid::R15PartType::R15_RIGHT_LOWER_ARM);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v91, RBX::Humanoid::R15PartType::R15_RIGHT_HAND);
  v50[1] = operator new(0x48u);
  v50[0] = v50[1];
  v51 = (char *)v50[1] + 72;
  std::string::basic_string(v50[1], v87);
  v50[1] = (char *)v50[1] + 24;
  std::string::basic_string(v50[1], v89);
  v50[1] = (char *)v50[1] + 24;
  std::string::basic_string(v50[1], v91);
  v50[1] = (char *)v50[1] + 24;
  v62 = 28;
  std::vector<std::string>::vector((std::vector<std::string> *)&v63, (const std::vector<std::string> *)v50);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v81, RBX::Humanoid::R15PartType::R15_LEFT_UPPER_LEG);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v83, RBX::Humanoid::R15PartType::R15_LEFT_LOWER_LEG);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v85, RBX::Humanoid::R15PartType::R15_LEFT_FOOT);
  v48[1] = operator new(0x48u);
  v48[0] = v48[1];
  v49 = (char *)v48[1] + 72;
  std::string::basic_string(v48[1], v81);
  v48[1] = (char *)v48[1] + 24;
  std::string::basic_string(v48[1], v83);
  v48[1] = (char *)v48[1] + 24;
  std::string::basic_string(v48[1], v85);
  v48[1] = (char *)v48[1] + 24;
  v65 = 30;
  std::vector<std::string>::vector((std::vector<std::string> *)&v66, (const std::vector<std::string> *)v48);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v75, RBX::Humanoid::R15PartType::R15_RIGHT_UPPER_LEG);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v77, RBX::Humanoid::R15PartType::R15_RIGHT_LOWER_LEG);
  RBX::Humanoid::getR15PartNameFromType((RBX::Humanoid *)v79, RBX::Humanoid::R15PartType::R15_RIGHT_FOOT);
  v46[1] = operator new(0x48u);
  v46[0] = v46[1];
  v47 = (char *)v46[1] + 72;
  std::string::basic_string(v46[1], v75);
  v46[1] = (char *)v46[1] + 24;
  std::string::basic_string(v46[1], v77);
  v46[1] = (char *)v46[1] + 24;
  std::string::basic_string(v46[1], v79);
  v46[1] = (char *)v46[1] + 24;
  v68 = 31;
  std::vector<std::string>::vector((std::vector<std::string> *)&ptr, (const std::vector<std::string> *)v46);
  xmmword_2A08C20 = 0;
  qword_2A08C30 = 0;
  v1 = operator new(0xA0u);
  *(&xmmword_2A08C20 + 1) = v1;
  xmmword_2A08C20 = v1;
  qword_2A08C30 = (__int64)(v1 + 40);
  *v1 = v56;
  std::vector<std::string>::vector((std::vector<std::string> *)(v1 + 2), (const std::vector<std::string> *)&v57);
  v2 = *(&xmmword_2A08C20 + 1);
  *(&xmmword_2A08C20 + 1) += 32LL;
  *(_DWORD *)(v2 + 32) = v59;
  std::vector<std::string>::vector((std::vector<std::string> *)(v2 + 40), (const std::vector<std::string> *)&v60);
  v3 = *(&xmmword_2A08C20 + 1);
  *(&xmmword_2A08C20 + 1) += 32LL;
  *(_DWORD *)(v3 + 32) = v62;
  std::vector<std::string>::vector((std::vector<std::string> *)(v3 + 40), (const std::vector<std::string> *)&v63);
  v4 = *(&xmmword_2A08C20 + 1);
  *(&xmmword_2A08C20 + 1) += 32LL;
  *(_DWORD *)(v4 + 32) = v65;
  std::vector<std::string>::vector((std::vector<std::string> *)(v4 + 40), (const std::vector<std::string> *)&v66);
  v5 = *(&xmmword_2A08C20 + 1);
  *(&xmmword_2A08C20 + 1) += 32LL;
  *(_DWORD *)(v5 + 32) = v68;
  std::vector<std::string>::vector((std::vector<std::string> *)(v5 + 40), (const std::vector<std::string> *)&ptr);
  *(&xmmword_2A08C20 + 1) += 32LL;
  v6 = (void **)ptr;
  if ( ptr )
  {
    v7 = v70;
    if ( v70 == ptr )
    {
      v9 = ptr;
    }
    else
    {
      do
      {
        v8 = v7 - 3;
        if ( (*(_BYTE *)(v7 - 3) & 1) != 0 )
          operator delete(*(v7 - 1));
        v7 = v8;
      }
      while ( v6 != v8 );
      v9 = ptr;
    }
    v70 = v6;
    operator delete(v9);
  }
  v10 = (void **)v66;
  if ( v66 )
  {
    v11 = v67;
    if ( v67 == v66 )
    {
      v13 = v66;
    }
    else
    {
      do
      {
        v12 = v11 - 3;
        if ( (*(_BYTE *)(v11 - 3) & 1) != 0 )
          operator delete(*(v11 - 1));
        v11 = v12;
      }
      while ( v10 != v12 );
      v13 = v66;
    }
    v67 = v10;
    operator delete(v13);
  }
  v14 = (void **)v63;
  if ( v63 )
  {
    v15 = v64;
    if ( v64 == v63 )
    {
      v17 = v63;
    }
    else
    {
      do
      {
        v16 = v15 - 3;
        if ( (*(_BYTE *)(v15 - 3) & 1) != 0 )
          operator delete(*(v15 - 1));
        v15 = v16;
      }
      while ( v14 != v16 );
      v17 = v63;
    }
    v64 = v14;
    operator delete(v17);
  }
  v18 = (void **)v60;
  if ( v60 )
  {
    v19 = v61;
    if ( v61 == v60 )
    {
      v21 = v60;
    }
    else
    {
      do
      {
        v20 = v19 - 3;
        if ( (*(_BYTE *)(v19 - 3) & 1) != 0 )
          operator delete(*(v19 - 1));
        v19 = v20;
      }
      while ( v18 != v20 );
      v21 = v60;
    }
    v61 = v18;
    operator delete(v21);
  }
  v22 = (void **)v57;
  if ( v57 )
  {
    v23 = v58;
    if ( v58 == v57 )
    {
      v25 = v57;
    }
    else
    {
      do
      {
        v24 = v23 - 3;
        if ( (*(_BYTE *)(v23 - 3) & 1) != 0 )
          operator delete(*(v23 - 1));
        v23 = v24;
      }
      while ( v22 != v24 );
      v25 = v57;
    }
    v58 = v22;
    operator delete(v25);
  }
  v26 = (void **)v46[0];
  if ( v46[0] )
  {
    v27 = (void **)v46[1];
    if ( v46[1] == v46[0] )
    {
      v29 = v46[0];
    }
    else
    {
      do
      {
        v28 = v27 - 3;
        if ( (*(_BYTE *)(v27 - 3) & 1) != 0 )
          operator delete(*(v27 - 1));
        v27 = v28;
      }
      while ( v26 != v28 );
      v29 = v46[0];
    }
    v46[1] = v26;
    operator delete(v29);
  }
  if ( (v79[0] & 1) != 0 )
  {
    operator delete(v80);
    if ( (v77[0] & 1) == 0 )
    {
LABEL_54:
      if ( (v75[0] & 1) == 0 )
        goto LABEL_56;
      goto LABEL_55;
    }
  }
  else if ( (v77[0] & 1) == 0 )
  {
    goto LABEL_54;
  }
  operator delete(v78);
  if ( (v75[0] & 1) != 0 )
LABEL_55:
    operator delete(v76);
LABEL_56:
  v30 = (void **)v48[0];
  if ( v48[0] )
  {
    v31 = (void **)v48[1];
    if ( v48[1] == v48[0] )
    {
      v33 = v48[0];
    }
    else
    {
      do
      {
        v32 = v31 - 3;
        if ( (*(_BYTE *)(v31 - 3) & 1) != 0 )
          operator delete(*(v31 - 1));
        v31 = v32;
      }
      while ( v30 != v32 );
      v33 = v48[0];
    }
    v48[1] = v30;
    operator delete(v33);
  }
  if ( (v85[0] & 1) != 0 )
  {
    operator delete(v86);
    if ( (v83[0] & 1) == 0 )
    {
LABEL_69:
      if ( (v81[0] & 1) == 0 )
        goto LABEL_71;
      goto LABEL_70;
    }
  }
  else if ( (v83[0] & 1) == 0 )
  {
    goto LABEL_69;
  }
  operator delete(v84);
  if ( (v81[0] & 1) != 0 )
LABEL_70:
    operator delete(v82);
LABEL_71:
  v34 = (void **)v50[0];
  if ( v50[0] )
  {
    v35 = (void **)v50[1];
    if ( v50[1] == v50[0] )
    {
      v37 = v50[0];
    }
    else
    {
      do
      {
        v36 = v35 - 3;
        if ( (*(_BYTE *)(v35 - 3) & 1) != 0 )
          operator delete(*(v35 - 1));
        v35 = v36;
      }
      while ( v34 != v36 );
      v37 = v50[0];
    }
    v50[1] = v34;
    operator delete(v37);
  }
  if ( (v91[0] & 1) != 0 )
  {
    operator delete(v92);
    if ( (v89[0] & 1) == 0 )
    {
LABEL_84:
      if ( (v87[0] & 1) == 0 )
        goto LABEL_86;
      goto LABEL_85;
    }
  }
  else if ( (v89[0] & 1) == 0 )
  {
    goto LABEL_84;
  }
  operator delete(v90);
  if ( (v87[0] & 1) != 0 )
LABEL_85:
    operator delete(v88);
LABEL_86:
  v38 = (void **)v52[0];
  if ( v52[0] )
  {
    v39 = (void **)v52[1];
    if ( v52[1] == v52[0] )
    {
      v41 = v52[0];
    }
    else
    {
      do
      {
        v40 = v39 - 3;
        if ( (*(_BYTE *)(v39 - 3) & 1) != 0 )
          operator delete(*(v39 - 1));
        v39 = v40;
      }
      while ( v38 != v40 );
      v41 = v52[0];
    }
    v52[1] = v38;
    operator delete(v41);
  }
  if ( (v97[0] & 1) == 0 )
  {
    if ( (v95[0] & 1) == 0 )
      goto LABEL_99;
LABEL_108:
    operator delete(v96);
    if ( (v93[0] & 1) == 0 )
      goto LABEL_101;
    goto LABEL_100;
  }
  operator delete(v98);
  if ( (v95[0] & 1) != 0 )
    goto LABEL_108;
LABEL_99:
  if ( (v93[0] & 1) != 0 )
LABEL_100:
    operator delete(v94);
LABEL_101:
  v42 = (void **)v54[0];
  if ( v54[0] )
  {
    v43 = (void **)v54[1];
    if ( v54[1] == v54[0] )
    {
      v45 = v54[0];
    }
    else
    {
      do
      {
        v44 = v43 - 3;
        if ( (*(_BYTE *)(v43 - 3) & 1) != 0 )
          operator delete(*(v43 - 1));
        v43 = v44;
      }
      while ( v42 != v44 );
      v45 = v54[0];
    }
    v54[1] = v42;
    operator delete(v45);
  }
  if ( (v73[0] & 1) != 0 )
    operator delete(v74);
  if ( (v71[0] & 1) != 0 )
    operator delete(v72);
  __cxa_atexit(
    (void (*)(void *))std::__vector_base<std::pair<RBX::AssetService::AssetType,std::vector<std::string> const>>::~__vector_base,
    &xmmword_2A08C20,
    &dso_handle);
  __cxa_guard_release(&byte_2A08C38);
  return (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&xmmword_2A08C20;
}


// Address: 0x10d94f0 | Name: _ZN3RBX27HumanoidDefaultBodyPartsR155cacheERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidDefaultBodyPartsR15::cache(
        RBX::HumanoidDefaultBodyPartsR15 *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  RBX::DataModelMesh *HeadMesh; // rax
  RBX::Instance *HeadDecal; // rax
  RBX::ModelInstance *CharacterFromHumanoid; // rax
  const RBX::Instance *v7; // r15
  __int64 v8; // r13
  const std::string *v9; // rbx
  const std::string *j; // rbp
  RBX::Instance *ConstFirstChildByName; // rax
  __int64 i; // [rsp+0h] [rbp-38h]

  if ( !RBX::Instance::findConstFirstChildByName(parent->px, (RBX::HumanoidDefaultBodyPartsR15 *)((char *)this + 8))
    && *((_DWORD *)humanoid + 177) )
  {
    if ( !RBX::Instance::findConstFirstChildByName(parent->px, (RBX::HumanoidDefaultBodyPartsR15 *)((char *)this + 8)) )
    {
      HeadMesh = RBX::Humanoid::getHeadMesh(humanoid);
      RBX::HumanoidDefaultInstances::addInstance(this, HeadMesh, parent);
      HeadDecal = (RBX::Instance *)RBX::Humanoid::getHeadDecal(humanoid);
      RBX::HumanoidDefaultInstances::addInstance(this, HeadDecal, parent);
    }
    CharacterFromHumanoid = RBX::Humanoid::getCharacterFromHumanoid(humanoid);
    if ( CharacterFromHumanoid )
    {
      v7 = (const RBX::Instance *)CharacterFromHumanoid;
      RBX::HumanoidDefaultBodyPartsR15::getAllBodyPartNames();
      v8 = xmmword_2A08C20;
      for ( i = *(&xmmword_2A08C20 + 1); v8 != i; v8 += 32 )
      {
        v9 = *(const std::string **)(v8 + 8);
        for ( j = *(const std::string **)(v8 + 16); j != v9; v9 = (const std::string *)((char *)v9 + 24) )
        {
          ConstFirstChildByName = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(v7, v9);
          RBX::HumanoidDefaultInstances::addInstance(this, ConstFirstChildByName, parent);
        }
      }
    }
  }
}


// Address: 0x10d95f0 | Name: _ZN3RBX27HumanoidDefaultBodyPartsR155applyERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEERKNS4_INS_19HumanoidDescriptionEEESC_
void __fastcall RBX::HumanoidDefaultBodyPartsR15::apply(
        RBX::HumanoidDefaultBodyPartsR15 *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent,
        const boost::shared_ptr<RBX::HumanoidDescription> *prev,
        const boost::shared_ptr<RBX::HumanoidDescription> *next)
{
  if ( *((_DWORD *)humanoid + 177) )
  {
    RBX::HumanoidDefaultBodyParts::getAllBodyPartNames();
    RBX::HumanoidDefaultInstances::applyInternal(
      this,
      humanoid,
      (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&allAssetsToParts,
      parent,
      prev,
      next);
    RBX::HumanoidDefaultBodyPartsR15::getAllBodyPartNames();
    RBX::HumanoidDefaultInstances::applyInternal(
      this,
      humanoid,
      (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&xmmword_2A08C20,
      parent,
      prev,
      next);
  }
}


// Address: 0x10d9670 | Name: _ZN3RBX25HumanoidDefaultAnimationsC2Ev
void __fastcall RBX::HumanoidDefaultAnimations::HumanoidDefaultAnimations(RBX::HumanoidDefaultAnimations *this)
{
  __int128 v1; // [rsp+0h] [rbp-28h] BYREF
  void *ptr; // [rsp+10h] [rbp-18h]

  ptr = operator new(0x20u);
  v1 = xmmword_3E5070;
  strcpy((char *)ptr, "HumanoidDefaultAnimations");
  *(_QWORD *)this = &off_28952E8;
  std::string::basic_string((char *)this + 8, &v1);
  if ( (v1 & 1) != 0 )
    operator delete(ptr);
  *(_QWORD *)this = &off_2895370;
}


// Address: 0x10d9700 | Name: _ZN3RBX25HumanoidDefaultAnimations15getAllAnimNamesEv
RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *__cdecl RBX::HumanoidDefaultAnimations::getAllAnimNames()
{
  _DWORD *v1; // rax
  __int64 v2; // rdi
  __int64 v3; // rdi
  __int64 v4; // rdi
  __int64 v5; // rdi
  __int64 v6; // rdi
  __int64 v7; // rdi
  char *v8; // r12
  int *v9; // r15
  __int64 v10; // rbx
  __int64 v11; // rax
  __int64 v12; // rbp
  void *v13; // rdi
  void **v14; // rbx
  void **v15; // rax
  void **v16; // rbp
  void *v17; // rdi
  void **v18; // rbx
  void **v19; // rax
  void **v20; // rbp
  void *v21; // rdi
  void **v22; // rbx
  void **v23; // rax
  void **v24; // rbp
  void *v25; // rdi
  void **v26; // rbx
  void **v27; // rax
  void **v28; // rbp
  void *v29; // rdi
  void **v30; // rbx
  void **v31; // rax
  void **v32; // rbp
  void *v33; // rdi
  void **v34; // rbx
  void **v35; // rax
  void **v36; // rbp
  void *v37; // rdi
  void **v38; // rbx
  void **v39; // rax
  void **v40; // rbp
  void *v41; // rdi
  void *v42[2]; // [rsp+0h] [rbp-2D8h] BYREF
  char *v43; // [rsp+10h] [rbp-2C8h]
  void *ptr[2]; // [rsp+20h] [rbp-2B8h] BYREF
  char *v45; // [rsp+30h] [rbp-2A8h]
  void *v46[2]; // [rsp+40h] [rbp-298h] BYREF
  char *v47; // [rsp+50h] [rbp-288h]
  void *v48[2]; // [rsp+60h] [rbp-278h] BYREF
  char *v49; // [rsp+70h] [rbp-268h]
  void *v50[2]; // [rsp+80h] [rbp-258h] BYREF
  char *v51; // [rsp+90h] [rbp-248h]
  void *v52[2]; // [rsp+A0h] [rbp-238h] BYREF
  char *v53; // [rsp+B0h] [rbp-228h]
  void *v54[2]; // [rsp+C0h] [rbp-218h] BYREF
  char *v55; // [rsp+D0h] [rbp-208h]
  __int128 v56; // [rsp+E0h] [rbp-1F8h] BYREF
  void *v57; // [rsp+F0h] [rbp-1E8h]
  __int128 v58; // [rsp+100h] [rbp-1D8h] BYREF
  void *v59; // [rsp+110h] [rbp-1C8h]
  char v60; // [rsp+118h] [rbp-1C0h] BYREF
  char v61[9]; // [rsp+119h] [rbp-1BFh] BYREF
  __int16 v62; // [rsp+122h] [rbp-1B6h]
  int v63; // [rsp+124h] [rbp-1B4h]
  void *v64; // [rsp+128h] [rbp-1B0h]
  __int128 v65; // [rsp+130h] [rbp-1A8h] BYREF
  void *v66; // [rsp+140h] [rbp-198h]
  __int128 v67; // [rsp+150h] [rbp-188h] BYREF
  void *v68; // [rsp+160h] [rbp-178h]
  __int128 v69; // [rsp+170h] [rbp-168h] BYREF
  void *v70; // [rsp+180h] [rbp-158h]
  __int128 v71; // [rsp+190h] [rbp-148h] BYREF
  void *v72; // [rsp+1A0h] [rbp-138h]
  __int128 v73; // [rsp+1B0h] [rbp-128h] BYREF
  void *v74; // [rsp+1C0h] [rbp-118h]
  int v75; // [rsp+1C8h] [rbp-110h] BYREF
  _BYTE v76[24]; // [rsp+1D0h] [rbp-108h] BYREF
  int v77; // [rsp+1E8h] [rbp-F0h]
  _BYTE v78[24]; // [rsp+1F0h] [rbp-E8h] BYREF
  int v79; // [rsp+208h] [rbp-D0h]
  _BYTE v80[24]; // [rsp+210h] [rbp-C8h] BYREF
  int v81; // [rsp+228h] [rbp-B0h]
  _BYTE v82[24]; // [rsp+230h] [rbp-A8h] BYREF
  int v83; // [rsp+248h] [rbp-90h]
  _BYTE v84[24]; // [rsp+250h] [rbp-88h] BYREF
  int v85; // [rsp+268h] [rbp-70h]
  _BYTE v86[24]; // [rsp+270h] [rbp-68h] BYREF
  int v87; // [rsp+288h] [rbp-50h]
  _BYTE v88[24]; // [rsp+290h] [rbp-48h] BYREF
  char v89; // [rsp+2A8h] [rbp-30h] BYREF

  if ( !(_BYTE)byte_2A08C58 && __cxa_guard_acquire(&byte_2A08C58) )
  {
    v71 = 0;
    v72 = 0;
    strcpy((char *)&v71, "\nclimb");
    v54[1] = operator new(0x18u);
    v54[0] = v54[1];
    v55 = (char *)v54[1] + 24;
    std::string::basic_string(v54[1], &v71);
    v54[1] = (char *)v54[1] + 24;
    v75 = 48;
    std::vector<std::string>::vector((std::vector<std::string> *)v76, (const std::vector<std::string> *)v54);
    v69 = 0;
    v70 = 0;
    LOBYTE(v69) = 8;
    *(_DWORD *)((char *)&v69 + 1) = 1819042150;
    BYTE5(v69) = 0;
    v52[1] = operator new(0x18u);
    v52[0] = v52[1];
    v53 = (char *)v52[1] + 24;
    std::string::basic_string(v52[1], &v69);
    v52[1] = (char *)v52[1] + 24;
    v77 = 50;
    std::vector<std::string>::vector((std::vector<std::string> *)v78, (const std::vector<std::string> *)v52);
    v67 = 0;
    v68 = 0;
    LOBYTE(v67) = 8;
    *(_DWORD *)((char *)&v67 + 1) = 1701602409;
    BYTE5(v67) = 0;
    v50[1] = operator new(0x18u);
    v50[0] = v50[1];
    v51 = (char *)v50[1] + 24;
    std::string::basic_string(v50[1], &v67);
    v50[1] = (char *)v50[1] + 24;
    v79 = 51;
    std::vector<std::string>::vector((std::vector<std::string> *)v80, (const std::vector<std::string> *)v50);
    v65 = 0;
    v66 = 0;
    LOBYTE(v65) = 8;
    *(_DWORD *)((char *)&v65 + 1) = 1886221674;
    BYTE5(v65) = 0;
    v48[1] = operator new(0x18u);
    v48[0] = v48[1];
    v49 = (char *)v48[1] + 24;
    std::string::basic_string(v48[1], &v65);
    v48[1] = (char *)v48[1] + 24;
    v81 = 52;
    std::vector<std::string>::vector((std::vector<std::string> *)v82, (const std::vector<std::string> *)v48);
    v73 = 0;
    v74 = 0;
    LOBYTE(v73) = 6;
    *(_DWORD *)((char *)&v73 + 1) = (_DWORD)&unk_6E7572;
    v46[1] = operator new(0x18u);
    v46[0] = v46[1];
    v47 = (char *)v46[1] + 24;
    std::string::basic_string(v46[1], &v73);
    v46[1] = (char *)v46[1] + 24;
    v83 = 53;
    std::vector<std::string>::vector((std::vector<std::string> *)v84, (const std::vector<std::string> *)v46);
    v58 = 0;
    v59 = 0;
    LOBYTE(v58) = 8;
    *(_DWORD *)((char *)&v58 + 1) = 1835628403;
    BYTE5(v58) = 0;
    v61[8] = 0;
    v62 = 0;
    v63 = 0;
    v64 = 0;
    v60 = 16;
    strcpy(v61, "swimidl");
    v42[1] = operator new(0x30u);
    v42[0] = v42[1];
    v43 = (char *)v42[1] + 48;
    std::string::basic_string(v42[1], &v58);
    v42[1] = (char *)v42[1] + 24;
    std::string::basic_string(v42[1], &v60);
    v42[1] = (char *)v42[1] + 24;
    v85 = 54;
    std::vector<std::string>::vector((std::vector<std::string> *)v86, (const std::vector<std::string> *)v42);
    v56 = 0;
    v57 = 0;
    LOBYTE(v56) = 8;
    *(_DWORD *)((char *)&v56 + 1) = 1802264951;
    BYTE5(v56) = 0;
    *(_OWORD *)ptr = 0;
    v45 = 0;
    ptr[1] = operator new(0x18u);
    ptr[0] = ptr[1];
    v45 = (char *)ptr[1] + 24;
    std::string::basic_string(ptr[1], &v56);
    ptr[1] = (char *)ptr[1] + 24;
    v87 = 55;
    std::vector<std::string>::vector((std::vector<std::string> *)v88, (const std::vector<std::string> *)ptr);
    xmmword_2A08C40 = 0;
    qword_2A08C50 = 0;
    v1 = operator new(0xE0u);
    *(&xmmword_2A08C40 + 1) = v1;
    xmmword_2A08C40 = v1;
    qword_2A08C50 = (__int64)(v1 + 56);
    *v1 = v75;
    std::vector<std::string>::vector((std::vector<std::string> *)(v1 + 2), (const std::vector<std::string> *)v76);
    v2 = *(&xmmword_2A08C40 + 1);
    *(&xmmword_2A08C40 + 1) += 32LL;
    *(_DWORD *)(v2 + 32) = v77;
    std::vector<std::string>::vector((std::vector<std::string> *)(v2 + 40), (const std::vector<std::string> *)v78);
    v3 = *(&xmmword_2A08C40 + 1);
    *(&xmmword_2A08C40 + 1) += 32LL;
    *(_DWORD *)(v3 + 32) = v79;
    std::vector<std::string>::vector((std::vector<std::string> *)(v3 + 40), (const std::vector<std::string> *)v80);
    v4 = *(&xmmword_2A08C40 + 1);
    *(&xmmword_2A08C40 + 1) += 32LL;
    *(_DWORD *)(v4 + 32) = v81;
    std::vector<std::string>::vector((std::vector<std::string> *)(v4 + 40), (const std::vector<std::string> *)v82);
    v5 = *(&xmmword_2A08C40 + 1);
    *(&xmmword_2A08C40 + 1) += 32LL;
    *(_DWORD *)(v5 + 32) = v83;
    std::vector<std::string>::vector((std::vector<std::string> *)(v5 + 40), (const std::vector<std::string> *)v84);
    v6 = *(&xmmword_2A08C40 + 1);
    *(&xmmword_2A08C40 + 1) += 32LL;
    *(_DWORD *)(v6 + 32) = v85;
    std::vector<std::string>::vector((std::vector<std::string> *)(v6 + 40), (const std::vector<std::string> *)v86);
    v7 = *(&xmmword_2A08C40 + 1);
    *(&xmmword_2A08C40 + 1) += 32LL;
    *(_DWORD *)(v7 + 32) = v87;
    std::vector<std::string>::vector((std::vector<std::string> *)(v7 + 40), (const std::vector<std::string> *)v88);
    v8 = &v89;
    *(&xmmword_2A08C40 + 1) += 32LL;
    do
    {
      v9 = (int *)(v8 - 32);
      v10 = *((_QWORD *)v8 - 3);
      if ( v10 )
      {
        v11 = *((_QWORD *)v8 - 2);
        if ( v11 == v10 )
        {
          v13 = (void *)*((_QWORD *)v8 - 3);
        }
        else
        {
          do
          {
            v12 = v11 - 24;
            if ( (*(_BYTE *)(v11 - 24) & 1) != 0 )
              operator delete(*(void **)(v11 - 8));
            v11 = v12;
          }
          while ( v10 != v12 );
          v13 = (void *)*((_QWORD *)v8 - 3);
        }
        *((_QWORD *)v8 - 2) = v10;
        operator delete(v13);
      }
      v8 -= 32;
    }
    while ( v9 != &v75 );
    v14 = (void **)ptr[0];
    if ( ptr[0] )
    {
      v15 = (void **)ptr[1];
      if ( ptr[1] == ptr[0] )
      {
        v17 = ptr[0];
      }
      else
      {
        do
        {
          v16 = v15 - 3;
          if ( (*(_BYTE *)(v15 - 3) & 1) != 0 )
            operator delete(*(v15 - 1));
          v15 = v16;
        }
        while ( v14 != v16 );
        v17 = ptr[0];
      }
      ptr[1] = v14;
      operator delete(v17);
    }
    if ( (v56 & 1) != 0 )
      operator delete(v57);
    v18 = (void **)v42[0];
    if ( v42[0] )
    {
      v19 = (void **)v42[1];
      if ( v42[1] == v42[0] )
      {
        v21 = v42[0];
      }
      else
      {
        do
        {
          v20 = v19 - 3;
          if ( (*(_BYTE *)(v19 - 3) & 1) != 0 )
            operator delete(*(v19 - 1));
          v19 = v20;
        }
        while ( v18 != v20 );
        v21 = v42[0];
      }
      v42[1] = v18;
      operator delete(v21);
    }
    if ( (v60 & 1) != 0 )
      operator delete(v64);
    if ( (v58 & 1) != 0 )
      operator delete(v59);
    v22 = (void **)v46[0];
    if ( v46[0] )
    {
      v23 = (void **)v46[1];
      if ( v46[1] == v46[0] )
      {
        v25 = v46[0];
      }
      else
      {
        do
        {
          v24 = v23 - 3;
          if ( (*(_BYTE *)(v23 - 3) & 1) != 0 )
            operator delete(*(v23 - 1));
          v23 = v24;
        }
        while ( v22 != v24 );
        v25 = v46[0];
      }
      v46[1] = v22;
      operator delete(v25);
    }
    if ( (v73 & 1) != 0 )
      operator delete(v74);
    v26 = (void **)v48[0];
    if ( v48[0] )
    {
      v27 = (void **)v48[1];
      if ( v48[1] == v48[0] )
      {
        v29 = v48[0];
      }
      else
      {
        do
        {
          v28 = v27 - 3;
          if ( (*(_BYTE *)(v27 - 3) & 1) != 0 )
            operator delete(*(v27 - 1));
          v27 = v28;
        }
        while ( v26 != v28 );
        v29 = v48[0];
      }
      v48[1] = v26;
      operator delete(v29);
    }
    if ( (v65 & 1) != 0 )
      operator delete(v66);
    v30 = (void **)v50[0];
    if ( v50[0] )
    {
      v31 = (void **)v50[1];
      if ( v50[1] == v50[0] )
      {
        v33 = v50[0];
      }
      else
      {
        do
        {
          v32 = v31 - 3;
          if ( (*(_BYTE *)(v31 - 3) & 1) != 0 )
            operator delete(*(v31 - 1));
          v31 = v32;
        }
        while ( v30 != v32 );
        v33 = v50[0];
      }
      v50[1] = v30;
      operator delete(v33);
    }
    if ( (v67 & 1) != 0 )
      operator delete(v68);
    v34 = (void **)v52[0];
    if ( v52[0] )
    {
      v35 = (void **)v52[1];
      if ( v52[1] == v52[0] )
      {
        v37 = v52[0];
      }
      else
      {
        do
        {
          v36 = v35 - 3;
          if ( (*(_BYTE *)(v35 - 3) & 1) != 0 )
            operator delete(*(v35 - 1));
          v35 = v36;
        }
        while ( v34 != v36 );
        v37 = v52[0];
      }
      v52[1] = v34;
      operator delete(v37);
    }
    if ( (v69 & 1) != 0 )
      operator delete(v70);
    v38 = (void **)v54[0];
    if ( v54[0] )
    {
      v39 = (void **)v54[1];
      if ( v54[1] == v54[0] )
      {
        v41 = v54[0];
      }
      else
      {
        do
        {
          v40 = v39 - 3;
          if ( (*(_BYTE *)(v39 - 3) & 1) != 0 )
            operator delete(*(v39 - 1));
          v39 = v40;
        }
        while ( v38 != v40 );
        v41 = v54[0];
      }
      v54[1] = v38;
      operator delete(v41);
    }
    if ( (v71 & 1) != 0 )
      operator delete(v72);
    __cxa_atexit(
      (void (*)(void *))std::__vector_base<std::pair<RBX::AssetService::AssetType,std::vector<std::string> const>>::~__vector_base,
      &xmmword_2A08C40,
      &dso_handle);
    __cxa_guard_release(&byte_2A08C58);
  }
  return (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&xmmword_2A08C40;
}


// Address: 0x10da800 | Name: _ZN3RBX25HumanoidDefaultAnimations5cacheERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidDefaultAnimations::cache(
        RBX::HumanoidDefaultAnimations *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  RBX::ModelInstance *CharacterFromHumanoid; // rax
  const RBX::Instance *ConstFirstChildByName; // r12
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v8; // r13
  const std::string *v9; // rbx
  const std::string *j; // rbp
  RBX::Instance *v11; // rax
  __int128 v12; // [rsp+0h] [rbp-58h] BYREF
  void *ptr; // [rsp+10h] [rbp-48h]
  __int64 i; // [rsp+20h] [rbp-38h]

  if ( !RBX::Instance::findConstFirstChildByName(parent->px, (RBX::HumanoidDefaultAnimations *)((char *)this + 8)) )
  {
    if ( *((_DWORD *)humanoid + 177) )
    {
      CharacterFromHumanoid = RBX::Humanoid::getCharacterFromHumanoid(humanoid);
      if ( CharacterFromHumanoid )
      {
        *((_QWORD *)&v12 + 1) = 0;
        ptr = 0;
        LOBYTE(v12) = 14;
        strcpy((char *)&v12 + 1, "Animate");
        ConstFirstChildByName = RBX::Instance::findConstFirstChildByName(
                                  (const RBX::Instance *)CharacterFromHumanoid,
                                  (const std::string *)&v12);
        if ( (v12 & 1) != 0 )
          operator delete(ptr);
        if ( ConstFirstChildByName )
        {
          descriptor = ConstFirstChildByName->descriptor;
          DescriptorPtr = Class_getDescriptorPtr(0);
          if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
          {
            RBX::HumanoidDefaultAnimations::getAllAnimNames();
            v8 = xmmword_2A08C40;
            for ( i = *(&xmmword_2A08C40 + 1); v8 != i; v8 += 32 )
            {
              v9 = *(const std::string **)(v8 + 8);
              for ( j = *(const std::string **)(v8 + 16); j != v9; v9 = (const std::string *)((char *)v9 + 24) )
              {
                v11 = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(ConstFirstChildByName, v9);
                RBX::HumanoidDefaultInstances::addInstance(this, v11, parent);
              }
            }
          }
        }
      }
    }
  }
}


// Address: 0x10da940 | Name: _ZN3RBX25HumanoidDefaultAnimations5applyERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEERKNS4_INS_19HumanoidDescriptionEEESC_
void __fastcall RBX::HumanoidDefaultAnimations::apply(
        RBX::HumanoidDefaultAnimations *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent,
        const boost::shared_ptr<RBX::HumanoidDescription> *prev,
        const boost::shared_ptr<RBX::HumanoidDescription> *next)
{
  if ( *((_DWORD *)humanoid + 177) )
  {
    RBX::HumanoidDefaultAnimations::getAllAnimNames();
    RBX::HumanoidDefaultInstances::applyInternal(
      this,
      humanoid,
      (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&xmmword_2A08C40,
      parent,
      prev,
      next);
  }
}


// Address: 0x10da9a0 | Name: _ZN3RBX25HumanoidDefaultAnimations9setParentERKN5boost8weak_ptrINS_13ModelInstanceEEENS1_10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidDefaultAnimations::setParent(
        RBX::HumanoidDefaultAnimations *this,
        const boost::weak_ptr<RBX::ModelInstance> *character,
        boost::shared_ptr<RBX::Instance> instance)
{
  boost::detail::sp_counted_base *px; // rax
  int64_t v4; // rax
  int64_t v5; // rcx
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::Instance> i; // [rsp+8h] [rbp-20h] BYREF

  i.px = (boost::shared_ptr<RBX::Instance>::element_type *)instance.px->_vptr$EventSource;
  px = (boost::detail::sp_counted_base *)instance.px->weak_this_.px;
  i.pn.pi_ = px;
  if ( px )
    _InterlockedAdd(&px->use_count_, 1u);
  v4 = RBX::HumanoidDescription::nullAssetId();
  RBX::HumanoidAssetSwapper::setAnimationParent(character, (boost::shared_ptr<RBX::Instance>)__PAIR128__(v4, &i), v5);
  pi = i.pn.pi_;
  if ( i.pn.pi_ && !_InterlockedSub(&i.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10daa60 | Name: _ZN3RBX21HumanoidDefaultAssets11cacheAssetsERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidDefaultAssets::cacheAssets(
        RBX::HumanoidDefaultAssets *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  RBX::Instance *Folder; // rax
  RBX::DataModelMesh *HeadMesh; // rax
  RBX::Instance *HeadDecal; // rsi
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::Instance> v7; // [rsp+0h] [rbp-38h] BYREF
  void *v8[5]; // [rsp+10h] [rbp-28h] BYREF

  HIBYTE(v8[2]) = 0;
  strcpy((char *)v8, "*HumanoidDefaultAssets");
  Folder = RBX::lazyCreateFolder(parent, (const std::string *)v8);
  RBX::shared_from<RBX::Instance>(&v7.px, Folder);
  if ( ((__int64)v8[0] & 1) != 0 )
    operator delete(v8[2]);
  if ( *((_DWORD *)humanoid + 177) )
  {
    RBX::HumanoidDefaultBodyPartsR15::cache((RBX::HumanoidDefaultAssets *)((char *)this + 32), humanoid, &v7);
    RBX::HumanoidDefaultAnimations::cache((RBX::HumanoidDefaultAssets *)((char *)this + 64), humanoid, &v7);
  }
  else if ( !RBX::Instance::findConstFirstChildByName(v7.px, (RBX::HumanoidDefaultAssets *)((char *)this + 8)) )
  {
    HeadMesh = RBX::Humanoid::getHeadMesh(humanoid);
    RBX::HumanoidDefaultInstances::addInstance(this, HeadMesh, &v7);
    HeadDecal = (RBX::Instance *)RBX::Humanoid::getHeadDecal(humanoid);
    RBX::HumanoidDefaultInstances::addInstance(this, HeadDecal, &v7);
  }
  pi = v7.pn.pi_;
  if ( v7.pn.pi_ && !_InterlockedSub(&v7.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10dabe0 | Name: _ZN3RBX21HumanoidDefaultAssets9hasCachedEbRKN5boost10shared_ptrINS_8InstanceEEE
bool __fastcall RBX::HumanoidDefaultAssets::hasCached(
        RBX::HumanoidDefaultAssets *this,
        bool r15_0,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  RBX::Instance *ConstFirstChildByName; // rsi
  const RBX::Instance *v5; // rax
  bool v6; // bl
  volatile signed __int32 *v7; // rbp
  void *v9[3]; // [rsp+0h] [rbp-38h] BYREF
  RBX::Instance *v10; // [rsp+18h] [rbp-20h] BYREF
  volatile signed __int32 *v11; // [rsp+20h] [rbp-18h]

  HIBYTE(v9[2]) = 0;
  strcpy((char *)v9, "*HumanoidDefaultAssets");
  ConstFirstChildByName = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(parent->px, (const std::string *)v9);
  RBX::shared_from<RBX::Instance>(&v10, ConstFirstChildByName);
  if ( ((__int64)v9[0] & 1) != 0 )
    operator delete(v9[2]);
  if ( v10 )
  {
    if ( !r15_0 )
    {
      v5 = RBX::Instance::findConstFirstChildByName(v10, (RBX::HumanoidDefaultAssets *)((char *)this + 8));
      goto LABEL_9;
    }
    if ( RBX::Instance::findConstFirstChildByName(v10, (RBX::HumanoidDefaultAssets *)((char *)this + 40)) )
    {
      v5 = RBX::Instance::findConstFirstChildByName(v10, (RBX::HumanoidDefaultAssets *)((char *)this + 72));
LABEL_9:
      v6 = v5 != 0;
      goto LABEL_10;
    }
  }
  v6 = 0;
LABEL_10:
  v7 = v11;
  if ( v11 )
  {
    if ( !_InterlockedSub(v11 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  return v6;
}


// Address: 0x10dad30 | Name: _ZN3RBX21HumanoidDefaultAssets17setToDefaultStateERNS_8HumanoidERKN5boost10shared_ptrINS_8InstanceEEERKNS4_INS_19HumanoidDescriptionEEESC_
void __fastcall RBX::HumanoidDefaultAssets::setToDefaultState(
        RBX::HumanoidDefaultAssets *this,
        RBX::Humanoid *humanoid,
        const boost::shared_ptr<RBX::Instance> *parent,
        const boost::shared_ptr<RBX::HumanoidDescription> *prev,
        const boost::shared_ptr<RBX::HumanoidDescription> *next)
{
  RBX::Instance *ConstFirstChildByName; // rsi
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::Instance> v10; // [rsp+0h] [rbp-58h] BYREF
  void *v11[9]; // [rsp+10h] [rbp-48h] BYREF

  HIBYTE(v11[2]) = 0;
  strcpy((char *)v11, "*HumanoidDefaultAssets");
  ConstFirstChildByName = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(
                                             parent->px,
                                             (const std::string *)v11);
  RBX::shared_from<RBX::Instance>(&v10.px, ConstFirstChildByName);
  if ( ((__int64)v11[0] & 1) != 0 )
    operator delete(v11[2]);
  if ( v10.px )
  {
    if ( *((_DWORD *)humanoid + 177) )
    {
      RBX::HumanoidDefaultBodyParts::getAllBodyPartNames();
      RBX::HumanoidDefaultInstances::applyInternal(
        (RBX::HumanoidDefaultAssets *)((char *)this + 32),
        humanoid,
        (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&allAssetsToParts,
        &v10,
        prev,
        next);
      RBX::HumanoidDefaultBodyPartsR15::getAllBodyPartNames();
      RBX::HumanoidDefaultInstances::applyInternal(
        (RBX::HumanoidDefaultAssets *)((char *)this + 32),
        humanoid,
        (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&xmmword_2A08C20,
        &v10,
        prev,
        next);
      if ( *((_DWORD *)humanoid + 177) )
      {
        RBX::HumanoidDefaultAnimations::getAllAnimNames();
        RBX::HumanoidDefaultInstances::applyInternal(
          (RBX::HumanoidDefaultAssets *)((char *)this + 64),
          humanoid,
          (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&xmmword_2A08C40,
          &v10,
          prev,
          next);
      }
    }
    else
    {
      RBX::HumanoidDefaultBodyParts::getAllBodyPartNames();
      RBX::HumanoidDefaultInstances::applyInternal(
        this,
        humanoid,
        (RBX::HumanoidDefaultInstances::AssetTypeToDefaultBodyPartType *)&allAssetsToParts,
        &v10,
        prev,
        next);
    }
  }
  pi = v10.pn.pi_;
  if ( v10.pn.pi_ && !_InterlockedSub(&v10.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x10daef0 | Name: _ZN3RBX21HumanoidDefaultAssets29IsDefaultableClothesAssetTypeENS_12AssetService9AssetTypeE
bool __fastcall RBX::HumanoidDefaultAssets::IsDefaultableClothesAssetType(RBX::AssetService::AssetType type)
{
  return (unsigned int)(type - 11) < 2;
}


// Address: 0x10daf00 | Name: _ZN3RBX21HumanoidDefaultAssets24cacheDefaultClothesAssetERKN5boost10shared_ptrINS_8InstanceEEENS_12AssetService9AssetTypeE
void __fastcall RBX::HumanoidDefaultAssets::cacheDefaultClothesAsset(
        RBX::HumanoidDefaultAssets *this,
        const boost::shared_ptr<RBX::Instance> *parent,
        RBX::AssetService::AssetType type)
{
  boost::shared_ptr<RBX::Instance>::element_type *px; // rbx
  RBX::Instance *i; // rax
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::ContentProvider *v8; // rax
  RBX::ContentProvider *v9; // r14
  boost::shared_ptr<RBX::Instance> ClothesAssetFolder; // rax
  boost::shared_ptr<RBX::Instance> v11; // rax
  __int128 v12; // xmm0
  volatile signed __int32 *v13; // rbx
  const char *v14; // rsi
  char *v15; // r14
  char *v16; // rbx
  unsigned __int64 v17; // r12
  __int64 v18; // r13
  RBX::Instance *v19; // rdi
  volatile signed __int32 *v20; // r15
  volatile signed __int32 *v21; // r15
  void *v22; // rdi
  volatile signed __int32 *v23; // rbx
  void *v24[2]; // [rsp+0h] [rbp-78h] BYREF
  __int64 v25; // [rsp+10h] [rbp-68h]
  RBX::Instance *newParent[2]; // [rsp+20h] [rbp-58h]
  _BYTE v27[16]; // [rsp+38h] [rbp-40h] BYREF
  void *ptr; // [rsp+48h] [rbp-30h]

  if ( (unsigned int)(type - 11) <= 1 )
  {
    px = parent->px;
    if ( parent->px )
    {
      for ( i = px->parent; i; i = i->parent )
        px = i;
      descriptor = px->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( px )
      {
        if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
        {
          v8 = RBX::ServiceProvider::create<RBX::ContentProvider>((const RBX::ServiceProvider *)px);
          if ( v8 )
          {
            v9 = v8;
            ClothesAssetFolder = RBX::getClothesAssetFolder(parent, type, 0);
            if ( !newParent[0] )
            {
              v11 = RBX::getClothesAssetFolder(parent, type, 1);
              v12 = *(_OWORD *)v24;
              *(_OWORD *)v24 = 0;
              v13 = (volatile signed __int32 *)newParent[1];
              *(_OWORD *)newParent = v12;
              if ( v13 )
              {
                if ( !_InterlockedSub(v13 + 2, 1u) )
                {
                  (*(void (__fastcall **)(volatile signed __int32 *, const boost::shared_ptr<RBX::Instance> *, boost::detail::sp_counted_base *))(*(_QWORD *)v13 + 16LL))(
                    v13,
                    parent,
                    v11.pn.pi_);
                  if ( !_InterlockedSub(v13 + 3, 1u) )
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
                }
              }
              if ( v24[1] )
              {
                if ( !_InterlockedSub((volatile signed __int32 *)v24[1] + 2, 1u) )
                {
                  (*(void (__fastcall **)(void *, const boost::shared_ptr<RBX::Instance> *, boost::detail::sp_counted_base *))(*(_QWORD *)v24[1] + 16LL))(
                    v24[1],
                    parent,
                    v11.pn.pi_);
                  if ( !_InterlockedSub((volatile signed __int32 *)v24[1] + 3, 1u) )
                    (*(void (__fastcall **)(void *))(*(_QWORD *)v24[1] + 24LL))(v24[1]);
                }
              }
              *(_OWORD *)v24 = 0;
              v25 = 0;
              v14 = "avatar/defaultPants.rbxm";
              if ( type == RBX::AssetService::AssetType::SHIRT )
                v14 = "avatar/defaultShirt.rbxm";
              RBX::ContentId::fromAssets((RBX::ContentId *)v27, v14);
              parent = (const boost::shared_ptr<RBX::Instance> *)v27;
              RBX::ContentProvider::blockingLoadInstances(
                v9,
                (const RBX::ContentId *)v27,
                (std::vector<boost::shared_ptr<RBX::Instance>> *)v24);
              if ( (v27[0] & 1) != 0 )
                operator delete(ptr);
              v15 = (char *)v24[0];
              v16 = (char *)v24[1];
              if ( v24[1] != v24[0] )
              {
                v17 = 0;
                v18 = 8;
                do
                {
                  v19 = *(RBX::Instance **)&v15[v18 - 8];
                  v20 = *(volatile signed __int32 **)&v15[v18];
                  if ( v20 )
                    _InterlockedAdd(v20 + 2, 1u);
                  if ( v19 )
                  {
                    parent = (const boost::shared_ptr<RBX::Instance> *)newParent[0];
                    RBX::Instance::setParentInternal(v19, newParent[0], 0);
                  }
                  if ( v20 )
                  {
                    if ( !_InterlockedSub(v20 + 2, 1u) )
                    {
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 16LL))(v20);
                      if ( !_InterlockedSub(v20 + 3, 1u) )
                        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 24LL))(v20);
                    }
                  }
                  ++v17;
                  v15 = (char *)v24[0];
                  v16 = (char *)v24[1];
                  v18 += 16;
                }
                while ( v17 < ((char *)v24[1] - (char *)v24[0]) >> 4 );
              }
              if ( v15 )
              {
                if ( v16 == v15 )
                {
                  v22 = v15;
                }
                else
                {
                  do
                  {
                    v21 = (volatile signed __int32 *)*((_QWORD *)v16 - 1);
                    if ( v21 )
                    {
                      if ( !_InterlockedSub(v21 + 2, 1u) )
                      {
                        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 16LL))(v21);
                        if ( !_InterlockedSub(v21 + 3, 1u) )
                          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 24LL))(v21);
                      }
                    }
                    v16 -= 16;
                  }
                  while ( v15 != v16 );
                  v22 = v24[0];
                }
                v24[1] = v15;
                operator delete(v22);
              }
            }
            v23 = (volatile signed __int32 *)newParent[1];
            if ( newParent[1]
              && !_InterlockedSub(
                    (volatile signed __int32 *)&newParent[1]->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
                    1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *, const boost::shared_ptr<RBX::Instance> *, boost::detail::sp_counted_base *))(*(_QWORD *)v23 + 16LL))(
                v23,
                parent,
                ClothesAssetFolder.pn.pi_);
              if ( !_InterlockedSub(v23 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 24LL))(v23);
            }
          }
        }
      }
    }
  }
}


// Address: 0x10db2e0 | Name: _ZN3RBXL21getClothesAssetFolderERKN5boost10shared_ptrINS_8InstanceEEENS_12AssetService9AssetTypeEb
__int64 __fastcall RBX::getClothesAssetFolder(
        __int64 a1,
        const boost::shared_ptr<RBX::Instance> *parent,
        RBX::AssetService::AssetType type,
        bool createIfRequired)
{
  RBX::Instance *Folder; // rax
  char v7; // bl
  char v8; // bp
  RBX::Instance *ConstFirstChildByName; // rax
  char v10; // bl
  char v11; // bp
  boost::detail::sp_counted_base *v12; // rax
  const char *v13; // rax
  RBX::Instance *v14; // rax
  char v15; // bl
  char v16; // bp
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v18; // rbp
  boost::detail::sp_counted_base *v19; // rbp
  __int128 v21; // [rsp+0h] [rbp-98h] BYREF
  void *v22; // [rsp+10h] [rbp-88h]
  void *v23[3]; // [rsp+20h] [rbp-78h] BYREF
  void *v24[3]; // [rsp+38h] [rbp-60h] BYREF
  boost::shared_ptr<RBX::Instance> v25; // [rsp+50h] [rbp-48h] BYREF
  boost::shared_ptr<RBX::Instance> v26; // [rsp+60h] [rbp-38h] BYREF

  HIBYTE(v23[2]) = 0;
  strcpy((char *)v23, "*HumanoidDefaultAssets");
  if ( createIfRequired )
  {
    Folder = RBX::lazyCreateFolder(parent, (const std::string *)v23);
    v7 = 1;
    v8 = 0;
  }
  else
  {
    Folder = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(parent->px, (const std::string *)v23);
    v8 = 1;
    v7 = 0;
  }
  RBX::shared_from<RBX::Instance>(&v26.px, Folder);
  if ( v8 && ((__int64)v23[0] & 1) != 0 )
    operator delete(v23[2]);
  if ( v7 && ((__int64)v23[0] & 1) != 0 )
    operator delete(v23[2]);
  if ( v26.px )
  {
    strcpy((char *)v24, ",HumanoidDefaultClothes");
    if ( createIfRequired )
    {
      ConstFirstChildByName = RBX::lazyCreateFolder(&v26, (const std::string *)v24);
      v10 = 1;
      v11 = 0;
    }
    else
    {
      ConstFirstChildByName = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(
                                                 v26.px,
                                                 (const std::string *)v24);
      v11 = 1;
      v10 = 0;
    }
    RBX::shared_from<RBX::Instance>(&v25.px, ConstFirstChildByName);
    if ( v11 && ((__int64)v24[0] & 1) != 0 )
      operator delete(v24[2]);
    if ( v10 && ((__int64)v24[0] & 1) != 0 )
      operator delete(v24[2]);
    if ( v25.px )
    {
      v13 = "Pants";
      if ( type == RBX::AssetService::AssetType::SHIRT )
        v13 = "Shirt";
      v21 = 0;
      v22 = 0;
      LOBYTE(v21) = 10;
      *(_WORD *)((char *)&v21 + 5) = *((unsigned __int8 *)v13 + 4);
      *(_DWORD *)((char *)&v21 + 1) = *(_DWORD *)v13;
      if ( createIfRequired )
      {
        v14 = RBX::lazyCreateFolder(&v25, (const std::string *)&v21);
        v15 = 1;
        v16 = 0;
      }
      else
      {
        v14 = (RBX::Instance *)RBX::Instance::findConstFirstChildByName(v25.px, (const std::string *)&v21);
        v16 = 1;
        v15 = 0;
      }
      RBX::shared_from<RBX::Instance>((boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)a1, v14);
      if ( v16 && (v21 & 1) != 0 )
        operator delete(v22);
      if ( v15 && (v21 & 1) != 0 )
        operator delete(v22);
    }
    else
    {
      *(_QWORD *)a1 = 0;
      pi = v25.pn.pi_;
      v25.pn.pi_ = 0;
      *(_QWORD *)(a1 + 8) = pi;
      v25.px = 0;
    }
    v18 = v25.pn.pi_;
    if ( v25.pn.pi_ )
    {
      if ( !_InterlockedSub(&v25.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v18->_vptr$sp_counted_base + 2))(v18);
        if ( !_InterlockedSub(&v18->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v18->_vptr$sp_counted_base + 3))(v18);
      }
    }
    v19 = v26.pn.pi_;
    if ( v26.pn.pi_ )
    {
      if ( !_InterlockedSub(&v26.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 2))(v19);
        if ( !_InterlockedSub(&v19->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 3))(v19);
      }
    }
  }
  else
  {
    *(_QWORD *)a1 = 0;
    v12 = v26.pn.pi_;
    v26.pn.pi_ = 0;
    *(_QWORD *)(a1 + 8) = v12;
    v26.px = 0;
  }
  return a1;
}


// Address: 0x10db770 | Name: _ZN3RBX21HumanoidDefaultAssets25cacheDefaultClothesAssetsERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::HumanoidDefaultAssets::cacheDefaultClothesAssets(
        RBX::HumanoidDefaultAssets *this,
        const boost::shared_ptr<RBX::Instance> *parent)
{
  RBX::HumanoidDefaultAssets::cacheDefaultClothesAsset(this, parent, RBX::AssetService::AssetType::SHIRT);
  RBX::HumanoidDefaultAssets::cacheDefaultClothesAsset(this, parent, RBX::AssetService::AssetType::PANTS);
}


// Address: 0x10db790 | Name: _ZN3RBX21HumanoidDefaultAssets22getDefaultClothesAssetERKN5boost10shared_ptrINS_8InstanceEEENS_12AssetService9AssetTypeERNSt3__16vectorIS4_NS9_9allocatorIS4_EEEE
void __fastcall RBX::HumanoidDefaultAssets::getDefaultClothesAsset(
        RBX::HumanoidDefaultAssets *this,
        const boost::shared_ptr<RBX::Instance> *parent,
        RBX::AssetService::AssetType type,
        RBX::Instances *instances)
{
  __int64 *v6; // rax
  volatile signed __int32 *v7; // rcx
  __int64 v8; // rbp
  __int64 v9; // r14
  RBX::Instance *p_x; // rsi
  volatile signed __int32 *v11; // r13
  boost::shared_ptr<RBX::Instance> v12; // rax
  boost::shared_ptr<RBX::Instance> v13; // xmm0
  boost::detail::sp_counted_base *pi; // rbx
  volatile signed __int32 *v15; // rbx
  volatile signed __int32 *v16; // [rsp+8h] [rbp-60h]
  boost::shared_ptr<RBX::Instance> __x; // [rsp+10h] [rbp-58h] BYREF
  __int64 v18; // [rsp+28h] [rbp-40h] BYREF
  volatile signed __int32 *v19; // [rsp+30h] [rbp-38h]

  if ( (unsigned int)(type - 11) <= 1 )
  {
    RBX::HumanoidDefaultAssets::cacheDefaultClothesAsset(this, parent, type);
    RBX::getClothesAssetFolder((__int64)&v18, parent, type, 0);
    v6 = *(__int64 **)(v18 + 72);
    if ( v6 )
    {
      v7 = *(volatile signed __int32 **)(v18 + 80);
      if ( v7 )
        _InterlockedAdd(v7 + 2, 1u);
      v16 = v7;
      v8 = *v6;
      v9 = v6[1];
      if ( *v6 != v9 )
      {
        do
        {
          p_x = *(RBX::Instance **)v8;
          v11 = *(volatile signed __int32 **)(v8 + 8);
          if ( v11 )
            _InterlockedAdd(v11 + 2, 1u);
          v12 = RBX::Instance::clone(p_x, RBX::CreatorRole::EngineCreator);
          v12.px = (boost::shared_ptr<RBX::Instance>::element_type *)*((_QWORD *)instances + 1);
          if ( v12.px >= (boost::shared_ptr<RBX::Instance>::element_type *)*((_QWORD *)instances + 2) )
          {
            p_x = (RBX::Instance *)&__x;
            std::vector<boost::shared_ptr<RBX::Instance>>::__push_back_slow_path<boost::shared_ptr<RBX::Instance>>(
              (std::vector<boost::shared_ptr<RBX::Instance>> *)instances,
              &__x);
          }
          else
          {
            v12.px->weak_this_.px = 0;
            v13 = __x;
            __x.pn.pi_ = 0;
            *(boost::shared_ptr<RBX::Instance> *)&v12.px->_vptr$EventSource = v13;
            __x.px = 0;
            *((_QWORD *)instances + 1) = &v12.px->weak_this_.pn;
          }
          pi = __x.pn.pi_;
          if ( __x.pn.pi_ )
          {
            if ( !_InterlockedSub(&__x.pn.pi_->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *, RBX::Instance *, boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base
               + 2))(
                pi,
                p_x,
                v12.pn.pi_);
              if ( !_InterlockedSub(&pi->weak_count_, 1u) )
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
            }
          }
          if ( v11 )
          {
            if ( !_InterlockedSub(v11 + 2, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *, RBX::Instance *, boost::detail::sp_counted_base *))(*(_QWORD *)v11 + 16LL))(
                v11,
                p_x,
                v12.pn.pi_);
              if ( !_InterlockedSub(v11 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
            }
          }
          v8 += 16;
        }
        while ( v8 != v9 );
      }
      if ( v16 )
      {
        if ( !_InterlockedSub(v16 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
          if ( !_InterlockedSub(v16 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
        }
      }
    }
    v15 = v19;
    if ( v19 && !_InterlockedSub(v19 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
}


// Address: 0x10dbe60 | Name: _GLOBAL__sub_I_HumanoidDefaultAssets.cpp
void __cdecl GLOBAL__sub_I_HumanoidDefaultAssets_cpp()
{
  qword_2A08BE8 = (__int64)boost::system::generic_category();
  qword_2A08BF0 = (__int64)boost::system::generic_category();
  qword_2A08BF8 = (__int64)boost::system::system_category();
}


