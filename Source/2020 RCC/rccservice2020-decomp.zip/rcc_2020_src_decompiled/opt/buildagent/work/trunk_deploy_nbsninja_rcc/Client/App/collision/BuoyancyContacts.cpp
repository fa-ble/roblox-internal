// Address: 0x1dec4b0 | Name: _ZN3RBX9Collision15BuoyancyContact22determineGeometricTypeEPNS_9PrimitiveE
RBX::Geometry::GeometryType __fastcall RBX::Collision::BuoyancyContact::determineGeometricType(
        RBX::Primitive *primitive)
{
  RBX::PartInstance *v1; // rax
  int v2; // ecx
  RBX::Geometry::GeometryType result; // eax
  RBX::Geometry::CollideType CollideType; // ecx
  RBX::Geometry::GeometryType GeometryType; // ecx
  RBX::Geometry::GeometryType v6; // ecx

  v1 = RBX::PartInstance::fromPrimitive(primitive);
  v2 = (*((__int64 (__fastcall **)(RBX::PartInstance *))v1->_vptr$EventSource + 42))(v1);
  result = GEOMETRY_CYLINDER;
  if ( v2 != 2 )
  {
    CollideType = RBX::Primitive::getCollideType(primitive);
    result = GEOMETRY_BALL;
    if ( CollideType != COLLIDE_BALL )
    {
      GeometryType = RBX::Primitive::getGeometryType(primitive);
      result = GEOMETRY_WEDGE;
      if ( GeometryType != GEOMETRY_WEDGE )
      {
        v6 = RBX::Primitive::getGeometryType(primitive);
        result = GEOMETRY_BLOCK;
        if ( v6 == GEOMETRY_CORNERWEDGE )
          return GEOMETRY_CORNERWEDGE;
      }
    }
  }
  return result;
}


// Address: 0x1dec510 | Name: _ZN3RBX9Collision15BuoyancyContact6createEPNS_9PrimitiveES3_
RBX::Collision::BuoyancyContact *__fastcall RBX::Collision::BuoyancyContact::create(
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  RBX::PartInstance *v2; // rax
  char *v3; // rbx
  __int64 v4; // rcx
  __int64 v5; // rax
  __int64 v6; // rcx
  __int64 (__fastcall **v7)(RBX::Collision::BuoyancyContact *__hidden, unsigned int); // rax
  __int64 v8; // rcx
  __int64 v9; // rax
  __int64 v10; // rcx
  __int64 v11; // rcx
  __int64 v12; // rax
  __int64 v13; // rcx
  RBX::Geometry::GeometryType GeometryType; // ebp
  RBX::Collision::Contact *v15; // rax
  __int64 v16; // rcx
  __int64 v17; // rax
  __int64 v18; // rcx
  __int64 v20; // rcx
  __int64 v21; // rax
  __int64 v22; // rcx
  float v23; // [rsp+0h] [rbp-24h]
  float v24; // [rsp+0h] [rbp-24h]
  float v25; // [rsp+0h] [rbp-24h]
  float v26; // [rsp+0h] [rbp-24h]
  float v27; // [rsp+0h] [rbp-24h]

  v2 = RBX::PartInstance::fromPrimitive(p1);
  if ( (*((unsigned int (__fastcall **)(RBX::PartInstance *))v2->_vptr$EventSource + 42))(v2) == 2 )
  {
    v3 = (char *)operator new(0xB0u);
    RBX::Collision::Contact::Contact((RBX::Collision::Contact *)v3, p0, p1);
    *(_QWORD *)v3 = &off_299DD10;
    *((float *)v3 + 12) = (*(float (__fastcall **)(RBX::Primitive *))(*(_QWORD *)p1 + 32LL))(p1);
    *((_DWORD *)v3 + 13) = 0;
    v3[56] = 0;
    *((_DWORD *)v3 + 16) = 0;
    *(_OWORD *)(v3 + 136) = 0;
    v4 = *((_QWORD *)v3 + 2);
    v23 = *(float *)(*(_QWORD *)(*((_QWORD *)v3 + 1) + 136LL) + 176LL);
    *((_DWORD *)v3 + 15) = 0;
    *((_DWORD *)v3 + 17) = 0;
    *((float *)v3 + 16) = v23
                        * (*(float (__fastcall **)(_QWORD))(**(_QWORD **)(v4 + 144) + 208LL))(*(_QWORD *)(v4 + 144));
    v5 = *((_QWORD *)p0 + 55);
    v6 = v5 - 128;
    if ( !v5 )
      v6 = 0;
    *((_QWORD *)v3 + 18) = *(_QWORD *)(v6 + 400);
    *(_OWORD *)(v3 + 152) = 0;
    *((_QWORD *)v3 + 21) = 0;
    v7 = &off_299DF98;
LABEL_17:
    *(_QWORD *)v3 = v7;
    goto LABEL_18;
  }
  if ( RBX::Primitive::getCollideType(p1) == COLLIDE_BALL )
  {
    v3 = (char *)operator new(0xA0u);
    RBX::Collision::Contact::Contact((RBX::Collision::Contact *)v3, p0, p1);
    *(_QWORD *)v3 = &off_299DD10;
    *((float *)v3 + 12) = (*(float (__fastcall **)(RBX::Primitive *))(*(_QWORD *)p1 + 32LL))(p1);
    *((_DWORD *)v3 + 13) = 0;
    v3[56] = 0;
    *((_DWORD *)v3 + 16) = 0;
    *(_OWORD *)(v3 + 136) = 0;
    v8 = *((_QWORD *)v3 + 2);
    v24 = *(float *)(*(_QWORD *)(*((_QWORD *)v3 + 1) + 136LL) + 176LL);
    *((_DWORD *)v3 + 15) = 0;
    *((_DWORD *)v3 + 17) = 0;
    *((float *)v3 + 16) = v24
                        * (*(float (__fastcall **)(_QWORD))(**(_QWORD **)(v8 + 144) + 208LL))(*(_QWORD *)(v8 + 144));
    v9 = *((_QWORD *)p0 + 55);
    v10 = v9 - 128;
    if ( !v9 )
      v10 = 0;
    *((_QWORD *)v3 + 18) = *(_QWORD *)(v10 + 400);
    v7 = &off_299DE80;
    goto LABEL_17;
  }
  if ( RBX::Primitive::getGeometryType(p1) == GEOMETRY_WEDGE )
  {
    v3 = (char *)operator new(0xB0u);
    RBX::Collision::Contact::Contact((RBX::Collision::Contact *)v3, p0, p1);
    *(_QWORD *)v3 = &off_299DD10;
    *((float *)v3 + 12) = (*(float (__fastcall **)(RBX::Primitive *))(*(_QWORD *)p1 + 32LL))(p1);
    *((_DWORD *)v3 + 13) = 0;
    v3[56] = 0;
    *((_DWORD *)v3 + 16) = 0;
    *(_OWORD *)(v3 + 136) = 0;
    v11 = *((_QWORD *)v3 + 2);
    v25 = *(float *)(*(_QWORD *)(*((_QWORD *)v3 + 1) + 136LL) + 176LL);
    *((_DWORD *)v3 + 15) = 0;
    *((_DWORD *)v3 + 17) = 0;
    *((float *)v3 + 16) = v25
                        * (*(float (__fastcall **)(_QWORD))(**(_QWORD **)(v11 + 144) + 208LL))(*(_QWORD *)(v11 + 144));
    v12 = *((_QWORD *)p0 + 55);
    v13 = v12 - 128;
    if ( !v12 )
      v13 = 0;
    *((_QWORD *)v3 + 18) = *(_QWORD *)(v13 + 400);
    *(_OWORD *)(v3 + 152) = 0;
    *((_QWORD *)v3 + 21) = 0;
    v7 = &off_299E068;
    goto LABEL_17;
  }
  GeometryType = RBX::Primitive::getGeometryType(p1);
  v15 = (RBX::Collision::Contact *)operator new(0xB0u);
  v3 = (char *)v15;
  if ( GeometryType == GEOMETRY_CORNERWEDGE )
  {
    RBX::Collision::Contact::Contact(v15, p0, p1);
    *(_QWORD *)v3 = &off_299DD10;
    *((float *)v3 + 12) = (*(float (__fastcall **)(RBX::Primitive *))(*(_QWORD *)p1 + 32LL))(p1);
    *((_DWORD *)v3 + 13) = 0;
    v3[56] = 0;
    *((_DWORD *)v3 + 16) = 0;
    *(_OWORD *)(v3 + 136) = 0;
    v16 = *((_QWORD *)v3 + 2);
    v26 = *(float *)(*(_QWORD *)(*((_QWORD *)v3 + 1) + 136LL) + 176LL);
    *((_DWORD *)v3 + 15) = 0;
    *((_DWORD *)v3 + 17) = 0;
    *((float *)v3 + 16) = v26
                        * (*(float (__fastcall **)(_QWORD))(**(_QWORD **)(v16 + 144) + 208LL))(*(_QWORD *)(v16 + 144));
    v17 = *((_QWORD *)p0 + 55);
    v18 = v17 - 128;
    if ( !v17 )
      v18 = 0;
    *((_QWORD *)v3 + 18) = *(_QWORD *)(v18 + 400);
    *(_OWORD *)(v3 + 152) = 0;
    *((_QWORD *)v3 + 21) = 0;
    v7 = &off_299E138;
    goto LABEL_17;
  }
  RBX::Collision::Contact::Contact(v15, p0, p1);
  *(_QWORD *)v3 = &off_299DD10;
  *((float *)v3 + 12) = (*(float (__fastcall **)(RBX::Primitive *))(*(_QWORD *)p1 + 32LL))(p1);
  *((_DWORD *)v3 + 13) = 0;
  v3[56] = 0;
  *((_DWORD *)v3 + 16) = 0;
  *(_OWORD *)(v3 + 136) = 0;
  v20 = *((_QWORD *)v3 + 2);
  v27 = *(float *)(*(_QWORD *)(*((_QWORD *)v3 + 1) + 136LL) + 176LL);
  *((_DWORD *)v3 + 15) = 0;
  *((_DWORD *)v3 + 17) = 0;
  *((float *)v3 + 16) = v27
                      * (*(float (__fastcall **)(_QWORD))(**(_QWORD **)(v20 + 144) + 208LL))(*(_QWORD *)(v20 + 144));
  v21 = *((_QWORD *)p0 + 55);
  v22 = v21 - 128;
  if ( !v21 )
    v22 = 0;
  *((_QWORD *)v3 + 18) = *(_QWORD *)(v22 + 400);
  *(_QWORD *)v3 = &off_299DDC8;
  *(_OWORD *)(v3 + 152) = 0;
  *((_QWORD *)v3 + 21) = 0;
LABEL_18:
  (*(void (__fastcall **)(char *))(*(_QWORD *)v3 + 152LL))(v3);
  return (RBX::Collision::BuoyancyContact *)v3;
}


// Address: 0x1dec9d0 | Name: _ZN3RBX9Collision15BuoyancyContactC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::BuoyancyContact::BuoyancyContact(
        RBX::Collision::BuoyancyContact *this,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  RBX::Primitive *prim1; // rcx
  __int64 v5; // rax
  __int64 v6; // rcx
  float v7; // [rsp+Ch] [rbp-1Ch]

  RBX::Collision::Contact::Contact(this, p0, p1);
  this->_vptr$Contact = (int (**)(void))&off_299DD10;
  this->radius = (*(float (__fastcall **)(RBX::Primitive *))(*(_QWORD *)p1 + 32LL))(p1);
  this->fullSurfaceArea = 0.0;
  this->submergedFrames = 0;
  this->fullBuoyancy.y = 0.0;
  *(_OWORD *)&this->buoyancyAccumulators.num = 0;
  prim1 = this->prim1;
  v7 = *(float *)(*((_QWORD *)this->prim0 + 17) + 176LL);
  this->fullBuoyancy.x = 0.0;
  this->fullBuoyancy.z = 0.0;
  this->fullBuoyancy.y = (*(float (__fastcall **)(_QWORD))(**((_QWORD **)prim1 + 18) + 208LL))(*((_QWORD *)prim1 + 18))
                       * v7;
  v5 = *((_QWORD *)p0 + 55);
  v6 = v5 - 128;
  if ( !v5 )
    v6 = 0;
  this->smoothGrid = *(RBX::Voxel2::Grid **)(v6 + 400);
}


// Address: 0x1deca90 | Name: _ZN3RBX9Collision15BuoyancyContact27updateBuoyancyFloatingForceEv
void __fastcall RBX::Collision::BuoyancyContact::updateBuoyancyFloatingForce(RBX::Collision::BuoyancyContact *this)
{
  RBX::Primitive *prim1; // rcx
  float v2; // [rsp+Ch] [rbp-Ch]

  prim1 = this->prim1;
  v2 = *(float *)(*((_QWORD *)this->prim0 + 17) + 176LL);
  this->fullBuoyancy.x = 0.0;
  this->fullBuoyancy.z = 0.0;
  this->fullBuoyancy.y = (*(float (__fastcall **)(_QWORD))(**((_QWORD **)prim1 + 18) + 208LL))(*((_QWORD *)prim1 + 18))
                       * v2;
}


// Address: 0x1decaf0 | Name: _ZN3RBX9Collision15BuoyancyContactD0Ev
void __fastcall __noreturn RBX::Collision::BuoyancyContact::~BuoyancyContact(RBX::Collision::BuoyancyContact *this)
{
  BUG();
}


// Address: 0x1decb10 | Name: _ZN3RBX9Collision15BuoyancyContact21getCollisionConnectorEj
RBX::CollisionConnector *__fastcall RBX::Collision::BuoyancyContact::getCollisionConnector(
        RBX::Collision::BuoyancyContact *this,
        unsigned int i)
{
  return 0;
}


// Address: 0x1decb20 | Name: _ZN3RBX9Collision15BuoyancyContact24deleteCollisionConnectorEj
void __fastcall RBX::Collision::BuoyancyContact::deleteCollisionConnector(
        RBX::Collision::BuoyancyContact *this,
        unsigned int i)
{
  RBX::BuoyancyAccumulator *v3; // rdi
  size_t num; // rax

  v3 = this->buoyancyAccumulators.data.elems[i];
  if ( v3 )
    operator delete(v3);
  num = this->buoyancyAccumulators.num;
  this->buoyancyAccumulators.data.elems[i] = (RBX::BuoyancyAccumulator *)*((_QWORD *)&this->fullBuoyancy.y + num);
  this->buoyancyAccumulators.num = num - 1;
}


// Address: 0x1decb60 | Name: _ZN3RBX9Collision15BuoyancyContact28deleteAllCollisionConnectorsEv
void __fastcall RBX::Collision::BuoyancyContact::deleteAllCollisionConnectors(RBX::Collision::BuoyancyContact *this)
{
  size_t num; // rax
  unsigned int v3; // ebp
  size_t i; // rcx
  RBX::BuoyancyAccumulator *v5; // rdi

  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v3 = 1;
    for ( i = 0; i < num; i = v3++ )
    {
      v5 = this->buoyancyAccumulators.data.elems[i];
      if ( v5 )
      {
        operator delete(v5);
        num = this->buoyancyAccumulators.num;
      }
    }
  }
  this->buoyancyAccumulators.num = 0;
  RBX::Primitive::onBuoyancyChanged(this->prim1, 0);
}


// Address: 0x1decbc0 | Name: _ZN3RBX9Collision15BuoyancyContact27updateCollisionDataInKernelEPNS_6KernelE
bool __fastcall RBX::Collision::BuoyancyContact::updateCollisionDataInKernel(
        RBX::Collision::BuoyancyContact *this,
        RBX::Kernel *kernel)
{
  int num; // ebx
  RBX::BuoyancyAccumulator **v4; // rbp
  int v5; // ebx
  __int64 v6; // r15
  bool v7; // r13
  RBX::BuoyancyAccumulator *v8; // rsi
  float submergeRatio; // xmm0_4
  bool v11; // [rsp+1h] [rbp-31h]

  v11 = RBX::ContactManager::doPrimitivesCollide(
          *(RBX::ContactManager **)(*((_QWORD *)this->prim0 + 17) + 784LL),
          this->prim0,
          this->prim1);
  num = this->buoyancyAccumulators.num;
  if ( !num )
    return 0;
  v4 = &this->buoyancyAccumulators.data.elems[num - 1];
  v5 = -num;
  v6 = 0;
  v7 = 0;
  do
  {
    v8 = v4[v6];
    if ( v8 )
    {
      submergeRatio = v8->submergeRatio;
      if ( v8->buoyancyAccumulatorIndex < 0 )
      {
        if ( submergeRatio > 0.0 )
        {
          if ( v11 )
            RBX::Kernel::insertBuoyancy(kernel, v8);
          this->inContact = 1;
          v7 = 1;
        }
      }
      else if ( submergeRatio <= 0.0 )
      {
        RBX::Kernel::removeBuoyancy(kernel, v8);
      }
    }
    --v6;
  }
  while ( v5 != (_DWORD)v6 );
  return v7;
}


// Address: 0x1decca0 | Name: _ZN3RBX9Collision15BuoyancyContact29removeCollisionDataFromKernelEPNS_6KernelE
bool __fastcall RBX::Collision::BuoyancyContact::removeCollisionDataFromKernel(
        RBX::Collision::BuoyancyContact *this,
        RBX::Kernel *kernel)
{
  int num; // ebx
  RBX::BuoyancyAccumulator **v4; // r13
  int v5; // ebx
  __int64 v6; // rbp
  char v7; // r12
  RBX::BuoyancyAccumulator *v8; // rsi

  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v4 = &this->buoyancyAccumulators.data.elems[num - 1];
    v5 = -num;
    v6 = 0;
    v7 = 0;
    do
    {
      v8 = v4[v6];
      if ( v8 && v8->buoyancyAccumulatorIndex >= 0 )
      {
        RBX::Kernel::removeBuoyancy(kernel, v8);
        v7 = 1;
      }
      --v6;
    }
    while ( v5 != (_DWORD)v6 );
  }
  else
  {
    v7 = 0;
  }
  (*((void (__fastcall **)(RBX::Collision::BuoyancyContact *))this->_vptr$Contact + 10))(this);
  this->inContact = 0;
  return v7 & 1;
}


// Address: 0x1decd20 | Name: _ZN3RBX9Collision15BuoyancyContact37removeCollisionDataFromKernelForSleepEPNS_6KernelE
bool __fastcall RBX::Collision::BuoyancyContact::removeCollisionDataFromKernelForSleep(
        RBX::Collision::BuoyancyContact *this,
        RBX::Kernel *kernel)
{
  int num; // r12d
  RBX::BuoyancyAccumulator **v4; // r15
  int v5; // r12d
  __int64 v6; // rbx
  bool result; // al
  RBX::BuoyancyAccumulator *v8; // rsi

  num = this->buoyancyAccumulators.num;
  if ( !num )
    return 0;
  v4 = &this->buoyancyAccumulators.data.elems[num - 1];
  v5 = -num;
  v6 = 0;
  result = 0;
  do
  {
    v8 = v4[v6];
    if ( v8 )
    {
      if ( v8->buoyancyAccumulatorIndex >= 0 )
      {
        RBX::Kernel::removeBuoyancy(kernel, v8);
        result = 1;
      }
    }
    --v6;
  }
  while ( v5 != (_DWORD)v6 );
  return result;
}


// Address: 0x1decd90 | Name: _ZN3RBX9Collision15BuoyancyContact35onPrimitiveContactParamatersChangedEv
void __fastcall RBX::Collision::BuoyancyContact::onPrimitiveContactParamatersChanged(
        RBX::Collision::BuoyancyContact *this)
{
  RBX::Primitive *prim1; // rcx
  RBX::Primitive *v2; // rsi
  RBX::World *v3; // rdi
  float v4; // [rsp+Ch] [rbp-Ch]

  prim1 = this->prim1;
  v4 = *(float *)(*((_QWORD *)this->prim0 + 17) + 176LL);
  this->fullBuoyancy.x = 0.0;
  this->fullBuoyancy.z = 0.0;
  this->fullBuoyancy.y = (*(float (__fastcall **)(_QWORD))(**((_QWORD **)prim1 + 18) + 208LL))(*((_QWORD *)prim1 + 18))
                       * v4;
  v2 = this->prim1;
  v3 = (RBX::World *)*((_QWORD *)v2 + 17);
  if ( v3 )
    RBX::World::ticklePrimitive(v3, v2, 1);
}


// Address: 0x1dece10 | Name: _ZN3RBX9Collision15BuoyancyContact21getDebugContactPointsEb
RBX::Collision::BuoyancyContact *__fastcall RBX::Collision::BuoyancyContact::getDebugContactPoints(
        RBX::Collision::BuoyancyContact *this,
        __int64 a2,
        char a3)
{
  RBX::Collision::BuoyancyContact *v3; // r12
  __int64 v4; // rbx
  unsigned __int8 v5; // r13
  unsigned __int64 v6; // r15
  __int64 v7; // r12
  char *v8; // rcx
  __int64 v9; // rbp
  __int64 v10; // rbx
  __m128 v11; // xmm1
  __m128 v12; // xmm0
  __m128 v13; // xmm6
  __m128 v14; // xmm3
  float v15; // xmm6_4
  __m128 v16; // xmm2
  RBX::Primitive *prim0; // rbp
  RBX::Primitive *prim1; // rax
  int (**v19)(void); // r8
  __int64 v20; // rbp
  __int64 v21; // rbx
  unsigned __int64 v22; // rax
  unsigned __int64 v23; // rax
  int (**v24)(void); // r13
  char *v25; // rdi
  RBX::Primitive *v26; // r13
  char *v27; // rbx
  size_t v28; // rdx
  int (**v29)(void); // rbp
  struct _Unwind_Exception *v31; // rax
  struct _Unwind_Exception *v32; // rbp
  int (**v33)(void); // rdi
  unsigned __int8 v35; // [rsp+14h] [rbp-64h]

  v3 = this;
  *(_OWORD *)&this->_vptr$Contact = 0;
  this->prim1 = 0;
  if ( *(_QWORD *)(a2 + 136) )
  {
    v4 = a2;
    v5 = a3 ^ 1;
    v6 = 0;
    v35 = a3 ^ 1;
    do
    {
      v9 = *(_QWORD *)(v4 + 8 * v6 + 72);
      if ( !(v5 | (v9 == 0)) && *(int *)(v9 + 16) >= 0 )
      {
        v10 = *(_QWORD *)(v9 + 24);
        while ( _InterlockedCompareExchange((volatile signed __int32 *)(v10 + 80), 1, 0) )
          ;
        if ( stru_2AABC90.value )
          RBX::Body::updatePVSafe((RBX::Body *)v10);
        else
          RBX::Body::updatePV((RBX::Body *)v10);
        _InterlockedCompareExchange((volatile signed __int32 *)(v10 + 80), 0, 1);
        v11 = (__m128)*(unsigned int *)(v9 + 32);
        v12 = (__m128)*(unsigned int *)(v9 + 36);
        v13 = (__m128)*(unsigned int *)(v9 + 40);
        v14 = _mm_add_ps(
                _mm_mul_ps(
                  _mm_shuffle_ps(v13, v13, 224),
                  _mm_unpacklo_ps((__m128)*(unsigned int *)(v10 + 216), (__m128)*(unsigned int *)(v10 + 228))),
                _mm_add_ps(
                  _mm_mul_ps(
                    _mm_shuffle_ps(v12, v12, 224),
                    _mm_unpacklo_ps((__m128)*(unsigned int *)(v10 + 212), (__m128)*(unsigned int *)(v10 + 224))),
                  _mm_mul_ps(
                    _mm_shuffle_ps(v11, v11, 224),
                    _mm_unpacklo_ps((__m128)*(unsigned int *)(v10 + 208), (__m128)*(unsigned int *)(v10 + 220)))));
        v15 = (float)((float)(v13.m128_f32[0] * *(float *)(v10 + 240))
                    + (float)((float)(v12.m128_f32[0] * *(float *)(v10 + 236))
                            + (float)(v11.m128_f32[0] * *(float *)(v10 + 232))))
            + *(float *)(v10 + 252);
        v16 = _mm_add_ps((__m128)*(unsigned __int64 *)(v10 + 244), v14);
        prim0 = v3->prim0;
        prim1 = v3->prim1;
        if ( prim0 >= prim1 )
        {
          v19 = v3->_vptr$Contact;
          v20 = prim0 - (RBX::Primitive *)v3->_vptr$Contact;
          v21 = 0x6DB6DB6DB6DB6DB7LL * (v20 >> 2);
          if ( (unsigned __int64)(v21 + 1) > 0x924924924924924LL )
          {
            std::__vector_base_common<true>::__throw_length_error(v3);
            v32 = v31;
            v33 = this->_vptr$Contact;
            if ( this->_vptr$Contact )
            {
              this->prim0 = (RBX::Primitive *)v33;
              operator delete(v33);
            }
            _Unwind_Resume(v32);
          }
          v22 = 0x6DB6DB6DB6DB6DB7LL * ((prim1 - (RBX::Primitive *)v19) >> 2);
          v7 = 0x924924924924924LL;
          if ( v22 > 0x492492492492491LL )
            goto LABEL_18;
          v23 = 2 * v22;
          if ( v23 < v21 + 1 )
            v23 = v21 + 1;
          v7 = v23;
          if ( v23 )
          {
LABEL_18:
            v24 = v19;
            v8 = (char *)operator new(28 * v7);
            v19 = v24;
          }
          else
          {
            v7 = 0;
            v8 = 0;
          }
          v25 = &v8[4 * (v20 >> 2)];
          v26 = (RBX::Primitive *)&v8[28 * v7];
          _mm_storel_ps((double *)v25, v16);
          *((float *)v25 + 2) = v15;
          v27 = &v25[28 * (v20 / -28)];
          *(_OWORD *)(v25 + 12) = 0;
          if ( v20 > 0 )
          {
            v28 = v20;
            v29 = v19;
            memcpy(v27, v19, v28);
            v19 = v29;
          }
          this->_vptr$Contact = (int (**)(void))v27;
          this->prim0 = (RBX::Primitive *)(v25 + 28);
          this->prim1 = v26;
          v3 = this;
          v5 = v35;
          v4 = a2;
          if ( v19 )
            operator delete(v19);
        }
        else
        {
          _mm_storel_ps((double *)prim0, v16);
          *((float *)prim0 + 2) = v15;
          *(_OWORD *)((char *)prim0 + 12) = 0;
          v3->prim0 = (RBX::Primitive *)((char *)v3->prim0 + 28);
          v4 = a2;
        }
      }
      v6 = (unsigned int)(v6 + 1);
    }
    while ( *(_QWORD *)(v4 + 136) > v6 );
  }
  return v3;
}


// Address: 0x1ded150 | Name: _ZN3RBX9Collision15BuoyancyContact12cellHasWaterEiii
bool __fastcall RBX::Collision::BuoyancyContact::cellHasWater(
        RBX::Collision::BuoyancyContact *this,
        int posX,
        int posY,
        int posZ)
{
  return RBX::Voxel2::Grid::getCell(
           this->smoothGrid,
           posX,
           posY,
           posZ,
           RBX::Voxel2::Grid::BoxReturnType::AirIfInsufficientDetail).material == 1;
}


// Address: 0x1ded170 | Name: _ZN3RBX9Collision15BuoyancyContact18worldPosUnderWaterERKN3G3D7Vector3E
bool __fastcall RBX::Collision::BuoyancyContact::worldPosUnderWater(
        RBX::Collision::BuoyancyContact *this,
        const RBX::Vector3 *pos)
{
  float v2; // xmm1_4
  RBX::Vector3 cellPos; // [rsp+8h] [rbp-10h] BYREF
  float waterLevel; // [rsp+14h] [rbp-4h] BYREF

  v2 = pos->z * 0.25;
  _mm_storel_ps((double *)&cellPos.x, _mm_mul_ps((__m128)*(unsigned __int64 *)&pos->x, (__m128)xmmword_3E8550));
  cellPos.z = v2;
  return RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &waterLevel);
}


// Address: 0x1ded1c0 | Name: _ZN3RBX9Collision15BuoyancyContact30hasDistanceSubmergedUnderWaterERKN3G3D7Vector3ERfS5_
bool __fastcall RBX::Collision::BuoyancyContact::hasDistanceSubmergedUnderWater(
        RBX::Collision::BuoyancyContact *this,
        const RBX::Vector3 *worldpos,
        float *waterLevel,
        const RBX::Vector3 *worldMaxSearch)
{
  int v5; // r13d
  int v6; // r14d
  int v7; // ebx
  int v8; // r14d
  int v9; // ebp
  unsigned __int8 material; // al
  float *v11; // rbx
  float v13; // [rsp+8h] [rbp-50h]
  float v14; // [rsp+8h] [rbp-50h]
  float x; // [rsp+Ch] [rbp-4Ch]
  RBX::Vector3 cellPos; // [rsp+10h] [rbp-48h] BYREF
  float *v17; // [rsp+20h] [rbp-38h]

  v17 = waterLevel;
  x = worldpos->y * 0.25;
  v13 = 0.25 * worldpos->z;
  v5 = (int)floorf(worldpos->x * 0.25);
  v6 = (int)floorf(x);
  v7 = (int)floorf(v13);
  if ( RBX::Voxel2::Grid::getCell(
         this->smoothGrid,
         v5,
         v6,
         v7,
         RBX::Voxel2::Grid::BoxReturnType::AirIfInsufficientDetail).material != 1 )
    return 0;
  v14 = worldMaxSearch->y * 0.25;
  v8 = v6 + 1;
  do
  {
    v9 = v8;
    if ( v14 < x )
      break;
    material = RBX::Voxel2::Grid::getCell(
                 this->smoothGrid,
                 v5,
                 v8++,
                 v7,
                 RBX::Voxel2::Grid::BoxReturnType::AirIfInsufficientDetail).material;
  }
  while ( material == 1 );
  cellPos.x = (float)v5;
  cellPos.y = (float)v9 + -1.0;
  cellPos.z = (float)v7;
  v11 = v17;
  RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, v17);
  return worldpos->y <= *v11;
}


// Address: 0x1ded310 | Name: _ZN3RBX9Collision15BuoyancyContact18worldPosAboveWaterERKN3G3D7Vector3EiRf
bool __fastcall RBX::Collision::BuoyancyContact::worldPosAboveWater(
        RBX::Collision::BuoyancyContact *this,
        const RBX::Vector3 *worldpos,
        int minY,
        float *waterLevel)
{
  int v7; // r12d
  int v8; // ebp
  int v9; // r15d
  int v10; // ebx
  float xa; // [rsp+0h] [rbp-58h]
  float x; // [rsp+0h] [rbp-58h]
  float v13; // [rsp+4h] [rbp-54h]
  RBX::Vector3 cellPos; // [rsp+8h] [rbp-50h] BYREF
  float v15; // [rsp+18h] [rbp-40h]
  float v16; // [rsp+1Ch] [rbp-3Ch]
  float v17; // [rsp+20h] [rbp-38h]
  float v18; // [rsp+24h] [rbp-34h]

  v18 = worldpos->x * 0.25;
  xa = worldpos->y * 0.25;
  v13 = 0.25 * worldpos->z;
  v17 = floorf(v18);
  v16 = floorf(xa);
  v15 = floorf(v13);
  cellPos.x = v18;
  cellPos.y = xa;
  cellPos.z = v13;
  if ( RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, waterLevel) )
    return 0;
  v7 = (int)v17;
  v8 = (int)v16;
  v9 = (int)v15;
  x = (float)minY;
  if ( RBX::Voxel2::Grid::getCell(
         this->smoothGrid,
         (int)v17,
         (int)v16,
         (int)v15,
         RBX::Voxel2::Grid::BoxReturnType::AirIfInsufficientDetail).material != 1 )
  {
    v10 = 4 * v8;
    do
    {
      *waterLevel = (float)v10;
      if ( RBX::Voxel2::Grid::getCell(
             this->smoothGrid,
             v7,
             --v8,
             v9,
             RBX::Voxel2::Grid::BoxReturnType::AirIfInsufficientDetail).material == 1 )
        break;
      v10 -= 4;
    }
    while ( *waterLevel >= x );
  }
  cellPos.x = (float)v7;
  cellPos.y = (float)v8;
  cellPos.z = (float)v9;
  RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, waterLevel);
  return *waterLevel >= x;
}


// Address: 0x1ded4b0 | Name: _ZN3RBX9Collision15BuoyancyContact15isTouchingWaterEPNS_9PrimitiveE
bool __fastcall RBX::Collision::BuoyancyContact::isTouchingWater(
        RBX::Collision::BuoyancyContact *this,
        RBX::Primitive *prim)
{
  __int64 v2; // rax
  __m128 v3; // xmm0
  float v4; // xmm1_4
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  __m128 z_low; // xmm0
  bool v7; // bp
  __m128 v8; // xmm0
  __m128 v9; // xmm0
  __m128 v10; // xmm0
  __m128 v11; // xmm0
  __m128 v12; // xmm0
  __m128 v13; // xmm0
  __m128 v14; // xmm0
  float waterLevel; // [rsp+4h] [rbp-44h] BYREF
  RBX::Extents v17; // [rsp+8h] [rbp-40h] BYREF
  RBX::Extents v18; // [rsp+20h] [rbp-28h] BYREF
  RBX::Vector3 Corner; // 0:kr00_12.12
  RBX::Vector3 v20; // 0:kr14_12.12
  RBX::Vector3 v21; // 0:kr20_12.12
  RBX::Vector3 v22; // 0:kr34_12.12
  RBX::Vector3 v23; // 0:kr40_12.12
  RBX::Vector3 v24; // 0:kr54_12.12
  RBX::Vector3 v25; // 0:kr60_12.12
  RBX::Vector3 v26; // 0:kr74_12.12

  v2 = *((_QWORD *)prim + 18);
  v3 = _mm_mul_ps((__m128)*(unsigned __int64 *)(v2 + 8), *(__m128 *)&stru_3EB1B0.x);
  v4 = *(float *)(v2 + 16) * 0.5;
  _mm_storel_ps((double *)&v17.low.x, _mm_xor_ps(v3, *(__m128 *)&stru_3E4970.x));
  v17.low.z = -v4;
  _mm_storel_ps((double *)&v17.high.x, v3);
  v17.high.z = v4;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(prim);
  RBX::Extents::toWorldSpace(&v18, &v17, CoordinateFrame);
  z_low = (__m128)LODWORD(v18.low.z);
  z_low.m128_f32[0] = (float)((float)(v18.low.z + v18.high.z) * 0.5) * 0.25;
  _mm_storel_ps(
    (double *)&v17.low.x,
    _mm_mul_ps(
      _mm_mul_ps(
        _mm_add_ps((__m128)*(unsigned __int64 *)&v18.high.x, (__m128)*(unsigned __int64 *)&v18.low.x),
        *(__m128 *)&stru_3EB1B0.x),
      (__m128)xmmword_3E8550));
  LODWORD(v17.low.z) = z_low.m128_i32[0];
  v7 = 1;
  if ( !RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel) )
  {
    Corner = RBX::Extents::getCorner(&v18, 0);
    z_low.m128_i32[0] = LODWORD(Corner.x);
    z_low.m128_i32[1] = LODWORD(Corner.y);
    v8 = _mm_mul_ps(z_low, (__m128)xmmword_3E8550);
    _mm_storel_ps((double *)&v17.low.x, v8);
    v17.low.z = Corner.z * 0.25;
    if ( !RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel) )
    {
      v20 = RBX::Extents::getCorner(&v18, 1);
      v8.m128_i32[0] = LODWORD(v20.x);
      v8.m128_i32[1] = LODWORD(v20.y);
      v9 = _mm_mul_ps(v8, (__m128)xmmword_3E8550);
      _mm_storel_ps((double *)&v17.low.x, v9);
      v17.low.z = v20.z * 0.25;
      if ( !RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel) )
      {
        v21 = RBX::Extents::getCorner(&v18, 2);
        v9.m128_i32[0] = LODWORD(v21.x);
        v9.m128_i32[1] = LODWORD(v21.y);
        v10 = _mm_mul_ps(v9, (__m128)xmmword_3E8550);
        _mm_storel_ps((double *)&v17.low.x, v10);
        v17.low.z = v21.z * 0.25;
        if ( !RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel) )
        {
          v22 = RBX::Extents::getCorner(&v18, 3);
          v10.m128_i32[0] = LODWORD(v22.x);
          v10.m128_i32[1] = LODWORD(v22.y);
          v11 = _mm_mul_ps(v10, (__m128)xmmword_3E8550);
          _mm_storel_ps((double *)&v17.low.x, v11);
          v17.low.z = v22.z * 0.25;
          if ( !RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel) )
          {
            v23 = RBX::Extents::getCorner(&v18, 4);
            v11.m128_i32[0] = LODWORD(v23.x);
            v11.m128_i32[1] = LODWORD(v23.y);
            v12 = _mm_mul_ps(v11, (__m128)xmmword_3E8550);
            _mm_storel_ps((double *)&v17.low.x, v12);
            v17.low.z = v23.z * 0.25;
            if ( !RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel) )
            {
              v24 = RBX::Extents::getCorner(&v18, 5);
              v12.m128_i32[0] = LODWORD(v24.x);
              v12.m128_i32[1] = LODWORD(v24.y);
              v13 = _mm_mul_ps(v12, (__m128)xmmword_3E8550);
              _mm_storel_ps((double *)&v17.low.x, v13);
              v17.low.z = v24.z * 0.25;
              if ( !RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel) )
              {
                v25 = RBX::Extents::getCorner(&v18, 6);
                v13.m128_i32[0] = LODWORD(v25.x);
                v13.m128_i32[1] = LODWORD(v25.y);
                v14 = _mm_mul_ps(v13, (__m128)xmmword_3E8550);
                _mm_storel_ps((double *)&v17.low.x, v14);
                v17.low.z = v25.z * 0.25;
                if ( !RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel) )
                {
                  v26 = RBX::Extents::getCorner(&v18, 7);
                  v14.m128_i32[0] = LODWORD(v26.x);
                  v14.m128_i32[1] = LODWORD(v26.y);
                  _mm_storel_ps((double *)&v17.low.x, _mm_mul_ps(v14, (__m128)xmmword_3E8550));
                  v17.low.z = v26.z * 0.25;
                  return RBX::MegaClusterInstance::isPointUnderwater(&v17.low, this->smoothGrid, &waterLevel);
                }
              }
            }
          }
        }
      }
    }
  }
  return v7;
}


// Address: 0x1ded7c0 | Name: _ZN3RBX9Collision15BuoyancyContact23computeExtentsWaterBandERKNS_7ExtentsERfS5_
void __fastcall RBX::Collision::BuoyancyContact::computeExtentsWaterBand(
        RBX::Collision::BuoyancyContact *this,
        const RBX::Extents *extents,
        float *floatDistance,
        float *sinkDistance)
{
  __m128 v4; // xmm0
  const RBX::Extents *v7; // rbx
  RBX::Vector3 *p_high; // r13
  float v9; // xmm1_4
  float v10; // xmm0_4
  int y; // edx
  int i; // ebp
  __m128 z_low; // xmm0
  int j; // ebp
  float v15; // xmm4_4
  __m128 x_low; // xmm0
  float v17; // xmm2_4
  float v18; // [rsp+Ch] [rbp-4Ch] BYREF
  RBX::Vector3 cellPos; // [rsp+10h] [rbp-48h] BYREF
  float v20; // [rsp+1Ch] [rbp-3Ch] BYREF
  float *v21; // [rsp+20h] [rbp-38h]
  RBX::Vector3 Corner; // 0:kr00_12.12
  RBX::Vector3 v23; // 0:kr14_12.12

  v7 = extents;
  p_high = &extents->high;
  if ( RBX::Collision::BuoyancyContact::hasDistanceSubmergedUnderWater(this, &extents->low, &v18, &extents->high) )
  {
    *floatDistance = v18 - extents->low.y;
    v9 = extents->high.z * 0.25;
    _mm_storel_ps(
      (double *)&cellPos.x,
      _mm_mul_ps((__m128)*(unsigned __int64 *)&extents->high.x, (__m128)xmmword_3E8550));
    cellPos.z = v9;
    if ( RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v20) )
    {
      *sinkDistance = -1.0;
      return;
    }
    y = (int)extents->low.y;
    extents = (const RBX::Extents *)((char *)extents + 12);
LABEL_7:
    if ( RBX::Collision::BuoyancyContact::worldPosAboveWater(this, &extents->low, y, &v18) )
    {
      *sinkDistance = v7->high.y - v18;
      return;
    }
    x_low = (__m128)LODWORD(v7->low.x);
    x_low.m128_f32[0] = (float)(x_low.m128_f32[0] + v7->high.x) * 0.5;
    v17 = (float)((float)(v7->low.z + v7->high.z) * 0.5) * 0.25;
    _mm_storel_ps(
      (double *)&cellPos.x,
      _mm_mul_ps(_mm_unpacklo_ps(x_low, (__m128)LODWORD(v7->low.y)), (__m128)xmmword_3E8550));
    cellPos.z = v17;
    if ( RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v20) )
    {
      *sinkDistance = *floatDistance;
      return;
    }
    goto LABEL_30;
  }
  if ( RBX::Collision::BuoyancyContact::hasDistanceSubmergedUnderWater(this, &extents->high, &v18, p_high) )
  {
    v10 = v18 - extents->low.y;
    *floatDistance = v10;
    y = (int)(float)(extents->low.y - v10);
    goto LABEL_7;
  }
  v21 = sinkDistance;
  *floatDistance = 0.0;
  for ( i = 0; i != 7; ++i )
  {
    Corner = RBX::Extents::getCorner(extents, i);
    v4.m128_i32[0] = LODWORD(Corner.x);
    v4.m128_i32[1] = LODWORD(Corner.y);
    if ( (Corner.x != extents->low.x
       || _mm_shuffle_ps(v4, v4, 229).m128_f32[0] != extents->low.y
       || Corner.z != extents->low.z)
      && (Corner.x != p_high->x
       || _mm_shuffle_ps(v4, v4, 229).m128_f32[0] != extents->high.y
       || Corner.z != extents->high.z) )
    {
      v4 = _mm_mul_ps(v4, (__m128)xmmword_3E8550);
      _mm_storel_ps((double *)&cellPos.x, v4);
      cellPos.z = Corner.z * 0.25;
      if ( RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v20) )
      {
        v4 = (__m128)*(unsigned int *)floatDistance;
        *floatDistance = v4.m128_f32[0] + 1.0;
      }
    }
  }
  if ( *floatDistance <= 0.0 )
  {
LABEL_30:
    *floatDistance = -1.0;
    return;
  }
  z_low = (__m128)LODWORD(extents->low.z);
  z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] + extents->high.z) * 0.5) * 0.25;
  _mm_storel_ps(
    (double *)&cellPos.x,
    _mm_mul_ps(
      _mm_mul_ps(
        _mm_add_ps((__m128)*(unsigned __int64 *)&extents->high.x, (__m128)*(unsigned __int64 *)&extents->low.x),
        *(__m128 *)&stru_3EB1B0.x),
      (__m128)xmmword_3E8550));
  LODWORD(cellPos.z) = z_low.m128_i32[0];
  if ( RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v20) )
  {
    z_low = (__m128)*(unsigned int *)floatDistance;
    *floatDistance = z_low.m128_f32[0] + 1.0;
  }
  for ( j = 0; j != 7; ++j )
  {
    v23 = RBX::Extents::getCorner(extents, j);
    z_low.m128_i32[0] = LODWORD(v23.x);
    z_low.m128_i32[1] = LODWORD(v23.y);
    v15 = (float)((float)((float)((float)(extents->low.z + extents->high.z) * 0.5) + v23.z) * 0.5) * 0.25;
    _mm_storel_ps(
      (double *)&cellPos.x,
      _mm_mul_ps(
        _mm_mul_ps(
          _mm_add_ps(
            _mm_mul_ps(
              _mm_add_ps((__m128)*(unsigned __int64 *)&extents->high.x, (__m128)*(unsigned __int64 *)&extents->low.x),
              *(__m128 *)&stru_3EB1B0.x),
            z_low),
          *(__m128 *)&stru_3EB1B0.x),
        (__m128)xmmword_3E8550));
    cellPos.z = v15;
    if ( RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v20) )
    {
      z_low = (__m128)*(unsigned int *)floatDistance;
      *floatDistance = z_low.m128_f32[0] + 1.0;
    }
  }
  *v21 = 17.0 - *floatDistance;
}


// Address: 0x1dedc10 | Name: _ZN3RBX9Collision28getAlphaBlendValueFromFramesEi
float __fastcall RBX::Collision::getAlphaBlendValueFromFrames(int frameNum)
{
  float result; // xmm0_4

  result = 0.0;
  if ( (int)accum <= frameNum )
  {
    if ( dword_2868A98 + (int)accum <= frameNum )
      return 1.0;
    else
      return (float)(frameNum - (int)accum) / (float)dword_2868A98;
  }
  return result;
}


// Address: 0x1dedc50 | Name: _ZN3RBX9Collision15BuoyancyContact27calculateLinearViscousForceEPNS_9PrimitiveEN3G3D7Vector3EjfPNS_19BuoyancyAccumulatorES5_f
// local variable allocation has failed, the output may be wrong!
__m128 __fastcall RBX::Collision::BuoyancyContact::calculateLinearViscousForce(
        RBX::Collision::BuoyancyContact *this,
        RBX::Primitive *floaterPrim,
        const RBX::Vector3 relativeVelocity,
        unsigned int i,
        __m128 viscosity_K,
        RBX::BuoyancyAccumulator *accum,
        const RBX::Vector3 partialBuoyancy,
        __m128 submergeRatio)
{
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  __m128 v10; // xmm0
  __m128 v11; // xmm3
  __m128 v12; // xmm1
  __m128 v13; // xmm2
  __m128 v14; // xmm0
  unsigned int *v15; // rax
  unsigned int v17; // [rsp+0h] [rbp-68h] BYREF
  unsigned __int64 v18; // [rsp+4h] [rbp-64h]
  __m128 v19; // [rsp+10h] [rbp-58h]
  __m128 v20; // [rsp+20h] [rbp-48h]
  __m128 v21; // [rsp+30h] [rbp-38h]
  __m128 v22; // [rsp+40h] [rbp-28h]

  v22 = submergeRatio;
  v21 = viscosity_K;
  v20 = *(__m128 *)&relativeVelocity.z;
  v19 = *(__m128 *)&relativeVelocity.x;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(floaterPrim);
  v10 = _mm_shuffle_ps(v19, v19, 229);
  v11 = _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(v20, v20, 224), (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[2][0]),
          _mm_add_ps(
            _mm_mul_ps((__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[1][0], v10),
            _mm_mul_ps(_mm_shuffle_ps(v19, v19, 224), (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[0][0])));
  v12 = (__m128)LODWORD(CoordinateFrame->rotation.elt[0][2]);
  v12.m128_f32[0] = v12.m128_f32[0] * v19.m128_f32[0];
  v10.m128_u64[1] = v20.m128_u64[1];
  v10.m128_f32[0] = (float)(v20.m128_f32[0] * CoordinateFrame->rotation.elt[2][2])
                  + (float)((float)(CoordinateFrame->rotation.elt[1][2] * v10.m128_f32[0]) + v12.m128_f32[0]);
  _mm_storel_ps((double *)&v17, v11);
  HIDWORD(v18) = v10.m128_i32[0];
  *(double *)v10.m128_u64 = (*((double (__fastcall **)(RBX::Collision::BuoyancyContact *, _QWORD, unsigned int *))this->_vptr$Contact
                             + 20))(
                              this,
                              i,
                              &v17);
  v13 = (__m128)v17;
  v13.m128_f32[0] = *(float *)&v17 * v10.m128_f32[0];
  v20 = v13;
  v14 = _mm_shuffle_ps(v10, v10, 229);
  v19 = _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(v12, v14, 0), v14, 226), (__m128)v18);
  v15 = (unsigned int *)RBX::Primitive::getCoordinateFrame(floaterPrim);
  return _mm_mul_ps(
           _mm_shuffle_ps(v22, v22, 224),
           _mm_mul_ps(
             _mm_shuffle_ps(v21, v21, 224),
             _mm_add_ps(
               _mm_mul_ps(_mm_shuffle_ps(v19, v19, 229), _mm_unpacklo_ps((__m128)v15[2], (__m128)v15[5])),
               _mm_add_ps(
                 _mm_mul_ps(_mm_shuffle_ps(v19, v19, 224), _mm_unpacklo_ps((__m128)v15[1], (__m128)v15[4])),
                 _mm_mul_ps(_mm_shuffle_ps(v20, v20, 224), _mm_unpacklo_ps((__m128)*v15, (__m128)v15[3]))))));
}


// Address: 0x1deddd0 | Name: _ZN3RBX9Collision15BuoyancyContact29calculateVSquaredViscousForceEPNS_9PrimitiveEPNS_19BuoyancyAccumulatorEjffN3G3D7Vector3Ef
__m128 __fastcall RBX::Collision::BuoyancyContact::calculateVSquaredViscousForce(
        RBX::Collision::BuoyancyContact *this,
        RBX::Primitive *floaterPrim,
        RBX::BuoyancyAccumulator *accum,
        unsigned int i,
        __m128 viscosity_K,
        __m128 maxViscousForce,
        const RBX::Vector3 partialBuoyancy,
        __m128 submergeRatio)
{
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  float x; // xmm1_4
  float y; // xmm0_4
  float z; // xmm4_4
  __m128 v14; // xmm2
  const RBX::PV *PV; // rax
  float v16; // xmm3_4
  __m128 v17; // xmm5
  float v18; // xmm7_4
  float v19; // xmm0_4
  __m128 z_low; // xmm4
  float v21; // xmm3_4
  __m128 y_low; // xmm6
  __m128 v23; // xmm1
  const RBX::CoordinateFrame *v24; // rax
  __m128 v25; // xmm1
  __m128 v26; // xmm0
  float v27; // xmm0_4
  __m128 v28; // xmm2
  __m128 v29; // xmm0
  const RBX::CoordinateFrame *v30; // rax
  __m128 v31; // xmm3
  __m128 v32; // xmm0
  __m128 v33; // xmm2
  __m128 v34; // xmm5
  __m128 v35; // xmm3
  __m128 v36; // xmm4
  __m128 v37; // xmm4
  __m128 v38; // xmm2
  float v39; // xmm2_4
  __m128 v40; // xmm3
  unsigned int v42; // [rsp+0h] [rbp-98h] BYREF
  unsigned __int64 v43; // [rsp+4h] [rbp-94h]
  __m128 v44; // [rsp+10h] [rbp-88h]
  __m128 v45; // [rsp+20h] [rbp-78h]
  __m128 v46; // [rsp+30h] [rbp-68h]
  __m128 v47; // [rsp+40h] [rbp-58h]
  __m128 v48; // [rsp+50h] [rbp-48h]
  __m128 v49; // [rsp+60h] [rbp-38h]

  v49 = submergeRatio;
  v48 = maxViscousForce;
  v47 = viscosity_K;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(floaterPrim);
  x = accum->position.x;
  y = accum->position.y;
  z = accum->position.z;
  v44.m128_f32[0] = (float)((float)(CoordinateFrame->rotation.elt[0][2] * z)
                          + (float)((float)(CoordinateFrame->rotation.elt[0][1] * y)
                                  + (float)(CoordinateFrame->rotation.elt[0][0] * x)))
                  + CoordinateFrame->translation.x;
  v14 = (__m128)LODWORD(CoordinateFrame->rotation.elt[1][2]);
  v14.m128_f32[0] = (float)((float)(v14.m128_f32[0] * z)
                          + (float)((float)(CoordinateFrame->rotation.elt[1][1] * y)
                                  + (float)(CoordinateFrame->rotation.elt[1][0] * x)))
                  + CoordinateFrame->translation.y;
  v45 = v14;
  v46.m128_f32[0] = (float)((float)(z * CoordinateFrame->rotation.elt[2][2])
                          + (float)((float)(y * CoordinateFrame->rotation.elt[2][1])
                                  + (float)(x * CoordinateFrame->rotation.elt[2][0])))
                  + CoordinateFrame->translation.z;
  PV = RBX::Primitive::getPV(floaterPrim);
  v16 = v44.m128_f32[0] - PV->position.translation.x;
  v17 = v14;
  v17.m128_f32[0] = v14.m128_f32[0] - PV->position.translation.y;
  v18 = v46.m128_f32[0] - PV->position.translation.z;
  v19 = PV->velocity.rotational.x;
  z_low = (__m128)LODWORD(PV->velocity.rotational.z);
  v14.m128_f32[0] = v17.m128_f32[0] * z_low.m128_f32[0];
  z_low.m128_f32[0] = z_low.m128_f32[0] * v16;
  v21 = v16 * PV->velocity.rotational.y;
  y_low = (__m128)LODWORD(PV->velocity.rotational.y);
  v23 = v17;
  y_low.m128_f32[0] = (float)((float)(y_low.m128_f32[0] * v18) - v14.m128_f32[0]) + PV->velocity.linear.x;
  v46 = y_low;
  z_low.m128_f32[0] = (float)(z_low.m128_f32[0] - (float)(v18 * v19)) + PV->velocity.linear.y;
  v44 = z_low;
  v23.m128_f32[0] = (float)((float)(v17.m128_f32[0] * v19) - v21) + PV->velocity.linear.z;
  v45 = v23;
  v24 = RBX::Primitive::getCoordinateFrame(floaterPrim);
  v25 = _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(v45, v45, 224), (__m128)*(unsigned __int64 *)&v24->rotation.elt[2][0]),
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v44, v44, 224), (__m128)*(unsigned __int64 *)&v24->rotation.elt[1][0]),
            _mm_mul_ps(_mm_shuffle_ps(v46, v46, 224), (__m128)*(unsigned __int64 *)&v24->rotation.elt[0][0])));
  v26.m128_u64[1] = v45.m128_u64[1];
  v27 = (float)(v45.m128_f32[0] * v24->rotation.elt[2][2])
      + (float)((float)(v44.m128_f32[0] * v24->rotation.elt[1][2]) + (float)(y_low.m128_f32[0] * v24->rotation.elt[0][2]));
  _mm_storel_ps((double *)&v42, v25);
  *((float *)&v43 + 1) = v27;
  *(double *)v26.m128_u64 = (*((double (__fastcall **)(RBX::Collision::BuoyancyContact *, _QWORD, unsigned int *))this->_vptr$Contact
                             + 20))(
                              this,
                              i,
                              &v42);
  v28 = (__m128)v42;
  v28.m128_f32[0] = *(float *)&v42 * v26.m128_f32[0];
  v45 = v28;
  v29 = _mm_shuffle_ps(v26, v26, 229);
  v44 = _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(v25, v29, 0), v29, 226), (__m128)v43);
  v30 = RBX::Primitive::getCoordinateFrame(floaterPrim);
  v31 = _mm_add_ps(
          _mm_mul_ps(
            _mm_shuffle_ps(v44, v44, 229),
            _mm_unpacklo_ps((__m128)LODWORD(v30->rotation.elt[0][2]), (__m128)LODWORD(v30->rotation.elt[1][2]))),
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(v44, v44, 224),
              _mm_unpacklo_ps((__m128)LODWORD(v30->rotation.elt[0][1]), (__m128)LODWORD(v30->rotation.elt[1][1]))),
            _mm_mul_ps(
              _mm_shuffle_ps(v45, v45, 224),
              _mm_unpacklo_ps((__m128)LODWORD(v30->rotation.elt[0][0]), (__m128)LODWORD(v30->rotation.elt[1][0])))));
  v32 = _mm_mul_ps((__m128)*(unsigned __int64 *)&v30->rotation.elt[2][1], v44);
  v32.m128_f32[0] = _mm_shuffle_ps(v32, v32, 229).m128_f32[0]
                  + (float)((float)(v45.m128_f32[0] * v30->rotation.elt[2][0]) + v32.m128_f32[0]);
  v33 = v47;
  v33.m128_f32[0] = v47.m128_f32[0] / (float)dword_2868AC8;
  v34 = _mm_mul_ps(_mm_shuffle_ps(v33, v33, 224), v31);
  v35 = _mm_mul_ps(v31, v31);
  v36 = 0;
  v36.m128_f32[0] = fsqrt(
                      (float)(v32.m128_f32[0] * v32.m128_f32[0])
                    + (float)(_mm_shuffle_ps(v35, v35, 229).m128_f32[0] + v35.m128_f32[0]));
  v25.m128_f32[0] = (float)(v32.m128_f32[0] * v33.m128_f32[0]) * v36.m128_f32[0];
  v37 = _mm_mul_ps(_mm_shuffle_ps(v36, v36, 224), v34);
  v38 = _mm_mul_ps(v37, v37);
  v39 = fsqrt(
          (float)(v25.m128_f32[0] * v25.m128_f32[0])
        + (float)(_mm_shuffle_ps(v38, v38, 229).m128_f32[0] + v38.m128_f32[0]));
  if ( v39 > v48.m128_f32[0] )
  {
    v40 = (__m128)0x3F800000u;
    v40.m128_f32[0] = 1.0 / v39;
    v37 = _mm_mul_ps(_mm_mul_ps(v37, _mm_shuffle_ps(v40, v40, 224)), _mm_shuffle_ps(v48, v48, 224));
  }
  return _mm_mul_ps(_mm_shuffle_ps(v49, v49, 224), v37);
}


// Address: 0x1dee0e0 | Name: _ZN3RBX9Collision15BuoyancyContact26updateBuoyancyAccumulatorsEv
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::Collision::BuoyancyContact::updateBuoyancyAccumulators(RBX::Collision::BuoyancyContact *this)
{
  RBX::Primitive *prim1; // r14
  signed __int64 num; // rax
  float v3; // xmm0_4
  size_t v4; // rax
  __m128 v5; // xmm1
  bool value; // bl
  float v7; // xmm0_4
  signed __int64 v8; // rax
  float v9; // xmm1_4
  size_t v10; // rdx
  __m128 v11; // xmm3
  __int64 v12; // rbx
  float v13; // xmm0_4
  unsigned int v14; // ebx
  size_t v15; // rbp
  RBX::BuoyancyAccumulator *v16; // rax
  const RBX::PV *v17; // rax
  __m128 x_low; // xmm2
  __m128 v19; // xmm0
  float v20; // xmm1_4
  __m128 v21; // xmm0
  __m128d v22; // xmm0
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  __m128 v24; // xmm1
  float v25; // xmm3_4
  __m128 v26; // xmm1
  __m128 v27; // xmm0
  float v28; // xmm3_4
  __m128 v29; // xmm2
  __m128 v30; // xmm0
  const RBX::CoordinateFrame *v31; // rax
  __m128 v32; // xmm1
  RBX::BuoyancyAccumulator *v33; // rax
  RBX::BuoyancyAccumulator *v34; // rax
  unsigned int v35; // ebp
  size_t v36; // rax
  RBX::BuoyancyAccumulator *v37; // rbx
  const RBX::PV *PV; // rax
  const RBX::PV *v39; // rax
  float x; // xmm3_4
  __m128 v41; // xmm4
  __m128 v42; // xmm0
  __m128 v43; // xmm2
  __m128d v44; // xmm0
  float v45; // xmm4_4
  float v46; // xmm4_4
  RBX::BuoyancyAccumulator *v47; // rax
  uint8_t v48; // al
  __m128 v49; // xmm4
  float v50; // xmm3_4
  __m128 v51; // xmm4
  __m128d v52; // xmm0
  __m128 v53; // xmm0
  __m128 v54; // xmm3
  __m128 v55; // xmm2
  float v56; // xmm1_4
  __m128 v57; // xmm2
  float v58; // xmm0_4
  __m128 v59; // xmm4
  float v60; // xmm3_4
  int submergedFrames; // eax
  unsigned int v62; // r12d
  float v63; // xmm3_4
  __m128 v64; // xmm6
  __m128 v65; // xmm2
  float v66; // xmm7_4
  __m128 v67; // xmm0
  __m128 v68; // xmm0
  __m128 v69; // xmm1
  float v70; // xmm0_4
  int v71; // eax
  float v72; // [rsp+Ch] [rbp-DCh]
  __m128 v73; // [rsp+10h] [rbp-D8h]
  float v74; // [rsp+10h] [rbp-D8h]
  __m128 v75; // [rsp+10h] [rbp-D8h]
  __m128 v76; // [rsp+20h] [rbp-C8h]
  __m128 v77; // [rsp+20h] [rbp-C8h]
  __m128 submergeRatio_low; // [rsp+20h] [rbp-C8h]
  unsigned __int64 relativeVelocitya; // [rsp+30h] [rbp-B8h]
  float relativeVelocity; // [rsp+30h] [rbp-B8h]
  double v81; // [rsp+40h] [rbp-A8h]
  __m128 v82; // [rsp+40h] [rbp-A8h]
  __m128 v83; // [rsp+40h] [rbp-A8h]
  double v84; // [rsp+58h] [rbp-90h]
  unsigned __int64 v85; // [rsp+58h] [rbp-90h]
  double v86; // [rsp+60h] [rbp-88h] BYREF
  float v87; // [rsp+68h] [rbp-80h]
  unsigned int v88; // [rsp+6Ch] [rbp-7Ch]
  __m128 v89; // [rsp+70h] [rbp-78h]
  __m128 v90; // [rsp+80h] [rbp-68h]
  __m128 v91; // [rsp+90h] [rbp-58h]
  __m128 v92; // [rsp+A0h] [rbp-48h]
  double v93; // [rsp+B0h] [rbp-38h]
  const RBX::Vector3 v94; // 0:kr00_12.12
  const RBX::Vector3 v95; // 0:kr14_12.12
  const RBX::Vector3 v96; // 0:xmm0_8.8,8:xmm1_4.4 OVERLAPPED

  prim1 = this->prim1;
  num = this->buoyancyAccumulators.num;
  if ( num < 0 )
  {
    v4 = (this->buoyancyAccumulators.num >> 1) | this->buoyancyAccumulators.num & 1;
    v3 = (float)(int)v4 + (float)(int)v4;
  }
  else
  {
    v3 = (float)(int)num;
  }
  v5 = (__m128)0x3F800000u;
  v5.m128_f32[0] = 1.0 / v3;
  v90 = (__m128)*(unsigned __int64 *)&this->fullBuoyancy.x;
  v76 = v5;
  v72 = this->fullBuoyancy.z * (float)(1.0 / v3);
  value = stru_2AAF558.value;
  v89 = (__m128)(unsigned int)dword_2868AE8;
  v7 = RBX::Constants::kernelDt();
  v8 = this->buoyancyAccumulators.num;
  if ( v8 < 0 )
  {
    v10 = (this->buoyancyAccumulators.num >> 1) | this->buoyancyAccumulators.num & 1;
    v9 = (float)(int)v10 + (float)(int)v10;
  }
  else
  {
    v9 = (float)(int)v8;
  }
  v11 = _mm_xor_ps(v89, *(__m128 *)&stru_3E4970.x);
  v90 = _mm_mul_ps(v90, _mm_shuffle_ps(v76, v76, 224));
  v11.m128_f32[0] = (float)(v11.m128_f32[0] / v7) / v9;
  v89 = v11;
  if ( value )
  {
    v12 = *((_QWORD *)prim1 + 26);
    if ( v12 )
    {
      RBX::Cofm::updateIfDirty(*((RBX::Cofm **)prim1 + 26));
      v13 = *(float *)(v12 + 24);
      if ( !this->buoyancyAccumulators.num )
        return;
      goto LABEL_25;
    }
    if ( !*((_BYTE *)prim1 + 236)
      || (v13 = 0.0, *((RBX::Primitive **)prim1 + 25) == (RBX::Primitive *)((char *)prim1 + 152)) )
    {
      v13 = *((float *)prim1 + 78);
    }
    if ( v8 )
    {
LABEL_25:
      *(float *)&v88 = (float)dword_2868AD8 * (float)(v13 * *(float *)a33dc);
      v35 = 1;
      v36 = 0;
      do
      {
        v37 = this->buoyancyAccumulators.data.elems[v36];
        if ( v37->submergeRatio <= 0.0 )
        {
          _mm_storel_ps((double *)&v37->force.x, (__m128)0LL);
          v37->force.z = 0.0;
          v47 = this->buoyancyAccumulators.data.elems[v36];
          _mm_storel_ps((double *)&v47->torque.x, (__m128)0LL);
          v47->torque.z = 0.0;
          v48 = 0;
LABEL_47:
          this->submergedFrames = v48;
          goto LABEL_48;
        }
        submergeRatio_low = (__m128)LODWORD(v37->submergeRatio);
        PV = RBX::Primitive::getPV(prim1);
        v83 = (__m128)*(unsigned __int64 *)&PV->velocity.linear.x;
        relativeVelocity = PV->velocity.linear.z;
        v39 = RBX::Primitive::getPV(prim1);
        x = v39->velocity.rotational.x;
        v41 = (__m128)*(unsigned __int64 *)&v39->velocity.rotational.y;
        v42 = _mm_mul_ps(v83, v83);
        v43 = (__m128)LODWORD(relativeVelocity);
        v43.m128_f32[0] = (float)(v43.m128_f32[0] * v43.m128_f32[0])
                        + (float)(_mm_shuffle_ps(v42, v42, 229).m128_f32[0] + v42.m128_f32[0]);
        if ( v43.m128_f32[0] == 0.0 )
          goto LABEL_31;
        v44 = (__m128d)_mm_and_ps(v43, (__m128)xmmword_3E5B40);
        v84 = *(float *)v44.m128d_f64;
        v93 = *(float *)v44.m128d_f64 + 1.0;
        v73 = v41;
        v92 = v43;
        v91.m128_f32[0] = x;
        v44.m128d_f64[0] = G3D::inf();
        v41 = v73;
        v44.m128d_f64[0] = _mm_cmpeq_sd(v44, (__m128d)*(unsigned __int64 *)&v93).m128d_f64[0];
        if ( COERCE_DOUBLE(
               *(_QWORD *)&v44.m128d_f64[0] & 0x3EE4F8B580000000LL
             | ~*(_QWORD *)&v44.m128d_f64[0] & COERCE_UNSIGNED_INT64(v93 * 0.000009999999747378752)) >= v84 )
        {
LABEL_31:
          v49 = _mm_mul_ps(v41, v41);
          v50 = (float)(x * x) + v49.m128_f32[0];
          v51 = _mm_shuffle_ps(v49, v49, 229);
          v51.m128_f32[0] = v51.m128_f32[0] + v50;
          if ( v51.m128_f32[0] == 0.0 )
            goto LABEL_44;
          v52 = (__m128d)_mm_and_ps(v51, (__m128)xmmword_3E5B40);
          *(double *)v91.m128_u64 = *(float *)v52.m128d_f64;
          *(double *)&v85 = *(float *)v52.m128d_f64 + 1.0;
          v74 = v51.m128_f32[0];
          v92 = v43;
          v52.m128d_f64[0] = G3D::inf();
          v46 = v74;
          v52.m128d_f64[0] = _mm_cmpeq_sd(v52, (__m128d)v85).m128d_f64[0];
          if ( COERCE_DOUBLE(
                 *(_QWORD *)&v52.m128d_f64[0] & 0x3EE4F8B580000000LL
               | ~*(_QWORD *)&v52.m128d_f64[0] & COERCE_UNSIGNED_INT64(*(double *)&v85 * 0.000009999999747378752)) >= *(double *)v91.m128_u64 )
          {
LABEL_44:
            v70 = v72 * submergeRatio_low.m128_f32[0];
            v69 = _mm_mul_ps(_mm_shuffle_ps(submergeRatio_low, submergeRatio_low, 224), v90);
            goto LABEL_45;
          }
        }
        else
        {
          v45 = _mm_shuffle_ps(v73, v73, 229).m128_f32[0];
          v46 = (float)(v45 * v45) + (float)((float)(v73.m128_f32[0] * v73.m128_f32[0]) + (float)(x * x));
        }
        v53 = (__m128)xmmword_3E8010;
        v53.m128_f32[0] = fmaxf(0.000001, fsqrt(v43.m128_f32[0]));
        v54 = 0;
        v54.m128_f32[0] = (float)dword_2868AB8;
        v55 = 0;
        v55.m128_f32[0] = fsqrt(v46);
        v56 = (float)dword_2868AA8 / 10.0;
        v57 = _mm_div_ps(_mm_unpacklo_ps(v55, v54), v53);
        v58 = 0.0;
        v59 = 0;
        if ( v56 < v57.m128_f32[0] )
        {
          v60 = _mm_shuffle_ps(v57, v57, 229).m128_f32[0];
          v59 = (__m128)0x3F800000u;
          if ( v57.m128_f32[0] < v60 )
          {
            v57.m128_f32[0] = (float)(v57.m128_f32[0] - v56) / (float)(v60 - v56);
            v59 = v57;
          }
        }
        submergedFrames = this->submergedFrames;
        if ( (int)accum <= submergedFrames )
        {
          v58 = 1.0;
          if ( dword_2868A98 + (int)accum > submergedFrames )
            v58 = (float)(submergedFrames - (int)accum) / (float)dword_2868A98;
        }
        v62 = v35 - 1;
        v59.m128_f32[0] = v59.m128_f32[0] * v58;
        v63 = 0.0;
        v64 = 0;
        v65 = 0;
        v66 = 0.0;
        v75 = v59;
        if ( v59.m128_f32[0] < 1.0 )
        {
          *(_QWORD *)&v96.x = v83.m128_u64[0];
          v96.z = relativeVelocity;
          *(_QWORD *)&v94.x = 0;
          LODWORD(v94.z) = v59.m128_i32[0];
          *(__m128 *)&v96.x = RBX::Collision::BuoyancyContact::calculateLinearViscousForce(
                                this,
                                prim1,
                                v96,
                                v62,
                                v89,
                                (RBX::BuoyancyAccumulator *)(unsigned int)accum,
                                v94,
                                submergeRatio_low);
          v64 = 0;
          v63 = 0.0;
          v59 = v75;
          v65 = *(__m128 *)&v96.x;
          v66 = relativeVelocity;
        }
        if ( v59.m128_f32[0] > 0.0 )
        {
          LODWORD(v95.x) = v65.m128_i32[0];
          LODWORD(v95.y) = v65.m128_i32[1];
          v95.z = 0.0;
          v67 = RBX::Collision::BuoyancyContact::calculateVSquaredViscousForce(
                  this,
                  prim1,
                  v37,
                  v62,
                  v89,
                  (__m128)v88,
                  v95,
                  submergeRatio_low);
          v59 = v75;
          v64 = v67;
          v63 = *(float *)&v88;
        }
        v68 = (__m128)0x3F800000u;
        v68.m128_f32[0] = 1.0 - v59.m128_f32[0];
        v69 = _mm_add_ps(
                _mm_mul_ps(_mm_shuffle_ps(submergeRatio_low, submergeRatio_low, 224), v90),
                _mm_add_ps(
                  _mm_mul_ps(_mm_shuffle_ps(v59, v59, 224), v64),
                  _mm_mul_ps(_mm_shuffle_ps(v68, v68, 224), v65)));
        v70 = (float)(v72 * submergeRatio_low.m128_f32[0])
            + (float)((float)(v63 * v59.m128_f32[0]) + (float)((float)(1.0 - v59.m128_f32[0]) * v66));
LABEL_45:
        _mm_storel_ps((double *)&v37->force.x, v69);
        v37->force.z = v70;
        v71 = this->submergedFrames;
        if ( (int)accum + dword_2868A98 > v71 )
        {
          v48 = v71 + 1;
          goto LABEL_47;
        }
LABEL_48:
        v36 = v35++;
      }
      while ( this->buoyancyAccumulators.num > v36 );
    }
  }
  else if ( v8 )
  {
    v91 = _mm_shuffle_ps(v89, v89, 224);
    v14 = 1;
    v15 = 0;
    do
    {
      v16 = this->buoyancyAccumulators.data.elems[v15];
      if ( v16->submergeRatio <= 0.0 )
      {
        _mm_storel_ps((double *)&v16->force.x, (__m128)0LL);
        v16->force.z = 0.0;
      }
      else
      {
        v77 = (__m128)LODWORD(v16->submergeRatio);
        v17 = RBX::Primitive::getPV(prim1);
        x_low = (__m128)LODWORD(v17->velocity.linear.x);
        v19 = _mm_mul_ps(
                (__m128)*(unsigned __int64 *)&v17->velocity.linear.y,
                (__m128)*(unsigned __int64 *)&v17->velocity.linear.y);
        v20 = (float)(x_low.m128_f32[0] * x_low.m128_f32[0]) + v19.m128_f32[0];
        v21 = _mm_shuffle_ps(v19, v19, 229);
        v21.m128_f32[0] = v21.m128_f32[0] + v20;
        if ( v21.m128_f32[0] == 0.0
          || (v22 = (__m128d)_mm_and_ps(v21, (__m128)xmmword_3E5B40),
              v81 = *(float *)v22.m128d_f64,
              *(double *)&relativeVelocitya = *(float *)v22.m128d_f64 + 1.0,
              v92 = (__m128)*(unsigned __int64 *)&v17->velocity.linear.y,
              v22.m128d_f64[0] = G3D::inf(),
              v22.m128d_f64[0] = _mm_cmpeq_sd(v22, (__m128d)relativeVelocitya).m128d_f64[0],
              COERCE_DOUBLE(
                *(_QWORD *)&v22.m128d_f64[0] & 0x3EE4F8B580000000LL
              | ~*(_QWORD *)&v22.m128d_f64[0]
              & COERCE_UNSIGNED_INT64(*(double *)&relativeVelocitya * 0.000009999999747378752)) >= v81) )
        {
          v34 = this->buoyancyAccumulators.data.elems[v15];
          _mm_storel_ps((double *)&v34->force.x, _mm_mul_ps(_mm_shuffle_ps(v77, v77, 224), v90));
          v34->force.z = v72 * v77.m128_f32[0];
        }
        else
        {
          CoordinateFrame = RBX::Primitive::getCoordinateFrame(prim1);
          v24 = _mm_shuffle_ps(v92, v92, 229);
          v25 = CoordinateFrame->rotation.elt[2][2] * v24.m128_f32[0];
          v26 = _mm_add_ps(
                  _mm_mul_ps(v24, (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[2][0]),
                  _mm_add_ps(
                    _mm_mul_ps(
                      _mm_shuffle_ps(v92, v92, 224),
                      (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[1][0]),
                    _mm_mul_ps(
                      _mm_shuffle_ps(x_low, x_low, 224),
                      (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[0][0])));
          v27 = (__m128)LODWORD(CoordinateFrame->rotation.elt[1][2]);
          v28 = v25
              + (float)((float)(v27.m128_f32[0] * v92.m128_f32[0])
                      + (float)(x_low.m128_f32[0] * CoordinateFrame->rotation.elt[0][2]));
          _mm_storel_ps(&v86, v26);
          v87 = v28;
          *(double *)v27.m128_u64 = (*((double (__fastcall **)(RBX::Collision::BuoyancyContact *, _QWORD, double *))this->_vptr$Contact
                                     + 20))(
                                      this,
                                      v14 - 1,
                                      &v86);
          v29 = (__m128)LODWORD(v86);
          v29.m128_f32[0] = *(float *)&v86 * v27.m128_f32[0];
          v30 = _mm_shuffle_ps(v27, v27, 229);
          v30.m128_f32[0] = v30.m128_f32[0] * *((float *)&v86 + 1);
          v26.m128_f32[0] = v26.m128_f32[0] * v87;
          v82 = v26;
          v31 = RBX::Primitive::getCoordinateFrame(prim1);
          v32 = _mm_mul_ps(
                  _mm_add_ps(
                    _mm_mul_ps(
                      _mm_shuffle_ps(v82, v82, 224),
                      _mm_unpacklo_ps(
                        (__m128)LODWORD(v31->rotation.elt[0][2]),
                        (__m128)LODWORD(v31->rotation.elt[1][2]))),
                    _mm_add_ps(
                      _mm_mul_ps(
                        _mm_shuffle_ps(v30, v30, 224),
                        _mm_unpacklo_ps(
                          (__m128)LODWORD(v31->rotation.elt[0][1]),
                          (__m128)LODWORD(v31->rotation.elt[1][1]))),
                      _mm_mul_ps(
                        _mm_shuffle_ps(v29, v29, 224),
                        _mm_unpacklo_ps(
                          (__m128)LODWORD(v31->rotation.elt[0][0]),
                          (__m128)LODWORD(v31->rotation.elt[1][0]))))),
                  v91);
          v30.m128_f32[0] = (float)((float)(v82.m128_f32[0] * v31->rotation.elt[2][2])
                                  + (float)((float)(v30.m128_f32[0] * v31->rotation.elt[2][1])
                                          + (float)(v29.m128_f32[0] * v31->rotation.elt[2][0])))
                          * v89.m128_f32[0];
          v33 = this->buoyancyAccumulators.data.elems[v15];
          _mm_storel_ps((double *)&v33->force.x, _mm_mul_ps(_mm_shuffle_ps(v77, v77, 224), _mm_add_ps(v32, v90)));
          v33->force.z = (float)(v30.m128_f32[0] + v72) * v77.m128_f32[0];
        }
      }
      v15 = v14++;
    }
    while ( this->buoyancyAccumulators.num > v15 );
  }
}


// Address: 0x1dee9c0 | Name: _ZN3RBX9Collision15BuoyancyContact18computeIsCollidingEf
char __fastcall RBX::Collision::BuoyancyContact::computeIsColliding(
        RBX::Collision::BuoyancyContact *this,
        double a2,
        float overlapIgnored)
{
  if ( !(*((unsigned __int8 (__fastcall **)(RBX::Collision::BuoyancyContact *, RBX::Primitive *, double, float))this->_vptr$Contact
         + 14))(
          this,
          this->prim1,
          a2,
          overlapIgnored) )
    return 0;
  if ( !this->buoyancyAccumulators.num )
    (*((void (__fastcall **)(RBX::Collision::BuoyancyContact *))this->_vptr$Contact + 15))(this);
  (*((void (__fastcall **)(RBX::Collision::BuoyancyContact *))this->_vptr$Contact + 16))(this);
  (*((void (__fastcall **)(RBX::Collision::BuoyancyContact *))this->_vptr$Contact + 17))(this);
  RBX::Collision::BuoyancyContact::updateBuoyancyAccumulators(this);
  RBX::Primitive::onBuoyancyChanged(this->prim1, 1);
  return 1;
}


// Address: 0x1deea70 | Name: _ZN3RBX9Collision19BuoyancyBallContact25getSurfaceAreaInDirectionERKN3G3D7Vector3ERfS6_
void __fastcall RBX::Collision::BuoyancyBallContact::getSurfaceAreaInDirection(
        RBX::Collision::BuoyancyBallContact *this,
        const RBX::Vector3 *relativeVelocity,
        float *crossArea,
        float *tangentArea)
{
  *crossArea = this->crossSectionArea;
  *tangentArea = this->crossSectionArea + this->crossSectionArea;
}


// Address: 0x1deea90 | Name: _ZN3RBX9Collision19BuoyancyBallContact16getCrossSectionsEiRKN3G3D7Vector3E
RBX::Vector3 __fastcall RBX::Collision::BuoyancyBallContact::getCrossSections(
        RBX::Collision::BuoyancyBallContact *this,
        int a2,
        const RBX::Vector3 *a3)
{
  __m128 crossSectionArea_low; // xmm1
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  crossSectionArea_low = (__m128)LODWORD(this->crossSectionArea);
  crossSectionArea_low.m128_f32[0] = crossSectionArea_low.m128_f32[0] * 0.125;
  *(_QWORD *)&result.x = _mm_shuffle_ps(crossSectionArea_low, crossSectionArea_low, 224).m128_u64[0];
  result.z = crossSectionArea_low.m128_f32[0];
  return result;
}


// Address: 0x1deeab0 | Name: _ZN3RBX9Collision19BuoyancyBallContact15isTouchingWaterEPNS_9PrimitiveE
bool __fastcall RBX::Collision::BuoyancyBallContact::isTouchingWater(
        RBX::Collision::BuoyancyBallContact *this,
        RBX::Primitive *prim)
{
  const RBX::PV *PV; // rax
  float z; // xmm2_4
  bool v4; // bp
  __int64 v5; // rax
  __m128 v6; // xmm0
  float v7; // xmm1_4
  __m128 v8; // xmm0
  __m128 v9; // xmm0
  __m128 v10; // xmm0
  __m128 v11; // xmm0
  __m128 v12; // xmm0
  RBX::Vector3 waterLevel; // [rsp+8h] [rbp-50h] BYREF
  float v15; // [rsp+14h] [rbp-44h] BYREF
  RBX::Extents cellPos; // [rsp+18h] [rbp-40h] BYREF
  __m128 v17; // [rsp+30h] [rbp-28h]
  RBX::Vector3 v18; // 0:kr00_12.12
  RBX::Vector3 v19; // 0:kr14_12.12
  RBX::Vector3 v20; // 0:kr20_12.12
  RBX::Vector3 v21; // 0:kr34_12.12
  RBX::Vector3 v22; // 0:kr40_12.12
  RBX::Vector3 v23; // 0:kr54_12.12

  PV = RBX::Primitive::getPV(prim);
  z = PV->position.translation.z;
  v17 = (__m128)*(unsigned __int64 *)&PV->position.translation.x;
  _mm_storel_ps((double *)&cellPos.low.x, _mm_mul_ps((__m128)xmmword_3E8550, v17));
  cellPos.low.z = 0.25 * z;
  v4 = 1;
  if ( !RBX::MegaClusterInstance::isPointUnderwater(&cellPos.low, this->smoothGrid, &waterLevel.x) )
  {
    v5 = *((_QWORD *)prim + 18);
    v6 = _mm_mul_ps((__m128)*(unsigned __int64 *)(v5 + 8), *(__m128 *)&stru_3EB1B0.x);
    v7 = *(float *)(v5 + 16) * 0.5;
    _mm_storel_ps((double *)&cellPos.low.x, _mm_xor_ps(v6, *(__m128 *)&stru_3E4970.x));
    cellPos.low.z = -v7;
    _mm_storel_ps((double *)&cellPos.high.x, v6);
    cellPos.high.z = v7;
    v18 = RBX::Extents::faceCenter(&cellPos, RBX::NormalId::NORM_X);
    v6.m128_i32[0] = LODWORD(v18.x);
    v6.m128_i32[1] = LODWORD(v18.y);
    v8 = _mm_mul_ps(_mm_add_ps(v6, v17), (__m128)xmmword_3E8550);
    _mm_storel_ps((double *)&waterLevel.x, v8);
    waterLevel.z = (float)(v18.z + z) * 0.25;
    v4 = 1;
    if ( !RBX::MegaClusterInstance::isPointUnderwater(&waterLevel, this->smoothGrid, &v15) )
    {
      v19 = RBX::Extents::faceCenter(&cellPos, RBX::NormalId::NORM_Y);
      v8.m128_i32[0] = LODWORD(v19.x);
      v8.m128_i32[1] = LODWORD(v19.y);
      v9 = _mm_mul_ps(_mm_add_ps(v8, v17), (__m128)xmmword_3E8550);
      _mm_storel_ps((double *)&waterLevel.x, v9);
      waterLevel.z = (float)(v19.z + z) * 0.25;
      if ( !RBX::MegaClusterInstance::isPointUnderwater(&waterLevel, this->smoothGrid, &v15) )
      {
        v20 = RBX::Extents::faceCenter(&cellPos, RBX::NormalId::NORM_Z);
        v9.m128_i32[0] = LODWORD(v20.x);
        v9.m128_i32[1] = LODWORD(v20.y);
        v10 = _mm_mul_ps(_mm_add_ps(v9, v17), (__m128)xmmword_3E8550);
        _mm_storel_ps((double *)&waterLevel.x, v10);
        waterLevel.z = (float)(v20.z + z) * 0.25;
        if ( !RBX::MegaClusterInstance::isPointUnderwater(&waterLevel, this->smoothGrid, &v15) )
        {
          v21 = RBX::Extents::faceCenter(&cellPos, RBX::NormalId::NORM_X_NEG);
          v10.m128_i32[0] = LODWORD(v21.x);
          v10.m128_i32[1] = LODWORD(v21.y);
          v11 = _mm_mul_ps(_mm_add_ps(v10, v17), (__m128)xmmword_3E8550);
          _mm_storel_ps((double *)&waterLevel.x, v11);
          waterLevel.z = (float)(v21.z + z) * 0.25;
          if ( !RBX::MegaClusterInstance::isPointUnderwater(&waterLevel, this->smoothGrid, &v15) )
          {
            v22 = RBX::Extents::faceCenter(&cellPos, RBX::NormalId::NORM_Y_NEG);
            v11.m128_i32[0] = LODWORD(v22.x);
            v11.m128_i32[1] = LODWORD(v22.y);
            v12 = _mm_mul_ps(_mm_add_ps(v11, v17), (__m128)xmmword_3E8550);
            _mm_storel_ps((double *)&waterLevel.x, v12);
            waterLevel.z = (float)(v22.z + z) * 0.25;
            if ( !RBX::MegaClusterInstance::isPointUnderwater(&waterLevel, this->smoothGrid, &v15) )
            {
              v23 = RBX::Extents::faceCenter(&cellPos, RBX::NormalId::NORM_Z_NEG);
              v12.m128_i32[0] = LODWORD(v23.x);
              v12.m128_i32[1] = LODWORD(v23.y);
              _mm_storel_ps((double *)&waterLevel.x, _mm_mul_ps(_mm_add_ps(v17, v12), (__m128)xmmword_3E8550));
              waterLevel.z = (float)(z + v23.z) * 0.25;
              return RBX::MegaClusterInstance::isPointUnderwater(&waterLevel, this->smoothGrid, &v15);
            }
          }
        }
      }
    }
  }
  return v4;
}


// Address: 0x1deed60 | Name: _ZN3RBX9Collision19BuoyancyBallContact26createBuoyancyAccumulatorsEv
void __fastcall RBX::Collision::BuoyancyBallContact::createBuoyancyAccumulators(
        RBX::Collision::BuoyancyBallContact *this)
{
  _DWORD *v1; // rax
  char *v2; // rcx
  size_t num; // rcx

  v1 = operator new(0x48u);
  v2 = (char *)this->prim1 + 152;
  *(_BYTE *)v1 = 1;
  v1[4] = -1;
  *((_QWORD *)v1 + 3) = v2;
  *((_OWORD *)v1 + 3) = 0;
  *((_OWORD *)v1 + 2) = 0;
  v1[16] = 0;
  num = this->buoyancyAccumulators.num;
  this->buoyancyAccumulators.data.elems[num] = (RBX::BuoyancyAccumulator *)v1;
  this->buoyancyAccumulators.num = num + 1;
}


// Address: 0x1deedb0 | Name: _ZN3RBX9Collision19BuoyancyBallContact15updateWaterBandEv
void __fastcall RBX::Collision::BuoyancyBallContact::updateWaterBand(RBX::Collision::BuoyancyBallContact *this)
{
  const RBX::PV *PV; // rax
  __m128 v2; // xmm2
  __m128 v3; // xmm1
  float z; // xmm0_4
  __m128 radius_low; // xmm3
  __m128 v6; // xmm3
  __m128i v7; // xmm0
  int v8; // ebp
  bool v9; // al
  int v10; // ecx
  __m128i v11; // xmm0
  __m128i v12; // xmm1
  __m128 v13; // xmm2
  float v14; // xmm0_4
  __m128 v15; // xmm1
  bool isPointUnderwater; // al
  __int32 v17; // xmm0_4
  __m128 v18; // xmm0
  int v19; // xmm0_4
  float v20; // xmm0_4
  int v21; // xmm0_4
  float v22; // xmm0_4
  __m128i v23; // xmm1
  RBX::BuoyancyAccumulator *v24; // rax
  float v25; // [rsp+0h] [rbp-A8h]
  float v26; // [rsp+0h] [rbp-A8h]
  float v27; // [rsp+0h] [rbp-A8h]
  unsigned int v28; // [rsp+4h] [rbp-A4h] BYREF
  RBX::Vector3 cellPos; // [rsp+8h] [rbp-A0h] BYREF
  float v30; // [rsp+18h] [rbp-90h] BYREF
  float v31; // [rsp+1Ch] [rbp-8Ch]
  __m128 v32; // [rsp+20h] [rbp-88h]
  RBX::Vector3 worldMaxSearch; // [rsp+30h] [rbp-78h] BYREF
  __m128 v34; // [rsp+40h] [rbp-68h]
  __m128 v35; // [rsp+50h] [rbp-58h]
  __m128 v36; // [rsp+60h] [rbp-48h]
  RBX::Vector3 worldpos; // [rsp+70h] [rbp-38h] BYREF
  __m128 v38; // [rsp+80h] [rbp-28h]

  PV = RBX::Primitive::getPV(this->prim1);
  v2 = (__m128)_mm_loadl_epi64((const __m128i *)&PV->position.translation);
  v3 = (__m128)_mm_shuffle_epi32((__m128i)v2, 229);
  z = PV->position.translation.z;
  radius_low = (__m128)LODWORD(this->radius);
  v34 = v3;
  v3.m128_f32[0] = v3.m128_f32[0] - radius_low.m128_f32[0];
  v31 = z;
  v35 = v2;
  v6 = _mm_add_ps(_mm_shuffle_ps(_mm_shuffle_ps(radius_low, (__m128)0LL, 0), (__m128)0LL, 226), v2);
  v38 = _mm_shuffle_ps(v6, v6, 229);
  v32 = v3;
  _mm_storel_ps((double *)&worldpos.x, _mm_shuffle_ps(_mm_shuffle_ps(v3, v6, 0), v6, 226));
  worldpos.z = z + 0.0;
  v36 = v6;
  _mm_storel_ps((double *)&worldMaxSearch.x, v6);
  v25 = z + 0.0;
  worldMaxSearch.z = z + 0.0;
  if ( !RBX::Collision::BuoyancyContact::hasDistanceSubmergedUnderWater(this, &worldpos, (float *)&v28, &worldMaxSearch) )
  {
    if ( RBX::Collision::BuoyancyContact::worldPosAboveWater(this, &worldMaxSearch, (int)v32.m128_f32[0], (float *)&v28) )
    {
      v11 = (__m128i)v28;
      v12 = (__m128i)v38;
      *(float *)v12.m128i_i32 = v38.m128_f32[0] - *(float *)&v28;
      v8 = _mm_cvtsi128_si32(v12);
      *(float *)v11.m128i_i32 = *(float *)&v28 - v32.m128_f32[0];
    }
    else
    {
      v13 = v34;
      v13.m128_f32[0] = v34.m128_f32[0] + 0.0;
      v14 = (float)(v35.m128_f32[0] - this->radius) * 0.25;
      v34 = _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(v13, v36, 0), v36, 226), (__m128)xmmword_3E8550);
      v15 = v34;
      v15.m128_f32[0] = v14;
      _mm_storel_ps((double *)&cellPos.x, v15);
      v26 = v25 * 0.25;
      cellPos.z = v26;
      isPointUnderwater = RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v30);
      v17 = 1065353216;
      v32.m128_i32[0] = 1065353216;
      if ( !isPointUnderwater )
        v17 = 0;
      v36.m128_i32[0] = v17;
      v18 = v34;
      v18.m128_f32[0] = (float)(v35.m128_f32[0] + this->radius) * 0.25;
      _mm_storel_ps((double *)&cellPos.x, v18);
      cellPos.z = v26;
      v19 = 1065353216;
      if ( !RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v30) )
        v19 = 0;
      v27 = *(float *)&v19;
      v20 = (float)(v31 - this->radius) * 0.25;
      _mm_storel_ps((double *)&cellPos.x, v34);
      cellPos.z = v20;
      v21 = 1065353216;
      if ( !RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v30) )
        v21 = 0;
      v35.m128_i32[0] = v21;
      v22 = (float)(v31 + this->radius) * 0.25;
      _mm_storel_ps((double *)&cellPos.x, v34);
      cellPos.z = v22;
      if ( !RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v30) )
        v32.m128_i32[0] = 0;
      v23 = (__m128i)v36.m128_u32[0];
      *(float *)v23.m128i_i32 = (float)((float)(v36.m128_f32[0] + v27) + v35.m128_f32[0]) + v32.m128_f32[0];
      v8 = _mm_cvtsi128_si32(v23);
      v11 = (__m128i)0x40800000u;
      *(float *)v11.m128i_i32 = 4.0 - *(float *)v23.m128i_i32;
    }
    goto LABEL_15;
  }
  v7 = (__m128i)v28;
  *(float *)v7.m128i_i32 = *(float *)&v28 - v32.m128_f32[0];
  v8 = _mm_cvtsi128_si32(v7);
  _mm_storel_ps((double *)&cellPos.x, _mm_mul_ps(v36, (__m128)xmmword_3E8550));
  cellPos.z = v25 * 0.25;
  v9 = RBX::MegaClusterInstance::isPointUnderwater(&cellPos, this->smoothGrid, &v30);
  v10 = -1082130432;
  if ( !v9 )
  {
    RBX::Collision::BuoyancyContact::worldPosAboveWater(this, &worldMaxSearch, (int)v32.m128_f32[0], (float *)&v28);
    v11 = (__m128i)v38;
    *(float *)v11.m128i_i32 = v38.m128_f32[0] - *(float *)&v28;
LABEL_15:
    v10 = _mm_cvtsi128_si32(v11);
  }
  v24 = this->buoyancyAccumulators.data.elems[0];
  LODWORD(v24->floatDistance) = v8;
  LODWORD(v24->sinkDistance) = v10;
}


// Address: 0x1def1d0 | Name: _ZN3RBX9Collision18BuoyancyBoxContact16getCrossSectionsEiRKN3G3D7Vector3E
RBX::Vector3 __fastcall RBX::Collision::BuoyancyBoxContact::getCrossSections(
        RBX::Collision::BuoyancyBoxContact *this,
        int i,
        const RBX::Vector3 *velocity)
{
  __int64 v3; // rax
  __m128 v4; // xmm0
  float v5; // xmm1_4
  __int64 v7; // rax
  float v8; // xmm1_4
  double v11; // [rsp+0h] [rbp-48h] BYREF
  float v12; // [rsp+8h] [rbp-40h]
  __int64 v13; // [rsp+Ch] [rbp-3Ch] BYREF
  int v14; // [rsp+14h] [rbp-34h]
  RBX::Extents v15; // [rsp+20h] [rbp-28h] BYREF
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  v3 = *((_QWORD *)this->prim1 + 18);
  v4 = _mm_mul_ps((__m128)*(unsigned __int64 *)(v3 + 8), *(__m128 *)&stru_3EB1B0.x);
  v5 = *(float *)(v3 + 16) * 0.5;
  _mm_storel_ps((double *)&v15.low.x, _mm_xor_ps(v4, *(__m128 *)&stru_3E4970.x));
  v15.low.z = -v5;
  _mm_storel_ps((double *)&v15.high.x, v4);
  v15.high.z = v5;
  *(RBX::Vector3int16 *)&v7 = RBX::Extents::getCornerIndex(&v15, i);
  v8 = this->crossSectionSurfaceAreas.z * 0.25;
  _mm_storel_ps(
    &v11,
    _mm_mul_ps((__m128)*(unsigned __int64 *)&this->crossSectionSurfaceAreas.x, (__m128)xmmword_3E8550));
  v12 = v8;
  _mm_storel_ps((double *)&v13, (__m128)0LL);
  v14 = 0;
  *(_QWORD *)&result.x = _mm_unpacklo_ps(
                           (__m128)*((unsigned int *)&v11 + 3 * ((velocity->x > 0.0) ^ (__int16)v7)),
                           (__m128)*((unsigned int *)&v11 + 3 * ((velocity->y > 0.0) ^ ((int)v7 >> 16)) + 1)).m128_u64[0];
  result.z = *(&v12 + 3 * ((velocity->z > 0.0) ^ SWORD2(v7)));
  return result;
}


// Address: 0x1def350 | Name: _ZN3RBX9Collision18BuoyancyBoxContact26createBuoyancyAccumulatorsEv
void __fastcall RBX::Collision::BuoyancyBoxContact::createBuoyancyAccumulators(
        RBX::Collision::BuoyancyBoxContact *this)
{
  __int64 v1; // rax
  __m128 v2; // xmm0
  float v3; // xmm1_4
  unsigned int i; // r12d
  char *v5; // rbx
  RBX::Primitive *prim1; // rbp
  size_t num; // rax
  RBX::Extents v8; // [rsp+8h] [rbp-40h] BYREF
  RBX::Vector3 Corner; // 0:kr00_12.12

  v1 = *((_QWORD *)this->prim1 + 18);
  v2 = _mm_mul_ps((__m128)*(unsigned __int64 *)(v1 + 8), *(__m128 *)&stru_3EB1B0.x);
  v3 = *(float *)(v1 + 16) * 0.5;
  _mm_storel_ps((double *)&v8.low.x, _mm_xor_ps(v2, *(__m128 *)&stru_3E4970.x));
  v8.low.z = -v3;
  _mm_storel_ps((double *)&v8.high.x, v2);
  v8.high.z = v3;
  for ( i = 0; i < 8; ++i )
  {
    v5 = (char *)operator new(0x48u);
    prim1 = this->prim1;
    Corner = RBX::Extents::getCorner(&v8, i);
    v2.m128_i32[0] = LODWORD(Corner.x);
    v2.m128_i32[1] = LODWORD(Corner.y);
    *v5 = 1;
    *((_DWORD *)v5 + 4) = -1;
    *((_QWORD *)v5 + 3) = (char *)prim1 + 152;
    _mm_storel_ps((double *)v5 + 4, _mm_mul_ps(v2, *(__m128 *)&stru_3EB1B0.x));
    *((float *)v5 + 10) = Corner.z * 0.5;
    v2 = 0;
    *(_OWORD *)(v5 + 44) = 0;
    *(_QWORD *)(v5 + 60) = 0;
    num = this->buoyancyAccumulators.num;
    this->buoyancyAccumulators.data.elems[num] = (RBX::BuoyancyAccumulator *)v5;
    this->buoyancyAccumulators.num = num + 1;
  }
}


// Address: 0x1def460 | Name: _ZN3RBX9Collision18BuoyancyBoxContact15updateWaterBandEv
void __fastcall RBX::Collision::BuoyancyBoxContact::updateWaterBand(RBX::Collision::BuoyancyBoxContact *this)
{
  size_t v1; // rbx
  __int64 v2; // rax
  __m128 v3; // xmm0
  float v4; // xmm1_4
  __m128 v5; // xmm2
  __m128 v6; // xmm3
  __m128 v7; // xmm4
  __m128 v8; // xmm2
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  RBX::BuoyancyAccumulator *v10; // rax
  float sinkDistance; // [rsp+8h] [rbp-80h] BYREF
  float floatDistance; // [rsp+Ch] [rbp-7Ch] BYREF
  RBX::Extents v13; // [rsp+10h] [rbp-78h] BYREF
  RBX::Extents v14; // [rsp+28h] [rbp-60h] BYREF
  RBX::Extents extents; // [rsp+40h] [rbp-48h] BYREF
  RBX::Vector3 Corner; // 0:kr00_12.12

  if ( this->buoyancyAccumulators.num )
  {
    v1 = 0;
    do
    {
      v2 = *((_QWORD *)this->prim1 + 18);
      v3 = _mm_mul_ps((__m128)*(unsigned __int64 *)(v2 + 8), *(__m128 *)&stru_3EB1B0.x);
      v4 = *(float *)(v2 + 16) * 0.5;
      _mm_storel_ps((double *)&v14.low.x, _mm_xor_ps(v3, *(__m128 *)&stru_3E4970.x));
      v14.low.z = -v4;
      _mm_storel_ps((double *)&v14.high.x, v3);
      v14.high.z = v4;
      Corner = RBX::Extents::getCorner(&v14, v1);
      v3.m128_i32[0] = LODWORD(Corner.x);
      v3.m128_i32[1] = LODWORD(Corner.y);
      v5 = 0;
      v5.m128_f32[0] = fminf(0.0, Corner.x);
      v6 = 0;
      v6.m128_f32[0] = fmaxf(0.0, Corner.x);
      v3.m128_i32[0] = _mm_shuffle_ps(v3, v3, 229).m128_u32[0];
      v7 = 0;
      v7.m128_f32[0] = fminf(0.0, v3.m128_f32[0]);
      _mm_storel_ps((double *)&v13.low.x, _mm_unpacklo_ps(v5, v7));
      v13.low.z = fminf(0.0, Corner.z);
      v8 = 0;
      v8.m128_f32[0] = fmaxf(0.0, v3.m128_f32[0]);
      _mm_storel_ps((double *)&v13.high.x, _mm_unpacklo_ps(v6, v8));
      v13.high.z = fmaxf(0.0, Corner.z);
      CoordinateFrame = RBX::Primitive::getCoordinateFrame(this->prim1);
      RBX::Extents::toWorldSpace(&extents, &v13, CoordinateFrame);
      RBX::Collision::BuoyancyContact::computeExtentsWaterBand(this, &extents, &floatDistance, &sinkDistance);
      v10 = this->buoyancyAccumulators.data.elems[v1];
      v10->floatDistance = floatDistance;
      v10->sinkDistance = sinkDistance;
      v1 = (unsigned int)(v1 + 1);
    }
    while ( this->buoyancyAccumulators.num > v1 );
  }
}


// Address: 0x1def5a0 | Name: _ZN3RBX9Collision18BuoyancyBoxContactC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::BuoyancyBoxContact::BuoyancyBoxContact(
        RBX::Collision::BuoyancyBoxContact *this,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  RBX::Primitive *prim1; // rcx
  __int64 v5; // rax
  __int64 v6; // rcx
  float v7; // [rsp+Ch] [rbp-1Ch]

  RBX::Collision::Contact::Contact(this, p0, p1);
  this->_vptr$Contact = (int (**)(void))&off_299DD10;
  this->radius = (*(float (__fastcall **)(RBX::Primitive *))(*(_QWORD *)p1 + 32LL))(p1);
  this->fullSurfaceArea = 0.0;
  this->submergedFrames = 0;
  this->fullBuoyancy.y = 0.0;
  *(_OWORD *)&this->buoyancyAccumulators.num = 0;
  prim1 = this->prim1;
  v7 = *(float *)(*((_QWORD *)this->prim0 + 17) + 176LL);
  this->fullBuoyancy.x = 0.0;
  this->fullBuoyancy.z = 0.0;
  this->fullBuoyancy.y = (*(float (__fastcall **)(_QWORD))(**((_QWORD **)prim1 + 18) + 208LL))(*((_QWORD *)prim1 + 18))
                       * v7;
  v5 = *((_QWORD *)p0 + 55);
  v6 = v5 - 128;
  if ( !v5 )
    v6 = 0;
  this->smoothGrid = *(RBX::Voxel2::Grid **)(v6 + 400);
  this->_vptr$Contact = (int (**)(void))&off_299DDC8;
  this->tangentSurfaceAreas.z = 0.0;
  *(_QWORD *)&this->tangentSurfaceAreas.x = 0;
  this->crossSectionSurfaceAreas.z = 0.0;
  *(_QWORD *)&this->crossSectionSurfaceAreas.x = 0;
}


// Address: 0x1def740 | Name: _ZN3RBX9Collision23BuoyancyCylinderContact19updateSubmergeRatioEv
void __fastcall RBX::Collision::BuoyancyCylinderContact::updateSubmergeRatio(
        RBX::Collision::BuoyancyCylinderContact *this)
{
  size_t num; // rax
  unsigned int v2; // ecx
  size_t i; // rdx
  RBX::BuoyancyAccumulator *v4; // rdx
  float floatDistance; // xmm1_4
  float sinkDistance; // xmm2_4
  __m128 v7; // xmm0
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  float v9; // xmm3_4
  float v10; // xmm2_4
  float v11; // xmm4_4
  float v12; // xmm1_4
  float x; // [rsp+8h] [rbp-20h]
  float xa; // [rsp+8h] [rbp-20h]
  float v15; // [rsp+Ch] [rbp-1Ch]
  float v16; // [rsp+10h] [rbp-18h]
  G3D::Vector3 v17; // 0:kr00_12.12

  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v2 = 1;
    for ( i = 0; i < num; i = v2++ )
    {
      v4 = this->buoyancyAccumulators.data.elems[i];
      floatDistance = v4->floatDistance;
      if ( floatDistance <= 0.0 )
      {
        v4->submergeRatio = 0.0;
      }
      else
      {
        sinkDistance = v4->sinkDistance;
        if ( sinkDistance <= 0.0 )
          v4->submergeRatio = 1.0;
        else
          v4->submergeRatio = floatDistance / (float)(sinkDistance + floatDistance);
      }
    }
  }
  v7 = (__m128)0xBF800000;
  x = (float)((float)((float)((float)(this->buoyancyAccumulators.data.elems[0]->submergeRatio
                                    + this->buoyancyAccumulators.data.elems[1]->submergeRatio)
                            + this->buoyancyAccumulators.data.elems[2]->submergeRatio)
                    + this->buoyancyAccumulators.data.elems[3]->submergeRatio)
            * 0.5)
    + -1.0;
  v15 = (float)((float)((float)((float)(this->buoyancyAccumulators.data.elems[4]->submergeRatio
                                      + this->buoyancyAccumulators.data.elems[5]->submergeRatio)
                              + this->buoyancyAccumulators.data.elems[6]->submergeRatio)
                      + this->buoyancyAccumulators.data.elems[7]->submergeRatio)
              * 0.5)
      + -1.0;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(this->prim1);
  v17 = G3D::Matrix3::column(&CoordinateFrame->rotation, 0);
  v7.m128_i32[0] = LODWORD(v17.x);
  v7.m128_i32[1] = LODWORD(v17.y);
  v9 = _mm_shuffle_ps(v7, v7, 229).m128_f32[0];
  v10 = fsqrt((float)(v17.z * v17.z) + (float)((float)(v9 * v9) + (float)(v7.m128_f32[0] * v7.m128_f32[0])));
  v16 = fabs(
          (float)((float)((float)(1.0 / v10) * v17.z) * 0.0)
        + (float)((float)((float)(v17.x * (float)(1.0 / v10)) * 0.0) + (float)(v9 * (float)(1.0 / v10))));
  xa = (float)((float)((float)(fsqrt(1.0 - (float)(x * x)) * x) + asinf(x)) * 0.31830987) + 0.5;
  v7.m128_f32[0] = asinf(v15);
  v11 = xa * (float)(1.0 - v16);
  this->buoyancyAccumulators.data.elems[0]->submergeRatio = (float)(this->buoyancyAccumulators.data.elems[0]->submergeRatio
                                                                  * v16)
                                                          + v11;
  this->buoyancyAccumulators.data.elems[1]->submergeRatio = (float)(this->buoyancyAccumulators.data.elems[1]->submergeRatio
                                                                  * v16)
                                                          + v11;
  this->buoyancyAccumulators.data.elems[2]->submergeRatio = (float)(this->buoyancyAccumulators.data.elems[2]->submergeRatio
                                                                  * v16)
                                                          + v11;
  this->buoyancyAccumulators.data.elems[3]->submergeRatio = (float)(this->buoyancyAccumulators.data.elems[3]->submergeRatio
                                                                  * v16)
                                                          + v11;
  v12 = (float)((float)((float)((float)(fsqrt(1.0 - (float)(v15 * v15)) * v15) + v7.m128_f32[0]) * 0.31830987) + 0.5)
      * (float)(1.0 - v16);
  this->buoyancyAccumulators.data.elems[4]->submergeRatio = (float)(this->buoyancyAccumulators.data.elems[4]->submergeRatio
                                                                  * v16)
                                                          + v12;
  this->buoyancyAccumulators.data.elems[5]->submergeRatio = (float)(this->buoyancyAccumulators.data.elems[5]->submergeRatio
                                                                  * v16)
                                                          + v12;
  this->buoyancyAccumulators.data.elems[6]->submergeRatio = (float)(this->buoyancyAccumulators.data.elems[6]->submergeRatio
                                                                  * v16)
                                                          + v12;
  this->buoyancyAccumulators.data.elems[7]->submergeRatio = (float)(this->buoyancyAccumulators.data.elems[7]->submergeRatio
                                                                  * v16)
                                                          + v12;
}


// Address: 0x1defcc0 | Name: _ZN3RBX9Collision15BuoyancyContactD2Ev
void __fastcall RBX::Collision::BuoyancyContact::~BuoyancyContact(RBX::Collision::BuoyancyContact *this)
{
  size_t num; // rax
  unsigned int v3; // ebp
  size_t i; // rcx
  RBX::BuoyancyAccumulator *v5; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299DD10;
  num = this->buoyancyAccumulators.num;
  if ( num )
  {
    v3 = 1;
    for ( i = 0; i < num; i = v3++ )
    {
      v5 = this->buoyancyAccumulators.data.elems[i];
      if ( v5 )
      {
        operator delete(v5);
        num = this->buoyancyAccumulators.num;
      }
    }
  }
  this->buoyancyAccumulators.num = 0;
  RBX::Primitive::onBuoyancyChanged(this->prim1, 0);
}


// Address: 0x1deffd0 | Name: _GLOBAL__sub_I_BuoyancyContacts.cpp
void __cdecl GLOBAL__sub_I_BuoyancyContacts_cpp()
{
  qword_2AAF540 = (__int64)boost::system::generic_category();
  qword_2AAF548 = (__int64)boost::system::generic_category();
  qword_2AAF550 = (__int64)boost::system::system_category();
  stru_2AAF558.value = 0;
  stru_2AAF558.name = "DebugRotationalViscocityEnabled2";
  dword_2AAF568 = FLog::RegisterFlag(
                    "DebugRotationalViscocityEnabled2",
                    &stru_2AAF558,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF56C = FLog::RegisterInt(
                    "NumberFramesSubmergedBeforeVSquaredViscocity",
                    (int *)&accum,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF570 = FLog::RegisterInt(
                    "NumberFramesSubmergedBeforeVSquareBlendFrames",
                    &dword_2868A98,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF574 = FLog::RegisterInt(
                    "LinearToVSquaredVelocityThresholdMinTenths",
                    &dword_2868AA8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF578 = FLog::RegisterInt(
                    "LinearToVSquaredVelocityThresholdMaxTenths",
                    &dword_2868AB8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF57C = FLog::RegisterInt("WaterViscosityDragFudgeFactor", &dword_2868AC8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF580 = FLog::RegisterInt("MaxViscousForceGravityTimesMult", &dword_2868AD8, FastVarType::FASTVARTYPE_DYNAMIC);
}


