// Address: 0x1d24300 | Name: _ZN3RBX19BuoyancyAccumulator22accumulateBuoyantForceEv
void __fastcall RBX::BuoyancyAccumulator::accumulateBuoyantForce(RBX::BuoyancyAccumulator *this)
{
  RBX::Body *buoyantBody; // rbx
  RBX::Body *root; // rax
  RBX::Solver::SolverRigidBody *rigidBody; // r15
  float x; // xmm1_4
  float y; // xmm0_4
  float z; // xmm6_4
  float v7; // xmm5_4
  float v8; // xmm7_4
  float v9; // xmm6_4
  float v10; // xmm5_4
  float v11; // xmm7_4
  float v12; // xmm6_4
  float v13; // xmm0_4
  float v14; // xmm2_4
  float v15; // xmm3_4
  RBX::Body *v16; // rax
  RBX::Solver::SolverRigidBody *v17; // rbx
  float v18; // [rsp+Ch] [rbp-1Ch]

  buoyantBody = this->buoyantBody;
  while ( _InterlockedCompareExchange(&buoyantBody->mx.sl.v, 1, 0) )
    ;
  if ( stru_2AABC90.value )
    RBX::Body::updatePVSafe(buoyantBody);
  else
    RBX::Body::updatePV(buoyantBody);
  _InterlockedCompareExchange(&buoyantBody->mx.sl.v, 0, 1);
  root = buoyantBody->root;
  rigidBody = root->rigidBody;
  if ( rigidBody )
  {
    x = this->position.x;
    y = this->position.y;
    z = this->position.z;
    v7 = (float)((float)(buoyantBody->pv.position.rotation.elt[0][2] * z)
               + (float)((float)(buoyantBody->pv.position.rotation.elt[0][1] * y)
                       + (float)(buoyantBody->pv.position.rotation.elt[0][0] * x)))
       + buoyantBody->pv.position.translation.x;
    v8 = (float)((float)(buoyantBody->pv.position.rotation.elt[1][2] * z)
               + (float)((float)(buoyantBody->pv.position.rotation.elt[1][1] * y)
                       + (float)(buoyantBody->pv.position.rotation.elt[1][0] * x)))
       + buoyantBody->pv.position.translation.y;
    v9 = (float)((float)(z * buoyantBody->pv.position.rotation.elt[2][2])
               + (float)((float)(y * buoyantBody->pv.position.rotation.elt[2][1])
                       + (float)(x * buoyantBody->pv.position.rotation.elt[2][0])))
       + buoyantBody->pv.position.translation.z;
    if ( rigidBody->dirty )
    {
      v18 = v7;
      RBX::Solver::SolverRigidBody::update(root->rigidBody);
      v7 = v18;
    }
    rigidBody->force.x = this->force.x + rigidBody->force.x;
    rigidBody->force.y = this->force.y + rigidBody->force.y;
    rigidBody->force.z = this->force.z + rigidBody->force.z;
    v10 = v7 - rigidBody->pv.position.translation.x;
    v11 = v8 - rigidBody->pv.position.translation.y;
    v12 = v9 - rigidBody->pv.position.translation.z;
    v13 = this->force.z;
    v14 = this->force.x;
    v15 = this->force.y;
    rigidBody->torque.x = (float)((float)(v11 * v13) - (float)(v12 * v15)) + rigidBody->torque.x;
    rigidBody->torque.y = (float)((float)(v12 * v14) - (float)(v13 * v10)) + rigidBody->torque.y;
    rigidBody->torque.z = (float)((float)(v10 * v15) - (float)(v11 * v14)) + rigidBody->torque.z;
  }
  v16 = this->buoyantBody->root;
  v17 = v16->rigidBody;
  if ( v17 )
  {
    if ( v17->dirty )
      RBX::Solver::SolverRigidBody::update(v16->rigidBody);
    v17->torque.x = this->torque.x + v17->torque.x;
    v17->torque.y = this->torque.y + v17->torque.y;
    v17->torque.z = this->torque.z + v17->torque.z;
  }
}


