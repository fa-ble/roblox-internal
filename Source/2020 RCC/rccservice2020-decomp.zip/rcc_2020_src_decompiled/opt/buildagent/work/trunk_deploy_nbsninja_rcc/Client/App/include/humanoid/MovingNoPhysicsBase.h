// Address: 0x10eccb0 | Name: _ZNK3RBX5HUMAN19MovingNoPhysicsBase17armsShouldCollideEv
bool __fastcall RBX::HUMAN::MovingNoPhysicsBase::armsShouldCollide(const RBX::HUMAN::MovingNoPhysicsBase *this)
{
  return 0;
}


// Address: 0x10eccc0 | Name: _ZNK3RBX5HUMAN19MovingNoPhysicsBase17legsShouldCollideEv
bool __fastcall RBX::HUMAN::MovingNoPhysicsBase::legsShouldCollide(const RBX::HUMAN::MovingNoPhysicsBase *this)
{
  return 0;
}


// Address: 0x10edee0 | Name: _ZNK3RBX5HUMAN19MovingNoPhysicsBase12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::MovingNoPhysicsBase::getStateType(
        const RBX::HUMAN::MovingNoPhysicsBase *this)
{
  return RBX::HUMAN::StateType::RUNNING_NO_PHYS;
}


