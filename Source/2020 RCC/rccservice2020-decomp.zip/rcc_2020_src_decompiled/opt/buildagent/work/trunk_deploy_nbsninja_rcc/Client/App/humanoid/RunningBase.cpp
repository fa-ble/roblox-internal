// Address: 0x10e9b80 | Name: _ZN3RBX5HUMAN11RunningBaseC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::RunningBase::RunningBase(
        RBX::HUMAN::RunningBase *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  __m128 v3; // xmm0
  const RBX::Humanoid *HumanoidConst; // rbx
  __m128 v5; // xmm0
  float v6; // xmm1_4
  __m128 v7; // xmm0
  __m128i v8; // xmm1
  __int128 v9; // xmm2
  __m128d v10; // xmm0
  __m128d v11; // xmm2
  RBX::PartInstance *TorsoFast; // rax
  RBX::Primitive *px; // rax
  __int64 v14; // rax
  __int64 v15; // rbx
  float v16; // [rsp+Ch] [rbp-6Ch]
  G3D::Vector3 v17; // [rsp+10h] [rbp-68h] BYREF
  __int128 v18; // [rsp+20h] [rbp-58h]
  __m128i v19; // [rsp+30h] [rbp-48h]
  __m128i v20; // [rsp+40h] [rbp-38h]
  RBX::Vector3 RelativeMovementVelocity; // 0:kr00_12.12

  RBX::HUMAN::Balancing::Balancing(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895EF0;
  v3 = 0;
  *(_OWORD *)((char *)this + 440) = 0;
  *(_OWORD *)((char *)this + 424) = 0;
  *(_OWORD *)((char *)this + 408) = 0;
  *(_OWORD *)((char *)this + 392) = 0;
  *((_DWORD *)this + 114) = 0;
  *((_DWORD *)this + 97) = 2139095040;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RelativeMovementVelocity = RBX::HUMAN::HumanoidState::getRelativeMovementVelocity(this);
  v3.m128_i32[0] = LODWORD(RelativeMovementVelocity.x);
  v3.m128_i32[1] = LODWORD(RelativeMovementVelocity.y);
  _mm_storel_ps((double *)&v17.x, v3);
  v17.z = RelativeMovementVelocity.z;
  *(G3D::Vector2 *)v3.m128_f32 = G3D::Vector3::xz(&v17);
  v5 = _mm_mul_ps(v3, v3);
  v6 = _mm_shuffle_ps(v5, v5, 229).m128_f32[0] + v5.m128_f32[0];
  v7 = 0;
  v7.m128_f32[0] = fsqrt(v6);
  RBX::HUMAN::HumanoidState::fireMovementSignal(this, (rbx::signal<void (float)> *)HumanoidConst + 329, v7, v6);
  if ( humanoid )
  {
    v8 = (__m128i)*((unsigned __int64 *)humanoid + 92);
    v9 = *((unsigned int *)humanoid + 186);
    v20 = v8;
    v19 = _mm_shuffle_epi32(v8, 229);
    v16 = *(float *)&v9;
    *(float *)&v9 = (float)(*(float *)&v9 * *(float *)&v9)
                  + (float)((float)(*(float *)v19.m128i_i32 * *(float *)v19.m128i_i32)
                          + (float)(*(float *)v8.m128i_i32 * *(float *)v8.m128i_i32));
    if ( *(float *)&v9 != 0.0 )
    {
      v18 = v9;
      v10.m128d_f64[0] = G3D::inf();
      v11 = (__m128d)0x3FF0000000000000uLL;
      v11.m128d_f64[0] = fabs(*(float *)&v18) + 1.0;
      v11.m128d_f64[0] = _mm_cmpeq_sd(v11, v10).m128d_f64[0];
      if ( COERCE_DOUBLE(
             *(_QWORD *)&v11.m128d_f64[0] & 0x3EE4F8B580000000LL
           | ~*(_QWORD *)&v11.m128d_f64[0]
           & COERCE_UNSIGNED_INT64((fabs(*(float *)&v18) + 1.0) * 0.000009999999747378752)) < fabs(*(float *)&v18) )
      {
        TorsoFast = RBX::Humanoid::getTorsoFast(humanoid);
        if ( TorsoFast )
        {
          px = TorsoFast->primitive.px;
          if ( px )
          {
            v14 = *((_QWORD *)px + 25);
            v15 = *(_QWORD *)(v14 + 64);
            if ( v15 )
            {
              if ( *(_BYTE *)(v15 + 1) )
                RBX::Solver::SolverRigidBody::update(*(RBX::Solver::SolverRigidBody **)(v14 + 64));
              *(float *)(v15 + 264) = *(float *)v20.m128i_i32 + *(float *)(v15 + 264);
              *(float *)(v15 + 268) = *(float *)v19.m128i_i32 + *(float *)(v15 + 268);
              *(float *)(v15 + 272) = v16 + *(float *)(v15 + 272);
            }
            *((_BYTE *)humanoid + 734) = 0;
            *((_QWORD *)humanoid + 92) = 0;
            *((_DWORD *)humanoid + 186) = 0;
          }
        }
      }
    }
  }
}


// Address: 0x10e9e00 | Name: _ZN3RBX5HUMAN11RunningBaseC2EPNS_8HumanoidENS0_9StateTypeEff
void __fastcall RBX::HUMAN::RunningBase::RunningBase(
        RBX::HUMAN::RunningBase *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState,
        float kP,
        float kD)
{
  __m128 v5; // xmm0
  const RBX::Humanoid *HumanoidConst; // r14
  __m128 v7; // xmm0
  float v8; // xmm1_4
  __m128 v9; // xmm0
  G3D::Vector3 v10; // [rsp+8h] [rbp-30h] BYREF
  RBX::Vector3 RelativeMovementVelocity; // 0:kr00_12.12

  RBX::HUMAN::Balancing::Balancing(this, humanoid, priorState, kP, kD);
  *(_QWORD *)this = &off_2895EF0;
  v5 = 0;
  *(_OWORD *)((char *)this + 440) = 0;
  *(_OWORD *)((char *)this + 424) = 0;
  *(_OWORD *)((char *)this + 408) = 0;
  *(_OWORD *)((char *)this + 392) = 0;
  *((_DWORD *)this + 114) = 0;
  *((_DWORD *)this + 97) = 2139095040;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RelativeMovementVelocity = RBX::HUMAN::HumanoidState::getRelativeMovementVelocity(this);
  v5.m128_i32[0] = LODWORD(RelativeMovementVelocity.x);
  v5.m128_i32[1] = LODWORD(RelativeMovementVelocity.y);
  _mm_storel_ps((double *)&v10.x, v5);
  v10.z = RelativeMovementVelocity.z;
  *(G3D::Vector2 *)v5.m128_f32 = G3D::Vector3::xz(&v10);
  v7 = _mm_mul_ps(v5, v5);
  v8 = _mm_shuffle_ps(v7, v7, 229).m128_f32[0] + v7.m128_f32[0];
  v9 = 0;
  v9.m128_f32[0] = fsqrt(v8);
  RBX::HUMAN::HumanoidState::fireMovementSignal(this, (rbx::signal<void (float)> *)HumanoidConst + 329, v9, v8);
}


// Address: 0x10e9f30 | Name: _ZN3RBX5HUMAN11RunningBase27onComputeForceImplOptimizedEPNS_8HumanoidEPNS_4BodyES5_
void __fastcall RBX::HUMAN::RunningBase::onComputeForceImplOptimized(
        RBX::HUMAN::RunningBase *this,
        RBX::Humanoid *humanoid,
        RBX::Body *torsoBody,
        RBX::Body *root)
{
  RBX::Primitive *FloorPrimitive; // r13
  __m128 v7; // xmm1
  __m128 v8; // xmm0
  __m128 v9; // xmm5
  __m128 v10; // xmm2
  RBX::Matrix3 *v11; // rcx
  RBX::Matrix3 *p_iBody; // rax
  float v13; // r14d
  RBX::Cofm *cofm; // rbp
  __int128 v15; // xmm0
  __int128 v16; // xmm1
  RBX::Matrix3 *p_moment; // rax
  RBX::Body *v18; // rax
  RBX::Solver::SolverRigidBody *rigidBody; // rbp
  float v20; // xmm5_4
  float v21; // xmm0_4
  float v22; // xmm2_4
  RBX::Cofm *v23; // rbp
  float *p_mass; // rbp
  RBX::Primitive *v25; // r14
  __m128 v26; // xmm0
  __m128 v27; // xmm1
  __m128 v28; // xmm0
  __m128 v29; // xmm3
  RBX::Solver::SolverRigidBody *v30; // rbp
  RBX::Velocity *p_velocity; // rbp
  RBX::Cofm *v32; // rbp
  RBX::Humanoid *v33; // r13
  float *v34; // rbp
  float v35; // xmm2_4
  char v36; // r12
  float v37; // xmm8_4
  RBX::Body *v38; // rax
  RBX::Solver::SolverRigidBody *v39; // rcx
  __m128 v40; // xmm7
  __m128 v41; // xmm7
  RBX::Cofm *v42; // rbp
  RBX::Cofm *v43; // rdi
  float *v44; // rbp
  float v45; // xmm0_4
  __m128 v46; // xmm2
  float v47; // xmm1_4
  float v48; // xmm3_4
  __m128 v49; // xmm5
  float v50; // xmm4_4
  float v51; // xmm1_4
  __m128 v52; // xmm1
  __m128 v53; // xmm0
  __m128 v54; // xmm0
  RBX::Matrix3 *v55; // rax
  __m128 v56; // xmm2
  __m128 v57; // xmm2
  float v58; // xmm0_4
  __m128i v59; // xmm1
  float v60; // xmm0_4
  __m128i si128; // xmm6
  float v62; // xmm5_4
  float v63; // xmm2_4
  float v64; // ebp
  float v65; // xmm0_4
  float v66; // xmm4_4
  RBX::Matrix3 *v67; // rax
  float v68; // xmm0_4
  __m128 v69; // xmm2
  __m128 v70; // xmm1
  int v71; // eax
  RBX::Body *v72; // rcx
  RBX::Solver::SolverRigidBody *v73; // rdx
  __m128 v74; // xmm11
  __m128 v75; // xmm4
  float z; // xmm3_4
  __m128 v77; // xmm4
  float v78; // xmm3_4
  __m128 v79; // xmm7
  __m128 v80; // xmm2
  float v81; // xmm3_4
  __m128 v82; // xmm4
  RBX::Cofm *v83; // rbp
  RBX::Cofm *v84; // rdi
  float *v85; // rbp
  float v86; // xmm0_4
  float v87; // xmm3_4
  __m128 v88; // xmm2
  float v89; // xmm11_4
  __m128 v90; // xmm7
  char v91; // al
  float v92; // xmm11_4
  __m128 v93; // xmm7
  __m128 v94; // xmm2
  float v95; // xmm0_4
  __m128 v96; // xmm8
  __m128 v97; // xmm1
  float v98; // xmm2_4
  float v99; // xmm3_4
  float v100; // xmm2_4
  float v101; // xmm1_4
  __m128 v102; // xmm2
  __m128 v103; // xmm3
  RBX::Body *v104; // rax
  RBX::Solver::SolverRigidBody *v105; // rcx
  __m128 v106; // xmm12
  RBX::Cofm *v107; // rbp
  float *v108; // rbp
  float v109; // xmm0_4
  float v110; // xmm2_4
  float v111; // xmm9_4
  float v112; // xmm1_4
  float v113; // xmm0_4
  float v114; // xmm2_4
  float v115; // xmm3_4
  __m128 v116; // xmm1
  float v117; // xmm5_4
  float v118; // xmm4_4
  __m128 v119; // xmm3
  float v120; // xmm4_4
  float v121; // xmm6_4
  float v122; // xmm5_4
  float v123; // xmm2_4
  float v124; // xmm0_4
  float v125; // xmm4_4
  __m128 v126; // xmm3
  RBX::Primitive *v127; // rax
  RBX::Humanoid *HumanoidConst; // rax
  RBX::HUMAN::StateType CurrentStateType; // eax
  const RBX::Humanoid *v130; // rax
  RBX::Humanoid *v131; // rax
  bool isFullySubmerged; // al
  RBX::Body *v133; // rax
  RBX::Solver::SolverRigidBody *v134; // rbp
  __m128 v135; // xmm1
  RBX::Solver::SolverRigidBody *v136; // rbp
  float v137; // xmm2_4
  float v138; // xmm2_4
  __m128 v139; // xmm5
  float v140; // xmm8_4
  float v141; // xmm4_4
  float v142; // xmm7_4
  float v143; // xmm2_4
  float v144; // xmm6_4
  float v145; // xmm1_4
  float v146; // xmm0_4
  float v147; // xmm1_4
  float v148; // xmm2_4
  RBX::PartInstance *v149; // rbp
  RBX::PartInstance *TorsoSlow; // rax
  volatile signed __int32 *v151; // rbp
  RBX::Solver::SolverRigidBody *v152; // rdi
  float v153; // xmm4_4
  float v154; // xmm1_4
  float v155; // xmm4_4
  __m128 v156; // xmm1
  float v157; // xmm4_4
  float v158; // xmm3_4
  float v159; // xmm4_4
  float v160; // xmm0_4
  bool IsSolid; // [rsp+Fh] [rbp-189h]
  float v162; // [rsp+10h] [rbp-188h]
  float v163; // [rsp+10h] [rbp-188h]
  float v164; // [rsp+10h] [rbp-188h]
  float v165; // [rsp+10h] [rbp-188h]
  float v166; // [rsp+10h] [rbp-188h]
  float v167; // [rsp+10h] [rbp-188h]
  float v168; // [rsp+10h] [rbp-188h]
  float v169; // [rsp+10h] [rbp-188h]
  float v170; // [rsp+10h] [rbp-188h]
  float v171; // [rsp+2Ch] [rbp-16Ch]
  float v172; // [rsp+2Ch] [rbp-16Ch]
  __m128 v173; // [rsp+30h] [rbp-168h]
  __m128 v174; // [rsp+30h] [rbp-168h]
  __m128 v175; // [rsp+30h] [rbp-168h]
  __m128 v176; // [rsp+30h] [rbp-168h]
  __m128 v177; // [rsp+40h] [rbp-158h]
  __m128 v178; // [rsp+40h] [rbp-158h]
  float y; // [rsp+50h] [rbp-148h]
  float v181; // [rsp+60h] [rbp-138h]
  float v182; // [rsp+60h] [rbp-138h]
  float x; // [rsp+6Ch] [rbp-12Ch]
  float v184; // [rsp+6Ch] [rbp-12Ch]
  float v185; // [rsp+70h] [rbp-128h]
  __m128 v186; // [rsp+70h] [rbp-128h]
  float v187; // [rsp+8Ch] [rbp-10Ch]
  float v188; // [rsp+90h] [rbp-108h]
  float v189; // [rsp+90h] [rbp-108h]
  float v190; // [rsp+ACh] [rbp-ECh] BYREF
  __m128 v191; // [rsp+B0h] [rbp-E8h]
  __m128 v192; // [rsp+C0h] [rbp-D8h]
  __m128 v193; // [rsp+D0h] [rbp-C8h]
  float v194; // [rsp+E8h] [rbp-B0h]
  float v195; // [rsp+ECh] [rbp-ACh]
  RBX::Matrix3 iBody; // [rsp+F0h] [rbp-A8h] BYREF
  RBX::Matrix3 v197; // [rsp+120h] [rbp-78h] BYREF
  RBX::Humanoid *v198; // [rsp+148h] [rbp-50h]
  __m128i v199[4]; // [rsp+150h] [rbp-48h] BYREF
  G3D::Vector3 v200; // 0:kr00_12.12

  v198 = humanoid;
  FloorPrimitive = RBX::HUMAN::HumanoidState::getFloorPrimitive(this);
  v185 = (float)dword_2859688;
  RBX::Body::updatePV(root);
  v162 = *((float *)this + 104) + *((float *)this + 110);
  v173 = _mm_add_ps(
           _mm_unpacklo_ps((__m128)*((unsigned int *)this + 111), (__m128)*((unsigned int *)this + 109)),
           _mm_unpacklo_ps((__m128)*((unsigned int *)this + 105), (__m128)*((unsigned int *)this + 103)));
  RBX::Body::updatePV(root);
  v163 = v162 - root->pv.velocity.rotational.y;
  v7 = _mm_unpacklo_ps((__m128)LODWORD(root->pv.velocity.rotational.z), (__m128)LODWORD(root->pv.velocity.rotational.x));
  v8 = _mm_sub_ps(v173, v7);
  v174 = v8;
  v200 = G3D::Matrix3::column(&root->pv.position.rotation, 1);
  v8.m128_i32[0] = LODWORD(v200.x);
  v8.m128_i32[1] = LODWORD(v200.y);
  v7.m128_i32[0] = LODWORD(v200.z);
  v9 = _mm_shuffle_ps(v8, v8, 229);
  v10 = _mm_mul_ps(_mm_unpacklo_ps(v7, v8), v174);
  v190 = (float)((float)(_mm_shuffle_ps(v10, v10, 229).m128_f32[0] + (float)(v163 * v9.m128_f32[0])) + v10.m128_f32[0])
       * v185;
  iBody.elt[0][0] = -(float)dword_2859698;
  v11 = &v197;
  if ( (float)dword_2859698 > v190 )
    v11 = (RBX::Matrix3 *)&v190;
  v197.elt[0][0] = (float)dword_2859698;
  p_iBody = &iBody;
  if ( v11->elt[0][0] > (float)-(float)dword_2859698 )
    p_iBody = v11;
  v13 = p_iBody->elt[0][0];
  v190 = p_iBody->elt[0][0];
  cofm = root->cofm;
  v193 = v9;
  if ( cofm )
  {
    RBX::Cofm::updateIfDirty(cofm);
    iBody.elt[2][2] = cofm->branch.moment.elt[2][2];
    v15 = *(_OWORD *)&cofm->branch.moment.elt[0][0];
    v16 = *(_OWORD *)&cofm->branch.moment.elt[1][1];
  }
  else
  {
    if ( !root->isMassless || root->root == root )
      p_moment = &root->bodyMass.moment;
    else
      p_moment = (RBX::Matrix3 *)&unk_58DF6C;
    iBody.elt[2][2] = p_moment->elt[2][2];
    v15 = *(_OWORD *)&p_moment->elt[0][0];
    v16 = *(_OWORD *)&p_moment->elt[1][1];
  }
  *(_OWORD *)&iBody.elt[1][1] = v16;
  *(_OWORD *)&iBody.elt[0][0] = v15;
  RBX::Body::updatePV(root);
  RBX::Math::momentToWorldSpace(&v197, &iBody, &root->pv.position.rotation);
  v18 = root->root;
  rigidBody = v18->rigidBody;
  if ( rigidBody )
  {
    v20 = (float)(v197.elt[0][2] * (float)(v200.z * v13))
        + (float)((float)(v197.elt[0][1] * (float)(v193.m128_f32[0] * v13))
                + (float)(v197.elt[0][0] * (float)(v200.x * v13)));
    v21 = (float)(v197.elt[1][2] * (float)(v200.z * v13))
        + (float)((float)(v197.elt[1][1] * (float)(v193.m128_f32[0] * v13))
                + (float)(v197.elt[1][0] * (float)(v200.x * v13)));
    v22 = (float)((float)(v200.z * v13) * v197.elt[2][2])
        + (float)((float)((float)(v193.m128_f32[0] * v13) * v197.elt[2][1])
                + (float)((float)(v200.x * v13) * v197.elt[2][0]));
    if ( rigidBody->dirty )
    {
      v164 = (float)(v197.elt[0][2] * (float)(v200.z * v13))
           + (float)((float)(v197.elt[0][1] * (float)(v193.m128_f32[0] * v13))
                   + (float)(v197.elt[0][0] * (float)(v200.x * v13)));
      RBX::Solver::SolverRigidBody::update(v18->rigidBody);
      v20 = v164;
    }
    rigidBody->torque.x = v20 + rigidBody->torque.x;
    rigidBody->torque.y = v21 + rigidBody->torque.y;
    rigidBody->torque.z = v22 + rigidBody->torque.z;
  }
  IsSolid = RBX::HUMAN::HumanoidState::computeFloorIsSolid(this);
  v23 = root->cofm;
  if ( v23 )
  {
    RBX::Cofm::updateIfDirty(root->cofm);
    p_mass = &v23->branch.mass;
    v25 = FloorPrimitive;
LABEL_21:
    v26 = (__m128)*(unsigned int *)p_mass;
    goto LABEL_22;
  }
  v25 = FloorPrimitive;
  if ( !root->isMassless || (v26 = 0, root->root == root) )
  {
    p_mass = &root->bodyMass.mass;
    goto LABEL_21;
  }
LABEL_22:
  v175 = v26;
  v27 = (__m128)*((unsigned __int64 *)this + 50);
  v28 = (__m128)*((unsigned int *)this + 102);
  v28.m128_f32[0] = v28.m128_f32[0] + *((float *)this + 108);
  v186 = v28;
  v29 = (__m128)*((unsigned __int64 *)this + 53);
  v30 = root->root->rigidBody;
  if ( v30 )
  {
    p_velocity = &v30->pv.velocity;
  }
  else
  {
    p_velocity = &vel;
    if ( !(_BYTE)byte_2A08DC8 )
    {
      if ( __cxa_guard_acquire(&byte_2A08DC8) )
      {
        *(_OWORD *)&vel.linear.x = 0;
        *(_QWORD *)&vel.rotational.y = 0;
        __cxa_guard_release(&byte_2A08DC8);
      }
      v25 = FloorPrimitive;
    }
  }
  x = p_velocity->linear.x;
  y = p_velocity->linear.y;
  v193.m128_i32[0] = LODWORD(p_velocity->linear.z);
  v32 = root->cofm;
  v33 = v198;
  if ( v32 )
  {
    RBX::Cofm::updateIfDirty(root->cofm);
    v34 = &v32->branch.mass;
LABEL_30:
    v35 = *v34;
    goto LABEL_31;
  }
  if ( !root->isMassless || (v35 = 0.0, root->root == root) )
  {
    v34 = &root->bodyMass.mass;
    goto LABEL_30;
  }
LABEL_31:
  v177 = _mm_add_ps(v27, v29);
  v36 = 0;
  if ( !v25 || (v37 = *((float *)this + 97), v37 >= INFINITY) )
  {
    v181 = 0.0;
LABEL_59:
    v172 = 0.0;
    v167 = 0.0;
    goto LABEL_60;
  }
  v187 = v35;
  v188 = (float)dword_28596D8;
  v171 = (float)dword_28596E8;
  v38 = root->root;
  v39 = v38->rigidBody;
  if ( v39 )
    v40 = (__m128)*(unsigned __int64 *)&v39->force.x;
  else
    v40 = 0;
  v41 = _mm_shuffle_ps(v40, v40, 229);
  v42 = root->cofm;
  if ( v42 )
  {
    v43 = root->cofm;
    v191 = v41;
    RBX::Cofm::updateIfDirty(v43);
    v41 = v191;
    v44 = &v42->branch.mass;
LABEL_42:
    v45 = *v44;
    goto LABEL_43;
  }
  if ( v38 == root || (v45 = 0.0, !root->isMassless) )
  {
    v44 = &root->bodyMass.mass;
    goto LABEL_42;
  }
LABEL_43:
  v46 = (__m128)*(unsigned __int64 *)((char *)this + 452);
  v47 = 0.0;
  if ( v46.m128_f32[0] < 0.99999899 )
  {
    v48 = *((float *)this + 112);
    v49 = _mm_mul_ps(v46, v46);
    if ( (float)(_mm_shuffle_ps(v49, v49, 229).m128_f32[0] + (float)((float)(v48 * v48) + v49.m128_f32[0])) > 0.000001 )
    {
      v50 = _mm_shuffle_ps(v46, v46, 229).m128_f32[0];
      v51 = (float)((float)(root->pv.position.translation.z - *((float *)this + 35)) * v50)
          + (float)((float)(v46.m128_f32[0] * 0.0)
                  + (float)((float)(root->pv.position.translation.x - *((float *)this + 33)) * v48));
      v47 = (float)((float)(v51 * v50) * 0.0)
          + (float)((float)((float)(v48 * v51) * 0.0) + (float)(v46.m128_f32[0] * v51));
    }
  }
  v41.m128_f32[0] = v41.m128_f32[0] / v45;
  v191 = v41;
  v165 = v37 + v47;
  if ( dword_2A08FA0 > 0 )
  {
    v52 = 0;
    v52.m128_f32[0] = fmaxf(0.0, -v41.m128_f32[0]);
    v53 = 0;
    v53.m128_f32[0] = (float)dword_2A08FA0;
    v54 = _mm_div_ps(_mm_unpacklo_ps(v53, v52), _mm_unpacklo_ps((__m128)xmmword_3E7F70, (__m128)*(unsigned int *)a33dc));
    v54.m128_f32[0] = fmaxf(
                        0.1,
                        (float)(1.0 - fminf(1.0, v54.m128_f32[0]))
                      + (float)(_mm_shuffle_ps(v54, v54, 229).m128_f32[0] * v54.m128_f32[0]));
    v188 = v188 * v54.m128_f32[0];
    v171 = v171 * fsqrt(v54.m128_f32[0]);
  }
  RBX::Body::updatePV(torsoBody);
  iBody.elt[0][0] = v165 - torsoBody->pv.position.translation.y;
  v192 = (__m128)*((unsigned int *)this + 6);
  v197.elt[0][0] = (float)((float)dword_28596F8 / 100.0) * v192.m128_f32[0];
  v55 = &iBody;
  if ( iBody.elt[0][0] > v197.elt[0][0] )
    v55 = &v197;
  v166 = v55->elt[0][0];
  v182 = (float)dword_2859708;
  RBX::Body::updatePV(root);
  if ( !*((_BYTE *)this + 12) )
  {
    v181 = 0.0;
    v36 = 0;
    goto LABEL_59;
  }
  v56 = v192;
  v56.m128_f32[0] = v192.m128_f32[0] * (float)(v182 / 100.0);
  v57 = _mm_xor_ps(v56, *(__m128 *)&stru_3E4970.x);
  v57.m128_f32[0] = fmaxf(v57.m128_f32[0], v166);
  v58 = root->pv.velocity.linear.y - *((float *)this + 101);
  v59 = (__m128i)LODWORD(v188);
  v192 = v57;
  v189 = (float)(v188 * v57.m128_f32[0]) - (float)(v171 * v58);
  *(float *)v59.m128i_i32 = v189 - v191.m128_f32[0];
  v199[0] = v59;
  v181 = *((float *)this + 36);
  v172 = *((float *)this + 38);
  v167 = 0.0;
  v195 = (float)(v172 * 0.0) + (float)((float)(v181 * 0.0) + *((float *)this + 37));
  v60 = RBX::HUMAN::HumanoidState::steepSlopeAngle(this);
  si128 = _mm_load_si128(v199);
  v62 = v60;
  v63 = v175.m128_f32[0];
  if ( *(float *)_mm_and_si128(_mm_load_si128((const __m128i *)&xmmword_3E5B40), si128).m128i_i32 > 0.000001 )
  {
    v64 = COERCE_FLOAT(_mm_cvtsi128_si32(si128));
    if ( (float)((float)dword_2859750 * (float)(*((float *)this + 6) * 0.0099999998)) <= v192.m128_f32[0] )
    {
      v66 = v187;
    }
    else if ( *(float *)si128.m128i_i32 >= 0.0 )
    {
      v66 = v187;
      if ( v192.m128_f32[0] < -0.000001 )
      {
        v64 = 0.0;
        si128.m128i_i32[0] = 0;
      }
    }
    else
    {
      v168 = fsqrt(fmaxf(0.0, (float)(-2.0 * v191.m128_f32[0]) * v192.m128_f32[0]));
      v194 = v60;
      RBX::Body::updatePV(root);
      v169 = v168 - root->pv.velocity.linear.y;
      v65 = RBX::Constants::worldDt();
      si128.m128i_i32[0] = _mm_load_si128(v199).m128i_u32[0];
      v62 = v194;
      v63 = v175.m128_f32[0];
      v66 = v187;
      if ( v189 > (float)(v169 / v65) )
      {
        v67 = &iBody;
        if ( (float)((float)(v169 / v65) - v191.m128_f32[0]) < 0.0 )
          v67 = &v197;
        iBody.elt[0][0] = (float)(v169 / v65) - v191.m128_f32[0];
        v197.elt[0][0] = 0.0;
        v64 = v67->elt[0][0];
        si128.m128i_i32[0] = LODWORD(v67->elt[0][0]);
      }
    }
    v153 = v66 / 14.5;
    if ( IsSolid )
    {
      v154 = fmaxf(-10000000.0 * v153, v64 * v63);
      v155 = v153 * 1000000000.0;
    }
    else
    {
      v154 = fmaxf(-100000.0 * v153, fminf(*((float *)&qword_28595E4 + 1), *(float *)si128.m128i_i32) * v63);
      v155 = v153 * 10000000.0;
    }
    v167 = fminf(v155, v154) + 0.0;
  }
  v36 = 1;
  if ( v62 <= v195 )
  {
    if ( !*((_BYTE *)this + 13) )
    {
      v156 = v177;
      v157 = _mm_shuffle_ps(v177, v177, 229).m128_f32[0];
      if ( fabs(v157) <= 0.000001 )
      {
        v158 = v167;
      }
      else
      {
        v158 = v167;
        if ( v192.m128_f32[0] < 0.000001
          && v192.m128_f32[0] > (float)((float)((float)-dword_2859760 * *((float *)this + 6)) * 0.0099999998) )
        {
          v159 = v157 - y;
          v158 = v167;
          v160 = (float)(RBX::HUMAN::HumanoidState::runningKMovePForPGS() * v159)
               - (float)(v191.m128_f32[0] + (float)(v167 / v175.m128_f32[0]));
          if ( v160 > 0.000001 )
            v158 = v167 + (float)(v160 * v175.m128_f32[0]);
          v156 = v177;
        }
      }
      v167 = v158;
      v177 = _mm_unpacklo_ps(v156, (__m128)0LL);
    }
    v36 = 0;
  }
LABEL_60:
  v68 = RBX::HUMAN::HumanoidState::runningKMovePForPGS();
  v70 = v177;
  v69 = _mm_shuffle_ps(v177, v177, 229);
  v70.m128_f32[0] = (float)(v177.m128_f32[0] - x) * v68;
  v184 = v68;
  v69.m128_f32[0] = (float)(v69.m128_f32[0] - y) * v68;
  v178 = v69;
  v71 = (*(__int64 (__fastcall **)(RBX::HUMAN::RunningBase *))(*(_QWORD *)this + 128LL))(this);
  v72 = root->root;
  v73 = v72->rigidBody;
  if ( v71 == 12 )
  {
    v74 = v186;
    if ( v73 )
    {
      v75 = (__m128)*(unsigned __int64 *)&v73->force.x;
      z = v73->force.z;
    }
    else
    {
      v75 = 0;
      z = 0.0;
    }
    v79 = v70;
    v80 = v75;
    v80.m128_f32[0] = v75.m128_f32[0] + 0.0;
    v82 = _mm_shuffle_ps(v75, v75, 229);
    v81 = z + 0.0;
    v82.m128_f32[0] = (float)(v82.m128_f32[0] + v167) - v73->constantForceY;
  }
  else
  {
    v74 = v186;
    if ( v73 )
    {
      v77 = (__m128)*(unsigned __int64 *)&v73->force.x;
      v78 = v73->force.z;
    }
    else
    {
      v77 = 0;
      v78 = 0.0;
    }
    v79 = v70;
    v80 = v77;
    v80.m128_f32[0] = v77.m128_f32[0] + 0.0;
    v82 = _mm_shuffle_ps(v77, v77, 229);
    v82.m128_f32[0] = v82.m128_f32[0] + v167;
    v81 = v78 + 0.0;
  }
  v83 = root->cofm;
  if ( v83 )
  {
    v84 = root->cofm;
    v191 = v80;
    v192 = v82;
    RBX::Cofm::updateIfDirty(v84);
    v82 = v192;
    v80 = v191;
    v79 = v70;
    v74 = v186;
    v85 = &v83->branch.mass;
  }
  else
  {
    if ( v72 != root )
    {
      v86 = 0.0;
      if ( root->isMassless )
        goto LABEL_75;
    }
    v85 = &root->bodyMass.mass;
  }
  v86 = *v85;
LABEL_75:
  v80.m128_f32[0] = v80.m128_f32[0] * (float)(1.0 / v86);
  v82.m128_f32[0] = v82.m128_f32[0] * (float)(1.0 / v86);
  v87 = v81 * (float)(1.0 / v86);
  v88 = _mm_unpacklo_ps(v80, v82);
  v89 = v74.m128_f32[0] - v193.m128_f32[0];
  v90 = _mm_unpacklo_ps(v79, v178);
  v91 = *((_BYTE *)this + 13);
  if ( (v36 || *((float *)this + 107) <= 0.0) && !v91 )
    v90 = _mm_shuffle_ps(_mm_shuffle_ps(v88, v90, 1), v90, 226);
  v92 = v89 * v184;
  v93 = _mm_sub_ps(v90, v88);
  if ( !v91 )
  {
    v94 = (__m128)_mm_shuffle_epi32(_mm_loadl_epi64((const __m128i *)&qword_28595E4), 229);
    v94.m128_f32[0] = fminf(
                        v94.m128_f32[0],
                        fmaxf(
                          *(float *)_mm_shuffle_epi32(_mm_loadl_epi64(&qword_2859780), 229).m128i_i32,
                          _mm_shuffle_ps(v93, v93, 229).m128_f32[0]));
    v93 = _mm_shuffle_ps(_mm_shuffle_ps(v94, v93, 0), v93, 226);
  }
  v74.m128_f32[0] = v92 - v87;
  if ( v25 )
    v95 = RBX::Humanoid::computeMaxHumanoidFloorFrictionForce(v33, v25);
  else
    v95 = 143.0;
  v96 = v175;
  v97 = 0;
  v98 = (float)(v74.m128_f32[0] * v74.m128_f32[0]) + (float)((float)(v93.m128_f32[0] * v93.m128_f32[0]) + 0.0);
  if ( v98 > (float)(v95 * v95) )
  {
    v99 = fsqrt(v98);
    v100 = 0.0;
    if ( v99 >= 0.0000001 )
    {
      if ( v99 >= 1.00001 || v99 <= 0.99998999 )
      {
        v101 = 1.0 / v99;
        v102 = v93;
        v102.m128_f32[0] = v93.m128_f32[0] * (float)(1.0 / v99);
        v103 = 0;
        v103.m128_f32[0] = 0.0 * v101;
        LODWORD(v100) = _mm_unpacklo_ps(v102, v103).m128_u32[0];
        v74.m128_f32[0] = v74.m128_f32[0] * v101;
      }
      else
      {
        LODWORD(v100) = _mm_unpacklo_ps(v93, (__m128)0LL).m128_u32[0];
      }
      v97 = v74;
    }
    v97.m128_f32[0] = v97.m128_f32[0] * v95;
    v93.m128_f32[0] = v100 * v95;
    v74 = v97;
  }
  if ( v36 && v25 )
  {
    v104 = root->root;
    v105 = v104->rigidBody;
    if ( v105 )
      v106 = (__m128)*(unsigned __int64 *)&v105->force.x;
    else
      v106 = 0;
    v107 = root->cofm;
    if ( v107 )
    {
      RBX::Cofm::updateIfDirty(root->cofm);
      v96 = v175;
      v108 = &v107->branch.mass;
      v109 = v181;
      v110 = v172;
    }
    else
    {
      v109 = v181;
      v110 = v172;
      if ( v104 != root )
      {
        v111 = 0.0;
        if ( root->isMassless )
          goto LABEL_103;
      }
      v108 = &root->bodyMass.mass;
    }
    v111 = *v108;
LABEL_103:
    v112 = fsqrt((float)(v110 * v110) + (float)((float)(v109 * v109) + 0.0));
    v113 = v109 * (float)(1.0 / v112);
    v114 = v110 * (float)(1.0 / v112);
    v115 = (float)(1.0 / v112) * 0.0;
    v116 = _mm_shuffle_ps(v93, v93, 229);
    v117 = (float)(v114 * v74.m128_f32[0]) + (float)((float)(v115 * v116.m128_f32[0]) + (float)(v113 * v93.m128_f32[0]));
    if ( v117 >= 0.0 )
    {
      v119 = v93;
    }
    else
    {
      v118 = 1.0 / fsqrt((float)(v114 * v114) + (float)((float)(v115 * v115) + (float)(v113 * v113)));
      v119 = v93;
      v119.m128_f32[0] = v93.m128_f32[0] - (float)((float)(v113 * v118) * v117);
      v93.m128_f32[0] = v119.m128_f32[0];
      v74.m128_f32[0] = v74.m128_f32[0] - (float)((float)(v118 * v114) * v117);
    }
    v120 = *((float *)this + 112);
    v121 = *((float *)this + 113);
    v122 = *((float *)this + 114);
    if ( v120 != 0.0 || v121 != 0.0 || v122 != 0.0 )
    {
      v123 = (float)(v122 * 0.0)
           + (float)((float)((float)(_mm_shuffle_ps(v106, v106, 229).m128_f32[0] / v111) * v121) + (float)(v120 * 0.0));
      v119.m128_f32[0] = v119.m128_f32[0] + (float)(v120 * v123);
      v116.m128_f32[0] = v116.m128_f32[0] + 0.0;
      v74.m128_f32[0] = v74.m128_f32[0] + (float)(v123 * v122);
      v93 = _mm_unpacklo_ps(v119, v116);
    }
  }
  v176 = _mm_mul_ps(_mm_shuffle_ps(v96, v96, 224), _mm_unpacklo_ps(v74, v93));
  v124 = v167 + (float)(_mm_shuffle_ps(v93, v93, 229).m128_f32[0] * v96.m128_f32[0]);
  if ( (*(unsigned int (__fastcall **)(RBX::HUMAN::RunningBase *))(*(_QWORD *)this + 128LL))(this) == 12 )
    v124 = v124 - root->root->rigidBody->constantForceY;
  v125 = v124;
  v126 = _mm_add_ps(v176, (__m128)xmmword_3E5050);
  if ( !stru_2A08CA8.value )
    goto LABEL_164;
  v127 = RBX::HUMAN::HumanoidState::getFloorPrimitive(this);
  v125 = v124;
  if ( v127 )
    goto LABEL_164;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  CurrentStateType = RBX::Humanoid::getCurrentStateType(HumanoidConst);
  v125 = v124;
  if ( CurrentStateType == RBX::HUMAN::StateType::CLIMBING
    || (v130 = RBX::HUMAN::HumanoidState::getHumanoidConst(this), v125 = v124, *((_DWORD *)v130 + 622) == 12)
    || (v131 = RBX::HUMAN::HumanoidState::getHumanoidConst(this),
        isFullySubmerged = RBX::Humanoid::isFullySubmerged(v131),
        v125 = v124,
        isFullySubmerged) )
  {
LABEL_164:
    v133 = root->root;
    v134 = v133->rigidBody;
    if ( v134 )
    {
      if ( v134->dirty )
      {
        RBX::Solver::SolverRigidBody::update(v133->rigidBody);
        v125 = v124;
      }
      v134->force.x = _mm_shuffle_ps(v126, v126, 229).m128_f32[0] + v134->force.x;
      v134->force.y = v134->force.y + v125;
      v134->force.z = v134->force.z + v126.m128_f32[0];
    }
  }
  if ( v25 )
  {
    if ( IsSolid
      && (v135 = _mm_mul_ps(v126, v126),
          (float)((float)(_mm_shuffle_ps(v135, v135, 229).m128_f32[0] + (float)(v125 * v125)) + v135.m128_f32[0]) > 0.000001) )
    {
      v136 = *(RBX::Solver::SolverRigidBody **)(*((_QWORD *)v25 + 25) + 64LL);
      if ( v136 )
      {
        v137 = (float)dword_2859728;
LABEL_128:
        v138 = v137 / 100.0;
        v139 = _mm_shuffle_ps(v126, v126, 229);
        v139.m128_f32[0] = v139.m128_f32[0] * v138;
        v140 = -v139.m128_f32[0];
        v141 = v125 * v138;
        v142 = -v141;
        v143 = v138 * v126.m128_f32[0];
        v144 = -v143;
        if ( v136->dirty )
        {
          v170 = v141;
          v193 = v139;
          RBX::Solver::SolverRigidBody::update(v136);
          v139.m128_i32[0] = v193.m128_i32[0];
          v141 = v170;
        }
        v145 = v136->force.y;
        v136->force.x = v136->force.x - v139.m128_f32[0];
        v136->force.y = v145 - v141;
        v136->force.z = v136->force.z - v143;
        v146 = *((float *)this + 33) - v136->pv.position.translation.x;
        v147 = *((float *)this + 34) - v136->pv.position.translation.y;
        v148 = *((float *)this + 35) - v136->pv.position.translation.z;
        v136->torque.x = (float)((float)(v147 * v144) - (float)(v148 * v142)) + v136->torque.x;
        v136->torque.y = (float)((float)(v148 * v140) - (float)(v144 * v146)) + v136->torque.y;
        v136->torque.z = (float)((float)(v146 * v142) - (float)(v147 * v140)) + v136->torque.z;
      }
    }
    else
    {
      v136 = *(RBX::Solver::SolverRigidBody **)(*((_QWORD *)v25 + 25) + 64LL);
      if ( v136 )
      {
        v137 = (float)dword_2859738;
        goto LABEL_128;
      }
    }
    v149 = RBX::PartInstance::fromPrimitive(v25);
    TorsoSlow = RBX::Humanoid::getTorsoSlow(v33);
    if ( v149 && TorsoSlow )
    {
      if ( *((RBX::Primitive **)this + 49) != v25 )
      {
        RBX::shared_from<RBX::PartInstance>(
          (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)&iBody,
          TorsoSlow);
        RBX::PartInstance::reportTouch(v149, (const boost::shared_ptr<RBX::PartInstance> *)&iBody);
        v151 = *(volatile signed __int32 **)&iBody.elt[0][2];
        if ( *(_QWORD *)&iBody.elt[0][2] )
        {
          if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&iBody.elt[0][2] + 8LL), 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v151 + 16LL))(v151);
            if ( !_InterlockedSub(v151 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v151 + 24LL))(v151);
          }
        }
      }
      v152 = root->root->rigidBody;
      if ( v152->dirty )
        RBX::Solver::SolverRigidBody::update(v152);
    }
  }
  *((_QWORD *)this + 49) = v25;
}


// Address: 0x10eb270 | Name: _ZN3RBX5HUMAN11RunningBase21conserveMomentumCheckEv
bool __fastcall RBX::HUMAN::RunningBase::conserveMomentumCheck(RBX::HUMAN::RunningBase *this)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Humanoid *v3; // rax

  if ( RBX::HUMAN::HumanoidState::getFloorPrimitive(this) )
    return 1;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  if ( RBX::Humanoid::getCurrentStateType(HumanoidConst) == RBX::HUMAN::StateType::CLIMBING
    || *((_DWORD *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 622) == 12 )
  {
    return 1;
  }
  v3 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  return RBX::Humanoid::isFullySubmerged(v3);
}


// Address: 0x10eb2c0 | Name: _ZN3RBX5HUMAN11RunningBase18onComputeForceImplEv
void __fastcall RBX::HUMAN::RunningBase::onComputeForceImpl(RBX::HUMAN::RunningBase *this)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Humanoid *v3; // rbx
  RBX::Body *TorsoBodyFast; // rax
  RBX::Body *v5; // r12
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v7; // r14
  RBX::Cofm *cofm; // rbx
  float *p_mass; // rbx
  RBX::Primitive *FloorPrimitive; // rax
  RBX::Primitive *v11; // r13
  __m128 v12; // xmm1
  __m128 v13; // xmm0
  __m128 v14; // xmm2
  RBX::Matrix3 *v15; // rcx
  RBX::Matrix3 *p_iBody; // rax
  float v17; // r15d
  RBX::Cofm *v18; // rbx
  __int128 v19; // xmm0
  __int128 v20; // xmm1
  RBX::Cofm *v21; // rbx
  __m128 v22; // xmm0
  __m128 v23; // xmm1
  float *p_moment; // rax
  RBX::Body *root; // rax
  RBX::Solver::SolverRigidBody *rigidBody; // rbx
  float v27; // xmm5_4
  float v28; // xmm0_4
  float v29; // xmm2_4
  __m128 *v30; // rax
  RBX::Body *v31; // rax
  RBX::Solver::SolverRigidBody *v32; // rbx
  float v33; // xmm2_4
  RBX::Cofm *v34; // rbx
  float *v35; // rbx
  RBX::Body *v36; // rax
  RBX::Solver::SolverRigidBody *v37; // rcx
  __m128 v38; // xmm2
  __m128 v39; // xmm2
  RBX::Cofm *v40; // rbx
  RBX::Cofm *v41; // rdi
  float mass; // xmm0_4
  float v43; // xmm1_4
  float v44; // xmm1_4
  float v45; // xmm2_4
  RBX::Body *v46; // rax
  RBX::Solver::SolverRigidBody *v47; // rcx
  __m128 v48; // xmm3
  float v49; // xmm3_4
  RBX::Cofm *v50; // rbx
  float *v51; // rbx
  float v52; // xmm0_4
  float v53; // xmm3_4
  float v54; // xmm1_4
  RBX::Body *v55; // rax
  RBX::Solver::SolverRigidBody *v56; // rbx
  __int64 v57; // rax
  __int64 v58; // rbx
  float v59; // xmm5_4
  float v60; // xmm1_4
  float v61; // xmm3_4
  float v62; // xmm2_4
  __m128 v63; // xmm0
  __m128 v64; // xmm2
  float v65; // xmm1_4
  RBX::Velocity *v66; // rbx
  RBX::Velocity *v67; // rbx
  float v68; // xmm0_4
  __m128 v69; // xmm1
  __m128 v70; // xmm1
  int v71; // eax
  RBX::Body *v72; // rcx
  RBX::Solver::SolverRigidBody *v73; // rdx
  __m128 v74; // xmm1
  float v75; // xmm3_4
  __m128 v76; // xmm2
  float z; // xmm3_4
  __m128 v78; // xmm5
  __int64 v79; // xmm6_8
  __m128 v80; // xmm4
  RBX::Cofm *v81; // rbx
  RBX::Cofm *v82; // rdi
  float *v83; // rbx
  RBX::Cofm *v84; // rbx
  RBX::Cofm *v85; // rdi
  float *v86; // rbx
  float v87; // xmm0_4
  __m128 v88; // xmm2
  __m128 v89; // xmm1
  float v90; // xmm3_4
  float v91; // xmm0_4
  __m128 v92; // xmm1
  __m128 v93; // xmm2
  __m128 v94; // xmm5
  char v95; // al
  float v96; // xmm6_4
  __m128 v97; // xmm5
  __m128 v98; // xmm2
  RBX::Humanoid *v99; // rax
  float v100; // xmm0_4
  float v101; // xmm1_4
  __m128 v102; // xmm2
  float v103; // xmm3_4
  __m128 v104; // xmm3
  float v105; // xmm1_4
  __m128 v106; // xmm2
  __m128 v107; // xmm3
  __m128 v108; // xmm3
  __m128 v109; // xmm0
  __m128 v110; // xmm0
  __m128 v111; // xmm6
  double v112; // xmm1_8
  double v113; // xmm0_8
  RBX::Humanoid *v114; // rax
  RBX::Humanoid *v115; // rax
  RBX::Body *v116; // rax
  RBX::Solver::SolverRigidBody *v117; // rbx
  RBX::Solver::SolverRigidBody *v118; // rdi
  RBX::Body *v119; // rax
  float v120; // xmm7_4
  RBX::Solver::SolverRigidBody *v121; // rbx
  float v122; // xmm7_4
  __int64 v123; // rax
  __int64 v124; // rbx
  RBX::PartInstance *v125; // rbx
  RBX::Humanoid *v126; // rax
  RBX::PartInstance *TorsoSlow; // rax
  double v128; // xmm4_8
  double v129; // xmm5_8
  volatile signed __int32 *v130; // rbx
  RBX::Solver::SolverRigidBody *v131; // rdi
  float v132; // [rsp+Ch] [rbp-11Ch]
  float v133; // [rsp+Ch] [rbp-11Ch]
  float v134; // [rsp+Ch] [rbp-11Ch]
  float v135; // [rsp+10h] [rbp-118h]
  float v136; // [rsp+10h] [rbp-118h]
  float v137; // [rsp+10h] [rbp-118h]
  float v138; // [rsp+10h] [rbp-118h]
  float v139; // [rsp+10h] [rbp-118h]
  __m128 v140; // [rsp+10h] [rbp-118h]
  __m128 v141; // [rsp+10h] [rbp-118h]
  __m128 v142; // [rsp+10h] [rbp-118h]
  __m128 v143; // [rsp+10h] [rbp-118h]
  __m128 v144; // [rsp+10h] [rbp-118h]
  __m128 v145; // [rsp+20h] [rbp-108h]
  __m128 v146; // [rsp+20h] [rbp-108h]
  float v147; // [rsp+20h] [rbp-108h]
  float v148; // [rsp+20h] [rbp-108h]
  float v149; // [rsp+20h] [rbp-108h]
  float v150; // [rsp+20h] [rbp-108h]
  RBX::Primitive *v151; // [rsp+38h] [rbp-F0h]
  float v152; // [rsp+38h] [rbp-F0h]
  float v153; // [rsp+38h] [rbp-F0h]
  float v154; // [rsp+38h] [rbp-F0h]
  float v155; // [rsp+40h] [rbp-E8h]
  __m128 v156; // [rsp+40h] [rbp-E8h]
  float v157; // [rsp+5Ch] [rbp-CCh] BYREF
  RBX::Matrix3 iBody; // [rsp+60h] [rbp-C8h] BYREF
  __m128 v159; // [rsp+90h] [rbp-98h]
  __m128 v160; // [rsp+A0h] [rbp-88h]
  RBX::Matrix3 v161; // [rsp+B8h] [rbp-70h] BYREF
  __m128 v162; // [rsp+E0h] [rbp-48h]
  G3D::Vector3 v163; // 0:kr00_12.12

  RBX::HUMAN::Balancing::onComputeForceImpl(this);
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  if ( !HumanoidConst )
    return;
  v3 = HumanoidConst;
  TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(HumanoidConst);
  if ( !TorsoBodyFast )
    return;
  v5 = TorsoBodyFast;
  RootBodyFast = RBX::Humanoid::getRootBodyFast(v3);
  if ( !RootBodyFast )
    return;
  v7 = RootBodyFast;
  if ( *((_QWORD *)v3 + 308) && stru_2A10FE8.value )
  {
    RBX::HUMAN::RunningBase::onComputeForceImplOptimized(this, v3, v5, RootBodyFast);
    return;
  }
  cofm = RootBodyFast->cofm;
  if ( cofm )
  {
    RBX::Cofm::updateIfDirty(RootBodyFast->cofm);
    p_mass = &cofm->branch.mass;
LABEL_12:
    v155 = *p_mass;
    goto LABEL_13;
  }
  if ( !RootBodyFast->isMassless || (v155 = 0.0, RootBodyFast->root == RootBodyFast) )
  {
    p_mass = &RootBodyFast->bodyMass.mass;
    goto LABEL_12;
  }
LABEL_13:
  FloorPrimitive = RBX::HUMAN::HumanoidState::getFloorPrimitive(this);
  v11 = FloorPrimitive;
  if ( stru_2A10FE8.value )
  {
    v151 = FloorPrimitive;
    v132 = (float)dword_2859688;
    RBX::Body::updatePV(v7);
    v135 = *((float *)this + 104) + *((float *)this + 110);
    v145 = _mm_add_ps(
             _mm_unpacklo_ps((__m128)*((unsigned int *)this + 111), (__m128)*((unsigned int *)this + 109)),
             _mm_unpacklo_ps((__m128)*((unsigned int *)this + 105), (__m128)*((unsigned int *)this + 103)));
    RBX::Body::updatePV(v7);
    v136 = v135 - v7->pv.velocity.rotational.y;
    v12 = _mm_unpacklo_ps((__m128)LODWORD(v7->pv.velocity.rotational.z), (__m128)LODWORD(v7->pv.velocity.rotational.x));
    v13 = _mm_sub_ps(v145, v12);
    v146 = v13;
    v163 = G3D::Matrix3::column(&v7->pv.position.rotation, 1);
    v13.m128_i32[0] = LODWORD(v163.x);
    v13.m128_i32[1] = LODWORD(v163.y);
    v12.m128_i32[0] = LODWORD(v163.z);
    v160 = _mm_shuffle_ps(v13, v13, 229);
    v159 = v13;
    v14 = _mm_mul_ps(_mm_unpacklo_ps(v12, v13), v146);
    v157 = (float)((float)(_mm_shuffle_ps(v14, v14, 229).m128_f32[0] + (float)(v136 * v160.m128_f32[0]))
                 + v14.m128_f32[0])
         * v132;
    iBody.elt[0][0] = -(float)dword_2859698;
    v15 = &v161;
    if ( (float)dword_2859698 > v157 )
      v15 = (RBX::Matrix3 *)&v157;
    v161.elt[0][0] = (float)dword_2859698;
    p_iBody = &iBody;
    if ( v15->elt[0][0] > (float)-(float)dword_2859698 )
      p_iBody = v15;
    v17 = p_iBody->elt[0][0];
    v157 = p_iBody->elt[0][0];
    v18 = v7->cofm;
    if ( v18 )
    {
      RBX::Cofm::updateIfDirty(v7->cofm);
      iBody.elt[2][2] = v18->branch.moment.elt[2][2];
      v19 = *(_OWORD *)&v18->branch.moment.elt[0][0];
      v20 = *(_OWORD *)&v18->branch.moment.elt[1][1];
    }
    else
    {
      if ( !v7->isMassless || v7->root == v7 )
        p_moment = (float *)&v7->bodyMass.moment;
      else
        p_moment = (float *)&unk_58DF6C;
      iBody.elt[2][2] = p_moment[8];
      v19 = *(_OWORD *)p_moment;
      v20 = *((_OWORD *)p_moment + 1);
    }
    *(_OWORD *)&iBody.elt[1][1] = v20;
    *(_OWORD *)&iBody.elt[0][0] = v19;
    RBX::Body::updatePV(v7);
    RBX::Math::momentToWorldSpace(&v161, &iBody, &v7->pv.position.rotation);
    root = v7->root;
    rigidBody = root->rigidBody;
    v11 = v151;
    if ( rigidBody )
    {
      v27 = (float)(v161.elt[0][2] * (float)(v163.z * v17))
          + (float)((float)(v161.elt[0][1] * (float)(v160.m128_f32[0] * v17))
                  + (float)(v161.elt[0][0] * (float)(v159.m128_f32[0] * v17)));
      v28 = (float)(v161.elt[1][2] * (float)(v163.z * v17))
          + (float)((float)(v161.elt[1][1] * (float)(v160.m128_f32[0] * v17))
                  + (float)(v161.elt[1][0] * (float)(v159.m128_f32[0] * v17)));
      v29 = (float)((float)(v163.z * v17) * v161.elt[2][2])
          + (float)((float)((float)(v160.m128_f32[0] * v17) * v161.elt[2][1])
                  + (float)((float)(v159.m128_f32[0] * v17) * v161.elt[2][0]));
      if ( rigidBody->dirty )
      {
        v147 = (float)(v161.elt[0][2] * (float)(v163.z * v17))
             + (float)((float)(v161.elt[0][1] * (float)(v160.m128_f32[0] * v17))
                     + (float)(v161.elt[0][0] * (float)(v159.m128_f32[0] * v17)));
        RBX::Solver::SolverRigidBody::update(root->rigidBody);
        v27 = v147;
      }
      rigidBody->torque.x = v27 + rigidBody->torque.x;
      rigidBody->torque.y = v28 + rigidBody->torque.y;
      rigidBody->torque.z = v29 + rigidBody->torque.z;
    }
  }
  else
  {
    v21 = v7->cofm;
    if ( v21 )
    {
      RBX::Cofm::updateIfDirty(v7->cofm);
      iBody.elt[2][2] = v21->branch.moment.elt[2][2];
      v22 = *(__m128 *)&v21->branch.moment.elt[0][0];
      v23 = *(__m128 *)&v21->branch.moment.elt[1][1];
    }
    else
    {
      if ( !v7->isMassless || v7->root == v7 )
        v30 = (__m128 *)&v7->bodyMass.moment;
      else
        v30 = (__m128 *)&unk_58DF6C;
      LODWORD(iBody.elt[2][2]) = v30[2].m128_i32[0];
      v22 = *v30;
      v23 = v30[1];
    }
    *(__m128 *)&iBody.elt[1][1] = v23;
    *(__m128 *)&iBody.elt[0][0] = v22;
    v22.m128_u64[0] = (unsigned __int64)RBX::Math::toDiagonal(&iBody);
    v137 = *((float *)this + 104) + *((float *)this + 110);
    RBX::Body::updatePV(v7);
    v31 = v7->root;
    v32 = v31->rigidBody;
    if ( v32 )
    {
      v33 = fminf(
              100000.0,
              fmaxf(
                -100000.0,
                (float)(v137 - v7->pv.velocity.rotational.y)
              * (float)(_mm_shuffle_ps(v22, v22, 229).m128_f32[0] * 450.0)));
      if ( v32->dirty )
        RBX::Solver::SolverRigidBody::update(v31->rigidBody);
      v32->torque.x = v32->torque.x + 0.0;
      v32->torque.y = v33 + v32->torque.y;
      v32->torque.z = v32->torque.z + 0.0;
    }
  }
  v34 = v7->cofm;
  if ( v34 )
  {
    RBX::Cofm::updateIfDirty(v7->cofm);
    v35 = &v34->branch.mass;
  }
  else
  {
    if ( v7->isMassless )
    {
      v152 = 0.0;
      if ( v7->root != v7 )
        goto LABEL_46;
    }
    v35 = &v7->bodyMass.mass;
  }
  v152 = *v35;
LABEL_46:
  if ( v11 && *((float *)this + 97) < INFINITY )
  {
    v148 = (float)dword_28596A8;
    v133 = (float)dword_28596B8;
    v36 = v7->root;
    v37 = v36->rigidBody;
    v38 = v37 ? (__m128)*(unsigned __int64 *)&v37->force.x : 0LL;
    v39 = _mm_xor_ps(_mm_shuffle_ps(v38, v38, 229), *(__m128 *)&stru_3E4970.x);
    v40 = v7->cofm;
    if ( v40 )
    {
      v41 = v7->cofm;
      v159 = v39;
      RBX::Cofm::updateIfDirty(v41);
      v39.m128_i32[0] = v159.m128_i32[0];
      mass = v40->branch.mass;
      v138 = *((float *)this + 97);
    }
    else
    {
      v138 = *((float *)this + 97);
      if ( v36 == v7 || (mass = 0.0, !v7->isMassless) )
        mass = v7->bodyMass.mass;
    }
    v43 = fmaxf(0.1, (float)((float)dword_28596C8 * (float)((float)(v39.m128_f32[0] / mass) / *(float *)a33dc)) / 100.0);
    RBX::Body::updatePV(v5);
    v139 = (float)(v138 - v5->pv.position.translation.y) * (float)(v148 * v43);
    RBX::Body::updatePV(v7);
    v44 = v139 - (float)((float)(v7->pv.velocity.linear.y - *((float *)this + 101)) * (float)(fsqrt(v43) * v133));
    if ( v44 > 0.0 )
    {
      v45 = v44;
      v46 = v7->root;
      v47 = v46->rigidBody;
      if ( v47 )
        v48 = (__m128)*(unsigned __int64 *)&v47->force.x;
      else
        v48 = 0;
      LODWORD(v49) = _mm_shuffle_ps(v48, v48, 229).m128_u32[0];
      v50 = v7->cofm;
      if ( v50 )
      {
        RBX::Cofm::updateIfDirty(v7->cofm);
        v45 = v44;
        v51 = &v50->branch.mass;
      }
      else
      {
        if ( v46 != v7 )
        {
          v52 = 0.0;
          if ( v7->isMassless )
          {
LABEL_66:
            v53 = v49 / v52;
            if ( v45 > v53 && *((_BYTE *)this + 12) )
            {
              v54 = fminf(
                      (float)(v155 / 14.5) * 1000000000.0,
                      fmaxf(-10000000.0 * (float)(v155 / 14.5), (float)(v45 - v53) * v152));
              v55 = v7->root;
              v56 = v55->rigidBody;
              if ( v56 )
              {
                if ( v56->dirty )
                  RBX::Solver::SolverRigidBody::update(v55->rigidBody);
                v56->force.x = v56->force.x + 0.0;
                v56->force.y = v56->force.y + v54;
                v56->force.z = v56->force.z + 0.0;
              }
              v57 = *((_QWORD *)v11 + 25);
              v58 = *(_QWORD *)(v57 + 64);
              if ( v58 )
              {
                v59 = -v54;
                if ( *(_BYTE *)(v58 + 1) )
                {
                  RBX::Solver::SolverRigidBody::update(*(RBX::Solver::SolverRigidBody **)(v57 + 64));
                  v59 = -v54;
                }
                *(float *)(v58 + 240) = *(float *)(v58 + 240) + 0.0;
                *(float *)(v58 + 244) = *(float *)(v58 + 244) - v54;
                *(float *)(v58 + 248) = *(float *)(v58 + 248) + 0.0;
                v60 = *((float *)this + 33) - *(float *)(v58 + 60);
                v61 = *((float *)this + 35) - *(float *)(v58 + 68);
                v62 = (float)(*((float *)this + 34) - *(float *)(v58 + 64)) * 0.0;
                *(float *)(v58 + 252) = (float)(v62 - (float)(v61 * v59)) + *(float *)(v58 + 252);
                *(float *)(v58 + 256) = (float)((float)(v61 * 0.0) - (float)(0.0 * v60)) + *(float *)(v58 + 256);
                *(float *)(v58 + 260) = (float)((float)(v60 * v59) - v62) + *(float *)(v58 + 260);
              }
            }
            goto LABEL_76;
          }
        }
        v51 = &v7->bodyMass.mass;
      }
      v52 = *v51;
      goto LABEL_66;
    }
  }
LABEL_76:
  v63 = (__m128)*((unsigned int *)this + 100);
  v64 = (__m128)*((unsigned int *)this + 101);
  v63.m128_f32[0] = v63.m128_f32[0] + *((float *)this + 106);
  v64.m128_f32[0] = v64.m128_f32[0] + *((float *)this + 107);
  v65 = *((float *)this + 102) + *((float *)this + 108);
  v66 = (RBX::Velocity *)v7->root->rigidBody;
  if ( v66 )
  {
    v67 = v66 + 3;
  }
  else
  {
    v67 = &vel;
    if ( !(_BYTE)byte_2A08DC8 && __cxa_guard_acquire(&byte_2A08DC8) )
    {
      *(_OWORD *)&vel.linear.x = 0;
      *(_QWORD *)&vel.rotational.y = 0;
      __cxa_guard_release(&byte_2A08DC8);
    }
  }
  v63.m128_f32[0] = v63.m128_f32[0] - v67->linear.x;
  v140 = v63;
  v64.m128_f32[0] = v64.m128_f32[0] - v67->linear.y;
  v149 = v65 - v67->linear.z;
  v68 = RBX::HUMAN::HumanoidState::runningKMovePForPGS();
  v69 = v140;
  v69.m128_f32[0] = v140.m128_f32[0] * v68;
  v141 = v69;
  v134 = v68;
  v70 = v64;
  v70.m128_f32[0] = v64.m128_f32[0] * v68;
  v156 = v70;
  v71 = (*(__int64 (__fastcall **)(RBX::HUMAN::RunningBase *))(*(_QWORD *)this + 128LL))(this);
  v72 = v7->root;
  v73 = v72->rigidBody;
  if ( v71 != 12 )
  {
    if ( v73 )
    {
      v76 = (__m128)*(unsigned __int64 *)&v73->force.x;
      z = v73->force.z;
    }
    else
    {
      z = 0.0;
      v76 = 0;
    }
    v78 = v141;
    v79 = LODWORD(v149);
    v84 = v7->cofm;
    if ( v84 )
    {
      v85 = v7->cofm;
      v159.m128_f32[0] = z;
      v160 = v76;
      RBX::Cofm::updateIfDirty(v85);
      v76 = v160;
      z = v159.m128_f32[0];
      v79 = LODWORD(v149);
      v78 = v141;
      v86 = &v84->branch.mass;
    }
    else
    {
      if ( v72 != v7 )
      {
        v91 = 0.0;
        if ( v7->isMassless )
          goto LABEL_99;
      }
      v86 = &v7->bodyMass.mass;
    }
    v91 = *v86;
LABEL_99:
    v92 = (__m128)0x3F800000u;
    v92.m128_f32[0] = 1.0 / v91;
    v90 = z * (float)(1.0 / v91);
    v89 = _mm_shuffle_ps(v92, v92, 224);
    goto LABEL_100;
  }
  if ( v73 )
  {
    v74 = (__m128)*(unsigned __int64 *)&v73->force.x;
    v75 = v73->force.z;
  }
  else
  {
    v75 = 0.0;
    v74 = 0;
  }
  v78 = v141;
  v79 = LODWORD(v149);
  v80 = _mm_shuffle_ps(v74, v74, 229);
  v80.m128_f32[0] = v80.m128_f32[0] - v73->constantForceY;
  v81 = v7->cofm;
  if ( v81 )
  {
    v82 = v7->cofm;
    v159.m128_f32[0] = v75;
    v160 = v74;
    v162 = v80;
    RBX::Cofm::updateIfDirty(v82);
    v80 = v162;
    v74 = v160;
    v75 = v159.m128_f32[0];
    v79 = LODWORD(v149);
    v78 = v141;
    v83 = &v81->branch.mass;
  }
  else
  {
    if ( v72 != v7 )
    {
      v87 = 0.0;
      if ( v7->isMassless )
        goto LABEL_94;
    }
    v83 = &v7->bodyMass.mass;
  }
  v87 = *v83;
LABEL_94:
  v88 = (__m128)0x3F800000u;
  v88.m128_f32[0] = 1.0 / v87;
  v89 = _mm_unpacklo_ps(v74, v80);
  v90 = v75 * (float)(1.0 / v87);
  v76 = _mm_shuffle_ps(v88, v88, 224);
LABEL_100:
  v93 = _mm_mul_ps(v76, v89);
  v94 = _mm_unpacklo_ps(v78, v156);
  v95 = *((_BYTE *)this + 13);
  if ( *((float *)this + 107) <= 0.0 && !v95 )
    v94 = _mm_shuffle_ps(_mm_shuffle_ps(v93, v94, 1), v94, 226);
  v96 = *(float *)&v79 * v134;
  v97 = _mm_sub_ps(v94, v93);
  if ( !v95 )
  {
    v98 = (__m128)_mm_shuffle_epi32(_mm_loadl_epi64((const __m128i *)&qword_28595E4), 229);
    v98.m128_f32[0] = fminf(
                        v98.m128_f32[0],
                        fmaxf(
                          *(float *)_mm_shuffle_epi32(_mm_loadl_epi64((const __m128i *)&qword_28595D8), 229).m128i_i32,
                          _mm_shuffle_ps(v97, v97, 229).m128_f32[0]));
    v97 = _mm_shuffle_ps(_mm_shuffle_ps(v98, v97, 0), v97, 226);
  }
  *(float *)&v79 = v96 - v90;
  v150 = *(float *)&v79;
  if ( v11 )
  {
    v142 = v97;
    v99 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    v100 = RBX::Humanoid::computeMaxHumanoidFloorFrictionForce(v99, v11);
    v79 = (unsigned int)v79;
    v97 = v142;
  }
  else
  {
    v100 = 143.0;
  }
  v101 = 0.0;
  v102.m128_i32[1] = HIDWORD(v79);
  v102.m128_f32[0] = (float)(*(float *)&v79 * *(float *)&v79)
                   + (float)((float)(v97.m128_f32[0] * v97.m128_f32[0]) + 0.0);
  if ( v102.m128_f32[0] <= (float)(v100 * v100) )
  {
    v104 = v97;
  }
  else
  {
    v103 = fsqrt(v102.m128_f32[0]);
    v102 = 0;
    if ( v103 >= 0.0000001 )
    {
      if ( v103 >= 1.00001 || v103 <= 0.99998999 )
      {
        v105 = 1.0 / v103;
        v106 = v97;
        v106.m128_f32[0] = v97.m128_f32[0] * (float)(1.0 / v103);
        v107 = 0;
        v107.m128_f32[0] = 0.0 * v105;
        v102 = _mm_unpacklo_ps(v106, v107);
        *(float *)&v79 = *(float *)&v79 * v105;
      }
      else
      {
        v102 = _mm_unpacklo_ps(v97, (__m128)0LL);
      }
      v101 = *(float *)&v79;
    }
    v102.m128_f32[0] = v102.m128_f32[0] * v100;
    v104 = v97;
    v104.m128_f32[0] = v102.m128_f32[0];
    v97 = v102;
    v150 = v101 * v100;
  }
  v97.m128_f32[0] = v97.m128_f32[0] * v152;
  v143 = v97;
  v108 = _mm_shuffle_ps(v104, v104, 229);
  v108.m128_f32[0] = v108.m128_f32[0] * v152;
  if ( (*(unsigned int (__fastcall **)(RBX::HUMAN::RunningBase *))(*(_QWORD *)this + 128LL))(this) == 12 )
  {
    v109 = v108;
    v109.m128_f32[0] = v108.m128_f32[0] - v7->root->rigidBody->constantForceY;
    v110 = _mm_shuffle_ps(_mm_shuffle_ps(v109, v143, 0), v143, 226);
  }
  else
  {
    v110 = _mm_unpacklo_ps(v143, v108);
  }
  v111 = v110;
  *(_QWORD *)&v112 = LODWORD(v150);
  *(_QWORD *)&v113 = LODWORD(v152);
  *(float *)&v113 = v152 * v150;
  v153 = v152 * v150;
  if ( stru_2A08CA8.value )
  {
    v144 = v111;
    if ( RBX::HUMAN::HumanoidState::getFloorPrimitive(this)
      || (v114 = RBX::HUMAN::HumanoidState::getHumanoidConst(this),
          RBX::Humanoid::getCurrentStateType(v114) == RBX::HUMAN::StateType::CLIMBING)
      || *((_DWORD *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 622) == 12
      || (v115 = RBX::HUMAN::HumanoidState::getHumanoidConst(this), RBX::Humanoid::isFullySubmerged(v115)) )
    {
      v116 = v7->root;
      v117 = v116->rigidBody;
      if ( v117 )
      {
        if ( v117->dirty )
        {
          v118 = v116->rigidBody;
LABEL_132:
          RBX::Solver::SolverRigidBody::update(v118);
          v111 = v144;
          goto LABEL_133;
        }
        goto LABEL_133;
      }
      goto LABEL_134;
    }
    if ( stru_2A08CA8.value )
      goto LABEL_134;
  }
  v119 = v7->root;
  v117 = v119->rigidBody;
  if ( v117 )
  {
    if ( v117->dirty )
    {
      v118 = v119->rigidBody;
      v144 = v111;
      goto LABEL_132;
    }
LABEL_133:
    v117->force.x = v117->force.x + v111.m128_f32[0];
    v117->force.y = _mm_shuffle_ps(v111, v111, 229).m128_f32[0] + v117->force.y;
    *(_QWORD *)&v113 = LODWORD(v117->force.z);
    *(float *)&v113 = *(float *)&v113 + v153;
    v117->force.z = *(float *)&v113;
  }
LABEL_134:
  if ( v11 )
  {
    v120 = _mm_shuffle_ps(v111, v111, 229).m128_f32[0];
    v113 = 0.0;
    if ( v120 <= 0.0 )
    {
      v123 = *((_QWORD *)v11 + 25);
      v124 = *(_QWORD *)(v123 + 64);
      if ( v124 )
      {
        if ( *(_BYTE *)(v124 + 1) )
          RBX::Solver::SolverRigidBody::update(*(RBX::Solver::SolverRigidBody **)(v123 + 64));
        v113 = 0.0;
        *(float *)(v124 + 240) = *(float *)(v124 + 240) + 0.0;
        *(float *)(v124 + 244) = *(float *)(v124 + 244) + 0.0;
        *(float *)(v124 + 248) = *(float *)(v124 + 248) + 0.0;
        *(_QWORD *)&v112 = *((unsigned int *)this + 33);
        v102.m128_u64[0] = *((unsigned int *)this + 34);
        v108.m128_u64[0] = *((unsigned int *)this + 35);
        v102.m128_f32[0] = (float)(v102.m128_f32[0] - *(float *)(v124 + 64)) * 0.0;
        v108.m128_f32[0] = (float)(v108.m128_f32[0] - *(float *)(v124 + 68)) * 0.0;
        *(float *)&v112 = (float)(*(float *)&v112 - *(float *)(v124 + 60)) * 0.0;
        *(float *)(v124 + 252) = (float)(v102.m128_f32[0] - v108.m128_f32[0]) + *(float *)(v124 + 252);
        v108.m128_f32[0] = (float)(v108.m128_f32[0] - *(float *)&v112) + *(float *)(v124 + 256);
        *(_DWORD *)(v124 + 256) = v108.m128_i32[0];
        *(float *)&v112 = (float)(*(float *)&v112 - v102.m128_f32[0]) + *(float *)(v124 + 260);
        *(_DWORD *)(v124 + 260) = LODWORD(v112);
      }
    }
    else
    {
      v121 = *(RBX::Solver::SolverRigidBody **)(*((_QWORD *)v11 + 25) + 64LL);
      if ( v121 )
      {
        v111.m128_f32[0] = v111.m128_f32[0] * -0.1;
        v122 = v120 * -0.1;
        v154 = v153 * -0.1;
        if ( v121->dirty )
          RBX::Solver::SolverRigidBody::update(v121);
        v121->force.x = v121->force.x + v111.m128_f32[0];
        v121->force.y = v121->force.y + v122;
        v121->force.z = v121->force.z + v154;
        *(_QWORD *)&v113 = *((unsigned int *)this + 33);
        *(float *)&v113 = *(float *)&v113 - v121->pv.position.translation.x;
        *(_QWORD *)&v112 = *((unsigned int *)this + 34);
        *(float *)&v112 = *(float *)&v112 - v121->pv.position.translation.y;
        v102.m128_u64[0] = *((unsigned int *)this + 35);
        v102.m128_f32[0] = v102.m128_f32[0] - v121->pv.position.translation.z;
        v108.m128_u64[0] = LODWORD(v154);
        v108.m128_f32[0] = (float)(v154 * *(float *)&v112) - (float)(v122 * v102.m128_f32[0]);
        *(float *)&v112 = *(float *)&v112 * v111.m128_f32[0];
        v108.m128_f32[0] = v108.m128_f32[0] + v121->torque.x;
        LODWORD(v121->torque.x) = v108.m128_i32[0];
        v102.m128_f32[0] = (float)((float)(v102.m128_f32[0] * v111.m128_f32[0]) - (float)(v154 * *(float *)&v113))
                         + v121->torque.y;
        LODWORD(v121->torque.y) = v102.m128_i32[0];
        *(float *)&v113 = (float)((float)(*(float *)&v113 * v122) - *(float *)&v112) + v121->torque.z;
        v121->torque.z = *(float *)&v113;
      }
    }
  }
  v125 = RBX::PartInstance::fromPrimitive(v11);
  v126 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  TorsoSlow = RBX::Humanoid::getTorsoSlow(v126);
  if ( v125 && TorsoSlow )
  {
    RBX::shared_from<RBX::PartInstance>(
      (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)&iBody,
      TorsoSlow);
    RBX::PartInstance::reportTouch(v125, (const boost::shared_ptr<RBX::PartInstance> *)&iBody);
    v130 = *(volatile signed __int32 **)&iBody.elt[0][2];
    if ( *(_QWORD *)&iBody.elt[0][2] )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&iBody.elt[0][2] + 8LL), 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, double, double, double, double, double, double, double))(*(_QWORD *)v130 + 16LL))(
          v130,
          v113,
          v112,
          *(double *)v102.m128_u64,
          *(double *)v108.m128_u64,
          v128,
          v129,
          *(double *)v111.m128_u64);
        if ( !_InterlockedSub(v130 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v130 + 24LL))(v130);
      }
    }
    v131 = v7->root->rigidBody;
    if ( v131->dirty )
      RBX::Solver::SolverRigidBody::update(v131);
  }
}


// Address: 0x10ec370 | Name: _ZN3RBX5HUMAN11RunningBase19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::RunningBase::onSimulatorStepImpl(RBX::HUMAN::RunningBase *this, double a2, double stepDt)
{
  float DesiredAltitude; // xmm0_4
  double v4; // xmm0_8
  const RBX::Humanoid *HumanoidConst; // rax
  __m128 v6; // xmm1
  __m128 v7; // xmm0
  __m128 v8; // xmm1
  RBX::Humanoid *v9; // rax
  RBX::PartInstance *TorsoSlow; // rax
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  __int128 v12; // xmm7
  __m128 v13; // xmm3
  __m128 v14; // xmm2
  __m128 v15; // xmm4
  __m128 v16; // xmm5
  __m128 v17; // xmm6
  __m128 v18; // xmm0
  __m128 v19; // xmm1
  __m128 v20; // xmm2
  __m128 v21; // xmm1
  _BOOL8 v22; // rax
  float v23; // xmm3_4
  __m128 v24; // xmm0
  __m128 v25; // xmm1
  __m128 v26; // rt1
  __m128 v27; // xmm0
  __m128 x_low; // xmm0
  RBX::Vector3 *v29; // rbx
  const RBX::Humanoid *v30; // r15
  RBX::Primitive *LadderPrimitive; // rax
  const RBX::Primitive *v32; // r14
  const RBX::PV *PV; // rax
  __m128 v34; // xmm5
  __m128 v35; // xmm0
  __m128 v36; // xmm7
  __m128 v37; // xmm1
  __m128 v38; // xmm2
  __m128 v39; // xmm0
  const RBX::Humanoid *v40; // rax
  float v41; // xmm3_4
  __m128 v42; // xmm0
  float v43; // xmm4_4
  __m128 v44; // xmm2
  float v45; // xmm3_4
  RBX::Velocity v46; // [rsp+8h] [rbp-70h] BYREF
  __m128 z_low; // [rsp+20h] [rbp-58h]
  __m128 v48; // [rsp+30h] [rbp-48h]
  __m128 v49; // [rsp+40h] [rbp-38h]
  __m128 v50; // [rsp+50h] [rbp-28h]
  G3D::Vector3 v51; // 0:kr00_12.12
  RBX::Vector3 DownwardVectorOnSteepSlope; // 0:kr14_12.12

  if ( RBX::HUMAN::HumanoidState::getFloorPrimitive(this) )
    DesiredAltitude = RBX::HUMAN::HumanoidState::getDesiredAltitude(this);
  else
    DesiredAltitude = INFINITY;
  *((float *)this + 97) = DesiredAltitude;
  RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v46, this);
  *((_QWORD *)this + 52) = *(_QWORD *)&v46.rotational.y;
  v4 = *(double *)&v46.linear.x;
  *((_OWORD *)this + 25) = *(_OWORD *)&v46.linear.x;
  if ( RBX::HUMAN::HumanoidState::getFloorPrimitive(this)
    || (*(unsigned int (__fastcall **)(RBX::HUMAN::RunningBase *, double, double))(*(_QWORD *)this + 128LL))(
         this,
         v4,
         stepDt) == 12
    || *((_DWORD *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 622) == 12 )
  {
    HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    (*(void (__fastcall **)(RBX::Velocity *, const RBX::Humanoid *, double, double))(*(_QWORD *)HumanoidConst + 416LL))(
      &v46,
      HumanoidConst,
      v4,
      stepDt);
    *(RBX::Velocity *)((char *)this + 424) = v46;
  }
  if ( *((_BYTE *)this + 13) )
  {
    v6 = _mm_mul_ps(
           (__m128)*(unsigned __int64 *)((char *)this + 428),
           (__m128)*(unsigned __int64 *)((char *)this + 428));
    v7 = 0;
    v7.m128_f32[0] = fsqrt(
                       _mm_shuffle_ps(v6, v6, 229).m128_f32[0]
                     + (float)((float)(*((float *)this + 106) * *((float *)this + 106)) + v6.m128_f32[0]));
    v8 = 0;
    if ( v7.m128_f32[0] > 0.0 )
    {
      v9 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
      TorsoSlow = RBX::Humanoid::getTorsoSlow(v9);
      CoordinateFrame = RBX::PartInstance::getCoordinateFrame(TorsoSlow);
      v51 = G3D::Matrix3::column(&CoordinateFrame->rotation, 2);
      v7.m128_i32[0] = LODWORD(v51.x);
      v7.m128_i32[1] = LODWORD(v51.y);
      v8.m128_i32[0] = LODWORD(v51.z);
      v12 = 0;
      v13 = _mm_unpacklo_ps((__m128)0LL, v8);
      v14 = _mm_shuffle_ps(_mm_shuffle_ps((__m128)*((unsigned int *)this + 106), v7, 0), v7, 226);
      v15 = (__m128)*(unsigned __int64 *)((char *)this + 428);
      v16 = _mm_mul_ps(v15, v15);
      v17 = _mm_add_ps(_mm_unpacklo_ps((__m128)0LL, v16), _mm_mul_ps(v14, v14));
      v16.m128_f32[0] = v8.m128_f32[0] * v8.m128_f32[0];
      v18 = _mm_sqrt_ps(_mm_add_ps(v16, v17));
      v19 = _mm_div_ps(*(__m128 *)&stru_3E5440.x, v18);
      v20 = _mm_mul_ps(v14, v19);
      v21 = _mm_mul_ps(_mm_mul_ps(_mm_shuffle_ps(v19, v19, 229), v15), _mm_mul_ps(_mm_shuffle_ps(v19, v19, 224), v13));
      v22 = (float)((float)(v21.m128_f32[0] - (float)(_mm_shuffle_ps(v20, v20, 229).m128_f32[0] * v20.m128_f32[0]))
                  - _mm_shuffle_ps(v21, v21, 229).m128_f32[0]) < -0.2;
      v23 = flt_4900F0[v22];
      if ( v23 <= 0.0 )
      {
        z_low.m128_f32[0] = flt_4900F0[v22];
        if ( RBX::HUMAN::HumanoidState::getFloorPrimitive(this) )
          goto LABEL_15;
        v24 = 0;
        v24.m128_f32[0] = fsqrt(
                            (float)(*((float *)this + 108) * *((float *)this + 108))
                          + (float)((float)(*((float *)this + 107) * *((float *)this + 107))
                                  + (float)(*((float *)this + 106) * *((float *)this + 106))));
        v12 = 0;
        v23 = z_low.m128_f32[0];
      }
      else
      {
        v24 = _mm_shuffle_ps(v18, v18, 229);
      }
      v25 = (__m128)0x3F333333u;
      v25.m128_f32[0] = 0.69999999 * v24.m128_f32[0];
      v26.m128_i32[0] = 1036831949;
      v27 = _mm_cmplt_ss(v24, v26);
      *((float *)this + 107) = v23 * COERCE_FLOAT(_mm_andnot_ps(v27, v25).m128_u32[0] | v27.m128_i32[0] & 0x3C23D70A);
      *((_DWORD *)this + 106) = 0;
      *((_OWORD *)this + 27) = v12;
    }
  }
LABEL_15:
  if ( RBX::HUMAN::HumanoidState::getFloorPrimitive(this) )
  {
    v46.linear = *(RBX::Vector3 *)((_BYTE *)this + 12);
    x_low = (__m128)LODWORD(v46.linear.x);
    z_low.m128_f32[0] = (float)(0.0 * v46.linear.z) + (float)((float)(v46.linear.x * 0.0) + v46.linear.y);
    DownwardVectorOnSteepSlope = RBX::Humanoid::getDownwardVectorOnSteepSlope(&v46.linear);
    x_low.m128_i32[0] = LODWORD(DownwardVectorOnSteepSlope.x);
    x_low.m128_i32[1] = LODWORD(DownwardVectorOnSteepSlope.y);
    _mm_storel_ps((double *)this + 56, x_low);
    *((_DWORD *)this + 114) = LODWORD(DownwardVectorOnSteepSlope.z);
    x_low.m128_f32[0] = RBX::HUMAN::HumanoidState::steepSlopeAngle(this);
    v29 = (RBX::Vector3 *)((char *)this + 424);
    if ( x_low.m128_f32[0] <= z_low.m128_f32[0] )
      RBX::Humanoid::reprojectDesiredLinearVelocityToFloor(&v46.linear, v29);
    else
      RBX::Humanoid::cancelXZDesiredVelocityUpSteepSlope(&v46.linear, v29);
  }
  else if ( stru_2A08D48.value
         && (*(unsigned int (__fastcall **)(RBX::HUMAN::RunningBase *))(*(_QWORD *)this + 128LL))(this) == 12 )
  {
    v30 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    LadderPrimitive = RBX::HUMAN::HumanoidState::getLadderPrimitive(this);
    if ( v30 )
    {
      v32 = LadderPrimitive;
      if ( LadderPrimitive )
      {
        if ( !RBX::Primitive::computeIsGrounded(LadderPrimitive) )
        {
          PV = RBX::Primitive::getPV(v32);
          v34 = (__m128)*((unsigned int *)this + 51);
          v34.m128_f32[0] = v34.m128_f32[0] - PV->position.translation.y;
          v35 = _mm_sub_ps(
                  _mm_unpacklo_ps((__m128)*((unsigned int *)this + 52), (__m128)*((unsigned int *)this + 50)),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(PV->position.translation.z),
                    (__m128)LODWORD(PV->position.translation.x)));
          v36 = (__m128)_mm_loadl_epi64((const __m128i *)&PV->velocity.rotational);
          v37 = (__m128)_mm_shuffle_epi32((__m128i)v36, 229);
          z_low = (__m128)LODWORD(PV->velocity.rotational.z);
          v50 = v36;
          v38 = _mm_sub_ps(
                  _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(z_low, v37, 0), v37, 226), v35),
                  _mm_mul_ps(_mm_unpacklo_ps(z_low, v36), _mm_unpacklo_ps(v34, v35)));
          v34.m128_f32[0] = (float)(v34.m128_f32[0] * v36.m128_f32[0])
                          - (float)(_mm_shuffle_ps(v35, v35, 229).m128_f32[0] * v37.m128_f32[0]);
          v39 = _mm_add_ps((__m128)*(unsigned __int64 *)&PV->velocity.linear.x, v38);
          v49 = v39;
          v34.m128_f32[0] = v34.m128_f32[0] + PV->velocity.linear.z;
          v48 = v34;
          v40 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
          v39.m128_f32[0] = RBX::EThrottle::getEnvironmentSpeed((const RBX::EThrottle *)(*((_QWORD *)v40 + 308) + 40LL));
          v38.m128_f32[0] = v48.m128_f32[0] * v39.m128_f32[0];
          v41 = z_low.m128_f32[0] * v39.m128_f32[0];
          v42 = _mm_shuffle_ps(v39, v39, 224);
          v43 = v38.m128_f32[0] + *((float *)this + 108);
          v44 = _mm_add_ps((__m128)*(unsigned __int64 *)((char *)this + 436), _mm_mul_ps(v42, v50));
          v45 = v41 + *((float *)this + 111);
          _mm_storel_ps((double *)this + 53, _mm_add_ps((__m128)*((unsigned __int64 *)this + 53), _mm_mul_ps(v49, v42)));
          *((float *)this + 108) = v43;
          _mm_storel_ps((double *)((char *)this + 436), v44);
          *((float *)this + 111) = v45;
        }
      }
    }
  }
}


// Address: 0x10ec7f0 | Name: _ZN3RBX5HUMAN11RunningBase29onCFrameChangedFromReflectionEv
void __fastcall RBX::HUMAN::RunningBase::onCFrameChangedFromReflection(RBX::HUMAN::RunningBase *this)
{
  float DesiredAltitude; // xmm0_4
  const RBX::Humanoid *HumanoidConst; // rax
  __m128 v3; // xmm0
  float v4; // xmm1_4
  __m128 v5; // xmm0
  __m128d v6; // xmm0
  float v7; // xmm0_4
  unsigned __int64 v8; // [rsp+8h] [rbp-30h]
  double v9; // [rsp+10h] [rbp-28h]
  RBX::Velocity v10; // [rsp+18h] [rbp-20h] BYREF

  RBX::HUMAN::HumanoidState::preStepFloor(this);
  if ( RBX::HUMAN::HumanoidState::getFloorPrimitive(this) )
    DesiredAltitude = RBX::HUMAN::HumanoidState::getDesiredAltitude(this);
  else
    DesiredAltitude = INFINITY;
  *((float *)this + 97) = DesiredAltitude;
  RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v10, this);
  *(RBX::Velocity *)((char *)this + 400) = v10;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  (*(void (__fastcall **)(RBX::Velocity *, const RBX::Humanoid *))(*(_QWORD *)HumanoidConst + 416LL))(
    &v10,
    HumanoidConst);
  *(RBX::Velocity *)((char *)this + 424) = v10;
  v3 = _mm_mul_ps((__m128)*(unsigned __int64 *)((char *)this + 428), (__m128)*(unsigned __int64 *)((char *)this + 428));
  v4 = (float)(*((float *)this + 106) * *((float *)this + 106)) + v3.m128_f32[0];
  v5 = _mm_shuffle_ps(v3, v3, 229);
  v5.m128_f32[0] = v5.m128_f32[0] + v4;
  if ( v5.m128_f32[0] != 0.0 )
  {
    v6 = (__m128d)_mm_and_ps(v5, (__m128)xmmword_3E5B40);
    v9 = *(float *)v6.m128d_f64;
    *(double *)&v8 = *(float *)v6.m128d_f64 + 1.0;
    v6.m128d_f64[0] = G3D::inf();
    v6.m128d_f64[0] = _mm_cmpeq_sd(v6, (__m128d)v8).m128d_f64[0];
    if ( COERCE_DOUBLE(
           *(_QWORD *)&v6.m128d_f64[0] & 0x3EE4F8B580000000LL
         | ~*(_QWORD *)&v6.m128d_f64[0] & COERCE_UNSIGNED_INT64(*(double *)&v8 * 0.000009999999747378752)) < v9 )
    {
      if ( *((_BYTE *)this + 13) )
      {
        v7 = fsqrt(
               (float)(*((float *)this + 108) * *((float *)this + 108))
             + (float)((float)(*((float *)this + 107) * *((float *)this + 107))
                     + (float)(*((float *)this + 106) * *((float *)this + 106))));
        *((_DWORD *)this + 106) = 0;
        *((float *)this + 107) = v7 * 0.69999999;
        *((_DWORD *)this + 108) = 0;
      }
    }
  }
}


// Address: 0x10ec980 | Name: _GLOBAL__sub_I_RunningBase.cpp
void __cdecl GLOBAL__sub_I_RunningBase_cpp()
{
  qword_2A08F50 = (__int64)boost::system::generic_category();
  qword_2A08F58 = (__int64)boost::system::generic_category();
  qword_2A08F60 = (__int64)boost::system::system_category();
  dword_2A08F6C = FLog::RegisterLogGroup("HumanoidFloorProcess", &byte_2A08F68, FastVarType::FASTVARTYPE_STATIC);
  dword_2A08F70 = FLog::RegisterInt("RunningBaseOrientationP", &dword_2859688, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F74 = FLog::RegisterInt("RunningBaseMaxAcceleration", &dword_2859698, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F78 = FLog::RegisterInt("RunningBaseAltitudeP", &dword_28596A8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F7C = FLog::RegisterInt("RunningBaseAltitudeD", &dword_28596B8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F80 = FLog::RegisterInt(
                    "RunningBaseGravityReductionFactorHundredth",
                    &dword_28596C8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F84 = FLog::RegisterInt("NewRunningBaseAltitudeP", &dword_28596D8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F88 = FLog::RegisterInt("NewRunningBaseAltitudeD", &dword_28596E8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F8C = FLog::RegisterInt("MaxAltitudePDHipHeightPercent", &dword_28596F8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F90 = FLog::RegisterInt(
                    "MaxAltitudePDStickHipHeightPercent",
                    &dword_2859708,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F94 = FLog::RegisterInt("SolidFloorMassMultTenth", &dword_2859718, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F98 = FLog::RegisterInt(
                    "SolidFloorPercentForceApplication",
                    &dword_2859728,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F9C = FLog::RegisterInt(
                    "NonSolidFloorPercentForceApplication",
                    &dword_2859738,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08FA4 = FLog::RegisterInt(
                    "NewRunningBaseGravityReductionFactorHundredth",
                    &dword_2A08FA0,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08FA8 = FLog::RegisterInt(
                    "NewPDAltitudeWeakPushFinalDepressPercent",
                    &dword_2859750,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08FAC = FLog::RegisterInt("NewPDAltitudeNoForceZonePercent", &dword_2859760, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08FB0 = FLog::RegisterInt(
                    "NewPDSteepSlopeSlidingWithGravityPercent",
                    &dword_2859770,
                    FastVarType::FASTVARTYPE_DYNAMIC);
}


