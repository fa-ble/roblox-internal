// Address: 0x1e08da0 | Name: _ZN3RBX9Collision21BlockBlockContact_NewD0Ev
void __fastcall RBX::Collision::BlockBlockContact_New::~BlockBlockContact_New(
        RBX::Collision::BlockBlockContact_New *this)
{
  RBX::Collision::FeaturePolyContact::~FeaturePolyContact(this);
  operator delete(this);
}


