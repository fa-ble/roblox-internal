// Address: 0x1060c70 | Name: _ZN3RBX24KeyframeSequenceProviderD2Ev
void __fastcall RBX::KeyframeSequenceProvider::~KeyframeSequenceProvider(RBX::KeyframeSequenceProvider *this)
{
  this->_vptr$EventSource = (int (**)(void))off_288FDB8;
  RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::~LRUCache(&this->frozenKeyframeSequenceCache);
  RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::~LRUCache(&this->fullKeyframeSequenceCache);
  while ( pthread_mutex_destroy(&this->keyframeSequenceCacheMutex.m) == 4 )
    ;
  std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::destroy(
    &this->activeKeyframeTable.__tree_,
    (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > >::__node_pointer)this->activeKeyframeTable.__tree_.__pair1_.__value_.__left_);
  RBX::Instance::~Instance(this);
}


// Address: 0x1060cd0 | Name: _ZN3RBX24KeyframeSequenceProviderD0Ev
void __fastcall RBX::KeyframeSequenceProvider::~KeyframeSequenceProvider(RBX::KeyframeSequenceProvider *this)
{
  this->_vptr$EventSource = (int (**)(void))off_288FDB8;
  RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::~LRUCache(&this->frozenKeyframeSequenceCache);
  RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::~LRUCache(&this->fullKeyframeSequenceCache);
  while ( pthread_mutex_destroy(&this->keyframeSequenceCacheMutex.m) == 4 )
    ;
  std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::destroy(
    &this->activeKeyframeTable.__tree_,
    (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > >::__node_pointer)this->activeKeyframeTable.__tree_.__pair1_.__value_.__left_);
  RBX::Instance::~Instance(this);
  operator delete(this);
}


