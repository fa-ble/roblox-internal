// Address: 0x10f8cc0 | Name: _ZNK3RBX19HumanoidDescription14getScaleHeightEv
float __fastcall RBX::HumanoidDescription::getScaleHeight(const RBX::HumanoidDescription *this)
{
  return this->scaleHeight;
}


// Address: 0x10f8e20 | Name: _ZNK3RBX19HumanoidDescription13getScaleWidthEv
float __fastcall RBX::HumanoidDescription::getScaleWidth(const RBX::HumanoidDescription *this)
{
  return this->scaleWidth;
}


// Address: 0x10f8e30 | Name: _ZNK3RBX19HumanoidDescription12getScaleHeadEv
float __fastcall RBX::HumanoidDescription::getScaleHead(const RBX::HumanoidDescription *this)
{
  return this->scaleHead;
}


// Address: 0x10f8e40 | Name: _ZNK3RBX19HumanoidDescription13getScaleDepthEv
float __fastcall RBX::HumanoidDescription::getScaleDepth(const RBX::HumanoidDescription *this)
{
  return this->scaleDepth;
}


// Address: 0x10f8e50 | Name: _ZNK3RBX19HumanoidDescription18getScaleProportionEv
float __fastcall RBX::HumanoidDescription::getScaleProportion(const RBX::HumanoidDescription *this)
{
  return this->scaleProportion;
}


// Address: 0x10f8e60 | Name: _ZNK3RBX19HumanoidDescription16getScaleBodyTypeEv
float __fastcall RBX::HumanoidDescription::getScaleBodyType(const RBX::HumanoidDescription *this)
{
  return this->scaleBodyType;
}


// Address: 0x10f8e70 | Name: _ZNK3RBX19HumanoidDescription16getBodyColorHeadEv
G3D::Color3 __fastcall RBX::HumanoidDescription::getBodyColorHead(const RBX::HumanoidDescription *this)
{
  G3D::Color3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.r = *(_QWORD *)&this->bodyColorHead.r;
  result.b = this->bodyColorHead.b;
  return result;
}


// Address: 0x10f8fe0 | Name: _ZNK3RBX19HumanoidDescription17getBodyColorTorsoEv
G3D::Color3 __fastcall RBX::HumanoidDescription::getBodyColorTorso(const RBX::HumanoidDescription *this)
{
  G3D::Color3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.r = *(_QWORD *)&this->bodyColorTorso.r;
  result.b = this->bodyColorTorso.b;
  return result;
}


// Address: 0x10f9000 | Name: _ZNK3RBX19HumanoidDescription20getBodyColorRightArmEv
G3D::Color3 __fastcall RBX::HumanoidDescription::getBodyColorRightArm(const RBX::HumanoidDescription *this)
{
  G3D::Color3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.r = *(_QWORD *)&this->bodyColorRightArm.r;
  result.b = this->bodyColorRightArm.b;
  return result;
}


// Address: 0x10f9020 | Name: _ZNK3RBX19HumanoidDescription19getBodyColorLeftArmEv
G3D::Color3 __fastcall RBX::HumanoidDescription::getBodyColorLeftArm(const RBX::HumanoidDescription *this)
{
  G3D::Color3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.r = *(_QWORD *)&this->bodyColorLeftArm.r;
  result.b = this->bodyColorLeftArm.b;
  return result;
}


// Address: 0x10f9040 | Name: _ZNK3RBX19HumanoidDescription20getBodyColorRightLegEv
G3D::Color3 __fastcall RBX::HumanoidDescription::getBodyColorRightLeg(const RBX::HumanoidDescription *this)
{
  G3D::Color3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.r = *(_QWORD *)&this->bodyColorRightLeg.r;
  result.b = this->bodyColorRightLeg.b;
  return result;
}


// Address: 0x10f9060 | Name: _ZNK3RBX19HumanoidDescription19getBodyColorLeftLegEv
G3D::Color3 __fastcall RBX::HumanoidDescription::getBodyColorLeftLeg(const RBX::HumanoidDescription *this)
{
  G3D::Color3 result; // 0:xmm0_8.8,8:xmm1_4.4

  *(_QWORD *)&result.r = *(_QWORD *)&this->bodyColorLeftLeg.r;
  result.b = this->bodyColorLeftLeg.b;
  return result;
}


// Address: 0x10f91d0 | Name: _ZNK3RBX19HumanoidDescription15getClothesShirtEv
int64_t __fastcall RBX::HumanoidDescription::getClothesShirt(const RBX::HumanoidDescription *this)
{
  return this->clothesShirt;
}


// Address: 0x10f9360 | Name: _ZNK3RBX19HumanoidDescription15getClothesPantsEv
int64_t __fastcall RBX::HumanoidDescription::getClothesPants(const RBX::HumanoidDescription *this)
{
  return this->clothesPants;
}


// Address: 0x10f9370 | Name: _ZNK3RBX19HumanoidDescription23getClothesGraphicTShirtEv
int64_t __fastcall RBX::HumanoidDescription::getClothesGraphicTShirt(const RBX::HumanoidDescription *this)
{
  return this->clothesGraphicTShirt;
}


// Address: 0x10f9380 | Name: _ZNK3RBX19HumanoidDescription16getBodyPartsFaceEv
int64_t __fastcall RBX::HumanoidDescription::getBodyPartsFace(const RBX::HumanoidDescription *this)
{
  return this->bodyPartsFace;
}


// Address: 0x10f9390 | Name: _ZNK3RBX19HumanoidDescription16getBodyPartsHeadEv
int64_t __fastcall RBX::HumanoidDescription::getBodyPartsHead(const RBX::HumanoidDescription *this)
{
  return this->bodyPartsHead;
}


// Address: 0x10f93a0 | Name: _ZNK3RBX19HumanoidDescription17getBodyPartsTorsoEv
int64_t __fastcall RBX::HumanoidDescription::getBodyPartsTorso(const RBX::HumanoidDescription *this)
{
  return this->bodyPartsTorso;
}


// Address: 0x10f93b0 | Name: _ZNK3RBX19HumanoidDescription19getBodyPartsLeftArmEv
int64_t __fastcall RBX::HumanoidDescription::getBodyPartsLeftArm(const RBX::HumanoidDescription *this)
{
  return this->bodyPartsLeftArm;
}


// Address: 0x10f93c0 | Name: _ZNK3RBX19HumanoidDescription20getBodyPartsRightArmEv
int64_t __fastcall RBX::HumanoidDescription::getBodyPartsRightArm(const RBX::HumanoidDescription *this)
{
  return this->bodyPartsRightArm;
}


// Address: 0x10f93d0 | Name: _ZNK3RBX19HumanoidDescription19getBodyPartsLeftLegEv
int64_t __fastcall RBX::HumanoidDescription::getBodyPartsLeftLeg(const RBX::HumanoidDescription *this)
{
  return this->bodyPartsLeftLeg;
}


// Address: 0x10f93e0 | Name: _ZNK3RBX19HumanoidDescription20getBodyPartsRightLegEv
int64_t __fastcall RBX::HumanoidDescription::getBodyPartsRightLeg(const RBX::HumanoidDescription *this)
{
  return this->bodyPartsRightLeg;
}


// Address: 0x10f93f0 | Name: _ZNK3RBX19HumanoidDescription16getAnimationWalkEv
int64_t __fastcall RBX::HumanoidDescription::getAnimationWalk(const RBX::HumanoidDescription *this)
{
  return this->animationWalk;
}


// Address: 0x10f9400 | Name: _ZNK3RBX19HumanoidDescription15getAnimationRunEv
int64_t __fastcall RBX::HumanoidDescription::getAnimationRun(const RBX::HumanoidDescription *this)
{
  return this->animationRun;
}


// Address: 0x10f9410 | Name: _ZNK3RBX19HumanoidDescription16getAnimationFallEv
int64_t __fastcall RBX::HumanoidDescription::getAnimationFall(const RBX::HumanoidDescription *this)
{
  return this->animationFall;
}


// Address: 0x10f9420 | Name: _ZNK3RBX19HumanoidDescription16getAnimationJumpEv
int64_t __fastcall RBX::HumanoidDescription::getAnimationJump(const RBX::HumanoidDescription *this)
{
  return this->animationJump;
}


// Address: 0x10f9430 | Name: _ZNK3RBX19HumanoidDescription16getAnimationSwimEv
int64_t __fastcall RBX::HumanoidDescription::getAnimationSwim(const RBX::HumanoidDescription *this)
{
  return this->animationSwim;
}


// Address: 0x10f9440 | Name: _ZNK3RBX19HumanoidDescription17getAnimationClimbEv
int64_t __fastcall RBX::HumanoidDescription::getAnimationClimb(const RBX::HumanoidDescription *this)
{
  return this->animationClimb;
}


// Address: 0x10f9450 | Name: _ZNK3RBX19HumanoidDescription16getAnimationIdleEv
int64_t __fastcall RBX::HumanoidDescription::getAnimationIdle(const RBX::HumanoidDescription *this)
{
  return this->animationIdle;
}


// Address: 0x10f9a70 | Name: _ZNK3RBX19HumanoidDescription21getNumberEmotesLoadedEv
int __fastcall RBX::HumanoidDescription::getNumberEmotesLoaded(const RBX::HumanoidDescription *this)
{
  return this->numberEmotesLoaded;
}


// Address: 0x10f9dd0 | Name: _ZN3RBX19HumanoidDescriptionD2Ev
void __fastcall RBX::HumanoidDescription::~HumanoidDescription(RBX::HumanoidDescription *this)
{
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const int,std::string > >,int,std::string,boost::hash<int>,std::equal_to<int> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // r12
  boost::unordered::detail::ptr_bucket::link_pointer next; // rbx
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v5; // r15
  size_t v6; // rbx
  boost::unordered::detail::ptr_bucket *v7; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v8; // r15
  size_t v9; // rbx
  boost::unordered::detail::ptr_bucket *v10; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v11; // r15
  size_t v12; // rbx
  boost::unordered::detail::ptr_bucket *v13; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v14; // r15
  size_t v15; // rbx
  boost::unordered::detail::ptr_bucket *v16; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v17; // r15
  size_t v18; // rbx
  boost::unordered::detail::ptr_bucket *v19; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v20; // r15
  size_t v21; // rbx
  boost::unordered::detail::ptr_bucket *v22; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v23; // r15
  size_t v24; // rbx
  boost::unordered::detail::ptr_bucket *v25; // rdi
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<long>,long,boost::hash<long>,std::equal_to<long> > >::bucket_pointer v26; // r15
  size_t v27; // rbx
  boost::unordered::detail::ptr_bucket *v28; // rdi

  this->_vptr$EventSource = (int (**)(void))off_2897790;
  buckets = this->equippedEmotes.table_.buckets_;
  if ( buckets )
  {
    if ( this->equippedEmotes.table_.size_ )
    {
      bucket_count = this->equippedEmotes.table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        if ( ((__int64)next[3].next_ & 1) != 0 )
          operator delete(next[5].next_);
        operator delete(next);
        --this->equippedEmotes.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->equippedEmotes.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->equippedEmotes.table_.max_load_ = 0;
  }
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,std::set<long>>>,std::string,std::set<long>,boost::hash<std::string>,std::equal_to<std::string>>>::delete_buckets(&this->emotesMap.table_);
  v5 = this->accessoriesWaist.table_.buckets_;
  if ( v5 )
  {
    if ( this->accessoriesWaist.table_.size_ )
    {
      v6 = this->accessoriesWaist.table_.bucket_count_;
      v7 = v5[v6].next_;
      do
      {
        v5[v6] = (boost::unordered::detail::ptr_bucket)v7->next_;
        operator delete(v7);
        --this->accessoriesWaist.table_.size_;
        v7 = v5[v6].next_;
      }
      while ( v7 );
      v5 = this->accessoriesWaist.table_.buckets_;
    }
    operator delete(v5);
    *(_OWORD *)&this->accessoriesWaist.table_.max_load_ = 0;
  }
  v8 = this->accessoriesBack.table_.buckets_;
  if ( v8 )
  {
    if ( this->accessoriesBack.table_.size_ )
    {
      v9 = this->accessoriesBack.table_.bucket_count_;
      v10 = v8[v9].next_;
      do
      {
        v8[v9] = (boost::unordered::detail::ptr_bucket)v10->next_;
        operator delete(v10);
        --this->accessoriesBack.table_.size_;
        v10 = v8[v9].next_;
      }
      while ( v10 );
      v8 = this->accessoriesBack.table_.buckets_;
    }
    operator delete(v8);
    *(_OWORD *)&this->accessoriesBack.table_.max_load_ = 0;
  }
  v11 = this->accessoriesFront.table_.buckets_;
  if ( v11 )
  {
    if ( this->accessoriesFront.table_.size_ )
    {
      v12 = this->accessoriesFront.table_.bucket_count_;
      v13 = v11[v12].next_;
      do
      {
        v11[v12] = (boost::unordered::detail::ptr_bucket)v13->next_;
        operator delete(v13);
        --this->accessoriesFront.table_.size_;
        v13 = v11[v12].next_;
      }
      while ( v13 );
      v11 = this->accessoriesFront.table_.buckets_;
    }
    operator delete(v11);
    *(_OWORD *)&this->accessoriesFront.table_.max_load_ = 0;
  }
  v14 = this->accessoriesShoulders.table_.buckets_;
  if ( v14 )
  {
    if ( this->accessoriesShoulders.table_.size_ )
    {
      v15 = this->accessoriesShoulders.table_.bucket_count_;
      v16 = v14[v15].next_;
      do
      {
        v14[v15] = (boost::unordered::detail::ptr_bucket)v16->next_;
        operator delete(v16);
        --this->accessoriesShoulders.table_.size_;
        v16 = v14[v15].next_;
      }
      while ( v16 );
      v14 = this->accessoriesShoulders.table_.buckets_;
    }
    operator delete(v14);
    *(_OWORD *)&this->accessoriesShoulders.table_.max_load_ = 0;
  }
  v17 = this->accessoriesNeck.table_.buckets_;
  if ( v17 )
  {
    if ( this->accessoriesNeck.table_.size_ )
    {
      v18 = this->accessoriesNeck.table_.bucket_count_;
      v19 = v17[v18].next_;
      do
      {
        v17[v18] = (boost::unordered::detail::ptr_bucket)v19->next_;
        operator delete(v19);
        --this->accessoriesNeck.table_.size_;
        v19 = v17[v18].next_;
      }
      while ( v19 );
      v17 = this->accessoriesNeck.table_.buckets_;
    }
    operator delete(v17);
    *(_OWORD *)&this->accessoriesNeck.table_.max_load_ = 0;
  }
  v20 = this->accessoriesFace.table_.buckets_;
  if ( v20 )
  {
    if ( this->accessoriesFace.table_.size_ )
    {
      v21 = this->accessoriesFace.table_.bucket_count_;
      v22 = v20[v21].next_;
      do
      {
        v20[v21] = (boost::unordered::detail::ptr_bucket)v22->next_;
        operator delete(v22);
        --this->accessoriesFace.table_.size_;
        v22 = v20[v21].next_;
      }
      while ( v22 );
      v20 = this->accessoriesFace.table_.buckets_;
    }
    operator delete(v20);
    *(_OWORD *)&this->accessoriesFace.table_.max_load_ = 0;
  }
  v23 = this->accessoriesHair.table_.buckets_;
  if ( v23 )
  {
    if ( this->accessoriesHair.table_.size_ )
    {
      v24 = this->accessoriesHair.table_.bucket_count_;
      v25 = v23[v24].next_;
      do
      {
        v23[v24] = (boost::unordered::detail::ptr_bucket)v25->next_;
        operator delete(v25);
        --this->accessoriesHair.table_.size_;
        v25 = v23[v24].next_;
      }
      while ( v25 );
      v23 = this->accessoriesHair.table_.buckets_;
    }
    operator delete(v23);
    *(_OWORD *)&this->accessoriesHair.table_.max_load_ = 0;
  }
  v26 = this->accessoriesHat.table_.buckets_;
  if ( v26 )
  {
    if ( this->accessoriesHat.table_.size_ )
    {
      v27 = this->accessoriesHat.table_.bucket_count_;
      v28 = v26[v27].next_;
      do
      {
        v26[v27] = (boost::unordered::detail::ptr_bucket)v28->next_;
        operator delete(v28);
        --this->accessoriesHat.table_.size_;
        v28 = v26[v27].next_;
      }
      while ( v28 );
      v26 = this->accessoriesHat.table_.buckets_;
    }
    operator delete(v26);
    *(_OWORD *)&this->accessoriesHat.table_.max_load_ = 0;
  }
  rbx::signals::signal_base::~signal_base(&this->equippedEmotesChangedSignal);
  rbx::signals::signal_base::~signal_base(&this->emotesChangedSignal);
  RBX::Instance::~Instance(this);
}


// Address: 0x10fa1a0 | Name: _ZN3RBX19HumanoidDescriptionD0Ev
void __fastcall RBX::HumanoidDescription::~HumanoidDescription(RBX::HumanoidDescription *this)
{
  RBX::HumanoidDescription::~HumanoidDescription(this);
  operator delete(this);
}


