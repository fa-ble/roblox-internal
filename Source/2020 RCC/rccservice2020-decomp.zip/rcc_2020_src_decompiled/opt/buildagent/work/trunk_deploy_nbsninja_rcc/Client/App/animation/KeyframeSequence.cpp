// Address: 0x104db40 | Name: _ZN3RBX16KeyframeSequence11addKeyframeEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::KeyframeSequence::addKeyframe(
        RBX::KeyframeSequence *this,
        boost::shared_ptr<RBX::Instance> keyframe)
{
  std::runtime_error *exception; // rbx

  if ( stru_2A035B8.value && this->frozen )
  {
    exception = (std::runtime_error *)__cxa_allocate_exception(0x10u);
    std::runtime_error::runtime_error(exception, "Trying to modify a frozen keyframe sequence");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  if ( keyframe.px->_vptr$EventSource )
    RBX::Instance::setParentWithScriptSecurityChecks((RBX::Instance *)keyframe.px->_vptr$EventSource, this);
}


// Address: 0x104dbc0 | Name: _ZN3RBX16KeyframeSequence14removeKeyframeEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::KeyframeSequence::removeKeyframe(
        RBX::KeyframeSequence *this,
        boost::shared_ptr<RBX::Instance> keyframe)
{
  int (**v2)(void); // rax
  std::runtime_error *exception; // rbx

  if ( stru_2A035B8.value && this->frozen )
  {
    exception = (std::runtime_error *)__cxa_allocate_exception(0x10u);
    std::runtime_error::runtime_error(exception, "Trying to modify a frozen keyframe sequence");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  v2 = keyframe.px->_vptr$EventSource;
  if ( keyframe.px->_vptr$EventSource )
  {
    if ( (char *)v2[11] == (char *)this )
      RBX::Instance::setParentWithScriptSecurityChecks((RBX::Instance *)v2, 0);
  }
}


// Address: 0x104dc50 | Name: _ZN3RBX16KeyframeSequence7setLoopEb
void __fastcall RBX::KeyframeSequence::setLoop(RBX::KeyframeSequence *this, bool value)
{
  if ( this->loop != value )
  {
    this->loop = value;
    RBX::Instance::raisePropertyChanged(this, &stru_2A03790);
  }
}


// Address: 0x104dc70 | Name: _ZN3RBX16KeyframeSequence11setPriorityENS0_8PriorityE
void __fastcall RBX::KeyframeSequence::setPriority(RBX::KeyframeSequence *this, RBX::KeyframeSequence::Priority value)
{
  if ( this->priority != value )
  {
    this->priority = value;
    RBX::Instance::raisePropertyChanged(this, &stru_2A037E8);
  }
}


// Address: 0x104dc90 | Name: _ZN3RBX16KeyframeSequence20setAuthoredHipHeightEf
void __fastcall RBX::KeyframeSequence::setAuthoredHipHeight(RBX::KeyframeSequence *this, float a2, float value)
{
  if ( this->authoredHipHeight != a2 )
  {
    this->authoredHipHeight = a2;
    RBX::Instance::raisePropertyChanged(this, &stru_2A03850);
  }
}


// Address: 0x104dcc0 | Name: _ZN3RBX10Reflection8EnumDescINS_16KeyframeSequence8PriorityEEC2Ev
void __fastcall RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority>::EnumDesc(
        RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority> *this)
{
  RBX::Reflection::EnumDescriptor::EnumDescriptor(this, "AnimationPriority");
  *(_QWORD *)this = &off_288D938;
  RBX::Reflection::EnumDescriptor::_addPairs(this, &stru_288F5E0, 4);
}


// Address: 0x104dd10 | Name: _ZN3RBX16KeyframeSequence5CacheC2Ev
void __fastcall RBX::KeyframeSequence::Cache::Cache(RBX::KeyframeSequence::Cache *this)
{
  *(_DWORD *)this = 0;
  *(_OWORD *)((char *)this + 88) = 0;
  *((_QWORD *)this + 13) = 0;
  *(_OWORD *)((char *)this + 56) = 0;
  *(_OWORD *)((char *)this + 40) = 0;
  *(_OWORD *)((char *)this + 24) = 0;
  *(_OWORD *)((char *)this + 8) = 0;
  *((_QWORD *)this + 9) = 0;
}


// Address: 0x104dd40 | Name: _ZNK3RBX16KeyframeSequence5Cache9findJointERKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEESA_i
int __fastcall RBX::KeyframeSequence::Cache::findJoint(
        const RBX::KeyframeSequence::Cache *this,
        const std::string *parentName,
        const std::string *childName,
        int indexHint)
{
  __int64 v6; // r13
  __int64 v7; // r12
  __int64 v8; // rbx
  __int64 v9; // r14
  unsigned __int8 v10; // r9
  size_t v11; // rdx
  unsigned __int64 v12; // rsi
  char *v13; // rsi
  __int64 v14; // rdx
  int v15; // eax
  __int64 v16; // r8
  unsigned __int64 v17; // rbx
  size_t v18; // rdx
  unsigned __int64 v19; // rsi
  char *v20; // rsi
  __int64 v21; // rdx
  const std::string *v22; // rbx
  int v23; // eax
  __int64 v24; // r14
  unsigned __int64 v25; // r15
  size_t v26; // r15
  char *v27; // rsi
  __int64 v28; // rbp
  unsigned __int64 v29; // r8
  char *v30; // r11
  __int64 v31; // r13
  unsigned __int8 v32; // dl
  unsigned __int64 v33; // rdi
  __int64 v34; // rdx
  int v35; // eax
  unsigned __int8 v36; // dl
  unsigned __int64 v37; // rdi
  __int64 v38; // rdx
  int v39; // eax
  __int64 v41; // [rsp+8h] [rbp-60h]
  size_t n; // [rsp+10h] [rbp-58h]
  size_t na; // [rsp+10h] [rbp-58h]
  const std::string *v44; // [rsp+18h] [rbp-50h]
  char *v45; // [rsp+18h] [rbp-50h]
  __int64 v46; // [rsp+20h] [rbp-48h]
  __int64 v47; // [rsp+28h] [rbp-40h]
  char *v48; // [rsp+30h] [rbp-38h]

  v41 = *((_QWORD *)this + 4);
  v6 = *((_QWORD *)this + 5) - v41;
  v46 = v6 >> 4;
  if ( v6 >> 4 <= (unsigned __int64)indexHint )
    goto LABEL_36;
  LODWORD(v7) = indexHint;
  v8 = 16LL * indexHint;
  v9 = *((_QWORD *)this + 1);
  v10 = *(_BYTE *)(v9 + 24LL * *(_QWORD *)(v41 + v8));
  v11 = (unsigned __int64)v10 >> 1;
  if ( (v10 & 1) != 0 )
    v11 = *(_QWORD *)(v9 + 24LL * *(_QWORD *)(v41 + 16LL * indexHint) + 8);
  v12 = *(unsigned __int8 *)parentName;
  if ( (v12 & 1) != 0 )
  {
    if ( v11 != *((_QWORD *)parentName + 1) )
      goto LABEL_36;
  }
  else if ( v11 != v12 >> 1 )
  {
    goto LABEL_36;
  }
  if ( (v12 & 1) != 0 )
    v13 = (char *)*((_QWORD *)parentName + 2);
  else
    v13 = (char *)parentName + 1;
  if ( (v10 & 1) != 0 )
  {
    if ( v11 )
    {
      v44 = childName;
      v15 = memcmp(*(const void **)(v9 + 24LL * *(_QWORD *)(v41 + 16LL * indexHint) + 16), v13, v11);
      childName = v44;
      if ( v15 )
        goto LABEL_36;
    }
  }
  else if ( v11 )
  {
    v14 = 0;
    while ( *(_BYTE *)(v9 + 24LL * *(_QWORD *)(v41 + 16LL * indexHint) + v14 + 1) == v13[v14] )
    {
      if ( (unsigned __int64)*(unsigned __int8 *)(v9 + 24LL * *(_QWORD *)(v41 + 16LL * indexHint)) >> 1 == ++v14 )
        goto LABEL_19;
    }
    goto LABEL_36;
  }
LABEL_19:
  v16 = 3LL * *(_QWORD *)(v41 + v8 + 8);
  v17 = *(unsigned __int8 *)(v9 + 24LL * *(_QWORD *)(v41 + v8 + 8));
  v18 = v17 >> 1;
  if ( (v17 & 1) != 0 )
    v18 = *(_QWORD *)(v9 + 8 * v16 + 8);
  v19 = *(unsigned __int8 *)childName;
  if ( (v19 & 1) != 0 )
  {
    if ( v18 != *((_QWORD *)childName + 1) )
      goto LABEL_36;
  }
  else if ( v18 != v19 >> 1 )
  {
    goto LABEL_36;
  }
  if ( (v19 & 1) != 0 )
    v20 = (char *)*((_QWORD *)childName + 2);
  else
    v20 = (char *)childName + 1;
  if ( (v17 & 1) != 0 )
  {
    if ( !v18 )
      return v7;
    v22 = childName;
    v23 = memcmp(*(const void **)(v9 + 8 * v16 + 16), v20, v18);
    childName = v22;
    if ( !v23 )
      return v7;
  }
  else
  {
    if ( !v18 )
      return v7;
    v21 = 0;
    while ( *(_BYTE *)(v9 + 8 * v16 + v21 + 1) == v20[v21] )
    {
      if ( v17 >> 1 == ++v21 )
        return v7;
    }
  }
LABEL_36:
  LODWORD(v7) = -1;
  if ( v6 )
  {
    v24 = *((_QWORD *)this + 1);
    v25 = *(unsigned __int8 *)parentName;
    if ( (v25 & 1) != 0 )
    {
      v26 = *((_QWORD *)parentName + 1);
      v27 = (char *)*((_QWORD *)parentName + 2);
    }
    else
    {
      v26 = v25 >> 1;
      v27 = (char *)parentName + 1;
    }
    v28 = v41;
    v29 = v6 >> 4;
    n = *(unsigned __int8 *)childName;
    if ( (n & 1) != 0 )
    {
      na = *((_QWORD *)childName + 1);
      v30 = (char *)*((_QWORD *)childName + 2);
    }
    else
    {
      na = n >> 1;
      v30 = (char *)childName + 1;
    }
    v47 = v24 + 1;
    v7 = 0;
    v45 = v30;
    v48 = v27;
    while ( 1 )
    {
      v31 = 16 * v7;
      v32 = *(_BYTE *)(v24 + 24LL * *(_QWORD *)(v28 + 16 * v7));
      v33 = (unsigned __int64)v32 >> 1;
      if ( (v32 & 1) != 0 )
        v33 = *(_QWORD *)(v24 + 24LL * *(_QWORD *)(v28 + 16 * v7) + 8);
      if ( v33 == v26 )
      {
        if ( (v32 & 1) != 0 )
        {
          if ( !v26
            || (v35 = memcmp(*(const void **)(v24 + 24LL * *(_QWORD *)(v28 + 16 * v7) + 16), v27, v26),
                v29 = v46,
                v27 = v48,
                v28 = v41,
                v30 = v45,
                !v35) )
          {
LABEL_55:
            v36 = *(_BYTE *)(v24 + 24LL * *(_QWORD *)(v28 + v31 + 8));
            v37 = (unsigned __int64)v36 >> 1;
            if ( (v36 & 1) != 0 )
              v37 = *(_QWORD *)(v24 + 24LL * *(_QWORD *)(v28 + v31 + 8) + 8);
            if ( v37 == na )
            {
              if ( (v36 & 1) != 0 )
              {
                if ( !na )
                  return v7;
                v39 = memcmp(*(const void **)(v24 + 24LL * *(_QWORD *)(v28 + v31 + 8) + 16), v30, na);
                v29 = v46;
                v27 = v48;
                v28 = v41;
                v30 = v45;
                if ( !v39 )
                  return v7;
              }
              else
              {
                if ( !na )
                  return v7;
                v38 = 0;
                while ( *(_BYTE *)(v47 + 24LL * *(_QWORD *)(v28 + v31 + 8) + v38) == v30[v38] )
                {
                  if ( (unsigned __int64)*(unsigned __int8 *)(v24 + 24LL * *(_QWORD *)(v28 + v31 + 8)) >> 1 == ++v38 )
                    return v7;
                }
              }
            }
          }
        }
        else
        {
          if ( !v26 )
            goto LABEL_55;
          v34 = 0;
          while ( *(_BYTE *)(v47 + 24LL * *(_QWORD *)(v28 + 16 * v7) + v34) == v27[v34] )
          {
            if ( (unsigned __int64)*(unsigned __int8 *)(v24 + 24LL * *(_QWORD *)(v28 + 16 * v7)) >> 1 == ++v34 )
              goto LABEL_55;
          }
        }
      }
      if ( ++v7 >= v29 )
      {
        LODWORD(v7) = -1;
        return v7;
      }
    }
  }
  return v7;
}


// Address: 0x104e3a0 | Name: _ZN3RBX16KeyframeSequenceC2Ev
void __fastcall RBX::KeyframeSequence::KeyframeSequence(RBX::KeyframeSequence *this)
{
  void *v1[7]; // [rsp+0h] [rbp-38h] BYREF

  RBX::Instance::Instance(this);
  this->_vptr$EventSource = (int (**)(void))&off_288FC78;
  this->descriptor = Class_getDescriptorPtr(this);
  this->_vptr$EventSource = (int (**)(void))off_288F630;
  this->cacheData.__ptr_.__value_ = 0;
  *(_QWORD *)&this->priority = 0x100000002LL;
  this->applyZeroWeight = 1;
  this->authoredHipHeight = 2.0;
  BYTE1(v1[2]) = 0;
  WORD1(v1[2]) = 0;
  HIDWORD(v1[2]) = 0;
  strcpy((char *)v1, " KeyframeSequenc");
  RBX::Instance::setName(this, (const std::string *)v1);
  if ( ((__int64)v1[0] & 1) != 0 )
    operator delete(v1[2]);
}


// Address: 0x104e4c0 | Name: _ZN3RBX16KeyframeSequence24transferKeyframeSequenceEPS0_
void __fastcall RBX::KeyframeSequence::transferKeyframeSequence(
        RBX::KeyframeSequence *this,
        RBX::KeyframeSequence *other)
{
  bool loop; // al
  RBX::KeyframeSequence::Priority priority; // eax
  float authoredHipHeight; // xmm0_4
  RBX::KeyframeSequence::Cache *value; // rax
  RBX::KeyframeSequence::Cache *v6; // r14
  RBX::KeyframeSequence::Cache *v7; // r15
  RBX::Instance ***px; // rax
  boost::detail::sp_counted_base *pi; // r14
  RBX::Instance **v10; // rbx
  RBX::Instance **v11; // r12
  RBX::KeyframeSequence::Cache *v12; // r12

  if ( other->cacheData.__ptr_.__value_ )
    this->gotCacheData = 1;
  RBX::Instance::removeAllChildren(this);
  loop = other->loop;
  if ( this->loop != loop )
  {
    this->loop = loop;
    RBX::Instance::raisePropertyChanged(this, &stru_2A03790);
  }
  priority = other->priority;
  if ( this->priority != priority )
  {
    this->priority = priority;
    RBX::Instance::raisePropertyChanged(this, &stru_2A037E8);
  }
  if ( stru_2A035E8.value )
  {
    authoredHipHeight = other->authoredHipHeight;
    if ( this->authoredHipHeight != authoredHipHeight )
    {
      this->authoredHipHeight = authoredHipHeight;
      RBX::Instance::raisePropertyChanged(this, &stru_2A03850);
    }
  }
  if ( stru_2A035B8.value && this->allowFrozenCache )
  {
    value = other->cacheData.__ptr_.__value_;
    other->cacheData.__ptr_.__value_ = 0;
    v6 = this->cacheData.__ptr_.__value_;
    this->cacheData.__ptr_.__value_ = value;
    if ( v6 )
    {
      RBX::KeyframeSequence::Cache::~Cache(v6);
      operator delete(v6);
      value = this->cacheData.__ptr_.__value_;
    }
    if ( value )
      this->frozen = 1;
  }
  else
  {
    v7 = other->cacheData.__ptr_.__value_;
    other->cacheData.__ptr_.__value_ = 0;
    px = (RBX::Instance ***)other->children.object.px;
    pi = other->children.object.pn.pi_;
    if ( pi )
      _InterlockedAdd(&pi->use_count_, 1u);
    if ( px )
    {
      v10 = *px;
      v11 = px[1];
      if ( *px != v11 )
      {
        do
        {
          RBX::Instance::setParentInternal(*v10, this, 0);
          v10 += 2;
        }
        while ( v11 != v10 );
      }
    }
    v12 = this->cacheData.__ptr_.__value_;
    this->cacheData.__ptr_.__value_ = v7;
    if ( v12 )
    {
      RBX::KeyframeSequence::Cache::~Cache(v12);
      operator delete(v12);
    }
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
  }
}


// Address: 0x104e6e0 | Name: _ZNK3RBX16KeyframeSequence11askAddChildEPKNS_8InstanceE
bool __fastcall RBX::KeyframeSequence::askAddChild(const RBX::KeyframeSequence *this, const RBX::Instance *instance)
{
  bool result; // al
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  if ( !stru_2A035B8.value )
  {
    if ( !instance )
      return 0;
LABEL_6:
    descriptor = instance->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    return *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364);
  }
  result = 0;
  if ( instance && !this->frozen )
    goto LABEL_6;
  return result;
}


// Address: 0x104e730 | Name: _ZNK3RBX16KeyframeSequence13getCachedDataEv
const RBX::KeyframeSequence::Cache *__fastcall RBX::KeyframeSequence::getCachedData(const RBX::KeyframeSequence *this)
{
  const RBX::KeyframeSequence::Cache *result; // rax

  result = this->cacheData.__ptr_.__value_;
  if ( !result )
  {
    RBX::KeyframeSequence::updateCacheData(this);
    return this->cacheData.__ptr_.__value_;
  }
  return result;
}


// Address: 0x104e750 | Name: _ZNK3RBX16KeyframeSequence15updateCacheDataEv
void __fastcall RBX::KeyframeSequence::updateCacheData(const RBX::KeyframeSequence *this)
{
  unsigned int v1; // r14d
  char *v2; // r12
  RBX::KeyframeSequence::Cache *value; // rbx
  __int64 v4; // rbx
  __int64 v5; // rax
  __int64 v6; // rbp
  RBX::KeyframeSequence::CachedKeyframe *v7; // rbp
  RBX::KeyframeSequence::CachedKeyframe *i; // rbx
  boost::_bi::bind_t<void,boost::_mfi::cmf2<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,const boost::shared_ptr<RBX::Instance> &>,boost::_bi::list3<boost::_bi::value<const RBX::KeyframeSequence *>,boost::reference_wrapper<RBX::KeyframeSequence::Cache>,boost::arg<1> > > v9[2]; // [rsp+0h] [rbp-48h] BYREF

  v1 = RBX::Memory::setCurrentCategory(dword_2A03614);
  v2 = (char *)operator new(0x70u);
  *(_DWORD *)v2 = 0;
  *(_OWORD *)(v2 + 88) = 0;
  *((_QWORD *)v2 + 13) = 0;
  *(_OWORD *)(v2 + 56) = 0;
  *(_OWORD *)(v2 + 40) = 0;
  *(_OWORD *)(v2 + 24) = 0;
  *(_OWORD *)(v2 + 8) = 0;
  *((_QWORD *)v2 + 9) = 0;
  value = this->cacheData.__ptr_.__value_;
  this->cacheData.__ptr_.__value_ = (RBX::KeyframeSequence::Cache *)v2;
  if ( value )
  {
    RBX::KeyframeSequence::Cache::~Cache(value);
    operator delete(value);
    v2 = (char *)this->cacheData.__ptr_.__value_;
  }
  *((_QWORD *)v2 + 8) = *((_QWORD *)v2 + 7);
  *((_QWORD *)v2 + 5) = *((_QWORD *)v2 + 4);
  v4 = *((_QWORD *)v2 + 1);
  v5 = *((_QWORD *)v2 + 2);
  if ( v5 != v4 )
  {
    do
    {
      v6 = v5 - 24;
      if ( (*(_BYTE *)(v5 - 24) & 1) != 0 )
        operator delete(*(void **)(v5 - 8));
      v5 = v6;
    }
    while ( v4 != v6 );
  }
  *((_QWORD *)v2 + 2) = v4;
  v7 = (RBX::KeyframeSequence::CachedKeyframe *)*((_QWORD *)v2 + 11);
  for ( i = (RBX::KeyframeSequence::CachedKeyframe *)*((_QWORD *)v2 + 12);
        v7 != i;
        RBX::KeyframeSequence::CachedKeyframe::~CachedKeyframe(i) )
  {
    i = (RBX::KeyframeSequence::CachedKeyframe *)((char *)i - 104);
  }
  *((_QWORD *)v2 + 12) = v7;
  *(_DWORD *)v2 = 0;
  *((_QWORD *)v2 + 10) = 0;
  v9[0].f_ = (boost::_mfi::cmf2<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,const boost::shared_ptr<RBX::Instance> &>)(unsigned __int64)RBX::KeyframeSequence::cacheKeyframePass0;
  v9[0].l_.a1_.t_ = this;
  v9[0].l_.a2_.t_ = (RBX::KeyframeSequence::Cache *)v2;
  RBX::Instance::visitChildren<boost::_bi::bind_t<void,boost::_mfi::cmf2<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,boost::shared_ptr<RBX::Instance> const&>,boost::_bi::list3<boost::_bi::value<RBX::KeyframeSequence const*>,boost::reference_wrapper<RBX::KeyframeSequence::Cache>,boost::arg<1>>>>(
    this,
    v9);
  std::vector<RBX::CachedPose>::reserve((std::vector<RBX::CachedPose> *)(v2 + 56), *((_QWORD *)v2 + 10));
  v9[0].f_ = (boost::_mfi::cmf2<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,const boost::shared_ptr<RBX::Instance> &>)(unsigned __int64)RBX::KeyframeSequence::cacheKeyframePass1;
  v9[0].l_.a1_.t_ = this;
  v9[0].l_.a2_.t_ = (RBX::KeyframeSequence::Cache *)v2;
  RBX::Instance::visitChildren<boost::_bi::bind_t<void,boost::_mfi::cmf2<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,boost::shared_ptr<RBX::Instance> const&>,boost::_bi::list3<boost::_bi::value<RBX::KeyframeSequence const*>,boost::reference_wrapper<RBX::KeyframeSequence::Cache>,boost::arg<1>>>>(
    this,
    v9);
  std::__sort<std::__less<RBX::KeyframeSequence::CachedKeyframe,RBX::KeyframeSequence::CachedKeyframe> &,RBX::KeyframeSequence::CachedKeyframe*>(
    *((RBX::KeyframeSequence::CachedKeyframe **)v2 + 11),
    *((RBX::KeyframeSequence::CachedKeyframe **)v2 + 12),
    (std::__less<RBX::KeyframeSequence::CachedKeyframe,RBX::KeyframeSequence::CachedKeyframe> *)v9);
  RBX::Memory::setCurrentCategory(v1);
}


// Address: 0x104e910 | Name: _ZNK3RBX16KeyframeSequence13gotCachedDataEv
bool __fastcall RBX::KeyframeSequence::gotCachedData(const RBX::KeyframeSequence *this)
{
  return this->gotCacheData;
}


// Address: 0x104e920 | Name: _ZNK3RBX16KeyframeSequence11getDurationEv
float __fastcall RBX::KeyframeSequence::getDuration(const RBX::KeyframeSequence *this)
{
  float *value; // rax

  value = (float *)this->cacheData.__ptr_.__value_;
  if ( !value )
  {
    RBX::KeyframeSequence::updateCacheData(this);
    value = (float *)this->cacheData.__ptr_.__value_;
  }
  return *value;
}


// Address: 0x104e950 | Name: _ZNK3RBX16KeyframeSequence5applyERNSt3__16vectorINS_9JointDataENS1_9allocatorIS3_EEEERNS2_INS_10CachedPoseENS4_IS8_EEEEdff
void __fastcall RBX::KeyframeSequence::apply(
        const RBX::KeyframeSequence *this,
        std::vector<RBX::JointData> *joints,
        std::vector<RBX::CachedPose> *poses,
        double keyframetime,
        float trackweight,
        float rootTranslationScale)
{
  bool applyZeroWeight; // al
  bool v7; // al
  RBX::KeyframeSequence::Cache *value; // rcx
  __int64 v9; // rax
  __int64 v10; // rbp
  __int64 v11; // rbp
  float v12; // xmm0_4
  __int64 v13; // rbp
  __int64 v14; // r13
  unsigned __int64 v15; // rdx
  __int64 v16; // rdi
  __int64 v17; // r13
  __int64 v18; // r13
  __int64 v19; // r15
  unsigned __int64 i; // r14
  unsigned __int8 *v21; // rax
  unsigned __int64 v22; // rcx
  __int64 v23; // r12
  __int64 v24; // rax
  __int64 v25; // rdi
  const std::string *v26; // rbp
  const std::string *v27; // rax
  int Joint; // eax
  __int64 v29; // rcx
  _QWORD *v30; // rdi
  __int64 v31; // rbx
  unsigned __int64 v32; // r9
  _QWORD *v33; // rdi
  __int64 v34; // rbx
  bool v35; // zf
  __int64 v36; // rdi
  __int64 v37; // rbx
  unsigned __int64 v38; // rdi
  __int64 v39; // rcx
  unsigned __int64 v40; // rbp
  unsigned __int64 v41; // rbp
  __int64 v42; // rdi
  const RBX::CachedPose *v43; // rsi
  const RBX::CachedPose *v44; // rdx
  float v45; // xmm0_4
  float v46; // xmm1_4
  unsigned __int8 *v47; // rax
  unsigned __int64 v48; // rcx
  std::vector<RBX::CachedPose> *v49; // rbp
  __int64 v50; // rax
  __int128 v51; // xmm0
  float v52; // [rsp+Ch] [rbp-ACh]
  std::vector<RBX::JointData> *v53; // [rsp+18h] [rbp-A0h]
  RBX::KeyframeSequence::Cache *v54; // [rsp+20h] [rbp-98h]
  _QWORD *v56; // [rsp+38h] [rbp-80h]
  RBX::CachedPose p1; // [rsp+40h] [rbp-78h] BYREF
  std::vector<RBX::CachedPose> *v58; // [rsp+60h] [rbp-58h]
  RBX::CachedPose v59; // [rsp+68h] [rbp-50h] BYREF

  v58 = poses;
  v52 = trackweight;
  applyZeroWeight = this->applyZeroWeight;
  if ( trackweight <= 0.000001 )
  {
    if ( !applyZeroWeight )
      return;
    v7 = 0;
    v52 = 0.000001;
  }
  else
  {
    if ( applyZeroWeight )
      goto LABEL_7;
    v7 = 1;
  }
  this->applyZeroWeight = v7;
LABEL_7:
  value = this->cacheData.__ptr_.__value_;
  v53 = joints;
  if ( !value )
  {
    RBX::KeyframeSequence::updateCacheData(this);
    value = this->cacheData.__ptr_.__value_;
  }
  v9 = *((_QWORD *)value + 11);
  v54 = value;
  v10 = *((_QWORD *)value + 12);
  if ( v10 != v9 )
  {
    v11 = v10 - v9;
    if ( !v11 )
      goto LABEL_17;
    v13 = 0x4EC4EC4EC4EC4EC5LL * (v11 >> 3);
    v14 = *((_QWORD *)value + 11);
    v15 = v13;
    do
    {
      v15 = (__int64)(v13 + (v15 >> 63)) >> 1;
      v16 = 104 * v15;
      v12 = keyframetime;
      if ( *(float *)(v14 + 104 * v15) <= v12 )
      {
        v15 = v13 + ~v15;
        v14 += v16 + 104;
      }
      v13 = v15;
    }
    while ( v15 );
    v17 = v14 - v9;
    if ( v17 )
      v18 = 0x4EC4EC4EC4EC4EC5LL * (v17 >> 3) - 1;
    else
LABEL_17:
      v18 = 0;
    v19 = *(_QWORD *)joints;
    if ( *((_QWORD *)joints + 1) != *(_QWORD *)joints )
    {
      for ( i = 0; i < (__int64)(*((_QWORD *)joints + 1) - *(_QWORD *)joints) >> 5; ++i )
      {
        v23 = 32 * i;
        v24 = *(_QWORD *)(v19 + 32 * i + 8);
        if ( !v24 )
          goto LABEL_72;
        if ( !*(_DWORD *)(v24 + 8) )
          goto LABEL_72;
        v25 = *(_QWORD *)(v19 + v23 + 16);
        if ( !v25 )
          goto LABEL_72;
        v26 = (const std::string *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v25 + 8LL))(v25);
        v56 = (_QWORD *)(v19 + v23 + 16);
        v27 = (const std::string *)(*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v56 + 16LL))(*v56);
        Joint = RBX::KeyframeSequence::Cache::findJoint(v54, v26, v27, *(_DWORD *)(v19 + v23 + 24));
        joints = v53;
        if ( Joint < 0 )
          goto LABEL_72;
        *(_DWORD *)(v19 + v23 + 24) = Joint;
        v29 = *((_QWORD *)v54 + 11);
        if ( stru_2A035D0.value )
        {
          if ( v18 )
          {
            v30 = (_QWORD *)(v29 + 104 * v18 + 56);
            v31 = v18;
            v32 = v18 + 1;
            while ( *(_DWORD *)(*v30 + 4LL * Joint) == -1 )
            {
              v30 -= 13;
              if ( !--v31 )
              {
                v31 = 0;
                break;
              }
            }
          }
          else
          {
            v31 = 0;
            v32 = 1;
          }
          v35 = *(_DWORD *)(*(_QWORD *)(v29 + 104 * v31 + 56) + 4LL * Joint) == -1;
          v36 = v29 + 104 * v31;
          v37 = 0;
          if ( !v35 )
            v37 = v36;
        }
        else
        {
          if ( v18 )
          {
            v33 = (_QWORD *)(v29 + 104 * v18 + 32);
            v34 = v18;
            v32 = v18 + 1;
            while ( !*(_QWORD *)(*v33 + 8LL * Joint) )
            {
              v33 -= 13;
              if ( !--v34 )
              {
                v34 = 0;
                break;
              }
            }
          }
          else
          {
            v34 = 0;
            v32 = v18 + 1;
          }
          v37 = v29 + 104 * v34;
          if ( !*(_QWORD *)(*(_QWORD *)(v37 + 32) + 8LL * Joint) )
            v37 = 0;
        }
        v38 = 0x4EC4EC4EC4EC4EC5LL * ((*((_QWORD *)v54 + 12) - v29) >> 3);
        if ( stru_2A035D0.value )
        {
          if ( v38 <= v32 )
            goto LABEL_58;
          v39 = 104 * v32 + v29;
          v40 = v32;
          while ( *(_DWORD *)(*(_QWORD *)(v39 + 56) + 4LL * Joint) == -1 )
          {
            ++v40;
            v39 += 104;
            if ( v40 >= v38 )
              goto LABEL_58;
          }
        }
        else
        {
          if ( v38 <= v32 )
          {
LABEL_58:
            v39 = 0;
            goto LABEL_59;
          }
          v39 = 104 * v32 + v29;
          v41 = v32;
          while ( !*(_QWORD *)(*(_QWORD *)(v39 + 32) + 8LL * Joint) )
          {
            ++v41;
            v39 += 104;
            if ( v41 >= v38 )
              goto LABEL_58;
          }
        }
LABEL_59:
        if ( v37 )
        {
          if ( !v39 )
            v39 = v37;
          if ( stru_2A035D0.value )
          {
            v42 = *((_QWORD *)v54 + 7);
            v43 = (const RBX::CachedPose *)(v42 + 32LL * *(unsigned int *)(*(_QWORD *)(v37 + 56) + 4LL * Joint));
            v44 = (const RBX::CachedPose *)(v42 + 32LL * *(unsigned int *)(*(_QWORD *)(v39 + 56) + 4LL * Joint));
          }
          else
          {
            v43 = *(const RBX::CachedPose **)(*(_QWORD *)(v37 + 32) + 8LL * Joint);
            v44 = *(const RBX::CachedPose **)(*(_QWORD *)(v39 + 32) + 8LL * Joint);
          }
          v45 = *(float *)v39 - keyframetime;
          v46 = keyframetime - *(float *)v37;
          RBX::CachedPose::interpolatePoses(&p1, v43, v44, v45, v46);
          if ( !stru_2A035E8.value )
            goto LABEL_71;
          v47 = (unsigned __int8 *)(*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v56 + 8LL))(*v56);
          v48 = *v47;
          if ( (v48 & 1) != 0 )
          {
            if ( *((_QWORD *)v47 + 1) != 16 )
              goto LABEL_71;
LABEL_70:
            if ( !(unsigned int)std::string::compare(v47, 0, -1, "HumanoidRootPart", 16) )
            {
              v21 = (unsigned __int8 *)(*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v56 + 16LL))(*v56);
              v22 = *v21;
              if ( (v22 & 1) != 0 )
              {
                if ( *((_QWORD *)v21 + 1) != 10 )
                  goto LABEL_71;
              }
              else if ( v22 >> 1 != 10 )
              {
                goto LABEL_71;
              }
              if ( !(unsigned int)std::string::compare(v21, 0, -1, "LowerTorso", 10) )
              {
                p1.translation.x = p1.translation.x * rootTranslationScale;
                p1.translation.y = p1.translation.y * rootTranslationScale;
                p1.translation.z = p1.translation.z * rootTranslationScale;
              }
            }
          }
          else if ( v48 >> 1 == 16 )
          {
            goto LABEL_70;
          }
LABEL_71:
          p1.weight = p1.weight * v52;
          v49 = v58;
          RBX::CachedPose::blendPosesOver(&v59, (const RBX::CachedPose *)(v23 + *(_QWORD *)v58), &p1);
          v50 = *(_QWORD *)v49;
          v51 = *(_OWORD *)&v59.translation.x;
          *(_OWORD *)(v50 + v23 + 14) = *(_OWORD *)((char *)&v59.rotaxisangle.x + 2);
          *(_OWORD *)(v50 + 32 * i) = v51;
          joints = v53;
        }
LABEL_72:
        v19 = *(_QWORD *)joints;
      }
    }
  }
}


// Address: 0x104ee30 | Name: _ZN3RBX10CachedPose16interpolatePosesERKS0_S2_ff
RBX::CachedPose *__fastcall RBX::CachedPose::interpolatePoses(
        RBX::CachedPose *__return_ptr retstr,
        const RBX::CachedPose *p0,
        const RBX::CachedPose *p1,
        __m128 w0,
        float w1)
{
  __m128 v6; // xmm1
  float v7; // xmm2_4
  __int128 v8; // xmm0
  __int128 v9; // xmm1
  float v11; // [rsp+4h] [rbp-34h]
  float v12; // [rsp+8h] [rbp-30h]
  int v13; // [rsp+Ch] [rbp-2Ch]
  __m128 v14; // [rsp+10h] [rbp-28h]
  RBX::Vector3 v15; // 0:kr00_12.12

  if ( w0.m128_f32[0] <= 0.0 )
  {
    v8 = *(_OWORD *)&p1->translation.x;
    v9 = *(_OWORD *)&p1->rotaxisangle.y;
LABEL_6:
    *(_OWORD *)&retstr->rotaxisangle.y = v9;
    *(_OWORD *)&retstr->translation.x = v8;
    return retstr;
  }
  if ( w1 <= 0.0 )
  {
    v8 = *(_OWORD *)&p0->translation.x;
    v9 = *(_OWORD *)&p0->rotaxisangle.y;
    goto LABEL_6;
  }
  w0.m128_f32[0] = RBX::adjustBlendWeight(
                     w1 + w0.m128_f32[0],
                     (RBX::Pose::PoseEasingStyle)p0->easingStyle.data,
                     (RBX::Pose::PoseEasingDirection)p0->easingDirection.data);
  v6 = (__m128)0x3F800000u;
  v6.m128_f32[0] = 1.0 - w0.m128_f32[0];
  LOWORD(v13) = 0;
  v12 = (float)(p1->weight * (float)(1.0 - w0.m128_f32[0])) + (float)(p0->weight * w0.m128_f32[0]);
  v7 = p0->translation.z * w0.m128_f32[0];
  v14 = _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(v6, v6, 224), (__m128)*(unsigned __int64 *)&p1->translation.x),
          _mm_mul_ps(_mm_shuffle_ps(w0, w0, 224), (__m128)*(unsigned __int64 *)&p0->translation.x));
  v11 = (float)(p1->translation.z * (float)(1.0 - w0.m128_f32[0])) + v7;
  v15 = RBX::lerpAxisAngle(&p0->rotaxisangle, &p1->rotaxisangle, 1.0 - w0.m128_f32[0], v7);
  w0.m128_i32[0] = LODWORD(v15.x);
  w0.m128_i32[1] = LODWORD(v15.y);
  _mm_storel_ps((double *)&retstr->translation.x, v14);
  retstr->translation.z = v11;
  _mm_storel_ps((double *)&retstr->rotaxisangle.x, w0);
  retstr->rotaxisangle.z = v15.z;
  retstr->weight = v12;
  *(_DWORD *)&retstr->easingStyle.data = v13;
  return retstr;
}


// Address: 0x104ef50 | Name: _ZN3RBX10CachedPose14blendPosesOverERKS0_S2_
RBX::CachedPose *__fastcall RBX::CachedPose::blendPosesOver(
        RBX::CachedPose *__return_ptr retstr,
        const RBX::CachedPose *p0,
        const RBX::CachedPose *p1)
{
  float weight; // xmm2_4
  float v4; // xmm3_4
  __int128 v5; // xmm0
  __m128 v6; // xmm1
  float *p_weight; // rcx
  float v8; // xmm1_4
  __m128 v9; // xmm0
  float *v10; // rcx
  float v11; // ebp
  float v12; // xmm2_4
  int v14; // [rsp+0h] [rbp-38h] BYREF
  float v15; // [rsp+4h] [rbp-34h] BYREF
  float v16; // [rsp+8h] [rbp-30h]
  int v17; // [rsp+Ch] [rbp-2Ch] BYREF
  __m128 v18; // [rsp+10h] [rbp-28h]
  RBX::Vector3 v19; // 0:kr00_12.12

  weight = p0->weight;
  v4 = p1->weight;
  if ( weight == 0.0 && v4 <= 1.0 )
  {
    v5 = *(_OWORD *)&p1->translation.x;
    *(_OWORD *)&retstr->rotaxisangle.y = *(_OWORD *)&p1->rotaxisangle.y;
    *(_OWORD *)&retstr->translation.x = v5;
  }
  else
  {
    v14 = 0;
    v6 = (__m128)0x3F800000u;
    p_weight = (float *)&v14;
    if ( (float)(1.0 - v4) > 0.0 )
      p_weight = &v15;
    v15 = 1.0 - v4;
    if ( weight <= *p_weight )
      p_weight = &p0->weight;
    v9 = (__m128)*(unsigned int *)p_weight;
    v8 = 1.0 / (float)(v4 + v9.m128_f32[0]);
    v9.m128_f32[0] = v9.m128_f32[0] * v8;
    v6.m128_f32[0] = v8 * v4;
    LOWORD(v14) = 0;
    v15 = weight + v4;
    v10 = (float *)&v17;
    if ( (float)(weight + v4) <= 1.0 )
      v10 = &v15;
    v17 = 1065353216;
    v11 = *v10;
    v12 = p0->translation.z * v9.m128_f32[0];
    v18 = _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v6, v6, 224), (__m128)*(unsigned __int64 *)&p1->translation.x),
            _mm_mul_ps(_mm_shuffle_ps(v9, v9, 224), (__m128)*(unsigned __int64 *)&p0->translation.x));
    v16 = (float)(p1->translation.z * v6.m128_f32[0]) + v12;
    v19 = RBX::lerpAxisAngle(&p0->rotaxisangle, &p1->rotaxisangle, v6.m128_f32[0], v12);
    v9.m128_i32[0] = LODWORD(v19.x);
    v9.m128_i32[1] = LODWORD(v19.y);
    _mm_storel_ps((double *)&retstr->translation.x, v18);
    retstr->translation.z = v16;
    _mm_storel_ps((double *)&retstr->rotaxisangle.x, v9);
    retstr->rotaxisangle.z = v19.z;
    retstr->weight = v11;
    *(_DWORD *)&retstr->easingStyle.data = v14;
  }
  return retstr;
}


// Address: 0x104f090 | Name: _ZN3RBX16KeyframeSequence12onChildAddedEPNS_8InstanceE
void __fastcall RBX::KeyframeSequence::onChildAdded(RBX::KeyframeSequence *this, RBX::Instance *child)
{
  RBX::KeyframeSequence::Cache *value; // rbx

  value = this->cacheData.__ptr_.__value_;
  if ( value )
  {
    this->cacheData.__ptr_.__value_ = 0;
    RBX::KeyframeSequence::Cache::~Cache(value);
    operator delete(value);
  }
}


// Address: 0x104f0c0 | Name: _ZN3RBX16KeyframeSequence15invalidateCacheEv
void __fastcall RBX::KeyframeSequence::invalidateCache(RBX::KeyframeSequence *this)
{
  RBX::KeyframeSequence::Cache *value; // rbx

  value = this->cacheData.__ptr_.__value_;
  if ( value )
  {
    this->cacheData.__ptr_.__value_ = 0;
    RBX::KeyframeSequence::Cache::~Cache(value);
    operator delete(value);
  }
}


// Address: 0x104f0f0 | Name: _ZN3RBX16KeyframeSequence15onChildRemovingEPNS_8InstanceE
void __fastcall RBX::KeyframeSequence::onChildRemoving(RBX::KeyframeSequence *this, RBX::Instance *child)
{
  RBX::KeyframeSequence::Cache *value; // rbx
  std::runtime_error *exception; // rbx

  if ( stru_2A035B8.value && this->frozen )
  {
    exception = (std::runtime_error *)__cxa_allocate_exception(0x10u);
    std::runtime_error::runtime_error(exception, "Trying to modify a frozen keyframe sequence");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  value = this->cacheData.__ptr_.__value_;
  if ( value )
  {
    this->cacheData.__ptr_.__value_ = 0;
    RBX::KeyframeSequence::Cache::~Cache(value);
    operator delete(value);
  }
}


// Address: 0x104f190 | Name: _ZN3RBX16KeyframeSequence19setAllowFrozenCacheEb
void __fastcall RBX::KeyframeSequence::setAllowFrozenCache(RBX::KeyframeSequence *this, bool value)
{
  this->allowFrozenCache = value;
}


// Address: 0x104f1a0 | Name: _ZN3RBX15isContainerPoseEPNS_4PoseE
bool __fastcall RBX::isContainerPose(RBX::Pose *pose)
{
  RBX::Instance *parent; // rax
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool v4; // cl

  parent = pose->parent;
  if ( parent )
  {
    descriptor = parent->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    v4 = *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364);
  }
  else
  {
    v4 = 1;
  }
  return v4 || pose->weight <= 0.000001;
}


// Address: 0x104f200 | Name: _ZNK3RBX16KeyframeSequence15AppendPosePass0ERNS0_5CacheERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::KeyframeSequence::AppendPosePass0(
        const RBX::KeyframeSequence *this,
        RBX::KeyframeSequence::Cache *cache,
        const boost::shared_ptr<RBX::Instance> *child)
{
  boost::shared_ptr<RBX::Instance>::element_type *px; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::Instance *parent; // rax
  const RBX::Reflection::ClassDescriptor *v8; // r15
  RBX::Reflection::ClassDescriptor *v9; // rax
  size_t v10; // rbx
  size_t v11; // rax
  std::pair<unsigned long,unsigned long> *v12; // rsi
  std::pair<unsigned long,unsigned long> *v13; // rcx
  unsigned __int64 v14; // rdx
  unsigned __int64 *p_second; // rsi
  unsigned __int64 v16; // rdi
  std::pair<unsigned long,unsigned long> v17; // [rsp+0h] [rbp-58h] BYREF
  _BYTE v18[16]; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]
  _BYTE v20[16]; // [rsp+28h] [rbp-30h] BYREF
  void *v21; // [rsp+38h] [rbp-20h]

  px = child->px;
  if ( !child->px )
    return;
  descriptor = px->descriptor;
  DescriptorPtr = Class_getDescriptorPtr(0);
  if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364) )
    return;
  parent = px->parent;
  if ( !parent )
    return;
  v8 = parent->descriptor;
  v9 = Class_getDescriptorPtr(0);
  if ( *((unsigned __int16 *)v8 + 363) - (unsigned int)*((unsigned __int16 *)v9 + 363) > *((unsigned __int16 *)v9 + 364)
    || *(float *)&px[1].guid.scope.peerId.peerId <= 0.000001 )
  {
    return;
  }
  std::string::basic_string(v20, px->parent->name.h.h);
  std::string::basic_string(v18, px->name.h.h);
  v10 = RBX::findOrAdd<std::string>((RBX::KeyframeSequence::Cache *)((char *)cache + 8), (const std::string *)v20);
  v11 = RBX::findOrAdd<std::string>((RBX::KeyframeSequence::Cache *)((char *)cache + 8), (const std::string *)v18);
  v17.first = v10;
  v17.second = v11;
  v12 = (std::pair<unsigned long,unsigned long> *)*((_QWORD *)cache + 4);
  v13 = (std::pair<unsigned long,unsigned long> *)*((_QWORD *)cache + 5);
  v14 = v13 - v12;
  if ( v13 != v12 )
  {
    p_second = &v12->second;
    v16 = 0;
    do
    {
      if ( *(p_second - 1) == v10 && *p_second == v11 )
        break;
      ++v16;
      p_second += 2;
    }
    while ( v16 < v14 );
    if ( v16 != v14 )
      goto LABEL_17;
    goto LABEL_12;
  }
  if ( !v14 )
  {
LABEL_12:
    if ( *((std::pair<unsigned long,unsigned long> **)cache + 6) == v13 )
    {
      std::vector<std::pair<unsigned long,unsigned long>>::__push_back_slow_path<std::pair<unsigned long,unsigned long> const&>(
        (RBX::KeyframeSequence::Cache *)((char *)cache + 32),
        &v17);
    }
    else
    {
      *v13 = v17;
      *((_QWORD *)cache + 5) += 16LL;
    }
  }
LABEL_17:
  ++*((_QWORD *)cache + 10);
  if ( (v18[0] & 1) != 0 )
    operator delete(ptr);
  if ( (v20[0] & 1) != 0 )
    operator delete(v21);
}


// Address: 0x104f3d0 | Name: _ZNK3RBX16KeyframeSequence15AppendPosePass1ERNS0_5CacheERKN5boost10shared_ptrINS_8InstanceEEEPNS0_14CachedKeyframeE
void __fastcall RBX::KeyframeSequence::AppendPosePass1(
        const RBX::KeyframeSequence *this,
        RBX::KeyframeSequence::Cache *cache,
        const boost::shared_ptr<RBX::Instance> *child,
        RBX::KeyframeSequence::CachedKeyframe *keyframe)
{
  boost::shared_ptr<RBX::Instance>::element_type *px; // r13
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::Instance *parent; // rax
  const RBX::Reflection::ClassDescriptor *v10; // rbx
  RBX::Reflection::ClassDescriptor *v11; // rax
  size_t v12; // rbp
  size_t v13; // rax
  std::pair<unsigned long,unsigned long> *v14; // rsi
  std::pair<unsigned long,unsigned long> *v15; // rcx
  unsigned __int64 v16; // rdx
  unsigned __int64 *p_second; // rsi
  unsigned __int64 v18; // rbx
  float v19; // xmm0_4
  _OWORD *v20; // rax
  __int128 v21; // xmm0
  std::pair<unsigned long,unsigned long> __x; // [rsp+8h] [rbp-A0h] BYREF
  unsigned int rfRadians; // [rsp+1Ch] [rbp-8Ch] BYREF
  RBX::CachedPose v24; // [rsp+20h] [rbp-88h] BYREF
  _BYTE v25[16]; // [rsp+48h] [rbp-60h] BYREF
  void *ptr; // [rsp+58h] [rbp-50h]
  _BYTE v27[16]; // [rsp+60h] [rbp-48h] BYREF
  void *v28; // [rsp+70h] [rbp-38h]

  px = child->px;
  if ( child->px )
  {
    descriptor = px->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      memset(&v24, 0, 30);
      parent = px->parent;
      if ( parent )
      {
        v10 = parent->descriptor;
        v11 = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)v10 + 363) - (unsigned int)*((unsigned __int16 *)v11 + 363) <= *((unsigned __int16 *)v11
                                                                                                  + 364)
          && *(float *)&px[1].guid.scope.peerId.peerId > 0.000001 )
        {
          std::string::basic_string(v27, px->parent->name.h.h);
          std::string::basic_string(v25, px->name.h.h);
          v12 = RBX::findOrAdd<std::string>(
                  (RBX::KeyframeSequence::Cache *)((char *)cache + 8),
                  (const std::string *)v27);
          v13 = RBX::findOrAdd<std::string>(
                  (RBX::KeyframeSequence::Cache *)((char *)cache + 8),
                  (const std::string *)v25);
          __x.first = v12;
          __x.second = v13;
          v14 = (std::pair<unsigned long,unsigned long> *)*((_QWORD *)cache + 4);
          v15 = (std::pair<unsigned long,unsigned long> *)*((_QWORD *)cache + 5);
          v16 = v15 - v14;
          if ( v15 == v14 )
          {
            v18 = 0;
            if ( v16 )
              goto LABEL_17;
          }
          else
          {
            p_second = &v14->second;
            v18 = 0;
            do
            {
              if ( *(p_second - 1) == v12 && *p_second == v13 )
                break;
              ++v18;
              p_second += 2;
            }
            while ( v18 < v16 );
            if ( v18 != v16 )
            {
LABEL_17:
              v24.weight = fminf(1.0, fmaxf(0.0, *(float *)&px[1].guid.scope.peerId.peerId));
              v24.translation = *(RBX::Vector3 *)((char *)&px[1].xmlId.px + 4);
              __x.first = 0;
              LODWORD(__x.second) = 0;
              G3D::Matrix3::toAxisAngle((const G3D::Matrix3 *)&px[1], (G3D::Vector3 *)&__x, (float *)&rfRadians);
              v19 = *(float *)&rfRadians * *(float *)&__x.second;
              _mm_storel_ps(
                (double *)&v24.rotaxisangle.x,
                _mm_mul_ps(_mm_shuffle_ps((__m128)rfRadians, (__m128)rfRadians, 224), (__m128)__x.first));
              v24.rotaxisangle.z = v19;
              v24.easingStyle.data = px[1].guid.index;
              v24.easingDirection.data = px[1].archivable;
              v20 = (_OWORD *)*((_QWORD *)cache + 8);
              if ( v20 == *((_OWORD **)cache + 9) )
              {
                std::vector<RBX::CachedPose>::__push_back_slow_path<RBX::CachedPose const&>(
                  (RBX::KeyframeSequence::Cache *)((char *)cache + 56),
                  &v24);
                if ( !stru_2A035D0.value )
                  goto LABEL_26;
              }
              else
              {
                v21 = *(_OWORD *)&v24.translation.x;
                v20[1] = *(_OWORD *)&v24.rotaxisangle.y;
                *v20 = v21;
                *((_QWORD *)cache + 8) += 32LL;
                if ( !stru_2A035D0.value )
                {
LABEL_26:
                  *(_QWORD *)(*((_QWORD *)keyframe + 4) + 8 * v18) = *((_QWORD *)cache + 8) - 32LL;
                  if ( (v25[0] & 1) == 0 )
                  {
LABEL_23:
                    if ( (v27[0] & 1) != 0 )
                      operator delete(v28);
                    return;
                  }
LABEL_22:
                  operator delete(ptr);
                  goto LABEL_23;
                }
              }
              *(_DWORD *)(*((_QWORD *)keyframe + 7) + 4 * v18) = ((*((_QWORD *)cache + 8) - *((_QWORD *)cache + 7)) >> 5)
                                                               - 1;
              if ( (v25[0] & 1) == 0 )
                goto LABEL_23;
              goto LABEL_22;
            }
          }
          if ( *((std::pair<unsigned long,unsigned long> **)cache + 6) == v15 )
          {
            std::vector<std::pair<unsigned long,unsigned long>>::__push_back_slow_path<std::pair<unsigned long,unsigned long> const&>(
              (RBX::KeyframeSequence::Cache *)((char *)cache + 32),
              &__x);
          }
          else
          {
            *v15 = __x;
            *((_QWORD *)cache + 5) += 16LL;
          }
          goto LABEL_17;
        }
      }
    }
  }
}


// Address: 0x104f6c0 | Name: _ZN3RBX10CachedPose9setCFrameERKN3G3D15CoordinateFrameE
void __fastcall RBX::CachedPose::setCFrame(RBX::CachedPose *this, const RBX::CoordinateFrame *cframe)
{
  float v2; // xmm0_4
  unsigned int rfRadians; // [rsp+Ch] [rbp-1Ch] BYREF
  G3D::Vector3 rkAxis; // [rsp+10h] [rbp-18h] BYREF

  this->translation = cframe->translation;
  *(_QWORD *)&rkAxis.x = 0;
  rkAxis.z = 0.0;
  G3D::Matrix3::toAxisAngle(&cframe->rotation, &rkAxis, (float *)&rfRadians);
  v2 = *(float *)&rfRadians * rkAxis.z;
  _mm_storel_ps(
    (double *)&this->rotaxisangle.x,
    _mm_mul_ps(_mm_shuffle_ps((__m128)rfRadians, (__m128)rfRadians, 224), (__m128)*(unsigned __int64 *)&rkAxis.x));
  this->rotaxisangle.z = v2;
}


// Address: 0x104f730 | Name: _ZNK3RBX16KeyframeSequence18cacheKeyframePass0ERNS0_5CacheERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::KeyframeSequence::cacheKeyframePass0(
        const RBX::KeyframeSequence *this,
        RBX::KeyframeSequence::Cache *cache,
        const boost::shared_ptr<RBX::Instance> *child)
{
  boost::shared_ptr<RBX::Instance>::element_type *px; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r12
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::KeyframeSequence::Cache *v6; // rax
  boost::_bi::bind_t<void,boost::_mfi::cmf2<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,const boost::shared_ptr<RBX::Instance> &>,boost::_bi::list3<boost::_bi::value<const RBX::KeyframeSequence *>,boost::reference_wrapper<RBX::KeyframeSequence::Cache>,boost::arg<1> > > v7[2]; // [rsp+0h] [rbp-48h] BYREF

  px = child->px;
  if ( child->px )
  {
    descriptor = px->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      LODWORD(v7[0].f_.f_) = px[1]._vptr$EventSource;
      v6 = (RBX::KeyframeSequence::Cache *)v7;
      if ( *(float *)&v7[0].f_.f_ <= *(float *)cache )
        v6 = cache;
      *(_DWORD *)cache = *(_DWORD *)v6;
      v7[0].f_ = (boost::_mfi::cmf2<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,const boost::shared_ptr<RBX::Instance> &>)(unsigned __int64)RBX::KeyframeSequence::AppendPosePass0;
      v7[0].l_.a1_.t_ = this;
      v7[0].l_.a2_.t_ = cache;
      RBX::Instance::visitDescendants<boost::_bi::bind_t<void,boost::_mfi::cmf2<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,boost::shared_ptr<RBX::Instance> const&>,boost::_bi::list3<boost::_bi::value<RBX::KeyframeSequence const*>,boost::reference_wrapper<RBX::KeyframeSequence::Cache>,boost::arg<1>>>>(
        px,
        v7);
    }
  }
}


// Address: 0x104f7c0 | Name: _ZNK3RBX16KeyframeSequence18cacheKeyframePass1ERNS0_5CacheERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::KeyframeSequence::cacheKeyframePass1(
        const RBX::KeyframeSequence *this,
        RBX::KeyframeSequence::Cache *cache,
        const boost::shared_ptr<RBX::Instance> *child)
{
  boost::shared_ptr<RBX::Instance>::element_type *px; // r13
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  size_t v6; // r8
  const void *v7; // r9
  int v8; // edx
  void *v9; // rcx
  unsigned __int64 v10; // rax
  unsigned __int64 v11; // rdx
  unsigned __int64 v12; // rax
  unsigned __int64 v13; // rdx
  RBX::KeyframeSequence::CachedKeyframe *v14; // rdi
  void *v15; // r14
  __int64 v16; // rbx
  void *v17; // r15
  void *v18; // rdi
  int v19; // [rsp+8h] [rbp-C0h] BYREF
  __int128 v20; // [rsp+10h] [rbp-B8h] BYREF
  void *v21[2]; // [rsp+20h] [rbp-A8h] BYREF
  __int128 v22; // [rsp+30h] [rbp-98h]
  void *v23[2]; // [rsp+40h] [rbp-88h] BYREF
  void *ptr[2]; // [rsp+50h] [rbp-78h]
  __int128 v25; // [rsp+60h] [rbp-68h]
  boost::_bi::bind_t<void,boost::_mfi::cmf3<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,const boost::shared_ptr<RBX::Instance> &,RBX::KeyframeSequence::CachedKeyframe *>,boost::_bi::list4<boost::_bi::value<const RBX::KeyframeSequence *>,boost::reference_wrapper<RBX::KeyframeSequence::Cache>,boost::arg<1>,boost::_bi::value<RBX::KeyframeSequence::CachedKeyframe *> > > __x[2]; // [rsp+70h] [rbp-58h] BYREF

  px = child->px;
  if ( child->px )
  {
    descriptor = px->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    v8 = *((unsigned __int16 *)DescriptorPtr + 363);
    v9 = (void *)((unsigned int)*((unsigned __int16 *)descriptor + 363) - v8);
    if ( (unsigned int)v9 <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      v25 = 0;
      *(_OWORD *)ptr = 0;
      *(_OWORD *)v23 = 0;
      v22 = 0;
      *(_OWORD *)v21 = 0;
      v20 = 0;
      v19 = (int)px[1]._vptr$EventSource;
      std::string::operator=((soap *)&v20, (int)px->name.h.h, v8, v9, v6, v7);
      if ( stru_2A035D0.value )
      {
        v10 = (__int64)(*((_QWORD *)cache + 5) - *((_QWORD *)cache + 4)) >> 4;
        LODWORD(__x[0].f_.f_) = -1;
        v11 = ((char *)v23[1] - (char *)v23[0]) >> 2;
        if ( v10 <= v11 )
        {
          if ( v10 < v11 )
            v23[1] = (char *)v23[0] + 4 * v10;
        }
        else
        {
          std::vector<unsigned int>::__append(
            (std::vector<unsigned int> *)v23,
            v10 - v11,
            (std::vector<unsigned int>::const_reference)__x);
        }
      }
      else
      {
        v12 = (__int64)(*((_QWORD *)cache + 5) - *((_QWORD *)cache + 4)) >> 4;
        v13 = (__int64)(v22 - (unsigned __int64)v21[1]) >> 3;
        if ( v12 <= v13 )
        {
          if ( v12 < v13 )
            *(_QWORD *)&v22 = (char *)v21[1] + 8 * v12;
        }
        else
        {
          std::vector<RBX::CachedPose *>::__append((std::vector<RBX::CachedPose *> *)&v21[1], v12 - v13);
        }
      }
      __x[0].f_ = (boost::_mfi::cmf3<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,const boost::shared_ptr<RBX::Instance> &,RBX::KeyframeSequence::CachedKeyframe *>)(unsigned __int64)RBX::KeyframeSequence::AppendPosePass1;
      __x[0].l_.a1_.t_ = this;
      __x[0].l_.a2_.t_ = cache;
      __x[0].l_.a4_.t_ = (RBX::KeyframeSequence::CachedKeyframe *)&v19;
      RBX::Instance::visitDescendants<boost::_bi::bind_t<void,boost::_mfi::cmf3<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,boost::shared_ptr<RBX::Instance> const&,RBX::KeyframeSequence::CachedKeyframe *>,boost::_bi::list4<boost::_bi::value<RBX::KeyframeSequence const*>,boost::reference_wrapper<RBX::KeyframeSequence::Cache>,boost::arg<1>,boost::_bi::value<RBX::KeyframeSequence::CachedKeyframe *>>>>(
        px,
        __x);
      if ( stru_2A03600.value )
      {
        __x[0].f_ = (boost::_mfi::cmf3<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,const boost::shared_ptr<RBX::Instance> &,RBX::KeyframeSequence::CachedKeyframe *>)(unsigned __int64)RBX::KeyframeSequence::cacheMarkerPass;
        __x[0].l_.a1_.t_ = this;
        __x[0].l_.a2_.t_ = cache;
        __x[0].l_.a4_.t_ = (RBX::KeyframeSequence::CachedKeyframe *)&v19;
        RBX::Instance::visitChildren<boost::_bi::bind_t<void,boost::_mfi::cmf3<void,RBX::KeyframeSequence,RBX::KeyframeSequence::Cache &,boost::shared_ptr<RBX::Instance> const&,RBX::KeyframeSequence::CachedKeyframe *>,boost::_bi::list4<boost::_bi::value<RBX::KeyframeSequence const*>,boost::reference_wrapper<RBX::KeyframeSequence::Cache>,boost::arg<1>,boost::_bi::value<RBX::KeyframeSequence::CachedKeyframe *>>>>(
          px,
          __x);
      }
      v14 = (RBX::KeyframeSequence::CachedKeyframe *)*((_QWORD *)cache + 12);
      if ( v14 == *((RBX::KeyframeSequence::CachedKeyframe **)cache + 13) )
      {
        std::vector<RBX::KeyframeSequence::CachedKeyframe>::__push_back_slow_path<RBX::KeyframeSequence::CachedKeyframe const&>(
          (RBX::KeyframeSequence::Cache *)((char *)cache + 88),
          (const RBX::KeyframeSequence::CachedKeyframe *)&v19);
      }
      else
      {
        RBX::KeyframeSequence::CachedKeyframe::CachedKeyframe(v14, (const RBX::KeyframeSequence::CachedKeyframe *)&v19);
        *((_QWORD *)cache + 12) += 104LL;
      }
      v15 = ptr[1];
      if ( ptr[1] )
      {
        v16 = v25;
        if ( (void *)v25 == ptr[1] )
        {
          v18 = ptr[1];
        }
        else
        {
          do
          {
            if ( (*(_BYTE *)(v16 - 24) & 1) != 0 )
              operator delete(*(void **)(v16 - 8));
            v17 = (void *)(v16 - 48);
            if ( (*(_BYTE *)(v16 - 48) & 1) != 0 )
              operator delete(*(void **)(v16 - 32));
            v16 -= 48;
          }
          while ( v15 != v17 );
          v18 = ptr[1];
        }
        *(_QWORD *)&v25 = v15;
        operator delete(v18);
      }
      if ( v23[0] )
      {
        v23[1] = v23[0];
        operator delete(v23[0]);
      }
      if ( v21[1] )
      {
        *(void **)&v22 = v21[1];
        operator delete(v21[1]);
      }
      if ( (v20 & 1) != 0 )
        operator delete(v21[0]);
    }
  }
}


// Address: 0x104fae0 | Name: _ZNK3RBX16KeyframeSequence15cacheMarkerPassERNS0_5CacheERKN5boost10shared_ptrINS_8InstanceEEEPNS0_14CachedKeyframeE
void __fastcall RBX::KeyframeSequence::cacheMarkerPass(
        const RBX::KeyframeSequence *this,
        RBX::KeyframeSequence::Cache *cache,
        const boost::shared_ptr<RBX::Instance> *child,
        RBX::KeyframeSequence::CachedKeyframe *keyframe)
{
  boost::shared_ptr<RBX::Instance>::element_type *px; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *h; // r15
  unsigned __int64 v9; // rax
  __int128 v10; // [rsp+0h] [rbp-68h] BYREF
  void *ptr; // [rsp+10h] [rbp-58h]
  __int128 v12; // [rsp+20h] [rbp-48h] BYREF
  void *v13; // [rsp+30h] [rbp-38h]
  __int128 v14; // [rsp+38h] [rbp-30h]
  void *v15; // [rsp+48h] [rbp-20h]

  px = child->px;
  if ( child->px )
  {
    descriptor = px->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      h = px->name.h.h;
      std::string::basic_string(&v10, &px[1]);
      std::string::basic_string(&v12, h);
      v15 = ptr;
      v14 = v10;
      v10 = 0;
      ptr = 0;
      v9 = *((_QWORD *)keyframe + 11);
      if ( v9 >= *((_QWORD *)keyframe + 12) )
      {
        std::vector<std::pair<std::string,std::string>>::__push_back_slow_path<std::pair<std::string,std::string>>(
          (RBX::KeyframeSequence::CachedKeyframe *)((char *)keyframe + 80),
          (std::pair<std::string,std::string > *)&v12);
        if ( (v14 & 1) != 0 )
        {
          operator delete(v15);
          if ( (v12 & 1) != 0 )
            goto LABEL_12;
        }
        else if ( (v12 & 1) != 0 )
        {
          goto LABEL_12;
        }
      }
      else
      {
        *(_QWORD *)(v9 + 16) = v13;
        *(_OWORD *)v9 = v12;
        v12 = 0;
        v13 = 0;
        *(_QWORD *)(v9 + 40) = v15;
        *(_OWORD *)(v9 + 24) = v14;
        v14 = 0;
        v15 = 0;
        *((_QWORD *)keyframe + 11) += 48LL;
        if ( (v12 & 1) != 0 )
        {
LABEL_12:
          operator delete(v13);
          if ( (v10 & 1) == 0 )
            return;
LABEL_9:
          operator delete(ptr);
          return;
        }
      }
      if ( (v10 & 1) == 0 )
        return;
      goto LABEL_9;
    }
  }
}


// Address: 0x104fe00 | Name: _ZNK3RBX10CachedPose9getCFrameEv
RBX::CoordinateFrame *__fastcall RBX::CachedPose::getCFrame(
        RBX::CoordinateFrame *__return_ptr retstr,
        const RBX::CachedPose *this)
{
  float v2; // xmm1_4
  float v3; // xmm0_4
  __int128 v4; // xmm0
  G3D::Vector3 rotaxisangle; // [rsp+8h] [rbp-50h] BYREF
  G3D::Matrix3 v7; // [rsp+18h] [rbp-40h] BYREF

  rotaxisangle = this->rotaxisangle;
  v3 = G3D::Vector3::unitize(&rotaxisangle, v2);
  G3D::Matrix3::fromAxisAngleFast(&v7, &rotaxisangle, v3);
  retstr->rotation.elt[2][2] = v7.elt[2][2];
  v4 = *(_OWORD *)&v7.elt[0][0];
  *(_OWORD *)&retstr->rotation.elt[1][1] = *(_OWORD *)&v7.elt[1][1];
  *(_OWORD *)&retstr->rotation.elt[0][0] = v4;
  retstr->translation = this->translation;
  return retstr;
}


// Address: 0x104fe80 | Name: _ZN3RBX13lerpAxisAngleERKN3G3D7Vector3ES3_ff
__m128 __fastcall RBX::lerpAxisAngle(const RBX::Vector3 *r0, const RBX::Vector3 *r1, __m128 a3, __m128 w0, float w1)
{
  __m128 v5; // xmm3
  __m128 v6; // xmm8
  __m128 v7; // xmm4
  __m128 z_low; // xmm7
  __m128 v9; // xmm2
  float v10; // xmm4_4
  __m128 v11; // xmm5
  __m128 v12; // xmm6
  __m128 v13; // xmm6
  __m128 v14; // xmm5
  __m128 v15; // xmm5
  float v16; // xmm6_4
  __m128 v17; // xmm3
  __m128d v18; // xmm0
  double v19; // xmm2_8
  __int128 v20; // xmm0
  __m128 v21; // xmm4
  float v22; // xmm7_4
  __m128 v23; // xmm2
  __m128 v24; // xmm1
  __m128 v25; // xmm4
  __m128 v26; // xmm4
  float v27; // xmm0_4
  float v28; // xmm0_4
  __m128 v29; // xmm1
  double v31; // [rsp+8h] [rbp-40h]
  float v32; // [rsp+10h] [rbp-38h]

  v5 = (__m128)*(unsigned __int64 *)&r0->x;
  v6 = (__m128)*(unsigned __int64 *)&r1->x;
  v7 = _mm_mul_ps(v5, v6);
  z_low = (__m128)LODWORD(r0->z);
  v9 = (__m128)LODWORD(r1->z);
  v10 = (float)(r0->z * v9.m128_f32[0]) + (float)(_mm_shuffle_ps(v7, v7, 229).m128_f32[0] + v7.m128_f32[0]);
  if ( v10 >= 0.0 )
    return _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(w0, w0, 224), v6), _mm_mul_ps(_mm_shuffle_ps(a3, a3, 224), v5));
  v11 = _mm_unpacklo_ps(v5, v6);
  v12 = _mm_shuffle_ps(_mm_shuffle_ps(v6, v5, 17), v5, 226);
  v13 = _mm_add_ps(_mm_mul_ps(v12, v12), _mm_mul_ps(v11, v11));
  v14 = _mm_unpacklo_ps(z_low, v9);
  v15 = _mm_sqrt_ps(_mm_add_ps(_mm_mul_ps(v14, v14), v13));
  v16 = _mm_shuffle_ps(v15, v15, 229).m128_f32[0];
  if ( v16 > v15.m128_f32[0] )
  {
    v17 = 0;
    if ( v16 != 0.0 )
    {
      v32 = a3.m128_f32[0];
      v18 = 0;
      v31 = fabs(v16);
      v18.m128d_f64[0] = G3D::inf();
      v19 = (v31 + 1.0) * 0.000009999999747378752;
      v18.m128d_f64[0] = _mm_cmpeq_sd(v18, (__m128d)COERCE_UNSIGNED_INT64(v31 + 1.0)).m128d_f64[0];
      v17 = 0;
      if ( COERCE_DOUBLE(*(_QWORD *)&v18.m128d_f64[0] & 0x3EE4F8B580000000LL | ~*(_QWORD *)&v18.m128d_f64[0]
                                                                             & *(_QWORD *)&v19) < v31 )
      {
        *((_QWORD *)&v20 + 1) = w0.m128_u64[1];
        *(_QWORD *)&v20 = (unsigned __int64)RBX::lerpAxisAngle(r1, r0, v32, *(float *)&v19);
        return (__m128)v20;
      }
    }
    return v17;
  }
  if ( (float)(v15.m128_f32[0] - (float)(v10 / v15.m128_f32[0])) <= 3.1415927 )
    return _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(w0, w0, 224), v6), _mm_mul_ps(_mm_shuffle_ps(a3, a3, 224), v5));
  v21 = (__m128)0xC0C90FDB;
  v21.m128_f32[0] = (float)(v15.m128_f32[0] + -6.2831855) / v15.m128_f32[0];
  v22 = z_low.m128_f32[0] * v21.m128_f32[0];
  v17 = _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(w0, w0, 224), v6),
          _mm_mul_ps(_mm_shuffle_ps(a3, a3, 224), _mm_mul_ps(v5, _mm_shuffle_ps(v21, v21, 224))));
  v23 = _mm_mul_ps(_mm_unpacklo_ps(v9, v17), _mm_unpacklo_ps(w0, v17));
  v24 = v17;
  v24.m128_f32[0] = a3.m128_f32[0];
  v25 = v17;
  v25.m128_f32[0] = v22;
  v26 = _mm_add_ps(_mm_mul_ps(v25, v24), v23);
  v27 = _mm_shuffle_ps(v26, v26, 229).m128_f32[0] + (float)(v26.m128_f32[0] * v26.m128_f32[0]);
  if ( v27 > 9.8696051 )
  {
    v28 = fsqrt(v27);
    v29 = (__m128)0xC0C90FDB;
    v29.m128_f32[0] = (float)(v28 + -6.2831855) / v28;
    return _mm_mul_ps(v17, _mm_shuffle_ps(v29, v29, 224));
  }
  return v17;
}


// Address: 0x1050080 | Name: _ZN3RBX17bounceEasingStyleEf
float __fastcall RBX::bounceEasingStyle(float a1, float t)
{
  if ( a1 < 0.36363637 )
    return (float)(7.5625 * a1) * a1;
  if ( a1 < 0.72727275 )
    return (float)((float)(7.5625 * (float)(a1 + -0.54545456)) * (float)(a1 + -0.54545456)) + 0.75;
  if ( a1 >= 0.90909088 )
    return (float)((float)(7.5625 * (float)(a1 + -0.95454544)) * (float)(a1 + -0.95454544)) + 0.984375;
  else
    return (float)((float)(7.5625 * (float)(a1 + -0.81818181)) * (float)(a1 + -0.81818181)) + 0.9375;
}


// Address: 0x1050130 | Name: _ZN3RBX17adjustBlendWeightEfNS_4Pose15PoseEasingStyleENS0_19PoseEasingDirectionE
float __fastcall RBX::adjustBlendWeight(
        float a1,
        float w,
        RBX::Pose::PoseEasingStyle easingStyle,
        RBX::Pose::PoseEasingDirection easingDirection)
{
  __m128 v4; // xmm2
  float v5; // xmm2_4
  float v6; // xmm2_4
  float v7; // xmm2_4
  float v8; // xmm0_4
  float v9; // xmm0_4
  float v10; // xmm1_4
  float v11; // xmm2_4
  float v12; // xmm2_4
  float v13; // xmm2_4
  float v14; // xmm0_4
  float v15; // xmm0_4
  float v17; // [rsp+Ch] [rbp-1Ch]
  float v18; // [rsp+Ch] [rbp-1Ch]
  float v19; // [rsp+Ch] [rbp-1Ch]
  float v20; // [rsp+10h] [rbp-18h]

  v4.m128_f32[0] = a1;
  switch ( easingStyle )
  {
    case RBX::Pose::PoseEasingStyle::POSE_EASING_STYLE_CONSTANT:
      if ( easingDirection )
      {
        if ( easingDirection == RBX::Pose::PoseEasingDirection::POSE_EASING_DIRECTION_IN_OUT )
          v4.m128_i32[0] = _mm_cmplt_ss((__m128)0x3F000000u, v4).m128_u32[0] & 0x3F800000;
        else
          v4.m128_i32[0] = 1065353216;
      }
      else
      {
        v4.m128_i32[0] = 0;
      }
      return v4.m128_f32[0];
    case RBX::Pose::PoseEasingStyle::POSE_EASING_STYLE_ELASTIC:
      if ( easingDirection )
      {
        if ( easingDirection != RBX::Pose::PoseEasingDirection::POSE_EASING_DIRECTION_IN_OUT )
        {
          v19 = 1.0 - a1;
          v20 = exp2f(-10.0 * (float)(1.0 - a1));
          v4.m128_f32[0] = sinf((float)((float)(v19 + -0.075000003) * -6.2831855) / 0.30000001) * v20;
          return v4.m128_f32[0];
        }
        v5 = (float)(a1 + a1) + -1.0;
        if ( (float)(a1 + a1) < 1.0 )
        {
          v17 = exp2f(10.0 * v5) * -0.5;
          v4.m128_f32[0] = sinf((float)((float)(v5 + -0.1125) * 6.2831855) / 0.45000002) * v17;
          return v4.m128_f32[0];
        }
        v18 = exp2f(-10.0 * v5) * 0.5;
        v9 = (float)((float)(v5 + -0.1125) * 6.2831855) / 0.45000002;
      }
      else
      {
        v18 = exp2f(-10.0 * a1);
        v9 = (float)((float)(v4.m128_f32[0] + -0.075000003) * 6.2831855) / 0.30000001;
      }
      v4.m128_f32[0] = (float)(sinf(v9) * v18) + 1.0;
      return v4.m128_f32[0];
    case RBX::Pose::PoseEasingStyle::POSE_EASING_STYLE_CUBIC:
      if ( easingDirection == RBX::Pose::PoseEasingDirection::POSE_EASING_DIRECTION_IN )
        return pow(a1, 3.0);
      if ( easingDirection != RBX::Pose::PoseEasingDirection::POSE_EASING_DIRECTION_IN_OUT )
        return 1.0 - pow((float)(1.0 - a1), 3.0);
      v6 = a1 + a1;
      if ( a1 >= 0.5 )
        v4.m128_f32[0] = (1.0 - pow((float)(2.0 - v6), 3.0)) * 0.5 + 0.5;
      else
        v4.m128_f32[0] = pow(v6, 3.0) * 0.5;
      return v4.m128_f32[0];
    case RBX::Pose::PoseEasingStyle::POSE_EASING_STYLE_BOUNCE:
      if ( easingDirection == RBX::Pose::PoseEasingDirection::POSE_EASING_DIRECTION_OUT )
      {
        v10 = 1.0 - a1;
        if ( (float)(1.0 - a1) >= 0.36363637 )
        {
          if ( v10 >= 0.72727275 )
          {
            if ( v10 >= 0.90909088 )
              v11 = (float)((float)(7.5625 * (float)(v10 + -0.95454544)) * (float)(v10 + -0.95454544)) + 0.984375;
            else
              v11 = (float)((float)(7.5625 * (float)(v10 + -0.81818181)) * (float)(v10 + -0.81818181)) + 0.9375;
          }
          else
          {
            v11 = (float)((float)(7.5625 * (float)(v10 + -0.54545456)) * (float)(v10 + -0.54545456)) + 0.75;
          }
        }
        else
        {
          v11 = (float)(7.5625 * v10) * v10;
        }
        v4.m128_f32[0] = 1.0 - v11;
      }
      else if ( easingDirection == RBX::Pose::PoseEasingDirection::POSE_EASING_DIRECTION_IN_OUT )
      {
        v7 = a1 + a1;
        if ( (float)(a1 + a1) >= 1.0 )
        {
          v12 = v7 + -1.0;
          if ( v12 >= 0.36363637 )
          {
            if ( v12 >= 0.72727275 )
            {
              if ( v12 >= 0.90909088 )
                v14 = (float)((float)(7.5625 * (float)(v12 + -0.95454544)) * (float)(v12 + -0.95454544)) + 0.984375;
              else
                v14 = (float)((float)(7.5625 * (float)(v12 + -0.81818181)) * (float)(v12 + -0.81818181)) + 0.9375;
            }
            else
            {
              v14 = (float)((float)(7.5625 * (float)(v12 + -0.54545456)) * (float)(v12 + -0.54545456)) + 0.75;
            }
            v13 = v14;
          }
          else
          {
            v13 = v12 * (float)(7.5625 * v12);
          }
          v4.m128_f32[0] = (float)(v13 * 0.5) + 0.5;
        }
        else
        {
          if ( v7 >= 0.36363637 )
          {
            if ( v7 >= 0.72727275 )
            {
              if ( v7 >= 0.90909088 )
                v8 = (float)((float)(7.5625 * (float)(v7 + -0.95454544)) * (float)(v7 + -0.95454544)) + 0.984375;
              else
                v8 = (float)((float)(7.5625 * (float)(v7 + -0.81818181)) * (float)(v7 + -0.81818181)) + 0.9375;
            }
            else
            {
              v8 = (float)((float)(7.5625 * (float)(v7 + -0.54545456)) * (float)(v7 + -0.54545456)) + 0.75;
            }
          }
          else
          {
            v8 = (float)(7.5625 * v7) * v7;
          }
          v4.m128_f32[0] = v8 * 0.5;
        }
      }
      else if ( a1 >= 0.36363637 )
      {
        if ( a1 >= 0.72727275 )
        {
          if ( a1 >= 0.90909088 )
            v15 = (float)((float)(7.5625 * (float)(a1 + -0.95454544)) * (float)(a1 + -0.95454544)) + 0.984375;
          else
            v15 = (float)((float)(7.5625 * (float)(a1 + -0.81818181)) * (float)(a1 + -0.81818181)) + 0.9375;
          v4.m128_f32[0] = v15;
        }
        else
        {
          v4.m128_f32[0] = (float)((float)(7.5625 * (float)(a1 + -0.54545456)) * (float)(a1 + -0.54545456)) + 0.75;
        }
      }
      else
      {
        v4.m128_f32[0] = a1 * (float)(7.5625 * a1);
      }
      return v4.m128_f32[0];
    default:
      return v4.m128_f32[0];
  }
}


// Address: 0x1050740 | Name: _Z22Class_getDescriptorPtrPN3RBX16KeyframeSequenceE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::KeyframeSequence *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A038D8;
  if ( !qword_2A038D8 )
  {
    if ( !(_BYTE)byte_2A03C20 )
    {
      if ( __cxa_guard_acquire(&byte_2A03C20) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A038E0,
          v2,
          "KeyframeSequence",
          0,
          attributes,
          RBX::Security::Permissions::None,
          &dword_2A04350);
        stru_2A03C18._vptr$ICreator = (int (**)(void))&off_288F8F8;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A038E8, &stru_2A03C18);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::KeyframeSequence,true>::~ClassRegistrar,
          &unk_2A038E0,
          &dso_handle);
        __cxa_guard_release(&byte_2A03C20);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A038E0;
    qword_2A038D8 = (RBX::Reflection::ClassDescriptor *)&unk_2A038E0;
  }
  return result;
}


// Address: 0x10508a0 | Name: _Z16Class_getNamePtrPN3RBX16KeyframeSequenceE
const RBX::Name *__fastcall Class_getNamePtr(RBX::KeyframeSequence *a1)
{
  const RBX::Name *result; // rax

  result = (const RBX::Name *)qword_2A03C28;
  if ( !qword_2A03C28 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A03C28 = (RBX::KeyframeSequence *)result;
  }
  return result;
}


// Address: 0x10508d0 | Name: _ZN3RBX10Reflection4Type12getSingletonINS_16KeyframeSequence8PriorityEEERKS1_v
const RBX::Reflection::Type *__cdecl RBX::Reflection::Type::getSingleton<RBX::KeyframeSequence::Priority>()
{
  return (const RBX::Reflection::Type *)RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority>::singleton();
}


// Address: 0x10508e0 | Name: j__ZN3RBX10Reflection8EnumDescINS_16KeyframeSequence8PriorityEE9singletonEv
// attributes: thunk
void __cdecl RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority>::singleton()
{
  _ZN3RBX10Reflection8EnumDescINS_16KeyframeSequence8PriorityEE9singletonEv();
}


// Address: 0x1050c80 | Name: _ZN3RBX9findOrAddINSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEEEmRNS1_6vectorIT_NS5_IS9_EEEERKS9_
size_t __fastcall RBX::findOrAdd<std::string>(std::vector<std::string> *v, const std::string *s)
{
  __int64 v2; // r14
  unsigned __int64 v3; // r15
  unsigned __int64 v4; // r13
  size_t v5; // r13
  char *v6; // rbp
  size_t v7; // rbx
  __int64 v8; // r12
  unsigned __int8 v9; // dl
  unsigned __int64 v10; // rsi
  __int64 v11; // rcx
  __int64 v14; // [rsp+8h] [rbp-40h]

  v2 = *(_QWORD *)v;
  v3 = 0xAAAAAAAAAAAAAAABLL * ((__int64)(*((_QWORD *)v + 1) - *(_QWORD *)v) >> 3);
  v14 = *((_QWORD *)v + 1);
  if ( v14 != *(_QWORD *)v )
  {
    v4 = *(unsigned __int8 *)s;
    if ( (v4 & 1) != 0 )
    {
      v5 = *((_QWORD *)s + 1);
      v6 = (char *)*((_QWORD *)s + 2);
    }
    else
    {
      v5 = v4 >> 1;
      v6 = (char *)s + 1;
    }
    v8 = v2 + 1;
    v7 = 0;
    while ( 1 )
    {
      v9 = *(_BYTE *)(v2 + 24 * v7);
      v10 = (unsigned __int64)v9 >> 1;
      if ( (v9 & 1) != 0 )
        v10 = *(_QWORD *)(v2 + 24 * v7 + 8);
      if ( v10 == v5 )
      {
        if ( (v9 & 1) != 0 )
        {
          if ( !v5 || !memcmp(*(const void **)(v2 + 24 * v7 + 16), v6, v5) )
          {
LABEL_20:
            if ( v7 == v3 )
              goto LABEL_21;
            return v7;
          }
        }
        else
        {
          if ( !v5 )
            goto LABEL_20;
          v11 = 0;
          while ( *(_BYTE *)(v8 + v11) == v6[v11] )
          {
            if ( (unsigned __int64)*(unsigned __int8 *)(v2 + 24 * v7) >> 1 == ++v11 )
              goto LABEL_20;
          }
        }
      }
      ++v7;
      v8 += 24;
      if ( v7 >= v3 )
        goto LABEL_20;
    }
  }
  v7 = 0;
  if ( !v3 )
  {
LABEL_21:
    if ( *((_QWORD *)v + 2) == v14 )
    {
      std::vector<std::string>::__push_back_slow_path<std::string const&>(v, s);
    }
    else
    {
      std::string::basic_string(v14, s);
      *((_QWORD *)v + 1) += 24LL;
    }
  }
  return v7;
}


// Address: 0x10556b0 | Name: _GLOBAL__sub_I_KeyframeSequence.cpp
void __cdecl GLOBAL__sub_I_KeyframeSequence_cpp()
{
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::Reflection::ClassDescriptor *v1; // r14
  char *v2; // rbx
  const RBX::Reflection::Type *v3; // rax
  RBX::Reflection::ClassDescriptor *v4; // r14
  char *v5; // rbx
  const RBX::Reflection::Type *v6; // rax
  RBX::Reflection::PropertyDescriptor::Attributes attributes; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesa; // [rsp+0h] [rbp-78h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesb; // [rsp+0h] [rbp-78h]
  RBX::Reflection::Descriptor::Attributes v10; // [rsp+28h] [rbp-50h] BYREF
  __int64 v11; // [rsp+38h] [rbp-40h]
  RBX::Reflection::PropertyDescriptor::Attributes flags; // [rsp+40h] [rbp-38h]
  RBX::Reflection::Descriptor::Attributes v13; // 0:r8.1,8:r9.8

  qword_2A035A0 = (__int64)boost::system::generic_category();
  qword_2A035A8 = (__int64)boost::system::generic_category();
  qword_2A035B0 = (__int64)boost::system::system_category();
  stru_2A035B8.value = 0;
  stru_2A035B8.name = "KeyframeSequenceEnableFrozen";
  dword_2A035C8 = FLog::RegisterFlag("KeyframeSequenceEnableFrozen", &stru_2A035B8, FastVarType::FASTVARTYPE_STATIC);
  stru_2A035D0.value = 0;
  stru_2A035D0.name = "KeyframeSequenceCacheMemoryOptimization";
  dword_2A035E0 = FLog::RegisterFlag(
                    "KeyframeSequenceCacheMemoryOptimization",
                    &stru_2A035D0,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A035E8.value = 0;
  stru_2A035E8.name = "UseHipHeightInKeyframeSequences2";
  dword_2A035F8 = FLog::RegisterFlag("UseHipHeightInKeyframeSequences2", &stru_2A035E8, FastVarType::FASTVARTYPE_STATIC);
  stru_2A03600.value = 0;
  stru_2A03600.name = "UseKeyframeMarkersForEvents2";
  dword_2A03610 = FLog::RegisterFlag("UseKeyframeMarkersForEvents2", &stru_2A03600, FastVarType::FASTVARTYPE_STATIC);
  dword_2A03614 = RBX::Memory::registerCategory(
                    (const char *)&stru_3F7F76,
                    RBX::Memory::DeveloperTag::DeveloperTag_Animation);
  DescriptorPtr = Class_getDescriptorPtr((RBX::KeyframeSequence *)&stru_3F7F76);
  v13.isDeprecated = 0;
  v13.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A03618,
    DescriptorPtr,
    "GetKeyframes",
    RBX::Security::Permissions::None,
    v13);
  qword_2A03618[0] = &off_288F988;
  xmmword_2A03680 = (unsigned __int64)RBX::KeyframeSequence::getKeyframes;
  qword_2A03658 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<boost::shared_ptr<RBX::Instance>> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A03618, &dso_handle);
  v10.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequence,void ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequence,void (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A03690,
    RBX::KeyframeSequence::addKeyframe,
    0,
    "AddKeyframe",
    (RBX::Security::Permissions)"keyframe",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v10.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequence,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A03690,
    &dso_handle);
  v10.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequence,void ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequence,void (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A03710,
    RBX::KeyframeSequence::removeKeyframe,
    0,
    "RemoveKeyframe",
    (RBX::Security::Permissions)"keyframe",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v10.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequence,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A03710,
    &dso_handle);
  v1 = Class_getDescriptorPtr((RBX::KeyframeSequence *)RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequence,void ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc);
  v2 = (char *)operator new(0x28u);
  *(_QWORD *)v2 = &off_288FA98;
  *(_OWORD *)(v2 + 8) = (unsigned __int64)RBX::KeyframeSequence::getLoop;
  *(_OWORD *)(v2 + 24) = (unsigned __int64)RBX::KeyframeSequence::setLoop;
  v10.isDeprecated = 0;
  v10.preferred = 0;
  LODWORD(v11) = 31;
  v3 = RBX::Reflection::Type::getSingleton<bool>();
  *(_QWORD *)&attributes.flags = v11;
  attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v10);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A03790,
    v1,
    v3,
    "Loop",
    &stru_458781.gap0,
    attributes,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A03790._vptr$Descriptor = (int (**)(void))&off_2882CC8;
  qword_2A037E0 = (__int64)v2;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2) )
    *((_BYTE *)&stru_2A03790.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A03790._vptr$Descriptor + 3))(&stru_2A03790) )
    *((_BYTE *)&stru_2A03790.security + 4) &= 0xF3u;
  stru_2A03790._vptr$Descriptor = (int (**)(void))&off_288F9D8;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<bool>::~TypedPropertyDescriptor,
    &stru_2A03790,
    &dso_handle);
  v10.isDeprecated = 0;
  v10.preferred = 0;
  LODWORD(v11) = 31;
  flags.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::KeyframeSequence::setPriority;
  *(_QWORD *)&attributesa.flags = *(_QWORD *)&v10.isDeprecated;
  attributesa.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::KeyframeSequence::setPriority;
  RBX::Reflection::EnumPropDescriptor<RBX::KeyframeSequence,RBX::KeyframeSequence::Priority>::EnumPropDescriptor<RBX::KeyframeSequence::Priority (RBX::KeyframeSequence::*)(void)const,void (RBX::KeyframeSequence::*)(RBX::KeyframeSequence::Priority)>(
    (RBX::Reflection::EnumPropDescriptor<RBX::KeyframeSequence,RBX::KeyframeSequence::Priority> *)&stru_2A037E8,
    "Priority",
    &stru_458781.gap0,
    RBX::KeyframeSequence::getPriority,
    0,
    RBX::Security::Permissions::None,
    attributesa,
    0,
    v11);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::EnumPropDescriptor<RBX::KeyframeSequence,RBX::KeyframeSequence::Priority>::~EnumPropDescriptor,
    &stru_2A037E8,
    &dso_handle);
  v4 = Class_getDescriptorPtr((RBX::KeyframeSequence *)RBX::Reflection::EnumPropDescriptor<RBX::KeyframeSequence,RBX::KeyframeSequence::Priority>::~EnumPropDescriptor);
  v5 = (char *)operator new(0x28u);
  *(_QWORD *)v5 = &off_288FC18;
  *(_OWORD *)(v5 + 8) = (unsigned __int64)RBX::KeyframeSequence::getAuthoredHipHeight;
  *(_OWORD *)(v5 + 24) = (unsigned __int64)RBX::KeyframeSequence::setAuthoredHipHeight;
  v10.isDeprecated = 0;
  v10.preferred = 0;
  LODWORD(v11) = 31;
  v6 = RBX::Reflection::Type::getSingleton<float>();
  *(_QWORD *)&attributesb.flags = v11;
  attributesb.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v10);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A03850,
    v4,
    v6,
    "AuthoredHipHeight",
    &stru_458781.gap0,
    attributesb,
    RBX::Security::Permissions::Plugin,
    RBX::Security::Permissions::Plugin,
    0);
  stru_2A03850._vptr$Descriptor = (int (**)(void))&off_2882B48;
  qword_2A038A0 = (__int64)v5;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v5 + 24LL))(v5) )
    *((_BYTE *)&stru_2A03850.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A03850._vptr$Descriptor + 3))(&stru_2A03850) )
    *((_BYTE *)&stru_2A03850.security + 4) &= 0xF3u;
  stru_2A03850._vptr$Descriptor = (int (**)(void))&off_288FB58;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A03850,
    &dso_handle);
  xmmword_2A038A8 = 0;
  qword_2A038B8 = 0;
  __cxa_atexit((void (*)(void *))&std::string::~string, &xmmword_2A038A8, &dso_handle);
  xmmword_2A038C8 = 0;
  byte_2A038C0 = 12;
  strcpy((char *)&dword_2A038C1, "__Root");
  __cxa_atexit((void (*)(void *))&std::string::~string, &byte_2A038C0, &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_0);
  dword_2A03C34 = 0;
  RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority>::singleton();
  dword_2A03C38 = 0;
  RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority>::singleton();
}


