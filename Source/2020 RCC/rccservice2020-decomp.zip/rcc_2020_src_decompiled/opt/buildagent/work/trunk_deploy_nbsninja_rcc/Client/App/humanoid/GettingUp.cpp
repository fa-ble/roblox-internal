// Address: 0x10e80a0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN9GettingUpE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::GettingUp *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08EB0;
  if ( !qword_2A08EB0 )
  {
    result = RBX::Name::declare("GettingUp");
    qword_2A08EB0 = result;
  }
  return result;
}


// Address: 0x10e80d0 | Name: _ZNK3RBX5HUMAN9GettingUp7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::GettingUp::getName(const RBX::HUMAN::GettingUp *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08EB0;
  if ( !qword_2A08EB0 )
  {
    result = RBX::Name::declare("GettingUp");
    qword_2A08EB0 = result;
  }
  return result;
}


// Address: 0x10e8100 | Name: _ZN3RBX5HUMAN9GettingUpC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::GettingUp::GettingUp(
        RBX::HUMAN::GettingUp *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  float v3; // xmm0_4

  RBX::HUMAN::Balancing::Balancing(this, humanoid, priorState, 5000.0, 300.0);
  *(_QWORD *)this = &off_28959D0;
  if ( humanoid )
  {
    if ( stru_2A10FE8.value )
    {
      *((float *)this + 78) = (float)dword_28595F0;
      v3 = (float)dword_2859600;
    }
    else
    {
      *((_DWORD *)this + 78) = 1158455296;
      v3 = 50.0;
    }
    *((float *)this + 79) = v3;
  }
}


// Address: 0x10e8180 | Name: _ZN3RBX5HUMAN9GettingUp19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::GettingUp::onSimulatorStepImpl(RBX::HUMAN::GettingUp *this, double a2, const float stepDt)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Body *RootBodyFast; // rax
  __m128 v5; // xmm0
  RBX::Body *v6; // r14
  RBX::Humanoid *v7; // rax
  RBX::PartInstance *HeadSlow; // rax
  RBX::Body *root; // rax
  RBX::Solver::SolverRigidBody *rigidBody; // rbx
  RBX::Vector3 ContactRepelForceInBalancing; // 0:kr00_12.12

  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RootBodyFast = RBX::Humanoid::getRootBodyFast(HumanoidConst);
  if ( RootBodyFast )
  {
    v5 = (__m128)*((unsigned int *)this + 4);
    if ( v5.m128_f32[0] < -3.5 && v5.m128_f32[0] > -4.5 )
    {
      v6 = RootBodyFast;
      v7 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
      HeadSlow = RBX::Humanoid::getHeadSlow(v7);
      if ( HeadSlow )
      {
        (*((void (__fastcall **)(RBX::PartInstance *, _QWORD))HeadSlow->_vptr$EventSource + 69))(HeadSlow, 0);
        ContactRepelForceInBalancing = RBX::HUMAN::Balancing::getContactRepelForceInBalancing(this);
        v5.m128_i32[0] = LODWORD(ContactRepelForceInBalancing.x);
        v5.m128_i32[1] = LODWORD(ContactRepelForceInBalancing.y);
        root = v6->root;
        rigidBody = root->rigidBody;
        if ( rigidBody )
        {
          if ( rigidBody->dirty )
            RBX::Solver::SolverRigidBody::update(root->rigidBody);
          rigidBody->force.x = rigidBody->force.x + ContactRepelForceInBalancing.x;
          rigidBody->force.y = _mm_shuffle_ps(v5, v5, 229).m128_f32[0] + rigidBody->force.y;
          rigidBody->force.z = ContactRepelForceInBalancing.z + rigidBody->force.z;
        }
      }
    }
  }
}


// Address: 0x10e8340 | Name: _GLOBAL__sub_I_GettingUp.cpp
void __cdecl GLOBAL__sub_I_GettingUp_cpp()
{
  qword_2A08E90 = (__int64)boost::system::generic_category();
  qword_2A08E98 = (__int64)boost::system::generic_category();
  qword_2A08EA0 = (__int64)boost::system::system_category();
  dword_2A08EA8 = FLog::RegisterInt("GettingUpBalanceP", &dword_28595F0, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08EAC = FLog::RegisterInt("GettingUpBalanceD", &dword_2859600, FastVarType::FASTVARTYPE_DYNAMIC);
}


