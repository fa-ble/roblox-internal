// Address: 0x1df1450 | Name: _ZN3RBX9Collision18FeaturePolyContact27updateCollisionsWithMatchesERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEE
float __fastcall RBX::Collision::FeaturePolyContact::updateCollisionsWithMatches(
        RBX::Collision::FeaturePolyContact *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors)
{
  unsigned int v2; // ebp
  size_t v3; // rax
  RBX::Collision::FeaturePolyCollisionConnector *v4; // rbx
  RBX::Collision::FeaturePolyCollisionConnector *MatchingCollisionConnector; // rax
  float depth; // xmm0_4
  float v8; // [rsp+0h] [rbp-24h]

  if ( !newCollisionConnectors->num )
    return 3.4028235e38;
  v8 = 3.4028235e38;
  v2 = 1;
  v3 = 0;
  do
  {
    v4 = newCollisionConnectors->data.elems[v3];
    if ( v4->normal.x != 0.0 || v4->normal.y != 0.0 || v4->normal.z != 0.0 )
    {
      MatchingCollisionConnector = RBX::Collision::FeaturePolyContact::findMatchingCollisionConnector(
                                     &this->collisionConnectors,
                                     newCollisionConnectors->data.elems[v3]);
      if ( MatchingCollisionConnector )
      {
        depth = v4->depth;
        MatchingCollisionConnector->contactPoint.z = v4->contactPoint.z;
        *(_QWORD *)&MatchingCollisionConnector->contactPoint.x = *(_QWORD *)&v4->contactPoint.x;
        MatchingCollisionConnector->normal.z = v4->normal.z;
        *(_QWORD *)&MatchingCollisionConnector->normal.x = *(_QWORD *)&v4->normal.x;
        MatchingCollisionConnector->depth = depth;
        *(_QWORD *)&v4->normal.x = 0;
        v4->normal.z = 0.0;
        v8 = fminf(depth, v8);
      }
    }
    v3 = v2++;
  }
  while ( newCollisionConnectors->num > v3 );
  return v8;
}


// Address: 0x1df1550 | Name: _ZN3RBX9Collision18FeaturePolyContact30findMatchingCollisionConnectorERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEES4_
RBX::Collision::FeaturePolyCollisionConnector *__fastcall RBX::Collision::FeaturePolyContact::findMatchingCollisionConnector(
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        RBX::Collision::FeaturePolyCollisionConnector *collisionToMatch)
{
  size_t num; // rcx
  unsigned int v3; // edx
  size_t v4; // rax
  RBX::Collision::FeaturePolyCollisionConnector *result; // rax
  RBX::Collision::FeaturePolyPair pairType; // ebp
  int param0; // r8d
  int param1; // r9d
  RBX::Body *bodyA; // r10
  float v10; // xmm4_4
  float v11; // xmm2_4
  bool v12; // r12

  num = collisionConnectors->num;
  if ( !num )
    return 0;
  v3 = 1;
  v4 = 0;
  while ( 1 )
  {
    result = collisionConnectors->data.elems[v4];
    if ( result->normal.x != 0.0 )
      goto LABEL_14;
    if ( result->normal.y != 0.0 )
      goto LABEL_14;
    if ( result->normal.z != 0.0 )
      goto LABEL_14;
    pairType = result->pairType;
    if ( pairType != collisionToMatch->pairType )
      goto LABEL_14;
    param0 = result->param0;
    param1 = result->param1;
    bodyA = result->bodyA;
    v10 = (float)collisionToMatch->param0;
    v11 = (float)collisionToMatch->param1;
    v12 = result->bodyA == collisionToMatch->bodyA && (float)param0 == v10 && (float)param1 == v11;
    if ( pairType == RBX::Collision::FeaturePolyPair::EDGE_EDGE_PAIR && !v12 )
      break;
    if ( pairType == RBX::Collision::FeaturePolyPair::EDGE_EDGE_PAIR || v12 )
      goto LABEL_17;
LABEL_14:
    v4 = v3++;
    if ( num <= v4 )
      return 0;
  }
  if ( (float)param1 != v10 || (float)param0 != v11 || bodyA != collisionToMatch->bodyB )
    goto LABEL_14;
LABEL_17:
  if ( bodyA != collisionToMatch->bodyA )
  {
    result->bodyA = result->bodyB;
    result->bodyB = bodyA;
    result->param0 = param1;
    result->param1 = param0;
  }
  return result;
}


// Address: 0x1df1690 | Name: _ZN3RBX9Collision18FeaturePolyContact23updateCollisionsWithNewERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
float __fastcall RBX::Collision::FeaturePolyContact::updateCollisionsWithNew(
        RBX::Collision::FeaturePolyContact *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors,
        float result,
        float bestDepthSoFar)
{
  size_t num; // rax
  unsigned int v6; // ebp
  size_t i; // rcx
  RBX::Collision::FeaturePolyCollisionConnector *v8; // rbx
  RBX::Primitive *prim0; // rdx
  RBX::Primitive *prim1; // rsi
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // rax
  float depth; // xmm0_4
  float v13; // [rsp+Ch] [rbp-2Ch]

  num = newCollisionConnectors->num;
  if ( num )
  {
    v6 = 1;
    for ( i = 0; i < num; i = v6++ )
    {
      v8 = newCollisionConnectors->data.elems[i];
      if ( v8->normal.x != 0.0 || v8->normal.y != 0.0 || v8->normal.z != 0.0 )
      {
        prim0 = this->prim0;
        prim1 = this->prim1;
        if ( v8->bodyA == (RBX::Body *)((char *)prim0 + 152) )
        {
          prim1 = this->prim0;
          prim0 = this->prim1;
        }
        v13 = result;
        CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                               &this->collisionConnectors,
                               prim1,
                               prim0,
                               v8->pairType);
        depth = v8->depth;
        CollisionConnector->contactPoint = v8->contactPoint;
        CollisionConnector->normal = v8->normal;
        CollisionConnector->depth = depth;
        CollisionConnector->param0 = v8->param0;
        CollisionConnector->param1 = v8->param1;
        result = fminf(depth, v13);
        *(_QWORD *)&v8->normal.x = 0;
        v8->normal.z = 0.0;
        num = newCollisionConnectors->num;
      }
    }
  }
  return result;
}


// Address: 0x1df1790 | Name: _ZN3RBX9Collision18FeaturePolyContact24createCollisionConnectorERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEPNS_9PrimitiveES8_NS0_15FeaturePolyPairE
RBX::Collision::FeaturePolyCollisionConnector *__fastcall RBX::Collision::FeaturePolyContact::createCollisionConnector(
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        RBX::Primitive *p0,
        RBX::Primitive *p1,
        RBX::Collision::FeaturePolyPair pairType)
{
  RBX::Collision::FeaturePolyCollisionConnector *v5; // rbx
  RBX::Primitive *bodyA; // rax
  int param0; // eax
  __int64 v9; // rax
  size_t num; // rax
  RBX::CollisionParams v12; // [rsp+0h] [rbp-48h] BYREF

  if ( collisionConnectors->num == 8 )
  {
    v5 = collisionConnectors->data.elems[0];
    if ( collisionConnectors->data.elems[0]->normal.x != 0.0 || v5->normal.y != 0.0 || v5->normal.z != 0.0 )
    {
      v5 = collisionConnectors->data.elems[1];
      if ( v5->normal.x != 0.0 || v5->normal.y != 0.0 || v5->normal.z != 0.0 )
      {
        v5 = collisionConnectors->data.elems[2];
        if ( v5->normal.x != 0.0 || v5->normal.y != 0.0 || v5->normal.z != 0.0 )
        {
          v5 = collisionConnectors->data.elems[3];
          if ( v5->normal.x != 0.0 || v5->normal.y != 0.0 || v5->normal.z != 0.0 )
          {
            v5 = collisionConnectors->data.elems[4];
            if ( v5->normal.x != 0.0 || v5->normal.y != 0.0 || v5->normal.z != 0.0 )
            {
              v5 = collisionConnectors->data.elems[5];
              if ( v5->normal.x != 0.0 || v5->normal.y != 0.0 || v5->normal.z != 0.0 )
              {
                v5 = collisionConnectors->data.elems[6];
                if ( v5->normal.x != 0.0 || v5->normal.y != 0.0 || v5->normal.z != 0.0 )
                  v5 = collisionConnectors->data.elems[7];
              }
            }
          }
        }
      }
    }
    v5->pairType = pairType;
    bodyA = (RBX::Primitive *)v5->bodyA;
    if ( v5->bodyA != (RBX::Body *)((char *)p0 + 152) )
    {
      v5->bodyA = v5->bodyB;
      v5->bodyB = (RBX::Body *)bodyA;
      param0 = v5->param0;
      v5->param0 = v5->param1;
      v5->param1 = param0;
    }
  }
  else
  {
    v5 = (RBX::Collision::FeaturePolyCollisionConnector *)operator new(0x48u);
    RBX::Collision::Contact::computeCollisionParams(&v12, p0, p1);
    v9 = *(_QWORD *)&v12.friction;
    *(_OWORD *)&v5->bodyA = *(_OWORD *)&v12.b0;
    *(_QWORD *)&v5->friction = v9;
    *(_OWORD *)&v5->normal.x = 0;
    *(_OWORD *)&v5->contactPoint.x = 0;
    v5->collisionIndex = -1;
    v5->canThrottle = 1;
    v5->pairType = pairType;
    num = collisionConnectors->num;
    collisionConnectors->data.elems[num] = v5;
    collisionConnectors->num = num + 1;
  }
  return v5;
}


// Address: 0x1df1a20 | Name: _ZN3RBX9Collision18FeaturePolyContact30updateCachedDataGetBestOverlapERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEE
float __fastcall RBX::Collision::FeaturePolyContact::updateCachedDataGetBestOverlap(
        RBX::Collision::FeaturePolyContact *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors)
{
  RBX::Collision::PolyCollisionConnectorArray *p_collisionConnectors; // r15
  unsigned int v4; // ebp
  size_t v5; // rcx
  RBX::Collision::FeaturePolyCollisionConnector *v6; // rbx
  RBX::Collision::FeaturePolyCollisionConnector *MatchingCollisionConnector; // rax
  float depth; // xmm0_4
  size_t num; // rax
  unsigned int v10; // ebx
  size_t i; // rcx
  RBX::Collision::FeaturePolyCollisionConnector *v12; // rbp
  RBX::Primitive *prim0; // rdx
  RBX::Primitive *prim1; // rsi
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // rax
  float v16; // xmm0_4
  float v18; // [rsp+0h] [rbp-38h]

  if ( newCollisionConnectors->num )
  {
    p_collisionConnectors = &this->collisionConnectors;
    v18 = 3.4028235e38;
    v4 = 1;
    v5 = 0;
    do
    {
      v6 = newCollisionConnectors->data.elems[v5];
      if ( v6->normal.x != 0.0 || v6->normal.y != 0.0 || v6->normal.z != 0.0 )
      {
        MatchingCollisionConnector = RBX::Collision::FeaturePolyContact::findMatchingCollisionConnector(
                                       p_collisionConnectors,
                                       newCollisionConnectors->data.elems[v5]);
        if ( MatchingCollisionConnector )
        {
          depth = v6->depth;
          MatchingCollisionConnector->contactPoint.z = v6->contactPoint.z;
          *(_QWORD *)&MatchingCollisionConnector->contactPoint.x = *(_QWORD *)&v6->contactPoint.x;
          MatchingCollisionConnector->normal.z = v6->normal.z;
          *(_QWORD *)&MatchingCollisionConnector->normal.x = *(_QWORD *)&v6->normal.x;
          MatchingCollisionConnector->depth = depth;
          *(_QWORD *)&v6->normal.x = 0;
          v6->normal.z = 0.0;
          v18 = fminf(depth, v18);
        }
      }
      v5 = v4;
      num = newCollisionConnectors->num;
      ++v4;
    }
    while ( num > v5 );
    if ( num )
    {
      v10 = 1;
      for ( i = 0; i < num; i = v10++ )
      {
        v12 = newCollisionConnectors->data.elems[i];
        if ( v12->normal.x != 0.0 || v12->normal.y != 0.0 || v12->normal.z != 0.0 )
        {
          prim0 = this->prim0;
          prim1 = this->prim1;
          if ( v12->bodyA == (RBX::Body *)((char *)prim0 + 152) )
          {
            prim1 = this->prim0;
            prim0 = this->prim1;
          }
          CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                                 p_collisionConnectors,
                                 prim1,
                                 prim0,
                                 v12->pairType);
          v16 = v12->depth;
          CollisionConnector->contactPoint = v12->contactPoint;
          CollisionConnector->normal = v12->normal;
          CollisionConnector->depth = v16;
          CollisionConnector->param0 = v12->param0;
          CollisionConnector->param1 = v12->param1;
          *(_QWORD *)&v12->normal.x = 0;
          v12->normal.z = 0.0;
          num = newCollisionConnectors->num;
          v18 = fminf(v16, v18);
        }
      }
    }
  }
  else
  {
    v18 = 3.4028235e38;
  }
  return -v18;
}


// Address: 0x1df1bf0 | Name: _ZN3RBX9Collision18FeaturePolyContact28deleteNewCollisionsContainerERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEE
void __fastcall RBX::Collision::FeaturePolyContact::deleteNewCollisionsContainer(
        RBX::Collision::FeaturePolyContact *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors)
{
  size_t num; // rax
  unsigned int v3; // ebp
  size_t i; // rcx
  RBX::Collision::FeaturePolyCollisionConnector *v5; // rdi

  num = newCollisionConnectors->num;
  if ( num )
  {
    v3 = 1;
    for ( i = 0; i < num; i = v3++ )
    {
      v5 = newCollisionConnectors->data.elems[i];
      if ( v5 )
      {
        operator delete(v5);
        num = newCollisionConnectors->num;
      }
    }
  }
  newCollisionConnectors->num = 0;
}


// Address: 0x1df1c50 | Name: _ZN3RBX9Collision18FeaturePolyContact21getCollisionConnectorEj
RBX::CollisionConnector *__fastcall RBX::Collision::FeaturePolyContact::getCollisionConnector(
        RBX::Collision::FeaturePolyContact *this,
        unsigned int i)
{
  return this->collisionConnectors.data.elems[i];
}


// Address: 0x1df1c60 | Name: _ZN3RBX9Collision18FeaturePolyContact24deleteCollisionConnectorEj
void __fastcall RBX::Collision::FeaturePolyContact::deleteCollisionConnector(
        RBX::Collision::FeaturePolyContact *this,
        unsigned int i)
{
  size_t num; // rax
  RBX::Collision::FeaturePolyCollisionConnector *v4; // rdi

  num = this->collisionConnectors.num;
  if ( num > i )
  {
    v4 = this->collisionConnectors.data.elems[i];
    if ( v4 )
    {
      operator delete(v4);
      num = this->collisionConnectors.num;
    }
    this->collisionConnectors.data.elems[i] = (RBX::Collision::FeaturePolyCollisionConnector *)*((_QWORD *)&this->contactManagerTransitionIndex
                                                                                               + num);
    this->collisionConnectors.num = num - 1;
  }
}


// Address: 0x1df1ca0 | Name: _ZN3RBX9Collision18FeaturePolyContact18computeIsCollidingEf
__int64 __fastcall RBX::Collision::FeaturePolyContact::computeIsColliding(
        RBX::Collision::FeaturePolyContact *this,
        float a2,
        double overlapIgnored)
{
  unsigned int v3; // ebx
  unsigned int v4; // eax
  size_t v5; // rcx
  RBX::Collision::FeaturePolyCollisionConnector *v6; // rcx
  RBX::Primitive *prim1; // r15
  const RBX::Extents *FastFuzzyExtents; // r14
  const RBX::Extents *v9; // rax
  size_t num; // rax
  unsigned int v11; // ebp
  size_t v12; // rcx
  RBX::Collision::FeaturePolyCollisionConnector *v13; // rdi
  RBX::Collision::PolyCollisionConnectorArray newCollisionConnectors; // [rsp+10h] [rbp-68h] BYREF

  v3 = (unsigned int)this;
  if ( this->collisionConnectors.num )
  {
    v4 = 1;
    v5 = 0;
    do
    {
      v6 = this->collisionConnectors.data.elems[v5];
      *(_QWORD *)&v6->normal.x = 0;
      v6->normal.z = 0.0;
      v5 = v4++;
    }
    while ( this->collisionConnectors.num > v5 );
  }
  prim1 = this->prim1;
  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(this->prim0);
  v9 = RBX::Primitive::getFastFuzzyExtents(prim1);
  if ( FastFuzzyExtents->low.x > v9->high.x
    || FastFuzzyExtents->low.y > v9->high.y
    || FastFuzzyExtents->low.z > v9->high.z
    || v9->low.y > FastFuzzyExtents->high.y
    || v9->low.x > FastFuzzyExtents->high.x
    || v9->low.z > FastFuzzyExtents->high.z )
  {
    return 0;
  }
  else
  {
    newCollisionConnectors.num = 0;
    if ( !(*((unsigned __int8 (__fastcall **)(RBX::Collision::FeaturePolyContact *, RBX::Collision::PolyCollisionConnectorArray *, float, double))this->_vptr$Contact
           + 14))(
            this,
            &newCollisionConnectors,
            a2,
            overlapIgnored)
      || (LOBYTE(v3) = 1,
          a2 > RBX::Collision::FeaturePolyContact::updateCachedDataGetBestOverlap(this, &newCollisionConnectors)) )
    {
      v3 = 0;
    }
    num = newCollisionConnectors.num;
    if ( newCollisionConnectors.num )
    {
      v11 = 1;
      v12 = 0;
      do
      {
        v13 = newCollisionConnectors.data.elems[v12];
        if ( v13 )
        {
          operator delete(v13);
          num = newCollisionConnectors.num;
        }
        v12 = v11++;
      }
      while ( num > v12 );
    }
  }
  return v3;
}


// Address: 0x1df1de0 | Name: _ZN3RBX9Collision18FeaturePolyContact5matchEPNS0_29FeaturePolyCollisionConnectorES3_
bool __fastcall RBX::Collision::FeaturePolyContact::match(
        RBX::Collision::FeaturePolyCollisionConnector *connA,
        RBX::Collision::FeaturePolyCollisionConnector *connB)
{
  RBX::Collision::FeaturePolyPair pairType; // r9d
  float param0; // xmm2_4
  float param1; // xmm0_4
  float v5; // xmm1_4
  RBX::Body *bodyA; // rdi
  float v7; // xmm3_4
  bool v8; // cl
  bool result; // al

  pairType = connA->pairType;
  if ( pairType != connB->pairType )
    return 0;
  param0 = (float)connA->param0;
  param1 = (float)connA->param1;
  v5 = (float)connB->param0;
  bodyA = connA->bodyA;
  v7 = (float)connB->param1;
  v8 = bodyA == connB->bodyA && param0 == v5 && param1 == v7;
  result = v8 || pairType == RBX::Collision::FeaturePolyPair::EDGE_EDGE_PAIR;
  if ( pairType == RBX::Collision::FeaturePolyPair::EDGE_EDGE_PAIR && !v8 )
    return bodyA == connB->bodyB && param0 == v7 && param1 == v5;
  return result;
}


// Address: 0x1df1e60 | Name: _ZN3RBX9Collision18FeaturePolyContactC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::FeaturePolyContact::FeaturePolyContact(
        RBX::Collision::FeaturePolyContact *this,
        RBX::Primitive *prim0,
        RBX::Primitive *prim1)
{
  RBX::Collision::Contact::Contact(this, prim0, prim1);
  this->_vptr$Contact = (int (**)(void))&off_299E350;
  this->collisionConnectors.num = 0;
}


// Address: 0x1df1e80 | Name: _ZN3RBX9Collision18FeaturePolyContactD2Ev
void __fastcall RBX::Collision::FeaturePolyContact::~FeaturePolyContact(RBX::Collision::FeaturePolyContact *this)
{
  this->_vptr$Contact = (int (**)(void))&off_299E350;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
}


// Address: 0x1df1ea0 | Name: _ZN3RBX9Collision18FeaturePolyContactD0Ev
void __fastcall __noreturn RBX::Collision::FeaturePolyContact::~FeaturePolyContact(
        RBX::Collision::FeaturePolyContact *this)
{
  BUG();
}


// Address: 0x1df1eb0 | Name: _GLOBAL__sub_I_FeaturePolyContact.cpp
void __cdecl GLOBAL__sub_I_FeaturePolyContact_cpp()
{
  qword_2AAF5B8 = (__int64)boost::system::generic_category();
  qword_2AAF5C0 = (__int64)boost::system::generic_category();
  qword_2AAF5C8 = (__int64)boost::system::system_category();
}


