// Address: 0x1055cb0 | Name: _Z32animationConvertToTrivialAssetIdRKNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEERN3RBX9ContentIdE
bool __fastcall animationConvertToTrivialAssetId(const std::string *configuredBaseUrl, RBX::ContentId *assetId)
{
  RBX::ContentId *v2; // r15
  const std::string *v3; // r12
  unsigned __int64 v4; // rbp
  char *v5; // r14
  unsigned __int64 v6; // rbp
  unsigned __int64 v7; // rsi
  unsigned __int64 v8; // r8
  char *v9; // r11
  _QWORD *v10; // r13
  char v11; // r9
  char *v12; // r14
  unsigned __int64 v13; // rsi
  __int64 v14; // r10
  bool v15; // bl
  unsigned __int64 v16; // rbp
  __int64 v17; // rax
  __int64 v18; // r15
  char v19; // bl
  __int64 v20; // rax
  char v21; // bl
  __int64 v22; // rax
  bool v23; // zf
  char *v24; // rbp
  int v25; // ebx
  char v26; // dl
  char *v27; // rdi
  unsigned __int64 v28; // rcx
  unsigned __int64 v29; // rcx
  __int64 v30; // rbp
  unsigned __int64 v31; // rdx
  unsigned __int64 v32; // r8
  unsigned __int64 v33; // rdi
  unsigned __int8 v34; // cl
  std::locale::__imp *locale; // rax
  unsigned __int64 v37; // r10
  const char *v38; // r12
  const char *v39; // rcx
  _BYTE **v40; // [rsp+8h] [rbp-B0h]
  char *v41; // [rsp+10h] [rbp-A8h]
  std::locale v42; // [rsp+18h] [rbp-A0h] BYREF
  void *ptr; // [rsp+28h] [rbp-90h]
  char *v44; // [rsp+30h] [rbp-88h]
  const std::string *v45; // [rsp+38h] [rbp-80h]
  RBX::ContentId *v46; // [rsp+40h] [rbp-78h]
  char v47; // [rsp+48h] [rbp-70h] BYREF
  char v48; // [rsp+49h] [rbp-6Fh] BYREF
  void *v49; // [rsp+58h] [rbp-60h]
  std::locale v50[2]; // [rsp+60h] [rbp-58h] BYREF
  void *v51; // [rsp+70h] [rbp-48h]
  unsigned __int64 v52; // [rsp+80h] [rbp-38h]

  v2 = assetId;
  v3 = configuredBaseUrl;
  v52 = __readfsqword(0x28u);
  if ( !(unsigned int)std::string::compare(assetId, 0, 13, "rbxassetid://") )
  {
    v7 = *(unsigned __int8 *)assetId;
    v40 = (_BYTE **)((char *)v2 + 16);
    v8 = *((_QWORD *)v2 + 1);
    v9 = (char *)*((_QWORD *)v2 + 2);
    v10 = (_QWORD *)((char *)v2 + 8);
    v11 = v7 & 1;
    v12 = (char *)v2 + 1;
    v13 = v7 >> 1;
    v14 = 12;
    v15 = 0;
  }
  else
  {
    std::locale::locale(&v42);
    std::locale::locale(v50, &v42);
    v4 = *(unsigned __int8 *)assetId;
    v5 = (char *)assetId + 1;
    v41 = (char *)assetId + 1;
    if ( (v4 & 1) != 0 )
    {
      v5 = (char *)*((_QWORD *)assetId + 2);
      v6 = *((_QWORD *)assetId + 1);
    }
    else
    {
      v6 = v4 >> 1;
    }
    v40 = (_BYTE **)((char *)assetId + 16);
    v10 = (_QWORD *)((char *)assetId + 8);
    if ( v6 )
    {
      v44 = (char *)assetId + 8;
      v45 = configuredBaseUrl;
      v46 = assetId;
      v16 = v6 - 1;
      v17 = 0;
      do
      {
        v18 = v17;
        v19 = v5[v17];
        v20 = std::locale::use_facet(v50, &std::ctype<char>::id);
        v21 = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v20 + 24LL))(v20, (unsigned int)v19);
        v22 = std::locale::use_facet(v50, &std::ctype<char>::id);
        if ( v21 != (*(unsigned __int8 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v22 + 24LL))(
                      v22,
                      (unsigned int)aHttp_2[v18]) )
        {
          std::locale::~locale(v50);
          v2 = v46;
          v3 = v45;
          v10 = v44;
          goto LABEL_15;
        }
        if ( v18 == 3 )
          break;
        v17 = v18 + 1;
      }
      while ( v16 != v18 );
      std::locale::~locale(v50);
      v23 = v18 == 3;
      v2 = v46;
      v3 = v45;
      v10 = v44;
      if ( !v23 )
        goto LABEL_15;
      std::locale::~locale(&v42);
      v24 = (char *)assetId + 1;
    }
    else
    {
      std::locale::~locale(v50);
LABEL_15:
      v24 = (char *)assetId + 1;
      if ( !(unsigned int)std::string::compare(v2, 0, 10, "rbxhttp://") )
      {
        std::locale::~locale(&v42);
      }
      else
      {
        v25 = std::string::compare(v2, 0, 11, "rbxasset://");
        std::locale::~locale(&v42);
        if ( v25 )
        {
          v26 = *(_BYTE *)v2;
LABEL_40:
          *(std::locale::__imp **)((char *)&v50[0].__locale_ + 7) = 0;
          v50[0].__locale_ = 0;
          if ( (v26 & 1) != 0 )
          {
            **v40 = 0;
            *v10 = 0;
          }
          else
          {
            *(_WORD *)v2 = 0;
          }
          std::string::reserve(v2, 0);
          *(_BYTE *)v2 = 0;
          locale = v50[0].__locale_;
          *((std::locale *)v2 + 1) = *(std::locale *)((char *)&v50[0].__locale_ + 7);
          *(_QWORD *)((char *)v2 + 1) = locale;
          *((_QWORD *)v2 + 2) = 0;
          return 0;
        }
      }
    }
    v14 = std::string::rfind(v2, 61, -1);
    v26 = *(_BYTE *)v2;
    v13 = (unsigned __int64)*(unsigned __int8 *)v2 >> 1;
    v11 = *(_BYTE *)v2 & 1;
    v9 = (char *)*((_QWORD *)v2 + 2);
    v27 = v9;
    if ( !v11 )
      v27 = v24;
    v8 = *((_QWORD *)v2 + 1);
    v28 = v8;
    if ( !v11 )
      v28 = (unsigned __int64)*(unsigned __int8 *)v2 >> 1;
    if ( v28 )
    {
      v29 = v28 - 1;
      v30 = 0;
      while ( v27[v30] == aHttpWwwRobloxC[v30] )
      {
        v15 = v30 == 20;
        if ( v30 != 20 )
        {
          v23 = v29 == v30++;
          if ( !v23 )
            continue;
        }
        if ( v14 == -1 )
          goto LABEL_40;
        goto LABEL_29;
      }
    }
    v15 = 0;
    if ( v14 == -1 )
      goto LABEL_40;
LABEL_29:
    v12 = v41;
  }
  v31 = v14 + 1;
  if ( v11 )
    v13 = v8;
  else
    v9 = v12;
  v32 = -1;
  if ( v13 > v31 )
  {
    v33 = v14 + 1;
    while ( 1 )
    {
      v34 = v9[v33];
      if ( v34 > 0x3Fu || ((1LL << v34) & 0x3FF000000000000LL) == 0 )
        break;
      if ( v13 == ++v33 )
        goto LABEL_45;
    }
    v32 = v33;
  }
LABEL_45:
  v37 = v14 + 20;
  if ( v37 >= v32 )
    v37 = v32;
  if ( v15 )
  {
    v38 = "http://www.roblox.com";
  }
  else if ( (*(_BYTE *)v3 & 1) != 0 )
  {
    v38 = (const char *)*((_QWORD *)v3 + 2);
  }
  else
  {
    v38 = (char *)v3 + 1;
  }
  std::string::basic_string(&v47, v2, v31, v37 - v31, v2);
  if ( (v47 & 1) != 0 )
    v39 = (const char *)v49;
  else
    v39 = &v48;
  RBX::format((RBX *)&v42, "%s/asset/?id=%s", v38, v39);
  std::string::basic_string(v50, &v42);
  RBX::ContentId::CorrectBackslash((std::string *)v50);
  if ( (*(_BYTE *)v2 & 1) != 0 )
  {
    **v40 = 0;
    *v10 = 0;
  }
  else
  {
    *v12 = 0;
    *(_BYTE *)v2 = 0;
  }
  std::string::reserve(v2, 0);
  *((_QWORD *)v2 + 2) = v51;
  *(_OWORD *)v2 = *(_OWORD *)&v50[0].__locale_;
  *(_OWORD *)&v50[0].__locale_ = 0;
  v51 = 0;
  if ( ((__int64)v42.__locale_ & 1) != 0 )
    operator delete(ptr);
  if ( (v47 & 1) != 0 )
    operator delete(v49);
  return 1;
}


// Address: 0x10561b0 | Name: _ZN3RBX24KeyframeSequenceProvider30registerActiveKeyframeSequenceEN5boost10shared_ptrINS_8InstanceEEE
std::string *__fastcall RBX::KeyframeSequenceProvider::registerActiveKeyframeSequence(
        std::string *id,
        RBX::Instance *context,
        RBX::KeyframeSequence **a3)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::KeyframeSequence *v6; // r15
  volatile signed __int32 *v7; // r12
  int v8; // edx
  std::pair<std::__tree_iterator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__tree_node<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,void *> *,long>,bool> v9; // rax
  volatile signed __int32 *left; // rbx
  RBX *exception; // rbx
  std::runtime_error *v13; // rbx
  std::tuple<> __args; // [rsp+8h] [rbp-50h] BYREF
  _BYTE v15[16]; // [rsp+10h] [rbp-48h] BYREF
  void *ptr; // [rsp+20h] [rbp-38h]
  std::tuple<const std::string &> v17; // [rsp+28h] [rbp-30h] BYREF

  if ( RBX::Network::Client::clientIsPresent(context, 0) || RBX::Network::Server::serverIsPresent(context, 0) )
  {
    exception = (RBX *)__cxa_allocate_exception(0x10u);
    RBX::runtime_error(exception, "Usage error: RegisterActiveKeyframeSequence can only be used in Solo mode.");
    goto LABEL_28;
  }
  if ( !*a3
    || (descriptor = (*a3)->descriptor,
        DescriptorPtr = Class_getDescriptorPtr(0),
        *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364)) )
  {
LABEL_27:
    exception = (RBX *)__cxa_allocate_exception(0x10u);
    std::runtime_error::runtime_error(exception, "Argument must be a 'KeyframeSequence' object");
LABEL_28:
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  v6 = *a3;
  v7 = (volatile signed __int32 *)a3[1];
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  if ( !v6 )
  {
    if ( v7 )
    {
      if ( !_InterlockedSub(v7 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
        if ( !_InterlockedSub(v7 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
      }
    }
    goto LABEL_27;
  }
  if ( RBX::KeyframeSequence::isFrozen(v6) )
  {
    v13 = (std::runtime_error *)__cxa_allocate_exception(0x10u);
    std::runtime_error::runtime_error(v13, "Unable to register a frozen KeyframeSequence");
    __cxa_throw(
      v13,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  v8 = HIDWORD(context[1]._vptr$EventSource);
  HIDWORD(context[1]._vptr$EventSource) = v8 + 1;
  RBX::format((RBX *)v15, "active://%d", v8);
  v17.__base_.__value_ = (const std::string *)v15;
  v9 = std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
         (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > > *)&context[1].boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
         (const std::string *)v15,
         &stru_4A8BF8,
         &v17,
         &__args);
  if ( v7 )
    _InterlockedAdd(v7 + 2, 1u);
  v9.first.__ptr_[7].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v6;
  left = (volatile signed __int32 *)v9.first.__ptr_[8].__left_;
  v9.first.__ptr_[8].__left_ = (std::__tree_end_node<std::__tree_node_base<void *> *>::pointer)v7;
  if ( left )
  {
    if ( !_InterlockedSub(left + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, _BYTE *, _QWORD))(*(_QWORD *)left + 16LL))(
        left,
        v15,
        *(_QWORD *)&v9.second);
      if ( !_InterlockedSub(left + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)left + 24LL))(left);
    }
  }
  std::string::basic_string(id, v15);
  RBX::ContentId::CorrectBackslash(id);
  if ( (v15[0] & 1) != 0 )
    operator delete(ptr);
  if ( v7 )
  {
    if ( !_InterlockedSub(v7 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  return id;
}


// Address: 0x10564c0 | Name: _ZN3RBX24KeyframeSequenceProvider24registerKeyframeSequenceEN5boost10shared_ptrINS_8InstanceEEE
__int64 __fastcall RBX::KeyframeSequenceProvider::registerKeyframeSequence(
        __int64 a1,
        RBX::Instance *a2,
        const boost::shared_ptr<RBX::Instance> *a3)
{
  RBX::DataModel *v5; // rax
  const RBX::Reflection::ClassDescriptor *descriptor; // rbp
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::KeyframeSequence *px; // rdi
  volatile signed __int32 *pi; // r14
  char *v10; // rbp
  char *v11; // r14
  volatile signed __int32 *v12; // rbx
  void *v13; // rdi
  RBX *exception; // rbx
  std::runtime_error *v16; // rbx
  void *ptr[2]; // [rsp+0h] [rbp-168h] BYREF
  __int64 v18; // [rsp+10h] [rbp-158h]
  __int128 v19; // [rsp+20h] [rbp-148h] BYREF
  int *out; // [rsp+30h] [rbp-138h] BYREF
  _QWORD v21[8]; // [rsp+38h] [rbp-130h] BYREF
  __int128 v22; // [rsp+78h] [rbp-F0h]
  void *v23[2]; // [rsp+88h] [rbp-E0h]
  int v24; // [rsp+98h] [rbp-D0h]
  _QWORD v25[18]; // [rsp+A0h] [rbp-C8h] BYREF
  int v26; // [rsp+130h] [rbp-38h]

  v5 = RBX::DataModel::get(a2);
  if ( !v5 || !RBX::DataModel::isInStudio(v5) )
  {
    exception = (RBX *)__cxa_allocate_exception(0x10u);
    RBX::runtime_error(exception, "Usage error: RegisterKeyframeSequence can only be called in Studio.");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  if ( a3->px )
  {
    descriptor = a3->px->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      px = (const RBX::KeyframeSequence *)a3->px;
      pi = (volatile signed __int32 *)a3->pn.pi_;
      if ( pi )
        _InterlockedAdd(pi + 2, 1u);
      if ( px && RBX::KeyframeSequence::isFrozen(px) )
      {
        v16 = (std::runtime_error *)__cxa_allocate_exception(0x10u);
        std::runtime_error::runtime_error(v16, "Unable to register a frozen KeyframeSequence");
        __cxa_throw(
          v16,
          (struct type_info *)&`typeinfo for'std::runtime_error,
          (void (*)(void *))&std::runtime_error::~runtime_error);
      }
      if ( pi )
      {
        if ( !_InterlockedSub(pi + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 16LL))(pi);
          if ( !_InterlockedSub(pi + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)pi + 24LL))(pi);
        }
      }
    }
  }
  v25[0] = &off_2875320;
  v19 = (unsigned __int64)&off_28752F8;
  std::ios_base::init((std::ios_base *)v25, v21);
  v25[17] = 0;
  v26 = -1;
  *(_QWORD *)&v19 = &off_28751B0;
  v25[0] = off_2875200;
  out = &off_28751D8;
  std::streambuf::basic_streambuf(v21);
  v21[0] = &off_28753A8;
  *(_OWORD *)v23 = 0;
  v22 = 0;
  v24 = 24;
  *(_OWORD *)ptr = 0;
  v18 = 0;
  std::vector<boost::shared_ptr<RBX::Instance>>::__push_back_slow_path<boost::shared_ptr<RBX::Instance> const&>(
    (std::vector<boost::shared_ptr<RBX::Instance>> *)ptr,
    a3);
  RBX::SerializerBinary::serialize(&out, ptr, 0, 0);
  RBX::ContentProvider::registerContent(a1, &v19);
  v10 = (char *)ptr[0];
  if ( ptr[0] )
  {
    v11 = (char *)ptr[1];
    if ( ptr[1] == ptr[0] )
    {
      v13 = ptr[0];
    }
    else
    {
      do
      {
        v12 = (volatile signed __int32 *)*((_QWORD *)v11 - 1);
        if ( v12 )
        {
          if ( !_InterlockedSub(v12 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 16LL))(v12);
            if ( !_InterlockedSub(v12 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v12 + 24LL))(v12);
          }
        }
        v11 -= 16;
      }
      while ( v10 != v11 );
      v13 = ptr[0];
    }
    ptr[1] = v10;
    operator delete(v13);
  }
  *(_QWORD *)&v19 = &off_28751B0;
  v25[0] = off_2875200;
  out = &off_28751D8;
  v21[0] = &off_28753A8;
  if ( (v22 & 1) != 0 )
    operator delete(v23[0]);
  std::streambuf::~streambuf(v21);
  std::iostream::~iostream(&v19, off_2875218);
  std::ios::~ios(v25);
  return a1;
}


// Address: 0x1056920 | Name: _ZN3RBX24KeyframeSequenceProvider27getKeyframeSequenceAsyncLuaENS_9ContentIdEN5boost8functionIFvNS2_10shared_ptrINS_8InstanceEEEEEENS3_IFvNSt3__112basic_stringIcNS9_11char_traitsIcEENS9_9allocatorIcEEEEEEE
void __fastcall RBX::KeyframeSequenceProvider::getKeyframeSequenceAsyncLua(
        __int64 a1,
        __int64 a2,
        __int64 *a3,
        __int64 *a4)
{
  __int64 v6; // rax
  __int64 v7; // rax
  volatile signed __int32 *v8; // rbx
  void (__fastcall *v9)(__int128 *, __int128 *, __int64); // rax
  void (__fastcall *v10)(__int128 *, __int128 *, __int64); // rax
  __int128 v11; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int64 v13; // [rsp+18h] [rbp-80h] BYREF
  __int128 v14; // [rsp+20h] [rbp-78h] BYREF
  __int64 v15; // [rsp+30h] [rbp-68h]
  __int64 v16; // [rsp+38h] [rbp-60h] BYREF
  __int128 v17; // [rsp+40h] [rbp-58h] BYREF
  __int64 v18; // [rsp+50h] [rbp-48h]
  _BYTE v19[16]; // [rsp+58h] [rbp-40h] BYREF
  void *v20; // [rsp+68h] [rbp-30h]
  _BYTE v21[8]; // [rsp+70h] [rbp-28h] BYREF
  volatile signed __int32 *v22; // [rsp+78h] [rbp-20h]

  std::string::basic_string(v19, a2);
  ptr = operator new(0x40u);
  v11 = xmmword_3E7A10;
  strcpy((char *)ptr, "KeyframeSequenceProvider:GetKeyframeSequenceAsync()");
  v16 = 0;
  v6 = *a3;
  if ( *a3 )
  {
    v16 = *a3;
    if ( (v6 & 1) != 0 )
    {
      v18 = a3[3];
      v17 = *(_OWORD *)(a3 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v6 & 0xFFFFFFFFFFFFFFFELL))(a3 + 1, &v17, 0);
    }
  }
  v13 = 0;
  v7 = *a4;
  if ( *a4 )
  {
    v13 = *a4;
    if ( (v7 & 1) != 0 )
    {
      v15 = a4[3];
      v14 = *(_OWORD *)(a4 + 1);
    }
    else
    {
      (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v7 & 0xFFFFFFFFFFFFFFFELL))(a4 + 1, &v14, 0);
    }
  }
  RBX::KeyframeSequenceProvider::privateGetKeyframeSequence(v21, a1, v19, 2, &v11, 0, 50.0, &v16, &v13);
  v8 = v22;
  if ( v22 )
  {
    if ( !_InterlockedSub(v22 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(&v14, &v14, 2);
    }
    v13 = 0;
  }
  if ( v16 )
  {
    if ( (v16 & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v16 & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v17, &v17, 2);
    }
    v16 = 0;
  }
  if ( (v11 & 1) != 0 )
    operator delete(ptr);
  if ( (v19[0] & 1) != 0 )
    operator delete(v20);
}


// Address: 0x1056c00 | Name: _ZN3RBX24KeyframeSequenceProvider22getKeyframeSequenceLuaENS_9ContentIdE
_OWORD *__fastcall RBX::KeyframeSequenceProvider::getKeyframeSequenceLua(_OWORD *a1, __int64 a2, __int64 a3)
{
  boost::shared_ptr<RBX::Instance> v3; // rax
  void (__fastcall *v4)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v5)(_BYTE *, _BYTE *, __int64); // rax
  RBX::Instance *v6; // rsi
  volatile signed __int32 *v7; // rbx
  __int128 v9; // [rsp+0h] [rbp-98h] BYREF
  void *ptr; // [rsp+10h] [rbp-88h]
  __int64 v11; // [rsp+20h] [rbp-78h] BYREF
  _BYTE v12[24]; // [rsp+28h] [rbp-70h] BYREF
  __int64 v13; // [rsp+40h] [rbp-58h] BYREF
  _BYTE v14[24]; // [rsp+48h] [rbp-50h] BYREF
  _BYTE v15[16]; // [rsp+60h] [rbp-38h] BYREF
  void *v16; // [rsp+70h] [rbp-28h]
  RBX::Instance *v17; // [rsp+78h] [rbp-20h] BYREF
  volatile signed __int32 *v18; // [rsp+80h] [rbp-18h]

  std::string::basic_string(v15, a3);
  ptr = operator new(0x30u);
  v9 = xmmword_3E4D30;
  strcpy((char *)ptr, "KeyframeSequenceProvider:GetKeyframeSequence()");
  v13 = 0;
  v11 = 0;
  RBX::KeyframeSequenceProvider::privateGetKeyframeSequence(&v17, a2, v15, 3, &v9, 0, 50.0, &v13, &v11);
  if ( v11 )
  {
    if ( (v11 & 1) == 0 )
    {
      v4 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v11 & 0xFFFFFFFFFFFFFFFELL);
      if ( v4 )
        v4(v12, v12, 2);
    }
    v11 = 0;
  }
  if ( v13 )
  {
    if ( (v13 & 1) == 0 )
    {
      v5 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v13 & 0xFFFFFFFFFFFFFFFELL);
      if ( v5 )
        v5(v14, v14, 2);
    }
    v13 = 0;
  }
  if ( (v9 & 1) != 0 )
    operator delete(ptr);
  if ( (v15[0] & 1) != 0 )
    operator delete(v16);
  v6 = v17;
  if ( v17 )
    v3 = RBX::Instance::clone(v17, RBX::CreatorRole::EngineCreator);
  else
    *a1 = 0;
  v7 = v18;
  if ( v18 )
  {
    if ( !_InterlockedSub(v18 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, RBX::Instance *, boost::detail::sp_counted_base *))(*(_QWORD *)v7 + 16LL))(
        v7,
        v6,
        v3.pn.pi_);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  return a1;
}


// Address: 0x1056eb0 | Name: _ZN3RBX24KeyframeSequenceProvider26getKeyframeSequenceByIdLuaElb
_OWORD *__fastcall RBX::KeyframeSequenceProvider::getKeyframeSequenceByIdLua(
        _OWORD *a1,
        RBX::KeyframeSequenceProvider *this,
        int64_t assetId,
        bool useCache)
{
  RBX::ContentProvider *v5; // rbp
  RBX::Instance *parent; // rax
  RBX::KeyframeSequenceProvider *v7; // rbp
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  unsigned __int8 *BaseUrl; // rax
  boost::shared_ptr<RBX::Instance> v11; // rax
  void (__fastcall *v12)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v13)(_BYTE *, _BYTE *, __int64); // rax
  RBX::Instance *v14; // rsi
  volatile signed __int32 *v15; // rbx
  std::runtime_error *exception; // rbp
  __int128 v18; // [rsp+0h] [rbp-D8h] BYREF
  void *ptr; // [rsp+10h] [rbp-C8h]
  __int64 v20; // [rsp+18h] [rbp-C0h] BYREF
  _BYTE v21[24]; // [rsp+20h] [rbp-B8h] BYREF
  __int64 v22; // [rsp+38h] [rbp-A0h] BYREF
  _BYTE v23[24]; // [rsp+40h] [rbp-98h] BYREF
  _BYTE v24[16]; // [rsp+58h] [rbp-80h] BYREF
  void *v25; // [rsp+68h] [rbp-70h]
  RBX::Instance *v26; // [rsp+70h] [rbp-68h] BYREF
  volatile signed __int32 *v27; // [rsp+78h] [rbp-60h]
  _BYTE v28[16]; // [rsp+80h] [rbp-58h] BYREF
  void *v29; // [rsp+90h] [rbp-48h]
  unsigned __int8 v30[16]; // [rsp+98h] [rbp-40h] BYREF
  void *v31; // [rsp+A8h] [rbp-30h]

  if ( assetId <= 0 )
  {
    exception = (std::runtime_error *)__cxa_allocate_exception(0x10u);
    std::runtime_error::runtime_error(exception, "GetKeyframeSequenceById assetId is not a positive number!");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  v5 = 0;
  RBX::format((RBX *)v30, "asset/?id=%lld", assetId);
  if ( this )
  {
    parent = this->parent;
    if ( parent )
    {
      do
      {
        v7 = (RBX::KeyframeSequenceProvider *)parent;
        parent = parent->parent;
      }
      while ( parent );
    }
    else
    {
      v7 = this;
    }
    descriptor = v7->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      v5 = RBX::ServiceProvider::create<RBX::ContentProvider>((const RBX::ServiceProvider *)v7);
    else
      v5 = 0;
  }
  BaseUrl = (unsigned __int8 *)RBX::ContentProvider::getBaseUrl(v5);
  std::operator+<char>((__int64)v28, BaseUrl, v30);
  RBX::ContentId::fromUrl(v24, v28);
  ptr = operator new(0x40u);
  v18 = xmmword_3E5410;
  strcpy((char *)ptr, "KeyframeSequenceProvider:GetKeyframeSequenceById()");
  v22 = 0;
  v20 = 0;
  RBX::KeyframeSequenceProvider::privateGetKeyframeSequence(
    &v26,
    this,
    v24,
    2 * (unsigned int)useCache + 1,
    &v18,
    0,
    50.0,
    &v22,
    &v20);
  if ( v20 )
  {
    if ( (v20 & 1) == 0 )
    {
      v12 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v20 & 0xFFFFFFFFFFFFFFFELL);
      if ( v12 )
        v12(v21, v21, 2);
    }
    v20 = 0;
  }
  if ( v22 )
  {
    if ( (v22 & 1) == 0 )
    {
      v13 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v22 & 0xFFFFFFFFFFFFFFFELL);
      if ( v13 )
        v13(v23, v23, 2);
    }
    v22 = 0;
  }
  if ( (v18 & 1) != 0 )
    operator delete(ptr);
  if ( (v24[0] & 1) != 0 )
    operator delete(v25);
  v14 = v26;
  if ( v26 )
    v11 = RBX::Instance::clone(v26, RBX::CreatorRole::EngineCreator);
  else
    *a1 = 0;
  v15 = v27;
  if ( v27 )
  {
    if ( !_InterlockedSub(v27 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, RBX::Instance *, boost::detail::sp_counted_base *))(*(_QWORD *)v15 + 16LL))(
        v15,
        v14,
        v11.pn.pi_);
      if ( !_InterlockedSub(v15 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
    }
  }
  if ( (v28[0] & 1) != 0 )
    operator delete(v29);
  if ( (v30[0] & 1) != 0 )
    operator delete(v31);
  return a1;
}


// Address: 0x10572e0 | Name: _ZN3RBX24KeyframeSequenceProvider11getMemStatsEv
_OWORD *__fastcall RBX::KeyframeSequenceProvider::getMemStats(_OWORD *a1, RBX::KeyframeSequenceProvider *this)
{
  std::__list_node_base<std::pair<std::string,std::pair<unsigned long,boost::shared_ptr<RBX::KeyframeSequence> > >,void *>::__link_pointer i; // rbp
  int MemSize; // r14d
  std::__tree_iterator<std::__value_type<std::string,int>,std::__tree_node<std::__value_type<std::string,int>,void *> *,long>::__iter_pointer v4; // rax
  std::__list_node_base<std::pair<std::string,std::pair<unsigned long,boost::shared_ptr<RBX::KeyframeSequence> > >,void *>::__link_pointer j; // rbp
  int v6; // r14d
  std::__tree_iterator<std::__value_type<std::string,int>,std::__tree_node<std::__value_type<std::string,int>,void *> *,long>::__iter_pointer v7; // rax
  std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > >::__iter_pointer begin_node; // rbp
  int v9; // r13d
  std::__tree_iterator<std::__value_type<std::string,int>,std::__tree_node<std::__value_type<std::string,int>,void *> *,long>::__iter_pointer v10; // rax
  _QWORD *p_left; // rcx
  RBX::KeyframeSequenceProvider *left; // rax
  __int64 v13; // rbp
  bool v14; // zf
  std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > >::__iter_pointer v15; // r15
  _QWORD *v16; // rbp
  __int64 v17; // rax
  __int128 *v18; // rax
  _QWORD *v19; // rcx
  std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > > *v20; // rax
  __int64 v21; // r15
  _OWORD *v22; // rbx
  std::tuple<> __args; // [rsp+8h] [rbp-F0h] BYREF
  std::tuple<const std::string &> v25[2]; // [rsp+10h] [rbp-E8h] BYREF
  std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > > v26; // [rsp+20h] [rbp-D8h] BYREF
  _OWORD *v27; // [rsp+38h] [rbp-C0h]
  __m128i v28; // [rsp+40h] [rbp-B8h] BYREF
  const RBX::Reflection::Type *v29; // [rsp+50h] [rbp-A8h] BYREF
  __int128 *v30; // [rsp+58h] [rbp-A0h]
  void *ptr[19]; // [rsp+60h] [rbp-98h] BYREF

  v27 = a1;
  ptr[12] = (void *)__readfsqword(0x28u);
  *(_OWORD *)&v26.__pair1_.__value_.__left_ = 0;
  v26.__begin_node_ = &v26.__pair1_.__value_;
  for ( i = this->fullKeyframeSequenceCache.list.__end_.__next_;
        &this->fullKeyframeSequenceCache.list != (RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string> >::List *)i;
        i = i->__next_ )
  {
    std::string::basic_string(&v29, &i[1]);
    MemSize = RBX::KeyframeSequence::getMemSize((const RBX::KeyframeSequence *)i[3].__prev_);
    if ( MemSize > 0 )
    {
      v25[0].__base_.__value_ = (const std::string *)&v29;
      v4 = std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,int>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
             &v26,
             (const std::string *)&v29,
             &stru_4A8BF8,
             v25,
             &__args).first.__ptr_;
      LODWORD(v4[7].__left_) += MemSize;
    }
    if ( ((unsigned __int8)v29 & 1) != 0 )
      operator delete(ptr[0]);
  }
  for ( j = this->frozenKeyframeSequenceCache.list.__end_.__next_;
        &this->frozenKeyframeSequenceCache.list != (RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string> >::List *)j;
        j = j->__next_ )
  {
    std::string::basic_string(&v29, &j[1]);
    v6 = RBX::KeyframeSequence::getMemSize((const RBX::KeyframeSequence *)j[3].__prev_);
    if ( v6 > 0 )
    {
      v25[0].__base_.__value_ = (const std::string *)&v29;
      v7 = std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,int>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
             &v26,
             (const std::string *)&v29,
             &stru_4A8BF8,
             v25,
             &__args).first.__ptr_;
      LODWORD(v7[7].__left_) += v6;
    }
    if ( ((unsigned __int8)v29 & 1) != 0 )
      operator delete(ptr[0]);
  }
  begin_node = this->activeKeyframeTable.__tree_.__begin_node_;
  if ( begin_node != (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > >::__iter_pointer)&this->activeKeyframeTable.__tree_.__pair1_ )
  {
    do
    {
      std::string::basic_string(&v29, &begin_node[4]);
      v9 = RBX::KeyframeSequence::getMemSize((const RBX::KeyframeSequence *)begin_node[7].__left_);
      if ( v9 > 0 )
      {
        v25[0].__base_.__value_ = (const std::string *)&v29;
        v10 = std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,int>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
                &v26,
                (const std::string *)&v29,
                &stru_4A8BF8,
                v25,
                &__args).first.__ptr_;
        LODWORD(v10[7].__left_) += v9;
      }
      if ( ((unsigned __int8)v29 & 1) != 0 )
        operator delete(ptr[0]);
      p_left = &begin_node[1].__left_->__left_;
      if ( p_left )
      {
        do
        {
          left = (RBX::KeyframeSequenceProvider *)p_left;
          p_left = (_QWORD *)*p_left;
        }
        while ( p_left );
      }
      else
      {
        left = (RBX::KeyframeSequenceProvider *)begin_node[2].__left_;
        if ( (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > >::__iter_pointer)left->_vptr$EventSource != begin_node )
        {
          v13 = (__int64)&begin_node[2];
          do
          {
            left = *(RBX::KeyframeSequenceProvider **)(*(_QWORD *)v13 + 16LL);
            v14 = left->_vptr$EventSource == *(int (***)(void))v13;
            v13 = *(_QWORD *)v13 + 16LL;
          }
          while ( !v14 );
        }
      }
      begin_node = (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > >::__iter_pointer)left;
    }
    while ( left != (RBX::KeyframeSequenceProvider *)&this->activeKeyframeTable.__tree_.__pair1_ );
  }
  boost::make_shared<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>>>();
  v15 = v26.__begin_node_;
  if ( (std::__compressed_pair<std::__tree_end_node<std::__tree_node_base<void *> *>> *)v26.__begin_node_ != &v26.__pair1_ )
  {
    v28 = _mm_unpacklo_epi64(
            (__m128i)(unsigned __int64)rbx::implementation::typed_holder<int>::construct_func,
            (__m128i)(unsigned __int64)rbx::implementation::typed_holder<int>::moveConstruct_func);
    do
    {
      v29 = RBX::Reflection::Type::getSingleton<int>();
      v30 = 0;
      LODWORD(ptr[0]) = v15[7].__left_;
      if ( !(_BYTE)byte_29F1EC8 && __cxa_guard_acquire(&byte_29F1EC8) )
      {
        xmmword_29F1EB0 = (__int128)_mm_load_si128(&v28);
        qword_29F1EC0 = (__int64)rbx::implementation::typed_holder<int>::destruct_func;
        __cxa_guard_release(&byte_29F1EC8);
      }
      v30 = &xmmword_29F1EB0;
      v16 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>>>::operator[](
              (boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,RBX::Reflection::Variant> >,std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string > > > *)v25[0].__base_.__value_,
              &v15[4]);
      v16[3] = v29;
      if ( &v29 != v16 + 3 )
      {
        v17 = v16[4];
        if ( v17 )
        {
          (*(void (__fastcall **)(_QWORD *))(v17 + 16))(v16 + 5);
          v16[4] = 0;
        }
        if ( v30 )
        {
          (*((void (__fastcall **)(void **, _QWORD *))v30 + 1))(ptr, v16 + 5);
          v18 = v30;
          v16[4] = v30;
          if ( v18 )
          {
            (*((void (__fastcall **)(void **))v18 + 2))(ptr);
            v30 = 0;
          }
        }
      }
      v29 = RBX::Reflection::Type::getSingleton<void>();
      if ( v30 )
      {
        (*((void (__fastcall **)(void **))v30 + 2))(ptr);
        v30 = 0;
      }
      v19 = &v15[1].__left_->__left_;
      if ( v19 )
      {
        do
        {
          v20 = (std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > > *)v19;
          v19 = (_QWORD *)*v19;
        }
        while ( v19 );
      }
      else
      {
        v20 = (std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > > *)v15[2].__left_;
        if ( v20->__begin_node_ != v15 )
        {
          v21 = (__int64)&v15[2];
          do
          {
            v20 = *(std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > > **)(*(_QWORD *)v21 + 16LL);
            v14 = v20->__begin_node_ == *(std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > >::__iter_pointer *)v21;
            v21 = *(_QWORD *)v21 + 16LL;
          }
          while ( !v14 );
        }
      }
      v15 = (std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > >::__iter_pointer)v20;
    }
    while ( v20 != (std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > > *)&v26.__pair1_ );
  }
  v22 = v27;
  *v27 = *(_OWORD *)&v25[0].__base_.__value_;
  std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,int>>>::destroy(
    &v26,
    (std::__tree<std::__value_type<std::string,int>,std::__map_value_compare<std::string,std::__value_type<std::string,int>,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,int> > >::__node_pointer)v26.__pair1_.__value_.__left_);
  return v22;
}


// Address: 0x1057780 | Name: _ZN3RBX24KeyframeSequenceProvider13getAnimationsElN5boost8functionIFvNS1_10shared_ptrINS_8InstanceEEEEEENS2_IFvNSt3__112basic_stringIcNS8_11char_traitsIcEENS8_9allocatorIcEEEEEEE
void __fastcall RBX::KeyframeSequenceProvider::getAnimations(
        RBX::KeyframeSequenceProvider *this,
        int64_t userId,
        __int64 *a3,
        __int64 *a4)
{
  RBX::DataModel *v6; // rax
  boost::shared_ptr<RBX::InventoryPages> v7; // rax
  __int128 v8; // kr00_16
  boost::detail::sp_counted_base *pi; // rdi
  __int64 v10; // rax
  __int64 v11; // rax
  void (__fastcall *v12)(char *, char *, __int64); // rax
  void (__fastcall *v13)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  boost::detail::sp_counted_base *v14; // rbx
  void (__fastcall *v15)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v16; // rbx
  void (__fastcall *v17)(_QWORD *, _QWORD *, __int64); // rax
  boost::_bi::bind_t<boost::_bi::unspecified,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Pages> > > >_0 v18; // [rsp+0h] [rbp-138h] BYREF
  _QWORD v19[4]; // [rsp+30h] [rbp-108h] BYREF
  __int128 a1; // [rsp+50h] [rbp-E8h] BYREF
  __int128 v21; // [rsp+60h] [rbp-D8h] BYREF
  void *v22; // [rsp+70h] [rbp-C8h]
  __int128 v23; // [rsp+80h] [rbp-B8h] BYREF
  void *ptr; // [rsp+90h] [rbp-A8h]
  __int128 v25; // [rsp+A0h] [rbp-98h]
  boost::function<void ()>_0 v26; // [rsp+B0h] [rbp-88h] BYREF
  __int64 v27; // [rsp+D0h] [rbp-68h] BYREF
  boost::_bi::bind_t<boost::_bi::unspecified,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Pages> > > >_0 v28; // [rsp+D8h] [rbp-60h] BYREF
  boost::weak_ptr<RBX::DataModel> args; // [rsp+108h] [rbp-30h] BYREF

  v27 = userId;
  if ( userId <= 0 )
  {
    ptr = operator new(0x50u);
    v23 = *(_OWORD *)&stru_3EAB50.vtable;
    strcpy((char *)ptr, "KeyframeSequenceProvider:GetAnimations userId is not a positive number!");
    boost::function1<void,std::string>::operator()(a4, &v23);
    if ( (v23 & 1) != 0 )
      operator delete(ptr);
  }
  else
  {
    v6 = RBX::DataModel::get(this);
    if ( v6 )
    {
      RBX::weak_from<RBX::DataModel>(&args, v6);
      HIDWORD(v18.f_.functor.bound_memfunc_ptr.memfunc_ptr) = 24;
      v7 = RBX::Creatable<RBX::Instance>::create<RBX::InventoryPages,boost::weak_ptr<RBX::DataModel>,long &,int>(
             &args,
             &v27,
             (int *)&v18.f_.functor.bound_memfunc_ptr.memfunc_ptr + 1);
      v8 = v25;
      v25 = 0;
      pi = args.pn.pi_;
      if ( args.pn.pi_ && !_InterlockedSub(&args.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *, boost::weak_ptr<RBX::DataModel> *, boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base
         + 3))(
          pi,
          &args,
          v7.pn.pi_);
      v19[0] = 0;
      v10 = *a3;
      if ( *a3 )
      {
        v19[0] = *a3;
        if ( (v10 & 1) != 0 )
        {
          v19[3] = a3[3];
          *(_OWORD *)&v19[1] = *(_OWORD *)(a3 + 1);
        }
        else
        {
          (*(void (__fastcall **)(__int64 *, _QWORD *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))(a3 + 1, &v19[1], 0);
        }
      }
      a1 = v8;
      if ( *((_QWORD *)&v8 + 1) )
        _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v8 + 1) + 8LL), 1u);
      boost::bind<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::shared_ptr<RBX::Pages>>(
        &v28,
        v18.f_,
        (boost::shared_ptr<RBX::Pages>)__PAIR128__(&a1, v19));
      boost::function<void ()(void)>::function<boost::_bi::bind_t<boost::_bi::unspecified,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::_bi::list1<boost::_bi::value<boost::shared_ptr<RBX::Pages>>>>>(
        &v26,
        v18,
        (boost::enable_if_c<true,int>::type)&v28);
      *((_QWORD *)&v18.f_.functor.data + 1) = 0;
      v11 = *a4;
      if ( *a4 )
      {
        *((_QWORD *)&v18.f_.functor.data + 1) = *a4;
        if ( (v11 & 1) != 0 )
        {
          v18.l_.a1_.t_.pn.pi_ = (boost::detail::sp_counted_base *)a4[3];
          *((_OWORD *)&v18.f_.functor.data + 1) = *(_OWORD *)(a4 + 1);
        }
        else
        {
          (*(void (__fastcall **)(__int64 *, char *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(
            a4 + 1,
            &v18.f_.functor.data + 16,
            0);
        }
      }
      (*(void (__fastcall **)(_QWORD, boost::function<void ()>_0 *, bool *))(*(_QWORD *)v8 + 304LL))(
        v8,
        &v26,
        &v18.f_.functor.type.const_qualified);
      if ( *((_QWORD *)&v18.f_.functor.data + 1) )
      {
        if ( !v18.f_.functor.type.const_qualified )
        {
          v12 = *(void (__fastcall **)(char *, char *, __int64))(*((_QWORD *)&v18.f_.functor.data + 1)
                                                               & 0xFFFFFFFFFFFFFFFELL);
          if ( v12 )
            v12(&v18.f_.functor.data + 16, &v18.f_.functor.data + 16, 2);
        }
        *((_QWORD *)&v18.f_.functor.data + 1) = 0;
      }
      if ( v26.vtable )
      {
        if ( ((__int64)v26.vtable & 1) == 0 )
        {
          v13 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v26.vtable & 0xFFFFFFFFFFFFFFFELL);
          if ( v13 )
            v13(&v26.functor, &v26.functor, 2);
        }
        v26.vtable = 0;
      }
      v14 = v28.l_.a1_.t_.pn.pi_;
      if ( v28.l_.a1_.t_.pn.pi_ )
      {
        if ( !_InterlockedSub(&v28.l_.a1_.t_.pn.pi_->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 2))(v14);
          if ( !_InterlockedSub(&v14->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
        }
      }
      if ( v28.f_.vtable )
      {
        if ( ((__int64)v28.f_.vtable & 1) == 0 )
        {
          v15 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v28.f_.vtable & 0xFFFFFFFFFFFFFFFELL);
          if ( v15 )
            v15(&v28.f_.functor, &v28.f_.functor, 2);
        }
        v28.f_.vtable = 0;
      }
      v16 = (volatile signed __int32 *)*((_QWORD *)&a1 + 1);
      if ( *((_QWORD *)&a1 + 1) )
      {
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&a1 + 1) + 8LL), 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
          if ( !_InterlockedSub(v16 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
        }
      }
      if ( v19[0] )
      {
        if ( (v19[0] & 1) == 0 )
        {
          v17 = *(void (__fastcall **)(_QWORD *, _QWORD *, __int64))(v19[0] & 0xFFFFFFFFFFFFFFFELL);
          if ( v17 )
            v17(&v19[1], &v19[1], 2);
        }
        v19[0] = 0;
      }
      if ( *((_QWORD *)&v8 + 1) && !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v8 + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v8 + 1) + 16LL))(*((_QWORD *)&v8 + 1));
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v8 + 1) + 12LL), 1u) )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v8 + 1) + 24LL))(*((_QWORD *)&v8 + 1));
      }
    }
    else
    {
      v22 = operator new(0x20u);
      v21 = *(_OWORD *)&errorFunction.vtable;
      strcpy((char *)v22, "Unable to access DataModel");
      boost::function1<void,std::string>::operator()(a4, &v21);
      if ( (v21 & 1) != 0 )
        operator delete(v22);
    }
  }
}


// Address: 0x1057dd0 | Name: _ZN3RBX24KeyframeSequenceProviderC2Ev
void __fastcall RBX::KeyframeSequenceProvider::KeyframeSequenceProvider(RBX::KeyframeSequenceProvider *this)
{
  RBX::Instance::Instance(this);
  this->isPublic = 1;
  this->_vptr$EventSource = (int (**)(void))&off_2890208;
  this->descriptor = Class_getDescriptorPtr(this);
  this->_vptr$EventSource = (int (**)(void))off_288FDB8;
  this->activeKeyframeId = 0;
  *(_OWORD *)&this->activeKeyframeTable.__tree_.__pair1_.__value_.__left_ = 0;
  this->activeKeyframeTable.__tree_.__begin_node_ = &this->activeKeyframeTable.__tree_.__pair1_.__value_;
  boost::mutex::mutex(&this->keyframeSequenceCacheMutex);
  this->fullKeyframeSequenceCache.list.__end_.__prev_ = &this->fullKeyframeSequenceCache.list.__end_;
  this->fullKeyframeSequenceCache.list.__end_.__next_ = &this->fullKeyframeSequenceCache.list.__end_;
  this->fullKeyframeSequenceCache.list.__size_alloc_.__value_ = 0;
  this->fullKeyframeSequenceCache.index.table_.current_ = 0;
  *(_OWORD *)&this->fullKeyframeSequenceCache.index.table_.bucket_count_ = 0x10u;
  this->fullKeyframeSequenceCache.index.table_.mlf_ = 1.0;
  *(_OWORD *)&this->fullKeyframeSequenceCache.index.table_.max_load_ = 0;
  this->fullKeyframeSequenceCache.totalMemory = 0;
  this->fullKeyframeSequenceCache._vptr$LRUCache = (int (**)(void))&off_2890178;
  this->fullKeyframeSequenceCache.maxSize = 100;
  this->frozenKeyframeSequenceCache.list.__end_.__prev_ = &this->frozenKeyframeSequenceCache.list.__end_;
  this->frozenKeyframeSequenceCache.list.__end_.__next_ = &this->frozenKeyframeSequenceCache.list.__end_;
  this->frozenKeyframeSequenceCache.list.__size_alloc_.__value_ = 0;
  this->frozenKeyframeSequenceCache.index.table_.current_ = 0;
  *(_OWORD *)&this->frozenKeyframeSequenceCache.index.table_.bucket_count_ = 0x10u;
  this->frozenKeyframeSequenceCache.index.table_.mlf_ = 1.0;
  *(_OWORD *)&this->frozenKeyframeSequenceCache.index.table_.max_load_ = 0;
  this->frozenKeyframeSequenceCache.totalMemory = 0;
  this->frozenKeyframeSequenceCache._vptr$LRUCache = (int (**)(void))&off_2890178;
  this->frozenKeyframeSequenceCache.maxSize = 100;
}


// Address: 0x1057f40 | Name: _ZN3RBX24KeyframeSequenceProvider26privateGetKeyframeSequenceENS_9ContentIdEjRKNSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEPKNS_8InstanceEfN5boost8functionIFvNSE_10shared_ptrISB_EEEEENSF_IFvS8_EEE
boost::detail::sp_counted_base *__fastcall RBX::KeyframeSequenceProvider::privateGetKeyframeSequence(
        boost::detail::sp_counted_base *a1,
        __int64 a2,
        const std::string *a3,
        int a4,
        unsigned __int8 *a5,
        const RBX::Instance *a6,
        float a7,
        float a8,
        boost::function1<void,boost::shared_ptr<RBX::Instance> >_0 *a9,
        __int64 *a10)
{
  boost::function1<void,boost::shared_ptr<RBX::Instance> >_0 *v14; // r15
  std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > > *v15; // rbp
  std::pair<std::__tree_iterator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__tree_node<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,void *> *,long>,bool> v16; // rax
  boost::detail::sp_counted_base *pi; // rbx
  std::__tree_iterator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__tree_node<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,void *> *,long>::__iter_pointer v18; // rax
  const RBX::Instance *v19; // r15
  const RBX::ServiceProvider *v20; // rax
  int v21; // r13d
  const RBX::ServiceProvider *v22; // rbp
  __int128 *p_keyframeSequence; // rsi
  std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > > *v24; // rbp
  std::pair<std::__tree_iterator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__tree_node<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,void *> *,long>,bool> v25; // rax
  boost::detail::sp_counted_base *v26; // rbx
  boost::detail::sp_counted_base *v27; // r14
  std::__tree_end_node<std::__tree_node_base<void *> *>::pointer left; // rax
  __int64 v29; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  unsigned int v31; // ecx
  RBX::ContentProvider *v32; // rax
  RBX::ContentProvider *v33; // rbp
  const std::string *BaseUrl; // rax
  const char *v35; // rdx
  const char *v36; // rcx
  void (__fastcall *v37)(boost::function1<void,std::string >::dummy *); // rcx
  bool v38; // al
  unsigned __int64 v39; // rdx
  void *v40; // rcx
  size_t v41; // r8
  const void *v42; // r9
  const RBX::ServiceProvider *v43; // rax
  const RBX::ServiceProvider *v44; // rbp
  boost::shared_ptr<RBX::KeyframeSequence> v45; // rax
  __int128 v46; // xmm0
  volatile signed __int32 *v47; // rbp
  volatile signed __int32 *v48; // rbp
  size_t v49; // rsi
  int v50; // ebx
  size_t v51; // rsi
  const RBX::ServiceProvider *v52; // rax
  const RBX::ServiceProvider *v53; // rbp
  __int64 v54; // rbx
  RBX::Reflection::ClassDescriptor *v55; // rax
  RBX::ContentProvider *v56; // rbp
  const std::string *AssetTypeAnimation; // rax
  boost::detail::sp_counted_base *v58; // rbp
  __int64 v59; // rax
  int v60; // ebx
  unsigned __int64 v61; // rax
  RBX::DataModel *v62; // rax
  std::istream *v63; // rcx
  boost::detail::function::vtable_base *v64; // rax
  __int64 v65; // rax
  char *v66; // rbp
  __int64 v67; // rax
  __int64 v68; // rax
  __int64 v69; // rax
  void (__fastcall *v70)(__int128 *, __int128 *, __int64); // rax
  __int64 v71; // rdi
  volatile signed __int32 *v72; // rbx
  void (__fastcall *v73)(__int128 *, __int128 *, __int64); // rax
  __int64 v74; // rdi
  volatile signed __int32 *v75; // rbx
  void (__fastcall *v76)(__int128 *, __int128 *, __int64); // rax
  __int64 v77; // rdi
  boost::detail::sp_counted_base *v78; // rbx
  void (__fastcall *v79)(__int128 *, __int128 *, __int64); // rax
  __int64 v80; // rdi
  volatile signed __int32 *v81; // rbx
  void (__fastcall *v82)(__int128 *, __int128 *, __int64); // rax
  __int64 v83; // rdi
  volatile signed __int32 *v84; // rbx
  void (__fastcall *v85)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v86)(__int128 *, __int128 *, __int64); // rax
  __int64 v87; // rdi
  volatile signed __int32 *v88; // rbx
  void (__fastcall *v89)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v90; // rdi
  volatile signed __int32 *v91; // rbx
  unsigned __int64 v92; // rax
  char v93; // bl
  std::istream *px; // rcx
  char *v95; // rbp
  __int64 v96; // rax
  __int64 v97; // rax
  void (__fastcall *v98)(_BYTE *, _BYTE *, __int64); // rax
  __int64 v99; // rdi
  void (__fastcall *v100)(__int128 *, __int128 *, __int64); // rax
  __int64 v101; // rdi
  void (__fastcall *v102)(__int128 *, __int128 *, __int64); // rax
  boost::detail::sp_counted_base *v103; // rdi
  void (__fastcall *v104)(__int128 *, __int128 *, __int64); // rax
  boost::detail::sp_counted_base *v105; // rdi
  void (__fastcall *v106)(__int128 *, __int128 *, __int64); // rax
  boost::detail::sp_counted_base *v107; // rdi
  void (__fastcall *v108)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v109)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v110; // rdi
  void (__fastcall *v111)(__int128 *, __int128 *, __int64); // rax
  volatile signed __int32 *v112; // rdi
  const RBX::ServiceProvider *v113; // rax
  const RBX::ServiceProvider *v114; // rbx
  const RBX::ServiceProvider *v115; // rax
  const RBX::ServiceProvider *v116; // rbx
  void (__fastcall *v117)(__int128 *, __int128 *, __int64); // rax
  boost::detail::sp_counted_base v118; // xmm0
  __int64 v119; // rbp
  RBX::Reflection::ClassDescriptor *v120; // rax
  RBX::ContentProvider *v121; // rbx
  const std::string *v122; // rax
  std::istream *v123; // r14
  std::istream *v124; // rbx
  volatile signed __int32 *v125; // rbp
  boost::weak_ptr<RBX::KeyframeSequenceProvider> v126; // rdx
  boost::weak_ptr<RBX::KeyframeSequence> v127; // r8
  void (__fastcall *v128)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v129)(_BYTE *, _BYTE *, __int64); // rax
  boost::detail::sp_counted_base *v130; // rdi
  void (__fastcall *v131)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v132)(boost::function<void (std::string)>_0 *, boost::function<void (std::string)>_0 *, __int64); // rax
  boost::detail::sp_counted_base *v133; // rdi
  volatile signed __int32 *v134; // rbx
  __int64 v135; // rbp
  RBX::Reflection::ClassDescriptor *v136; // rax
  RBX::ContentProvider *v137; // rbp
  const std::string *v138; // rax
  void (__fastcall *v139)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v140)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v141)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v142)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v143)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __int64 v144; // rdi
  __int64 v145; // rdi
  __int64 v146; // rax
  volatile signed __int32 *v147; // rdi
  void (__fastcall *v148)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  void (__fastcall *v149)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  volatile signed __int32 *v150; // rbx
  __int64 v152; // rbx
  RBX::Reflection::ClassDescriptor *v153; // rax
  RBX::ContentProvider *v154; // rdi
  void *exception; // r15
  char *v156; // r14
  void *v157; // rbp
  void *v158; // r14
  char *v159; // rdx
  _BYTE v160[64]; // [rsp-8h] [rbp-5A0h] BYREF
  __int128 v161; // [rsp+38h] [rbp-560h] BYREF
  __int64 v162; // [rsp+48h] [rbp-550h]
  __int128 keyframeSequence; // [rsp+50h] [rbp-548h] BYREF
  void *v164; // [rsp+60h] [rbp-538h]
  _BYTE v165[24]; // [rsp+70h] [rbp-528h] BYREF
  __int128 v166; // [rsp+88h] [rbp-510h] BYREF
  __int128 v167; // [rsp+98h] [rbp-500h] BYREF
  __int64 v168; // [rsp+A8h] [rbp-4F0h]
  boost::weak_ptr<RBX::KeyframeSequenceProvider> v169; // [rsp+B0h] [rbp-4E8h] BYREF
  void *ptr; // [rsp+C0h] [rbp-4D8h]
  __int128 v171; // [rsp+C8h] [rbp-4D0h] BYREF
  __int128 v172; // [rsp+D8h] [rbp-4C0h] BYREF
  __int64 v173; // [rsp+E8h] [rbp-4B0h]
  int v174; // [rsp+F0h] [rbp-4A8h]
  float updatedPriority; // [rsp+F4h] [rbp-4A4h]
  std::istream *keyframeSequenceProvider; // [rsp+F8h] [rbp-4A0h] BYREF
  boost::detail::sp_counted_base *v177; // [rsp+100h] [rbp-498h]
  void *v178; // [rsp+108h] [rbp-490h]
  __int128 v179; // [rsp+110h] [rbp-488h] BYREF
  __int128 v180; // [rsp+120h] [rbp-478h] BYREF
  __int64 v181; // [rsp+130h] [rbp-468h]
  std::istream *stream; // [rsp+138h] [rbp-460h]
  boost::detail::sp_counted_base *v183; // [rsp+140h] [rbp-458h]
  unsigned __int64 v184; // [rsp+148h] [rbp-450h]
  __int128 v185; // [rsp+150h] [rbp-448h] BYREF
  __int128 v186; // [rsp+160h] [rbp-438h] BYREF
  __int64 v187; // [rsp+170h] [rbp-428h]
  std::istream *v188; // [rsp+178h] [rbp-420h]
  volatile signed __int32 *v189; // [rsp+180h] [rbp-418h]
  unsigned __int64 v190; // [rsp+188h] [rbp-410h]
  __int128 v191; // [rsp+190h] [rbp-408h] BYREF
  __int128 v192; // [rsp+1A0h] [rbp-3F8h] BYREF
  __int64 v193; // [rsp+1B0h] [rbp-3E8h]
  boost::function1<void,boost::shared_ptr<RBX::Instance> >_0 v194; // [rsp+1B8h] [rbp-3E0h] BYREF
  RBX::Instance v195; // [rsp+1D8h] [rbp-3C0h] BYREF
  volatile signed __int32 *v196; // [rsp+258h] [rbp-340h]
  unsigned __int64 v197; // [rsp+260h] [rbp-338h]
  __int128 v198; // [rsp+268h] [rbp-330h] BYREF
  __int64 v199; // [rsp+278h] [rbp-320h]
  boost::function1<void,std::string >_0 v200; // [rsp+280h] [rbp-318h] BYREF
  boost::function1<void,boost::shared_ptr<RBX::Instance> >_0 other; // [rsp+2A0h] [rbp-2F8h] BYREF
  boost::detail::function::vtable_base *v202; // [rsp+2C0h] [rbp-2D8h]
  boost::detail::function::function_buffer functor; // [rsp+2C8h] [rbp-2D0h] BYREF
  boost::detail::function::vtable_base *vtable; // [rsp+2E0h] [rbp-2B8h]
  boost::function<void (std::string)>_0 errorFunction; // [rsp+2E8h] [rbp-2B0h] BYREF
  volatile signed __int32 *v206; // [rsp+308h] [rbp-290h]
  rbx::signals::slot_base *v207; // [rsp+310h] [rbp-288h]
  volatile signed __int32 *v208; // [rsp+318h] [rbp-280h]
  boost::detail::function::vtable_base *v209; // [rsp+320h] [rbp-278h]
  __int128 v210; // [rsp+328h] [rbp-270h] BYREF
  void *obj_ptr; // [rsp+338h] [rbp-260h]
  rbx::signals::slot_base *v212; // [rsp+340h] [rbp-258h] BYREF
  volatile signed __int32 *v213; // [rsp+348h] [rbp-250h]
  __int64 v214; // [rsp+350h] [rbp-248h] BYREF
  __int128 v215; // [rsp+358h] [rbp-240h] BYREF
  __int64 v216; // [rsp+368h] [rbp-230h]
  boost::detail::function::vtable_base *v217; // [rsp+370h] [rbp-228h] BYREF
  boost::detail::function::function_buffer v218; // [rsp+378h] [rbp-220h] BYREF
  boost::detail::function::vtable_base *v219; // [rsp+390h] [rbp-208h] BYREF
  boost::detail::function::function_buffer v220; // [rsp+398h] [rbp-200h] BYREF
  __int64 v221; // [rsp+3B0h] [rbp-1E8h] BYREF
  __int64 v222; // [rsp+3B8h] [rbp-1E0h]
  boost::weak_ptr<RBX::KeyframeSequenceProvider> v223; // [rsp+3C0h] [rbp-1D8h]
  boost::shared_ptr<RBX::Instance> v224; // [rsp+3D0h] [rbp-1C8h] BYREF
  boost::shared_ptr<RBX::Instance> v225; // [rsp+3E0h] [rbp-1B8h] BYREF
  boost::shared_ptr<RBX::Instance> a0; // [rsp+3F0h] [rbp-1A8h] BYREF
  _BYTE v227[16]; // [rsp+400h] [rbp-198h] BYREF
  void *v228; // [rsp+410h] [rbp-188h]
  char v229[16]; // [rsp+418h] [rbp-180h] BYREF
  void *v230; // [rsp+428h] [rbp-170h]
  char v231[16]; // [rsp+430h] [rbp-168h] BYREF
  void *v232; // [rsp+440h] [rbp-158h]
  int v233; // [rsp+448h] [rbp-150h]
  unsigned __int8 *v234; // [rsp+450h] [rbp-148h]
  _BYTE v235[16]; // [rsp+458h] [rbp-140h] BYREF
  void *v236; // [rsp+468h] [rbp-130h]
  char v237[8]; // [rsp+470h] [rbp-128h] BYREF
  __int64 v238; // [rsp+478h] [rbp-120h]
  __int128 v239; // [rsp+480h] [rbp-118h] BYREF
  void *v240; // [rsp+490h] [rbp-108h]
  char v241[8]; // [rsp+498h] [rbp-100h] BYREF
  char v242[136]; // [rsp+4A0h] [rbp-F8h] BYREF
  __int64 v243; // [rsp+528h] [rbp-70h]
  _BYTE v244[24]; // [rsp+530h] [rbp-68h] BYREF
  __int64 v245; // [rsp+548h] [rbp-50h]
  _BYTE v246[72]; // [rsp+550h] [rbp-48h] BYREF

  updatedPriority = a7;
  v234 = a5;
  v195.children.object.pn.pi_ = a1;
  v14 = a9;
  keyframeSequence = 0;
  v164 = 0;
  if ( stru_2A03C58.value )
  {
    if ( RBX::AnimationId::isActiveContentId(a3) )
    {
      v15 = (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > > *)(a2 + 136);
      if ( std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::find<std::string>(
             (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > > *)(a2 + 136),
             a3).__ptr_ == (std::__tree_iterator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__tree_node<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,void *> *,long>::__iter_pointer)(a2 + 144) )
      {
        exception = __cxa_allocate_exception(0x10u);
        if ( (*(_BYTE *)a3 & 1) != 0 )
          v156 = (char *)*((_QWORD *)a3 + 2);
        else
          v156 = (char *)a3 + 1;
        RBX::format((RBX *)&v195, (const char *)&stru_3F7F76.combinedSignal.head.px + 1, v156);
        std::runtime_error::runtime_error(exception, &v195);
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'std::runtime_error,
          (void (*)(void *))&std::runtime_error::~runtime_error);
      }
      if ( a9->vtable )
      {
        v195._vptr$EventSource = (int (**)(void))a3;
        v16 = std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
                v15,
                a3,
                &stru_4A8BF8,
                (std::tuple<const std::string &> *)&v195,
                (std::tuple<> *)&v160[24]);
        a0.px = (boost::shared_ptr<RBX::Instance>::element_type *)v16.first.__ptr_[7].__left_;
        v16.first.__ptr_ = v16.first.__ptr_[8].__left_;
        a0.pn.pi_ = (boost::detail::sp_counted_base *)v16.first.__ptr_;
        if ( v16.first.__ptr_ )
          _InterlockedAdd((volatile signed __int32 *)&v16.first.__ptr_[1], 1u);
        boost::function1<void,boost::shared_ptr<RBX::Instance>>::operator()(
          a9,
          (boost::shared_ptr<RBX::Instance>)__PAIR128__(*(unsigned __int64 *)&v16.second, &a0));
        pi = a0.pn.pi_;
        if ( a0.pn.pi_ )
        {
          if ( !_InterlockedSub(&a0.pn.pi_->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
            if ( !_InterlockedSub(&pi->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
          }
        }
      }
      v195._vptr$EventSource = (int (**)(void))a3;
      v18 = std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
              v15,
              a3,
              &stru_4A8BF8,
              (std::tuple<const std::string &> *)&v195,
              (std::tuple<> *)&v160[24]).first.__ptr_;
      goto LABEL_30;
    }
    v19 = a6;
    std::string::basic_string(&v195, a3);
    memset(&v160[24], 0, 24);
    if ( a2 )
    {
      v20 = *(const RBX::ServiceProvider **)(a2 + 88);
      if ( v20 )
      {
        v21 = a4;
        do
        {
          v22 = v20;
          v20 = (const RBX::ServiceProvider *)*((_QWORD *)v20 + 11);
        }
        while ( v20 );
      }
      else
      {
        v22 = (const RBX::ServiceProvider *)a2;
        v21 = a4;
      }
      v29 = *((_QWORD *)v22 + 3);
      DescriptorPtr = Class_getDescriptorPtr(0);
      v31 = *(unsigned __int16 *)(v29 + 726) - *((unsigned __int16 *)DescriptorPtr + 363);
      a4 = v21;
      if ( v31 <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        v32 = RBX::ServiceProvider::create<RBX::ContentProvider>(v22);
        v33 = v32;
        a4 = v21;
        if ( v32 )
        {
          BaseUrl = RBX::ContentProvider::getBaseUrl(v32);
          a4 = v21;
          if ( animationConvertToTrivialAssetId(BaseUrl, (RBX::ContentId *)&v195) )
          {
            a4 = v21;
            if ( RBX::ContentProvider::formatAssetIdWithServerPlaceId(
                   v33,
                   (RBX::ContentId *)&v195,
                   (std::string *)&v160[24]) )
            {
              goto LABEL_54;
            }
          }
        }
      }
    }
    std::string::basic_string(&keyframeSequenceProvider, a3);
    RBX::sanitizeAnimationIdNonStudio((RBX *)&v169, (const RBX::AnimationId *)&keyframeSequenceProvider);
    if ( ((__int64)v169.px & 1) != 0 )
    {
      v35 = (const char *)ptr;
      if ( (v160[24] & 1) == 0 )
      {
LABEL_40:
        v36 = &v160[25];
LABEL_43:
        RBX::format((RBX *)v165, "Invalid animation id '%s': %s", v35, v36);
        if ( ((__int64)v169.px & 1) != 0 )
          operator delete(ptr);
        if ( ((unsigned __int8)keyframeSequenceProvider & 1) != 0 )
          operator delete(v178);
        v37 = boost::function1<void,std::string>::dummy::nonnull;
        if ( !*a10 )
          v37 = 0;
        if ( !v37 )
        {
          v157 = __cxa_allocate_exception(0x10u);
          std::runtime_error::runtime_error(v157, v165);
          __cxa_throw(
            v157,
            (struct type_info *)&`typeinfo for'std::runtime_error,
            (void (*)(void *))&std::runtime_error::~runtime_error);
        }
        std::string::basic_string(&v239, v165);
        boost::function1<void,std::string>::operator()(a10, &v239);
        if ( (v239 & 1) != 0 )
          operator delete(v240);
        if ( (v165[0] & 1) != 0 )
          operator delete(*(void **)&v165[16]);
LABEL_54:
        std::string::basic_string(v165, &v195);
        if ( (keyframeSequence & 1) != 0 )
        {
          *(_BYTE *)v164 = 0;
          *((_QWORD *)&keyframeSequence + 1) = 0;
        }
        else
        {
          LOWORD(keyframeSequence) = 0;
        }
        p_keyframeSequence = 0;
        std::string::reserve(&keyframeSequence, 0);
        a6 = v19;
        v164 = *(void **)&v165[16];
        keyframeSequence = *(_OWORD *)v165;
        v14 = a9;
        if ( (v160[24] & 1) != 0 )
          operator delete(*(void **)&v160[40]);
        if ( ((__int64)v195._vptr$EventSource & 1) != 0 )
          operator delete(v195.weak_this_.pn.pi_);
LABEL_61:
        *(_OWORD *)&v160[8] = 0;
        v195._vptr$EventSource = (int (**)(void))(a2 + 160);
        LOBYTE(v195.weak_this_.px) = 0;
        boost::unique_lock<boost::mutex>::lock((boost::unique_lock<boost::mutex> *)&v195);
        v27 = v195.children.object.pn.pi_;
        v174 = a4;
        if ( (a4 & 2) != 0
          && ((a4 & 4) != 0
           && (*(_QWORD *)&v160[24] = 0,
               RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::fetch(
                 (RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string> > *)(a2 + 296),
                 (const std::string *)&keyframeSequence,
                 (boost::shared_ptr<RBX::KeyframeSequence> *)&v160[8],
                 (size_t *)&v160[24],
                 1))
           || (*(_QWORD *)&v160[24] = 0,
               p_keyframeSequence = &keyframeSequence,
               v38 = RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::fetch(
                       (RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string> > *)(a2 + 200),
                       (const std::string *)&keyframeSequence,
                       (boost::shared_ptr<RBX::KeyframeSequence> *)&v160[8],
                       (size_t *)&v160[24],
                       1),
               LOBYTE(a4) = v174,
               v38)) )
        {
          if ( !RBX::KeyframeSequence::gotCachedData(*(const RBX::KeyframeSequence **)&v160[8]) )
          {
            if ( stru_2A11A78.value )
            {
              if ( !a2 )
                goto LABEL_94;
              v43 = *(const RBX::ServiceProvider **)(a2 + 88);
              if ( v43 )
              {
                do
                {
                  v44 = v43;
                  v43 = (const RBX::ServiceProvider *)*((_QWORD *)v43 + 11);
                }
                while ( v43 );
              }
              else
              {
                v44 = (const RBX::ServiceProvider *)a2;
              }
              v54 = *((_QWORD *)v44 + 3);
              v55 = Class_getDescriptorPtr(0);
              if ( *(unsigned __int16 *)(v54 + 726) - (unsigned int)*((unsigned __int16 *)v55 + 363) <= *((unsigned __int16 *)v55 + 364) )
                v56 = RBX::ServiceProvider::create<RBX::ContentProvider>(v44);
              else
LABEL_94:
                v56 = 0;
              AssetTypeAnimation = RBX::ContentProvider::getAssetTypeAnimation();
              RBX::ContentProvider::updateRequestPriority(
                v56,
                (const RBX::ContentId *)&keyframeSequence,
                AssetTypeAnimation,
                updatedPriority);
            }
            else
            {
              if ( !a2 )
                goto LABEL_561;
              v52 = *(const RBX::ServiceProvider **)(a2 + 88);
              if ( v52 )
              {
                do
                {
                  v53 = v52;
                  v52 = (const RBX::ServiceProvider *)*((_QWORD *)v52 + 11);
                }
                while ( v52 );
              }
              else
              {
                v53 = (const RBX::ServiceProvider *)a2;
              }
              v152 = *((_QWORD *)v53 + 3);
              v153 = Class_getDescriptorPtr(0);
              if ( *(unsigned __int16 *)(v152 + 726) - (unsigned int)*((unsigned __int16 *)v153 + 363) <= *((unsigned __int16 *)v153 + 364) )
                v154 = RBX::ServiceProvider::create<RBX::ContentProvider>(v53);
              else
LABEL_561:
                v154 = 0;
              RBX::ContentProvider::updateRequestPriority_deprecated(
                v154,
                (const RBX::ContentId *)&keyframeSequence,
                a8);
            }
          }
          if ( v14->vtable )
          {
            v224 = *(boost::shared_ptr<RBX::Instance> *)&v160[8];
            if ( *(_QWORD *)&v160[16] )
              _InterlockedAdd((volatile signed __int32 *)(*(_QWORD *)&v160[16] + 8LL), 1u);
            boost::function1<void,boost::shared_ptr<RBX::Instance>>::operator()(
              v14,
              (boost::shared_ptr<RBX::Instance>)__PAIR128__(v39, &v224));
            v58 = v224.pn.pi_;
            if ( v224.pn.pi_ )
            {
              if ( !_InterlockedSub(&v224.pn.pi_->use_count_, 1u) )
              {
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))v58->_vptr$sp_counted_base + 2))(v58);
                if ( !_InterlockedSub(&v58->weak_count_, 1u) )
                  (*((void (__fastcall **)(boost::detail::sp_counted_base *))v58->_vptr$sp_counted_base + 3))(v58);
              }
            }
          }
          v27->_vptr$sp_counted_base = *(int (***)(void))&v160[8];
          v59 = *(_QWORD *)&v160[16];
          *(_QWORD *)&v160[16] = 0;
          *(_QWORD *)&v27->use_count_ = v59;
          *(_QWORD *)&v160[8] = 0;
          v50 = 1;
          if ( LOBYTE(v195.weak_this_.px) )
LABEL_105:
            boost::mutex::unlock((boost::mutex *)v195._vptr$EventSource);
        }
        else
        {
          v45 = RBX::Creatable<RBX::Instance>::create<RBX::KeyframeSequence>();
          v46 = *(_OWORD *)&v160[24];
          *(_OWORD *)&v160[24] = 0;
          v47 = *(volatile signed __int32 **)&v160[16];
          *(_OWORD *)&v160[8] = v46;
          if ( v47 )
          {
            if ( !_InterlockedSub(v47 + 2, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *, __int128 *, boost::detail::sp_counted_base *))(*(_QWORD *)v47 + 16LL))(
                v47,
                p_keyframeSequence,
                v45.pn.pi_);
              if ( !_InterlockedSub(v47 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v47 + 24LL))(v47);
            }
          }
          v48 = *(volatile signed __int32 **)&v160[32];
          if ( *(_QWORD *)&v160[32] )
          {
            if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v160[32] + 8LL), 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *, __int128 *, boost::detail::sp_counted_base *))(*(_QWORD *)v48 + 16LL))(
                v48,
                p_keyframeSequence,
                v45.pn.pi_);
              if ( !_InterlockedSub(v48 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v48 + 24LL))(v48);
            }
          }
          if ( (a4 & 4) != 0 )
          {
            RBX::KeyframeSequence::setAllowFrozenCache(*(RBX::KeyframeSequence **)&v160[8], 1);
            v51 = *(_QWORD *)(a2 + 384);
            if ( v51 )
              --v51;
            RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::resize(
              (RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string> > *)(a2 + 296),
              v51);
            v50 = 0;
            RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::insert(
              (RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string> > *)(a2 + 296),
              (const std::string *)&keyframeSequence,
              (const boost::shared_ptr<RBX::KeyframeSequence> *)&v160[8],
              0);
          }
          else
          {
            v49 = *(_QWORD *)(a2 + 288);
            if ( v49 )
              --v49;
            RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::resize(
              (RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string> > *)(a2 + 200),
              v49);
            v50 = 0;
            RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string>>::insert(
              (RBX::LRUCache<std::string,boost::shared_ptr<RBX::KeyframeSequence>,boost::hash<std::string> > *)(a2 + 200),
              (const std::string *)&keyframeSequence,
              (const boost::shared_ptr<RBX::KeyframeSequence> *)&v160[8],
              0);
          }
          if ( LOBYTE(v195.weak_this_.px) )
            goto LABEL_105;
        }
        if ( v50 )
          goto LABEL_546;
        memset(&v195.parent, 0, 24);
        v60 = (int)v234;
        v61 = *v234;
        if ( (v61 & 1) != 0 )
        {
          if ( *((_QWORD *)v234 + 1) )
            goto LABEL_112;
        }
        else if ( v61 >> 1 )
        {
          goto LABEL_112;
        }
        if ( !(unsigned int)std::string::compare(v234, 0, -1, &uri_string, 0) )
        {
          if ( a6 )
          {
            RBX::Instance::getFullName(&v195);
            if ( ((__int64)v195.parent & 1) != 0 )
            {
              LOBYTE(v195.ancestryChangedSignal.head.px->strong.v) = 0;
              v195.onDemandPtr.px = 0;
            }
            else
            {
              LOWORD(v195.parent) = 0;
            }
            std::string::reserve(&v195.parent, 0);
            v195.ancestryChangedSignal.head.px = (rbx::signals::slot_base *)v195.weak_this_.pn.pi_;
            *(_OWORD *)&v195.parent = *(_OWORD *)&v195._vptr$EventSource;
          }
LABEL_113:
          *(_DWORD *)&v160[36] = 0;
          *(_QWORD *)&v160[40] = 0;
          v160[24] = 22;
          *(_QWORD *)&v160[25] = 0x6F6974616D696E41LL;
          *(_DWORD *)&v160[33] = (_DWORD)&off_64496E;
          RBX::InstanceIdentifier::InstanceIdentifier(
            (RBX::InstanceIdentifier *)&v195,
            a6,
            (const std::string *)&v160[24]);
          if ( (v160[24] & 1) != 0 )
            operator delete(*(void **)&v160[40]);
          v62 = RBX::DataModel::get((RBX::Instance *)a2);
          if ( !v62 )
          {
            v214 = 0;
            v65 = *a10;
            if ( *a10 )
            {
              v214 = *a10;
              if ( (v65 & 1) != 0 )
              {
                v216 = a10[3];
                v215 = *(_OWORD *)(a10 + 1);
              }
              else
              {
                (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v65 & 0xFFFFFFFFFFFFFFFELL))(a10 + 1, &v215, 0);
              }
            }
            memset(v165, 0, sizeof(v165));
            *(_QWORD *)&v165[16] = operator new(0x20u);
            *(_OWORD *)v165 = *(_OWORD *)&::errorFunction.vtable;
            strcpy(*(char **)&v165[16], "Unable to access DataModel");
            if ( v214 )
            {
              std::string::basic_string(&v160[24], v165);
              boost::function1<void,std::string>::operator()(&v214, (__int128 *)&v160[24]);
              if ( (v160[24] & 1) != 0 )
                operator delete(*(void **)&v160[40]);
            }
            if ( (v165[0] & 1) != 0 )
              operator delete(*(void **)&v165[16]);
            if ( v214 )
            {
              if ( (v214 & 1) == 0 )
              {
                v117 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v214 & 0xFFFFFFFFFFFFFFFELL);
                if ( v117 )
                  v117(&v215, &v215, 2);
              }
              v214 = 0;
            }
            v118 = *(boost::detail::sp_counted_base *)&v160[8];
            *(_QWORD *)&v160[16] = 0;
            *v27 = v118;
            *(_QWORD *)&v160[8] = 0;
            if ( (v195.guid.scope.peerId.peerId & 1) == 0 )
            {
LABEL_542:
              if ( ((__int64)v195.descriptor & 1) == 0 )
              {
LABEL_543:
                if ( ((__int64)v195._vptr$EventSource & 1) == 0 )
                {
LABEL_544:
                  if ( ((__int64)v195.parent & 1) != 0 )
LABEL_545:
                    operator delete(v195.ancestryChangedSignal.head.px);
LABEL_546:
                  v150 = *(volatile signed __int32 **)&v160[16];
                  if ( *(_QWORD *)&v160[16] )
                  {
                    if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v160[16] + 8LL), 1u) )
                    {
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v150 + 16LL))(v150);
                      if ( !_InterlockedSub(v150 + 3, 1u) )
                        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v150 + 24LL))(v150);
                    }
                  }
                  goto LABEL_550;
                }
LABEL_412:
                operator delete(v195.weak_this_.pn.pi_);
                if ( ((__int64)v195.parent & 1) == 0 )
                  goto LABEL_546;
                goto LABEL_545;
              }
LABEL_411:
              operator delete(v195.registry.px);
              if ( ((__int64)v195._vptr$EventSource & 1) == 0 )
                goto LABEL_544;
              goto LABEL_412;
            }
LABEL_410:
            operator delete(v195.name.h.h);
            if ( ((__int64)v195.descriptor & 1) == 0 )
              goto LABEL_543;
            goto LABEL_411;
          }
          other.vtable = 0;
          v200.vtable = 0;
          RBX::weak_from<RBX::DataModel>(&v212, v62);
          if ( !v14->vtable )
          {
LABEL_277:
            v92 = *a10;
            v93 = v174;
            if ( !*a10 )
              goto LABEL_389;
            px = (std::istream *)v212;
            v195.combinedSignal.head.px = v212;
            v196 = v213;
            if ( v213 )
            {
              _InterlockedAdd(v213 + 3, 1u);
              v92 = *a10;
              v197 = 0;
              if ( !v92 )
                goto LABEL_285;
            }
            else
            {
              v197 = 0;
            }
            v197 = v92;
            if ( (v92 & 1) != 0 )
            {
              v199 = a10[3];
              v198 = *(_OWORD *)(a10 + 1);
            }
            else
            {
              (*(void (__fastcall **)(__int64 *, __int128 *, _QWORD))(v92 & 0xFFFFFFFFFFFFFFFELL))(a10 + 1, &v198, 0);
              px = (std::istream *)v195.combinedSignal.head.px;
            }
LABEL_285:
            v188 = px;
            v189 = v196;
            if ( v196 )
              _InterlockedAdd(v196 + 3, 1u);
            v190 = 0;
            if ( v197 )
            {
              v190 = v197;
              if ( (v197 & 1) != 0 )
              {
                *(_QWORD *)&v192 = v199;
                v191 = v198;
              }
              else
              {
                (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(v197 & 0xFFFFFFFFFFFFFFFELL))(&v198, &v191, 0);
                px = v188;
              }
            }
            stream = px;
            v183 = (boost::detail::sp_counted_base *)v189;
            if ( v189 )
              _InterlockedAdd(v189 + 3, 1u);
            v184 = 0;
            if ( v190 )
            {
              v184 = v190;
              if ( (v190 & 1) != 0 )
              {
                *(_QWORD *)&v186 = v192;
                v185 = v191;
              }
              else
              {
                (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(v190 & 0xFFFFFFFFFFFFFFFELL))(&v191, &v185, 0);
                px = stream;
              }
            }
            v194.vtable = 0;
            keyframeSequenceProvider = px;
            v177 = v183;
            if ( v183 )
              _InterlockedAdd(&v183->weak_count_, 1u);
            v178 = 0;
            if ( v184 )
            {
              v178 = (void *)v184;
              if ( (v184 & 1) != 0 )
              {
                *(_QWORD *)&v180 = v186;
                v179 = v185;
              }
              else
              {
                (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(v184 & 0xFFFFFFFFFFFFFFFELL))(&v185, &v179, 0);
                px = keyframeSequenceProvider;
              }
            }
            v169.px = (boost::weak_ptr<RBX::KeyframeSequenceProvider>::element_type *)px;
            v169.pn.pi_ = v177;
            if ( v177 )
              _InterlockedAdd(&v177->weak_count_, 1u);
            ptr = 0;
            if ( v178 )
            {
              ptr = v178;
              if ( ((unsigned __int8)v178 & 1) != 0 )
              {
                *(_QWORD *)&v172 = v180;
                v171 = v179;
              }
              else
              {
                (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))((unsigned __int64)v178 & 0xFFFFFFFFFFFFFFFELL))(
                  &v179,
                  &v171,
                  0);
                px = (std::istream *)v169.px;
              }
            }
            *(_QWORD *)v165 = px;
            *(_QWORD *)&v165[8] = v169.pn.pi_;
            if ( v169.pn.pi_ )
              _InterlockedAdd(&v169.pn.pi_->weak_count_, 1u);
            *(_QWORD *)&v165[16] = 0;
            if ( ptr )
            {
              *(_QWORD *)&v165[16] = ptr;
              if ( ((unsigned __int8)ptr & 1) != 0 )
              {
                *(_QWORD *)&v167 = v172;
                v166 = v171;
              }
              else
              {
                (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))((unsigned __int64)ptr & 0xFFFFFFFFFFFFFFFELL))(
                  &v171,
                  &v166,
                  0);
                px = *(std::istream **)v165;
              }
            }
            *(_QWORD *)&v160[24] = px;
            *(_QWORD *)&v160[32] = *(_QWORD *)&v165[8];
            if ( *(_QWORD *)&v165[8] )
              _InterlockedAdd((volatile signed __int32 *)(*(_QWORD *)&v165[8] + 12LL), 1u);
            *(_QWORD *)&v160[40] = 0;
            if ( *(_QWORD *)&v165[16] )
            {
              *(_QWORD *)&v160[40] = *(_QWORD *)&v165[16];
              if ( (v165[16] & 1) != 0 )
              {
                *(_QWORD *)&v161 = v167;
                *(_OWORD *)&v160[48] = v166;
              }
              else
              {
                (*(void (__fastcall **)(__int128 *, _BYTE *, _QWORD))(*(_QWORD *)&v165[16] & 0xFFFFFFFFFFFFFFFELL))(
                  &v166,
                  &v160[48],
                  0);
              }
            }
            v95 = (char *)operator new(0x30u);
            *(_QWORD *)v95 = *(_QWORD *)&v160[24];
            v96 = *(_QWORD *)&v160[32];
            *((_QWORD *)v95 + 1) = *(_QWORD *)&v160[32];
            if ( v96 )
              _InterlockedAdd((volatile signed __int32 *)(v96 + 12), 1u);
            *((_QWORD *)v95 + 2) = 0;
            v97 = *(_QWORD *)&v160[40];
            if ( *(_QWORD *)&v160[40] )
            {
              *((_QWORD *)v95 + 2) = *(_QWORD *)&v160[40];
              if ( (v97 & 1) != 0 )
              {
                *((_QWORD *)v95 + 5) = v161;
                *(_OWORD *)(v95 + 24) = *(_OWORD *)&v160[48];
                v194.functor.obj_ptr = v95;
              }
              else
              {
                (*(void (__fastcall **)(_BYTE *, char *, _QWORD))(v97 & 0xFFFFFFFFFFFFFFFELL))(&v160[48], v95 + 24, 0);
                v97 = *(_QWORD *)&v160[40];
                v194.functor.obj_ptr = v95;
                if ( !*(_QWORD *)&v160[40] )
                {
LABEL_333:
                  v99 = *(_QWORD *)&v160[32];
                  if ( *(_QWORD *)&v160[32]
                    && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v160[32] + 12LL), 1u) )
                  {
                    (*(void (__fastcall **)(__int64))(*(_QWORD *)v99 + 24LL))(v99);
                  }
                  if ( *(_QWORD *)&v165[16] )
                  {
                    if ( (v165[16] & 1) == 0 )
                    {
                      v100 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*(_QWORD *)&v165[16]
                                                                                    & 0xFFFFFFFFFFFFFFFELL);
                      if ( v100 )
                        v100(&v166, &v166, 2);
                    }
                    *(_QWORD *)&v165[16] = 0;
                  }
                  v101 = *(_QWORD *)&v165[8];
                  if ( *(_QWORD *)&v165[8]
                    && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v165[8] + 12LL), 1u) )
                  {
                    (*(void (__fastcall **)(__int64))(*(_QWORD *)v101 + 24LL))(v101);
                  }
                  if ( ptr )
                  {
                    if ( ((unsigned __int8)ptr & 1) == 0 )
                    {
                      v102 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)ptr
                                                                                    & 0xFFFFFFFFFFFFFFFELL);
                      if ( v102 )
                        v102(&v171, &v171, 2);
                    }
                    ptr = 0;
                  }
                  v103 = v169.pn.pi_;
                  if ( v169.pn.pi_ && !_InterlockedSub(&v169.pn.pi_->weak_count_, 1u) )
                    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v103->_vptr$sp_counted_base + 3))(v103);
                  v194.vtable = (boost::detail::function::vtable_base *)off_2890358;
                  if ( v178 )
                  {
                    if ( ((unsigned __int8)v178 & 1) == 0 )
                    {
                      v104 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v178
                                                                                    & 0xFFFFFFFFFFFFFFFELL);
                      if ( v104 )
                        v104(&v179, &v179, 2);
                    }
                    v178 = 0;
                  }
                  v105 = v177;
                  if ( v177 && !_InterlockedSub(&v177->weak_count_, 1u) )
                    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v105->_vptr$sp_counted_base + 3))(v105);
                  if ( v184 )
                  {
                    if ( (v184 & 1) == 0 )
                    {
                      v106 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v184 & 0xFFFFFFFFFFFFFFFELL);
                      if ( v106 )
                        v106(&v185, &v185, 2);
                    }
                    v184 = 0;
                  }
                  v107 = v183;
                  if ( v183 && !_InterlockedSub(&v183->weak_count_, 1u) )
                    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v107->_vptr$sp_counted_base + 3))(v107);
                  boost::function1<void,std::string>::swap((boost::function1<void,std::string >_0 *)&v194, &v200);
                  if ( v194.vtable )
                  {
                    if ( ((__int64)v194.vtable & 1) == 0 )
                    {
                      v108 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v194.vtable & 0xFFFFFFFFFFFFFFFELL);
                      if ( v108 )
                        v108(&v194.functor, &v194.functor, 2);
                    }
                    v194.vtable = 0;
                  }
                  if ( v190 )
                  {
                    if ( (v190 & 1) == 0 )
                    {
                      v109 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v190 & 0xFFFFFFFFFFFFFFFELL);
                      if ( v109 )
                        v109(&v191, &v191, 2);
                    }
                    v190 = 0;
                  }
                  v110 = v189;
                  if ( v189 && !_InterlockedSub(v189 + 3, 1u) )
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v110 + 24LL))(v110);
                  if ( v197 )
                  {
                    if ( (v197 & 1) == 0 )
                    {
                      v111 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v197 & 0xFFFFFFFFFFFFFFFELL);
                      if ( v111 )
                        v111(&v198, &v198, 2);
                    }
                    v197 = 0;
                  }
                  v112 = v196;
                  if ( v196 && !_InterlockedSub(v196 + 3, 1u) )
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v112 + 24LL))(v112);
LABEL_389:
                  if ( (v93 & 1) != 0 )
                  {
                    if ( !a2 )
                      goto LABEL_416;
                    v115 = *(const RBX::ServiceProvider **)(a2 + 88);
                    if ( v115 )
                    {
                      do
                      {
                        v116 = v115;
                        v115 = (const RBX::ServiceProvider *)*((_QWORD *)v115 + 11);
                      }
                      while ( v115 );
                    }
                    else
                    {
                      v116 = (const RBX::ServiceProvider *)a2;
                    }
                    v119 = *((_QWORD *)v116 + 3);
                    v120 = Class_getDescriptorPtr(0);
                    if ( *(unsigned __int16 *)(v119 + 726) - (unsigned int)*((unsigned __int16 *)v120 + 363) <= *((unsigned __int16 *)v120 + 364) )
                      v121 = RBX::ServiceProvider::create<RBX::ContentProvider>(v116);
                    else
LABEL_416:
                      v121 = 0;
                    v122 = RBX::ContentProvider::getAssetTypeAnimation();
                    RBX::ContentProvider::getContentSync(
                      v121,
                      (const RBX::ContentId *)&keyframeSequence,
                      v122,
                      1,
                      !stru_2A11470.value);
                    v123 = stream;
                    RBX::weak_from<RBX::KeyframeSequenceProvider>((RBX::KeyframeSequenceProvider *)a2);
                    v124 = *(std::istream **)&v160[8];
                    v125 = *(volatile signed __int32 **)&v160[16];
                    if ( *(_QWORD *)&v160[16] )
                      _InterlockedAdd((volatile signed __int32 *)(*(_QWORD *)&v160[16] + 12LL), 1u);
                    vtable = 0;
                    if ( other.vtable )
                    {
                      vtable = other.vtable;
                      if ( ((__int64)other.vtable & 1) != 0 )
                      {
                        *((_QWORD *)&errorFunction.functor.data + 1) = other.functor.bound_memfunc_ptr.obj_ptr;
                        *(_OWORD *)&errorFunction.vtable = *(_OWORD *)&other.functor.obj_ptr;
                      }
                      else
                      {
                        (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::function<void (std::string)>_0 *, _QWORD))((unsigned __int64)other.vtable & 0xFFFFFFFFFFFFFFFELL))(
                          &other.functor,
                          &errorFunction,
                          0);
                      }
                    }
                    v202 = 0;
                    if ( v200.vtable )
                    {
                      v202 = v200.vtable;
                      if ( ((__int64)v200.vtable & 1) != 0 )
                        functor = v200.functor;
                      else
                        (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v200.vtable & 0xFFFFFFFFFFFFFFFELL))(
                          &v200.functor,
                          &functor,
                          0);
                    }
                    v169 = v223;
                    if ( v223.pn.pi_ )
                      _InterlockedAdd(&v223.pn.pi_->weak_count_, 1u);
                    keyframeSequenceProvider = v124;
                    v177 = (boost::detail::sp_counted_base *)v125;
                    if ( v125 )
                      _InterlockedAdd(v125 + 3, 1u);
                    *(_QWORD *)&v160[24] = 0;
                    if ( vtable )
                    {
                      *(_QWORD *)&v160[24] = vtable;
                      if ( ((unsigned __int8)vtable & 1) != 0 )
                      {
                        *(_QWORD *)&v160[48] = *((_QWORD *)&errorFunction.functor.data + 1);
                        *(_OWORD *)&v160[32] = *(_OWORD *)&errorFunction.vtable;
                      }
                      else
                      {
                        (*(void (__fastcall **)(boost::function<void (std::string)>_0 *, _BYTE *, _QWORD))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL))(
                          &errorFunction,
                          &v160[32],
                          0);
                      }
                    }
                    *(_QWORD *)v165 = 0;
                    if ( v202 )
                    {
                      *(_QWORD *)v165 = v202;
                      if ( ((unsigned __int8)v202 & 1) != 0 )
                      {
                        *(_QWORD *)&v166 = functor.bound_memfunc_ptr.obj_ptr;
                        *(_OWORD *)&v165[8] = *(_OWORD *)&functor.obj_ptr;
                      }
                      else
                      {
                        (*(void (__fastcall **)(boost::detail::function::function_buffer *, _BYTE *, _QWORD))((unsigned __int64)v202 & 0xFFFFFFFFFFFFFFFELL))(
                          &functor,
                          &v165[8],
                          0);
                      }
                    }
                    v126.px = (boost::weak_ptr<RBX::KeyframeSequenceProvider>::element_type *)&v169;
                    v126.pn.pi_ = (boost::detail::sp_counted_base *)&keyframeSequenceProvider;
                    v127.pn.pi_ = (boost::detail::sp_counted_base *)&keyframeSequence;
                    v127.px = (boost::weak_ptr<RBX::KeyframeSequence>::element_type *)(&dword_0 + 1);
                    RBX::KeyframeLoaderHelper(
                      RBX::HttpRequestResult::Http_Succeeded,
                      v123,
                      v126,
                      v127,
                      (bool)&v195,
                      (const std::string *)&v160[24],
                      (const RBX::InstanceIdentifier *)v165,
                      *(boost::function<void (boost::shared_ptr<RBX::Instance>)>_0 *)v160,
                      *(boost::function<void (std::string)>_0 *)&v160[32]);
                    v27 = v195.children.object.pn.pi_;
                    if ( *(_QWORD *)v165 )
                    {
                      if ( (v165[0] & 1) == 0 )
                      {
                        v128 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)v165 & 0xFFFFFFFFFFFFFFFELL);
                        if ( v128 )
                          v128(&v165[8], &v165[8], 2);
                      }
                      *(_QWORD *)v165 = 0;
                    }
                    if ( *(_QWORD *)&v160[24] )
                    {
                      if ( (v160[24] & 1) == 0 )
                      {
                        v129 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v160[24]
                                                                                & 0xFFFFFFFFFFFFFFFELL);
                        if ( v129 )
                          v129(&v160[32], &v160[32], 2);
                      }
                      *(_QWORD *)&v160[24] = 0;
                    }
                    if ( v125 && !_InterlockedSub(v125 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v125 + 24LL))(v125);
                    v130 = v169.pn.pi_;
                    if ( v169.pn.pi_ && !_InterlockedSub(&v169.pn.pi_->weak_count_, 1u) )
                      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v130->_vptr$sp_counted_base + 3))(v130);
                    if ( v202 )
                    {
                      if ( ((unsigned __int8)v202 & 1) == 0 )
                      {
                        v131 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v202 & 0xFFFFFFFFFFFFFFFELL);
                        if ( v131 )
                          v131(&functor, &functor, 2);
                      }
                      v202 = 0;
                    }
                    if ( vtable )
                    {
                      if ( ((unsigned __int8)vtable & 1) == 0 )
                      {
                        v132 = *(void (__fastcall **)(boost::function<void (std::string)>_0 *, boost::function<void (std::string)>_0 *, __int64))((unsigned __int64)vtable & 0xFFFFFFFFFFFFFFFELL);
                        if ( v132 )
                          v132(&errorFunction, &errorFunction, 2);
                      }
                      vtable = 0;
                    }
                    if ( v125 && !_InterlockedSub(v125 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v125 + 24LL))(v125);
                    v133 = v223.pn.pi_;
                    if ( v223.pn.pi_ && !_InterlockedSub(&v223.pn.pi_->weak_count_, 1u) )
                      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v133->_vptr$sp_counted_base + 3))(v133);
                    v134 = (volatile signed __int32 *)v183;
                    if ( v183 )
                    {
                      if ( !_InterlockedSub(&v183->use_count_, 1u) )
                      {
                        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v134 + 16LL))(v134);
                        if ( !_InterlockedSub(v134 + 3, 1u) )
                          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v134 + 24LL))(v134);
                      }
                    }
LABEL_528:
                    v27->_vptr$sp_counted_base = *(int (***)(void))&v160[8];
                    v146 = *(_QWORD *)&v160[16];
                    *(_QWORD *)&v160[16] = 0;
                    *(_QWORD *)&v27->use_count_ = v146;
                    *(_QWORD *)&v160[8] = 0;
                    v147 = v213;
                    if ( v213 && !_InterlockedSub(v213 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v147 + 24LL))(v147);
                    if ( v200.vtable )
                    {
                      if ( ((__int64)v200.vtable & 1) == 0 )
                      {
                        v148 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v200.vtable & 0xFFFFFFFFFFFFFFFELL);
                        if ( v148 )
                          v148(&v200.functor, &v200.functor, 2);
                      }
                      v200.vtable = 0;
                    }
                    if ( other.vtable )
                    {
                      if ( ((__int64)other.vtable & 1) == 0 )
                      {
                        v149 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)other.vtable & 0xFFFFFFFFFFFFFFFELL);
                        if ( v149 )
                          v149(&other.functor, &other.functor, 2);
                      }
                      other.vtable = 0;
                    }
                    if ( (v195.guid.scope.peerId.peerId & 1) == 0 )
                      goto LABEL_542;
                    goto LABEL_410;
                  }
                  std::string::basic_string(v165, &keyframeSequence);
                  if ( !a2 )
                    goto LABEL_478;
                  v113 = *(const RBX::ServiceProvider **)(a2 + 88);
                  if ( v113 )
                  {
                    do
                    {
                      v114 = v113;
                      v113 = (const RBX::ServiceProvider *)*((_QWORD *)v113 + 11);
                    }
                    while ( v113 );
                  }
                  else
                  {
                    v114 = (const RBX::ServiceProvider *)a2;
                  }
                  v135 = *((_QWORD *)v114 + 3);
                  v136 = Class_getDescriptorPtr(0);
                  if ( *(unsigned __int16 *)(v135 + 726) - (unsigned int)*((unsigned __int16 *)v136 + 363) <= *((unsigned __int16 *)v136 + 364) )
                    v137 = RBX::ServiceProvider::create<RBX::ContentProvider>(v114);
                  else
LABEL_478:
                    v137 = 0;
                  RBX::weak_from<RBX::KeyframeSequenceProvider>((RBX::KeyframeSequenceProvider *)a2);
                  v221 = *(_QWORD *)&v160[8];
                  v222 = *(_QWORD *)&v160[16];
                  if ( *(_QWORD *)&v160[16] )
                    _InterlockedAdd((volatile signed __int32 *)(*(_QWORD *)&v160[16] + 12LL), 1u);
                  std::string::basic_string(v235, v165);
                  std::string::basic_string(v227, &v195);
                  std::string::basic_string(v229, &v195.descriptor);
                  std::string::basic_string(v231, &v195.guid);
                  v233 = (int)v195.children.object.px;
                  v219 = 0;
                  if ( other.vtable )
                  {
                    v219 = other.vtable;
                    if ( ((__int64)other.vtable & 1) != 0 )
                      v220 = other.functor;
                    else
                      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)other.vtable & 0xFFFFFFFFFFFFFFFELL))(
                        &other.functor,
                        &v220,
                        0);
                  }
                  v217 = 0;
                  if ( v200.vtable )
                  {
                    v217 = v200.vtable;
                    if ( ((__int64)v200.vtable & 1) != 0 )
                      v218 = v200.functor;
                    else
                      (*(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, _QWORD))((unsigned __int64)v200.vtable & 0xFFFFFFFFFFFFFFFELL))(
                        &v200.functor,
                        &v218,
                        0);
                  }
                  boost::bind<void,RBX::HttpRequestResult,std::istream *,boost::weak_ptr<RBX::KeyframeSequenceProvider>,boost::weak_ptr<RBX::KeyframeSequence>,std::string const&,RBX::InstanceIdentifier const&,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>,boost::arg<1>,boost::arg<2>,boost::weak_ptr<RBX::KeyframeSequenceProvider>,boost::weak_ptr<RBX::KeyframeSequence>,std::string,RBX::InstanceIdentifier,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>(
                    v241,
                    RBX::AsyncKeyframeLoaderHelper,
                    v237,
                    &v221,
                    v235,
                    v227,
                    &v219,
                    &v217);
                  boost::function<void ()(RBX::HttpRequestResult,std::istream *,boost::shared_ptr<std::string const>,boost::shared_ptr<std::exception>)>::function<boost::_bi::bind_t<void,void (*)(RBX::HttpRequestResult,std::istream *,boost::weak_ptr<RBX::KeyframeSequenceProvider>,boost::weak_ptr<RBX::KeyframeSequence>,std::string const&,RBX::InstanceIdentifier const&,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>),boost::_bi::list8<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider>>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<std::string>,boost::_bi::value<RBX::InstanceIdentifier>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>>(
                    &v160[24],
                    v241,
                    0);
                  v138 = RBX::ContentProvider::getAssetTypeAnimation();
                  RBX::ContentProvider::getContent(
                    v137,
                    (const RBX::ContentId *)&keyframeSequence,
                    updatedPriority,
                    (const RBX::HttpRequestCallback *)&v160[24],
                    v138,
                    (const std::string *)&xmmword_2A11CA0,
                    RBX::HttpResultJob::Http_AsyncInline,
                    1,
                    !stru_2A11470.value);
                  if ( *(_QWORD *)&v160[24] )
                  {
                    if ( (v160[24] & 1) == 0 )
                    {
                      v139 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v160[24]
                                                                              & 0xFFFFFFFFFFFFFFFELL);
                      if ( v139 )
                        v139(&v160[32], &v160[32], 2);
                    }
                    *(_QWORD *)&v160[24] = 0;
                  }
                  if ( v245 )
                  {
                    if ( (v245 & 1) == 0 )
                    {
                      v140 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v245 & 0xFFFFFFFFFFFFFFFELL);
                      if ( v140 )
                        v140(v246, v246, 2);
                    }
                    v245 = 0;
                  }
                  if ( v243 )
                  {
                    if ( (v243 & 1) == 0 )
                    {
                      v141 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v243 & 0xFFFFFFFFFFFFFFFELL);
                      if ( v141 )
                        v141(v244, v244, 2);
                    }
                    v243 = 0;
                  }
                  boost::_bi::storage6<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider>>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<std::string>,boost::_bi::value<RBX::InstanceIdentifier>>::~storage6((boost::_bi::storage6<boost::arg<1>,boost::arg<2>,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequenceProvider> >,boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<std::string >,boost::_bi::value<RBX::InstanceIdentifier> > *)v242);
                  if ( v217 )
                  {
                    if ( ((unsigned __int8)v217 & 1) == 0 )
                    {
                      v142 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v217 & 0xFFFFFFFFFFFFFFFELL);
                      if ( v142 )
                        v142(&v218, &v218, 2);
                    }
                    v217 = 0;
                  }
                  if ( v219 )
                  {
                    if ( ((unsigned __int8)v219 & 1) == 0 )
                    {
                      v143 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v219 & 0xFFFFFFFFFFFFFFFELL);
                      if ( v143 )
                        v143(&v220, &v220, 2);
                    }
                    v219 = 0;
                  }
                  if ( (v231[0] & 1) != 0 )
                  {
                    operator delete(v232);
                    if ( (v229[0] & 1) == 0 )
                    {
LABEL_517:
                      if ( (v227[0] & 1) == 0 )
                        goto LABEL_518;
                      goto LABEL_555;
                    }
                  }
                  else if ( (v229[0] & 1) == 0 )
                  {
                    goto LABEL_517;
                  }
                  operator delete(v230);
                  if ( (v227[0] & 1) == 0 )
                  {
LABEL_518:
                    if ( (v235[0] & 1) == 0 )
                      goto LABEL_520;
                    goto LABEL_519;
                  }
LABEL_555:
                  operator delete(v228);
                  if ( (v235[0] & 1) == 0 )
                  {
LABEL_520:
                    v144 = v222;
                    if ( v222 && !_InterlockedSub((volatile signed __int32 *)(v222 + 12), 1u) )
                      (*(void (__fastcall **)(__int64))(*(_QWORD *)v144 + 24LL))(v144);
                    v145 = v238;
                    if ( v238 && !_InterlockedSub((volatile signed __int32 *)(v238 + 12), 1u) )
                      (*(void (__fastcall **)(__int64))(*(_QWORD *)v145 + 24LL))(v145);
                    if ( (v165[0] & 1) != 0 )
                      operator delete(*(void **)&v165[16]);
                    goto LABEL_528;
                  }
LABEL_519:
                  operator delete(v236);
                  goto LABEL_520;
                }
              }
              if ( (v97 & 1) == 0 )
              {
                v98 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v97 & 0xFFFFFFFFFFFFFFFELL);
                if ( v98 )
                  v98(&v160[48], &v160[48], 2);
              }
              *(_QWORD *)&v160[40] = 0;
              goto LABEL_333;
            }
            v194.functor.obj_ptr = v95;
            goto LABEL_333;
          }
          v63 = *(std::istream **)&v160[8];
          errorFunction.functor.bound_memfunc_ptr.obj_ptr = *(void **)&v160[8];
          v206 = *(volatile signed __int32 **)&v160[16];
          if ( *(_QWORD *)&v160[16] )
            _InterlockedAdd((volatile signed __int32 *)(*(_QWORD *)&v160[16] + 8LL), 1u);
          v207 = v212;
          v208 = v213;
          if ( v213 )
            _InterlockedAdd(v213 + 3, 1u);
          v209 = 0;
          v64 = v14->vtable;
          if ( v14->vtable )
          {
            v209 = v14->vtable;
            if ( ((unsigned __int8)v64 & 1) != 0 )
            {
              obj_ptr = v14->functor.bound_memfunc_ptr.obj_ptr;
              v210 = *(_OWORD *)&v14->functor.obj_ptr;
            }
            else
            {
              (*(void (__fastcall **)(boost::detail::function::function_buffer *, __int128 *, _QWORD))((unsigned __int64)v64 & 0xFFFFFFFFFFFFFFFELL))(
                &v14->functor,
                &v210,
                0);
              v63 = (std::istream *)errorFunction.functor.bound_memfunc_ptr.obj_ptr;
            }
          }
          v188 = v63;
          v189 = v206;
          if ( v206 )
            _InterlockedAdd(v206 + 2, 1u);
          v190 = (unsigned __int64)v207;
          *(_QWORD *)&v191 = v208;
          if ( v208 )
            _InterlockedAdd(v208 + 3, 1u);
          *((_QWORD *)&v191 + 1) = 0;
          if ( v209 )
          {
            *((_QWORD *)&v191 + 1) = v209;
            if ( ((unsigned __int8)v209 & 1) != 0 )
            {
              v193 = (__int64)obj_ptr;
              v192 = v210;
            }
            else
            {
              (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))((unsigned __int64)v209 & 0xFFFFFFFFFFFFFFFELL))(
                &v210,
                &v192,
                0);
              v63 = v188;
            }
          }
          stream = v63;
          v183 = (boost::detail::sp_counted_base *)v189;
          if ( v189 )
            _InterlockedAdd(v189 + 2, 1u);
          v184 = v190;
          *(_QWORD *)&v185 = v191;
          if ( (_QWORD)v191 )
            _InterlockedAdd((volatile signed __int32 *)(v191 + 12), 1u);
          *((_QWORD *)&v185 + 1) = 0;
          if ( *((_QWORD *)&v191 + 1) )
          {
            *((_QWORD *)&v185 + 1) = *((_QWORD *)&v191 + 1);
            if ( (BYTE8(v191) & 1) != 0 )
            {
              v187 = v193;
              v186 = v192;
            }
            else
            {
              (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(*((_QWORD *)&v191 + 1) & 0xFFFFFFFFFFFFFFFELL))(
                &v192,
                &v186,
                0);
              v63 = stream;
            }
          }
          v194.vtable = 0;
          keyframeSequenceProvider = v63;
          v177 = v183;
          if ( v183 )
            _InterlockedAdd(&v183->use_count_, 1u);
          v178 = (void *)v184;
          *(_QWORD *)&v179 = v185;
          if ( (_QWORD)v185 )
            _InterlockedAdd((volatile signed __int32 *)(v185 + 12), 1u);
          *((_QWORD *)&v179 + 1) = 0;
          if ( *((_QWORD *)&v185 + 1) )
          {
            *((_QWORD *)&v179 + 1) = *((_QWORD *)&v185 + 1);
            if ( (BYTE8(v185) & 1) != 0 )
            {
              v181 = v187;
              v180 = v186;
            }
            else
            {
              (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(*((_QWORD *)&v185 + 1) & 0xFFFFFFFFFFFFFFFELL))(
                &v186,
                &v180,
                0);
              v63 = keyframeSequenceProvider;
            }
          }
          v169.px = (boost::weak_ptr<RBX::KeyframeSequenceProvider>::element_type *)v63;
          v169.pn.pi_ = v177;
          if ( v177 )
            _InterlockedAdd(&v177->use_count_, 1u);
          ptr = v178;
          *(_QWORD *)&v171 = v179;
          if ( (_QWORD)v179 )
            _InterlockedAdd((volatile signed __int32 *)(v179 + 12), 1u);
          *((_QWORD *)&v171 + 1) = 0;
          if ( *((_QWORD *)&v179 + 1) )
          {
            *((_QWORD *)&v171 + 1) = *((_QWORD *)&v179 + 1);
            if ( (BYTE8(v179) & 1) != 0 )
            {
              v173 = v181;
              v172 = v180;
            }
            else
            {
              (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(*((_QWORD *)&v179 + 1) & 0xFFFFFFFFFFFFFFFELL))(
                &v180,
                &v172,
                0);
              v63 = (std::istream *)v169.px;
            }
          }
          *(_QWORD *)v165 = v63;
          *(_QWORD *)&v165[8] = v169.pn.pi_;
          if ( v169.pn.pi_ )
            _InterlockedAdd(&v169.pn.pi_->use_count_, 1u);
          *(_QWORD *)&v165[16] = ptr;
          *(_QWORD *)&v166 = v171;
          if ( (_QWORD)v171 )
            _InterlockedAdd((volatile signed __int32 *)(v171 + 12), 1u);
          *((_QWORD *)&v166 + 1) = 0;
          if ( *((_QWORD *)&v171 + 1) )
          {
            *((_QWORD *)&v166 + 1) = *((_QWORD *)&v171 + 1);
            if ( (BYTE8(v171) & 1) != 0 )
            {
              v168 = v173;
              v167 = v172;
            }
            else
            {
              (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(*((_QWORD *)&v171 + 1) & 0xFFFFFFFFFFFFFFFELL))(
                &v172,
                &v167,
                0);
              v63 = *(std::istream **)v165;
            }
          }
          *(_QWORD *)&v160[24] = v63;
          *(_QWORD *)&v160[32] = *(_QWORD *)&v165[8];
          if ( *(_QWORD *)&v165[8] )
            _InterlockedAdd((volatile signed __int32 *)(*(_QWORD *)&v165[8] + 8LL), 1u);
          *(_QWORD *)&v160[40] = *(_QWORD *)&v165[16];
          *(_QWORD *)&v160[48] = v166;
          if ( (_QWORD)v166 )
            _InterlockedAdd((volatile signed __int32 *)(v166 + 12), 1u);
          *(_QWORD *)&v160[56] = 0;
          if ( *((_QWORD *)&v166 + 1) )
          {
            *(_QWORD *)&v160[56] = *((_QWORD *)&v166 + 1);
            if ( (BYTE8(v166) & 1) != 0 )
            {
              v162 = v168;
              v161 = v167;
            }
            else
            {
              (*(void (__fastcall **)(__int128 *, __int128 *, _QWORD))(*((_QWORD *)&v166 + 1) & 0xFFFFFFFFFFFFFFFELL))(
                &v167,
                &v161,
                0);
            }
          }
          v66 = (char *)operator new(0x40u);
          *(_QWORD *)v66 = *(_QWORD *)&v160[24];
          v67 = *(_QWORD *)&v160[32];
          *((_QWORD *)v66 + 1) = *(_QWORD *)&v160[32];
          if ( v67 )
            _InterlockedAdd((volatile signed __int32 *)(v67 + 8), 1u);
          *((_QWORD *)v66 + 2) = *(_QWORD *)&v160[40];
          v68 = *(_QWORD *)&v160[48];
          *((_QWORD *)v66 + 3) = *(_QWORD *)&v160[48];
          if ( v68 )
            _InterlockedAdd((volatile signed __int32 *)(v68 + 12), 1u);
          *((_QWORD *)v66 + 4) = 0;
          v69 = *(_QWORD *)&v160[56];
          if ( *(_QWORD *)&v160[56] )
          {
            *((_QWORD *)v66 + 4) = *(_QWORD *)&v160[56];
            if ( (v69 & 1) != 0 )
            {
              *((_QWORD *)v66 + 7) = v162;
              *(_OWORD *)(v66 + 40) = v161;
              v194.functor.obj_ptr = v66;
            }
            else
            {
              (*(void (__fastcall **)(__int128 *, char *, _QWORD))(v69 & 0xFFFFFFFFFFFFFFFELL))(&v161, v66 + 40, 0);
              v69 = *(_QWORD *)&v160[56];
              v194.functor.obj_ptr = v66;
              if ( !*(_QWORD *)&v160[56] )
              {
LABEL_193:
                v71 = *(_QWORD *)&v160[48];
                if ( *(_QWORD *)&v160[48]
                  && !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v160[48] + 12LL), 1u) )
                {
                  (*(void (__fastcall **)(__int64))(*(_QWORD *)v71 + 24LL))(v71);
                }
                v72 = *(volatile signed __int32 **)&v160[32];
                if ( *(_QWORD *)&v160[32] )
                {
                  if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v160[32] + 8LL), 1u) )
                  {
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v72 + 16LL))(v72);
                    if ( !_InterlockedSub(v72 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v72 + 24LL))(v72);
                  }
                }
                if ( *((_QWORD *)&v166 + 1) )
                {
                  if ( (BYTE8(v166) & 1) == 0 )
                  {
                    v73 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*((_QWORD *)&v166 + 1)
                                                                                 & 0xFFFFFFFFFFFFFFFELL);
                    if ( v73 )
                      v73(&v167, &v167, 2);
                  }
                  *((_QWORD *)&v166 + 1) = 0;
                }
                v74 = v166;
                if ( (_QWORD)v166 && !_InterlockedSub((volatile signed __int32 *)(v166 + 12), 1u) )
                  (*(void (__fastcall **)(__int64))(*(_QWORD *)v74 + 24LL))(v74);
                v75 = *(volatile signed __int32 **)&v165[8];
                if ( *(_QWORD *)&v165[8] )
                {
                  if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v165[8] + 8LL), 1u) )
                  {
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v75 + 16LL))(v75);
                    if ( !_InterlockedSub(v75 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v75 + 24LL))(v75);
                  }
                }
                if ( *((_QWORD *)&v171 + 1) )
                {
                  if ( (BYTE8(v171) & 1) == 0 )
                  {
                    v76 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*((_QWORD *)&v171 + 1)
                                                                                 & 0xFFFFFFFFFFFFFFFELL);
                    if ( v76 )
                      v76(&v172, &v172, 2);
                  }
                  *((_QWORD *)&v171 + 1) = 0;
                }
                v77 = v171;
                if ( (_QWORD)v171 && !_InterlockedSub((volatile signed __int32 *)(v171 + 12), 1u) )
                  (*(void (__fastcall **)(__int64))(*(_QWORD *)v77 + 24LL))(v77);
                v78 = v169.pn.pi_;
                if ( v169.pn.pi_ )
                {
                  if ( !_InterlockedSub(&v169.pn.pi_->use_count_, 1u) )
                  {
                    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v78->_vptr$sp_counted_base + 2))(v78);
                    if ( !_InterlockedSub(&v78->weak_count_, 1u) )
                      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v78->_vptr$sp_counted_base + 3))(v78);
                  }
                }
                v194.vtable = (boost::detail::function::vtable_base *)off_2890338;
                if ( *((_QWORD *)&v179 + 1) )
                {
                  if ( (BYTE8(v179) & 1) == 0 )
                  {
                    v79 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*((_QWORD *)&v179 + 1)
                                                                                 & 0xFFFFFFFFFFFFFFFELL);
                    if ( v79 )
                      v79(&v180, &v180, 2);
                  }
                  *((_QWORD *)&v179 + 1) = 0;
                }
                v80 = v179;
                if ( (_QWORD)v179 && !_InterlockedSub((volatile signed __int32 *)(v179 + 12), 1u) )
                  (*(void (__fastcall **)(__int64))(*(_QWORD *)v80 + 24LL))(v80);
                v81 = (volatile signed __int32 *)v177;
                if ( v177 )
                {
                  if ( !_InterlockedSub(&v177->use_count_, 1u) )
                  {
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v81 + 16LL))(v81);
                    if ( !_InterlockedSub(v81 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v81 + 24LL))(v81);
                  }
                }
                if ( *((_QWORD *)&v185 + 1) )
                {
                  if ( (BYTE8(v185) & 1) == 0 )
                  {
                    v82 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*((_QWORD *)&v185 + 1)
                                                                                 & 0xFFFFFFFFFFFFFFFELL);
                    if ( v82 )
                      v82(&v186, &v186, 2);
                  }
                  *((_QWORD *)&v185 + 1) = 0;
                }
                v83 = v185;
                if ( (_QWORD)v185 && !_InterlockedSub((volatile signed __int32 *)(v185 + 12), 1u) )
                  (*(void (__fastcall **)(__int64))(*(_QWORD *)v83 + 24LL))(v83);
                v84 = (volatile signed __int32 *)v183;
                if ( v183 )
                {
                  if ( !_InterlockedSub(&v183->use_count_, 1u) )
                  {
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v84 + 16LL))(v84);
                    if ( !_InterlockedSub(v84 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v84 + 24LL))(v84);
                  }
                }
                boost::function1<void,boost::shared_ptr<RBX::Instance>>::swap(&v194, &other);
                if ( v194.vtable )
                {
                  if ( ((__int64)v194.vtable & 1) == 0 )
                  {
                    v85 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v194.vtable & 0xFFFFFFFFFFFFFFFELL);
                    if ( v85 )
                      v85(&v194.functor, &v194.functor, 2);
                  }
                  v194.vtable = 0;
                }
                if ( *((_QWORD *)&v191 + 1) )
                {
                  if ( (BYTE8(v191) & 1) == 0 )
                  {
                    v86 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(*((_QWORD *)&v191 + 1)
                                                                                 & 0xFFFFFFFFFFFFFFFELL);
                    if ( v86 )
                      v86(&v192, &v192, 2);
                  }
                  *((_QWORD *)&v191 + 1) = 0;
                }
                v87 = v191;
                if ( (_QWORD)v191 && !_InterlockedSub((volatile signed __int32 *)(v191 + 12), 1u) )
                  (*(void (__fastcall **)(__int64))(*(_QWORD *)v87 + 24LL))(v87);
                v88 = v189;
                if ( v189 )
                {
                  if ( !_InterlockedSub(v189 + 2, 1u) )
                  {
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v88 + 16LL))(v88);
                    if ( !_InterlockedSub(v88 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v88 + 24LL))(v88);
                  }
                }
                if ( v209 )
                {
                  if ( ((unsigned __int8)v209 & 1) == 0 )
                  {
                    v89 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v209
                                                                                 & 0xFFFFFFFFFFFFFFFELL);
                    if ( v89 )
                      v89(&v210, &v210, 2);
                  }
                  v209 = 0;
                }
                v90 = v208;
                if ( v208 && !_InterlockedSub(v208 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v90 + 24LL))(v90);
                v91 = v206;
                if ( v206 )
                {
                  if ( !_InterlockedSub(v206 + 2, 1u) )
                  {
                    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v91 + 16LL))(v91);
                    if ( !_InterlockedSub(v91 + 3, 1u) )
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v91 + 24LL))(v91);
                  }
                }
                goto LABEL_277;
              }
            }
            if ( (v69 & 1) == 0 )
            {
              v70 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v69 & 0xFFFFFFFFFFFFFFFELL);
              if ( v70 )
                v70(&v161, &v161, 2);
            }
            *(_QWORD *)&v160[56] = 0;
            goto LABEL_193;
          }
          v194.functor.obj_ptr = v66;
          goto LABEL_193;
        }
LABEL_112:
        std::string::operator=((soap *)&v195.parent, v60, v39, v40, v41, v42);
        goto LABEL_113;
      }
    }
    else
    {
      v35 = (char *)&v169.px + 1;
      if ( (v160[24] & 1) == 0 )
        goto LABEL_40;
    }
    v36 = *(const char **)&v160[40];
    goto LABEL_43;
  }
  RBX::KeyframeSequenceProvider::getAnimationIdFromContentId_deprecated(
    (RBX::KeyframeSequenceProvider *)&v195,
    (const RBX::ContentId *)a2);
  if ( (keyframeSequence & 1) != 0 )
  {
    *(_BYTE *)v164 = 0;
    *((_QWORD *)&keyframeSequence + 1) = 0;
  }
  else
  {
    LOWORD(keyframeSequence) = 0;
  }
  p_keyframeSequence = 0;
  std::string::reserve(&keyframeSequence, 0);
  v164 = v195.weak_this_.pn.pi_;
  keyframeSequence = *(_OWORD *)&v195._vptr$EventSource;
  if ( !RBX::AnimationId::isActiveContentId((const RBX::ContentId *)&keyframeSequence) )
    goto LABEL_61;
  v24 = (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > > *)(a2 + 136);
  if ( std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::find<std::string>(
         (std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::less<std::string >,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> > > > *)(a2 + 136),
         (const std::string *)&keyframeSequence).__ptr_ == (std::__tree_iterator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,std::__tree_node<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence> >,void *> *,long>::__iter_pointer)(a2 + 144) )
  {
    v158 = __cxa_allocate_exception(0x10u);
    if ( (keyframeSequence & 1) != 0 )
      v159 = (char *)v164;
    else
      v159 = (char *)&keyframeSequence + 1;
    RBX::format((RBX *)&v195, (const char *)&stru_3F7F76.combinedSignal.head.px + 1, v159);
    std::runtime_error::runtime_error(v158, &v195);
    __cxa_throw(
      v158,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  if ( a9->vtable )
  {
    v195._vptr$EventSource = (int (**)(void))&keyframeSequence;
    v25 = std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
            v24,
            (const std::string *)&keyframeSequence,
            &stru_4A8BF8,
            (std::tuple<const std::string &> *)&v195,
            (std::tuple<> *)&v160[24]);
    v225.px = (boost::shared_ptr<RBX::Instance>::element_type *)v25.first.__ptr_[7].__left_;
    v25.first.__ptr_ = v25.first.__ptr_[8].__left_;
    v225.pn.pi_ = (boost::detail::sp_counted_base *)v25.first.__ptr_;
    if ( v25.first.__ptr_ )
      _InterlockedAdd((volatile signed __int32 *)&v25.first.__ptr_[1], 1u);
    boost::function1<void,boost::shared_ptr<RBX::Instance>>::operator()(
      a9,
      (boost::shared_ptr<RBX::Instance>)__PAIR128__(*(unsigned __int64 *)&v25.second, &v225));
    v26 = v225.pn.pi_;
    if ( v225.pn.pi_ )
    {
      if ( !_InterlockedSub(&v225.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v26->_vptr$sp_counted_base + 2))(v26);
        if ( !_InterlockedSub(&v26->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v26->_vptr$sp_counted_base + 3))(v26);
      }
    }
  }
  v195._vptr$EventSource = (int (**)(void))&keyframeSequence;
  v18 = std::__tree<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::__map_value_compare<std::string,std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>,std::less<std::string>,true>,std::allocator<std::__value_type<std::string,boost::shared_ptr<RBX::KeyframeSequence>>>>::__emplace_unique_key_args<std::string,std::piecewise_construct_t const&,std::tuple<std::string const&>,std::tuple<>>(
          v24,
          (const std::string *)&keyframeSequence,
          &stru_4A8BF8,
          (std::tuple<const std::string &> *)&v195,
          (std::tuple<> *)&v160[24]).first.__ptr_;
LABEL_30:
  v27 = v195.children.object.pn.pi_;
  v195.children.object.pn.pi_->_vptr$sp_counted_base = (int (**)(void))v18[7].__left_;
  left = v18[8].__left_;
  *(_QWORD *)&v27->use_count_ = left;
  if ( left )
  {
    _InterlockedAdd((volatile signed __int32 *)&left->__right_, 1u);
    if ( (keyframeSequence & 1) == 0 )
      return v27;
    goto LABEL_551;
  }
LABEL_550:
  if ( (keyframeSequence & 1) != 0 )
LABEL_551:
    operator delete(v164);
  return v27;
}


// Address: 0x105bf00 | Name: _ZN3RBX24KeyframeSequenceProvider19getKeyframeSequenceENS_9ContentIdEPKNS_8InstanceEf
boost::detail::sp_counted_base *__fastcall RBX::KeyframeSequenceProvider::getKeyframeSequence(
        boost::detail::sp_counted_base *a1,
        __int64 a2,
        __int64 a3,
        const RBX::Instance *a4,
        float a5,
        float a6)
{
  int v7; // ebp
  boost::detail::sp_counted_base v8; // xmm0
  void (__fastcall *v9)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v10)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64); // rax
  __int128 v12; // [rsp+10h] [rbp-B8h] BYREF
  void *ptr; // [rsp+20h] [rbp-A8h]
  boost::detail::sp_counted_base v14; // [rsp+30h] [rbp-98h] BYREF
  __int64 v15; // [rsp+48h] [rbp-80h] BYREF
  _BYTE v16[24]; // [rsp+50h] [rbp-78h] BYREF
  boost::function1<void,boost::shared_ptr<RBX::Instance> >_0 v17; // [rsp+68h] [rbp-60h] BYREF
  _BYTE v18[16]; // [rsp+88h] [rbp-40h] BYREF
  void *v19; // [rsp+98h] [rbp-30h]

  v7 = 4 * stru_2A035B8.value + 2;
  std::string::basic_string(v18, a3);
  v12 = 0;
  ptr = 0;
  v17.vtable = 0;
  v15 = 0;
  RBX::KeyframeSequenceProvider::privateGetKeyframeSequence(
    &v14,
    a2,
    (const std::string *)v18,
    v7,
    (unsigned __int8 *)&v12,
    a4,
    a5,
    a6,
    &v17,
    &v15);
  v8 = v14;
  *(_QWORD *)&v14.use_count_ = 0;
  *a1 = v8;
  v14._vptr$sp_counted_base = 0;
  if ( v15 )
  {
    if ( (v15 & 1) == 0 )
    {
      v9 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(v15 & 0xFFFFFFFFFFFFFFFELL);
      if ( v9 )
        v9(v16, v16, 2);
    }
    v15 = 0;
  }
  if ( v17.vtable )
  {
    if ( ((__int64)v17.vtable & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(boost::detail::function::function_buffer *, boost::detail::function::function_buffer *, __int64))((unsigned __int64)v17.vtable & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v17.functor, &v17.functor, 2);
    }
    v17.vtable = 0;
  }
  if ( (v12 & 1) != 0 )
    operator delete(ptr);
  if ( (v18[0] & 1) != 0 )
    operator delete(v19);
  return a1;
}


// Address: 0x105c120 | Name: _ZN3RBX24KeyframeSequenceProvider38getAnimationIdFromContentId_deprecatedERKNS_9ContentIdE
std::string *__fastcall RBX::KeyframeSequenceProvider::getAnimationIdFromContentId_deprecated(
        RBX::KeyframeSequenceProvider *this,
        RBX::Instance *a2,
        unsigned __int8 *a3)
{
  std::string *v4; // rbp
  unsigned __int8 *v5; // r12
  const char *v6; // r15
  size_t v7; // rax
  size_t v8; // rbx
  char *v9; // rbp
  size_t v10; // r14
  int v11; // eax
  RBX::Instance *v12; // r15
  __int64 v13; // r14
  unsigned __int64 v14; // rax
  unsigned __int64 v15; // rax
  unsigned __int64 v16; // rax
  __int64 v17; // rsi
  __int64 v18; // rdx
  RBX::Instance *parent; // rax
  RBX::Instance *v20; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // rbp
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::ContentProvider *v23; // rdi
  const std::string *BaseUrl; // rax
  unsigned __int64 v25; // rdx
  unsigned __int64 v26; // rdx
  char *v27; // rax
  char *v28; // rbx
  char *v29; // rsi
  unsigned __int64 v30; // rdx
  unsigned __int64 v31; // rax
  char v32; // cl
  __int64 v33; // rax
  unsigned __int64 v34; // rdx
  __int64 v35; // rbx
  RBX::DataModel *v36; // rax
  int64_t PlaceIDOrZeroInStudio; // rax
  char *v38; // rsi
  unsigned __int64 v39; // rdx
  void *v41; // rax
  __int128 v42; // [rsp+0h] [rbp-A8h] BYREF
  void *v43; // [rsp+10h] [rbp-98h]
  __int128 dest; // [rsp+20h] [rbp-88h] BYREF
  void *v45; // [rsp+30h] [rbp-78h]
  __int128 v46; // [rsp+38h] [rbp-70h] BYREF
  void *ptr; // [rsp+48h] [rbp-60h]
  __int128 v48; // [rsp+50h] [rbp-58h] BYREF
  void *v49; // [rsp+60h] [rbp-48h]
  std::string *id; // [rsp+68h] [rbp-40h]
  RBX::Instance *context; // [rsp+70h] [rbp-38h]

  v4 = (std::string *)this;
  if ( !(unsigned int)std::string::compare(a3, 0, 4, "http")
    || !(unsigned int)std::string::compare(a3, 0, 11, "rbxasset://")
    || !(unsigned int)std::string::compare(a3, 0, 13, "rbxassetid://") )
  {
    context = a2;
    v48 = 0;
    v49 = 0;
    v5 = a3 + 1;
    v6 = (const char *)(a3 + 1);
    if ( (*a3 & 1) != 0 )
      v6 = (const char *)*((_QWORD *)a3 + 2);
    dest = 0;
    v45 = 0;
    v7 = strlen(v6);
    if ( v7 >= 0xFFFFFFFFFFFFFFF0LL )
    {
      v41 = (void *)std::__basic_string_common<true>::__throw_length_error(&dest);
      sub_D9C950(v41);
    }
    v8 = v7;
    id = (std::string *)this;
    if ( v7 >= 0x17 )
    {
      v10 = (v7 + 16) & 0xFFFFFFFFFFFFFFF0LL;
      v9 = (char *)operator new(v10);
      v45 = v9;
      *(_QWORD *)&dest = v10 | 1;
      *((_QWORD *)&dest + 1) = v8;
    }
    else
    {
      LOBYTE(dest) = 2 * v7;
      v9 = (char *)&dest + 1;
      if ( !v7 )
      {
LABEL_13:
        v9[v8] = 0;
        v11 = std::string::compare(a3, 0, 13, "rbxassetid://");
        v12 = context;
        if ( v11 )
          v13 = (unsigned int)std::string::rfind(&dest, 61, -1) + 1;
        else
          v13 = 13;
        v14 = *a3;
        if ( (v14 & 1) != 0 )
        {
          v5 = (unsigned __int8 *)*((_QWORD *)a3 + 2);
          v15 = *((_QWORD *)a3 + 1);
          if ( !v15 )
            goto LABEL_25;
        }
        else
        {
          v15 = v14 >> 1;
          if ( !v15 )
            goto LABEL_25;
        }
        v16 = v15 - 1;
        v17 = 0;
        while ( v5[v17] == aHttpWwwRobloxC[v17] )
        {
          v18 = v17;
          if ( v17 != 20 )
          {
            ++v17;
            if ( v16 != v18 )
              continue;
          }
          if ( v18 != 20 )
            break;
          std::string::append(&v48, "http://www.roblox.com", 20, "http://www.roblox.com");
          goto LABEL_37;
        }
LABEL_25:
        if ( !v12 )
          goto LABEL_31;
        parent = v12->parent;
        if ( parent )
        {
          do
          {
            v20 = parent;
            parent = parent->parent;
          }
          while ( parent );
        }
        else
        {
          v20 = v12;
        }
        descriptor = v20->descriptor;
        DescriptorPtr = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
          v23 = RBX::ServiceProvider::create<RBX::ContentProvider>((const RBX::ServiceProvider *)v20);
        else
LABEL_31:
          v23 = 0;
        BaseUrl = RBX::ContentProvider::getBaseUrl(v23);
        v25 = *(unsigned __int8 *)BaseUrl;
        if ( (v25 & 1) != 0 )
        {
          v26 = *((_QWORD *)BaseUrl + 1);
          v27 = (char *)*((_QWORD *)BaseUrl + 2);
        }
        else
        {
          v27 = (char *)BaseUrl + 1;
          v26 = v25 >> 1;
        }
        std::string::append(&v48, v27, v26);
LABEL_37:
        std::string::basic_string(&v42, &dest, v13, 19, &dest);
        v28 = (char *)&v42 + 1;
        if ( (v42 & 1) != 0 )
        {
          v29 = (char *)v43;
          v30 = *((_QWORD *)&v42 + 1);
          if ( !*((_QWORD *)&v42 + 1) )
            goto LABEL_52;
        }
        else
        {
          v30 = (unsigned __int64)(unsigned __int8)v42 >> 1;
          v29 = (char *)&v42 + 1;
          if ( !v30 )
            goto LABEL_52;
        }
        v31 = 0;
        while ( 1 )
        {
          v32 = v29[v31];
          if ( (unsigned __int8)v32 > 0x3Fu || ((1LL << v32) & 0x3FF000000000000LL) == 0 )
            break;
          if ( v30 == ++v31 )
            goto LABEL_52;
        }
        if ( v31 < v30 )
        {
          std::string::basic_string(&v46, &v42, 0, v31, &v42);
          if ( (v42 & 1) != 0 )
          {
            *(_BYTE *)v43 = 0;
            *((_QWORD *)&v42 + 1) = 0;
          }
          else
          {
            LOWORD(v42) = 0;
          }
          std::string::reserve(&v42, 0);
          v43 = ptr;
          v42 = v46;
        }
LABEL_52:
        v33 = std::string::append(&v48, "/asset/?id=");
        v4 = id;
        if ( (v42 & 1) != 0 )
        {
          v28 = (char *)v43;
          v34 = *((_QWORD *)&v42 + 1);
        }
        else
        {
          v34 = (unsigned __int64)(unsigned __int8)v42 >> 1;
        }
        std::string::append(v33, v28, v34);
        v35 = std::string::append(&v48, "&serverplaceid=");
        v36 = RBX::DataModel::get(v12);
        PlaceIDOrZeroInStudio = RBX::DataModel::getPlaceIDOrZeroInStudio(v36);
        RBX::format((RBX *)&v46, "%lld", PlaceIDOrZeroInStudio);
        if ( (v46 & 1) != 0 )
        {
          v38 = (char *)ptr;
          v39 = *((_QWORD *)&v46 + 1);
        }
        else
        {
          v39 = (unsigned __int64)(unsigned __int8)v46 >> 1;
          v38 = (char *)&v46 + 1;
        }
        std::string::append(v35, v38, v39);
        if ( (v46 & 1) != 0 )
          operator delete(ptr);
        std::string::basic_string(v4, &v48);
        RBX::ContentId::CorrectBackslash(v4);
        if ( (v42 & 1) != 0 )
        {
          operator delete(v43);
          if ( (dest & 1) == 0 )
          {
LABEL_62:
            if ( (v48 & 1) == 0 )
              return v4;
LABEL_63:
            operator delete(v49);
            return v4;
          }
        }
        else if ( (dest & 1) == 0 )
        {
          goto LABEL_62;
        }
        operator delete(v45);
        if ( (v48 & 1) == 0 )
          return v4;
        goto LABEL_63;
      }
    }
    memcpy(v9, v6, v8);
    goto LABEL_13;
  }
  std::string::basic_string(this, a3);
  return v4;
}


// Address: 0x105c620 | Name: _ZN3RBXL28sanitizeAnimationIdNonStudioERKNS_11AnimationIdE
RBX *__fastcall RBX::sanitizeAnimationIdNonStudio(RBX *this, const RBX::AnimationId *a2)
{
  RBX *v2; // rbx
  unsigned __int64 v3; // rax
  unsigned __int64 v4; // rax
  __int64 v5; // rbx
  unsigned __int8 v6; // r14
  unsigned __int64 v7; // rax
  char v8; // r13
  bool v9; // r15
  _BYTE *v10; // rcx
  unsigned int v11; // ebp
  unsigned __int64 v12; // r12
  unsigned __int64 v13; // rbx
  const unsigned __int16 **v14; // rax
  __int64 v15; // rsi
  const unsigned __int16 **v16; // rdx
  _BYTE *v17; // r13
  __int64 v18; // rbx
  const unsigned __int16 **v19; // r14
  const __int32_t **v20; // rax
  _BYTE *v21; // r14
  const void *v22; // rax
  char *v23; // rbp
  size_t v24; // rbx
  char *v25; // rax
  char *v26; // rax
  char *v27; // rax
  char *v28; // rax
  char *v29; // rax
  char *v31; // rax
  char *v32; // rax
  unsigned __int8 v33; // [rsp+8h] [rbp-50h] BYREF
  _BYTE s[7]; // [rsp+9h] [rbp-4Fh] BYREF
  unsigned __int64 v35; // [rsp+10h] [rbp-48h]
  void *ptr; // [rsp+18h] [rbp-40h]
  RBX *v37; // [rsp+20h] [rbp-38h]

  v2 = this;
  if ( !(unsigned int)std::string::compare(a2, 0, 13, "rbxassetid://") )
  {
    RBX::sanitizePrintedId(this, a2, 14);
  }
  else if ( !(unsigned int)std::string::compare(a2, 0, 4, "http")
         || !(unsigned int)std::string::compare(a2, 0, 10, "rbxhttp://") )
  {
    v37 = this;
    v5 = 0;
    std::string::basic_string(&v33, a2, 0, 128, a2);
    v6 = v33;
    v7 = (unsigned __int64)v33 >> 1;
    v8 = v33 & 1;
    v9 = (v33 & 1) == 0;
    if ( (v33 & 1) != 0 )
      v7 = v35;
    v10 = s;
    if ( v7 )
    {
      v11 = 1;
      v12 = 0;
      v13 = v35;
      v14 = __ctype_b_loc();
      v15 = v13;
      v10 = s;
      v16 = v14;
      do
      {
        v17 = s;
        if ( !v9 )
          v17 = ptr;
        v18 = (unsigned __int8)v17[v12];
        if ( ((*v16)[v18] & 0x100) != 0 )
        {
          if ( (unsigned int)(v18 + 128) <= 0x17F )
          {
            v19 = v16;
            v20 = __ctype_tolower_loc();
            v16 = v19;
            v10 = s;
            LODWORD(v18) = (*v20)[v18];
          }
          v17[v12] = v18;
          v6 = v33;
          v15 = v35;
        }
        v12 = v11;
        v8 = v6 & 1;
        v9 = (v6 & 1) == 0;
        v5 = v6 >> 1;
        if ( (v6 & 1) != 0 )
          v5 = v15;
        ++v11;
      }
      while ( v5 > v12 );
    }
    if ( v8 )
      v10 = ptr;
    if ( v5 >= 3 )
    {
      v21 = v10;
      v22 = v10;
      v23 = &v10[v5];
      do
      {
        v24 = v5 - 2;
        if ( !v24 )
          break;
        v25 = (char *)memchr(v22, 105, v24);
        if ( !v25 )
          break;
        if ( !(*(_WORD *)v25 ^ 0x6469 | (unsigned __int8)v25[2] ^ 0x3D) )
        {
          if ( v25 == v23 )
            break;
          v28 = (char *)(v25 - v21);
          if ( v28 == (char *)-1LL )
            break;
          v2 = v37;
          RBX::sanitizePrintedId(v37, &v33, v28 + 3);
          if ( (v33 & 1) != 0 )
            goto LABEL_39;
          return v2;
        }
        v22 = v25 + 1;
        v5 = v23 - (_BYTE *)v22;
      }
      while ( v23 - (_BYTE *)v22 >= 3 );
    }
    v2 = v37;
    *(_OWORD *)v37 = 0;
    *((_QWORD *)v2 + 2) = 0;
    v29 = (char *)operator new(0x40u);
    *((_QWORD *)v2 + 2) = v29;
    *(_OWORD *)v2 = xmmword_3E71F0;
    strcpy(v29, "<error: id not found in first 128 char for http AssetId>");
    if ( v8 )
LABEL_39:
      operator delete(ptr);
  }
  else if ( !(unsigned int)std::string::compare(a2, 0, 7, "file://") )
  {
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
    v26 = (char *)operator new(0x20u);
    *((_QWORD *)this + 2) = v26;
    *(_OWORD *)this = *(_OWORD *)&stru_3EB180.vtable;
    strcpy(v26, "<error: file:// not allowed>");
  }
  else if ( !(unsigned int)std::string::compare(a2, 0, 10, "rbxtemp://") )
  {
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
    v27 = (char *)operator new(0x20u);
    *((_QWORD *)this + 2) = v27;
    *(_OWORD *)this = xmmword_3E71E0;
    strcpy(v27, "<error: rbxtemp:// not allowed>");
  }
  else if ( !(unsigned int)std::string::compare(a2, 0, 11, "rbxasset://") )
  {
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
    v31 = (char *)operator new(0x30u);
    *((_QWORD *)this + 2) = v31;
    *(_OWORD *)this = xmmword_3E71C0;
    strcpy(v31, "<error: rbxasset:// file not found>");
  }
  else
  {
    v3 = *(unsigned __int8 *)a2;
    if ( (v3 & 1) != 0 )
      v4 = *((_QWORD *)a2 + 1);
    else
      v4 = v3 >> 1;
    *(_OWORD *)this = 0;
    *((_QWORD *)this + 2) = 0;
    if ( v4 )
    {
      v32 = (char *)operator new(0x30u);
      *((_QWORD *)this + 2) = v32;
      *(_OWORD *)this = xmmword_3E8C20;
      strcpy(v32, "<error: unknown AssetId protocol>");
    }
    else
    {
      strcpy((char *)this, " <error: null id>");
    }
  }
  return v2;
}


// Address: 0x105ca70 | Name: _ZN3RBXL25AsyncKeyframeLoaderHelperENS_17HttpRequestResultEPNSt3__113basic_istreamIcNS1_11char_traitsIcEEEEN5boost8weak_ptrINS_24KeyframeSequenceProviderEEENS8_INS_16KeyframeSequenceEEERKNS1_12basic_stringIcS4_NS1_9allocatorIcEEEERKNS_18InstanceIdentifierENS7_8functionIFvNS7_10shared_ptrINS_8InstanceEEEEEENSM_IFvSG_EEE
void __fastcall RBX::AsyncKeyframeLoaderHelper(
        RBX::HttpRequestResult result,
        std::istream *stream,
        boost::weak_ptr<RBX::KeyframeSequenceProvider> keyframeSequenceProvider,
        boost::weak_ptr<RBX::KeyframeSequence> keyframeSequence,
        const std::string *assetId,
        const RBX::InstanceIdentifier *instanceIdentifier)
{
  char pi; // r14
  boost::detail::sp_counted_base *px; // r15
  boost::detail::sp_counted_base *v8; // rax
  volatile signed __int32 *v9; // rbx
  __int64 v10; // rax
  __int64 v11; // rax
  boost::weak_ptr<RBX::KeyframeSequenceProvider> v12; // rdx
  boost::weak_ptr<RBX::KeyframeSequence> v13; // r8
  void (__fastcall *v14)(_BYTE *, _BYTE *, __int64); // rax
  void (__fastcall *v15)(_BYTE *, _BYTE *, __int64); // rax
  boost::detail::sp_counted_base *v16; // rdi
  _BYTE v17[72]; // [rsp-8h] [rbp-A0h] BYREF
  __int64 v18; // [rsp+40h] [rbp-58h]
  boost::weak_ptr<RBX::KeyframeSequenceProvider> v19; // [rsp+48h] [rbp-50h] BYREF
  _QWORD keyframeSequenceProvidera[8]; // [rsp+58h] [rbp-40h] BYREF

  pi = (char)keyframeSequence.pn.pi_;
  px = (boost::detail::sp_counted_base *)keyframeSequence.px;
  v19.px = (boost::weak_ptr<RBX::KeyframeSequenceProvider>::element_type *)keyframeSequenceProvider.px->_vptr$EventSource;
  v8 = (boost::detail::sp_counted_base *)keyframeSequenceProvider.px->weak_this_.px;
  v19.pn.pi_ = v8;
  if ( v8 )
    _InterlockedAdd(&v8->weak_count_, 1u);
  keyframeSequenceProvidera[0] = keyframeSequenceProvider.pn.pi_->_vptr$sp_counted_base;
  v9 = *(volatile signed __int32 **)&keyframeSequenceProvider.pn.pi_->use_count_;
  keyframeSequenceProvidera[1] = v9;
  if ( v9 )
    _InterlockedAdd(v9 + 3, 1u);
  *(_QWORD *)&v17[48] = 0;
  v10 = *(_QWORD *)assetId;
  if ( *(_QWORD *)assetId )
  {
    *(_QWORD *)&v17[48] = *(_QWORD *)assetId;
    if ( (v10 & 1) != 0 )
    {
      v18 = *((_QWORD *)assetId + 3);
      *(_OWORD *)&v17[56] = *(_OWORD *)((char *)assetId + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, _BYTE *, _QWORD))(v10 & 0xFFFFFFFFFFFFFFFELL))((char *)assetId + 8, &v17[56], 0);
    }
  }
  *(_QWORD *)&v17[16] = 0;
  v11 = *(_QWORD *)instanceIdentifier;
  if ( *(_QWORD *)instanceIdentifier )
  {
    *(_QWORD *)&v17[16] = *(_QWORD *)instanceIdentifier;
    if ( (v11 & 1) != 0 )
    {
      *(_QWORD *)&v17[40] = *((_QWORD *)instanceIdentifier + 3);
      *(_OWORD *)&v17[24] = *(_OWORD *)((char *)instanceIdentifier + 8);
    }
    else
    {
      (*(void (__fastcall **)(char *, _BYTE *, _QWORD))(v11 & 0xFFFFFFFFFFFFFFFELL))(
        (char *)instanceIdentifier + 8,
        &v17[24],
        0);
    }
  }
  v12.px = (boost::weak_ptr<RBX::KeyframeSequenceProvider>::element_type *)&v19;
  v12.pn.pi_ = (boost::detail::sp_counted_base *)keyframeSequenceProvidera;
  v13.px = 0;
  v13.pn.pi_ = px;
  RBX::KeyframeLoaderHelper(
    result,
    stream,
    v12,
    v13,
    pi,
    (const std::string *)&v17[48],
    (const RBX::InstanceIdentifier *)&v17[16],
    *(boost::function<void (boost::shared_ptr<RBX::Instance>)>_0 *)v17,
    *(boost::function<void (std::string)>_0 *)&v17[32]);
  if ( *(_QWORD *)&v17[16] )
  {
    if ( (v17[16] & 1) == 0 )
    {
      v14 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v17[16] & 0xFFFFFFFFFFFFFFFELL);
      if ( v14 )
        v14(&v17[24], &v17[24], 2);
    }
    *(_QWORD *)&v17[16] = 0;
  }
  if ( *(_QWORD *)&v17[48] )
  {
    if ( (v17[48] & 1) == 0 )
    {
      v15 = *(void (__fastcall **)(_BYTE *, _BYTE *, __int64))(*(_QWORD *)&v17[48] & 0xFFFFFFFFFFFFFFFELL);
      if ( v15 )
        v15(&v17[56], &v17[56], 2);
    }
    *(_QWORD *)&v17[48] = 0;
  }
  if ( v9 && !_InterlockedSub(v9 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
  v16 = v19.pn.pi_;
  if ( v19.pn.pi_ )
  {
    if ( !_InterlockedSub(&v19.pn.pi_->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
  }
}


// Address: 0x105cd10 | Name: _Z22Class_getDescriptorPtrPN3RBX24KeyframeSequenceProviderE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::KeyframeSequenceProvider *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+21h] [rbp-27h]
  __int16 v5; // [rsp+25h] [rbp-23h]
  char v6; // [rsp+27h] [rbp-21h]
  unsigned __int64 v7; // [rsp+28h] [rbp-20h]
  __int64 v8; // [rsp+38h] [rbp-10h]

  result = qword_2A03FE0;
  if ( !qword_2A03FE0 )
  {
    if ( !(_BYTE)byte_2A04320 )
    {
      if ( __cxa_guard_acquire(&byte_2A04320) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 17;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A03FE8,
          v2,
          "KeyframeSequenceProvider",
          1,
          attributes,
          RBX::Security::Permissions::None,
          &dword_2A04350);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::KeyframeSequenceProvider,false>::~ClassRegistrar,
          &unk_2A03FE8,
          &dso_handle);
        __cxa_guard_release(&byte_2A04320);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A03FE8;
    qword_2A03FE0 = (RBX::Reflection::ClassDescriptor *)&unk_2A03FE8;
  }
  return result;
}


// Address: 0x105ce00 | Name: _Z16Class_getNamePtrPN3RBX24KeyframeSequenceProviderE
const RBX::Name *__fastcall Class_getNamePtr(RBX::KeyframeSequenceProvider *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A04328;
  if ( !qword_2A04328 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A04328 = result;
  }
  return result;
}


// Address: 0x105cfe0 | Name: _ZN3RBXL17sanitizePrintedIdERKNSt3__112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEm
RBX *__fastcall RBX::sanitizePrintedId(RBX *a1, unsigned __int8 *a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  unsigned __int64 v8; // rax
  unsigned __int64 v9; // rax
  char *v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // r8
  __int64 v14; // r9
  char *v15; // rax
  const char *v17; // rdx
  char v18; // r8
  unsigned __int64 v19; // rsi
  char *v20; // rdi
  unsigned __int64 v21; // rax
  char v22; // cl
  __int128 v23; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]
  __int128 v25; // [rsp+18h] [rbp-30h] BYREF
  char *v26; // [rsp+28h] [rbp-20h]

  v8 = *a2;
  if ( (v8 & 1) != 0 )
    v9 = *((_QWORD *)a2 + 1);
  else
    v9 = v8 >> 1;
  if ( v9 < a3 + 1 )
  {
    *(_OWORD *)a1 = 0;
    *((_QWORD *)a1 + 2) = 0;
    v10 = (char *)operator new(0x20u);
    *((_QWORD *)a1 + 2) = v10;
    *(_OWORD *)a1 = xmmword_3E5070;
    strcpy(v10, "<error:  missing assetid>");
    return a1;
  }
  if ( *(char *)std::string::at(a2, a3, a3, a3 + 1, a5, a6) > 57
    || *(char *)std::string::at(a2, a3, v11, v12, v13, v14) <= 47 )
  {
    *(_OWORD *)a1 = 0;
    *((_QWORD *)a1 + 2) = 0;
    v15 = (char *)operator new(0x30u);
    *((_QWORD *)a1 + 2) = v15;
    *(_OWORD *)a1 = xmmword_3E4D30;
    strcpy(v15, "<error:  assetid does not start with a number>");
    return a1;
  }
  std::string::basic_string(&v23, a2, a3, 19, a2);
  v17 = (const char *)ptr;
  v18 = v23 & 1;
  if ( (v23 & 1) != 0 )
  {
    v19 = *((_QWORD *)&v23 + 1);
    v20 = (char *)ptr;
    if ( !*((_QWORD *)&v23 + 1) )
      goto LABEL_24;
LABEL_14:
    v21 = 0;
    while ( 1 )
    {
      v22 = v20[v21];
      if ( (unsigned __int8)v22 > 0x3Fu || ((1LL << v22) & 0x3FF000000000000LL) == 0 )
        break;
      if ( v19 == ++v21 )
        goto LABEL_24;
    }
    if ( v21 < v19 )
    {
      std::string::basic_string(&v25, &v23, 0, v21, &v23);
      if ( (v23 & 1) != 0 )
      {
        *(_BYTE *)ptr = 0;
        *((_QWORD *)&v23 + 1) = 0;
      }
      else
      {
        LOWORD(v23) = 0;
      }
      std::string::reserve(&v23, 0);
      v23 = v25;
      v17 = v26;
      ptr = v26;
      v18 = v25 & 1;
    }
    goto LABEL_24;
  }
  v19 = (unsigned __int64)(unsigned __int8)v23 >> 1;
  v20 = (char *)&v23 + 1;
  if ( v19 )
    goto LABEL_14;
LABEL_24:
  if ( !v18 )
    v17 = (char *)&v23 + 1;
  RBX::format(a1, "rbxassetid://%s", v17);
  if ( (v23 & 1) != 0 )
    operator delete(ptr);
  return a1;
}


// Address: 0x105d210 | Name: _ZN3RBXL20KeyframeLoaderHelperENS_17HttpRequestResultEPNSt3__113basic_istreamIcNS1_11char_traitsIcEEEEN5boost8weak_ptrINS_24KeyframeSequenceProviderEEENS8_INS_16KeyframeSequenceEEEbRKNS1_12basic_stringIcS4_NS1_9allocatorIcEEEERKNS_18InstanceIdentifierENS7_8functionIFvNS7_10shared_ptrINS_8InstanceEEEEEENSM_IFvSG_EEE
void __fastcall RBX::KeyframeLoaderHelper(
        RBX::HttpRequestResult result,
        std::istream *stream,
        boost::weak_ptr<RBX::KeyframeSequenceProvider> keyframeSequenceProvider,
        boost::weak_ptr<RBX::KeyframeSequence> keyframeSequence,
        const RBX::InstanceIdentifier *synchronous,
        const std::string *assetId,
        const RBX::InstanceIdentifier *instanceIdentifier)
{
  boost::weak_ptr<RBX::KeyframeSequenceProvider>::element_type *px; // rbp
  char v8; // r14
  boost::detail::sp_counted_base *pi; // rbx
  RBX::Instance *v10; // r12
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *v11; // rax
  boost::detail::sp_counted_base *v12; // r13
  boost::weak_ptr<RBX::KeyframeSequence>::element_type *v13; // rbp
  void (*v14)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>); // rax
  boost::detail::sp_counted_base *v15; // r12
  volatile signed __int32 *v16; // r14
  signed __int32 v17; // eax
  int (**v18)(void); // rdi
  signed __int32 v19; // ett
  RBX::DataModel *v20; // rax
  char v21; // bl
  void **p_obj_ptr; // rdx
  unsigned __int64 v23; // rax
  const char *v24; // r12
  unsigned __int64 v25; // rax
  void *v26; // rbx
  __int64 v27; // rax
  __int64 v28; // rbp
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  volatile signed __int32 *v30; // r15
  volatile signed __int32 *v31; // rbx
  void (__fastcall *v32)(__int128 *, __int128 *, __int64); // rax
  void *v33; // rdi
  void (__fastcall *v34)(boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, __int64); // rax
  const RBX::KeyframeSequence *v35; // rbp
  signed __int32 v36; // eax
  signed __int32 v37; // ett
  void (__fastcall *v38)(boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, __int64); // rax
  void (__fastcall *v39)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, __int64); // rax
  void (__fastcall *v40)(boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, __int64); // rax
  char *v41; // r14
  char *v42; // rbp
  volatile signed __int32 *v43; // rbx
  volatile signed __int32 *obj_ptr; // r12
  void (__fastcall *v45)(boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, __int64); // rax
  RBX::DataModel *v46; // r14
  boost::weak_ptr<RBX::KeyframeSequence> v47; // rdi
  boost::shared_ptr<RBX::KeyframeSequence> v48; // rdx
  void (__fastcall *v49)(boost::_bi::value<boost::function<void (std::string)> >_0 *, boost::_bi::value<boost::function<void (std::string)> >_0 *, __int64); // rax
  void (__fastcall *v50)(boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, __int64); // rax
  void *v51; // rdi
  boost::weak_ptr<RBX::KeyframeSequence> v52; // rdx
  boost::shared_ptr<RBX::KeyframeSequence> v53; // r8
  void (__fastcall *v54)(boost::_bi::value<boost::function<void (std::string)> >_0 *, boost::_bi::value<boost::function<void (std::string)> >_0 *, __int64); // rax
  void (__fastcall *v55)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, __int64); // rax
  void (__fastcall *v56)(boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, __int64); // rax
  volatile signed __int32 *v57; // r14
  boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > > v58; // [rsp+0h] [rbp-1B8h] BYREF
  boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > v59; // [rsp+68h] [rbp-150h] BYREF
  boost::shared_ptr<RBX::KeyframeSequence>::element_type *v60; // [rsp+78h] [rbp-140h]
  boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void (boost::shared_ptr<RBX::Instance>)>,boost::function<void (std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > > v61; // [rsp+80h] [rbp-138h] BYREF
  void (*v62)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>); // [rsp+F0h] [rbp-C8h]
  boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > v63; // [rsp+F8h] [rbp-C0h] BYREF
  boost::shared_ptr<RBX::KeyframeSequence>::element_type *v64; // [rsp+108h] [rbp-B0h]
  void *v65[2]; // [rsp+110h] [rbp-A8h] BYREF
  __int64 v66; // [rsp+120h] [rbp-98h]
  unsigned __int64 weakKeyframeSequence; // [rsp+128h] [rbp-90h] BYREF
  boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > v68; // [rsp+130h] [rbp-88h] BYREF
  boost::shared_ptr<RBX::KeyframeSequence>::element_type *v69; // [rsp+140h] [rbp-78h]
  unsigned __int64 v70; // [rsp+148h] [rbp-70h] BYREF
  __int128 v71; // [rsp+150h] [rbp-68h] BYREF
  __int64 v72; // [rsp+160h] [rbp-58h]
  const RBX::KeyframeSequence *a1; // [rsp+168h] [rbp-50h] BYREF
  volatile signed __int32 *v74; // [rsp+170h] [rbp-48h]
  boost::weak_ptr<RBX::KeyframeSequence> v75; // [rsp+178h] [rbp-40h] BYREF

  px = keyframeSequenceProvider.px;
  if ( result != RBX::HttpRequestResult::Http_Failed )
  {
    if ( result != RBX::HttpRequestResult::Http_Succeeded )
      return;
    v8 = (char)keyframeSequence.px;
    pi = keyframeSequenceProvider.pn.pi_;
    *(_OWORD *)v65 = 0;
    v66 = 0;
    RBX::Serializer::loadInstances(stream, v65);
    v10 = (RBX::Instance *)px->_vptr$EventSource;
    v11 = px->weak_this_.px;
    if ( v11 )
      _InterlockedAdd((volatile signed __int32 *)&v11->weak_this_.px + 1, 1u);
    *((_QWORD *)&v58.l_.a3_.t_.functor.data + 1) = v11;
    v12 = (boost::detail::sp_counted_base *)pi->_vptr$sp_counted_base;
    v13 = *(boost::weak_ptr<RBX::KeyframeSequence>::element_type **)&pi->use_count_;
    if ( v13 )
      _InterlockedAdd((volatile signed __int32 *)&v13->weak_this_.px + 1, 1u);
    v62 = 0;
    v14 = *(void (**)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>))assetId;
    if ( *(_QWORD *)assetId )
    {
      v62 = *(void (**)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>))assetId;
      if ( ((unsigned __int8)v14 & 1) != 0 )
      {
        v64 = (boost::shared_ptr<RBX::KeyframeSequence>::element_type *)*((_QWORD *)assetId + 3);
        v63 = *(boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *)((char *)assetId + 8);
      }
      else
      {
        (*(void (__fastcall **)(char *, boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, _QWORD))((unsigned __int64)v14 & 0xFFFFFFFFFFFFFFFELL))(
          (char *)assetId + 8,
          &v63,
          0);
      }
    }
    v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr = 0;
    v25 = *(_QWORD *)instanceIdentifier;
    if ( *(_QWORD *)instanceIdentifier )
    {
      v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr = *(void **)instanceIdentifier;
      if ( (v25 & 1) != 0 )
      {
        v60 = (boost::shared_ptr<RBX::KeyframeSequence>::element_type *)*((_QWORD *)instanceIdentifier + 3);
        v59 = *(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *)((char *)instanceIdentifier + 8);
      }
      else
      {
        (*(void (__fastcall **)(char *, boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, _QWORD))(v25 & 0xFFFFFFFFFFFFFFFELL))(
          (char *)instanceIdentifier + 8,
          &v59,
          0);
      }
    }
    v26 = v65[0];
    if ( (__int16 *)((char *)v65[1] - (char *)v65[0]) != &word_10 )
    {
      v58.l_.a1_.t_.px = v13;
      v61.f_ = 0;
      if ( v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr )
      {
        v61.f_ = (void (*)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>))v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr;
        if ( (*(&v58.l_.a4_.t_.functor.data + 16) & 1) != 0 )
        {
          v61.l_.a2_.t_.px = v60;
          v61.l_.boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > = v59;
        }
        else
        {
          (*(void (__fastcall **)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, _QWORD))((unsigned __int64)v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL))(
            &v59,
            &v61.l_,
            0);
        }
      }
      v58.l_.a2_.t_.pn.pi_ = (boost::detail::sp_counted_base *)operator new(0x30u);
      *(_OWORD *)&v58.l_.a1_.t_.pn.pi_ = xmmword_3E6A90;
      strcpy((char *)v58.l_.a2_.t_.pn.pi_, "KeyframeSequence loaded is not valid.");
      v31 = (volatile signed __int32 *)*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1);
      v13 = v58.l_.a1_.t_.px;
      if ( v61.f_ )
      {
        std::string::basic_string(&v58.l_.a3_.t_.functor.data + 16, &v58.l_.a1_.t_.pn);
        boost::function1<void,std::string>::operator()(&v61, (__int128 *)&v58.l_.a3_.t_.functor.data + 1);
        if ( (*(&v58.l_.a3_.t_.functor.data + 16) & 1) != 0 )
          operator delete(v58.l_.a4_.t_.functor.obj_ptr);
      }
      if ( ((__int64)v58.l_.a1_.t_.pn.pi_ & 1) != 0 )
        operator delete(v58.l_.a2_.t_.pn.pi_);
      if ( v61.f_ )
      {
        if ( ((__int64)v61.f_ & 1) == 0 )
        {
          v34 = *(void (__fastcall **)(boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, __int64))((unsigned __int64)v61.f_ & 0xFFFFFFFFFFFFFFFELL);
          if ( v34 )
            v34(&v61.l_, &v61.l_, 2);
        }
        v61.f_ = 0;
      }
LABEL_114:
      if ( v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr )
      {
        if ( (*(&v58.l_.a4_.t_.functor.data + 16) & 1) == 0 )
        {
          v39 = *(void (__fastcall **)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, __int64))((unsigned __int64)v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL);
          if ( v39 )
            v39(&v59, &v59, 2);
        }
        v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr = 0;
      }
      if ( v62 )
      {
        if ( ((unsigned __int8)v62 & 1) == 0 )
        {
          v40 = *(void (__fastcall **)(boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, __int64))((unsigned __int64)v62 & 0xFFFFFFFFFFFFFFFELL);
          if ( v40 )
            v40(&v63, &v63, 2);
        }
        v62 = 0;
      }
      if ( v13 && !_InterlockedSub((volatile signed __int32 *)&v13->weak_this_.px + 1, 1u) )
        (*((void (__fastcall **)(boost::weak_ptr<RBX::KeyframeSequence>::element_type *))v13->_vptr$EventSource + 3))(v13);
      if ( v31 && !_InterlockedSub(v31 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v31 + 24LL))(v31);
      v41 = (char *)v65[0];
      if ( v65[0] )
      {
        v42 = (char *)v65[1];
        if ( v65[1] == v65[0] )
        {
          v33 = v65[0];
        }
        else
        {
          do
          {
            v43 = (volatile signed __int32 *)*((_QWORD *)v42 - 1);
            if ( v43 && !_InterlockedSub(v43 + 2, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v43 + 16LL))(v43);
              if ( !_InterlockedSub(v43 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v43 + 24LL))(v43);
            }
            v42 -= 16;
          }
          while ( v41 != v42 );
          v33 = v65[0];
        }
        v65[1] = v41;
        goto LABEL_140;
      }
      return;
    }
    v27 = *(_QWORD *)v65[0];
    if ( !*(_QWORD *)v65[0] )
    {
      v30 = 0;
      v31 = (volatile signed __int32 *)*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1);
LABEL_96:
      v61.f_ = 0;
      if ( v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr )
      {
        v61.f_ = (void (*)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>))v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr;
        if ( (*(&v58.l_.a4_.t_.functor.data + 16) & 1) != 0 )
        {
          v61.l_.a2_.t_.px = v60;
          v61.l_.boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > = v59;
        }
        else
        {
          (*(void (__fastcall **)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, _QWORD))((unsigned __int64)v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL))(
            &v59,
            &v61.l_,
            0);
        }
      }
      v58.l_.a2_.t_.pn.pi_ = (boost::detail::sp_counted_base *)operator new(0x30u);
      *(_OWORD *)&v58.l_.a1_.t_.pn.pi_ = xmmword_3E6A90;
      strcpy((char *)v58.l_.a2_.t_.pn.pi_, "KeyframeSequence loaded is not valid.");
      if ( v61.f_ )
      {
        std::string::basic_string(&v58.l_.a3_.t_.functor.data + 16, &v58.l_.a1_.t_.pn);
        boost::function1<void,std::string>::operator()(&v61, (__int128 *)&v58.l_.a3_.t_.functor.data + 1);
        if ( (*(&v58.l_.a3_.t_.functor.data + 16) & 1) != 0 )
          operator delete(v58.l_.a4_.t_.functor.obj_ptr);
      }
      if ( ((__int64)v58.l_.a1_.t_.pn.pi_ & 1) != 0 )
        operator delete(v58.l_.a2_.t_.pn.pi_);
      if ( v61.f_ )
      {
        if ( ((__int64)v61.f_ & 1) == 0 )
        {
          v38 = *(void (__fastcall **)(boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, __int64))((unsigned __int64)v61.f_ & 0xFFFFFFFFFFFFFFFELL);
          if ( v38 )
            v38(&v61.l_, &v61.l_, 2);
        }
        v61.f_ = 0;
      }
      goto LABEL_110;
    }
    v58.l_.a1_.t_.px = v13;
    v28 = *(_QWORD *)(v27 + 24);
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *(unsigned __int16 *)(v28 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      v30 = 0;
      v31 = (volatile signed __int32 *)*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1);
LABEL_95:
      v13 = v58.l_.a1_.t_.px;
      goto LABEL_96;
    }
    v35 = *(const RBX::KeyframeSequence **)v26;
    v30 = (volatile signed __int32 *)*((_QWORD *)v26 + 1);
    if ( v30 )
      _InterlockedAdd(v30 + 2, 1u);
    v31 = (volatile signed __int32 *)*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1);
    if ( !v35 )
      goto LABEL_95;
    if ( *((_QWORD *)&v58.l_.a3_.t_.functor.data + 1) )
    {
      v36 = *(_DWORD *)(*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1) + 8LL);
      v58.l_.a3_.t_.functor.obj_ptr = 0;
      do
      {
        if ( !v36 )
          goto LABEL_143;
        v37 = v36;
        v36 = _InterlockedCompareExchange(
                (volatile signed __int32 *)(*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1) + 8LL),
                v36 + 1,
                v36);
      }
      while ( v37 != v36 );
      v58.l_.a3_.t_.functor.obj_ptr = (void *)*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1);
      if ( !v10 )
        goto LABEL_143;
      v58.l_.a3_.t_.functor.obj_ptr = (void *)*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1);
      RBX::KeyframeSequence::getCachedData(v35);
      if ( v8 )
      {
        v58.l_.a1_.t_.pn.pi_ = v12;
        v58.l_.a2_.t_.px = v58.l_.a1_.t_.px;
        if ( v58.l_.a1_.t_.px )
          _InterlockedAdd((volatile signed __int32 *)&v58.l_.a1_.t_.px->weak_this_.px + 1, 1u);
        weakKeyframeSequence = (unsigned __int64)v35;
        v68.a1_.t_.px = (boost::weak_ptr<RBX::KeyframeSequence>::element_type *)v30;
        if ( v30 )
          _InterlockedAdd(v30 + 2, 1u);
        v61.f_ = 0;
        if ( v62 )
        {
          v61.f_ = v62;
          if ( ((unsigned __int8)v62 & 1) != 0 )
          {
            v61.l_.a2_.t_.px = v64;
            v61.l_.boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > = (boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > >)v63;
          }
          else
          {
            (*(void (__fastcall **)(boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, _QWORD))((unsigned __int64)v62 & 0xFFFFFFFFFFFFFFFELL))(
              &v63,
              &v61.l_,
              0);
          }
        }
        v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr = 0;
        if ( v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr )
        {
          v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr = v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr;
          if ( (*(&v58.l_.a4_.t_.functor.data + 16) & 1) != 0 )
          {
            *((_QWORD *)&v58.l_.a4_.t_.functor.data + 1) = v60;
            *(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *)&v58.l_.a4_.t_.vtable = v59;
          }
          else
          {
            (*(void (__fastcall **)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::value<boost::function<void (std::string)> >_0 *, _QWORD))((unsigned __int64)v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL))(
              &v59,
              &v58.l_.a4_,
              0);
          }
        }
        v47.px = (boost::weak_ptr<RBX::KeyframeSequence>::element_type *)&v58.l_.a1_.t_.pn;
        v47.pn.pi_ = (boost::detail::sp_counted_base *)&weakKeyframeSequence;
        v48.px = (boost::shared_ptr<RBX::KeyframeSequence>::element_type *)&v61;
        v48.pn.pi_ = (boost::detail::sp_counted_base *)(&v58.l_.a3_.t_.functor.data + 16);
        RBX::transferKeyframeSequenceData(
          v47,
          v48,
          *(boost::function<void (boost::shared_ptr<RBX::Instance>)>_0 *)&v58.f_,
          *(boost::function<void (std::string)>_0 *)&v58.l_.a2_.t_.pn.pi_);
        if ( v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr )
        {
          if ( (*(&v58.l_.a3_.t_.functor.data + 16) & 1) == 0 )
          {
            v49 = *(void (__fastcall **)(boost::_bi::value<boost::function<void (std::string)> >_0 *, boost::_bi::value<boost::function<void (std::string)> >_0 *, __int64))((unsigned __int64)v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL);
            if ( v49 )
              v49(&v58.l_.a4_, &v58.l_.a4_, 2);
          }
          v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr = 0;
        }
        if ( v61.f_ )
        {
          if ( ((__int64)v61.f_ & 1) == 0 )
          {
            v50 = *(void (__fastcall **)(boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, __int64))((unsigned __int64)v61.f_ & 0xFFFFFFFFFFFFFFFELL);
            if ( v50 )
              v50(&v61.l_, &v61.l_, 2);
          }
          v61.f_ = 0;
        }
        if ( v30 )
        {
          if ( !_InterlockedSub(v30 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v30 + 16LL))(v30);
            if ( !_InterlockedSub(v30 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v30 + 24LL))(v30);
          }
        }
        v51 = v58.l_.a2_.t_.px;
        obj_ptr = v31;
        if ( v58.l_.a2_.t_.px )
        {
          obj_ptr = v31;
          if ( !_InterlockedSub((volatile signed __int32 *)&v58.l_.a2_.t_.px->weak_this_.px + 1, 1u) )
          {
LABEL_192:
            (*(void (__fastcall **)(void *))(*(_QWORD *)v51 + 24LL))(v51);
            obj_ptr = v31;
          }
        }
      }
      else
      {
        v46 = RBX::DataModel::get(v10);
        obj_ptr = (volatile signed __int32 *)*((_QWORD *)&v58.l_.a3_.t_.functor.data + 1);
        if ( v46 )
        {
          v75.px = (boost::weak_ptr<RBX::KeyframeSequence>::element_type *)v12;
          v75.pn.pi_ = (boost::detail::sp_counted_base *)v58.l_.a1_.t_.px;
          if ( v58.l_.a1_.t_.px )
            _InterlockedAdd((volatile signed __int32 *)&v58.l_.a1_.t_.px->weak_this_.px + 1, 1u);
          a1 = v35;
          v74 = v30;
          if ( v30 )
            _InterlockedAdd(v30 + 2, 1u);
          v58.l_.a1_.t_.pn.pi_ = 0;
          if ( v62 )
          {
            v58.l_.a1_.t_.pn.pi_ = (boost::detail::sp_counted_base *)v62;
            if ( ((unsigned __int8)v62 & 1) != 0 )
            {
              v58.l_.a3_.t_.vtable = (boost::detail::function::vtable_base *)v64;
              v58.l_.a2_ = v63;
            }
            else
            {
              (*(void (__fastcall **)(boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, _QWORD))((unsigned __int64)v62 & 0xFFFFFFFFFFFFFFFELL))(
                &v63,
                &v58.l_.a2_,
                0);
            }
          }
          weakKeyframeSequence = 0;
          if ( v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr )
          {
            weakKeyframeSequence = (unsigned __int64)v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr;
            if ( (*(&v58.l_.a4_.t_.functor.data + 16) & 1) != 0 )
            {
              v69 = v60;
              v68 = v59;
            }
            else
            {
              (*(void (__fastcall **)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, _QWORD))((unsigned __int64)v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL))(
                &v59,
                &v68,
                0);
            }
          }
          v52.px = (boost::weak_ptr<RBX::KeyframeSequence>::element_type *)&v75;
          v52.pn.pi_ = (boost::detail::sp_counted_base *)&a1;
          v53.px = (boost::shared_ptr<RBX::KeyframeSequence>::element_type *)&v58.l_.a1_.t_.pn;
          v53.pn.pi_ = (boost::detail::sp_counted_base *)&weakKeyframeSequence;
          boost::bind<void,boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>,boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>>(
            &v61,
            RBX::transferKeyframeSequenceData,
            v52,
            v53,
            *(boost::function<void (boost::shared_ptr<RBX::Instance>)>_0 *)&v58.f_,
            *(boost::function<void (std::string)>_0 *)&v58.l_.a2_.t_.pn.pi_);
          boost::function<void ()(RBX::DataModel *)>::function<boost::_bi::bind_t<void,void (*)(boost::weak_ptr<RBX::KeyframeSequence>,boost::shared_ptr<RBX::KeyframeSequence>,boost::function<void ()(boost::shared_ptr<RBX::Instance>)>,boost::function<void ()(std::string)>),boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>>>(
            (boost::function<void (RBX::DataModel *)>_0 *)(&v58.l_.a3_.t_.functor.data + 16),
            v58,
            (boost::enable_if_c<true,int>::type)&v61);
          RBX::DataModel::submitTask(
            v46,
            *(RBX::DataModel::Task *)&v58.f_,
            (RBX::DataModelJob::TaskType)(&v58.l_.a3_.t_.functor.data + 16));
          if ( v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr )
          {
            if ( (*(&v58.l_.a3_.t_.functor.data + 16) & 1) == 0 )
            {
              v54 = *(void (__fastcall **)(boost::_bi::value<boost::function<void (std::string)> >_0 *, boost::_bi::value<boost::function<void (std::string)> >_0 *, __int64))((unsigned __int64)v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL);
              if ( v54 )
                v54(&v58.l_.a4_, &v58.l_.a4_, 2);
            }
            v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr = 0;
          }
          boost::_bi::storage4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence>>,boost::_bi::value<boost::function<void ()(boost::shared_ptr<RBX::Instance>)>>,boost::_bi::value<boost::function<void ()(std::string)>>>::~storage4(&v61.l_);
          if ( weakKeyframeSequence )
          {
            if ( (weakKeyframeSequence & 1) == 0 )
            {
              v55 = *(void (__fastcall **)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, __int64))(weakKeyframeSequence & 0xFFFFFFFFFFFFFFFELL);
              if ( v55 )
                v55(&v68, &v68, 2);
            }
            weakKeyframeSequence = 0;
          }
          if ( v58.l_.a1_.t_.pn.pi_ )
          {
            if ( ((__int64)v58.l_.a1_.t_.pn.pi_ & 1) == 0 )
            {
              v56 = *(void (__fastcall **)(boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> > *, __int64))((unsigned __int64)v58.l_.a1_.t_.pn.pi_ & 0xFFFFFFFFFFFFFFFELL);
              if ( v56 )
                v56(&v58.l_.a2_, &v58.l_.a2_, 2);
            }
            v58.l_.a1_.t_.pn.pi_ = 0;
          }
          v57 = v74;
          if ( v74 )
          {
            if ( !_InterlockedSub(v74 + 2, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v57 + 16LL))(v57);
              if ( !_InterlockedSub(v57 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v57 + 24LL))(v57);
            }
          }
          v51 = v75.pn.pi_;
          obj_ptr = v31;
          if ( v75.pn.pi_ )
          {
            obj_ptr = v31;
            if ( !_InterlockedSub(&v75.pn.pi_->weak_count_, 1u) )
              goto LABEL_192;
          }
        }
      }
    }
    else
    {
      v58.l_.a3_.t_.functor.obj_ptr = 0;
LABEL_143:
      v61.f_ = 0;
      if ( v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr )
      {
        v61.f_ = (void (*)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>))v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr;
        if ( (*(&v58.l_.a4_.t_.functor.data + 16) & 1) != 0 )
        {
          v61.l_.a2_.t_.px = v60;
          v61.l_.boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > = v59;
        }
        else
        {
          (*(void (__fastcall **)(boost::_bi::storage1<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, _QWORD))((unsigned __int64)v58.l_.a4_.t_.functor.bound_memfunc_ptr.obj_ptr & 0xFFFFFFFFFFFFFFFELL))(
            &v59,
            &v61.l_,
            0);
        }
      }
      v58.l_.a2_.t_.pn.pi_ = (boost::detail::sp_counted_base *)operator new(0x40u);
      *(_OWORD *)&v58.l_.a1_.t_.pn.pi_ = xmmword_3E5410;
      strcpy((char *)v58.l_.a2_.t_.pn.pi_, "Could not access KeyframeSequenceProvider service.");
      obj_ptr = (volatile signed __int32 *)v58.l_.a3_.t_.functor.obj_ptr;
      if ( v61.f_ )
      {
        std::string::basic_string(&v58.l_.a3_.t_.functor.data + 16, &v58.l_.a1_.t_.pn);
        boost::function1<void,std::string>::operator()(&v61, (__int128 *)&v58.l_.a3_.t_.functor.data + 1);
        if ( (*(&v58.l_.a3_.t_.functor.data + 16) & 1) != 0 )
          operator delete(v58.l_.a4_.t_.functor.obj_ptr);
      }
      if ( ((__int64)v58.l_.a1_.t_.pn.pi_ & 1) != 0 )
        operator delete(v58.l_.a2_.t_.pn.pi_);
      if ( v61.f_ )
      {
        if ( ((__int64)v61.f_ & 1) == 0 )
        {
          v45 = *(void (__fastcall **)(boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, boost::_bi::list4<boost::_bi::value<boost::weak_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::shared_ptr<RBX::KeyframeSequence> >,boost::_bi::value<boost::function<void (boost::shared_ptr<RBX::Instance>)> >,boost::_bi::value<boost::function<void (std::string)> > > *, __int64))((unsigned __int64)v61.f_ & 0xFFFFFFFFFFFFFFFELL);
          if ( v45 )
            v45(&v61.l_, &v61.l_, 2);
        }
        v61.f_ = 0;
      }
    }
    if ( !obj_ptr )
    {
      v13 = v58.l_.a1_.t_.px;
      if ( !v30 )
        goto LABEL_114;
      goto LABEL_111;
    }
    v13 = v58.l_.a1_.t_.px;
    if ( !_InterlockedSub(obj_ptr + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)obj_ptr + 16LL))(obj_ptr);
      if ( !_InterlockedSub(obj_ptr + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)obj_ptr + 24LL))(obj_ptr);
    }
LABEL_110:
    if ( !v30 )
      goto LABEL_114;
LABEL_111:
    if ( !_InterlockedSub(v30 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v30 + 16LL))(v30);
      if ( !_InterlockedSub(v30 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v30 + 24LL))(v30);
    }
    goto LABEL_114;
  }
  v15 = keyframeSequence.pn.pi_;
  memset(&v58.l_.a3_.t_.functor.data + 16, 0, 24);
  v16 = (volatile signed __int32 *)keyframeSequenceProvider.px->weak_this_.px;
  if ( v16 )
  {
    v17 = *((_DWORD *)v16 + 2);
    v18 = 0;
    while ( v17 )
    {
      v19 = v17;
      v17 = _InterlockedCompareExchange(v16 + 2, v17 + 1, v17);
      if ( v19 == v17 )
      {
        v18 = keyframeSequenceProvider.px->_vptr$EventSource;
        goto LABEL_17;
      }
    }
    v16 = 0;
  }
  else
  {
    v16 = 0;
    v18 = 0;
  }
LABEL_17:
  v20 = RBX::DataModel::get((RBX::Instance *)v18);
  if ( v20 && RBX::DataModel::isInStudio(v20) )
  {
    v21 = 0;
  }
  else
  {
    std::string::basic_string(&v58.l_.a1_.t_.pn, v15);
    RBX::ContentId::CorrectBackslash((std::string *)&v58.l_.a1_.t_.pn);
    RBX::sanitizeAnimationIdNonStudio((RBX *)&v61, (const RBX::AnimationId *)&v58.l_.a1_.t_.pn);
    if ( (*(&v58.l_.a3_.t_.functor.data + 16) & 1) != 0 )
    {
      *(_BYTE *)v58.l_.a4_.t_.functor.obj_ptr = 0;
      v58.l_.a4_.t_.vtable = 0;
    }
    else
    {
      *((_WORD *)&v58.l_.a3_.t_.functor.data + 8) = 0;
    }
    std::string::reserve(&v58.l_.a3_.t_.functor.data + 16, 0);
    v58.l_.a4_.t_.functor.obj_ptr = v61.l_.a1_.t_.pn.pi_;
    *((_OWORD *)&v58.l_.a3_.t_.functor.data + 1) = *(_OWORD *)&v61.f_;
    memset(&v61, 0, 24);
    if ( ((__int64)v58.l_.a1_.t_.pn.pi_ & 1) != 0 )
      operator delete(v58.l_.a2_.t_.pn.pi_);
    v21 = 1;
  }
  v61.l_.a1_.t_.px = (boost::weak_ptr<RBX::KeyframeSequence>::element_type *)("_ZNSt13runtime_errorC1ERKNSt3__112basic_st"
                                                                              "ringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE"
                                                                            + 6);
  v61.l_.a1_.t_.pn.pi_ = 0;
  LOBYTE(v61.f_) = 18;
  *(void (**)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>))((char *)&v61.f_ + 1) = (void (*)(boost::weak_ptr<RBX::KeyframeSequence>, boost::shared_ptr<RBX::KeyframeSequence>, boost::function<void (boost::shared_ptr<RBX::Instance>)>, boost::function<void (std::string)>))0x6F6974616D696E41LL;
  memset(&v58.l_.a1_.t_.pn, 0, 24);
  v58.l_.a2_.t_.pn.pi_ = (boost::detail::sp_counted_base *)operator new(0x20u);
  *(_OWORD *)&v58.l_.a1_.t_.pn.pi_ = *(_OWORD *)&userJoinData.vtable;
  strcpy((char *)v58.l_.a2_.t_.pn.pi_, "Animation failed to load");
  p_obj_ptr = &v58.l_.a3_.t_.functor.bound_memfunc_ptr.obj_ptr;
  if ( !v21 )
    p_obj_ptr = (void **)&v15->_vptr$sp_counted_base;
  RBX::StandardOut::printAssetLoadErrorWithIdentifierLink(
    (const std::string *)&v61,
    synchronous,
    (const std::string *)p_obj_ptr,
    (const std::string *)&v58.l_.a1_.t_.pn);
  if ( ((__int64)v58.l_.a1_.t_.pn.pi_ & 1) != 0 )
    operator delete(v58.l_.a2_.t_.pn.pi_);
  if ( ((__int64)v61.f_ & 1) != 0 )
    operator delete(v61.l_.a1_.t_.pn.pi_);
  v70 = 0;
  v23 = *(_QWORD *)instanceIdentifier;
  if ( *(_QWORD *)instanceIdentifier )
  {
    v70 = *(_QWORD *)instanceIdentifier;
    if ( (v23 & 1) != 0 )
    {
      v72 = *((_QWORD *)instanceIdentifier + 3);
      v71 = *(_OWORD *)((char *)instanceIdentifier + 8);
      if ( ((__int64)v15->_vptr$sp_counted_base & 1) != 0 )
        goto LABEL_36;
LABEL_50:
      v24 = (char *)&v15->_vptr$sp_counted_base + 1;
      goto LABEL_51;
    }
    (*(void (__fastcall **)(char *, __int128 *, _QWORD))(v23 & 0xFFFFFFFFFFFFFFFELL))(
      (char *)instanceIdentifier + 8,
      &v71,
      0);
  }
  if ( ((__int64)v15->_vptr$sp_counted_base & 1) == 0 )
    goto LABEL_50;
LABEL_36:
  v24 = (const char *)v15[1]._vptr$sp_counted_base;
LABEL_51:
  RBX::format((RBX *)&v58.l_.a1_.t_.pn, "Animation failed to load, assetId: %s", v24);
  if ( v70 )
  {
    std::string::basic_string(&v61, &v58.l_.a1_.t_.pn);
    boost::function1<void,std::string>::operator()(&v70, (__int128 *)&v61);
    if ( ((__int64)v61.f_ & 1) != 0 )
      operator delete(v61.l_.a1_.t_.pn.pi_);
  }
  if ( ((__int64)v58.l_.a1_.t_.pn.pi_ & 1) != 0 )
    operator delete(v58.l_.a2_.t_.pn.pi_);
  if ( v70 )
  {
    if ( (v70 & 1) == 0 )
    {
      v32 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))(v70 & 0xFFFFFFFFFFFFFFFELL);
      if ( v32 )
        v32(&v71, &v71, 2);
    }
    v70 = 0;
  }
  if ( v16 )
  {
    if ( !_InterlockedSub(v16 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
      if ( !_InterlockedSub(v16 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
    }
  }
  if ( (*(&v58.l_.a3_.t_.functor.data + 16) & 1) != 0 )
  {
    v33 = v58.l_.a4_.t_.functor.obj_ptr;
LABEL_140:
    operator delete(v33);
  }
}


// Address: 0x105e900 | Name: _ZN3RBXL28transferKeyframeSequenceDataEN5boost8weak_ptrINS_16KeyframeSequenceEEENS0_10shared_ptrIS2_EENS0_8functionIFvNS4_INS_8InstanceEEEEEENS6_IFvNSt3__112basic_stringIcNSB_11char_traitsIcEENSB_9allocatorIcEEEEEEE
void __fastcall RBX::transferKeyframeSequenceData(
        boost::weak_ptr<RBX::KeyframeSequence> weakKeyframeSequence,
        boost::shared_ptr<RBX::KeyframeSequence> keyframeSequenceData)
{
  boost::detail::sp_counted_base *px; // rbx
  boost::shared_ptr<RBX::KeyframeSequence>::element_type *v3; // r14
  signed __int32 use_count; // eax
  signed __int32 v5; // ett
  int (**v6)(void); // r15
  unsigned __int64 v7; // rdx
  boost::detail::sp_counted_base *pi; // r14
  int (**v9)(void); // rax
  void (__fastcall *v10)(__int128 *, __int128 *, __int64); // rax
  int (**v11)(void); // [rsp+0h] [rbp-78h] BYREF
  __int128 v12; // [rsp+8h] [rbp-70h] BYREF
  __int64 v13; // [rsp+18h] [rbp-60h]
  __int128 v14; // [rsp+20h] [rbp-58h] BYREF
  void *v15; // [rsp+30h] [rbp-48h]
  boost::shared_ptr<RBX::Instance> a0; // [rsp+38h] [rbp-40h] BYREF
  __int128 v17; // [rsp+48h] [rbp-30h] BYREF
  void *ptr; // [rsp+58h] [rbp-20h]

  px = (boost::detail::sp_counted_base *)weakKeyframeSequence.px->weak_this_.px;
  if ( px )
  {
    v3 = keyframeSequenceData.px;
    use_count = px->use_count_;
    while ( use_count )
    {
      v5 = use_count;
      use_count = _InterlockedCompareExchange(&px->use_count_, use_count + 1, use_count);
      if ( v5 == use_count )
      {
        v6 = weakKeyframeSequence.px->_vptr$EventSource;
        if ( !weakKeyframeSequence.px->_vptr$EventSource )
          goto LABEL_12;
        RBX::KeyframeSequence::transferKeyframeSequence(
          (RBX::KeyframeSequence *)weakKeyframeSequence.px->_vptr$EventSource,
          (RBX::KeyframeSequence *)weakKeyframeSequence.pn.pi_->_vptr$sp_counted_base);
        if ( v3->_vptr$EventSource )
        {
          a0.px = (boost::shared_ptr<RBX::Instance>::element_type *)v6;
          a0.pn.pi_ = px;
          _InterlockedAdd(&px->use_count_, 1u);
          boost::function1<void,boost::shared_ptr<RBX::Instance>>::operator()(
            (const boost::function1<void,boost::shared_ptr<RBX::Instance> >_0 *)v3,
            (boost::shared_ptr<RBX::Instance>)__PAIR128__(v7, &a0));
          pi = a0.pn.pi_;
          if ( a0.pn.pi_ )
          {
            if ( !_InterlockedSub(&a0.pn.pi_->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
              if ( !_InterlockedSub(&pi->weak_count_, 1u) )
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
            }
          }
        }
        goto LABEL_26;
      }
    }
  }
  px = 0;
LABEL_12:
  v11 = 0;
  v9 = keyframeSequenceData.pn.pi_->_vptr$sp_counted_base;
  if ( keyframeSequenceData.pn.pi_->_vptr$sp_counted_base )
  {
    v11 = keyframeSequenceData.pn.pi_->_vptr$sp_counted_base;
    if ( ((unsigned __int8)v9 & 1) != 0 )
    {
      v13 = *(_QWORD *)&keyframeSequenceData.pn.pi_[1].use_count_;
      v12 = *(_OWORD *)&keyframeSequenceData.pn.pi_->use_count_;
    }
    else
    {
      (*(void (__fastcall **)(boost::detail::atomic_int_least32_t *, __int128 *, _QWORD))((unsigned __int64)v9
                                                                                        & 0xFFFFFFFFFFFFFFFELL))(
        &keyframeSequenceData.pn.pi_->use_count_,
        &v12,
        0);
    }
  }
  v14 = 0;
  v15 = 0;
  v15 = operator new(0x30u);
  v14 = xmmword_3E6A90;
  strcpy((char *)v15, "Unable to copy KeyframeSequence data.");
  if ( v11 )
  {
    std::string::basic_string(&v17, &v14);
    boost::function1<void,std::string>::operator()(&v11, &v17);
    if ( (v17 & 1) != 0 )
      operator delete(ptr);
  }
  if ( (v14 & 1) != 0 )
    operator delete(v15);
  if ( v11 )
  {
    if ( ((unsigned __int8)v11 & 1) == 0 )
    {
      v10 = *(void (__fastcall **)(__int128 *, __int128 *, __int64))((unsigned __int64)v11 & 0xFFFFFFFFFFFFFFFELL);
      if ( v10 )
        v10(&v12, &v12, 2);
    }
    v11 = 0;
  }
LABEL_26:
  if ( px && !_InterlockedSub(&px->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 2))(px);
    if ( !_InterlockedSub(&px->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))px->_vptr$sp_counted_base + 3))(px);
  }
}


// Address: 0x1069d50 | Name: _GLOBAL__sub_I_KeyframeSequenceProvider.cpp
void __cdecl GLOBAL__sub_I_KeyframeSequenceProvider_cpp()
{
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::Reflection::ClassDescriptor *v1; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::Descriptor::Attributes v3; // [rsp+18h] [rbp-30h] BYREF
  RBX::Reflection::Descriptor::Attributes v4; // 0:r8.1,8:r9.8
  RBX::Reflection::Descriptor::Attributes v5; // 0:r8.1,8:r9.8
  RBX::Reflection::Descriptor::Attributes v6; // 0:r8.1,8:r9.8

  qword_2A03C40 = (__int64)boost::system::generic_category();
  qword_2A03C48 = (__int64)boost::system::generic_category();
  qword_2A03C50 = (__int64)boost::system::system_category();
  stru_2A03C58.value = 0;
  stru_2A03C58.name = "AnimationLoadSimplification2";
  dword_2A03C68 = FLog::RegisterFlag("AnimationLoadSimplification2", &stru_2A03C58, FastVarType::FASTVARTYPE_DYNAMIC);
  v3.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,RBX::ContentId ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,RBX::ContentId (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A03C70,
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,RBX::ContentId (boost::shared_ptr<RBX::Instance>),1>::FunctionPtr)RBX::KeyframeSequenceProvider::registerActiveKeyframeSequence,
    0,
    "RegisterActiveKeyframeSequence",
    (RBX::Security::Permissions)"keyframeSequence",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v3.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,RBX::ContentId ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A03C70,
    &dso_handle);
  v3.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,RBX::ContentId ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,RBX::ContentId (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A03CF0,
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,RBX::ContentId (boost::shared_ptr<RBX::Instance>),1>::FunctionPtr)RBX::KeyframeSequenceProvider::registerKeyframeSequence,
    0,
    "RegisterKeyframeSequence",
    (RBX::Security::Permissions)"keyframeSequence",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v3.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,RBX::ContentId ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A03CF0,
    &dso_handle);
  v3.isDeprecated = 0;
  RBX::Reflection::BoundYieldFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(RBX::ContentId),1>::BoundYieldFuncDesc(
    (RBX::Reflection::BoundYieldFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> (RBX::ContentId),1> *)&attributes,
    (RBX::Reflection::BoundYieldFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> (RBX::ContentId),1>::YieldFunctionPtr)RBX::KeyframeSequenceProvider::getKeyframeSequenceAsyncLua,
    0,
    (const char *)&stru_3F7F76.descriptor + 1,
    (RBX::Security::Permissions)"assetId",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v3.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundYieldFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(RBX::ContentId),1>::~BoundYieldFuncDesc,
    &attributes,
    &dso_handle);
  v3.isDeprecated = 1;
  v3.preferred = (const RBX::Reflection::Descriptor *)&attributes;
  RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(RBX::ContentId),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> (RBX::ContentId),1> *)&unk_2A03DE8,
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> (RBX::ContentId),1>::FunctionPtr)RBX::KeyframeSequenceProvider::getKeyframeSequenceLua,
    0,
    (const char *)&stru_3F7F76.guid + 2,
    (RBX::Security::Permissions)"assetId",
    (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v3));
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(RBX::ContentId),1>::~BoundFuncDesc,
    &unk_2A03DE8,
    &dso_handle);
  DescriptorPtr = Class_getDescriptorPtr((RBX::KeyframeSequenceProvider *)RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(RBX::ContentId),1>::~BoundFuncDesc);
  v4.isDeprecated = 1;
  v4.preferred = (const RBX::Reflection::Descriptor *)&attributes;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A03E68,
    DescriptorPtr,
    "GetKeyframeSequenceById",
    RBX::Security::Permissions::Plugin,
    v4);
  qword_2A03E68[0] = &off_2890078;
  qword_2A03ED0 = (__int64)RBX::KeyframeSequenceProvider::getKeyframeSequenceByIdLua;
  xmmword_2A03ED8 = 0;
  qword_2A03EE8 = 0;
  RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(long,bool),2>::declareSignature(
    (RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> (long,bool),2> *)qword_2A03E68,
    "assetId",
    "useCache");
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(long,bool),2>::~BoundFuncDesc,
    qword_2A03E68,
    &dso_handle);
  v1 = Class_getDescriptorPtr((RBX::KeyframeSequenceProvider *)RBX::Reflection::BoundFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(long,bool),2>::~BoundFuncDesc);
  v5.isDeprecated = 0;
  v5.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A03EF0,
    v1,
    "GetMemStats",
    RBX::Security::Permissions::RobloxScript,
    v5);
  qword_2A03EF0[0] = &off_2890128;
  xmmword_2A03F58 = (unsigned __int64)RBX::KeyframeSequenceProvider::getMemStats;
  qword_2A03F30 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<boost::unordered::unordered_map<std::string,RBX::Reflection::Variant,boost::hash<std::string>,std::equal_to<std::string>,std::allocator<std::pair<std::string const,RBX::Reflection::Variant>>> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A03EF0, &dso_handle);
  v2 = Class_getDescriptorPtr((RBX::KeyframeSequenceProvider *)RBX::Reflection::FunctionDescriptor::~FunctionDescriptor);
  v6.isDeprecated = 0;
  v6.preferred = 0;
  RBX::Reflection::YieldFunctionDescriptor::YieldFunctionDescriptor(
    (RBX::Reflection::YieldFunctionDescriptor *)qword_2A03F68,
    v2,
    "GetAnimations",
    RBX::Security::Permissions::None,
    v6);
  qword_2A03F68[0] = &off_28900C8;
  qword_2A03FC8 = (__int64)RBX::KeyframeSequenceProvider::getAnimations;
  xmmword_2A03FD0 = 0;
  RBX::Reflection::BoundYieldFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(long),1>::declareSignature(
    (RBX::Reflection::BoundYieldFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> (long),1> *)qword_2A03F68,
    "userId");
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundYieldFuncDesc<RBX::KeyframeSequenceProvider,boost::shared_ptr<RBX::Instance> ()(long),1>::~BoundYieldFuncDesc,
    qword_2A03F68,
    &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_1);
}


