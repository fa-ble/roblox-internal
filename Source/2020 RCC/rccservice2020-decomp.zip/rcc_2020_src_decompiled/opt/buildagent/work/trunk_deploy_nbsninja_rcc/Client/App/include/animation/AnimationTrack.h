// Address: 0x10450b0 | Name: _ZNK3RBX14AnimationTrack15getTargetWeightEv
float __fastcall RBX::AnimationTrack::getTargetWeight(const RBX::AnimationTrack *this)
{
  return this->weightTarget;
}


