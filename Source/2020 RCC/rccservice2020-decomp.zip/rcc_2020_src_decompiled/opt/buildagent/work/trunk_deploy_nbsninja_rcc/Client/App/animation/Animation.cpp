// Address: 0x10497c0 | Name: _ZN3RBX9Animation10setAssetIdENS_11AnimationIdE
void __fastcall RBX::Animation::setAssetId(__int64 a1, const RBX::ContentId *a2)
{
  int v2; // edx
  void *v3; // rcx
  size_t v4; // r8
  const void *v5; // r9

  if ( RBX::operator!=((const RBX::ContentId *)(a1 + 128), a2) )
  {
    std::string::operator=((soap *)(a1 + 128), (int)a2, v2, v3, v4, v5);
    RBX::Instance::raisePropertyChanged((RBX::Instance *)a1, &stru_2A02680);
  }
}


// Address: 0x1049810 | Name: _ZN3RBX9AnimationC2Ev
void __fastcall RBX::Animation::Animation(RBX::Animation *this)
{
  char v1; // [rsp+0h] [rbp-38h] BYREF
  char v2[8]; // [rsp+1h] [rbp-37h] BYREF
  char v3[3]; // [rsp+9h] [rbp-2Fh] BYREF
  int v4; // [rsp+Ch] [rbp-2Ch]
  void *ptr; // [rsp+10h] [rbp-28h]

  RBX::Instance::Instance((RBX::Instance *)this);
  *(_QWORD *)this = &off_288EA18;
  *((_QWORD *)this + 3) = Class_getDescriptorPtr(this);
  *(_QWORD *)this = &off_288E678;
  *((_OWORD *)this + 8) = 0;
  *((_QWORD *)this + 18) = 0;
  strcpy(v3, "n");
  v3[2] = 0;
  v4 = 0;
  ptr = 0;
  v1 = 18;
  strcpy(v2, "Animati");
  RBX::Instance::setName((RBX::Instance *)this, (const std::string *)&v1);
  if ( (v1 & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x10498e0 | Name: _ZNK3RBX9Animation15isEmbeddedAssetEv
bool __fastcall RBX::Animation::isEmbeddedAsset(const RBX::Animation *this)
{
  bool v1; // r14

  v1 = 0;
  if ( (unsigned int)std::string::compare((char *)this + 128, 0, 4, "http") )
    return (unsigned int)std::string::compare((char *)this + 128, 0, 11, "rbxasset://") != 0;
  return v1;
}


// Address: 0x1049930 | Name: _ZNK3RBX9Animation19getKeyframeSequenceEv
const RBX::Animation *__fastcall RBX::Animation::getKeyframeSequence(
        const RBX::Animation *a1,
        const RBX::Instance *this)
{
  RBX::Animation::getKeyframeSequence(a1, this, 50.0);
  return a1;
}


// Address: 0x1049950 | Name: _ZNK3RBX9Animation19getKeyframeSequenceEPKNS_8InstanceEf
const RBX::Animation *__fastcall RBX::Animation::getKeyframeSequence(
        const RBX::Animation *this,
        const RBX::Instance *context,
        float priority,
        const RBX::ServiceProvider *a4)
{
  const RBX::ServiceProvider *v4; // rbx
  unsigned __int64 v5; // rax
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rax
  const RBX::ServiceProvider *i; // rax
  __int64 v8; // r12
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::KeyframeSequenceProvider *v10; // rax
  RBX::KeyframeSequenceProvider *v11; // rbx
  _BYTE v13[16]; // [rsp+10h] [rbp-38h] BYREF
  void *ptr; // [rsp+20h] [rbp-28h]

  v4 = a4;
  v5 = LOBYTE(context[1]._vptr$EventSource);
  if ( (v5 & 1) != 0 )
  {
    px = context[1].weak_this_.px;
    if ( a4 )
      goto LABEL_3;
LABEL_12:
    *(_OWORD *)this = 0;
    return this;
  }
  px = (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *)(v5 >> 1);
  if ( !a4 )
    goto LABEL_12;
LABEL_3:
  if ( !px )
    goto LABEL_12;
  for ( i = (const RBX::ServiceProvider *)*((_QWORD *)a4 + 11); i; i = (const RBX::ServiceProvider *)*((_QWORD *)i + 11) )
    v4 = i;
  v8 = *((_QWORD *)v4 + 3);
  DescriptorPtr = Class_getDescriptorPtr(0);
  if ( !v4 )
    goto LABEL_12;
  if ( *(unsigned __int16 *)(v8 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364) )
    goto LABEL_12;
  v10 = RBX::ServiceProvider::create<RBX::KeyframeSequenceProvider>(v4);
  if ( !v10 )
    goto LABEL_12;
  v11 = v10;
  std::string::basic_string(v13, &context[1]);
  RBX::KeyframeSequenceProvider::getKeyframeSequence(this, v11, v13, context, priority);
  if ( (v13[0] & 1) != 0 )
    operator delete(ptr);
  return this;
}


// Address: 0x1049a70 | Name: _Z22Class_getDescriptorPtrPN3RBX9AnimationE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::Animation *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A026D8;
  if ( !qword_2A026D8 )
  {
    if ( !(_BYTE)byte_2A02A20 )
    {
      if ( __cxa_guard_acquire(&byte_2A02A20) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A026E0,
          v2,
          "Animation",
          0,
          attributes,
          RBX::Security::Permissions::None,
          &dword_2A04350);
        stru_2A02A18._vptr$ICreator = (int (**)(void))&off_288E8B8;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A026E8, &stru_2A02A18);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::Animation,true>::~ClassRegistrar,
          &unk_2A026E0,
          &dso_handle);
        __cxa_guard_release(&byte_2A02A20);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A026E0;
    qword_2A026D8 = (RBX::Reflection::ClassDescriptor *)&unk_2A026E0;
  }
  return result;
}


// Address: 0x1049bd0 | Name: _Z16Class_getNamePtrPN3RBX9AnimationE
const RBX::Name *__fastcall Class_getNamePtr(RBX::Animation *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A02A28;
  if ( !qword_2A02A28 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A02A28 = result;
  }
  return result;
}


// Address: 0x104a950 | Name: _GLOBAL__sub_I_Animation.cpp
void __cdecl GLOBAL__sub_I_Animation_cpp()
{
  RBX::Animation *v0; // rdi
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // r14
  char *v2; // rbx
  const RBX::Reflection::Type *v3; // rax
  RBX::Reflection::PropertyDescriptor::Attributes attributes; // [rsp+0h] [rbp-58h]
  RBX::Reflection::PropertyDescriptor::Attributes v5; // [rsp+30h] [rbp-28h] BYREF

  qword_2A02668 = (__int64)boost::system::generic_category();
  qword_2A02670 = (__int64)boost::system::generic_category();
  qword_2A02678 = (__int64)boost::system::system_category();
  DescriptorPtr = Class_getDescriptorPtr(v0);
  v2 = (char *)operator new(0x28u);
  *(_QWORD *)v2 = &off_288E9A8;
  *(_OWORD *)(v2 + 8) = (unsigned __int64)RBX::Animation::getAssetId;
  *(_OWORD *)(v2 + 24) = (unsigned __int64)RBX::Animation::setAssetId;
  v5.isDeprecated = 0;
  v5.preferred = 0;
  v5.flags = RBX::Reflection::PropertyDescriptor::Functionality::STANDARD;
  v3 = RBX::Reflection::Type::getSingleton<RBX::AnimationId>();
  *(_QWORD *)&attributes.flags = *(_QWORD *)&v5.flags;
  attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v5);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A02680,
    DescriptorPtr,
    v3,
    "AnimationId",
    &stru_458781.gap0,
    attributes,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A02680._vptr$Descriptor = (int (**)(void))&off_288E7F8;
  qword_2A026D0 = (__int64)v2;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v2 + 24LL))(v2) )
    *((_BYTE *)&stru_2A02680.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A02680._vptr$Descriptor + 3))(&stru_2A02680) )
    *((_BYTE *)&stru_2A02680.security + 4) &= 0xF3u;
  stru_2A02680._vptr$Descriptor = (int (**)(void))&off_288E8E8;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<RBX::AnimationId>::~TypedPropertyDescriptor,
    &stru_2A02680,
    &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_0);
}


