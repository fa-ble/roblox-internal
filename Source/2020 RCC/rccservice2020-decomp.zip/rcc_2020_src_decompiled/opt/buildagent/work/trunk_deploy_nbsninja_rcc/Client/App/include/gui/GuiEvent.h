// Address: 0x14368f0 | Name: _ZN3RBX7GuiBase14processGestureENS_10GuiGestureERKN5boost10shared_ptrIKNSt3__16vectorINS_10Reflection7VariantENS4_9allocatorIS7_EEEEEERKNS3_IKNS6_5TupleEEE
RBX::GuiResponse *__fastcall RBX::GuiBase::processGesture(
        RBX::GuiResponse *__return_ptr retstr,
        RBX::GuiBase *this,
        RBX::GuiGesture_0 gesture,
        const boost::shared_ptr<const std::vector<RBX::Reflection::Variant> > *touchPositions,
        const boost::shared_ptr<const RBX::Reflection::Tuple> *args)
{
  *(_QWORD *)&retstr->response = 0;
  retstr->mouseWasOver = RBX::GuiResponse::MouseOverType::NOT_MOUSE_OVER;
  retstr->target = 0;
  return retstr;
}


// Address: 0x1436c40 | Name: _ZN3RBX7GuiBase7processERKN5boost10shared_ptrINS_11InputObjectEEE
RBX::GuiResponse *__fastcall RBX::GuiBase::process(
        RBX::GuiResponse *__return_ptr retstr,
        RBX::GuiBase *this,
        const boost::shared_ptr<RBX::InputObject> *event)
{
  *(_QWORD *)&retstr->response = 0;
  retstr->mouseWasOver = RBX::GuiResponse::MouseOverType::NOT_MOUSE_OVER;
  retstr->target = 0;
  return retstr;
}


// Address: 0x1787e50 | Name: _ZN3RBX9GuiObject10preProcessERKN5boost10shared_ptrINS_11InputObjectEEE
RBX::GuiResponse *__fastcall RBX::GuiObject::preProcess(
        RBX::GuiResponse *__return_ptr retstr,
        RBX::GuiObject *this,
        const boost::shared_ptr<RBX::InputObject> *event)
{
  *(_QWORD *)&retstr->response = 0;
  retstr->mouseWasOver = RBX::GuiResponse::MouseOverType::NOT_MOUSE_OVER;
  retstr->target = 0;
  return retstr;
}


// Address: 0x1787e80 | Name: _ZN3RBX9GuiObject20preProcessMouseEventERKN5boost10shared_ptrINS_11InputObjectEEE
RBX::GuiResponse *__fastcall RBX::GuiObject::preProcessMouseEvent(
        RBX::GuiResponse *__return_ptr retstr,
        RBX::GuiObject *this,
        const boost::shared_ptr<RBX::InputObject> *event)
{
  *(_QWORD *)&retstr->response = 0;
  retstr->mouseWasOver = RBX::GuiResponse::MouseOverType::NOT_MOUSE_OVER;
  retstr->target = 0;
  return retstr;
}


// Address: 0x17a32c0 | Name: _ZN3RBX9GuiObject15processKeyEventERKN5boost10shared_ptrINS_11InputObjectEEE
RBX::GuiResponse *__fastcall RBX::GuiObject::processKeyEvent(
        RBX::GuiResponse *__return_ptr retstr,
        RBX::GuiObject *this,
        const boost::shared_ptr<RBX::InputObject> *event)
{
  *(_QWORD *)&retstr->response = 0;
  retstr->mouseWasOver = RBX::GuiResponse::MouseOverType::NOT_MOUSE_OVER;
  retstr->target = 0;
  return retstr;
}


// Address: 0x17a3370 | Name: _ZN3RBX9GuiObject19processGamepadEventERKN5boost10shared_ptrINS_11InputObjectEEE
RBX::GuiResponse *__fastcall RBX::GuiObject::processGamepadEvent(
        RBX::GuiResponse *__return_ptr retstr,
        RBX::GuiObject *this,
        const boost::shared_ptr<RBX::InputObject> *event)
{
  *(_QWORD *)&retstr->response = 0;
  retstr->mouseWasOver = RBX::GuiResponse::MouseOverType::NOT_MOUSE_OVER;
  retstr->target = 0;
  return retstr;
}


