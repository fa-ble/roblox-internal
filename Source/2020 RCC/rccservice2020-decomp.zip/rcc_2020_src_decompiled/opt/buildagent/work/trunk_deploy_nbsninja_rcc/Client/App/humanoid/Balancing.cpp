// Address: 0x10e5c30 | Name: _ZN3RBX5HUMAN9BalancingC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Balancing::Balancing(
        RBX::HUMAN::Balancing *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v4; // r14

  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895850;
  *(_OWORD *)((char *)this + 312) = xmmword_3E8570;
  *((_QWORD *)this + 41) = 0xFFFFFFFF00000000LL;
  *((_DWORD *)this + 86) = 0;
  *((_OWORD *)this + 23) = 0;
  *((_OWORD *)this + 22) = 0;
  *((_DWORD *)this + 96) = 0;
  RootBodyFast = RBX::Humanoid::getRootBodyFast(humanoid);
  v4 = RootBodyFast;
  if ( RootBodyFast )
  {
    RBX::Body::updatePV(RootBodyFast);
    *((_DWORD *)this + 85) = LODWORD(v4->pv.position.translation.y);
  }
  *((_DWORD *)this + 84) = *((_DWORD *)this + 4);
  if ( stru_2A10FE8.value )
  {
    *((float *)this + 78) = (float)dword_2859538;
    *((float *)this + 79) = (float)dword_2859548;
  }
}


// Address: 0x10e5d80 | Name: _ZN3RBX5HUMAN9BalancingC2EPNS_8HumanoidENS0_9StateTypeEff
void __fastcall RBX::HUMAN::Balancing::Balancing(
        RBX::HUMAN::Balancing *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState,
        float kP,
        float kD)
{
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v6; // r14

  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895850;
  *((float *)this + 78) = kP;
  *((float *)this + 79) = kD;
  *((_QWORD *)this + 40) = 0;
  *((_QWORD *)this + 41) = 0xFFFFFFFF00000000LL;
  *((_DWORD *)this + 86) = 0;
  *((_OWORD *)this + 23) = 0;
  *((_OWORD *)this + 22) = 0;
  *((_DWORD *)this + 96) = 0;
  RootBodyFast = RBX::Humanoid::getRootBodyFast(humanoid);
  v6 = RootBodyFast;
  if ( RootBodyFast )
  {
    RBX::Body::updatePV(RootBodyFast);
    *((_DWORD *)this + 85) = LODWORD(v6->pv.position.translation.y);
  }
  *((_DWORD *)this + 84) = *((_DWORD *)this + 4);
}


// Address: 0x10e5ec0 | Name: _ZN3RBX5HUMAN9Balancing11balanceRateEd
__int64 __fastcall RBX::HUMAN::Balancing::balanceRate(double a1, double torqueMag)
{
  return (unsigned int)(int)(a1 / -12000.0 + 20.0);
}


// Address: 0x10e5ef0 | Name: _ZN3RBX5HUMAN9Balancing18onComputeForceImplEv
void __fastcall RBX::HUMAN::Balancing::onComputeForceImpl(RBX::HUMAN::Balancing *this)
{
  __m128 v1; // xmm0
  __m128 v2; // xmm1
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v6; // r12
  int v7; // eax
  RBX::Body *v8; // rax
  RBX::Solver::SolverRigidBody *v9; // rbx
  RBX::Humanoid *v10; // rax
  RBX::Body *TorsoBodyFast; // rax
  RBX::Body *v12; // rbx
  __m128 v13; // xmm4
  __m128 z_low; // xmm3
  RBX::Solver::SolverRigidBody *rigidBody; // rax
  __m128 v16; // xmm0
  __m128 v17; // xmm1
  float v18; // xmm2_4
  __m128 v19; // xmm1
  __m128 v20; // xmm1
  __m128 v21; // xmm2
  __m128 v22; // xmm1
  __m128i v23; // xmm0
  __m128 v24; // xmm3
  __m128 v25; // xmm2
  __m128 v26; // xmm4
  __m128 v27; // xmm0
  __m128 v28; // xmm1
  __m128 v29; // xmm2
  __m128 v30; // xmm2
  __m128 v31; // xmm2
  __m128 v32; // xmm4
  __m128 v33; // xmm0
  float v34; // xmm0_4
  __m128 v35; // xmm2
  float v36; // xmm6_4
  float v37; // xmm10_4
  float v38; // xmm0_4
  float v39; // xmm7_4
  float v40; // xmm15_4
  float v41; // xmm2_4
  float v42; // xmm4_4
  float v43; // xmm8_4
  float v44; // xmm3_4
  __m128 v45; // xmm14
  __m128 v46; // xmm11
  __m128 v47; // xmm12
  __m128 v48; // xmm13
  float v49; // xmm11_4
  float v50; // xmm6_4
  float v51; // xmm0_4
  __m128 v52; // xmm9
  __m128 v53; // xmm4
  RBX::Cofm *v54; // rbx
  RBX::Cofm *v55; // rdi
  float *v56; // rcx
  float *v57; // rsi
  unsigned int *v58; // rdx
  float *v59; // rax
  float *v60; // rdi
  float *v61; // r10
  float *v62; // r8
  float *v63; // r9
  float *v64; // rbx
  RBX::Cofm *v65; // r15
  __m128 v66; // xmm1
  RBX::Cofm *cofm; // rbx
  __int128 v68; // xmm0
  __int128 v69; // xmm1
  float *p_moment; // rax
  __m128 v71; // xmm0
  __m128 v72; // xmm6
  float v73; // xmm4_4
  RBX::Body *root; // rax
  RBX::Solver::SolverRigidBody *v75; // rbx
  float v76; // xmm1_4
  float v77; // xmm11_4
  __m128 v78; // xmm5
  __m128 v79; // xmm0
  __m128 v80; // xmm0
  __m128 v81; // xmm0
  __m128 v82; // xmm1
  __m128 *v83; // rax
  __m128 v84; // xmm2
  __m128 v85; // xmm4
  __m128 v86; // xmm2
  __m128 v87; // xmm2
  __m128 v88; // xmm6
  __m128 v89; // xmm3
  __m128 v90; // xmm6
  __m128 v91; // xmm6
  float v92; // xmm5_4
  float v93; // xmm0_4
  __m128 v94; // xmm4
  __m128 v95; // xmm3
  float v96; // xmm6_4
  RBX::Body *v97; // rax
  RBX::Solver::SolverRigidBody *v98; // rbx
  float v99; // xmm1_4
  __m128 v100; // [rsp+0h] [rbp-138h]
  __m128 v101; // [rsp+0h] [rbp-138h]
  __m128 v102; // [rsp+0h] [rbp-138h]
  __m128 v103; // [rsp+10h] [rbp-128h]
  __m128 v104; // [rsp+10h] [rbp-128h]
  __m128 v105; // [rsp+10h] [rbp-128h]
  float v106; // [rsp+10h] [rbp-128h]
  float z; // [rsp+24h] [rbp-114h]
  float v108; // [rsp+28h] [rbp-110h]
  float v109; // [rsp+2Ch] [rbp-10Ch]
  float v110; // [rsp+30h] [rbp-108h]
  __m128 v111; // [rsp+30h] [rbp-108h]
  __m128 v112; // [rsp+50h] [rbp-E8h]
  RBX::Matrix3 iBody; // [rsp+60h] [rbp-D8h] BYREF
  RBX::Matrix3 v114; // [rsp+88h] [rbp-B0h] BYREF
  __m128 v115; // [rsp+B0h] [rbp-88h]
  __m128 v116; // [rsp+C0h] [rbp-78h]
  __m128 v117; // [rsp+D0h] [rbp-68h]
  __m128 v118; // [rsp+E0h] [rbp-58h]
  __m128 v119; // [rsp+F0h] [rbp-48h]
  __m128 v120; // [rsp+100h] [rbp-38h]
  G3D::Vector3 v121; // 0:kr00_12.12
  G3D::Vector3 v122; // 0:kr14_12.12
  G3D::Vector3 v123; // 0:kr20_12.12
  RBX::Vector3 v124; // 0:kr34_12.12

  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RootBodyFast = RBX::Humanoid::getRootBodyFast(HumanoidConst);
  if ( RootBodyFast )
  {
    v6 = RootBodyFast;
    v7 = *((_DWORD *)this + 83);
    if ( v7 <= 0 )
    {
      v10 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
      TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(v10);
      if ( TorsoBodyFast )
      {
        v12 = TorsoBodyFast;
        RBX::Body::updatePV(TorsoBodyFast);
        v121 = G3D::Matrix3::column(&v12->pv.position.rotation, 1);
        v1.m128_i32[0] = LODWORD(v121.x);
        v1.m128_i32[1] = LODWORD(v121.y);
        v2.m128_i32[0] = LODWORD(v121.z);
        v100 = v2;
        RBX::Body::updatePV(v12);
        v13 = (__m128)*(unsigned __int64 *)&v12->pv.velocity.rotational.x;
        z_low = (__m128)LODWORD(v12->pv.velocity.rotational.z);
        rigidBody = v6->root->rigidBody;
        if ( rigidBody )
        {
          v119 = (__m128)*(unsigned __int64 *)&rigidBody->torque.x;
          z = rigidBody->torque.z;
        }
        else
        {
          z = 0.0;
          v119 = 0;
        }
        v16 = _mm_shuffle_ps(v1, v1, 229);
        v110 = z_low.m128_f32[0];
        v112 = v13;
        if ( v16.m128_f32[0] >= -0.89999998
          || (v17 = _mm_mul_ps(v13, v13),
              v18 = _mm_shuffle_ps(v17, v17, 229).m128_f32[0] + v17.m128_f32[0],
              v19 = z_low,
              fsqrt((float)(z_low.m128_f32[0] * z_low.m128_f32[0]) + v18) >= 0.0099999998) )
        {
          v20 = 0;
          v20.m128_f32[0] = 0.0 * v121.x;
          v21 = _mm_mul_ps((__m128)0LL, _mm_unpacklo_ps(v16, v100));
          v101 = _mm_sub_ps(_mm_unpacklo_ps(v100, v20), v21);
          v21.m128_f32[0] = v21.m128_f32[0] - v121.x;
          v103 = v21;
        }
        else
        {
          RBX::Body::updatePV(v12);
          v122 = G3D::Matrix3::column(&v12->pv.position.rotation, 0);
          v16.m128_i32[0] = LODWORD(v122.x);
          v16.m128_i32[1] = LODWORD(v122.y);
          v101 = _mm_mul_ps(v16, (__m128)xmmword_3E50C0);
          v19.m128_f32[0] = v122.z * -0.25;
          v103 = v19;
        }
        RBX::Body::updatePV(v6);
        if ( stru_2A10FE8.value )
        {
          v22 = (__m128)*((unsigned int *)this + 79);
          v23 = _mm_xor_si128(_mm_cvtsi32_si128(*((_DWORD *)this + 78)), *(__m128i *)&stru_3E4970.x);
          v24 = _mm_mul_ps(v101, (__m128)_mm_shuffle_epi32(v23, 80));
          v25 = v103;
          v25.m128_f32[0] = v103.m128_f32[0] * *(float *)v23.m128i_i32;
          v26 = v25;
          v27 = (__m128)LODWORD(v110);
          v27.m128_f32[0] = v110 * v22.m128_f32[0];
          v28 = _mm_shuffle_ps(v22, v22, 224);
          v102 = _mm_sub_ps(v24, _mm_mul_ps(v112, v28));
          v26.m128_f32[0] = v25.m128_f32[0] - v27.m128_f32[0];
          v104 = v26;
          v123 = G3D::Matrix3::column(&v6->pv.position.rotation, 1);
          v27.m128_i32[0] = LODWORD(v123.x);
          v27.m128_i32[1] = LODWORD(v123.y);
          v28.m128_i32[0] = LODWORD(v123.z);
          v32 = v104;
          v29 = _mm_mul_ps(v102, v27);
          v24.m128_f32[0] = _mm_shuffle_ps(v29, v29, 229).m128_f32[0] + v29.m128_f32[0];
          v30 = v28;
          v30.m128_f32[0] = (float)(v123.z * v104.m128_f32[0]) + v24.m128_f32[0];
          v28.m128_f32[0] = v123.z * v30.m128_f32[0];
          v31 = _mm_sub_ps(v102, _mm_mul_ps(_mm_shuffle_ps(v30, v30, 224), v27));
          v32.m128_f32[0] = v104.m128_f32[0] - v28.m128_f32[0];
          v33 = _mm_mul_ps(v31, v31);
          v34 = (float)(v32.m128_f32[0] * v32.m128_f32[0])
              + (float)(_mm_shuffle_ps(v33, v33, 229).m128_f32[0] + v33.m128_f32[0]);
          if ( v34 >= 0.000001 )
          {
            v66 = (__m128)0x457A0000u;
            v66.m128_f32[0] = fminf(4000.0 / fsqrt(v34), 1.0);
            v32.m128_f32[0] = v32.m128_f32[0] * v66.m128_f32[0];
            v35 = _mm_mul_ps(v31, _mm_shuffle_ps(v66, v66, 224));
          }
          else
          {
            v32 = 0;
            v35 = 0;
          }
          cofm = v6->cofm;
          v105 = v32;
          if ( cofm )
          {
            RBX::Cofm::updateIfDirty(cofm);
            iBody.elt[2][2] = cofm->branch.moment.elt[2][2];
            v68 = *(_OWORD *)&cofm->branch.moment.elt[0][0];
            v69 = *(_OWORD *)&cofm->branch.moment.elt[1][1];
          }
          else
          {
            if ( !v6->isMassless || v6->root == v6 )
              p_moment = (float *)&v6->bodyMass.moment;
            else
              p_moment = (float *)&unk_58DF6C;
            iBody.elt[2][2] = p_moment[8];
            v68 = *(_OWORD *)p_moment;
            v69 = *((_OWORD *)p_moment + 1);
          }
          *(_OWORD *)&iBody.elt[1][1] = v69;
          *(_OWORD *)&iBody.elt[0][0] = v68;
          RBX::Body::updatePV(v6);
          RBX::Math::momentToWorldSpace(&v114, &iBody, &v6->pv.position.rotation);
          v71 = _mm_shuffle_ps(v35, v35, 229);
          v72 = _mm_add_ps(
                  _mm_mul_ps(
                    _mm_shuffle_ps(v105, v105, 224),
                    _mm_unpacklo_ps((__m128)LODWORD(v114.elt[0][2]), (__m128)LODWORD(v114.elt[1][2]))),
                  _mm_add_ps(
                    _mm_mul_ps(_mm_unpacklo_ps((__m128)LODWORD(v114.elt[0][1]), (__m128)LODWORD(v114.elt[1][1])), v71),
                    _mm_mul_ps(
                      _mm_shuffle_ps(v35, v35, 224),
                      _mm_unpacklo_ps((__m128)LODWORD(v114.elt[0][0]), (__m128)LODWORD(v114.elt[1][0])))));
          v73 = (float)(v105.m128_f32[0] * v114.elt[2][2])
              + (float)((float)(v114.elt[2][1] * v71.m128_f32[0]) + (float)(v114.elt[2][0] * v35.m128_f32[0]));
          root = v6->root;
          v75 = root->rigidBody;
          if ( v75 )
          {
            LODWORD(v76) = _mm_shuffle_ps(v72, v72, 229).m128_u32[0];
            if ( v75->dirty )
            {
              v106 = (float)(v105.m128_f32[0] * v114.elt[2][2])
                   + (float)((float)(v114.elt[2][1] * v71.m128_f32[0]) + (float)(v114.elt[2][0] * v35.m128_f32[0]));
              RBX::Solver::SolverRigidBody::update(root->rigidBody);
              v73 = v106;
            }
            v75->torque.x = v75->torque.x + v72.m128_f32[0];
            v75->torque.y = v76 + v75->torque.y;
            v75->torque.z = v75->torque.z + v73;
          }
          _mm_storel_ps((double *)this + 40, v72);
          *((float *)this + 82) = v73;
        }
        else
        {
          v36 = _mm_shuffle_ps(v101, v101, 229).m128_f32[0];
          v37 = v6->pv.position.rotation.elt[0][0];
          v38 = v6->pv.position.rotation.elt[1][0];
          v39 = v6->pv.position.rotation.elt[2][0];
          v45 = v103;
          v116.m128_f32[0] = (float)(v103.m128_f32[0] * v39)
                           + (float)((float)(v36 * v38) + (float)(v101.m128_f32[0] * v37));
          v40 = v6->pv.position.rotation.elt[0][1];
          v41 = v6->pv.position.rotation.elt[1][1];
          v52 = (__m128)LODWORD(v6->pv.position.rotation.elt[2][1]);
          v115.m128_f32[0] = (float)(v103.m128_f32[0] * v52.m128_f32[0])
                           + (float)((float)(v36 * v41) + (float)(v101.m128_f32[0] * v40));
          v42 = v6->pv.position.rotation.elt[0][2];
          v43 = v6->pv.position.rotation.elt[1][2];
          v44 = v6->pv.position.rotation.elt[2][2];
          v45.m128_f32[0] = (float)(v103.m128_f32[0] * v44)
                          + (float)((float)(v36 * v43) + (float)(v101.m128_f32[0] * v42));
          v46 = _mm_shuffle_ps(v112, v112, 229);
          v47 = v46;
          v47.m128_f32[0] = (float)(v46.m128_f32[0] * v38) + (float)(v112.m128_f32[0] * v37);
          v48 = v46;
          v48.m128_f32[0] = (float)(v46.m128_f32[0] * v41) + (float)(v112.m128_f32[0] * v40);
          v49 = (float)(v46.m128_f32[0] * v43) + (float)(v112.m128_f32[0] * v42);
          v50 = _mm_shuffle_ps(v119, v119, 229).m128_f32[0];
          v109 = (float)(v39 * z) + (float)((float)(v38 * v50) + (float)(v37 * v119.m128_f32[0]));
          v51 = v110 * v52.m128_f32[0];
          v52.m128_f32[0] = (float)(v52.m128_f32[0] * z) + (float)((float)(v41 * v50) + (float)(v40 * v119.m128_f32[0]));
          v108 = (float)(v44 * z) + (float)((float)(v50 * v43) + (float)(v42 * v119.m128_f32[0]));
          v53 = _mm_xor_ps((__m128)*((unsigned int *)this + 78), *(__m128 *)&stru_3E4970.x);
          v54 = v6->cofm;
          if ( v54 )
          {
            v55 = v6->cofm;
            v118 = v47;
            v117 = v48;
            v120 = v53;
            RBX::Cofm::updateIfDirty(v55);
            v53.m128_i32[0] = v120.m128_i32[0];
            v56 = (float *)&v54->branch.moment;
            v57 = &v54->branch.moment.elt[0][1];
            v58 = (unsigned int *)&v54->branch.moment.elt[0][2];
            v59 = v54->branch.moment.elt[1];
            v60 = &v54->branch.moment.elt[1][1];
            v61 = &v54->branch.moment.elt[1][2];
            v62 = v54->branch.moment.elt[2];
            v63 = &v54->branch.moment.elt[2][1];
            v64 = &v54->branch.moment.elt[2][2];
            v65 = v6->cofm;
          }
          else
          {
            if ( !v6->isMassless || v6->root == v6 )
              v56 = (float *)&v6->bodyMass.moment;
            else
              v56 = (float *)&unk_58DF6C;
            v57 = v56 + 1;
            v58 = (unsigned int *)(v56 + 2);
            v59 = v56 + 3;
            v60 = v56 + 4;
            v61 = v56 + 5;
            v62 = v56 + 6;
            v63 = v56 + 7;
            v64 = v56 + 8;
            v65 = 0;
          }
          v47.m128_f32[0] = v47.m128_f32[0] + (float)(v110 * v39);
          v48.m128_f32[0] = v48.m128_f32[0] + v51;
          v77 = v49 + (float)(v110 * v44);
          v78 = (__m128)*v58;
          v78.m128_f32[0] = (float)((float)(v78.m128_f32[0] * v45.m128_f32[0])
                                  + (float)((float)(*v57 * v115.m128_f32[0]) + (float)(*v56 * v116.m128_f32[0])))
                          * v53.m128_f32[0];
          v52.m128_f32[0] = v52.m128_f32[0]
                          + (float)((float)((float)(*v61 * v45.m128_f32[0])
                                          + (float)((float)(*v60 * v115.m128_f32[0]) + (float)(*v59 * v116.m128_f32[0])))
                                  * v53.m128_f32[0]);
          v45.m128_f32[0] = (float)((float)(v45.m128_f32[0] * *v64)
                                  + (float)((float)(v115.m128_f32[0] * *v63) + (float)(v116.m128_f32[0] * *v62)))
                          * v53.m128_f32[0];
          v79 = (__m128)LODWORD(v109);
          v111 = v78;
          v79.m128_f32[0] = v109 + v78.m128_f32[0];
          v115 = v79;
          v80 = (__m128)LODWORD(v108);
          v80.m128_f32[0] = v108 + v45.m128_f32[0];
          v116 = v80;
          v118 = v47;
          v117 = v48;
          if ( v65 )
          {
            RBX::Cofm::updateIfDirty(v65);
            iBody.elt[2][2] = v65->branch.moment.elt[2][2];
            v81 = *(__m128 *)&v65->branch.moment.elt[0][0];
            v82 = *(__m128 *)&v65->branch.moment.elt[1][1];
          }
          else
          {
            if ( !v6->isMassless || v6->root == v6 )
              v83 = (__m128 *)&v6->bodyMass.moment;
            else
              v83 = (__m128 *)&unk_58DF6C;
            LODWORD(iBody.elt[2][2]) = v83[2].m128_i32[0];
            v81 = *v83;
            v82 = v83[1];
          }
          *(__m128 *)&iBody.elt[1][1] = v82;
          *(__m128 *)&iBody.elt[0][0] = v81;
          v124 = RBX::Math::toDiagonal(&iBody);
          v81.m128_i32[0] = LODWORD(v124.x);
          v81.m128_i32[1] = LODWORD(v124.y);
          v84 = v111;
          v84.m128_f32[0] = v111.m128_f32[0] - v109;
          v85.m128_f32[0] = v124.x * 4000.0;
          v86 = _mm_cmplt_ss(_mm_and_ps(v84, (__m128)xmmword_3E5B40), v85);
          v87 = _mm_or_ps(_mm_andnot_ps(v86, v115), _mm_and_ps(v111, v86));
          v88 = v45;
          v88.m128_f32[0] = v45.m128_f32[0] - v108;
          v89.m128_f32[0] = 4000.0 * v124.z;
          v90 = _mm_cmplt_ss(_mm_and_ps(v88, (__m128)xmmword_3E5B40), v89);
          v91 = _mm_or_ps(_mm_andnot_ps(v90, v116), _mm_and_ps(v45, v90));
          v92 = v117.m128_f32[0] * _mm_shuffle_ps(v81, v81, 229).m128_f32[0];
          v93 = *((float *)this + 79);
          v87.m128_f32[0] = v87.m128_f32[0] - (float)((float)(v118.m128_f32[0] * v124.x) * v93);
          v94 = v52;
          v94.m128_f32[0] = v52.m128_f32[0] - (float)(v92 * v93);
          v91.m128_f32[0] = v91.m128_f32[0] - (float)((float)(v77 * v124.z) * v93);
          v95 = _mm_sub_ps(
                  _mm_add_ps(
                    _mm_mul_ps(
                      _mm_shuffle_ps(v91, v91, 224),
                      _mm_unpacklo_ps(
                        (__m128)LODWORD(v6->pv.position.rotation.elt[0][2]),
                        (__m128)LODWORD(v6->pv.position.rotation.elt[1][2]))),
                    _mm_add_ps(
                      _mm_mul_ps(
                        _mm_shuffle_ps(v94, v94, 224),
                        _mm_unpacklo_ps(
                          (__m128)LODWORD(v6->pv.position.rotation.elt[0][1]),
                          (__m128)LODWORD(v6->pv.position.rotation.elt[1][1]))),
                      _mm_mul_ps(
                        _mm_shuffle_ps(v87, v87, 224),
                        _mm_unpacklo_ps(
                          (__m128)LODWORD(v6->pv.position.rotation.elt[0][0]),
                          (__m128)LODWORD(v6->pv.position.rotation.elt[1][0]))))),
                  v119);
          v96 = (float)((float)(v91.m128_f32[0] * v6->pv.position.rotation.elt[2][2])
                      + (float)((float)(v94.m128_f32[0] * v6->pv.position.rotation.elt[2][1])
                              + (float)(v87.m128_f32[0] * v6->pv.position.rotation.elt[2][0])))
              - z;
          v97 = v6->root;
          v98 = v97->rigidBody;
          if ( v98 )
          {
            LODWORD(v99) = _mm_shuffle_ps(v95, v95, 229).m128_u32[0];
            if ( v98->dirty )
              RBX::Solver::SolverRigidBody::update(v97->rigidBody);
            v98->torque.x = v98->torque.x + v95.m128_f32[0];
            v98->torque.y = v99 + v98->torque.y;
            v98->torque.z = v98->torque.z + v96;
          }
          _mm_storel_ps((double *)this + 40, v95);
          *((float *)this + 82) = v96;
        }
        *((_DWORD *)this + 83) = !stru_2A10FE8.value;
      }
    }
    else
    {
      *((_DWORD *)this + 83) = v7 - 1;
      v8 = v6->root;
      v9 = v8->rigidBody;
      if ( v9 )
      {
        if ( v9->dirty )
          RBX::Solver::SolverRigidBody::update(v8->rigidBody);
        v9->torque.x = *((float *)this + 80) + v9->torque.x;
        v9->torque.y = *((float *)this + 81) + v9->torque.y;
        v9->torque.z = *((float *)this + 82) + v9->torque.z;
      }
    }
  }
}


// Address: 0x10e69a0 | Name: _ZN3RBX5HUMAN9Balancing31getContactRepelForceInBalancingEv
RBX::Vector3 __fastcall RBX::HUMAN::Balancing::getContactRepelForceInBalancing(RBX::HUMAN::Balancing *this)
{
  RBX::HUMAN::Balancing *v1; // r15
  RBX::Profiler::Token v2; // r14
  uint64_t v3; // rbx
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v6; // rbp
  float v7; // xmm0_4
  RBX::Humanoid *v8; // rax
  RBX::PartInstance *TorsoFast; // rax
  RBX::Instance *parent; // rdi
  __int64 *v11; // r13
  __int64 *v12; // rbp
  RBX::Primitive *v13; // r15
  RBX::Collision::Contact *ContactNew; // rbx
  RBX::Primitive *prim0; // r14
  RBX::Assembly *PrimitiveAssemblyFast; // rbp
  const RBX::CollisionConnector *DeepestCollision; // r14
  __m128 v18; // xmm0
  float v19; // xmm1_4
  __m128 v20; // xmm2
  float v21; // xmm2_4
  RBX::Primitive *v22; // rcx
  __m128 v23; // xmm3
  float x; // xmm0_4
  float v25; // xmm1_4
  float v26; // xmm1_4
  int v27; // r12d
  volatile signed __int32 *v28; // rbx
  signed __int32 v29; // eax
  signed __int32 v30; // ett
  __int64 v31; // rbp
  __m128 v32; // xmm1
  __m128 v33; // xmm0
  __int64 v34; // rbx
  __int64 i; // rbp
  volatile signed __int32 *v36; // rdi
  __int64 v37; // rbx
  __int64 j; // rbp
  volatile signed __int32 *v39; // rdi
  RBX::Profiler::Token token; // [rsp+0h] [rbp-B8h]
  float v43; // [rsp+Ch] [rbp-ACh]
  float v44; // [rsp+10h] [rbp-A8h]
  float v45; // [rsp+10h] [rbp-A8h]
  float v46; // [rsp+10h] [rbp-A8h]
  __int64 *v47; // [rsp+10h] [rbp-A8h]
  float *v48; // [rsp+20h] [rbp-98h]
  int v49; // [rsp+2Ch] [rbp-8Ch]
  float y; // [rsp+30h] [rbp-88h]
  __int64 v51; // [rsp+30h] [rbp-88h]
  uint64_t enterTimestamp; // [rsp+38h] [rbp-80h]
  float v53; // [rsp+40h] [rbp-78h]
  unsigned __int64 v54; // [rsp+50h] [rbp-68h]
  __m128 v55; // [rsp+60h] [rbp-58h]
  RBX::Body *v56; // [rsp+78h] [rbp-40h]
  RBX::Body *v57; // [rsp+80h] [rbp-38h]
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  v1 = this;
  if ( !(_BYTE)byte_2A08E48 && __cxa_guard_acquire(&byte_2A08E48) )
  {
    qword_2A08E40 = RBX::Profiler::getToken("Humanoid", "getContactRepelForceInBalancing", -1);
    __cxa_guard_release(&byte_2A08E48);
  }
  v2 = qword_2A08E40;
  v3 = RBX::Profiler::enterRegion(qword_2A08E40);
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RootBodyFast = RBX::Humanoid::getRootBodyFast(HumanoidConst);
  v6 = RootBodyFast;
  v53 = 0.0;
  v54 = 0;
  if ( RootBodyFast )
  {
    *((_QWORD *)this + 47) = 0;
    *((_DWORD *)this + 96) = 0;
    v44 = *((float *)this + 85);
    enterTimestamp = v3;
    RBX::Body::updatePV(RootBodyFast);
    y = v6->pv.position.translation.y;
    if ( (float)(v44 - y) > RBX::HUMAN::Freefall::minimumMoveDistance() )
    {
      RBX::Body::updatePV(v6);
      *((_DWORD *)this + 85) = LODWORD(v6->pv.position.translation.y);
      *((_DWORD *)this + 84) = *((_DWORD *)this + 4);
      v45 = RBX::HUMAN::Freefall::unstickForceDecay() * *((float *)this + 86);
      *((float *)this + 86) = v45;
      if ( RBX::HUMAN::Freefall::unstickForceEpsilon() > v45 )
        *((_DWORD *)this + 86) = 0;
      goto LABEL_55;
    }
    v46 = RBX::HUMAN::Freefall::unstickForceAttack() + *((float *)this + 86);
    *((float *)this + 86) = v46;
    if ( v46 > RBX::HUMAN::Freefall::maximumUnstickForce() )
      *((float *)this + 86) = RBX::HUMAN::Freefall::maximumUnstickForce();
    v57 = v6;
    v7 = *((float *)this + 4) - *((float *)this + 84);
    v51 = *((_QWORD *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 308);
    if ( !v51 || !*(_QWORD *)(v51 + 784) || fabs(v7) <= RBX::HUMAN::Freefall::maximumMoveTime() )
      goto LABEL_55;
    v8 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    TorsoFast = RBX::Humanoid::getTorsoFast(v8);
    if ( TorsoFast )
    {
      parent = TorsoFast->parent;
      if ( parent )
        RBX::PartInstance::findPartDescendentsIncludingSelf(parent, (RBX::HUMAN::Balancing *)((char *)v1 + 352));
    }
    v11 = (__int64 *)*((_QWORD *)v1 + 44);
    v12 = (__int64 *)*((_QWORD *)v1 + 45);
    if ( v11 == v12 )
      goto LABEL_55;
    v55 = 0;
    v43 = 0.0;
    v49 = 0;
    v47 = (__int64 *)*((_QWORD *)v1 + 45);
    while ( 1 )
    {
      v28 = (volatile signed __int32 *)v11[1];
      if ( v28 )
      {
        v29 = *((_DWORD *)v28 + 2);
        do
        {
          if ( !v29 )
            goto LABEL_47;
          v30 = v29;
          v29 = _InterlockedCompareExchange(v28 + 2, v29 + 1, v29);
        }
        while ( v30 != v29 );
        v31 = *v11;
        if ( !_InterlockedSub(v28 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v28 + 16LL))(v28);
          if ( !_InterlockedSub(v28 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v28 + 24LL))(v28);
        }
        if ( v31 && (v22 = *(RBX::Primitive **)(v31 + 232)) != 0 )
        {
          v12 = v47;
          if ( !*((_BYTE *)v22 + 594)
            && !*((_BYTE *)v22 + 596)
            && (int)((*((_QWORD *)v22 + 59) - *((_QWORD *)v22 + 58)) >> 4) > 0 )
          {
            v56 = (RBX::Body *)((char *)v22 + 152);
            v27 = 0;
            token = v2;
            v48 = (float *)v1;
            while ( 1 )
            {
              v13 = v22;
              ContactNew = RBX::Primitive::getContactNew(v22, v27);
              if ( !RBX::Collision::Contact::getInContact(ContactNew) )
                goto LABEL_29;
              prim0 = ContactNew->prim0;
              if ( prim0 == v13 )
                prim0 = ContactNew->prim1;
              PrimitiveAssemblyFast = RBX::Assembly::getPrimitiveAssemblyFast(v13);
              if ( PrimitiveAssemblyFast == RBX::Assembly::getPrimitiveAssemblyFast(prim0) )
                break;
              v12 = v47;
              DeepestCollision = RBX::Collision::Contact::getDeepestCollision(ContactNew);
              if ( !DeepestCollision )
              {
                v2 = token;
                goto LABEL_29;
              }
              RBX::Body::updatePV(v57);
              v18 = _mm_sub_ps(
                      (__m128)*(unsigned __int64 *)&v57->pv.position.translation.x,
                      (__m128)*(unsigned __int64 *)&DeepestCollision->contactPoint.x);
              v19 = v57->pv.position.translation.z - DeepestCollision->contactPoint.z;
              v20 = _mm_mul_ps(v18, v18);
              v21 = fsqrt((float)(v19 * v19) + (float)(_mm_shuffle_ps(v20, v20, 229).m128_f32[0] + v20.m128_f32[0]));
              v22 = v13;
              if ( v21 > 0.0099999998 )
              {
                ++v49;
                v23 = (__m128)0x3F800000u;
                v23.m128_f32[0] = 1.0 / v21;
                v55 = _mm_add_ps(v55, _mm_mul_ps(v18, _mm_shuffle_ps(v23, v23, 224)));
                v43 = v43 + (float)(v19 * (float)(1.0 / v21));
                x = DeepestCollision->normal.x;
                v1 = (RBX::HUMAN::Balancing *)v48;
                v25 = v48[94];
                if ( DeepestCollision->bodyA == v56 )
                {
                  v48[94] = x + v25;
                  v48[95] = DeepestCollision->normal.y + v48[95];
                  v48[96] = DeepestCollision->normal.z + v48[96];
                }
                else
                {
                  v48[94] = v25 - x;
                  v26 = v48[96];
                  v48[95] = v48[95] - DeepestCollision->normal.y;
                  v48[96] = v26 - DeepestCollision->normal.z;
                }
                v2 = token;
                goto LABEL_31;
              }
              v2 = token;
LABEL_30:
              v1 = (RBX::HUMAN::Balancing *)v48;
LABEL_31:
              if ( ++v27 >= (int)((*((_QWORD *)v22 + 59) - *((_QWORD *)v22 + 58)) >> 4) )
                goto LABEL_47;
            }
            v2 = token;
            v12 = v47;
LABEL_29:
            v22 = v13;
            goto LABEL_30;
          }
        }
        else
        {
          v12 = v47;
        }
      }
LABEL_47:
      v11 += 2;
      if ( v11 == v12 )
      {
        if ( v49 > 0 )
        {
          v32 = (__m128)0x3F800000u;
          v32.m128_f32[0] = 1.0 / (float)v49;
          *((float *)v1 + 94) = *((float *)v1 + 94) * v32.m128_f32[0];
          *((float *)v1 + 95) = *((float *)v1 + 95) * v32.m128_f32[0];
          *((float *)v1 + 96) = *((float *)v1 + 96) * v32.m128_f32[0];
          v33 = (__m128)*(unsigned int *)(v51 + 176);
          v33.m128_f32[0] = v33.m128_f32[0] * *((float *)v1 + 86);
          v34 = *((_QWORD *)v1 + 44);
          for ( i = *((_QWORD *)v1 + 45); v34 != i; i -= 16 )
          {
            v36 = *(volatile signed __int32 **)(i - 8);
            if ( v36 && !_InterlockedSub(v36 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v36 + 24LL))(v36);
          }
          v54 = _mm_mul_ps(_mm_shuffle_ps(v32, v32, 224), _mm_mul_ps(v55, _mm_shuffle_ps(v33, v33, 224))).m128_u64[0];
          *((_QWORD *)v1 + 45) = v34;
          v53 = (float)(v43 * v33.m128_f32[0]) * v32.m128_f32[0];
          goto LABEL_61;
        }
LABEL_55:
        v37 = *((_QWORD *)v1 + 44);
        for ( j = *((_QWORD *)v1 + 45); v37 != j; j -= 16 )
        {
          v39 = *(volatile signed __int32 **)(j - 8);
          if ( v39 && !_InterlockedSub(v39 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v39 + 24LL))(v39);
        }
        *((_QWORD *)v1 + 45) = v37;
LABEL_61:
        v3 = enterTimestamp;
        break;
      }
    }
  }
  RBX::Profiler::leaveRegion(v2, v3);
  *(_QWORD *)&result.x = v54;
  result.z = v53;
  return result;
}


// Address: 0x10e70c0 | Name: _GLOBAL__sub_I_Balancing.cpp
void __cdecl GLOBAL__sub_I_Balancing_cpp()
{
  qword_2A08E20 = (__int64)boost::system::generic_category();
  qword_2A08E28 = (__int64)boost::system::generic_category();
  qword_2A08E30 = (__int64)boost::system::system_category();
  dword_2A08E38 = FLog::RegisterInt("DefaultBalanceP", &dword_2859538, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08E3C = FLog::RegisterInt("DefaultBalanceD", &dword_2859548, FastVarType::FASTVARTYPE_DYNAMIC);
}


