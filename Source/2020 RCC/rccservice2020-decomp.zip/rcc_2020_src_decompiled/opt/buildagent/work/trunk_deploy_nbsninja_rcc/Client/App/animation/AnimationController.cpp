// Address: 0x104aaf0 | Name: _ZN3RBX19AnimationController25getPlayingAnimationTracksEv
_OWORD *__fastcall RBX::AnimationController::getPlayingAnimationTracks(_OWORD *a1, RBX::AnimationController *this)
{
  RBX::Animator *Animator; // rax

  Animator = RBX::AnimationController::getAnimator(this);
  RBX::Animator::getPlayingAnimationTracks(a1, Animator);
  return a1;
}


// Address: 0x104ab10 | Name: _ZN3RBX19AnimationController13loadAnimationEN5boost10shared_ptrINS_8InstanceEEE
RBX::AnimationController *__fastcall RBX::AnimationController::loadAnimation(
        RBX::AnimationController *this,
        boost::shared_ptr<RBX::Instance> instance)
{
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::Instance> v3; // rax
  volatile signed __int32 *v4; // rcx
  volatile signed __int32 *v5; // rbx
  int (**instancea)(void); // [rsp+8h] [rbp-20h] BYREF
  volatile signed __int32 *v8; // [rsp+10h] [rbp-18h]

  pi = instance.pn.pi_;
  v3.px = (boost::shared_ptr<RBX::Instance>::element_type *)RBX::AnimationController::getAnimator((RBX::AnimationController *)instance.px);
  instancea = pi->_vptr$sp_counted_base;
  v4 = *(volatile signed __int32 **)&pi->use_count_;
  v8 = v4;
  if ( v4 )
    _InterlockedAdd(v4 + 2, 1u);
  v3.pn.pi_ = (boost::detail::sp_counted_base *)&instancea;
  RBX::Animator::loadAnimation((RBX::Animator *)this, v3);
  v5 = v8;
  if ( v8 )
  {
    if ( !_InterlockedSub(v8 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 16LL))(v5);
      if ( !_InterlockedSub(v5 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
    }
  }
  return this;
}


// Address: 0x104abd0 | Name: _ZN3RBX19AnimationControllerC2Ev
void __fastcall RBX::AnimationController::AnimationController(RBX::AnimationController *this)
{
  void *v1[7]; // [rsp+0h] [rbp-38h] BYREF

  RBX::Instance::Instance(this);
  this->_vptr$EventSource = (int (**)(void))&off_288EF18;
  this->descriptor = Class_getDescriptorPtr(this);
  this->_vptr$EventSource = (int (**)(void))off_288EBC0;
  this->animator = 0;
  this->animationPlayedSignal.head.px = 0;
  strcpy((char *)&v1[2] + 1, "ler");
  BYTE5(v1[2]) = 0;
  HIWORD(v1[2]) = 0;
  strcpy((char *)v1, "&AnimationContro");
  RBX::Instance::setName(this, (const std::string *)v1);
  if ( ((__int64)v1[0] & 1) != 0 )
    operator delete(v1[2]);
}


// Address: 0x104acd0 | Name: _ZN3RBX19AnimationControllerD2Ev
void __fastcall RBX::AnimationController::~AnimationController(RBX::AnimationController *this)
{
  boost::detail::sp_counted_base *pi; // r14

  this->_vptr$EventSource = (int (**)(void))off_288EBC0;
  rbx::signals::signal_base::~signal_base(&this->animationPlayedSignal);
  pi = this->animator.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  RBX::Instance::~Instance(this);
}


// Address: 0x104ad40 | Name: _ZN3RBX19AnimationControllerD0Ev
void __fastcall RBX::AnimationController::~AnimationController(RBX::AnimationController *this)
{
  boost::detail::sp_counted_base *pi; // r14

  this->_vptr$EventSource = (int (**)(void))off_288EBC0;
  rbx::signals::signal_base::~signal_base(&this->animationPlayedSignal);
  pi = this->animator.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  RBX::Instance::~Instance(this);
  operator delete(this);
}


// Address: 0x104adb0 | Name: _ZNK3RBX19AnimationController12askSetParentEPKNS_8InstanceE
bool __fastcall RBX::AnimationController::askSetParent(
        const RBX::AnimationController *this,
        const RBX::Instance *instance)
{
  return 1;
}


// Address: 0x104adc0 | Name: _ZN3RBX19AnimationController11getAnimatorEv
RBX::Animator *__fastcall RBX::AnimationController::getAnimator(RBX::AnimationController *this)
{
  _BYTE *px; // rax
  RBX::Animator *result; // rax
  RBX::Animator ***v3; // rax
  RBX::Animator **v4; // rbx
  RBX::Animator **v5; // r12
  RBX::Animator *v6; // r15
  __int64 v7; // r13
  RBX::Reflection::ClassDescriptor *v8; // rax
  boost::shared_ptr<RBX::Animator> v9; // xmm0
  boost::detail::sp_counted_base *v10; // rbx
  volatile signed __int32 *v11; // rbx
  boost::shared_ptr<RBX::Animator> v12; // rax
  boost::shared_ptr<RBX::Animator> v13; // xmm0
  boost::detail::sp_counted_base *v14; // rbx
  volatile signed __int32 *v15; // rbx
  RBX::Animator ***v16; // rax
  RBX::Animator **v17; // rbx
  RBX::Animator **v18; // r12
  RBX::Animator *v19; // r15
  __int64 v20; // r13
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  boost::shared_ptr<RBX::Animator> v22; // xmm0
  boost::detail::sp_counted_base *pi; // rbx
  volatile signed __int32 *v24; // rbx
  _OWORD v25[3]; // [rsp+0h] [rbp-38h] BYREF

  px = this->animator.px;
  if ( !px )
    goto LABEL_4;
  if ( !*((_QWORD *)px + 11) )
  {
    if ( px[57] )
    {
      v16 = (RBX::Animator ***)this->children.object.px;
      if ( v16 )
      {
        v17 = *v16;
        v18 = v16[1];
        if ( *v16 != v18 )
        {
          while ( 1 )
          {
            v19 = *v17;
            if ( *v17 )
            {
              v20 = *((_QWORD *)v19 + 3);
              DescriptorPtr = Class_getDescriptorPtr(0);
              if ( *(unsigned __int16 *)(v20 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
                break;
            }
            v17 += 2;
            if ( v18 == v17 )
              goto LABEL_3;
          }
          RBX::shared_from<RBX::Animator>(v25, v19);
          v22 = (boost::shared_ptr<RBX::Animator>)v25[0];
          v25[0] = 0;
          pi = this->animator.pn.pi_;
          this->animator = v22;
          if ( pi )
          {
            if ( !_InterlockedSub(&pi->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
              if ( !_InterlockedSub(&pi->weak_count_, 1u) )
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
            }
          }
          v24 = (volatile signed __int32 *)*((_QWORD *)&v25[0] + 1);
          if ( *((_QWORD *)&v25[0] + 1) )
          {
            if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v25[0] + 1) + 8LL), 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 16LL))(v24);
              if ( !_InterlockedSub(v24 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 24LL))(v24);
            }
          }
        }
      }
    }
  }
LABEL_3:
  result = (RBX::Animator *)this->animator.px;
  if ( !result )
  {
LABEL_4:
    v3 = (RBX::Animator ***)this->children.object.px;
    if ( !v3 || (v4 = *v3, v5 = v3[1], *v3 == v5) )
    {
LABEL_9:
      v6 = 0;
    }
    else
    {
      while ( 1 )
      {
        v6 = *v4;
        if ( *v4 )
        {
          v7 = *((_QWORD *)v6 + 3);
          v8 = Class_getDescriptorPtr(0);
          if ( *(unsigned __int16 *)(v7 + 726) - (unsigned int)*((unsigned __int16 *)v8 + 363) <= *((unsigned __int16 *)v8
                                                                                                  + 364) )
            break;
        }
        v4 += 2;
        if ( v5 == v4 )
          goto LABEL_9;
      }
    }
    RBX::shared_from<RBX::Animator>(v25, v6);
    v9 = (boost::shared_ptr<RBX::Animator>)v25[0];
    v25[0] = 0;
    v10 = this->animator.pn.pi_;
    this->animator = v9;
    if ( v10 )
    {
      if ( !_InterlockedSub(&v10->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
        if ( !_InterlockedSub(&v10->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
      }
    }
    v11 = (volatile signed __int32 *)*((_QWORD *)&v25[0] + 1);
    if ( *((_QWORD *)&v25[0] + 1) )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v25[0] + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
        if ( !_InterlockedSub(v11 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
      }
    }
    result = (RBX::Animator *)this->animator.px;
    if ( !result )
    {
      v12 = RBX::Creatable<RBX::Instance>::create<RBX::Animator>();
      v13 = (boost::shared_ptr<RBX::Animator>)v25[0];
      v25[0] = 0;
      v14 = this->animator.pn.pi_;
      this->animator = v13;
      if ( v14 )
      {
        if ( !_InterlockedSub(&v14->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *, RBX::Animator *, boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base
           + 2))(
            v14,
            v6,
            v12.pn.pi_);
          if ( !_InterlockedSub(&v14->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
        }
      }
      v15 = (volatile signed __int32 *)*((_QWORD *)&v25[0] + 1);
      if ( *((_QWORD *)&v25[0] + 1) && !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v25[0] + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *, RBX::Animator *, boost::detail::sp_counted_base *))(*(_QWORD *)v15 + 16LL))(
          v15,
          v6,
          v12.pn.pi_);
        if ( !_InterlockedSub(v15 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
      }
      RBX::Instance::setParentInternal((RBX::Instance *)this->animator.px, this, 0);
      return (RBX::Animator *)this->animator.px;
    }
  }
  return result;
}


// Address: 0x104b090 | Name: _Z22Class_getDescriptorPtrPN3RBX19AnimationControllerE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::AnimationController *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A02B80;
  if ( !qword_2A02B80 )
  {
    if ( !(_BYTE)byte_2A02EC8 )
    {
      if ( __cxa_guard_acquire(&byte_2A02EC8) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A02B88,
          v2,
          "AnimationController",
          0,
          attributes,
          RBX::Security::Permissions::None,
          &dword_2A04350);
        stru_2A02EC0._vptr$ICreator = (int (**)(void))&off_288EDA8;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A02B90, &stru_2A02EC0);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::AnimationController,true>::~ClassRegistrar,
          &unk_2A02B88,
          &dso_handle);
        __cxa_guard_release(&byte_2A02EC8);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A02B88;
    qword_2A02B80 = (RBX::Reflection::ClassDescriptor *)&unk_2A02B88;
  }
  return result;
}


// Address: 0x104b1f0 | Name: _Z16Class_getNamePtrPN3RBX19AnimationControllerE
const RBX::Name *__fastcall Class_getNamePtr(RBX::AnimationController *a1)
{
  const RBX::Name *result; // rax

  result = (const RBX::Name *)qword_2A02ED0;
  if ( !qword_2A02ED0 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A02ED0 = (RBX::AnimationController *)result;
  }
  return result;
}


// Address: 0x104bfe0 | Name: _GLOBAL__sub_I_AnimationController.cpp
void __cdecl GLOBAL__sub_I_AnimationController_cpp()
{
  RBX::AnimationController *v0; // rdi
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v2; // r9
  unsigned __int64 v3; // [rsp+18h] [rbp-20h]
  RBX::Reflection::Descriptor::Attributes v4; // 0:r8.1,8:r9.8

  qword_2A02A70 = (__int64)boost::system::generic_category();
  qword_2A02A78 = (__int64)boost::system::generic_category();
  qword_2A02A80 = (__int64)boost::system::system_category();
  DescriptorPtr = Class_getDescriptorPtr(v0);
  v4.isDeprecated = 0;
  v4.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A02A88,
    DescriptorPtr,
    "GetPlayingAnimationTracks",
    RBX::Security::Permissions::None,
    v4);
  qword_2A02A88[0] = &off_288EE38;
  xmmword_2A02AF0 = (unsigned __int64)RBX::AnimationController::getPlayingAnimationTracks;
  qword_2A02AC8 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A02A88, &dso_handle);
  LOBYTE(v3) = 0;
  RBX::Reflection::BoundFuncDesc<RBX::AnimationController,boost::shared_ptr<RBX::Instance> ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::AnimationController,boost::shared_ptr<RBX::Instance> (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A02B00,
    (RBX::Reflection::BoundFuncDesc<RBX::AnimationController,boost::shared_ptr<RBX::Instance> (boost::shared_ptr<RBX::Instance>),1>::FunctionPtr)RBX::AnimationController::loadAnimation,
    0,
    "LoadAnimation",
    (RBX::Security::Permissions)"animation",
    (RBX::Reflection::Descriptor::Attributes)v3);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::AnimationController,boost::shared_ptr<RBX::Instance> ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A02B00,
    &dso_handle);
  LOBYTE(v3) = 0;
  RBX::Reflection::EventDesc<RBX::AnimationController,void ()(boost::shared_ptr<RBX::Instance>),rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>,rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)> RBX::AnimationController::*>::EventDesc(
    (RBX::AnimationController *)&unk_2858860,
    (rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *)&inputbuff.encodingTable[6].bitLength,
    "AnimationPlayed",
    "animationTrack",
    RBX::Security::Permissions::None,
    v2,
    (RBX::Reflection::Descriptor::Attributes)v3);
  __cxa_atexit((void (*)(void *))RBX::Reflection::EventDescriptor::~EventDescriptor, &unk_2858860, &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_0);
}


