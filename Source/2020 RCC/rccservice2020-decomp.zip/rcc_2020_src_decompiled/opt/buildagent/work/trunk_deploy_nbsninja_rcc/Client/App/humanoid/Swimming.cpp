// Address: 0x10ee9a0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN8SwimmingE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Swimming *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A093D0;
  if ( !qword_2A093D0 )
  {
    result = RBX::Name::declare("Swimming");
    qword_2A093D0 = result;
  }
  return result;
}


// Address: 0x10ee9d0 | Name: _ZNK3RBX5HUMAN8Swimming7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Swimming::getName(const RBX::HUMAN::Swimming *this)
{
  const RBX::Name *result; // rax

  result = qword_2A093D0;
  if ( !qword_2A093D0 )
  {
    result = RBX::Name::declare("Swimming");
    qword_2A093D0 = result;
  }
  return result;
}


// Address: 0x10eea00 | Name: _ZN3RBX5HUMAN8Swimming13velocityDecayEv
float __cdecl RBX::HUMAN::Swimming::velocityDecay()
{
  return 0.050000001;
}


// Address: 0x10eea10 | Name: _ZN3RBX5HUMAN8SwimmingC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Swimming::Swimming(
        RBX::HUMAN::Swimming *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  double v3; // xmm1_8

  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_28976D0;
  *(_OWORD *)((char *)this + 328) = 0;
  *(_OWORD *)((char *)this + 312) = 0;
  *((_DWORD *)this + 86) = 0;
  rbx::signal<void ()(float)>::operator()((rbx::signal<void (float)> *)humanoid + 328, 0.0, v3);
}


// Address: 0x10eea70 | Name: _ZN3RBX5HUMAN8Swimming18onComputeForceImplEv
void __fastcall RBX::HUMAN::Swimming::onComputeForceImpl(RBX::HUMAN::Swimming *this)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Body *TorsoBodyFast; // rax
  RBX::Body *v3; // r14
  RBX::Humanoid *v4; // rax
  RBX::Body *RootBodyFast; // rax
  __m128 v6; // xmm4
  RBX::Body *v7; // r12
  __m128 v8; // xmm5
  __m128 v9; // xmm8
  __m128 v10; // xmm0
  __m128 x_low; // xmm1
  __m128 v12; // xmm0
  float v13; // xmm8_4
  RBX::Solver::SolverRigidBody *rigidBody; // rbx
  RBX::Velocity *p_velocity; // rbx
  float x; // xmm2_4
  float y; // xmm3_4
  float z; // xmm4_4
  RBX::Cofm *cofm; // rbx
  unsigned int *p_mass; // rbx
  RBX::Body *root; // rax
  RBX::Solver::SolverRigidBody *v22; // rbx
  float v23; // xmm0_4
  float v24; // xmm1_4
  float v25; // xmm2_4
  float v26; // xmm3_4
  __m128i v27; // xmm6
  float v28; // xmm7_4
  float v29; // xmm3_4
  float v30; // xmm6_4
  RBX::Cofm *v31; // rbx
  float *v32; // rbx
  float v33; // xmm2_4
  RBX::Body *v34; // rax
  RBX::Solver::SolverRigidBody *v35; // rbx
  float v36; // xmm2_4
  RBX::Humanoid *v37; // rax
  __m128 v38; // xmm9
  __m128 y_low; // xmm4
  RBX::Solver::SolverRigidBody *v40; // rax
  float v41; // xmm3_4
  __m128 v42; // xmm6
  float v43; // xmm5_4
  __m128 v44; // xmm1
  float v45; // xmm0_4
  __m128 v46; // xmm0
  __m128 v47; // xmm1
  __m128 v48; // xmm1
  float v49; // xmm2_4
  __m128 v50; // xmm0
  __m128 v51; // xmm0
  __m128 v52; // xmm4
  __m128 v53; // xmm2
  __m128 v54; // xmm1
  __m128 v55; // xmm8
  __m128 v56; // xmm11
  __m128 v57; // xmm1
  __m128 v58; // xmm2
  float v59; // xmm9_4
  float v60; // xmm3_4
  float v61; // xmm6_4
  __m128 v62; // xmm12
  RBX::Cofm *v63; // rbx
  RBX::Matrix3 *p_moment; // rsi
  unsigned int *v65; // r11
  unsigned int *v66; // rax
  unsigned int *v67; // rcx
  unsigned int *v68; // rdx
  unsigned int *v69; // rdi
  float *v70; // r10
  float *v71; // r9
  float *v72; // r8
  float v73; // xmm0_4
  __m128 v74; // xmm14
  float v75; // xmm5_4
  __m128 v76; // xmm13
  RBX::Cofm *v77; // rbx
  float v78; // xmm15_4
  float v79; // xmm4_4
  float v80; // xmm7_4
  float v81; // xmm10_4
  __m128 v82; // xmm11
  float v83; // xmm9_4
  float v84; // xmm15_4
  float v85; // xmm2_4
  __m128 v86; // xmm4
  __m128 v87; // xmm8
  __m128 v88; // xmm6
  float v89; // xmm2_4
  RBX::Matrix3 *v90; // rcx
  unsigned int *v91; // rax
  unsigned int *v92; // rdx
  unsigned int *v93; // r10
  unsigned int *v94; // rdi
  unsigned int *v95; // rsi
  float *v96; // r9
  float *v97; // r8
  float *v98; // rbx
  float v99; // xmm7_4
  float v100; // xmm6_4
  float v101; // xmm4_4
  __m128 v102; // xmm2
  __m128 v103; // xmm11
  __m128 v104; // xmm10
  __m128 v105; // xmm8
  __m128 v106; // xmm2
  float v107; // xmm6_4
  float v108; // xmm15_4
  float v109; // xmm7_4
  RBX::Cofm *v110; // rbx
  __m128 v111; // xmm8
  __m128 v112; // xmm5
  RBX::Matrix3 *v113; // rsi
  unsigned int *v114; // r10
  unsigned int *v115; // rdx
  unsigned int *v116; // rax
  unsigned int *v117; // rcx
  unsigned int *v118; // rdi
  float *v119; // r8
  float *v120; // r9
  float *v121; // rbx
  RBX::Cofm *v122; // rbx
  __m128 v123; // xmm0
  __m128 v124; // xmm1
  __m128 v125; // xmm3
  __m128 v126; // xmm2
  __m128 v127; // xmm1
  float v128; // xmm9_4
  __m128 *v129; // rax
  RBX::Solver::SolverRigidBody *v130; // r14
  __m128 v131; // xmm4
  __m128 v132; // xmm0
  float v133; // xmm5_4
  float v134; // xmm11_4
  float v135; // xmm10_4
  float v136; // xmm8_4
  float v137; // xmm15_4
  float v138; // xmm6_4
  float v139; // xmm3_4
  float v140; // xmm12_4
  float v141; // xmm1_4
  float v142; // xmm2_4
  float v143; // xmm8_4
  float v144; // xmm15_4
  float v145; // xmm0_4
  float v146; // xmm6_4
  float v147; // [rsp+Ch] [rbp-20Ch]
  float v148; // [rsp+10h] [rbp-208h]
  float v149; // [rsp+10h] [rbp-208h]
  float v150; // [rsp+10h] [rbp-208h]
  float v151; // [rsp+10h] [rbp-208h]
  float v152; // [rsp+20h] [rbp-1F8h]
  float v153; // [rsp+3Ch] [rbp-1DCh]
  float v154; // [rsp+3Ch] [rbp-1DCh]
  float v155; // [rsp+40h] [rbp-1D8h]
  __m128 v156; // [rsp+40h] [rbp-1D8h]
  float v157; // [rsp+40h] [rbp-1D8h]
  __m128 v158; // [rsp+50h] [rbp-1C8h]
  __m128 z_low; // [rsp+60h] [rbp-1B8h]
  float v160; // [rsp+60h] [rbp-1B8h]
  __m128 v161; // [rsp+60h] [rbp-1B8h]
  __m128 v162; // [rsp+70h] [rbp-1A8h]
  float v163; // [rsp+80h] [rbp-198h]
  float v164; // [rsp+90h] [rbp-188h]
  __m128 v165; // [rsp+90h] [rbp-188h]
  __m128 v166; // [rsp+A0h] [rbp-178h]
  __m128 v167; // [rsp+A0h] [rbp-178h]
  __m128 v168; // [rsp+A0h] [rbp-178h]
  __m128 v169; // [rsp+B0h] [rbp-168h]
  __m128 v170; // [rsp+B0h] [rbp-168h]
  float v171; // [rsp+B0h] [rbp-168h]
  float v172; // [rsp+C8h] [rbp-150h]
  float v173; // [rsp+CCh] [rbp-14Ch]
  __m128 v174; // [rsp+D0h] [rbp-148h]
  __m128 v175; // [rsp+E0h] [rbp-138h]
  __m128 v176; // [rsp+F0h] [rbp-128h]
  __m128 v177; // [rsp+F0h] [rbp-128h]
  __m128 v178; // [rsp+120h] [rbp-F8h]
  __m128 v179; // [rsp+130h] [rbp-E8h]
  __m128 v180; // [rsp+130h] [rbp-E8h]
  __m128 v181; // [rsp+140h] [rbp-D8h]
  __m128 v182; // [rsp+140h] [rbp-D8h]
  RBX::Matrix3 m; // [rsp+150h] [rbp-C8h] BYREF
  __m128 v184; // [rsp+180h] [rbp-98h]
  __m128 v185; // [rsp+190h] [rbp-88h]
  __m128 v186; // [rsp+1A0h] [rbp-78h]
  __m128 v187; // [rsp+1B0h] [rbp-68h]
  __m128 v188; // [rsp+1C0h] [rbp-58h]
  __m128 v189; // [rsp+1D0h] [rbp-48h]
  __m128 v190; // [rsp+1E0h] [rbp-38h]
  G3D::Vector3 v191; // 0:kr00_12.12
  G3D::Vector3 v192; // 0:kr14_12.12
  RBX::Vector3 v193; // 0:kr20_12.12

  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(HumanoidConst);
  if ( !TorsoBodyFast )
    return;
  v3 = TorsoBodyFast;
  v4 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RootBodyFast = RBX::Humanoid::getRootBodyFast(v4);
  if ( !RootBodyFast )
    return;
  v7 = RootBodyFast;
  v8 = (__m128)_mm_loadl_epi64((const __m128i *)((char *)this + 324));
  v10 = (__m128)_mm_shuffle_epi32((__m128i)v8, 229);
  v9 = (__m128)*((unsigned int *)this + 83);
  v6.m128_f32[0] = fsqrt(
                     (float)((float)(v10.m128_f32[0] * v10.m128_f32[0]) + (float)(v8.m128_f32[0] * v8.m128_f32[0]))
                   + (float)(v9.m128_f32[0] * v9.m128_f32[0]));
  v10.m128_f32[0] = v10.m128_f32[0] + v10.m128_f32[0];
  x_low = 0;
  x_low.m128_f32[0] = fsqrt(
                        (float)((float)(v8.m128_f32[0] * v8.m128_f32[0]) + 0.0)
                      + (float)(v9.m128_f32[0] * v9.m128_f32[0]));
  if ( x_low.m128_f32[0] > v10.m128_f32[0] && v10.m128_f32[0] > (float)-x_low.m128_f32[0] )
  {
    v12 = (__m128)0x3F800000u;
    v12.m128_f32[0] = 1.0 / x_low.m128_f32[0];
    x_low = _mm_shuffle_ps(_mm_shuffle_ps((__m128)0LL, v8, 0), v8, 226);
    v13 = v9.m128_f32[0] * v12.m128_f32[0];
    v10 = _mm_mul_ps(_mm_shuffle_ps(v12, v12, 224), x_low);
    v8 = _mm_mul_ps(_mm_shuffle_ps(v6, v6, 224), v10);
    v9.m128_f32[0] = v13 * v6.m128_f32[0];
  }
  rigidBody = RootBodyFast->root->rigidBody;
  v158 = v8;
  if ( rigidBody )
  {
    p_velocity = &rigidBody->pv.velocity;
    if ( v6.m128_f32[0] <= 10.0 )
      goto LABEL_21;
LABEL_11:
    x = p_velocity->linear.x;
    y = p_velocity->linear.y;
    z = p_velocity->linear.z;
    cofm = v7->cofm;
    if ( cofm )
    {
      v148 = z;
      RBX::Cofm::updateIfDirty(v7->cofm);
      z = v148;
      v8 = v158;
      p_mass = (unsigned int *)&cofm->branch.mass;
    }
    else
    {
      if ( v7->isMassless )
      {
        v10 = 0;
        if ( v7->root != v7 )
        {
LABEL_17:
          root = v7->root;
          v22 = root->rigidBody;
          if ( v22 )
          {
            v23 = v10.m128_f32[0] * 35.0;
            v24 = (float)(v8.m128_f32[0] - x) * v23;
            v25 = (float)(_mm_shuffle_ps(v8, v8, 229).m128_f32[0] - y) * v23;
            v26 = (float)(v9.m128_f32[0] - z) * v23;
            v10 = (__m128)_mm_loadl_epi64((const __m128i *)&qword_28597A0);
            v27 = _mm_loadl_epi64((const __m128i *)&qword_28597AC);
            v28 = fminf(*(float *)&dword_28597B4, fmaxf(*(float *)&dword_28597A8, v26));
            LODWORD(v29) = _mm_shuffle_epi32((__m128i)v10, 229).m128i_u32[0];
            v10.m128_f32[0] = fmaxf(v10.m128_f32[0], v24);
            x_low = (__m128)_mm_shuffle_epi32(v27, 229);
            v30 = fminf(*(float *)v27.m128i_i32, v10.m128_f32[0]);
            x_low.m128_f32[0] = fminf(x_low.m128_f32[0], fmaxf(v29, v25));
            if ( v22->dirty )
              RBX::Solver::SolverRigidBody::update(root->rigidBody);
            v22->force.x = v30 + v22->force.x;
            v22->force.y = x_low.m128_f32[0] + v22->force.y;
            v22->force.z = v28 + v22->force.z;
          }
          goto LABEL_21;
        }
      }
      p_mass = (unsigned int *)&v7->bodyMass.mass;
    }
    v10 = (__m128)*p_mass;
    goto LABEL_17;
  }
  p_velocity = &vel;
  if ( (_BYTE)byte_2A08DC8 )
  {
    if ( v6.m128_f32[0] <= 10.0 )
      goto LABEL_21;
    goto LABEL_11;
  }
  v151 = v6.m128_f32[0];
  if ( __cxa_guard_acquire(&byte_2A08DC8) )
  {
    v10 = 0;
    *(_OWORD *)&vel.linear.x = 0;
    *(_QWORD *)&vel.rotational.y = 0;
    __cxa_guard_release(&byte_2A08DC8);
  }
  v8 = v158;
  if ( v151 > 10.0 )
    goto LABEL_11;
LABEL_21:
  if ( *((char *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 697) > 0 )
  {
    v31 = v7->cofm;
    if ( v31 )
    {
      RBX::Cofm::updateIfDirty(v7->cofm);
      v32 = &v31->branch.mass;
    }
    else
    {
      if ( v7->isMassless )
      {
        v33 = 0.0;
        if ( v7->root != v7 )
          goto LABEL_28;
      }
      v32 = &v7->bodyMass.mass;
    }
    v33 = *v32;
LABEL_28:
    v34 = v7->root;
    v35 = v34->rigidBody;
    if ( v35 )
    {
      v36 = v33 * 500.0;
      if ( v35->dirty )
        RBX::Solver::SolverRigidBody::update(v34->rigidBody);
      v10 = 0;
      x_low = (__m128)LODWORD(v35->force.x);
      v35->force.x = x_low.m128_f32[0] + 0.0;
      v35->force.y = v36 + v35->force.y;
      v35->force.z = v35->force.z + 0.0;
    }
    v37 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    RBX::Humanoid::setJump(v37, 0);
  }
  RBX::Body::updatePV(v3);
  v191 = G3D::Matrix3::column(&v3->pv.position.rotation, 1);
  v10.m128_i32[0] = LODWORD(v191.x);
  v10.m128_i32[1] = LODWORD(v191.y);
  x_low.m128_i32[0] = LODWORD(v191.z);
  v166 = v10;
  v169 = x_low;
  RBX::Body::updatePV(v3);
  v192 = G3D::Matrix3::column(&v3->pv.position.rotation, 2);
  v10.m128_i32[0] = LODWORD(v192.x);
  v10.m128_i32[1] = LODWORD(v192.y);
  RBX::Body::updatePV(v3);
  v38 = (__m128)LODWORD(v3->pv.velocity.rotational.x);
  y_low = (__m128)LODWORD(v3->pv.velocity.rotational.y);
  z_low = (__m128)LODWORD(v3->pv.velocity.rotational.z);
  v40 = v7->root->rigidBody;
  if ( v40 )
  {
    v187 = (__m128)*(unsigned __int64 *)&v40->torque.x;
    v41 = v40->torque.z;
  }
  else
  {
    v187 = 0;
    v41 = 0.0;
  }
  v42 = v158;
  LODWORD(v43) = _mm_shuffle_ps(v10, v10, 229).m128_u32[0];
  v44 = _mm_shuffle_ps(v158, v158, 229);
  v45 = (float)(v9.m128_f32[0] * v9.m128_f32[0])
      + (float)((float)(v44.m128_f32[0] * v44.m128_f32[0]) + (float)(v158.m128_f32[0] * v158.m128_f32[0]));
  v173 = v41;
  v176 = y_low;
  if ( v45 >= 5.0 )
  {
    v49 = fsqrt(v45);
    v50 = (__m128)0x3F800000u;
    v50.m128_f32[0] = 1.0 / v49;
    v42.m128_f32[0] = v158.m128_f32[0] * (float)(1.0 / v49);
    v51 = _mm_mul_ps(_mm_shuffle_ps(v50, v50, 224), _mm_unpacklo_ps(v44, v9));
    v52 = _mm_shuffle_ps(v166, v166, 229);
    v53 = _mm_shuffle_ps(v51, v51, 229);
    v54 = _mm_sub_ps(
            _mm_mul_ps(_mm_unpacklo_ps(v169, v166), v51),
            _mm_mul_ps(
              _mm_shuffle_ps(_mm_shuffle_ps(v169, v52, 0), v52, 226),
              _mm_shuffle_ps(_mm_shuffle_ps(v42, v53, 0), v53, 226)));
    v52.m128_f32[0] = (float)(v52.m128_f32[0] * v42.m128_f32[0]) - (float)(v51.m128_f32[0] * v166.m128_f32[0]);
    v167 = v52;
    v184 = (__m128)0x447A0000u;
    v186 = (__m128)0x43FA0000u;
    v185 = (__m128)0x42960000u;
    v170 = v54;
  }
  else
  {
    v46 = v166;
    v186 = 0;
    v46.m128_f32[0] = v166.m128_f32[0] * 0.0;
    v47 = _mm_shuffle_ps(v166, v166, 229);
    v48 = _mm_mul_ps((__m128)0LL, _mm_shuffle_ps(_mm_shuffle_ps(v169, v47, 0), v47, 226));
    v170 = _mm_sub_ps(_mm_unpacklo_ps(v169, v46), v48);
    v48.m128_f32[0] = v48.m128_f32[0] - v166.m128_f32[0];
    v167 = v48;
    v184 = (__m128)0x43FA0000u;
    v185 = (__m128)0x42480000u;
  }
  v164 = v43 * 0.0;
  RBX::Body::updatePV(v7);
  v55 = (__m128)*(unsigned __int64 *)&v7->pv.position.rotation.elt[0][0];
  v56 = _mm_mul_ps(_mm_shuffle_ps(v38, v38, 224), v55);
  v57 = (__m128)*(unsigned __int64 *)&v7->pv.position.rotation.elt[1][0];
  v58 = _mm_shuffle_ps(z_low, z_low, 224);
  v59 = v38.m128_f32[0] * v7->pv.position.rotation.elt[0][2];
  v60 = v7->pv.position.rotation.elt[1][2];
  v61 = v176.m128_f32[0] * v60;
  v62 = (__m128)LODWORD(v7->pv.position.rotation.elt[2][2]);
  v63 = v7->cofm;
  v181 = _mm_mul_ps(_mm_shuffle_ps(v176, v176, 224), v57);
  v153 = v7->pv.position.rotation.elt[2][2];
  v179 = (__m128)*(unsigned __int64 *)&v7->pv.position.rotation.elt[2][0];
  if ( v63 )
  {
    RBX::Cofm::updateIfDirty(v63);
    p_moment = &v63->branch.moment;
    v65 = (unsigned int *)&v63->branch.moment.elt[0][1];
    v66 = (unsigned int *)&v63->branch.moment.elt[0][2];
    v67 = (unsigned int *)v63->branch.moment.elt[1];
    v68 = (unsigned int *)&v63->branch.moment.elt[1][1];
    v69 = (unsigned int *)&v63->branch.moment.elt[1][2];
    v70 = v63->branch.moment.elt[2];
    v71 = &v63->branch.moment.elt[2][1];
    v72 = &v63->branch.moment.elt[2][2];
    v73 = v7->pv.position.rotation.elt[0][0];
    v57.m128_i32[0] = LODWORD(v7->pv.position.rotation.elt[1][0]);
    v74 = (__m128)LODWORD(v7->pv.position.rotation.elt[2][0]);
    v163 = v7->pv.position.rotation.elt[0][1];
    v75 = v7->pv.position.rotation.elt[1][1];
    v76 = (__m128)LODWORD(v7->pv.position.rotation.elt[2][1]);
    v147 = v7->pv.position.rotation.elt[0][2];
    v60 = v7->pv.position.rotation.elt[1][2];
    v62 = (__m128)LODWORD(v7->pv.position.rotation.elt[2][2]);
    v77 = v7->cofm;
    v78 = v164;
    v79 = v192.x * 0.0;
    v80 = v192.x;
    v81 = 0.0 * v192.z;
  }
  else
  {
    v147 = v7->pv.position.rotation.elt[0][2];
    if ( !v7->isMassless || v7->root == v7 )
      p_moment = &v7->bodyMass.moment;
    else
      p_moment = (RBX::Matrix3 *)&unk_58DF6C;
    v78 = v164;
    v79 = v192.x * 0.0;
    v80 = v192.x;
    v81 = 0.0 * v192.z;
    v65 = (unsigned int *)&p_moment->elt[0][1];
    v66 = (unsigned int *)&p_moment->elt[0][2];
    v67 = (unsigned int *)p_moment->elt[1];
    v68 = (unsigned int *)&p_moment->elt[1][1];
    v69 = (unsigned int *)&p_moment->elt[1][2];
    v70 = p_moment->elt[2];
    v71 = &p_moment->elt[2][1];
    v72 = &p_moment->elt[2][2];
    LODWORD(v163) = _mm_shuffle_ps(v55, v55, 229).m128_u32[0];
    LODWORD(v75) = _mm_shuffle_ps(v57, v57, 229).m128_u32[0];
    v76 = _mm_shuffle_ps(
            (__m128)*(unsigned __int64 *)&v7->pv.position.rotation.elt[2][0],
            (__m128)*(unsigned __int64 *)&v7->pv.position.rotation.elt[2][0],
            229);
    v77 = 0;
    v74 = (__m128)*(unsigned __int64 *)&v7->pv.position.rotation.elt[2][0];
    LODWORD(v73) = *(_QWORD *)&v7->pv.position.rotation.elt[0][0];
  }
  v82 = _mm_add_ps(v56, v181);
  v162 = _mm_mul_ps(v58, v179);
  v83 = v59 + v61;
  v160 = z_low.m128_f32[0] * v153;
  v155 = v192.z - v78;
  v152 = v79 - v81;
  v84 = v78 - v80;
  v174 = (__m128)*v69;
  v180 = (__m128)*v68;
  v189 = (__m128)*v67;
  v177 = (__m128)*v66;
  v182 = (__m128)*v65;
  v190 = (__m128)LODWORD(p_moment->elt[0][0]);
  v85 = _mm_shuffle_ps(v170, v170, 229).m128_f32[0];
  v86 = v167;
  v87 = v167;
  v87.m128_f32[0] = (float)(v167.m128_f32[0] * v74.m128_f32[0])
                  + (float)((float)(v85 * v57.m128_f32[0]) + (float)(v170.m128_f32[0] * v73));
  v88 = v167;
  v88.m128_f32[0] = (float)(v167.m128_f32[0] * v76.m128_f32[0])
                  + (float)((float)(v85 * v75) + (float)(v170.m128_f32[0] * v163));
  v86.m128_f32[0] = (float)(v167.m128_f32[0] * v62.m128_f32[0])
                  + (float)((float)(v85 * v60) + (float)(v170.m128_f32[0] * v147));
  v89 = *v70;
  v188 = v87;
  v175 = v88;
  v154 = *v71 * v88.m128_f32[0];
  v168 = v86;
  v172 = *v72 * v86.m128_f32[0];
  v171 = v89 * v87.m128_f32[0];
  if ( v77 )
  {
    RBX::Cofm::updateIfDirty(v77);
    v90 = &v77->branch.moment;
    v91 = (unsigned int *)&v77->branch.moment.elt[0][1];
    v92 = (unsigned int *)&v77->branch.moment.elt[0][2];
    v93 = (unsigned int *)v77->branch.moment.elt[1];
    v94 = (unsigned int *)&v77->branch.moment.elt[1][1];
    v95 = (unsigned int *)&v77->branch.moment.elt[1][2];
    v96 = v77->branch.moment.elt[2];
    v97 = &v77->branch.moment.elt[2][1];
    v98 = &v77->branch.moment.elt[2][2];
    v73 = v7->pv.position.rotation.elt[0][0];
    v99 = v7->pv.position.rotation.elt[0][1];
    v57.m128_i32[0] = LODWORD(v7->pv.position.rotation.elt[1][0]);
    v74 = (__m128)LODWORD(v7->pv.position.rotation.elt[2][0]);
    v75 = v7->pv.position.rotation.elt[1][1];
    v76 = (__m128)LODWORD(v7->pv.position.rotation.elt[2][1]);
    v100 = v7->pv.position.rotation.elt[0][2];
    v60 = v7->pv.position.rotation.elt[1][2];
    v62 = (__m128)LODWORD(v7->pv.position.rotation.elt[2][2]);
    v101 = v152;
    v102 = v162;
  }
  else
  {
    v99 = v163;
    v100 = v147;
    if ( !v7->isMassless || v7->root == v7 )
      v90 = &v7->bodyMass.moment;
    else
      v90 = (RBX::Matrix3 *)&unk_58DF6C;
    v101 = v152;
    v102 = v162;
    v91 = (unsigned int *)&v90->elt[0][1];
    v92 = (unsigned int *)&v90->elt[0][2];
    v93 = (unsigned int *)v90->elt[1];
    v94 = (unsigned int *)&v90->elt[1][1];
    v95 = (unsigned int *)&v90->elt[1][2];
    v96 = v90->elt[2];
    v97 = &v90->elt[2][1];
    v98 = &v90->elt[2][2];
  }
  v103 = _mm_add_ps(v82, v102);
  v38.m128_f32[0] = v83 + v160;
  v161 = (__m128)LODWORD(v90->elt[0][0]);
  v74.m128_f32[0] = (float)(v74.m128_f32[0] * v84) + (float)((float)(v57.m128_f32[0] * v101) + (float)(v73 * v155));
  v104 = (__m128)*v91;
  v105 = (__m128)*v92;
  v76.m128_f32[0] = (float)(v76.m128_f32[0] * v84) + (float)((float)(v75 * v101) + (float)(v99 * v155));
  v106 = (__m128)*v95;
  v62.m128_f32[0] = (float)(v62.m128_f32[0] * v84) + (float)((float)(v60 * v101) + (float)(v100 * v155));
  v107 = *v96 * v74.m128_f32[0];
  v108 = *v97 * v76.m128_f32[0];
  v109 = *v98 * v62.m128_f32[0];
  v156 = (__m128)*v94;
  v165 = (__m128)*v93;
  if ( stru_2A10FE8.value )
  {
    v110 = v7->cofm;
    if ( v110 )
    {
      v178 = (__m128)*v92;
      RBX::Cofm::updateIfDirty(v7->cofm);
      v111 = v106;
      v112 = v178;
      v113 = &v110->branch.moment;
      v114 = (unsigned int *)&v110->branch.moment.elt[0][1];
      v115 = (unsigned int *)&v110->branch.moment.elt[0][2];
      v116 = (unsigned int *)v110->branch.moment.elt[1];
      v117 = (unsigned int *)&v110->branch.moment.elt[1][1];
      v118 = (unsigned int *)&v110->branch.moment.elt[1][2];
      v119 = v110->branch.moment.elt[2];
      v120 = &v110->branch.moment.elt[2][1];
      v121 = &v110->branch.moment.elt[2][2];
    }
    else
    {
      v125 = (__m128)*v92;
      if ( !v7->isMassless || v7->root == v7 )
        v113 = &v7->bodyMass.moment;
      else
        v113 = (RBX::Matrix3 *)&unk_58DF6C;
      v111 = v106;
      v114 = (unsigned int *)&v113->elt[0][1];
      v115 = (unsigned int *)&v113->elt[0][2];
      v116 = (unsigned int *)v113->elt[1];
      v117 = (unsigned int *)&v113->elt[1][1];
      v118 = (unsigned int *)&v113->elt[1][2];
      v119 = v113->elt[2];
      v120 = &v113->elt[2][1];
      v121 = &v113->elt[2][2];
      v112 = v125;
    }
    v126 = _mm_shuffle_ps(v103, v103, 229);
    v127 = _mm_add_ps(
             _mm_mul_ps(_mm_shuffle_ps(v38, v38, 224), _mm_unpacklo_ps((__m128)*v115, (__m128)*v118)),
             _mm_add_ps(
               _mm_mul_ps(v126, _mm_unpacklo_ps((__m128)*v114, (__m128)*v117)),
               _mm_mul_ps(
                 _mm_shuffle_ps(v103, v103, 224),
                 _mm_unpacklo_ps((__m128)LODWORD(v113->elt[0][0]), (__m128)*v116))));
    v128 = (float)(v38.m128_f32[0] * *v121)
         + (float)((float)(*v120 * v126.m128_f32[0]) + (float)(*v119 * v103.m128_f32[0]));
  }
  else
  {
    v122 = v7->cofm;
    if ( v122 )
    {
      RBX::Cofm::updateIfDirty(v122);
      m.elt[2][2] = v122->branch.moment.elt[2][2];
      v123 = *(__m128 *)&v122->branch.moment.elt[0][0];
      v124 = *(__m128 *)&v122->branch.moment.elt[1][1];
    }
    else
    {
      if ( !v7->isMassless || v7->root == v7 )
        v129 = (__m128 *)&v7->bodyMass.moment;
      else
        v129 = (__m128 *)&unk_58DF6C;
      LODWORD(m.elt[2][2]) = v129[2].m128_i32[0];
      v123 = *v129;
      v124 = v129[1];
    }
    *(__m128 *)&m.elt[1][1] = v124;
    *(__m128 *)&m.elt[0][0] = v123;
    v193 = RBX::Math::toDiagonal(&m);
    v123.m128_i32[0] = LODWORD(v193.x);
    v123.m128_i32[1] = LODWORD(v193.y);
    v128 = v38.m128_f32[0] * v193.z;
    v127 = _mm_mul_ps(v103, v123);
    v112 = v105;
    v111 = v106;
  }
  v130 = v7->root->rigidBody;
  if ( v130 )
  {
    v131 = _mm_xor_ps(v184, *(__m128 *)&stru_3E4970.x);
    v132 = _mm_sub_ps(
             _mm_sub_ps(
               _mm_mul_ps(
                 _mm_shuffle_ps(v131, v131, 224),
                 _mm_add_ps(
                   _mm_mul_ps(_mm_shuffle_ps(v168, v168, 224), _mm_unpacklo_ps(v177, v174)),
                   _mm_add_ps(
                     _mm_mul_ps(_mm_shuffle_ps(v175, v175, 224), _mm_unpacklo_ps(v182, v180)),
                     _mm_mul_ps(_mm_shuffle_ps(v188, v188, 224), _mm_unpacklo_ps(v190, v189))))),
               _mm_mul_ps(
                 _mm_shuffle_ps(v186, v186, 224),
                 _mm_add_ps(
                   _mm_mul_ps(_mm_shuffle_ps(v62, v62, 224), _mm_unpacklo_ps(v112, v111)),
                   _mm_add_ps(
                     _mm_mul_ps(_mm_shuffle_ps(v76, v76, 224), _mm_unpacklo_ps(v104, v156)),
                     _mm_mul_ps(_mm_shuffle_ps(v74, v74, 224), _mm_unpacklo_ps(v161, v165)))))),
             _mm_mul_ps(_mm_shuffle_ps(v185, v185, 224), v127));
    v133 = (float)((float)((float)((float)(v171 + v154) + v172) * v131.m128_f32[0])
                 - (float)((float)((float)(v107 + v108) + v109) * v186.m128_f32[0]))
         - (float)(v128 * v185.m128_f32[0]);
    v134 = v7->pv.position.rotation.elt[0][0];
    v135 = v7->pv.position.rotation.elt[1][0];
    v149 = v7->pv.position.rotation.elt[2][0];
    v136 = v7->pv.position.rotation.elt[0][1];
    v137 = v7->pv.position.rotation.elt[1][1];
    v157 = v7->pv.position.rotation.elt[2][1];
    v138 = v7->pv.position.rotation.elt[0][2];
    v139 = v7->pv.position.rotation.elt[1][2];
    v131.m128_f32[0] = _mm_shuffle_ps(v187, v187, 229).m128_f32[0];
    v140 = v7->pv.position.rotation.elt[2][2];
    v141 = (float)((float)(v173 * v140) + (float)((float)(v131.m128_f32[0] * v139) + (float)(v187.m128_f32[0] * v138)))
         + v133;
    v142 = (float)((float)(v173 * v149) + (float)((float)(v131.m128_f32[0] * v135) + (float)(v187.m128_f32[0] * v134)))
         + v132.m128_f32[0];
    v132.m128_f32[0] = _mm_shuffle_ps(v132, v132, 229).m128_f32[0]
                     + (float)((float)(v173 * v157)
                             + (float)((float)(v131.m128_f32[0] * v137) + (float)(v187.m128_f32[0] * v136)));
    v143 = (float)(v136 * v132.m128_f32[0]) + (float)(v134 * v142);
    v144 = (float)(v137 * v132.m128_f32[0]) + (float)(v135 * v142);
    v145 = (float)(v132.m128_f32[0] * v157) + (float)(v142 * v149);
    v146 = (float)((float)(v138 * v141) + v143) - v187.m128_f32[0];
    v150 = (float)((float)(v139 * v141) + v144) - v131.m128_f32[0];
    if ( v130->dirty )
      RBX::Solver::SolverRigidBody::update(v130);
    v130->torque.x = v146 + v130->torque.x;
    v130->torque.y = v150 + v130->torque.y;
    v130->torque.z = (float)((float)((float)(v141 * v140) + v145) - v173) + v130->torque.z;
  }
}


// Address: 0x10efb70 | Name: _ZN3RBX5HUMAN8Swimming19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::Swimming::onSimulatorStepImpl(RBX::HUMAN::Swimming *this, double a2, float stepDt)
{
  const RBX::Humanoid *HumanoidConst; // rax
  float v4; // xmm0_4
  float v5; // xmm2_4
  __m128 v6; // xmm1
  __m128 v7; // xmm3
  __m128 v8; // xmm3
  float v9; // xmm2_4
  float v10; // xmm3_4
  float v11; // [rsp+Ch] [rbp-2Ch]
  __int128 v12; // [rsp+10h] [rbp-28h] BYREF
  __int64 v13; // [rsp+20h] [rbp-18h]

  v11 = *(float *)&a2;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  (*(void (__fastcall **)(__int128 *, const RBX::Humanoid *, double, float))(*(_QWORD *)HumanoidConst + 416LL))(
    &v12,
    HumanoidConst,
    a2,
    stepDt);
  *(_OWORD *)((char *)this + 324) = v12;
  *(_QWORD *)((char *)this + 340) = v13;
  v4 = *((float *)this + 78);
  v5 = *((float *)this + 81) + v4;
  *((float *)this + 81) = v5;
  v6 = (__m128)*(unsigned __int64 *)((char *)this + 316);
  v7 = _mm_add_ps((__m128)*((unsigned __int64 *)this + 41), v6);
  *((_DWORD *)this + 82) = v7.m128_i32[0];
  *((_DWORD *)this + 83) = _mm_shuffle_ps(v7, v7, 229).m128_u32[0];
  v8 = _mm_mul_ps(v7, v7);
  if ( fsqrt(_mm_shuffle_ps(v8, v8, 229).m128_f32[0] + (float)((float)(v5 * v5) + v8.m128_f32[0])) >= 0.1 )
  {
    LODWORD(v9) = _mm_shuffle_epi32((__m128i)v6, 229).m128i_u32[0];
  }
  else
  {
    if ( !(_BYTE)byte_2A08DC8 && __cxa_guard_acquire(&byte_2A08DC8) )
    {
      *(_OWORD *)&vel.linear.x = 0;
      *(_QWORD *)&vel.rotational.y = 0;
      __cxa_guard_release(&byte_2A08DC8);
    }
    *(RBX::Velocity *)((char *)this + 324) = vel;
    v4 = *((float *)this + 78);
    v6.m128_i32[0] = *((_DWORD *)this + 79);
    v9 = *((float *)this + 80);
  }
  v10 = (float)((float)(v11 * -0.050000001) / 0.033333335) + 1.0;
  *((float *)this + 78) = v4 * v10;
  *((float *)this + 79) = v6.m128_f32[0] * v10;
  *((float *)this + 80) = v10 * v9;
}


// Address: 0x10efcf0 | Name: _ZN3RBX5HUMAN8Swimming10fireEventsEv
void __fastcall RBX::HUMAN::Swimming::fireEvents(RBX::HUMAN::Swimming *this)
{
  __m128 v1; // xmm0
  rbx::signal<void (float)> *v2; // r14
  __m128 v3; // xmm0
  float v4; // xmm1_4
  __m128 v5; // xmm0
  RBX::Vector3 RelativeMovementVelocity; // 0:kr00_12.12

  RBX::HUMAN::HumanoidState::fireEvents(this);
  v2 = (rbx::signal<void (float)> *)((char *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 2624);
  RelativeMovementVelocity = RBX::HUMAN::HumanoidState::getRelativeMovementVelocity(this);
  v1.m128_i32[0] = LODWORD(RelativeMovementVelocity.x);
  v1.m128_i32[1] = LODWORD(RelativeMovementVelocity.y);
  v3 = _mm_mul_ps(v1, v1);
  v4 = (float)(RelativeMovementVelocity.z * RelativeMovementVelocity.z)
     + (float)(_mm_shuffle_ps(v3, v3, 229).m128_f32[0] + v3.m128_f32[0]);
  v5 = 0;
  v5.m128_f32[0] = fsqrt(v4);
  RBX::HUMAN::HumanoidState::fireMovementSignal(this, v2, v5, v4);
}


// Address: 0x10efdb0 | Name: _GLOBAL__sub_I_Swimming.cpp
void __cdecl GLOBAL__sub_I_Swimming_cpp()
{
  qword_2A093B8 = (__int64)boost::system::generic_category();
  qword_2A093C0 = (__int64)boost::system::generic_category();
  qword_2A093C8 = (__int64)boost::system::system_category();
}


