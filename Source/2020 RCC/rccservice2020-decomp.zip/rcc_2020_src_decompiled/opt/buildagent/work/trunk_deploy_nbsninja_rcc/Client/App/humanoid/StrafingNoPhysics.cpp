// Address: 0x10ee8c0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN17StrafingNoPhysicsE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::StrafingNoPhysics *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A093B0;
  if ( !qword_2A093B0 )
  {
    result = RBX::Name::declare("StrafingNoPhysics");
    qword_2A093B0 = result;
  }
  return result;
}


// Address: 0x10ee8f0 | Name: _ZNK3RBX5HUMAN17StrafingNoPhysics7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::StrafingNoPhysics::getName(const RBX::HUMAN::StrafingNoPhysics *this)
{
  const RBX::Name *result; // rax

  result = qword_2A093B0;
  if ( !qword_2A093B0 )
  {
    result = RBX::Name::declare("StrafingNoPhysics");
    qword_2A093B0 = result;
  }
  return result;
}


// Address: 0x10ee920 | Name: _ZN3RBX5HUMAN17StrafingNoPhysicsC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::StrafingNoPhysics::StrafingNoPhysics(
        RBX::HUMAN::StrafingNoPhysics *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::MovingNoPhysicsBase::MovingNoPhysicsBase(this, humanoid, priorState);
  *(_QWORD *)this = &off_2897610;
}


// Address: 0x10ee970 | Name: _GLOBAL__sub_I_StrafingNoPhysics.cpp
void __cdecl GLOBAL__sub_I_StrafingNoPhysics_cpp()
{
  qword_2A09398 = (__int64)boost::system::generic_category();
  qword_2A093A0 = (__int64)boost::system::generic_category();
  qword_2A093A8 = (__int64)boost::system::system_category();
}


