// Address: 0x15d22c0 | Name: _ZN3RBX7GuiItem11onLoseFocusEv
void __fastcall RBX::GuiItem::onLoseFocus(RBX::GuiItem *this)
{
  ;
}


// Address: 0x15d22d0 | Name: _ZN3RBX7GuiItem12canLoseFocusEv
bool __fastcall RBX::GuiItem::canLoseFocus(RBX::GuiItem *this)
{
  return 0;
}


// Address: 0x15d22e0 | Name: _ZNK3RBX7GuiItem11getPositionENS_6CanvasE
RBX::Vector2 __fastcall RBX::GuiItem::getPosition(const RBX::GuiItem *this, double a2, RBX::Canvas canvas)
{
  volatile signed __int32 *v3; // rbx
  signed __int32 v4; // eax
  signed __int32 v5; // ett
  __int64 v6; // r15

  v3 = (volatile signed __int32 *)*((_QWORD *)this + 4);
  v4 = *((_DWORD *)v3 + 2);
  do
  {
    v5 = v4;
    v4 = _InterlockedCompareExchange(v3 + 2, v4 + 1, v4);
  }
  while ( v5 != v4 );
  v6 = *((_QWORD *)this + 3);
  if ( !_InterlockedSub(v3 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, double, double))(*(_QWORD *)v3 + 16LL))(
      v3,
      a2,
      *(double *)&canvas);
    if ( !_InterlockedSub(v3 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *, double))(*(_QWORD *)v3 + 24LL))(v3, a2);
  }
  return (*(RBX::Vector2 (__fastcall **)(__int64, const RBX::GuiItem *, double, double))(*(_QWORD *)v6 + 24LL))(
           v6,
           this,
           a2,
           *(double *)&canvas);
}


// Address: 0x15d2360 | Name: _ZNK3RBX7GuiItem16getChildPositionEPKS0_NS_6CanvasE
RBX::Vector2 __fastcall RBX::GuiItem::getChildPosition(
        const RBX::GuiItem *this,
        const RBX::GuiItem *child,
        double a3,
        RBX::Canvas canvas)
{
  return 0;
}


// Address: 0x15d2370 | Name: _ZNK3RBX7GuiItem11getFontSizeEv
int __fastcall RBX::GuiItem::getFontSize(const RBX::GuiItem *this)
{
  return 12;
}


// Address: 0x15d2380 | Name: _ZNK3RBX10TopMenuBar9isVisibleEv
bool __fastcall RBX::TopMenuBar::isVisible(const RBX::TopMenuBar *this)
{
  return *((_BYTE *)this + 132);
}


// Address: 0x15d2390 | Name: _ZN3RBX7GuiItem8getTitleEv
RBX::GuiItem *__fastcall RBX::GuiItem::getTitle(RBX::GuiItem *this, __int64 a2)
{
  std::string::basic_string(this, a2 + 64);
  return this;
}


// Address: 0x15d23b0 | Name: _ZNK3RBX7GuiItem7getSizeENS_6CanvasE
RBX::Vector2 __fastcall RBX::GuiItem::getSize(const RBX::GuiItem *this, double a2, RBX::Canvas canvas)
{
  return (RBX::Vector2)*((_QWORD *)this + 13);
}


// Address: 0x15d23c0 | Name: _ZN3RBX7GuiItem8render2dEPNS_5AdornE
void __fastcall RBX::GuiItem::render2d(RBX::GuiItem *this, RBX::Adorn *adorn)
{
  ;
}


// Address: 0x15d23d0 | Name: _ZN3RBX10TopMenuBar12asTopbarMenuEv
RBX::TopMenuBar *__fastcall RBX::TopMenuBar::asTopbarMenu(RBX::TopMenuBar *this)
{
  return this;
}


// Address: 0x15d23e0 | Name: _ZNK3RBX10TopMenuBar12asTopbarMenuEv
const RBX::TopMenuBar *__fastcall RBX::TopMenuBar::asTopbarMenu(const RBX::TopMenuBar *this)
{
  return this;
}


// Address: 0x15d23f0 | Name: _ZN3RBX10TopMenuBarD0Ev
void __fastcall RBX::TopMenuBar::~TopMenuBar(RBX::TopMenuBar *this)
{
  RBX::GuiItem::~GuiItem(this);
  operator delete(this);
}


// Address: 0x15d2410 | Name: _ZN3RBX13RelativePanelD0Ev
void __fastcall RBX::RelativePanel::~RelativePanel(RBX::RelativePanel *this)
{
  RBX::GuiItem::~GuiItem(this);
  operator delete(this);
}


// Address: 0x15d2430 | Name: _ZNK3RBX11TextDisplay9isVisibleEv
bool __fastcall RBX::TextDisplay::isVisible(const RBX::TextDisplay *this)
{
  return *((_BYTE *)this + 176);
}


// Address: 0x15d2440 | Name: _ZN3RBX7GuiItem12asTopbarMenuEv
RBX::TopMenuBar *__fastcall RBX::GuiItem::asTopbarMenu(RBX::GuiItem *this)
{
  return 0;
}


// Address: 0x15d2450 | Name: _ZNK3RBX7GuiItem12asTopbarMenuEv
const RBX::TopMenuBar *__fastcall RBX::GuiItem::asTopbarMenu(const RBX::GuiItem *this)
{
  return 0;
}


// Address: 0x15d2460 | Name: _ZN3RBX11TextDisplayD2Ev
void __fastcall RBX::TextDisplay::~TextDisplay(RBX::TextDisplay *this)
{
  *(_QWORD *)this = off_28C95A0;
  if ( (*((_BYTE *)this + 112) & 1) != 0 )
    operator delete(*((void **)this + 16));
  RBX::GuiItem::~GuiItem(this);
}


// Address: 0x15d2490 | Name: _ZN3RBX11TextDisplayD0Ev
void __fastcall RBX::TextDisplay::~TextDisplay(RBX::TextDisplay *this)
{
  *(_QWORD *)this = off_28C95A0;
  if ( (*((_BYTE *)this + 112) & 1) != 0 )
    operator delete(*((void **)this + 16));
  RBX::GuiItem::~GuiItem(this);
  operator delete(this);
}


// Address: 0x15d24d0 | Name: _ZNK3RBX7GuiItem9isVisibleEv
bool __fastcall RBX::GuiItem::isVisible(const RBX::GuiItem *this)
{
  return 1;
}


// Address: 0x15d24e0 | Name: _ZN3RBX7GuiItem8render2dEPNS_11LegacyAdornERKN3G3D7Vector2E
void __fastcall RBX::GuiItem::render2d(RBX::GuiItem *this, RBX::LegacyAdorn *adorn, const RBX::Vector2 *pos)
{
  ;
}


// Address: 0x15d24f0 | Name: _ZN3RBX7GuiRootD0Ev
void __fastcall RBX::GuiRoot::~GuiRoot(RBX::GuiRoot *this)
{
  RBX::GuiItem::~GuiItem(this);
  operator delete(this);
}


// Address: 0x176dc50 | Name: _ZN3RBX7GuiItem10addGuiItemEN5boost10shared_ptrIS0_EE
void __fastcall RBX::GuiItem::addGuiItem(RBX::GuiItem *this, boost::shared_ptr<RBX::GuiItem> guiItem)
{
  RBX::GuiItem *v2; // rbx
  unsigned __int64 v3; // rdx
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::GuiItem> newParent; // [rsp+8h] [rbp-20h] BYREF

  v2 = *(RBX::GuiItem **)guiItem.px;
  RBX::shared_from<RBX::GuiItem>(&newParent, this);
  RBX::GuiItem::setParent(v2, (boost::shared_ptr<RBX::GuiItem>)__PAIR128__(v3, &newParent));
  pi = newParent.pn.pi_;
  if ( newParent.pn.pi_ && !_InterlockedSub(&newParent.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
    if ( !_InterlockedSub(&pi->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
  }
}


// Address: 0x176df20 | Name: _ZN3RBX7GuiItem9setParentEN5boost10shared_ptrIS0_EE
void __fastcall RBX::GuiItem::setParent(
        RBX::GuiItem *this,
        boost::shared_ptr<RBX::GuiItem> newParent,
        __m128 a3,
        __m128 a4)
{
  _QWORD *px; // r15
  volatile signed __int32 *v6; // r14
  signed __int32 v7; // eax
  __int64 v8; // r13
  signed __int32 v9; // ett
  _QWORD *v10; // rbx
  __m128 *v11; // rbp
  __m128 *v12; // r15
  bool v13; // zf
  volatile signed __int32 *v14; // rbx
  __m128 *v15; // rbp
  volatile signed __int32 *v16; // rbx
  volatile signed __int32 *v17; // rbp
  volatile signed __int32 *v18; // rdi
  boost::shared_ptr<RBX::GuiItem> *v19; // rax
  boost::shared_ptr<RBX::GuiItem> v20; // xmm0
  boost::detail::sp_counted_base *pi; // rbx
  boost::shared_ptr<RBX::GuiItem> v22; // [rsp+0h] [rbp-48h] BYREF
  _QWORD *v23; // [rsp+10h] [rbp-38h]

  px = newParent.px;
  v6 = (volatile signed __int32 *)*((_QWORD *)this + 4);
  if ( v6 )
  {
    v7 = *((_DWORD *)v6 + 2);
    v8 = 0;
    while ( v7 )
    {
      v9 = v7;
      v7 = _InterlockedCompareExchange(v6 + 2, v7 + 1, v7);
      if ( v9 == v7 )
      {
        v8 = *((_QWORD *)this + 3);
        goto LABEL_8;
      }
    }
  }
  else
  {
    v8 = 0;
  }
  v6 = 0;
LABEL_8:
  v10 = *(_QWORD **)newParent.px;
  if ( *(_QWORD *)newParent.px != v8 )
  {
    if ( !v8 )
    {
LABEL_30:
      *((_QWORD *)this + 3) = v10;
      v17 = (volatile signed __int32 *)px[1];
      v18 = (volatile signed __int32 *)*((_QWORD *)this + 4);
      if ( v17 != v18 )
      {
        if ( v17 )
        {
          _InterlockedAdd(v17 + 3, 1u);
          v18 = (volatile signed __int32 *)*((_QWORD *)this + 4);
        }
        if ( v18 && !_InterlockedSub(v18 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *, boost::shared_ptr<RBX::GuiItem>::element_type *, boost::detail::sp_counted_base *))(*(_QWORD *)v18 + 24LL))(
            v18,
            newParent.px,
            newParent.pn.pi_);
        *((_QWORD *)this + 4) = v17;
        v10 = (_QWORD *)*px;
      }
      if ( v10 )
      {
        newParent.px = this;
        RBX::shared_from<RBX::GuiItem>(&v22, this);
        v19 = (boost::shared_ptr<RBX::GuiItem> *)v10[6];
        if ( (unsigned __int64)v19 >= v10[7] )
        {
          newParent.px = &v22;
          std::vector<boost::shared_ptr<RBX::GuiItem>>::__push_back_slow_path<boost::shared_ptr<RBX::GuiItem>>(
            (std::vector<boost::shared_ptr<RBX::GuiItem>> *)(v10 + 5),
            &v22);
        }
        else
        {
          v19->pn.pi_ = 0;
          v20 = v22;
          v22.pn.pi_ = 0;
          *v19 = v20;
          v22.px = 0;
          v10[6] = v19 + 1;
        }
        pi = v22.pn.pi_;
        if ( v22.pn.pi_ )
        {
          if ( !_InterlockedSub(&v22.pn.pi_->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
            if ( !_InterlockedSub(&pi->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
          }
        }
      }
      goto LABEL_45;
    }
    v23 = newParent.px;
    v11 = *(__m128 **)(v8 + 40);
    v12 = *(__m128 **)(v8 + 48);
    do
    {
      if ( v12 == v11 )
      {
        px = v23;
        goto LABEL_30;
      }
      v13 = v11->m128_u64[0] == (_QWORD)this;
      ++v11;
    }
    while ( !v13 );
    if ( v12 == v11 )
    {
      v15 = v11 - 1;
    }
    else
    {
      a4 = 0;
      do
      {
        a3 = *v11;
        *v11 = a4;
        v14 = (volatile signed __int32 *)v11[-1].m128_u64[1];
        v11[-1] = a3;
        if ( v14 )
        {
          if ( !_InterlockedSub(v14 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *, boost::shared_ptr<RBX::GuiItem>::element_type *, boost::detail::sp_counted_base *))(*(_QWORD *)v14 + 16LL))(
              v14,
              newParent.px,
              newParent.pn.pi_);
            a4 = 0;
            if ( !_InterlockedSub(v14 + 3, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *, double, double))(*(_QWORD *)v14 + 24LL))(
                v14,
                *(double *)a3.m128_u64,
                0.0);
              a4 = 0;
            }
          }
        }
        ++v11;
      }
      while ( v12 != v11 );
      v12 = *(__m128 **)(v8 + 48);
      v13 = &v12[1] == v11;
      v15 = v11 - 1;
      if ( v13 )
        goto LABEL_29;
    }
    do
    {
      v16 = (volatile signed __int32 *)v12[-1].m128_u64[1];
      if ( v16 )
      {
        if ( !_InterlockedSub(v16 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *, boost::shared_ptr<RBX::GuiItem>::element_type *, boost::detail::sp_counted_base *, double, double))(*(_QWORD *)v16 + 16LL))(
            v16,
            newParent.px,
            newParent.pn.pi_,
            *(double *)a3.m128_u64,
            *(double *)a4.m128_u64);
          if ( !_InterlockedSub(v16 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
        }
      }
      --v12;
    }
    while ( v15 != v12 );
LABEL_29:
    *(_QWORD *)(v8 + 48) = v15;
    px = v23;
    v10 = (_QWORD *)*v23;
    goto LABEL_30;
  }
LABEL_45:
  if ( v6 && !_InterlockedSub(v6 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, boost::shared_ptr<RBX::GuiItem>::element_type *, boost::detail::sp_counted_base *))(*(_QWORD *)v6 + 16LL))(
      v6,
      newParent.px,
      newParent.pn.pi_);
    if ( !_InterlockedSub(v6 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  }
}


