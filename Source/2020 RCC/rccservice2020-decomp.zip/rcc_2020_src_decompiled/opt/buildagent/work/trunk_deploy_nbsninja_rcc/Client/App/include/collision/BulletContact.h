// Address: 0x1de9ed0 | Name: _ZN3RBX9Collision24BulletCollisionInterface18clearManifoldPointEPNS0_24BulletCollisionConnectorER20btAlignedObjectArrayIP20btPersistentManifoldE
void __fastcall RBX::Collision::BulletCollisionInterface::clearManifoldPoint(
        RBX::Collision::BulletCollisionConnector *conn,
        btManifoldArray *manifoldArray)
{
  __int64 bulletManifoldIndex; // rax
  __int64 bulletPointCacheIndex; // rcx
  btPersistentManifold *v4; // rdi

  bulletManifoldIndex = conn->bulletManifoldIndex;
  bulletPointCacheIndex = conn->bulletPointCacheIndex;
  if ( ((unsigned int)bulletManifoldIndex & conn->bulletPointCacheIndex) != 0xFFFFFFFF )
  {
    v4 = manifoldArray->m_data[bulletManifoldIndex];
    btPersistentManifold::clearUserCache(v4, &v4->m_pointCache[bulletPointCacheIndex]);
  }
}


