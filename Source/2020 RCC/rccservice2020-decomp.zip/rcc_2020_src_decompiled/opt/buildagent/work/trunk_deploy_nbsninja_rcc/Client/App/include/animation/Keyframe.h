// Address: 0x104c780 | Name: _ZNK3RBX8Keyframe7getTimeEv
float __fastcall RBX::Keyframe::getTime(const RBX::Keyframe *this)
{
  return this->time;
}


// Address: 0x104c790 | Name: _ZN3RBX8Keyframe25getKeyframeChildrenOfTypeINS_4PoseEEEN5boost10shared_ptrIKNSt3__16vectorINS4_INS_8InstanceEEENS5_9allocatorIS8_EEEEEEv
_OWORD *__fastcall RBX::Keyframe::getKeyframeChildrenOfType<RBX::Pose>(_OWORD *a1, RBX::Keyframe *this)
{
  RBX::Keyframe **px; // r12
  boost::detail::sp_counted_base *pi; // r15
  boost::detail::sp_if_not_array<std::vector<boost::shared_ptr<RBX::Instance>> >::type v4; // rax
  RBX::Keyframe *v5; // rbx
  __int64 v6; // r13
  int (***v7)(void); // rax
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *v8; // rcx
  std::vector<boost::shared_ptr<RBX::Instance>> *v10[2]; // [rsp+0h] [rbp-38h]

  px = (RBX::Keyframe **)this->children.object.px;
  pi = this->children.object.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v4 = boost::make_shared<std::vector<boost::shared_ptr<RBX::Instance>>>();
  if ( px )
  {
    v5 = *px;
    if ( *px != px[1] )
    {
      while ( 1 )
      {
        if ( !v5->_vptr$EventSource )
          goto LABEL_6;
        v6 = *((_QWORD *)v5->_vptr$EventSource + 3);
        v4.px = Class_getDescriptorPtr(0);
        v4.pn.pi_ = (boost::detail::sp_counted_base *)*((unsigned __int16 *)v4.px + 363);
        if ( (unsigned int)*(unsigned __int16 *)(v6 + 726) - LODWORD(v4.pn.pi_) > *((unsigned __int16 *)v4.px + 364) )
          goto LABEL_6;
        v7 = (int (***)(void))*((_QWORD *)v10[0] + 1);
        if ( v7 == *((int (****)(void))v10[0] + 2) )
        {
          this = v5;
          std::vector<boost::shared_ptr<RBX::Instance>>::__push_back_slow_path<boost::shared_ptr<RBX::Instance> const&>(
            v10[0],
            (const boost::shared_ptr<RBX::Instance> *)v5);
LABEL_6:
          v5 = (RBX::Keyframe *)((char *)v5 + 16);
          if ( v5 == px[1] )
            break;
        }
        else
        {
          *v7 = v5->_vptr$EventSource;
          v8 = v5->weak_this_.px;
          v7[1] = (int (**)(void))v8;
          if ( v8 )
          {
            _InterlockedAdd(
              (volatile signed __int32 *)&v8->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
              1u);
            v7 = (int (***)(void))*((_QWORD *)v10[0] + 1);
          }
          *((_QWORD *)v10[0] + 1) = v7 + 2;
          v5 = (RBX::Keyframe *)((char *)v5 + 16);
          if ( v5 == px[1] )
            break;
        }
      }
    }
  }
  *a1 = *(_OWORD *)v10;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, RBX::Keyframe *, boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base
       + 2))(
        pi,
        this,
        v4.pn.pi_);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return a1;
}


// Address: 0x104c930 | Name: _ZN3RBX8Keyframe25getKeyframeChildrenOfTypeINS_14KeyframeMarkerEEEN5boost10shared_ptrIKNSt3__16vectorINS4_INS_8InstanceEEENS5_9allocatorIS8_EEEEEEv
_OWORD *__fastcall RBX::Keyframe::getKeyframeChildrenOfType<RBX::KeyframeMarker>(_OWORD *a1, RBX::Keyframe *this)
{
  RBX::Keyframe **px; // r12
  boost::detail::sp_counted_base *pi; // r15
  boost::detail::sp_if_not_array<std::vector<boost::shared_ptr<RBX::Instance>> >::type v4; // rax
  RBX::Keyframe *v5; // rbx
  __int64 v6; // r13
  int (***v7)(void); // rax
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *v8; // rcx
  std::vector<boost::shared_ptr<RBX::Instance>> *v10[2]; // [rsp+0h] [rbp-38h]

  px = (RBX::Keyframe **)this->children.object.px;
  pi = this->children.object.pn.pi_;
  if ( pi )
    _InterlockedAdd(&pi->use_count_, 1u);
  v4 = boost::make_shared<std::vector<boost::shared_ptr<RBX::Instance>>>();
  if ( px )
  {
    v5 = *px;
    if ( *px != px[1] )
    {
      while ( 1 )
      {
        if ( !v5->_vptr$EventSource )
          goto LABEL_6;
        v6 = *((_QWORD *)v5->_vptr$EventSource + 3);
        v4.px = Class_getDescriptorPtr(0);
        v4.pn.pi_ = (boost::detail::sp_counted_base *)*((unsigned __int16 *)v4.px + 363);
        if ( (unsigned int)*(unsigned __int16 *)(v6 + 726) - LODWORD(v4.pn.pi_) > *((unsigned __int16 *)v4.px + 364) )
          goto LABEL_6;
        v7 = (int (***)(void))*((_QWORD *)v10[0] + 1);
        if ( v7 == *((int (****)(void))v10[0] + 2) )
        {
          this = v5;
          std::vector<boost::shared_ptr<RBX::Instance>>::__push_back_slow_path<boost::shared_ptr<RBX::Instance> const&>(
            v10[0],
            (const boost::shared_ptr<RBX::Instance> *)v5);
LABEL_6:
          v5 = (RBX::Keyframe *)((char *)v5 + 16);
          if ( v5 == px[1] )
            break;
        }
        else
        {
          *v7 = v5->_vptr$EventSource;
          v8 = v5->weak_this_.px;
          v7[1] = (int (**)(void))v8;
          if ( v8 )
          {
            _InterlockedAdd(
              (volatile signed __int32 *)&v8->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
              1u);
            v7 = (int (***)(void))*((_QWORD *)v10[0] + 1);
          }
          *((_QWORD *)v10[0] + 1) = v7 + 2;
          v5 = (RBX::Keyframe *)((char *)v5 + 16);
          if ( v5 == px[1] )
            break;
        }
      }
    }
  }
  *a1 = *(_OWORD *)v10;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *, RBX::Keyframe *, boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base
       + 2))(
        pi,
        this,
        v4.pn.pi_);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  return a1;
}


// Address: 0x104cb30 | Name: _ZN3RBX8KeyframeD0Ev
void __fastcall RBX::Keyframe::~Keyframe(RBX::Keyframe *this)
{
  RBX::Instance::~Instance(this);
  operator delete(this);
}


// Address: 0x104cb80 | Name: _ZNK3RBX8Keyframe11askAddChildEPKNS_8InstanceE
bool __fastcall RBX::Keyframe::askAddChild(const RBX::Keyframe *this, const RBX::Instance *instance)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  if ( !instance )
    return 0;
  descriptor = instance->descriptor;
  DescriptorPtr = Class_getDescriptorPtr(0);
  return *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364);
}


// Address: 0x104cbc0 | Name: _ZN3RBX8Keyframe12onChildAddedEPNS_8InstanceE
void __fastcall RBX::Keyframe::onChildAdded(RBX::Keyframe *this, RBX::Instance *child)
{
  RBX::KeyframeSequence *parent; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  parent = (RBX::KeyframeSequence *)this->parent;
  if ( parent )
  {
    descriptor = parent->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      RBX::KeyframeSequence::invalidateCache(parent);
  }
}


// Address: 0x104cc10 | Name: _ZN3RBX8Keyframe14onChildRemovedEPNS_8InstanceE
void __fastcall RBX::Keyframe::onChildRemoved(RBX::Keyframe *this, RBX::Instance *child)
{
  RBX::KeyframeSequence *parent; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  parent = (RBX::KeyframeSequence *)this->parent;
  if ( parent )
  {
    descriptor = parent->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      RBX::KeyframeSequence::invalidateCache(parent);
  }
}


