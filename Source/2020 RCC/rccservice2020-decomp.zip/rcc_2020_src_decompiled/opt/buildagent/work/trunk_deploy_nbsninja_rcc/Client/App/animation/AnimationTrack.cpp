// Address: 0x1042640 | Name: _ZN3RBX14AnimationTrack4playEfff
void __fastcall RBX::AnimationTrack::play(
        RBX::AnimationTrack *this,
        double a2,
        float fadeTime,
        float weight,
        float speed)
{
  boost::detail::sp_counted_base *pi; // r15
  signed __int32 use_count; // eax
  signed __int32 v7; // ett
  RBX::Animator *px; // r14
  boost::detail::sp_counted_base *v9; // rbx
  boost::detail::sp_counted_base *v10; // rbx
  boost::shared_ptr<RBX::Instance> animationTrack; // [rsp+10h] [rbp-68h] BYREF
  void *v12; // [rsp+20h] [rbp-58h]
  boost::shared_ptr<RBX::Instance> v13; // [rsp+30h] [rbp-48h]
  boost::shared_ptr<RBX::Instance> v14; // [rsp+40h] [rbp-38h] BYREF
  void *ptr; // [rsp+50h] [rbp-28h]

  if ( !RBX::Math::isNanInf(fadeTime) && !RBX::Math::isNanInf(fadeTime) && !RBX::Math::isNanInf(fadeTime) )
  {
    *(_QWORD *)&a2 = LODWORD(a2);
    RBX::AnimationTrack::localPlay(this, fadeTime, weight, speed);
    pi = this->animator.pn.pi_;
    if ( pi )
    {
      use_count = pi->use_count_;
      while ( use_count )
      {
        v7 = use_count;
        use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
        if ( v7 == use_count )
        {
          px = (RBX::Animator *)this->animator.px;
          if ( px )
          {
            RBX::shared_from<RBX::AnimationTrack>(this);
            std::string::basic_string(&animationTrack, (char *)this->animation.px + 128);
            ptr = v12;
            v14 = animationTrack;
            animationTrack = 0;
            v12 = 0;
            *(_QWORD *)&a2 = LODWORD(a2);
            RBX::Animator::replicateAnimationUpdate(
              (__int64)px,
              (__int64)&v14,
              1u,
              1u,
              0,
              *(float *)&a2,
              fadeTime,
              weight,
              0.0);
            if ( ((__int64)v14.px & 1) != 0 )
              operator delete(ptr);
            if ( ((__int64)animationTrack.px & 1) != 0 )
              operator delete(v12);
            animationTrack = v13;
            if ( v13.pn.pi_ )
              _InterlockedAdd(&v13.pn.pi_->use_count_, 1u);
            RBX::Animator::tellParentAnimationPlayed(px, &animationTrack);
            v9 = animationTrack.pn.pi_;
            if ( animationTrack.pn.pi_ )
            {
              if ( !_InterlockedSub(&animationTrack.pn.pi_->use_count_, 1u) )
              {
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 2))(v9);
                if ( !_InterlockedSub(&v9->weak_count_, 1u) )
                  (*((void (__fastcall **)(boost::detail::sp_counted_base *))v9->_vptr$sp_counted_base + 3))(v9);
              }
            }
            v10 = v13.pn.pi_;
            if ( v13.pn.pi_ )
            {
              if ( !_InterlockedSub(&v13.pn.pi_->use_count_, 1u) )
              {
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 2))(v10);
                if ( !_InterlockedSub(&v10->weak_count_, 1u) )
                  (*((void (__fastcall **)(boost::detail::sp_counted_base *))v10->_vptr$sp_counted_base + 3))(v10);
              }
            }
          }
          if ( !_InterlockedSub(&pi->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *, double))pi->_vptr$sp_counted_base + 2))(pi, a2);
            if ( !_InterlockedSub(&pi->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
          }
          return;
        }
      }
    }
  }
}


// Address: 0x1042910 | Name: _ZN3RBX14AnimationTrack4stopEf
void __fastcall RBX::AnimationTrack::stop(RBX::AnimationTrack *this, float a2, float fadeTime)
{
  bool isPlaying; // bp
  bool v4; // zf
  boost::detail::sp_counted_base *pi; // r14
  signed __int32 use_count; // eax
  signed __int32 v7; // ett
  boost::weak_ptr<RBX::Animator>::element_type *px; // r15
  __int128 v9; // [rsp+10h] [rbp-58h] BYREF
  void *v10; // [rsp+20h] [rbp-48h]
  __int128 v11; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  if ( !RBX::Math::isNanInf(fadeTime) )
  {
    isPlaying = this->isPlaying;
    if ( !stru_2A01C38.value || (v4 = !isPlaying, isPlaying = 1, !v4) )
    {
      this->weightTarget = 0.0;
      this->weightTime = a2;
      this->isPlaying = 0;
      rbx::signal<void ()(void)>::operator()(&this->stoppedSignal);
      if ( isPlaying )
        RBX::Instance::raisePropertyChanged(this, &stru_2A01F58);
      pi = this->animator.pn.pi_;
      if ( pi )
      {
        use_count = pi->use_count_;
        while ( use_count )
        {
          v7 = use_count;
          use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
          if ( v7 == use_count )
          {
            px = this->animator.px;
            if ( px )
            {
              std::string::basic_string(&v9, (char *)this->animation.px + 128);
              ptr = v10;
              v11 = v9;
              v9 = 0;
              v10 = 0;
              RBX::Animator::replicateAnimationUpdate(
                (__int64)px,
                (__int64)&v11,
                0,
                1u,
                0,
                a2,
                this->weightTarget,
                this->timeSpeed,
                0.0);
              if ( (v11 & 1) != 0 )
                operator delete(ptr);
              if ( (v9 & 1) != 0 )
                operator delete(v10);
            }
            if ( !_InterlockedSub(&pi->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
              if ( !_InterlockedSub(&pi->weak_count_, 1u) )
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
            }
            return;
          }
        }
      }
    }
  }
}


// Address: 0x1042b00 | Name: _ZN3RBX14AnimationTrack12adjustWeightEff
void __fastcall RBX::AnimationTrack::adjustWeight(RBX::AnimationTrack *this, float a2, float weight, float fadeTime)
{
  float weightTarget; // xmm0_4
  boost::detail::sp_counted_base *pi; // r14
  signed __int32 use_count; // eax
  signed __int32 v7; // ett
  boost::weak_ptr<RBX::Animator>::element_type *px; // r15
  __int128 v10; // [rsp+10h] [rbp-58h] BYREF
  void *v11; // [rsp+20h] [rbp-48h]
  __int128 v12; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  if ( !RBX::Math::isNanInf(weight) && !RBX::Math::isNanInf(weight) )
  {
    weightTarget = this->weightTarget;
    this->weightTarget = a2;
    this->weightTime = weight;
    if ( weightTarget != a2 )
    {
      pi = this->animator.pn.pi_;
      if ( pi )
      {
        use_count = pi->use_count_;
        while ( use_count )
        {
          v7 = use_count;
          use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
          if ( v7 == use_count )
          {
            px = this->animator.px;
            if ( px )
            {
              std::string::basic_string(&v10, (char *)this->animation.px + 128);
              ptr = v11;
              v12 = v10;
              v10 = 0;
              v11 = 0;
              RBX::Animator::replicateAnimationUpdate(
                (__int64)px,
                (__int64)&v12,
                1u,
                2u,
                0,
                weight,
                a2,
                this->timeSpeed,
                this->timePosition);
              if ( (v12 & 1) != 0 )
                operator delete(ptr);
              if ( (v10 & 1) != 0 )
                operator delete(v11);
            }
            if ( !_InterlockedSub(&pi->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
              if ( !_InterlockedSub(&pi->weak_count_, 1u) )
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
            }
            return;
          }
        }
      }
    }
  }
}


// Address: 0x1042ce0 | Name: _ZN3RBX14AnimationTrack11adjustSpeedEf
void __fastcall RBX::AnimationTrack::adjustSpeed(RBX::AnimationTrack *this, float a2, float value)
{
  float timeSpeed; // xmm0_4
  boost::detail::sp_counted_base *pi; // r14
  signed __int32 use_count; // eax
  signed __int32 v6; // ett
  boost::weak_ptr<RBX::Animator>::element_type *px; // r15
  __int128 v9; // [rsp+10h] [rbp-58h] BYREF
  void *v10; // [rsp+20h] [rbp-48h]
  __int128 v11; // [rsp+30h] [rbp-38h] BYREF
  void *ptr; // [rsp+40h] [rbp-28h]

  if ( !RBX::Math::isNan(value) )
  {
    timeSpeed = this->timeSpeed;
    this->timeSpeed = a2;
    if ( timeSpeed != a2 )
    {
      pi = this->animator.pn.pi_;
      if ( pi )
      {
        use_count = pi->use_count_;
        while ( use_count )
        {
          v6 = use_count;
          use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
          if ( v6 == use_count )
          {
            px = this->animator.px;
            if ( px )
            {
              std::string::basic_string(&v9, (char *)this->animation.px + 128);
              ptr = v10;
              v11 = v9;
              v9 = 0;
              v10 = 0;
              RBX::Animator::replicateAnimationUpdate(
                (__int64)px,
                (__int64)&v11,
                1u,
                4u,
                0,
                this->weightTime,
                this->weightTarget,
                a2,
                this->timePosition);
              if ( (v11 & 1) != 0 )
                operator delete(ptr);
              if ( (v9 & 1) != 0 )
                operator delete(v10);
            }
            if ( !_InterlockedSub(&pi->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
              if ( !_InterlockedSub(&pi->weak_count_, 1u) )
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
            }
            return;
          }
        }
      }
    }
  }
}


// Address: 0x1042eb0 | Name: _ZN3RBX14AnimationTrack17getTimeOfKeyframeENSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
double __fastcall RBX::AnimationTrack::getTimeOfKeyframe(__int64 a1, unsigned __int8 *a2)
{
  const RBX::KeyframeSequence::Cache *CachedData; // rax
  __int64 v4; // rbx
  __int64 v5; // r12
  unsigned __int64 v6; // r13
  size_t v7; // r15
  unsigned __int8 v8; // cl
  unsigned __int64 v9; // rdx
  _BYTE *v10; // rsi
  __int64 v11; // rcx
  RBX *exception; // rbx

  CachedData = RBX::KeyframeSequence::getCachedData(*(const RBX::KeyframeSequence **)(a1 + 184));
  v4 = *((_QWORD *)CachedData + 11);
  v5 = *((_QWORD *)CachedData + 12);
  if ( v4 == v5 )
  {
LABEL_19:
    exception = (RBX *)__cxa_allocate_exception(0x10u);
    RBX::runtime_error(exception, "Could not find a keyframe by that name!");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  v6 = *a2;
  if ( (v6 & 1) != 0 )
    v7 = *((_QWORD *)a2 + 1);
  else
    v7 = v6 >> 1;
  while ( 1 )
  {
    v8 = *(_BYTE *)(v4 + 8);
    v9 = (unsigned __int64)v8 >> 1;
    if ( (v8 & 1) != 0 )
      v9 = *(_QWORD *)(v4 + 16);
    if ( v9 == v7 )
    {
      v10 = a2 + 1;
      if ( (v6 & 1) != 0 )
        v10 = (_BYTE *)*((_QWORD *)a2 + 2);
      if ( (v8 & 1) == 0 )
      {
        if ( !v7 )
          return *(float *)v4;
        v11 = 0;
        while ( *(_BYTE *)(v4 + v11 + 9) == v10[v11] )
        {
          if ( (unsigned __int64)*(unsigned __int8 *)(v4 + 8) >> 1 == ++v11 )
            return *(float *)v4;
        }
        goto LABEL_18;
      }
      if ( !v7 || !memcmp(*(const void **)(v4 + 24), v10, v7) )
        return *(float *)v4;
    }
LABEL_18:
    v4 += 104;
    if ( v4 == v5 )
      goto LABEL_19;
  }
}


// Address: 0x1043000 | Name: _ZNK3RBX14AnimationTrack12getIsPlayingEv
bool __fastcall RBX::AnimationTrack::getIsPlaying(const RBX::AnimationTrack *this)
{
  return this->isPlaying;
}


// Address: 0x1043010 | Name: _ZNK3RBX14AnimationTrack15getTimePositionEv
float __fastcall RBX::AnimationTrack::getTimePosition(const RBX::AnimationTrack *this)
{
  return this->timePosition;
}


// Address: 0x1043020 | Name: _ZN3RBX14AnimationTrack15setTimePositionEf
void __fastcall RBX::AnimationTrack::setTimePosition(RBX::AnimationTrack *this, float a2, float value)
{
  __int128 timePosition_low; // xmm0
  float v4; // xmm1_4
  boost::detail::sp_counted_base *pi; // r14
  signed __int32 use_count; // eax
  signed __int32 v7; // ett
  boost::weak_ptr<RBX::Animator>::element_type *px; // r15
  float timePosition; // [rsp+Ch] [rbp-6Ch]
  __int128 v11; // [rsp+10h] [rbp-68h] BYREF
  void *v12; // [rsp+20h] [rbp-58h]
  __int128 v13; // [rsp+30h] [rbp-48h] BYREF
  void *ptr; // [rsp+40h] [rbp-38h]
  __int128 v15; // [rsp+50h] [rbp-28h]

  if ( RBX::Math::isNanInf(value) )
    return;
  timePosition_low = LODWORD(this->timePosition);
  timePosition = this->timePosition;
  *(float *)&timePosition_low = RBX::KeyframeSequence::getDuration((const RBX::KeyframeSequence *)this->keyframeSequence.px);
  v4 = a2;
  if ( *(float *)&timePosition_low > 0.0 )
  {
    if ( this->loopedOverridden )
    {
      if ( this->looped )
      {
LABEL_5:
        v15 = timePosition_low;
        v4 = COERCE_FLOAT(_mm_cmplt_ss((__m128)LODWORD(a2), (__m128)0LL).m128_u32[0] & timePosition_low)
           + fmodf(a2, *(float *)&timePosition_low);
        goto LABEL_8;
      }
    }
    else if ( *((_BYTE *)this->keyframeSequence.px + 140) )
    {
      goto LABEL_5;
    }
    v4 = fminf(*(float *)&timePosition_low, fmaxf(0.0, a2));
  }
LABEL_8:
  this->timePosition = v4;
  if ( timePosition != v4 )
  {
    pi = this->animator.pn.pi_;
    if ( pi )
    {
      use_count = pi->use_count_;
      while ( use_count )
      {
        v7 = use_count;
        use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
        if ( v7 == use_count )
        {
          px = this->animator.px;
          if ( px )
          {
            std::string::basic_string(&v11, (char *)this->animation.px + 128);
            ptr = v12;
            v13 = v11;
            v11 = 0;
            v12 = 0;
            RBX::Animator::replicateAnimationUpdate(
              (__int64)px,
              (__int64)&v13,
              1u,
              8u,
              0,
              this->weightTime,
              this->weightTarget,
              this->timeSpeed,
              a2);
            if ( (v13 & 1) != 0 )
              operator delete(ptr);
            if ( (v11 & 1) != 0 )
              operator delete(v12);
          }
          if ( !_InterlockedSub(&pi->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
            if ( !_InterlockedSub(&pi->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
          }
          return;
        }
      }
    }
  }
}


// Address: 0x1043270 | Name: _ZNK3RBX14AnimationTrack9getLoopedEv
bool __fastcall RBX::AnimationTrack::getLooped(const RBX::AnimationTrack *this)
{
  if ( this->loopedOverridden )
    return this->looped;
  else
    return *((_BYTE *)this->keyframeSequence.px + 140);
}


// Address: 0x10432a0 | Name: _ZN3RBX14AnimationTrack9setLoopedEb
void __fastcall RBX::AnimationTrack::setLooped(RBX::AnimationTrack *this, bool value)
{
  if ( !this->loopedOverridden || (value ^ this->looped) == 1 )
  {
    this->loopedOverridden = 1;
    this->looped = value;
    RBX::Instance::raisePropertyChanged(this, &stru_2A02008);
  }
}


// Address: 0x10432e0 | Name: _ZNK3RBX14AnimationTrack16getCurrentWeightEv
float __fastcall RBX::AnimationTrack::getCurrentWeight(const RBX::AnimationTrack *this)
{
  return this->weightCurrent;
}


// Address: 0x10432f0 | Name: _ZNK3RBX14AnimationTrack8getSpeedEv
float __fastcall RBX::AnimationTrack::getSpeed(const RBX::AnimationTrack *this)
{
  return this->timeSpeed;
}


// Address: 0x1043310 | Name: _ZNK3RBX14AnimationTrack11getPriorityEv
RBX::KeyframeSequence::Priority __fastcall RBX::AnimationTrack::getPriority(const RBX::AnimationTrack *this)
{
  if ( this->priorityOverridden )
    return this->priority;
  else
    return *((_DWORD *)this->keyframeSequence.px + 34);
}


// Address: 0x1043340 | Name: _ZN3RBX14AnimationTrack11setPriorityENS_16KeyframeSequence8PriorityE
void __fastcall RBX::AnimationTrack::setPriority(RBX::AnimationTrack *this, RBX::KeyframeSequence::Priority value)
{
  RBX::KeyframeSequence::Priority *p_priority; // rax
  RBX::KeyframeSequence::Priority v3; // eax
  boost::detail::sp_counted_base *pi; // rbx
  signed __int32 use_count; // eax
  signed __int32 v6; // ett

  if ( this->priorityOverridden )
    p_priority = &this->priority;
  else
    p_priority = (RBX::KeyframeSequence::Priority *)((char *)this->keyframeSequence.px + 136);
  v3 = *p_priority;
  this->priority = value;
  this->priorityOverridden = 1;
  if ( v3 != value )
  {
    pi = this->animator.pn.pi_;
    if ( pi )
    {
      use_count = pi->use_count_;
      while ( use_count )
      {
        v6 = use_count;
        use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
        if ( v6 == use_count )
        {
          if ( !_InterlockedSub(&pi->use_count_, 1u) )
          {
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
            if ( !_InterlockedSub(&pi->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
          }
          return;
        }
      }
    }
  }
}


// Address: 0x10433d0 | Name: _ZN3RBX14AnimationTrack22getMarkerReachedSignalERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE
RBX::Lua::EventInstance *__fastcall RBX::AnimationTrack::getMarkerReachedSignal(
        RBX::Lua::EventInstance *__return_ptr retstr,
        RBX::AnimationTrack *this,
        const std::string *markerName)
{
  unsigned __int64 v6; // rcx
  char *v7; // rax
  unsigned __int64 v8; // rcx
  __int64 v9; // r8
  unsigned __int64 v10; // rcx
  unsigned __int64 v11; // rdi
  unsigned __int64 v12; // rbx
  size_t v13; // rsi
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,boost::shared_ptr<rbx::signal<void (std::string)> > > >,const std::string,boost::shared_ptr<rbx::signal<void (std::string)> >,boost::hash<const std::string >,std::equal_to<const std::string > > >::iterator v14; // rax
  boost::shared_ptr<rbx::signal<void (std::string)> >::element_type *v15; // rcx
  boost::detail::sp_counted_base *v16; // rax
  boost::detail::sp_counted_base *v17; // rbx
  boost::detail::sp_if_not_array<rbx::signal<void (std::string)> >::type v18; // rax
  unsigned __int128 v19; // xmm0
  boost::detail::sp_counted_base *v20; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,boost::shared_ptr<rbx::signal<void (std::string)> > > >,const std::string,boost::shared_ptr<rbx::signal<void (std::string)> >,boost::hash<const std::string >,std::equal_to<const std::string > > >::value_type *v21; // rax
  boost::shared_ptr<rbx::signal<void (std::string)> > v22; // kr00_16
  boost::shared_ptr<RBX::Lua::EventSignalWrapperBase> v23; // kr10_16
  boost::weak_ptr<RBX::AnimationTrack> v24; // rax
  volatile signed __int32 *v25; // rbx
  signed __int32 v26; // eax
  boost::weak_ptr<RBX::Instance>::element_type *v27; // rbp
  signed __int32 v28; // ett
  boost::detail::sp_counted_base *v29; // rbx
  const RBX::Name *v30; // r14
  const RBX::Name *v31; // rax
  __int64 v32; // rdi
  boost::detail::sp_counted_base *v33; // rbx
  unsigned __int128 v35; // [rsp+0h] [rbp-78h] BYREF
  unsigned __int128 v36; // [rsp+10h] [rbp-68h] BYREF
  void *ptr; // [rsp+20h] [rbp-58h]
  __int128 v38; // [rsp+30h] [rbp-48h]

  v6 = *(unsigned __int8 *)markerName;
  if ( (v6 & 1) != 0 )
  {
    v7 = (char *)*((_QWORD *)markerName + 2);
    v8 = *((_QWORD *)markerName + 1);
  }
  else
  {
    v7 = (char *)markerName + 1;
    v8 = v6 >> 1;
  }
  if ( !v8 )
  {
    v10 = 0;
    goto LABEL_13;
  }
  v9 = v8 & 1;
  if ( v8 == 1 )
  {
    v10 = 0;
    if ( !v9 )
      goto LABEL_13;
LABEL_12:
    v10 ^= (v10 << 6) + 2654435769u + (v10 >> 2) + *v7;
    goto LABEL_13;
  }
  v11 = v9 - v8;
  v10 = 0;
  do
  {
    v12 = v10 ^ (*v7 + (v10 >> 2) + (v10 << 6) + 2654435769u);
    v10 = v12 ^ (v7[1] + (v12 >> 2) + (v12 << 6) + 2654435769u);
    v7 += 2;
    v11 += 2LL;
  }
  while ( v11 );
  if ( v9 )
    goto LABEL_12;
LABEL_13:
  v13 = 2147483649u
      * ((21
        * ((265 * ((~v10 + (v10 << 21)) ^ ((~v10 + (v10 << 21)) >> 24)))
         ^ ((265 * ((~v10 + (v10 << 21)) ^ ((~v10 + (v10 << 21)) >> 24))) >> 14)))
       ^ ((21
         * ((265 * ((~v10 + (v10 << 21)) ^ ((~v10 + (v10 << 21)) >> 24)))
          ^ ((265 * ((~v10 + (v10 << 21)) ^ ((~v10 + (v10 << 21)) >> 24))) >> 14))) >> 28));
  v14.node_ = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,boost::shared_ptr<rbx::signal<void ()(std::string)>>>>,std::string const,boost::shared_ptr<rbx::signal<void ()(std::string)>>,boost::hash<std::string const>,std::equal_to<std::string const>>>::find_node_impl<std::string,std::equal_to<std::string const>>(
                &this->markerReachedSignals.table_,
                v13,
                markerName,
                (const std::equal_to<const std::string > *)&this->markerReachedSignals.table_.funcs_[(unsigned __int8)this->markerReachedSignals.table_.current_]).node_;
  v35 = 0;
  if ( v14.node_ )
  {
    v15 = (boost::shared_ptr<rbx::signal<void (std::string)> >::element_type *)*((_QWORD *)&v14.node_->value_base_.data_.data_.align_
                                                                               + 3);
    v16 = (boost::detail::sp_counted_base *)*((_QWORD *)&v14.node_->value_base_.data_.data_.align_ + 4);
    if ( v16 )
    {
      _InterlockedAdd(&v16->use_count_, 1u);
      v17 = (boost::detail::sp_counted_base *)*((_QWORD *)&v35 + 1);
      *(_QWORD *)&v35 = v15;
      *((_QWORD *)&v35 + 1) = v16;
      if ( v17 )
      {
        if ( !_InterlockedSub(&v17->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
          if ( !_InterlockedSub(&v17->weak_count_, 1u) )
LABEL_18:
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 3))(v17);
        }
      }
    }
    else
    {
      v35 = (unsigned __int64)v15;
    }
  }
  else
  {
    v18 = boost::make_shared<rbx::signal<void ()(std::string)>>();
    v19 = v36;
    v36 = 0;
    v20 = (boost::detail::sp_counted_base *)*((_QWORD *)&v35 + 1);
    v35 = v19;
    if ( v20 )
    {
      if ( !_InterlockedSub(&v20->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *, size_t, boost::detail::sp_counted_base *))v20->_vptr$sp_counted_base
         + 2))(
          v20,
          v13,
          v18.pn.pi_);
        if ( !_InterlockedSub(&v20->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v20->_vptr$sp_counted_base + 3))(v20);
      }
    }
    if ( *((_QWORD *)&v36 + 1) )
    {
      if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v36 + 1) + 8LL), 1u) )
      {
        (*(void (__fastcall **)(_QWORD, size_t, boost::detail::sp_counted_base *))(**((_QWORD **)&v36 + 1) + 16LL))(
          *((_QWORD *)&v36 + 1),
          v13,
          v18.pn.pi_);
        if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v36 + 1) + 12LL), 1u) )
          (*(void (__fastcall **)(_QWORD))(**((_QWORD **)&v36 + 1) + 24LL))(*((_QWORD *)&v36 + 1));
      }
    }
    v21 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,boost::shared_ptr<rbx::signal<void ()(std::string)>>>>,std::string const,boost::shared_ptr<rbx::signal<void ()(std::string)>>,boost::hash<std::string const>,std::equal_to<std::string const>>>::operator[](
            &this->markerReachedSignals.table_,
            markerName);
    v22 = (boost::shared_ptr<rbx::signal<void (std::string)> >)v35;
    if ( *((_QWORD *)&v35 + 1) )
      _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v35 + 1) + 8LL), 1u);
    *((_QWORD *)v21 + 3) = v35;
    v17 = (boost::detail::sp_counted_base *)*((_QWORD *)v21 + 4);
    *((_QWORD *)v21 + 4) = v22.pn.pi_;
    if ( v17 )
    {
      if ( !_InterlockedSub(&v17->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v17->_vptr$sp_counted_base + 2))(v17);
        if ( !_InterlockedSub(&v17->weak_count_, 1u) )
          goto LABEL_18;
      }
    }
  }
  boost::make_shared<RBX::Lua::EventSignalWrapper<void ()(std::string),rbx::signal<void ()(std::string)>>,boost::shared_ptr<rbx::signal<void ()(std::string)>> &>((boost::shared_ptr<rbx::signal<void (std::string)> > *)&v35);
  v23 = (boost::shared_ptr<RBX::Lua::EventSignalWrapperBase>)v36;
  if ( *((_QWORD *)&v36 + 1) )
    _InterlockedAdd((volatile signed __int32 *)(*((_QWORD *)&v36 + 1) + 8LL), 1u);
  v24 = RBX::weak_from<RBX::AnimationTrack>(this);
  v25 = (volatile signed __int32 *)*((_QWORD *)&v38 + 1);
  if ( *((_QWORD *)&v38 + 1) )
  {
    v26 = *(_DWORD *)(*((_QWORD *)&v38 + 1) + 8LL);
    v27 = 0;
    while ( v26 )
    {
      v28 = v26;
      v26 = _InterlockedCompareExchange(v25 + 2, v26 + 1, v26);
      if ( v28 == v26 )
      {
        v27 = (boost::weak_ptr<RBX::Instance>::element_type *)v38;
        if ( !_InterlockedSub(v25 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *, RBX::AnimationTrack *, boost::detail::sp_counted_base *))(*(_QWORD *)v25 + 16LL))(
            v25,
            this,
            v24.pn.pi_);
          if ( !_InterlockedSub(v25 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 24LL))(v25);
        }
        break;
      }
    }
  }
  else
  {
    v27 = 0;
  }
  v29 = (boost::detail::sp_counted_base *)*((_QWORD *)&v38 + 1);
  v38 = 0;
  std::operator+<char>((__int64)&v36, (unsigned __int8 *)markerName, "Reached");
  v30 = RBX::Name::declare((const std::string *)&v36);
  v31 = qword_2A025F8;
  if ( !qword_2A025F8 )
  {
    v31 = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr((RBX::AnimationTrack *)&v36) + 1);
    qword_2A025F8 = v31;
  }
  retstr->descriptor = 0;
  retstr->signalWrapper = v23;
  if ( v23.pn.pi_ )
    _InterlockedAdd(&v23.pn.pi_->use_count_, 1u);
  retstr->source.px = v27;
  retstr->source.pn.pi_ = v29;
  if ( v29 )
    _InterlockedAdd(&v29->weak_count_, 1u);
  retstr->eventInfo.eventName = v30;
  retstr->eventInfo.ownerClassName = v31;
  retstr->eventInfo.isScriptable = 1;
  retstr->eventInfo.security = RBX::Security::Permissions::None;
  if ( (v36 & 1) != 0 )
    operator delete(ptr);
  if ( v29 && !_InterlockedSub(&v29->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v29->_vptr$sp_counted_base + 3))(v29);
  v32 = *((_QWORD *)&v38 + 1);
  if ( *((_QWORD *)&v38 + 1) && !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v38 + 1) + 12LL), 1u) )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v32 + 24LL))(v32);
  if ( v23.pn.pi_ )
  {
    if ( !_InterlockedSub(&v23.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v23.pn.pi_->_vptr$sp_counted_base + 2))(v23.pn.pi_);
      if ( !_InterlockedSub(&v23.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v23.pn.pi_->_vptr$sp_counted_base + 3))(v23.pn.pi_);
    }
    if ( !_InterlockedSub(&v23.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v23.pn.pi_->_vptr$sp_counted_base + 2))(v23.pn.pi_);
      if ( !_InterlockedSub(&v23.pn.pi_->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v23.pn.pi_->_vptr$sp_counted_base + 3))(v23.pn.pi_);
    }
  }
  v33 = (boost::detail::sp_counted_base *)*((_QWORD *)&v35 + 1);
  if ( *((_QWORD *)&v35 + 1) )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v35 + 1) + 8LL), 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v33->_vptr$sp_counted_base + 2))(v33);
      if ( !_InterlockedSub(&v33->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v33->_vptr$sp_counted_base + 3))(v33);
    }
  }
  return retstr;
}


// Address: 0x1043970 | Name: _ZN3RBX14AnimationTrackC2EN5boost8weak_ptrINS_8AnimatorEEENS1_10shared_ptrINS_9AnimationEEENS5_IKNS_16KeyframeSequenceEEE
void __fastcall RBX::AnimationTrack::AnimationTrack(
        RBX::AnimationTrack *this,
        boost::weak_ptr<RBX::Animator> animator,
        boost::shared_ptr<RBX::Animation> animation)
{
  boost::shared_ptr<RBX::Animation>::element_type *px; // r14
  boost::detail::sp_counted_base *pi; // r15
  boost::detail::sp_counted_base *v5; // rax
  boost::detail::sp_counted_base *v6; // rax
  boost::detail::sp_counted_base *v7; // rax
  char v8; // [rsp+0h] [rbp-38h] BYREF
  char v9[15]; // [rsp+1h] [rbp-37h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  px = animation.px;
  pi = animator.pn.pi_;
  RBX::Instance::Instance(this);
  this->_vptr$EventSource = (int (**)(void))&off_288E428;
  this->descriptor = Class_getDescriptorPtr(this);
  this->_vptr$EventSource = (int (**)(void))off_288D9A0;
  *(_OWORD *)&this->keyframeReachedSignal.head.px = 0;
  this->didLoopSignal.head.px = 0;
  this->animator.px = *(boost::weak_ptr<RBX::Animator>::element_type **)animator.px;
  v5 = (boost::detail::sp_counted_base *)*((_QWORD *)animator.px + 1);
  this->animator.pn.pi_ = v5;
  if ( v5 )
    _InterlockedAdd(&v5->weak_count_, 1u);
  this->animation.px = pi->_vptr$sp_counted_base;
  v6 = *(boost::detail::sp_counted_base **)&pi->use_count_;
  this->animation.pn.pi_ = v6;
  if ( v6 )
    _InterlockedAdd(&v6->use_count_, 1u);
  this->keyframeSequence.px = *(boost::shared_ptr<const RBX::KeyframeSequence>::element_type **)px;
  v7 = (boost::detail::sp_counted_base *)*((_QWORD *)px + 1);
  this->keyframeSequence.pn.pi_ = v7;
  if ( v7 )
    _InterlockedAdd(&v7->use_count_, 1u);
  this->markerReachedSignals.table_.current_ = 0;
  *(_OWORD *)&this->markerReachedSignals.table_.bucket_count_ = 0x10u;
  this->markerReachedSignals.table_.mlf_ = 1.0;
  *(_OWORD *)&this->markerReachedSignals.table_.max_load_ = 0;
  this->timePosition = 0.0;
  *(_OWORD *)&this->timeSpeed = 0x3F800000u;
  *(_QWORD *)&this->priority = 1000;
  ptr = 0;
  v8 = 28;
  strcpy(v9, "AnimationTrack");
  (*((void (__fastcall **)(RBX::AnimationTrack *, char *))this->_vptr$EventSource + 14))(this, &v8);
  if ( (v8 & 1) != 0 )
    operator delete(ptr);
  this->isParentLocked = 1;
}


// Address: 0x1043bc0 | Name: _ZN3RBX14AnimationTrackD2Ev
void __fastcall RBX::AnimationTrack::~AnimationTrack(RBX::AnimationTrack *this)
{
  boost::detail::sp_counted_base *pi; // r14
  boost::detail::sp_counted_base *v3; // r14
  boost::detail::sp_counted_base *v4; // rdi

  this->_vptr$EventSource = (int (**)(void))off_288D9A0;
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<std::string const,boost::shared_ptr<rbx::signal<void ()(std::string)>>>>,std::string const,boost::shared_ptr<rbx::signal<void ()(std::string)>>,boost::hash<std::string const>,std::equal_to<std::string const>>>::~table(&this->markerReachedSignals.table_);
  pi = this->keyframeSequence.pn.pi_;
  if ( pi )
  {
    if ( !_InterlockedSub(&pi->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
      if ( !_InterlockedSub(&pi->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
    }
  }
  v3 = this->animation.pn.pi_;
  if ( v3 )
  {
    if ( !_InterlockedSub(&v3->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v3->_vptr$sp_counted_base + 2))(v3);
      if ( !_InterlockedSub(&v3->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v3->_vptr$sp_counted_base + 3))(v3);
    }
  }
  v4 = this->animator.pn.pi_;
  if ( v4 && !_InterlockedSub(&v4->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v4->_vptr$sp_counted_base + 3))(v4);
  rbx::signals::signal_base::~signal_base(&this->didLoopSignal);
  rbx::signals::signal_base::~signal_base(&this->stoppedSignal);
  rbx::signals::signal_base::~signal_base(&this->keyframeReachedSignal);
  RBX::Instance::~Instance(this);
}


// Address: 0x1043ca0 | Name: _ZN3RBX14AnimationTrackD0Ev
void __fastcall RBX::AnimationTrack::~AnimationTrack(RBX::AnimationTrack *this)
{
  RBX::AnimationTrack::~AnimationTrack(this);
  operator delete(this);
}


// Address: 0x1043cc0 | Name: _ZN3RBX14AnimationTrack4stepERNSt3__16vectorINS_9JointDataENS1_9allocatorIS3_EEEERNS2_INS_10CachedPoseENS4_IS8_EEEEdff
void __fastcall RBX::AnimationTrack::step(
        RBX::AnimationTrack *this,
        std::vector<RBX::JointData> *joints,
        std::vector<RBX::CachedPose> *poses,
        double time,
        float dt,
        float rootTranslationScale)
{
  __int128 timePosition_low; // xmm0
  const RBX::KeyframeSequence::Cache *CachedData; // rax
  float v9; // xmm1_4
  float weightTime; // xmm0_4
  float *v11; // rcx
  float v12; // eax
  float weightTarget; // xmm1_4
  float Duration; // xmm0_4
  bool v15; // bp
  float v16; // xmm0_4
  float timePosition; // xmm1_4
  const RBX::KeyframeSequence::Cache *v18; // rax
  __int64 v19; // rcx
  __int64 v20; // rax
  size_t v21; // rsi
  bool isPlaying; // r14
  float x; // [rsp+8h] [rbp-50h]
  float v25; // [rsp+18h] [rbp-40h] BYREF
  int v26; // [rsp+1Ch] [rbp-3Ch] BYREF
  __int128 v27; // [rsp+20h] [rbp-38h]

  if ( RBX::Math::isNanInf(dt)
    || RBX::Math::isNanInf(dt)
    || RBX::Math::isNanInf(dt)
    || RBX::Math::isNanInf(dt)
    || RBX::Math::isNanInf(dt) )
  {
    return;
  }
  timePosition_low = LODWORD(this->timePosition);
  x = (float)(this->timeSpeed * dt) + *(float *)&timePosition_low;
  if ( !stru_2A03600.value
    || (CachedData = RBX::KeyframeSequence::getCachedData((const RBX::KeyframeSequence *)this->keyframeSequence.px),
        *((_QWORD *)CachedData + 11) != *((_QWORD *)CachedData + 12)) )
  {
    *(float *)&timePosition_low = RBX::KeyframeSequence::getDuration((const RBX::KeyframeSequence *)this->keyframeSequence.px);
    v9 = x;
    if ( *(float *)&timePosition_low > 0.0 )
    {
      if ( this->loopedOverridden )
      {
        if ( !this->looped )
          goto LABEL_14;
      }
      else if ( !*((_BYTE *)this->keyframeSequence.px + 140) )
      {
LABEL_14:
        v9 = fminf(*(float *)&timePosition_low, fmaxf(0.0, x));
        goto LABEL_15;
      }
      v27 = timePosition_low;
      v9 = COERCE_FLOAT(_mm_cmplt_ss((__m128)LODWORD(x), (__m128)0LL).m128_u32[0] & timePosition_low)
         + fmodf(x, *(float *)&timePosition_low);
    }
LABEL_15:
    this->timePosition = v9;
  }
  weightTime = this->weightTime;
  v11 = (float *)&v26;
  if ( (float)(weightTime - dt) > 0.0 )
    v11 = &v25;
  v26 = 0;
  v25 = weightTime - dt;
  v12 = *v11;
  this->weightTime = *v11;
  weightTarget = this->weightTarget;
  if ( v12 > 0.0 )
    weightTarget = weightTarget + (float)((float)(this->weightCurrent - weightTarget) * (float)(v12 / weightTime));
  this->weightCurrent = weightTarget;
  RBX::KeyframeSequence::apply(
    (const RBX::KeyframeSequence *)this->keyframeSequence.px,
    joints,
    poses,
    this->timePosition,
    weightTarget,
    rootTranslationScale);
  if ( this->isPlaying )
  {
    Duration = RBX::KeyframeSequence::getDuration((const RBX::KeyframeSequence *)this->keyframeSequence.px);
    if ( Duration <= 0.0 )
    {
      v15 = 0;
    }
    else
    {
      rootTranslationScale = x;
      v15 = x > Duration || x < 0.0;
    }
    RBX::AnimationTrack::detectKeyframeReached(this, this->timePosition, rootTranslationScale);
    if ( this->loopedOverridden )
    {
      if ( this->looped )
        goto LABEL_40;
    }
    else if ( *((_BYTE *)this->keyframeSequence.px + 140) )
    {
      goto LABEL_40;
    }
    v16 = RBX::KeyframeSequence::getDuration((const RBX::KeyframeSequence *)this->keyframeSequence.px);
    if ( v16 > 0.0 )
    {
      timePosition = this->timePosition;
      if ( this->timeSpeed >= 0.0 )
      {
        if ( timePosition < v16 )
          goto LABEL_40;
      }
      else if ( timePosition > 0.0 )
      {
        goto LABEL_40;
      }
      v18 = RBX::KeyframeSequence::getCachedData((const RBX::KeyframeSequence *)this->keyframeSequence.px);
      v19 = *((_QWORD *)v18 + 11);
      v20 = *((_QWORD *)v18 + 12);
      if ( v19 != v20 )
      {
        if ( this->timeSpeed >= 0.0 )
          v21 = 0x4EC4EC4EC4EC4EC5LL * ((v20 - v19) >> 3) - 1;
        else
          v21 = 0;
        RBX::AnimationTrack::triggerKeyframeReached(this, v21);
      }
      isPlaying = this->isPlaying;
      *(_QWORD *)&this->weightTarget = 0x3E99999A00000000LL;
      this->isPlaying = 0;
      rbx::signal<void ()(void)>::operator()(&this->stoppedSignal);
      if ( isPlaying )
        RBX::Instance::raisePropertyChanged(this, &stru_2A01F58);
    }
LABEL_40:
    if ( v15 )
      rbx::signal<void ()(void)>::operator()(&this->didLoopSignal);
  }
}


// Address: 0x1044030 | Name: _ZNK3RBX14AnimationTrack17clampKeyframeTimeEf
float __fastcall RBX::AnimationTrack::clampKeyframeTime(const RBX::AnimationTrack *this, __m128 a2, float keyframeTime)
{
  float Duration; // xmm0_4
  bool *p_looped; // rbx

  Duration = RBX::KeyframeSequence::getDuration((const RBX::KeyframeSequence *)this->keyframeSequence.px);
  if ( Duration <= 0.0 )
    return a2.m128_f32[0];
  if ( this->loopedOverridden )
    p_looped = &this->looped;
  else
    p_looped = (bool *)this->keyframeSequence.px + 140;
  if ( *p_looped )
    return COERCE_FLOAT(_mm_cmplt_ss(a2, (__m128)0LL).m128_u32[0] & LODWORD(Duration)) + fmodf(a2.m128_f32[0], Duration);
  else
    return fminf(Duration, fmaxf(0.0, a2.m128_f32[0]));
}


// Address: 0x10440d0 | Name: _ZN3RBX14AnimationTrack21detectKeyframeReachedEff
void __fastcall RBX::AnimationTrack::detectKeyframeReached(
        RBX::AnimationTrack *this,
        float a2,
        float fromPosition,
        float toPosition)
{
  const RBX::KeyframeSequence::Cache *CachedData; // r15
  __int64 v5; // rcx
  __int64 v6; // rax
  bool *p_looped; // rdx
  bool v8; // bp
  unsigned __int64 v9; // r12
  size_t LastKeyframeBeforeOrAt; // rbx
  size_t v11; // rax
  size_t v12; // r15
  size_t FirstKeyframeAfterOrAt; // rbx
  size_t v14; // rax
  unsigned __int64 v15; // r15
  unsigned __int64 v16; // rcx
  unsigned __int64 v17; // rcx

  CachedData = RBX::KeyframeSequence::getCachedData((const RBX::KeyframeSequence *)this->keyframeSequence.px);
  v5 = *((_QWORD *)CachedData + 11);
  v6 = *((_QWORD *)CachedData + 12);
  if ( v5 == v6 )
    return;
  if ( this->loopedOverridden )
    p_looped = &this->looped;
  else
    p_looped = (bool *)this->keyframeSequence.px + 140;
  v8 = *p_looped;
  v9 = 0x4EC4EC4EC4EC4EC5LL * ((v6 - v5) >> 3);
  if ( this->timeSpeed >= 0.0 )
  {
    FirstKeyframeAfterOrAt = RBX::KeyframeSequence::Cache::findFirstKeyframeAfterOrAt(CachedData, 0.0);
    v14 = RBX::KeyframeSequence::Cache::findFirstKeyframeAfterOrAt(CachedData, 0.0);
    v15 = v14;
    if ( stru_2A01C38.value )
    {
      if ( v8 && (v14 < FirstKeyframeAfterOrAt || a2 > fromPosition && v14 == FirstKeyframeAfterOrAt) )
        v15 = v9 + v14;
      if ( FirstKeyframeAfterOrAt >= v15 )
        return;
    }
    else
    {
      v17 = 0;
      if ( v14 < FirstKeyframeAfterOrAt )
        v17 = v9;
      if ( !v8 )
        v17 = 0;
      v15 = v17 + v14;
      if ( FirstKeyframeAfterOrAt >= v17 + v14 )
        return;
    }
    do
    {
      RBX::AnimationTrack::triggerKeyframeReached(this, FirstKeyframeAfterOrAt % v9);
      ++FirstKeyframeAfterOrAt;
    }
    while ( v15 != FirstKeyframeAfterOrAt );
    return;
  }
  LastKeyframeBeforeOrAt = RBX::KeyframeSequence::Cache::findLastKeyframeBeforeOrAt(CachedData, 0.0);
  v11 = RBX::KeyframeSequence::Cache::findLastKeyframeBeforeOrAt(CachedData, 0.0);
  v12 = v11;
  if ( stru_2A01C38.value )
  {
    if ( !v8 || LastKeyframeBeforeOrAt >= v11 && (fromPosition <= a2 || LastKeyframeBeforeOrAt != v11) )
      goto LABEL_27;
    LastKeyframeBeforeOrAt += v9;
    if ( LastKeyframeBeforeOrAt <= v11 )
      return;
  }
  else
  {
    v16 = 0;
    if ( LastKeyframeBeforeOrAt < v11 )
      v16 = v9;
    if ( !v8 )
      v16 = 0;
    LastKeyframeBeforeOrAt += v16;
    if ( LastKeyframeBeforeOrAt <= v11 )
      return;
  }
  do
  {
    RBX::AnimationTrack::triggerKeyframeReached(this, LastKeyframeBeforeOrAt % v9);
    --LastKeyframeBeforeOrAt;
LABEL_27:
    ;
  }
  while ( LastKeyframeBeforeOrAt > v12 );
}


// Address: 0x10442a0 | Name: _ZN3RBX14AnimationTrack25triggerKeyframeReachedEndEv
void __fastcall RBX::AnimationTrack::triggerKeyframeReachedEnd(RBX::AnimationTrack *this)
{
  const RBX::KeyframeSequence::Cache *CachedData; // rax
  __int64 v2; // rcx
  __int64 v3; // rax
  size_t v4; // rsi

  CachedData = RBX::KeyframeSequence::getCachedData((const RBX::KeyframeSequence *)this->keyframeSequence.px);
  v2 = *((_QWORD *)CachedData + 11);
  v3 = *((_QWORD *)CachedData + 12);
  if ( v2 != v3 )
  {
    if ( this->timeSpeed >= 0.0 )
      v4 = 0x4EC4EC4EC4EC4EC5LL * ((v3 - v2) >> 3) - 1;
    else
      v4 = 0;
    RBX::AnimationTrack::triggerKeyframeReached(this, v4);
  }
}


// Address: 0x1044300 | Name: _ZN3RBX14AnimationTrack9localStopEf
void __fastcall RBX::AnimationTrack::localStop(RBX::AnimationTrack *this, float a2, float fadeTime)
{
  bool isPlaying; // bp

  isPlaying = this->isPlaying;
  this->weightTarget = 0.0;
  this->weightTime = a2;
  this->isPlaying = 0;
  rbx::signal<void ()(void)>::operator()(&this->stoppedSignal);
  if ( isPlaying )
    RBX::Instance::raisePropertyChanged(this, &stru_2A01F58);
}


// Address: 0x1044360 | Name: _ZN3RBX14AnimationTrack9localPlayEfff
void __fastcall RBX::AnimationTrack::localPlay(
        RBX::AnimationTrack *this,
        double a2,
        double fadeTime,
        double weight,
        double speed)
{
  bool isPlaying; // bp
  boost::detail::sp_counted_base *pi; // rbx
  signed __int32 use_count; // eax
  signed __int32 v8; // ett
  RBX::Animator *px; // r15
  boost::shared_ptr<RBX::AnimationTrack> v10; // rax
  boost::detail::sp_counted_base *v11; // r15
  float v12; // [rsp+14h] [rbp-34h]
  boost::shared_ptr<RBX::AnimationTrack> animationTrack; // [rsp+18h] [rbp-30h] BYREF

  v12 = *(float *)&a2;
  isPlaying = this->isPlaying;
  pi = this->animator.pn.pi_;
  if ( pi )
  {
    use_count = pi->use_count_;
    while ( use_count )
    {
      v8 = use_count;
      use_count = _InterlockedCompareExchange(&pi->use_count_, use_count + 1, use_count);
      if ( v8 == use_count )
      {
        px = (RBX::Animator *)this->animator.px;
        if ( px )
        {
          v10 = RBX::shared_from<RBX::AnimationTrack>(this);
          RBX::Animator::reloadAnimation(
            px,
            (boost::shared_ptr<RBX::AnimationTrack>)__PAIR128__((unsigned __int64)v10.pn.pi_, &animationTrack));
          v11 = animationTrack.pn.pi_;
          *(_QWORD *)&weight = LODWORD(weight);
          if ( animationTrack.pn.pi_ )
          {
            if ( !_InterlockedSub(&animationTrack.pn.pi_->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *, double, double, float, double))v11->_vptr$sp_counted_base
               + 2))(
                v11,
                a2,
                fadeTime,
                *(float *)&weight,
                speed);
              *(_QWORD *)&weight = LODWORD(weight);
              if ( !_InterlockedSub(&v11->weak_count_, 1u) )
              {
                (*((void (__fastcall **)(boost::detail::sp_counted_base *, double, double, float))v11->_vptr$sp_counted_base
                 + 3))(
                  v11,
                  a2,
                  fadeTime,
                  *(float *)&weight);
                *(_QWORD *)&weight = LODWORD(weight);
              }
            }
          }
        }
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *, double, double, double, double))pi->_vptr$sp_counted_base
           + 2))(
            pi,
            a2,
            fadeTime,
            weight,
            speed);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *, double, double, float))pi->_vptr$sp_counted_base
             + 3))(
              pi,
              a2,
              fadeTime,
              *(float *)&weight);
        }
        break;
      }
    }
  }
  this->timePosition = 0.0;
  this->timeSpeed = *(float *)&weight;
  if ( *(float *)&weight < 0.0 && stru_2A01C38.value )
    this->timePosition = RBX::KeyframeSequence::getDuration((const RBX::KeyframeSequence *)this->keyframeSequence.px);
  this->weightTarget = *(float *)&fadeTime;
  this->weightTime = v12;
  this->isPlaying = 1;
  if ( !isPlaying )
    RBX::Instance::raisePropertyChanged(this, &stru_2A01F58);
}


// Address: 0x1044550 | Name: _ZN3RBX14AnimationTrack17localAdjustWeightEff
void __fastcall RBX::AnimationTrack::localAdjustWeight(
        RBX::AnimationTrack *this,
        float a2,
        float weight,
        float fadeTime)
{
  this->weightTarget = a2;
  this->weightTime = weight;
}


// Address: 0x1044570 | Name: _ZN3RBX14AnimationTrack16localAdjustSpeedEf
void __fastcall RBX::AnimationTrack::localAdjustSpeed(RBX::AnimationTrack *this, float a2, float value)
{
  this->timeSpeed = a2;
}


// Address: 0x1044580 | Name: _ZN3RBX14AnimationTrack20localSetTimePositionEf
void __fastcall RBX::AnimationTrack::localSetTimePosition(RBX::AnimationTrack *this, __m128 a2, float value)
{
  float Duration; // xmm2_4
  bool *p_looped; // rax
  float v5; // xmm2_4

  Duration = RBX::KeyframeSequence::getDuration((const RBX::KeyframeSequence *)this->keyframeSequence.px);
  if ( Duration <= 0.0 )
  {
    v5 = a2.m128_f32[0];
  }
  else
  {
    if ( this->loopedOverridden )
      p_looped = &this->looped;
    else
      p_looped = (bool *)this->keyframeSequence.px + 140;
    if ( *p_looped )
      v5 = COERCE_FLOAT(_mm_cmplt_ss(a2, (__m128)0LL).m128_u32[0] & LODWORD(Duration)) + fmodf(a2.m128_f32[0], Duration);
    else
      v5 = fminf(Duration, fmaxf(0.0, a2.m128_f32[0]));
  }
  this->timePosition = v5;
}


// Address: 0x1044620 | Name: _ZN3RBX14AnimationTrack16localSetPriorityENS_16KeyframeSequence8PriorityE
void __fastcall RBX::AnimationTrack::localSetPriority(RBX::AnimationTrack *this, RBX::KeyframeSequence::Priority value)
{
  this->priority = value;
  this->priorityOverridden = 1;
}


// Address: 0x1044640 | Name: _ZNK3RBX14AnimationTrack9isStoppedEv
bool __fastcall RBX::AnimationTrack::isStopped(const RBX::AnimationTrack *this)
{
  bool result; // al
  __m128 weightTarget_low; // xmm0
  __m128d v3; // xmm0
  unsigned __int64 v4; // [rsp+8h] [rbp-10h]
  double v5; // [rsp+10h] [rbp-8h]

  if ( this->weightTime > 0.0 )
    return 0;
  weightTarget_low = (__m128)LODWORD(this->weightTarget);
  result = 1;
  if ( weightTarget_low.m128_f32[0] != 0.0 )
  {
    v3 = (__m128d)_mm_and_ps(weightTarget_low, (__m128)xmmword_3E5B40);
    v5 = *(float *)v3.m128d_f64;
    *(double *)&v4 = *(float *)v3.m128d_f64 + 1.0;
    v3.m128d_f64[0] = G3D::inf();
    v3.m128d_f64[0] = _mm_cmpeq_sd(v3, (__m128d)v4).m128d_f64[0];
    return COERCE_DOUBLE(
             *(_QWORD *)&v3.m128d_f64[0] & 0x3EE4F8B580000000LL
           | ~*(_QWORD *)&v3.m128d_f64[0] & COERCE_UNSIGNED_INT64(*(double *)&v4 * 0.000009999999747378752)) >= v5;
  }
  return result;
}


// Address: 0x10446d0 | Name: _ZN3RBX14AnimationTrack22triggerKeyframeReachedEm
void __fastcall RBX::AnimationTrack::triggerKeyframeReached(RBX::AnimationTrack *this, size_t index)
{
  __int64 v2; // r13
  size_t v3; // rbp
  size_t v4; // rax
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // rcx
  __int64 v7; // rbx
  _QWORD *v8; // rbp
  _BYTE v9[16]; // [rsp+0h] [rbp-48h] BYREF
  void *ptr; // [rsp+10h] [rbp-38h]

  v2 = *((_QWORD *)RBX::KeyframeSequence::getCachedData((const RBX::KeyframeSequence *)this->keyframeSequence.px) + 11);
  v3 = 104 * index;
  v4 = strlen("Keyframe");
  v5 = *(unsigned __int8 *)(v2 + 104 * index + 8);
  if ( (v5 & 1) != 0 )
    v6 = *(_QWORD *)(v2 + v3 + 16);
  else
    v6 = v5 >> 1;
  if ( v4 != v6 || (unsigned int)std::string::compare(v2 + v3 + 8, 0, -1, "Keyframe", v4) )
  {
    std::string::basic_string(v9, v2 + v3 + 8);
    rbx::signal<void ()(std::string)>::operator()(&this->keyframeReachedSignal.head.px, (__int64)v9);
    if ( (v9[0] & 1) != 0 )
      operator delete(ptr);
  }
  if ( stru_2A03600.value )
  {
    v7 = *(_QWORD *)(v2 + v3 + 80);
    if ( v7 != *(_QWORD *)(v2 + v3 + 88) )
    {
      v8 = (_QWORD *)(v2 + v3 + 88);
      do
      {
        RBX::AnimationTrack::raiseMarkerReached(this, (const std::string *)v7, (const std::string *)(v7 + 24));
        v7 += 48;
      }
      while ( v7 != *v8 );
    }
  }
}


// Address: 0x10447f0 | Name: _ZN3RBX14AnimationTrack18raiseMarkerReachedERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_
void __fastcall RBX::AnimationTrack::raiseMarkerReached(
        RBX::AnimationTrack *this,
        const std::string *markerName,
        const std::string *value)
{
  unsigned __int64 v4; // rax
  char *v5; // r15
  unsigned __int64 v6; // rax
  __int64 v7; // r10
  unsigned __int64 v8; // rbx
  unsigned __int64 v9; // rdx
  unsigned __int64 v10; // rax
  unsigned __int64 v11; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const std::string,boost::shared_ptr<rbx::signal<void (std::string)> > > >,const std::string,boost::shared_ptr<rbx::signal<void (std::string)> >,boost::hash<const std::string >,std::equal_to<const std::string > > >::iterator v12; // rax
  rbx::signals::slot_base **v13; // rbx
  _BYTE v14[16]; // [rsp+8h] [rbp-30h] BYREF
  void *ptr; // [rsp+18h] [rbp-20h]

  v4 = *(unsigned __int8 *)markerName;
  if ( (v4 & 1) != 0 )
  {
    v5 = (char *)*((_QWORD *)markerName + 2);
    v6 = *((_QWORD *)markerName + 1);
  }
  else
  {
    v5 = (char *)markerName + 1;
    v6 = v4 >> 1;
  }
  if ( !v6 )
  {
    v8 = 0;
    goto LABEL_12;
  }
  v7 = v6 & 1;
  if ( v6 == 1 )
  {
    v8 = 0;
LABEL_11:
    v8 ^= (v8 << 6) + 2654435769u + (v8 >> 2) + *v5;
    goto LABEL_12;
  }
  v9 = v7 - v6;
  v8 = 0;
  do
  {
    v10 = v8 ^ (*v5 + (v8 >> 2) + (v8 << 6) + 2654435769u);
    v8 = v10 ^ (v5[1] + (v10 >> 2) + (v10 << 6) + 2654435769u);
    v5 += 2;
    v9 += 2LL;
  }
  while ( v9 );
  if ( v7 )
    goto LABEL_11;
LABEL_12:
  v11 = ~v8 + (v8 << 21);
  v12.node_ = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<std::string const,boost::shared_ptr<rbx::signal<void ()(std::string)>>>>,std::string const,boost::shared_ptr<rbx::signal<void ()(std::string)>>,boost::hash<std::string const>,std::equal_to<std::string const>>>::find_node_impl<std::string,std::equal_to<std::string const>>(
                &this->markerReachedSignals.table_,
                2147483649u
              * ((21 * ((265 * (v11 ^ (v11 >> 24))) ^ ((265 * (v11 ^ (v11 >> 24))) >> 14)))
               ^ ((21 * ((265 * (v11 ^ (v11 >> 24))) ^ ((265 * (v11 ^ (v11 >> 24))) >> 14))) >> 28)),
                markerName,
                (const std::equal_to<const std::string > *)&this->markerReachedSignals.table_.funcs_[(unsigned __int8)this->markerReachedSignals.table_.current_]).node_;
  if ( v12.node_ )
  {
    v13 = (rbx::signals::slot_base **)*((_QWORD *)&v12.node_->value_base_.data_.data_.align_ + 3);
    std::string::basic_string(v14, value);
    rbx::signal<void ()(std::string)>::operator()(v13, (__int64)v14);
    if ( (v14[0] & 1) != 0 )
      operator delete(ptr);
  }
}


// Address: 0x1044980 | Name: _Z22Class_getDescriptorPtrPN3RBX14AnimationTrackE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::AnimationTrack *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+21h] [rbp-27h]
  __int16 v5; // [rsp+25h] [rbp-23h]
  char v6; // [rsp+27h] [rbp-21h]
  unsigned __int64 v7; // [rsp+28h] [rbp-20h]
  __int64 v8; // [rsp+38h] [rbp-10h]

  result = qword_2A022B0;
  if ( !qword_2A022B0 )
  {
    if ( !(_BYTE)byte_2A025F0 )
    {
      if ( __cxa_guard_acquire(&byte_2A025F0) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A022B8,
          v2,
          "AnimationTrack",
          0,
          attributes,
          RBX::Security::Permissions::None,
          &dword_2A04350);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::AnimationTrack,false>::~ClassRegistrar,
          &unk_2A022B8,
          &dso_handle);
        __cxa_guard_release(&byte_2A025F0);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A022B8;
    qword_2A022B0 = (RBX::Reflection::ClassDescriptor *)&unk_2A022B8;
  }
  return result;
}


// Address: 0x1044a70 | Name: _Z16Class_getNamePtrPN3RBX14AnimationTrackE
const RBX::Name *__fastcall Class_getNamePtr(RBX::AnimationTrack *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A025F8;
  if ( !qword_2A025F8 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A025F8 = result;
  }
  return result;
}


// Address: 0x1048d30 | Name: _GLOBAL__sub_I_AnimationTrack.cpp
void __cdecl GLOBAL__sub_I_AnimationTrack_cpp()
{
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // r14
  char *v1; // rbx
  const RBX::Reflection::Type *v2; // rax
  RBX::Reflection::ClassDescriptor *v3; // r14
  char *v4; // rbx
  const RBX::Reflection::Type *v5; // rax
  RBX::Reflection::ClassDescriptor *v6; // r14
  char *v7; // rbx
  const RBX::Reflection::Type *v8; // rax
  RBX::Reflection::ClassDescriptor *v9; // rbx
  const RBX::Reflection::Type *v10; // rax
  char *v11; // rax
  __int64 v12; // r9
  RBX::Reflection::Descriptor::Attributes attributes; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesa; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesb; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesc; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesd; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributese; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesf; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesg; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesh; // [rsp+0h] [rbp-88h]
  RBX::Reflection::PropertyDescriptor::Attributes attributesi; // [rsp+0h] [rbp-88h]
  RBX::Reflection::Descriptor::Attributes attributes_8; // [rsp+8h] [rbp-80h]
  RBX::Reflection::Descriptor::Attributes v24; // [rsp+28h] [rbp-60h] BYREF
  __int64 v25; // [rsp+38h] [rbp-50h]
  RBX::Reflection::PropertyDescriptor::Attributes flags; // [rsp+40h] [rbp-48h]
  RBX::Reflection::Descriptor::Attributes v27; // 0:r8.1,8:r9.8
  RBX::Reflection::Descriptor::Attributes v28; // 0:r8.1,8:r9.8
  std::tuple<float,float,float> v29; // 0:xmm0_8.8,8:xmm1_4.4

  qword_2A01C08 = (__int64)boost::system::generic_category();
  qword_2A01C10 = (__int64)boost::system::generic_category();
  qword_2A01C18 = (__int64)boost::system::system_category();
  stru_2A01C20.value = 0;
  stru_2A01C20.name = "UserNoUpdateOnLoop";
  dword_2A01C30 = FLog::RegisterFlag("UserNoUpdateOnLoop", &stru_2A01C20, FastVarType::FASTVARTYPE_STATIC);
  stru_2A01C38.value = 0;
  stru_2A01C38.name = "FixKeyframeDetectionV2";
  dword_2A01C48 = FLog::RegisterFlag("FixKeyframeDetectionV2", &stru_2A01C38, FastVarType::FASTVARTYPE_STATIC);
  stru_2A01C50.value = 0;
  stru_2A01C50.name = "UserAnimateScriptEmoteHook";
  dword_2A01C60 = FLog::RegisterFlag("UserAnimateScriptEmoteHook", &stru_2A01C50, FastVarType::FASTVARTYPE_STATIC);
  v24.isDeprecated = 0;
  attributes_8.preferred = *(const RBX::Reflection::Descriptor **)&v24.isDeprecated;
  *(_DWORD *)&attributes_8.isDeprecated = 0;
  *(_QWORD *)&v29.__base_.__value_ = 0x3F8000003DCCCCCDLL;
  v29.__base_.__value_ = 1.0;
  RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,void ()(float,float,float),3>::BoundFuncDesc(
    (RBX::AnimationTrack *)&unk_2A01C68,
    (rbx::signals::slot_base *)RBX::AnimationTrack::play,
    0,
    "Play",
    "fadeTime",
    "weight",
    v29,
    "speed",
    attributes_8,
    0);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,void ()(float,float,float),3>::~BoundFuncDesc,
    &unk_2A01C68,
    &dso_handle);
  v24.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,void ()(float),1>::BoundFuncDesc(
    (RBX::AnimationTrack *)&unk_2A01CF8,
    (rbx::signals::slot_base *)RBX::AnimationTrack::stop,
    0,
    "Stop",
    (std::tuple<float>)1036831949,
    "fadeTime",
    RBX::Security::Permissions::None,
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,void ()(float),1>::~BoundFuncDesc,
    &unk_2A01CF8,
    &dso_handle);
  v24.isDeprecated = 0;
  attributes.preferred = *(const RBX::Reflection::Descriptor **)&v24.isDeprecated;
  *(_DWORD *)&attributes.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,void ()(float,float),2>::BoundFuncDesc(
    (RBX::AnimationTrack *)&unk_2A01D78,
    (rbx::signals::slot_base *)RBX::AnimationTrack::adjustWeight,
    0,
    "AdjustWeight",
    "weight",
    *(__m128i *)&stru_3E49A0.__base_.__value_,
    "fadeTime",
    attributes,
    0);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,void ()(float,float),2>::~BoundFuncDesc,
    &unk_2A01D78,
    &dso_handle);
  v24.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,void ()(float),1>::BoundFuncDesc(
    (RBX::AnimationTrack *)&unk_2A01E00,
    (rbx::signals::slot_base *)RBX::AnimationTrack::adjustSpeed,
    0,
    "AdjustSpeed",
    (std::tuple<float>)1065353216,
    "speed",
    RBX::Security::Permissions::None,
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,void ()(float),1>::~BoundFuncDesc,
    &unk_2A01E00,
    &dso_handle);
  v24.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,double ()(std::string),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,double (std::string),1> *)&unk_2A01E80,
    (RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,double (std::string),1>::FunctionPtr)RBX::AnimationTrack::getTimeOfKeyframe,
    0,
    "GetTimeOfKeyframe",
    (RBX::Security::Permissions)"keyframeName",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,double ()(std::string),1>::~BoundFuncDesc,
    &unk_2A01E80,
    &dso_handle);
  v24.isDeprecated = 0;
  LODWORD(v25) = 19;
  *(_QWORD *)&attributesa.flags = v25;
  attributesa.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated;
  RBX::Reflection::PropDescriptor<RBX::AnimationTrack,float>::PropDescriptor<float (RBX::AnimationTrack::*)(void)const,long>(
    &stru_2A01F00,
    "Length",
    &stru_458781.gap0,
    (int (**)(void))RBX::AnimationTrack::getLength,
    0,
    RBX::Security::Permissions::None,
    attributesa,
    RBX::Security::Permissions::None);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A01F00,
    &dso_handle);
  DescriptorPtr = Class_getDescriptorPtr((RBX::AnimationTrack *)RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor);
  v1 = (char *)operator new(0x18u);
  *(_QWORD *)v1 = &off_288E0C8;
  *(_OWORD *)(v1 + 8) = (unsigned __int64)RBX::AnimationTrack::getIsPlaying;
  v24.isDeprecated = 0;
  v24.preferred = 0;
  LODWORD(v25) = 19;
  v2 = RBX::Reflection::Type::getSingleton<bool>();
  *(_QWORD *)&attributesb.flags = v25;
  attributesb.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v24);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A01F58,
    DescriptorPtr,
    v2,
    "IsPlaying",
    &stru_458781.gap0,
    attributesb,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A01F58._vptr$Descriptor = (int (**)(void))&off_2882CC8;
  qword_2A01FA8 = (__int64)v1;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v1 + 24LL))(v1) )
    *((_BYTE *)&stru_2A01F58.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A01F58._vptr$Descriptor + 3))(&stru_2A01F58) )
    *((_BYTE *)&stru_2A01F58.security + 4) &= 0xF3u;
  stru_2A01F58._vptr$Descriptor = (int (**)(void))&off_288E008;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<bool>::~TypedPropertyDescriptor,
    &stru_2A01F58,
    &dso_handle);
  v3 = Class_getDescriptorPtr((RBX::AnimationTrack *)RBX::Reflection::TypedPropertyDescriptor<bool>::~TypedPropertyDescriptor);
  v4 = (char *)operator new(0x28u);
  *(_QWORD *)v4 = &off_288E128;
  *(_OWORD *)(v4 + 8) = (unsigned __int64)RBX::AnimationTrack::getTimePosition;
  *(_OWORD *)(v4 + 24) = (unsigned __int64)RBX::AnimationTrack::setTimePosition;
  v24.isDeprecated = 0;
  v24.preferred = 0;
  LODWORD(v25) = 21;
  v5 = RBX::Reflection::Type::getSingleton<float>();
  *(_QWORD *)&attributesc.flags = v25;
  attributesc.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v24);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A01FB0,
    v3,
    v5,
    "TimePosition",
    &stru_458781.gap0,
    attributesc,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A01FB0._vptr$Descriptor = (int (**)(void))&off_2882B48;
  qword_2A02000 = (__int64)v4;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v4 + 24LL))(v4) )
    *((_BYTE *)&stru_2A01FB0.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A01FB0._vptr$Descriptor + 3))(&stru_2A01FB0) )
    *((_BYTE *)&stru_2A01FB0.security + 4) &= 0xF3u;
  stru_2A01FB0._vptr$Descriptor = (int (**)(void))&off_288DEE8;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A01FB0,
    &dso_handle);
  v6 = Class_getDescriptorPtr((RBX::AnimationTrack *)RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor);
  v7 = (char *)operator new(0x28u);
  *(_QWORD *)v7 = &off_288E188;
  *(_OWORD *)(v7 + 8) = (unsigned __int64)RBX::AnimationTrack::getLooped;
  *(_OWORD *)(v7 + 24) = (unsigned __int64)RBX::AnimationTrack::setLooped;
  v24.isDeprecated = 0;
  v24.preferred = 0;
  LODWORD(v25) = 19;
  v8 = RBX::Reflection::Type::getSingleton<bool>();
  *(_QWORD *)&attributesd.flags = v25;
  attributesd.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v24);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A02008,
    v6,
    v8,
    "Looped",
    &stru_458781.gap0,
    attributesd,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A02008._vptr$Descriptor = (int (**)(void))&off_2882CC8;
  qword_2A02058 = (__int64)v7;
  if ( (*(unsigned __int8 (__fastcall **)(char *))(*(_QWORD *)v7 + 24LL))(v7) )
    *((_BYTE *)&stru_2A02008.security + 4) &= 0xEBu;
  if ( (*((unsigned __int8 (__fastcall **)(RBX::Reflection::PropertyDescriptor *))stru_2A02008._vptr$Descriptor + 3))(&stru_2A02008) )
    *((_BYTE *)&stru_2A02008.security + 4) &= 0xF3u;
  stru_2A02008._vptr$Descriptor = (int (**)(void))&off_288E008;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<bool>::~TypedPropertyDescriptor,
    &stru_2A02008,
    &dso_handle);
  v24.isDeprecated = 0;
  v24.preferred = 0;
  LODWORD(v25) = 19;
  *(_QWORD *)&attributese.flags = v25;
  attributese.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated;
  RBX::Reflection::PropDescriptor<RBX::AnimationTrack,float>::PropDescriptor<float (RBX::AnimationTrack::*)(void)const,long>(
    &stru_2A02060,
    "WeightTarget",
    &stru_458781.gap0,
    (int (**)(void))RBX::AnimationTrack::getTargetWeight,
    0,
    RBX::Security::Permissions::None,
    attributese,
    RBX::Security::Permissions::None);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A02060,
    &dso_handle);
  v24.isDeprecated = 0;
  v24.preferred = 0;
  LODWORD(v25) = 19;
  *(_QWORD *)&attributesf.flags = v25;
  attributesf.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated;
  RBX::Reflection::PropDescriptor<RBX::AnimationTrack,float>::PropDescriptor<float (RBX::AnimationTrack::*)(void)const,long>(
    &stru_2A020B8,
    "WeightCurrent",
    &stru_458781.gap0,
    (int (**)(void))RBX::AnimationTrack::getCurrentWeight,
    0,
    RBX::Security::Permissions::None,
    attributesf,
    RBX::Security::Permissions::None);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A020B8,
    &dso_handle);
  v24.isDeprecated = 0;
  v24.preferred = 0;
  LODWORD(v25) = 19;
  *(_QWORD *)&attributesg.flags = v25;
  attributesg.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated;
  RBX::Reflection::PropDescriptor<RBX::AnimationTrack,float>::PropDescriptor<float (RBX::AnimationTrack::*)(void)const,long>(
    &stru_2A02110,
    "Speed",
    &stru_458781.gap0,
    (int (**)(void))RBX::AnimationTrack::getSpeed,
    0,
    RBX::Security::Permissions::None,
    attributesg,
    RBX::Security::Permissions::None);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor,
    &stru_2A02110,
    &dso_handle);
  v24.isDeprecated = 0;
  v24.preferred = 0;
  LODWORD(v25) = 19;
  v9 = Class_getDescriptorPtr((RBX::AnimationTrack *)RBX::Reflection::TypedPropertyDescriptor<float>::~TypedPropertyDescriptor);
  v10 = RBX::Reflection::RefType<RBX::Animation *>::singleton();
  *(_QWORD *)&attributesh.flags = v25;
  attributesh.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v24);
  RBX::Reflection::PropertyDescriptor::PropertyDescriptor(
    &stru_2A02168,
    v9,
    v10,
    "Animation",
    &stru_458781.gap0,
    attributesh,
    RBX::Security::Permissions::None,
    RBX::Security::Permissions::None,
    0);
  stru_2A02168._vptr$Descriptor = (int (**)(void))&off_288DC78;
  qword_2A021B8 = (__int64)&off_288DD38;
  v11 = (char *)operator new(0x18u);
  *(_QWORD *)v11 = &off_288E228;
  *(_OWORD *)(v11 + 8) = (unsigned __int64)RBX::AnimationTrack::getAnimation;
  qword_2A021C0 = (__int64)v11;
  *((_BYTE *)&stru_2A02168.security + 4) &= 0xF3u;
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::RefPropDescriptor<RBX::AnimationTrack,RBX::Animation>::~RefPropDescriptor,
    &stru_2A02168,
    &dso_handle);
  v24.isDeprecated = 0;
  v24.preferred = 0;
  LODWORD(v25) = 31;
  flags.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::AnimationTrack::setPriority;
  *(_QWORD *)&attributesi.flags = *(_QWORD *)&v24.isDeprecated;
  attributesi.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)(unsigned __int64)RBX::AnimationTrack::setPriority;
  RBX::Reflection::EnumPropDescriptor<RBX::AnimationTrack,RBX::KeyframeSequence::Priority>::EnumPropDescriptor<RBX::KeyframeSequence::Priority (RBX::AnimationTrack::*)(void)const,void (RBX::AnimationTrack::*)(RBX::KeyframeSequence::Priority)>(
    &stru_2A021C8,
    "Priority",
    &stru_458781.gap0,
    RBX::AnimationTrack::getPriority,
    0,
    RBX::Security::Permissions::None,
    attributesi,
    0,
    v25);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::EnumPropDescriptor<RBX::AnimationTrack,RBX::KeyframeSequence::Priority>::~EnumPropDescriptor,
    &stru_2A021C8,
    &dso_handle);
  v24.isDeprecated = 0;
  v24.preferred = 0;
  RBX::Reflection::EventDesc<RBX::AnimationTrack,void ()(std::string),rbx::signal<void ()(std::string)>,rbx::signal<void ()(std::string)> RBX::AnimationTrack::*>::EventDesc(
    (RBX::AnimationTrack *)&unk_2858720,
    (rbx::signal<void (std::string)> *)&inputbuff.encodingTable[5].bitLength,
    "KeyframeReached",
    "keyframeName",
    RBX::Security::Permissions::None,
    v12,
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated);
  __cxa_atexit((void (*)(void *))RBX::Reflection::EventDescriptor::~EventDescriptor, &unk_2858720, &dso_handle);
  v27.isDeprecated = 0;
  v27.preferred = 0;
  RBX::Reflection::EventDesc<RBX::AnimationTrack,void ()(void),rbx::signal<void ()(void)>,rbx::signal<void ()(void)> RBX::AnimationTrack::*>::EventDesc(
    (RBX::Reflection::EventDesc<RBX::AnimationTrack,void (),rbx::signal<void ()>,rbx::signal<void ()> RBX::AnimationTrack::*> *)&unk_2858788,
    (rbx::signal<void ()> *)&inputbuff.encodingTable[6],
    "Stopped",
    RBX::Security::Permissions::None,
    v27);
  __cxa_atexit((void (*)(void *))RBX::Reflection::EventDescriptor::~EventDescriptor, &unk_2858788, &dso_handle);
  v28.isDeprecated = 0;
  v28.preferred = 0;
  RBX::Reflection::EventDesc<RBX::AnimationTrack,void ()(void),rbx::signal<void ()(void)>,rbx::signal<void ()(void)> RBX::AnimationTrack::*>::EventDesc(
    (RBX::Reflection::EventDesc<RBX::AnimationTrack,void (),rbx::signal<void ()>,rbx::signal<void ()> RBX::AnimationTrack::*> *)&unk_28587F0,
    (rbx::signal<void ()> *)&inputbuff.encodingTable[6].bitLength,
    "DidLoop",
    RBX::Security::Permissions::None,
    v28);
  __cxa_atexit((void (*)(void *))RBX::Reflection::EventDescriptor::~EventDescriptor, &unk_28587F0, &dso_handle);
  v24.isDeprecated = 0;
  v24.preferred = 0;
  RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,RBX::Lua::EventInstance ()(std::string const&),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,RBX::Lua::EventInstance (const std::string &),1> *)&unk_2A02230,
    (RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,RBX::Lua::EventInstance (const std::string &),1>::FunctionPtr)RBX::AnimationTrack::getMarkerReachedSignal,
    0,
    "GetMarkerReachedSignal",
    (RBX::Security::Permissions)"name",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v24.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::AnimationTrack,RBX::Lua::EventInstance ()(std::string const&),1>::~BoundFuncDesc,
    &unk_2A02230,
    &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_0);
}


