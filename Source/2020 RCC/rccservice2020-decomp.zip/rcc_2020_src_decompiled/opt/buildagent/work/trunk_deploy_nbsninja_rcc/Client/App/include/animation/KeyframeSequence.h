// Address: 0x1050a40 | Name: _ZNK3RBX16KeyframeSequence7getLoopEv
bool __fastcall RBX::KeyframeSequence::getLoop(const RBX::KeyframeSequence *this)
{
  return this->loop;
}


// Address: 0x1050a50 | Name: _ZNK3RBX16KeyframeSequence11getPriorityEv
RBX::KeyframeSequence::Priority __fastcall RBX::KeyframeSequence::getPriority(const RBX::KeyframeSequence *this)
{
  return this->priority;
}


// Address: 0x1050bc0 | Name: _ZNK3RBX16KeyframeSequence20getAuthoredHipHeightEv
float __fastcall RBX::KeyframeSequence::getAuthoredHipHeight(const RBX::KeyframeSequence *this)
{
  return this->authoredHipHeight;
}


// Address: 0x1050bd0 | Name: _ZN3RBX16KeyframeSequence14CachedKeyframeD2Ev
void __fastcall RBX::KeyframeSequence::CachedKeyframe::~CachedKeyframe(RBX::KeyframeSequence::CachedKeyframe *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  __int64 v4; // r12
  void *v5; // rdi
  void *v6; // rdi
  void *v7; // rdi

  v2 = *((_QWORD *)this + 10);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 11);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 10);
    }
    else
    {
      do
      {
        if ( (*(_BYTE *)(v3 - 24) & 1) != 0 )
          operator delete(*(void **)(v3 - 8));
        v4 = v3 - 48;
        if ( (*(_BYTE *)(v3 - 48) & 1) != 0 )
          operator delete(*(void **)(v3 - 32));
        v3 -= 48;
      }
      while ( v2 != v4 );
      v5 = (void *)*((_QWORD *)this + 10);
    }
    *((_QWORD *)this + 11) = v2;
    operator delete(v5);
  }
  v6 = (void *)*((_QWORD *)this + 7);
  if ( v6 )
  {
    *((_QWORD *)this + 8) = v6;
    operator delete(v6);
  }
  v7 = (void *)*((_QWORD *)this + 4);
  if ( v7 )
  {
    *((_QWORD *)this + 5) = v7;
    operator delete(v7);
  }
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
    operator delete(*((void **)this + 3));
}


// Address: 0x1051340 | Name: _ZN3RBX16KeyframeSequenceD2Ev
void __fastcall RBX::KeyframeSequence::~KeyframeSequence(RBX::KeyframeSequence *this)
{
  RBX::KeyframeSequence::Cache *value; // r14

  this->_vptr$EventSource = (int (**)(void))off_288F630;
  value = this->cacheData.__ptr_.__value_;
  this->cacheData.__ptr_.__value_ = 0;
  if ( value )
  {
    RBX::KeyframeSequence::Cache::~Cache(value);
    operator delete(value);
  }
  RBX::Instance::~Instance(this);
}


// Address: 0x1051390 | Name: _ZN3RBX16KeyframeSequenceD0Ev
void __fastcall RBX::KeyframeSequence::~KeyframeSequence(RBX::KeyframeSequence *this)
{
  RBX::KeyframeSequence::Cache *value; // r14

  this->_vptr$EventSource = (int (**)(void))off_288F630;
  value = this->cacheData.__ptr_.__value_;
  this->cacheData.__ptr_.__value_ = 0;
  if ( value )
  {
    RBX::KeyframeSequence::Cache::~Cache(value);
    operator delete(value);
  }
  RBX::Instance::~Instance(this);
  operator delete(this);
}


// Address: 0x1051410 | Name: _ZNK3RBX16KeyframeSequence12askSetParentEPKNS_8InstanceE
bool __fastcall RBX::KeyframeSequence::askSetParent(const RBX::KeyframeSequence *this, const RBX::Instance *instance)
{
  return 0;
}


// Address: 0x1052370 | Name: _ZN3RBX16KeyframeSequence5CacheD2Ev
void __fastcall RBX::KeyframeSequence::Cache::~Cache(RBX::KeyframeSequence::Cache *this)
{
  RBX::KeyframeSequence::CachedKeyframe *v2; // r15
  RBX::KeyframeSequence::CachedKeyframe *v3; // rbx
  void *v4; // rdi
  void *v5; // rdi
  void *v6; // rdi
  __int64 v7; // r15
  __int64 v8; // rax
  __int64 v9; // rbx
  void *v10; // rdi

  v2 = (RBX::KeyframeSequence::CachedKeyframe *)*((_QWORD *)this + 11);
  if ( v2 )
  {
    v3 = (RBX::KeyframeSequence::CachedKeyframe *)*((_QWORD *)this + 12);
    if ( v3 == v2 )
    {
      v4 = (void *)*((_QWORD *)this + 11);
    }
    else
    {
      do
      {
        v3 = (RBX::KeyframeSequence::CachedKeyframe *)((char *)v3 - 104);
        RBX::KeyframeSequence::CachedKeyframe::~CachedKeyframe(v3);
      }
      while ( v2 != v3 );
      v4 = (void *)*((_QWORD *)this + 11);
    }
    *((_QWORD *)this + 12) = v2;
    operator delete(v4);
  }
  v5 = (void *)*((_QWORD *)this + 7);
  if ( v5 )
  {
    *((_QWORD *)this + 8) = v5;
    operator delete(v5);
  }
  v6 = (void *)*((_QWORD *)this + 4);
  if ( v6 )
  {
    *((_QWORD *)this + 5) = v6;
    operator delete(v6);
  }
  v7 = *((_QWORD *)this + 1);
  if ( v7 )
  {
    v8 = *((_QWORD *)this + 2);
    if ( v8 == v7 )
    {
      v10 = (void *)*((_QWORD *)this + 1);
    }
    else
    {
      do
      {
        v9 = v8 - 24;
        if ( (*(_BYTE *)(v8 - 24) & 1) != 0 )
          operator delete(*(void **)(v8 - 8));
        v8 = v9;
      }
      while ( v7 != v9 );
      v10 = (void *)*((_QWORD *)this + 1);
    }
    *((_QWORD *)this + 2) = v7;
    operator delete(v10);
  }
}


// Address: 0x1052f20 | Name: _ZN3RBX16KeyframeSequence14CachedKeyframeC2ERKS1_
void __fastcall RBX::KeyframeSequence::CachedKeyframe::CachedKeyframe(
        RBX::KeyframeSequence::CachedKeyframe *this,
        const RBX::KeyframeSequence::CachedKeyframe *a2)
{
  void **v2; // rax
  void **v3; // r13
  _BYTE *v6; // r14
  signed __int64 v7; // rdi
  char *v8; // r13
  const void *v9; // rsi
  __int64 v10; // rbp
  signed __int64 v11; // rdi
  char *v12; // rbp
  const void *v13; // rsi
  __int64 v14; // r15
  struct _Unwind_Exception *v15; // rbx
  void *v16; // rdi
  void *v17; // rdi
  void **v18; // [rsp+0h] [rbp-38h]

  v18 = v2;
  *(_DWORD *)this = *(_DWORD *)a2;
  v6 = (char *)this + 8;
  std::string::basic_string((char *)this + 8, (char *)a2 + 8);
  *((_OWORD *)this + 2) = 0;
  *((_QWORD *)this + 6) = 0;
  v7 = *((_QWORD *)a2 + 5) - *((_QWORD *)a2 + 4);
  if ( v7 )
  {
    if ( (unsigned __int64)(v7 >> 3) >> 61 )
    {
      std::__vector_base_common<true>::__throw_length_error((char *)this + 32);
      goto LABEL_11;
    }
    v8 = (char *)operator new(v7);
    *((_QWORD *)this + 5) = v8;
    *((_QWORD *)this + 4) = v8;
    *((_QWORD *)this + 6) = &v8[8 * (v7 >> 3)];
    v9 = (const void *)*((_QWORD *)a2 + 4);
    v10 = *((_QWORD *)a2 + 5) - (_QWORD)v9;
    if ( v10 > 0 )
    {
      memcpy(v8, v9, *((_QWORD *)a2 + 5) - (_QWORD)v9);
      *((_QWORD *)this + 5) = &v8[v10];
    }
  }
  v18 = (void **)((char *)this + 32);
  v3 = (void **)((char *)this + 56);
  *(_OWORD *)((char *)this + 56) = 0;
  *((_QWORD *)this + 9) = 0;
  v11 = *((_QWORD *)a2 + 8) - *((_QWORD *)a2 + 7);
  if ( !v11 )
    goto LABEL_9;
  if ( (unsigned __int64)(v11 >> 2) >> 62 )
  {
LABEL_11:
    v15 = (struct _Unwind_Exception *)std::__vector_base_common<true>::__throw_length_error(v3);
    v16 = *v3;
    if ( *v3 )
    {
      *((_QWORD *)this + 8) = v16;
      operator delete(v16);
    }
    v17 = *v18;
    if ( *v18 )
    {
      *((_QWORD *)this + 5) = v17;
      operator delete(v17);
    }
    if ( (*v6 & 1) == 0 )
      _Unwind_Resume(v15);
    operator delete(*((void **)this + 3));
    _Unwind_Resume(v15);
  }
  v12 = (char *)operator new(v11);
  *((_QWORD *)this + 8) = v12;
  *((_QWORD *)this + 7) = v12;
  *((_QWORD *)this + 9) = &v12[4 * (v11 >> 2)];
  v13 = (const void *)*((_QWORD *)a2 + 7);
  v14 = *((_QWORD *)a2 + 8) - (_QWORD)v13;
  if ( v14 > 0 )
  {
    memcpy(v12, v13, *((_QWORD *)a2 + 8) - (_QWORD)v13);
    *((_QWORD *)this + 8) = &v12[v14];
  }
LABEL_9:
  std::vector<std::pair<std::string,std::string>>::vector(
    (RBX::KeyframeSequence::CachedKeyframe *)((char *)this + 80),
    (const RBX::KeyframeSequence::CachedKeyframe *)((char *)a2 + 80));
}


// Address: 0x10554d0 | Name: _ZN3RBX16KeyframeSequence14CachedKeyframeaSEOS1_
RBX::KeyframeSequence::CachedKeyframe *__fastcall RBX::KeyframeSequence::CachedKeyframe::operator=(
        RBX::KeyframeSequence::CachedKeyframe *this,
        RBX::KeyframeSequence::CachedKeyframe *a2)
{
  _WORD *v3; // r15
  __int128 v4; // xmm0
  void *v5; // rdi
  void *v6; // rdi
  char *v7; // r15
  __int64 v8; // rbp
  _QWORD *v9; // r12
  __int64 v10; // r13
  __int64 v11; // r15
  char *v12; // r13
  void *v13; // rdi

  *(_DWORD *)this = *(_DWORD *)a2;
  v3 = (_WORD *)((char *)this + 8);
  if ( (*((_BYTE *)this + 8) & 1) != 0 )
  {
    **((_BYTE **)this + 3) = 0;
    *((_QWORD *)this + 2) = 0;
  }
  else
  {
    *v3 = 0;
  }
  std::string::reserve((char *)this + 8, 0);
  *((_QWORD *)this + 3) = *((_QWORD *)a2 + 3);
  *(_OWORD *)v3 = *(_OWORD *)((char *)a2 + 8);
  v4 = 0;
  *(_OWORD *)((char *)a2 + 8) = 0;
  *((_QWORD *)a2 + 3) = 0;
  v5 = (void *)*((_QWORD *)this + 4);
  if ( v5 )
  {
    *((_QWORD *)this + 5) = v5;
    operator delete(v5);
    v4 = 0;
    *((_OWORD *)this + 2) = 0;
    *((_QWORD *)this + 6) = 0;
  }
  *((_QWORD *)this + 4) = *((_QWORD *)a2 + 4);
  *((_QWORD *)this + 5) = *((_QWORD *)a2 + 5);
  *((_QWORD *)this + 6) = *((_QWORD *)a2 + 6);
  *((_OWORD *)a2 + 2) = v4;
  *((_QWORD *)a2 + 6) = 0;
  v6 = (void *)*((_QWORD *)this + 7);
  if ( v6 )
  {
    *((_QWORD *)this + 8) = v6;
    operator delete(v6);
    *(_OWORD *)((char *)this + 56) = 0;
    *((_QWORD *)this + 9) = 0;
  }
  *((_QWORD *)this + 7) = *((_QWORD *)a2 + 7);
  *((_QWORD *)this + 8) = *((_QWORD *)a2 + 8);
  *((_QWORD *)this + 9) = *((_QWORD *)a2 + 9);
  *(_OWORD *)((char *)a2 + 56) = 0;
  *((_QWORD *)a2 + 9) = 0;
  v7 = (char *)a2 + 80;
  v8 = *((_QWORD *)this + 10);
  if ( v8 )
  {
    v9 = (_QWORD *)((char *)this + 88);
    v10 = *((_QWORD *)this + 11);
    if ( v10 == v8 )
    {
      v13 = (void *)*((_QWORD *)this + 10);
      v12 = (char *)this + 80;
    }
    else
    {
      do
      {
        if ( (*(_BYTE *)(v10 - 24) & 1) != 0 )
          operator delete(*(void **)(v10 - 8));
        v11 = v10 - 48;
        if ( (*(_BYTE *)(v10 - 48) & 1) != 0 )
          operator delete(*(void **)(v10 - 32));
        v10 -= 48;
      }
      while ( v8 != v11 );
      v12 = (char *)this + 80;
      v13 = (void *)*((_QWORD *)this + 10);
      v7 = (char *)a2 + 80;
    }
    *v9 = v8;
    operator delete(v13);
    *(_OWORD *)v12 = 0;
    *((_QWORD *)v12 + 2) = 0;
  }
  else
  {
    v9 = (_QWORD *)((char *)this + 88);
  }
  *((_QWORD *)this + 10) = *((_QWORD *)a2 + 10);
  *v9 = *((_QWORD *)a2 + 11);
  *((_QWORD *)this + 12) = *((_QWORD *)a2 + 12);
  *(_OWORD *)v7 = 0;
  *((_QWORD *)v7 + 2) = 0;
  return this;
}


