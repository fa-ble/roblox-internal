// Address: 0x1e05000 | Name: _ZN3RBX9Collision17BlockBlockContact18geoFeaturesOverlapEiiiNS_8NormalIdES2_f
bool __fastcall RBX::Collision::BlockBlockContact::geoFeaturesOverlap(
        RBX::Collision::BlockBlockContact *this,
        int pointBody,
        int planeBody,
        int pointID,
        unsigned int pointFaceID,
        RBX::NormalId planeFaceID,
        float overlapIgnored)
{
  RBX::Body *Body; // rax
  __int64 v12; // rcx
  __m128 v13; // xmm1
  __m128 v14; // xmm2
  __m128 v15; // xmm0
  __m128 v16; // xmm4
  float v17; // xmm3_4
  __m128 v18; // xmm4
  __m128 v19; // xmm3
  RBX::Body *v20; // rax
  __m128 v21; // xmm4
  __m128 v22; // xmm7
  __m128 v23; // xmm5
  __m128 v24; // xmm2
  __int64 v25; // rax
  const RBX::Vector3 *v26; // rax
  __m128 v27; // xmm0
  __m128 v29; // [rsp+0h] [rbp-68h]
  __m128 v30; // [rsp+10h] [rbp-58h]
  __m128 v31; // [rsp+10h] [rbp-58h]

  Body = RBX::Collision::Contact::getBody(this, pointBody);
  v12 = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)&this->prim0 + (pointBody != 0)) + 144LL) + 72LL);
  v13 = (__m128)*(unsigned int *)(v12 + 12LL * dword_56F9F0[4 * pointFaceID + pointID]);
  v14 = (__m128)*(unsigned __int64 *)(v12 + 12LL * dword_56F9F0[4 * pointFaceID + pointID] + 4);
  v15 = _mm_mul_ps((__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[0][1], v14);
  v16 = _mm_mul_ps((__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[1][1], v14);
  v17 = (float)(Body->pv.position.rotation.elt[1][0] * v13.m128_f32[0]) + v16.m128_f32[0];
  v18 = _mm_shuffle_ps(v16, v16, 229);
  v18.m128_f32[0] = (float)(v18.m128_f32[0] + v17) + Body->pv.position.translation.y;
  v29 = v18;
  v19 = _mm_mul_ps((__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[2][1], v14);
  v30 = _mm_add_ps(
          _mm_unpacklo_ps(
            (__m128)LODWORD(Body->pv.position.translation.x),
            (__m128)LODWORD(Body->pv.position.translation.z)),
          _mm_add_ps(
            _mm_shuffle_ps(_mm_shuffle_ps(v19, v15, 17), v15, 226),
            _mm_add_ps(
              _mm_unpacklo_ps(v15, v19),
              _mm_mul_ps(
                _mm_shuffle_ps(v13, v13, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(Body->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(Body->pv.position.rotation.elt[2][0]))))));
  v20 = RBX::Collision::Contact::getBody(this, planeBody);
  v21 = v29;
  v21.m128_f32[0] = v29.m128_f32[0] - v20->pv.position.translation.y;
  v22 = _mm_sub_ps(
          v30,
          _mm_unpacklo_ps(
            (__m128)LODWORD(v20->pv.position.translation.x),
            (__m128)LODWORD(v20->pv.position.translation.z)));
  v23 = _mm_mul_ps(
          _mm_unpacklo_ps(
            (__m128)LODWORD(v20->pv.position.rotation.elt[0][1]),
            (__m128)LODWORD(v20->pv.position.rotation.elt[2][1])),
          v22);
  v19.m128_f32[0] = (float)(v20->pv.position.rotation.elt[1][1] * v21.m128_f32[0]) + v23.m128_f32[0];
  v24 = _mm_add_ps(
          _mm_mul_ps(
            _mm_shuffle_ps(v22, v22, 229),
            _mm_unpacklo_ps(
              (__m128)LODWORD(v20->pv.position.rotation.elt[2][0]),
              (__m128)LODWORD(v20->pv.position.rotation.elt[2][2]))),
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(v21, v21, 224),
              _mm_unpacklo_ps(
                (__m128)LODWORD(v20->pv.position.rotation.elt[1][0]),
                (__m128)LODWORD(v20->pv.position.rotation.elt[1][2]))),
            _mm_mul_ps(
              _mm_shuffle_ps(v22, v22, 224),
              _mm_unpacklo_ps(
                (__m128)LODWORD(v20->pv.position.rotation.elt[0][0]),
                (__m128)LODWORD(v20->pv.position.rotation.elt[0][2])))));
  v25 = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)&this->prim0 + (planeBody != 0)) + 144LL) + 72LL);
  v31 = _mm_sub_ps(
          v24,
          _mm_unpacklo_ps(
            (__m128)*(unsigned int *)(v25 + 12LL * dword_56F9F0[4 * planeFaceID]),
            (__m128)*(unsigned int *)(v25 + 12LL * dword_56F9F0[4 * planeFaceID] + 8)));
  v29.m128_f32[0] = (float)(_mm_shuffle_ps(v23, v23, 229).m128_f32[0] + v19.m128_f32[0])
                  - *(float *)(v25 + 12LL * dword_56F9F0[4 * planeFaceID] + 4);
  v26 = RBX::normalIdToVector3(planeFaceID);
  v27 = _mm_mul_ps(_mm_unpacklo_ps((__m128)LODWORD(v26->x), (__m128)LODWORD(v26->z)), v31);
  return (float)-overlapIgnored > (float)(_mm_shuffle_ps(v27, v27, 229).m128_f32[0]
                                        + (float)((float)(v29.m128_f32[0] * v26->y) + v27.m128_f32[0]));
}


// Address: 0x1e05250 | Name: _ZN3RBX9Collision17BlockBlockContact16getBestPlaneEdgeEfRb
bool __fastcall RBX::Collision::BlockBlockContact::getBestPlaneEdge(
        RBX::Collision::BlockBlockContact *this,
        float a2,
        float overlapIgnored,
        bool *planeContact)
{
  __int64 witnessId; // rcx
  int v5; // ebx
  int v6; // r14d
  RBX::Body *Body; // r15
  unsigned int *v8; // rax
  float *v9; // r13
  __m128 v10; // xmm1
  __m128 v11; // xmm0
  __m128 v12; // xmm2
  const RBX::Matrix3 *v13; // rbp
  __m128 v14; // xmm4
  int separatingAxisId; // r15d
  int v16; // r14d
  __m128i v17; // xmm2
  __int32 v18; // xmm2_4
  int v19; // eax
  __int32 v21; // xmm1_4
  __int32 v22; // xmm2_4
  bool result; // al
  RBX::Body *v24; // r15
  RBX::Body *v25; // rax
  RBX::Primitive *prim0; // rcx
  RBX::Primitive *prim1; // rdx
  const RBX::Matrix3 *p_rotation; // rbp
  const RBX::Matrix3 *v29; // r14
  __m128 v30; // xmm1
  __m128 v31; // xmm0
  unsigned int i; // r15d
  __m128 v33; // xmm2
  __m128 v34; // xmm3
  __m128 v35; // xmm5
  float v36; // xmm0_4
  float v37; // xmm1_4
  float v38; // xmm0_4
  __m128 x_low; // xmm0
  __m128 v40; // xmm1
  __m128 v41; // xmm0
  __m128 v42; // xmm5
  __m128 v43; // xmm2
  RBX::Collision::BlockBlockContact *v44; // rbx
  RBX::Block *v45; // rdi
  RBX::Block *v46; // rdi
  const RBX::Matrix3 *v47; // rsi
  RBX::NormalId v48; // edx
  RBX::Vector3 *p_vec; // rcx
  G3D::Vector3 v50; // [rsp+0h] [rbp-118h] BYREF
  RBX::NormalId iCol[3]; // [rsp+10h] [rbp-108h]
  float v52; // [rsp+1Ch] [rbp-FCh]
  __m128 v53; // [rsp+20h] [rbp-F8h]
  __int64 v54; // [rsp+38h] [rbp-E0h]
  RBX::Vector3 _vec; // [rsp+40h] [rbp-D8h] BYREF
  float v56; // [rsp+4Ch] [rbp-CCh]
  unsigned int *v57; // [rsp+50h] [rbp-C8h]
  bool *v58; // [rsp+58h] [rbp-C0h]
  __m128 v59; // [rsp+60h] [rbp-B8h]
  G3D::Matrix3 *v60[2]; // [rsp+70h] [rbp-A8h]
  __int64 v61; // [rsp+88h] [rbp-90h]
  __m128 v62; // [rsp+90h] [rbp-88h]
  __m128 v63; // [rsp+A0h] [rbp-78h]
  __m128 v64; // [rsp+B0h] [rbp-68h]
  __m128 v65; // [rsp+C0h] [rbp-58h]
  RBX::Collision::BlockBlockContact *v66; // [rsp+D0h] [rbp-48h]
  double v67; // [rsp+D8h] [rbp-40h]
  unsigned int *v68; // [rsp+E0h] [rbp-38h]
  G3D::Vector3 v69; // 0:kr00_12.12
  RBX::Vector3 v70; // 0:kr14_12.12
  G3D::Vector3 v71; // 0:kr20_12.12
  G3D::Vector3 v72; // 0:kr34_12.12
  RBX::Vector3 v73; // 0:kr40_12.12
  RBX::Vector3 v74; // 0:kr54_12.12

  v58 = planeContact;
  v56 = a2;
  v61 = *(_QWORD *)this->feature;
  LODWORD(v57) = HIDWORD(v61);
  v64.m128_i32[0] = v61;
  v63.m128_i8[0] = (unsigned int)v61 < 6 || HIDWORD(v61) < 6;
  witnessId = (unsigned int)this->witnessId;
  v53.m128_i32[0] = 2139095040;
  v59.m128_i32[0] = 2139095040;
  while ( 2 )
  {
    v5 = (int)witnessId % 2;
    LODWORD(v52) = witnessId + 1;
    *(_QWORD *)iCol = witnessId;
    v6 = witnessId - ((witnessId + ((unsigned int)(witnessId + 1) >> 31) + 1) & 0xFFFFFFFE) + 1;
    Body = RBX::Collision::Contact::getBody(this, (int)witnessId % 2);
    v60[0] = &Body->pv.position.rotation;
    v8 = (unsigned int *)RBX::Collision::Contact::getBody(this, v6);
    v65.m128_u64[0] = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)&this->prim0 + (v5 != 0)) + 144LL) + 72LL);
    v9 = *(float **)(*(_QWORD *)(*((_QWORD *)&this->prim0 + (v6 != 0)) + 144LL) + 72LL);
    v10 = (__m128)v8[61];
    v11 = (__m128)v8[62];
    v10.m128_f32[0] = v10.m128_f32[0] - Body->pv.position.translation.x;
    v11.m128_f32[0] = v11.m128_f32[0] - Body->pv.position.translation.y;
    v12 = (__m128)v8[63];
    v13 = (const RBX::Matrix3 *)(v8 + 52);
    v12.m128_f32[0] = v12.m128_f32[0] - Body->pv.position.translation.z;
    v14 = _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(v12, v12, 224),
              (__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[2][0]),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(v11, v11, 224),
                (__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[1][0]),
              _mm_mul_ps(
                _mm_shuffle_ps(v10, v10, 224),
                (__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[0][0])));
    v12.m128_f32[0] = (float)(v12.m128_f32[0] * Body->pv.position.rotation.elt[2][2])
                    + (float)((float)(v11.m128_f32[0] * Body->pv.position.rotation.elt[1][2])
                            + (float)(v10.m128_f32[0] * Body->pv.position.rotation.elt[0][2]));
    _mm_storel_ps((double *)&v50.x, v14);
    LODWORD(v50.z) = v12.m128_i32[0];
    separatingAxisId = this->separatingAxisId;
    v62.m128_i32[0] = v5;
    v54 = v6;
    do
    {
      v16 = separatingAxisId % 3;
      v69 = G3D::Matrix3::column(v60[0], separatingAxisId % 3);
      v11.m128_i32[0] = LODWORD(v69.x);
      v11.m128_i32[1] = LODWORD(v69.y);
      _mm_storel_ps((double *)&_vec.x, v11);
      _vec.z = v69.z;
      v70 = RBX::Math::vectorToObjectSpace(&_vec, v13);
      v11.m128_i32[0] = LODWORD(v70.x);
      v11.m128_i32[1] = LODWORD(v70.y);
      v17 = (__m128i)_mm_and_ps(_mm_mul_ps((__m128)*(unsigned __int64 *)v9, v11), (__m128)xmmword_3E5B40);
      v10.m128_f32[0] = v70.z * v9[2];
      v10 = _mm_and_ps(v10, (__m128)xmmword_3E5B40);
      v11 = (__m128)*((unsigned int *)&v50.x + separatingAxisId % 3);
      v10.m128_f32[0] = (float)((float)(v10.m128_f32[0]
                                      + (float)(*(float *)_mm_shuffle_epi32(v17, 229).m128i_i32 + *(float *)v17.m128i_i32))
                              + *(float *)(v65.m128_u64[0] + 4LL * v16))
                      - fabs(*(&v50.x + v16));
      if ( v10.m128_f32[0] <= v56 )
      {
        this->witnessId = v62.m128_i32[0];
        this->separatingAxisId = v16;
        return 0;
      }
      if ( v63.m128_i8[0] )
      {
        v18 = v10.m128_i32[0];
        if ( *((_DWORD *)&v61 + v5) % 3 != v16 )
          v18 = v59.m128_i32[0];
        v59.m128_i32[0] = v18;
      }
      if ( v53.m128_f32[0] <= v10.m128_f32[0] )
      {
        v16 = this->separatingAxisId;
      }
      else
      {
        v19 = v16 + 3;
        if ( v11.m128_f32[0] > 0.0 )
          v19 = separatingAxisId % 3;
        this->feature[v5] = v19;
        this->feature[v54] = -1;
        this->witnessId = v62.m128_i32[0];
        this->separatingAxisId = v16;
        *v58 = 1;
        v53.m128_i32[0] = v10.m128_i32[0];
      }
    }
    while ( separatingAxisId++ < v16 + 2 );
    witnessId = LODWORD(v52);
    if ( iCol[0] <= this->witnessId )
      continue;
    break;
  }
  if ( v63.m128_i8[0] )
  {
    if ( this->feature[0] == v64.m128_i32[0] )
    {
      v21 = v53.m128_i32[0];
      v22 = v59.m128_i32[0];
      if ( v59.m128_f32[0] > (float)(1.01 * v53.m128_f32[0]) || this->feature[1] == (_DWORD)v57 )
        goto LABEL_25;
      goto LABEL_24;
    }
    v21 = v53.m128_i32[0];
    v22 = v59.m128_i32[0];
    if ( v59.m128_f32[0] <= (float)(1.01 * v53.m128_f32[0]) )
    {
LABEL_24:
      this->feature[0] = v64.m128_i32[0];
      this->feature[1] = (int)v57;
      v21 = v22;
    }
  }
  else
  {
    v21 = v53.m128_i32[0];
  }
LABEL_25:
  v53.m128_i32[0] = v21;
  iCol[0] = RBX::NormalId::NORM_X;
  v24 = RBX::Collision::Contact::getBody(this, 0);
  v25 = RBX::Collision::Contact::getBody(this, 1);
  prim0 = this->prim0;
  v66 = this;
  prim1 = this->prim1;
  v57 = *(unsigned int **)(*((_QWORD *)prim0 + 18) + 72LL);
  v68 = *(unsigned int **)(*((_QWORD *)prim1 + 18) + 72LL);
  v52 = v25->pv.position.translation.x - v24->pv.position.translation.x;
  p_rotation = &v25->pv.position.rotation;
  v29 = &v24->pv.position.rotation;
  v30 = _mm_sub_ps(
          (__m128)*(unsigned __int64 *)&v25->pv.position.translation.y,
          (__m128)*(unsigned __int64 *)&v24->pv.position.translation.y);
  v64 = v30;
  v67 = v53.m128_f32[0];
  v31 = (__m128)0x7F800000u;
  LODWORD(v54) = 2139095040;
  while ( 2 )
  {
    for ( i = 0; i < 3; ++i )
    {
      v71 = G3D::Matrix3::column(v29, iCol[0]);
      v31.m128_i32[0] = LODWORD(v71.x);
      v31.m128_i32[1] = LODWORD(v71.y);
      v30.m128_i32[0] = LODWORD(v71.z);
      *(__m128 *)v60 = v31;
      v53 = v30;
      v72 = G3D::Matrix3::column(p_rotation, i);
      v31.m128_i32[0] = LODWORD(v72.x);
      v31.m128_i32[1] = LODWORD(v72.y);
      v33 = _mm_shuffle_ps(*(__m128 *)v60, *(__m128 *)v60, 229);
      v34 = v33;
      v35 = v53;
      v36 = _mm_shuffle_ps(v31, v31, 229).m128_f32[0];
      v34.m128_f32[0] = (float)(v33.m128_f32[0] * v72.z) - (float)(v53.m128_f32[0] * v36);
      v37 = v72.z * *(float *)v60;
      v35.m128_f32[0] = (float)(v53.m128_f32[0] * v72.x) - (float)(v72.z * *(float *)v60);
      v38 = (float)(v36 * *(float *)v60) - (float)(v33.m128_f32[0] * v72.x);
      _mm_storel_ps((double *)&v50.x, _mm_unpacklo_ps(v34, v35));
      v50.z = v38;
      if ( G3D::Vector3::unitize(&v50, v37) <= 0.001 )
        return *v58;
      x_low = (__m128)LODWORD(v50.x);
      v40 = _mm_mul_ps((__m128)*(unsigned __int64 *)&v50.y, v64);
      x_low.m128_f32[0] = (float)(v50.x * v52) + v40.m128_f32[0];
      v30 = _mm_shuffle_ps(v40, v40, 229);
      v30.m128_f32[0] = v30.m128_f32[0] + x_low.m128_f32[0];
      v63 = v30;
      v73 = RBX::Math::vectorToObjectSpace(&v50, v29);
      x_low.m128_i32[0] = LODWORD(v73.x);
      x_low.m128_i32[1] = LODWORD(v73.y);
      v30.m128_i32[0] = LODWORD(v73.z);
      v65 = x_low;
      v53 = v30;
      v62 = (__m128)*v57;
      v59 = (__m128)v57[1];
      v41 = (__m128)v57[2];
      *(__m128 *)v60 = v41;
      v74 = RBX::Math::vectorToObjectSpace(&v50, p_rotation);
      v41.m128_i32[0] = LODWORD(v74.x);
      v41.m128_i32[1] = LODWORD(v74.y);
      v30.m128_i32[0] = LODWORD(v74.z);
      v42 = _mm_add_ps(
              _mm_and_ps(
                _mm_mul_ps(_mm_unpacklo_ps(v53, v30), _mm_unpacklo_ps(*(__m128 *)v60, (__m128)v68[2])),
                (__m128)xmmword_3E5B40),
              _mm_add_ps(
                _mm_and_ps(
                  _mm_mul_ps(
                    _mm_shuffle_ps(_mm_shuffle_ps(v41, v65, 17), v65, 226),
                    _mm_unpacklo_ps(v59, (__m128)v68[1])),
                  (__m128)xmmword_3E5B40),
                _mm_and_ps(
                  _mm_mul_ps(_mm_unpacklo_ps(v65, v41), _mm_unpacklo_ps(v62, (__m128)*v68)),
                  (__m128)xmmword_3E5B40)));
      v43 = _mm_shuffle_ps(v42, v42, 229);
      v43.m128_f32[0] = (float)(v43.m128_f32[0] + v42.m128_f32[0]) - fabs(v63.m128_f32[0]);
      if ( v43.m128_f32[0] <= v56 )
        return 0;
      v31 = (__m128)(unsigned int)v54;
      if ( *(float *)&v54 > v43.m128_f32[0] )
      {
        v31 = 0;
        v30 = (__m128)*(unsigned __int64 *)&v67;
        if ( v67 <= v43.m128_f32[0] * 10.0 )
        {
          LODWORD(v54) = v43.m128_i32[0];
        }
        else
        {
          v53 = v43;
          v44 = v66;
          v45 = (RBX::Block *)*((_QWORD *)v66->prim0 + 18);
          if ( v63.m128_f32[0] <= 0.0 )
          {
            v30 = _mm_xor_ps((__m128)LODWORD(v50.z), *(__m128 *)&stru_3E4970.x);
            _mm_storel_ps((double *)&_vec.x, _mm_xor_ps((__m128)*(unsigned __int64 *)&v50.x, *(__m128 *)&stru_3E4970.x));
            LODWORD(_vec.z) = v30.m128_i32[0];
            v44->feature[0] = RBX::Block::getClosestEdge(v45, v29, iCol[0], &_vec) + 6;
            v46 = (RBX::Block *)*((_QWORD *)v44->prim1 + 18);
            v47 = p_rotation;
            v48 = i;
            p_vec = &v50;
          }
          else
          {
            v44->feature[0] = RBX::Block::getClosestEdge(v45, v29, iCol[0], &v50) + 6;
            v46 = (RBX::Block *)*((_QWORD *)v44->prim1 + 18);
            v30 = _mm_xor_ps((__m128)LODWORD(v50.z), *(__m128 *)&stru_3E4970.x);
            _mm_storel_ps((double *)&_vec.x, _mm_xor_ps((__m128)*(unsigned __int64 *)&v50.x, *(__m128 *)&stru_3E4970.x));
            LODWORD(_vec.z) = v30.m128_i32[0];
            v47 = p_rotation;
            v48 = i;
            p_vec = &_vec;
          }
          v44->feature[1] = RBX::Block::getClosestEdge(v46, v47, v48, p_vec) + 6;
          *v58 = 0;
          v31.m128_u64[1] = v53.m128_u64[1];
          LODWORD(v54) = v53.m128_i32[0];
        }
      }
    }
    result = 1;
    if ( ++iCol[0] < (unsigned int)RBX::NormalId::NORM_X_NEG )
      continue;
    break;
  }
  return result;
}


// Address: 0x1e059e0 | Name: _ZN3RBX9Collision17BlockBlockContact19computePlaneContactERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
int __fastcall RBX::Collision::BlockBlockContact::computePlaneContact(
        RBX::Collision::BlockBlockContact *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors,
        float a3,
        float overlapIgnored)
{
  RBX::NormalId v4; // r14d
  int v5; // ebx
  unsigned int v6; // r15d
  RBX::Body *Body; // r12
  RBX::Body *v8; // rbx
  __m128 x_low; // xmm2
  __m128 y_low; // xmm1
  __m128 z_low; // xmm0
  __m128 v12; // xmm4
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  RBX::Block *v15; // r12
  RBX::Block *v16; // rbp
  signed int v17; // eax
  RBX::NormalId ClosestObjectNormalId; // r15d
  int *v19; // rbp
  __int64 i; // rbx
  const RBX::Vector3 *vertices; // rax
  __m128 v22; // xmm0
  __m128 v23; // xmm1
  __m128 v24; // xmm2
  float v25; // xmm3_4
  float v26; // xmm4_4
  __m128 v27; // xmm1
  __m128 v28; // xmm0
  float v29; // xmm4_4
  unsigned int v31; // [rsp+4h] [rbp-154h]
  G3D::Matrix3 v32; // [rsp+8h] [rbp-150h] BYREF
  G3D::Matrix3 v33; // [rsp+30h] [rbp-128h] BYREF
  unsigned __int64 v34; // [rsp+54h] [rbp-104h] BYREF
  float v35; // [rsp+5Ch] [rbp-FCh]
  int v36; // [rsp+68h] [rbp-F0h]
  float v37; // [rsp+6Ch] [rbp-ECh]
  float v38; // [rsp+70h] [rbp-E8h]
  float v39; // [rsp+74h] [rbp-E4h]
  float v40; // [rsp+78h] [rbp-E0h]
  float v41; // [rsp+7Ch] [rbp-DCh]
  __m128 v42; // [rsp+80h] [rbp-D8h]
  G3D::Matrix3 *objectR; // [rsp+90h] [rbp-C8h]
  RBX::Collision::BlockBlockContact *v44; // [rsp+98h] [rbp-C0h]
  RBX::Collision::PolyCollisionConnectorArray *v45; // [rsp+A0h] [rbp-B8h]
  RBX::Vector2 planeRect; // [rsp+A8h] [rbp-B0h] BYREF
  __m128 v47; // [rsp+B0h] [rbp-A8h]
  __m128 v48; // [rsp+C0h] [rbp-98h]
  __m128 v49; // [rsp+D0h] [rbp-88h]
  __m128 v50; // [rsp+E0h] [rbp-78h]
  __m128 v51; // [rsp+F0h] [rbp-68h]
  __m128 v52; // [rsp+100h] [rbp-58h]
  __m128 v53; // [rsp+110h] [rbp-48h]

  v37 = a3;
  v45 = newCollisionConnectors;
  v4 = this->feature[0];
  if ( v4 < RBX::NormalId::NORM_X )
  {
    v4 = this->feature[1];
    v5 = 1;
    v6 = 0;
  }
  else
  {
    v5 = 0;
    v6 = 1;
  }
  v31 = v5;
  Body = RBX::Collision::Contact::getBody(this, v6);
  v8 = RBX::Collision::Contact::getBody(this, v5);
  *(_OWORD *)&v33.elt[0][0] = 0x3F800000u;
  *(_OWORD *)&v33.elt[1][1] = 0x3F800000u;
  v33.elt[2][2] = 1.0;
  _mm_storel_ps((double *)&v34, (__m128)0LL);
  v35 = 0.0;
  G3D::Matrix3::transpose(&v32, &v8->pv.position.rotation);
  v33 = v32;
  G3D::Matrix3::operator-(&v32, &v33);
  x_low = (__m128)LODWORD(v8->pv.position.translation.x);
  y_low = (__m128)LODWORD(v8->pv.position.translation.y);
  z_low = (__m128)LODWORD(v8->pv.position.translation.z);
  v12 = _mm_add_ps(
          _mm_mul_ps(
            _mm_shuffle_ps(z_low, z_low, 224),
            _mm_unpacklo_ps((__m128)LODWORD(v32.elt[0][2]), (__m128)LODWORD(v32.elt[1][2]))),
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(y_low, y_low, 224),
              _mm_unpacklo_ps((__m128)LODWORD(v32.elt[0][1]), (__m128)LODWORD(v32.elt[1][1]))),
            _mm_mul_ps(
              _mm_shuffle_ps(x_low, x_low, 224),
              _mm_unpacklo_ps((__m128)LODWORD(v32.elt[0][0]), (__m128)LODWORD(v32.elt[1][0])))));
  z_low.m128_f32[0] = (float)(z_low.m128_f32[0] * v32.elt[2][2])
                    + (float)((float)(y_low.m128_f32[0] * v32.elt[2][1]) + (float)(x_low.m128_f32[0] * v32.elt[2][0]));
  _mm_storel_ps((double *)&v34, v12);
  v35 = z_low.m128_f32[0];
  objectR = &Body->pv.position.rotation;
  G3D::Matrix3::operator*(&v32, &v33, &Body->pv.position.rotation);
  v42 = (__m128)LODWORD(Body->pv.position.translation.x);
  v13 = (__m128)LODWORD(Body->pv.position.translation.y);
  v14 = (__m128)LODWORD(Body->pv.position.translation.z);
  v50 = _mm_unpacklo_ps((__m128)LODWORD(v33.elt[0][0]), (__m128)LODWORD(v33.elt[1][0]));
  v49 = _mm_mul_ps(
          _mm_shuffle_ps(v13, v13, 224),
          _mm_unpacklo_ps((__m128)LODWORD(v33.elt[0][1]), (__m128)LODWORD(v33.elt[1][1])));
  v47 = _mm_mul_ps(
          _mm_shuffle_ps(v14, v14, 224),
          _mm_unpacklo_ps((__m128)LODWORD(v33.elt[0][2]), (__m128)LODWORD(v33.elt[1][2])));
  v48 = (__m128)v34;
  v53 = _mm_unpacklo_ps((__m128)LODWORD(v32.elt[0][0]), (__m128)LODWORD(v32.elt[1][0]));
  v52 = _mm_unpacklo_ps((__m128)LODWORD(v32.elt[0][1]), (__m128)LODWORD(v32.elt[1][1]));
  v51 = _mm_unpacklo_ps((__m128)LODWORD(v32.elt[0][2]), (__m128)LODWORD(v32.elt[1][2]));
  v40 = v32.elt[2][1];
  v41 = v32.elt[2][0];
  v39 = v32.elt[2][2];
  v38 = (float)((float)((float)(v33.elt[2][0] * v42.m128_f32[0]) + (float)(v13.m128_f32[0] * v33.elt[2][1]))
              + (float)(v14.m128_f32[0] * v33.elt[2][2]))
      + v35;
  v36 = v6;
  v15 = *(RBX::Block **)(*((_QWORD *)&this->prim0 + v6) + 144LL);
  v44 = this;
  v16 = *(RBX::Block **)(*((_QWORD *)&this->prim0 + v31) + 144LL);
  v17 = (-2 * (v4 / 3)) | 1;
  x_low.m128_f32[0] = (float)v17 * v8->pv.position.rotation.elt[2][v4 % 3];
  v13.m128_u64[1] = 0x8000000080000000LL;
  _mm_storel_ps(
    (double *)&v33,
    _mm_xor_ps(
      _mm_mul_ps(
        _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v17), 80)),
        _mm_unpacklo_ps(
          (__m128)LODWORD(v8->pv.position.rotation.elt[0][v4 % 3]),
          (__m128)LODWORD(v8->pv.position.rotation.elt[1][v4 % 3]))),
      *(__m128 *)&stru_3E4970.x));
  v33.elt[0][2] = -x_low.m128_f32[0];
  ClosestObjectNormalId = RBX::Math::getClosestObjectNormalId((const G3D::Vector3 *)&v33, objectR);
  *(RBX::Vector2 *)v13.m128_f32 = RBX::Block::getProjectedVertex(v16, &v16->vertices[dword_56F9F0[4 * v4]], v4);
  _mm_storel_ps((double *)&planeRect, v13);
  memset(&v33, 0, 32);
  v42 = _mm_add_ps(_mm_add_ps(_mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v42, v42, 224), v50), v49), v47), v48);
  v19 = &dword_56F9F0[4 * ClosestObjectNormalId];
  for ( i = 0; i != 4; ++i )
  {
    vertices = v15->vertices;
    v22 = (__m128)LODWORD(vertices[v19[i]].x);
    v23 = (__m128)LODWORD(vertices[v19[i]].y);
    v24 = (__m128)LODWORD(vertices[v19[i]].z);
    v25 = v41 * v22.m128_f32[0];
    v26 = v40 * v23.m128_f32[0];
    v27 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v23, v23, 224), v52), _mm_mul_ps(_mm_shuffle_ps(v22, v22, 224), v53));
    v28 = (__m128)LODWORD(v39);
    v29 = (float)((float)(v26 + v25) + (float)(v39 * v24.m128_f32[0])) + v38;
    _mm_storel_ps((double *)&v32, _mm_add_ps(_mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v24, v24, 224), v51), v27), v42));
    v32.elt[0][2] = v29;
    *(RBX::Vector2 *)v28.m128_f32 = RBX::Block::getProjectedVertex(v15, (const RBX::Vector3 *)&v32, v4);
    LODWORD(v33.elt[0][2 * i]) = v28.m128_i32[0];
    LODWORD(v33.elt[0][2 * i + 1]) = _mm_shuffle_ps(v28, v28, 77).m128_u32[0];
  }
  return RBX::Collision::BlockBlockContact::intersectRectQuad(
           v44,
           v45,
           &planeRect,
           (RBX::Vector2 (*)[4])&v33,
           v37,
           v31,
           v36,
           v4,
           ClosestObjectNormalId);
}


// Address: 0x1e05eb0 | Name: _ZN3RBX9Collision17BlockBlockContact17intersectRectQuadERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEERN3G3D7Vector2ERA4_S8_fiiNS_8NormalIdESC_
__int64 __fastcall RBX::Collision::BlockBlockContact::intersectRectQuad(
        RBX::Collision::BlockBlockContact *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors,
        RBX::Vector2 *planeRect,
        RBX::Vector2 (*otherQuad)[4],
        __m128 overlapIgnored,
        int bPlane,
        int bOther,
        RBX::NormalId planeID,
        RBX::NormalId otherPlaneID)
{
  float x; // xmm0_4
  float y; // xmm1_4
  float v12; // xmm3_4
  __int64 i; // rax
  float v14; // xmm4_4
  float v15; // xmm5_4
  RBX::Primitive **p_prim1; // rdx
  RBX::Primitive **p_prim0; // rcx
  __int64 v18; // r13
  __int64 j; // rbx
  __int64 v20; // rbp
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // rax
  const RBX::Vector3 *v22; // rsi
  RBX::Collision::FeaturePolyCollisionConnector *v23; // rbp
  __int64 result; // rax
  __m128 x_low; // xmm0
  __m128 y_low; // xmm1
  __m128 v27; // xmm7
  __m128 v28; // xmm0
  __m128 v29; // xmm1
  char v30; // al
  __int64 k; // rcx
  __int64 v32; // rdx
  __m128 v33; // xmm2
  __m128 v34; // xmm3
  __m128 v35; // xmm4
  __m128 v36; // xmm5
  __m128 v37; // xmm3
  __m128 v38; // xmm2
  __m128 v39; // xmm2
  __m128 v40; // xmm3
  __int8 v41; // dl
  __int64 v42; // rbx
  __int64 v44; // rbp
  RBX::Collision::FeaturePolyCollisionConnector *v45; // r14
  _BYTE *v46; // rsi
  int *v47; // rdi
  char v48; // cl
  int *v49; // rbp
  _BYTE *v50; // rbx
  __int64 v51; // r13
  __int64 v52; // rax
  int v53; // edi
  int v54; // r10d
  __int64 v55; // r8
  __int64 v56; // rax
  int v57; // ecx
  const RBX::Vector3 *v58; // r14
  __int64 v59; // r9
  __int64 v60; // rax
  int v61; // ebx
  const RBX::Vector3 *v62; // r12
  int v63; // ebx
  int v64; // eax
  RBX::NormalId v65; // ebp
  RBX::NormalId v66; // r15d
  RBX::Collision::FeaturePolyCollisionConnector *v67; // rbx
  int planeBodya; // [rsp+4h] [rbp-104h]
  int pointBodya; // [rsp+8h] [rbp-100h]
  int v72; // [rsp+Ch] [rbp-FCh]
  int v73; // [rsp+10h] [rbp-F8h]
  int v74; // [rsp+14h] [rbp-F4h]
  _BYTE *v75; // [rsp+18h] [rbp-F0h]
  RBX::Vector2 *v76; // [rsp+20h] [rbp-E8h]
  int *v77; // [rsp+28h] [rbp-E0h]
  int *v78; // [rsp+30h] [rbp-D8h]
  __int64 v79; // [rsp+38h] [rbp-D0h]
  _BYTE v80[16]; // [rsp+40h] [rbp-C8h] BYREF
  __int64 v81; // [rsp+50h] [rbp-B8h]
  RBX::Collision::PolyCollisionConnectorArray *collisionConnectors; // [rsp+58h] [rbp-B0h]
  __m128 v83; // [rsp+60h] [rbp-A8h]
  _BYTE v84[16]; // [rsp+70h] [rbp-98h] BYREF
  __m128 v85; // [rsp+80h] [rbp-88h]
  __m128 v86; // [rsp+90h] [rbp-78h]
  __m128 v87; // [rsp+A0h] [rbp-68h]
  int *v88; // [rsp+B8h] [rbp-50h]
  unsigned __int64 v89; // [rsp+C0h] [rbp-48h]
  RBX::Primitive **v90; // [rsp+C8h] [rbp-40h]
  RBX::Primitive **v91; // [rsp+D0h] [rbp-38h]

  v83 = overlapIgnored;
  collisionConnectors = newCollisionConnectors;
  v73 = (int)&loc_1010101;
  x = planeRect->x;
  v76 = planeRect;
  y = planeRect->y;
  v12 = -y;
  for ( i = 0; i != -4; --i )
  {
    v14 = (*otherQuad)[i + 3].y;
    if ( y >= v14 )
    {
      v80[i + 3] = 1;
    }
    else
    {
      v80[i + 3] = 0;
      *((_BYTE *)&v73 + i + 3) = 0;
    }
    v15 = (*otherQuad)[i + 3].x;
    if ( v15 >= (float)-x )
    {
      v80[i + 7] = 1;
      if ( v14 >= v12 )
      {
LABEL_7:
        v80[i + 11] = 1;
        if ( x >= v15 )
          goto LABEL_8;
        goto LABEL_11;
      }
    }
    else
    {
      v80[i + 7] = 0;
      *((_BYTE *)&v73 + i + 3) = 0;
      if ( v14 >= v12 )
        goto LABEL_7;
    }
    v80[i + 11] = 0;
    *((_BYTE *)&v73 + i + 3) = 0;
    if ( x >= v15 )
    {
LABEL_8:
      v80[i + 15] = 1;
      continue;
    }
LABEL_11:
    v80[i + 15] = 0;
    *((_BYTE *)&v73 + i + 3) = 0;
  }
  p_prim1 = &this->prim1;
  v79 = 8LL * (bOther != 0) + 8;
  p_prim0 = &this->prim1;
  if ( !bOther )
    p_prim0 = &this->prim0;
  v90 = p_prim0;
  if ( !bPlane )
    p_prim1 = &this->prim0;
  v91 = p_prim1;
  v18 = 8LL * (bPlane != 0) + 8;
  v81 = 16LL * (unsigned int)planeID;
  v78 = (int *)((char *)dword_56F9F0 + v81);
  v87 = _mm_xor_ps(*(__m128 *)&stru_3E4970.x, v83);
  v89 = 16LL * (unsigned int)otherPlaneID;
  v77 = &dword_56F9F0[v89 / 4];
  LODWORD(v75) = 0;
  for ( j = 3; j != -1; --j )
  {
    if ( *((_BYTE *)&v73 + j) )
    {
      v20 = v79;
      CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                             collisionConnectors,
                             *(RBX::Primitive **)((char *)&this->_vptr$Contact + v79),
                             *(RBX::Primitive **)((char *)&this->_vptr$Contact + v18),
                             RBX::Collision::FeaturePolyPair::VERTEX_FACE_PAIR);
      v22 = (const RBX::Vector3 *)(*(_QWORD *)((*(_QWORD **)((char *)&this->_vptr$Contact + v20))[18] + 72LL)
                                 + 12LL * v77[j]);
      v23 = CollisionConnector;
      RBX::Collision::BlockBlockContact::updateVertexFaceCollision(
        CollisionConnector,
        v22,
        (const RBX::Vector3 *)(*(_QWORD *)((*(_QWORD **)((char *)&this->_vptr$Contact + v18))[18] + 72LL) + 12LL * *v78),
        j,
        planeID);
      if ( RBX::Collision::BlockBlockContact::geoFeaturesOverlap(
             this,
             bOther,
             bPlane,
             j,
             otherPlaneID,
             planeID,
             v83.m128_f32[0])
        && v23->depth < v87.m128_f32[0] )
      {
        LODWORD(v75) = (_DWORD)v75 + 1;
      }
      else
      {
        *(_QWORD *)&v23->normal.x = 0;
        v23->normal.z = 0.0;
      }
    }
  }
  result = 4;
  if ( (_DWORD)v75 != 4 )
  {
    x_low = (__m128)LODWORD(v76->x);
    y_low = (__m128)LODWORD(v76->y);
    v72 = (int)&loc_1010101;
    v27 = _mm_unpacklo_ps(_mm_xor_ps(*(__m128 *)&stru_3E4970.x, y_low), y_low);
    v28 = _mm_unpacklo_ps(x_low, _mm_xor_ps(x_low, *(__m128 *)&stru_3E4970.x));
    v29 = (__m128)xmmword_3EA800;
    v30 = 1;
    for ( k = 6; k != 2; --k )
    {
      v32 = k & 3;
      v33 = (__m128)LODWORD((*otherQuad)[v32].x);
      v34 = (__m128)LODWORD((*otherQuad)[v32].y);
      v35 = (__m128)LODWORD((*otherQuad)[k - 3].x);
      v36 = (__m128)*((unsigned int *)&(*otherQuad)[k - 2] - 1);
      v33.m128_f32[0] = v33.m128_f32[0] - v35.m128_f32[0];
      v34.m128_f32[0] = v34.m128_f32[0] - v36.m128_f32[0];
      v37 = _mm_mul_ps(_mm_shuffle_ps(v34, v34, 224), _mm_sub_ps(v28, _mm_shuffle_ps(v35, v35, 224)));
      v38 = _mm_mul_ps(_mm_shuffle_ps(v33, v33, 224), _mm_sub_ps(v27, _mm_shuffle_ps(v36, v36, 224)));
      v39 = _mm_sub_ps(_mm_unpacklo_ps(v38, v38), _mm_shuffle_ps(v37, v37, 20));
      v40 = _mm_cmpnle_ps((__m128)0LL, v39);
      v86 = v40;
      if ( (v40.m128_i8[12] & 1) != 0 )
        v30 = 0;
      v83.m128_i8[4 * k + 4] = (v40.m128_i8[12] & 1) == 0;
      v83.m128_i8[4 * k + 5] = (v86.m128_i8[8] & 1) == 0;
      v41 = v86.m128_i8[0];
      v83.m128_i8[4 * k + 6] = (v86.m128_i8[4] & 1) == 0;
      v29 = _mm_and_ps(v29, _mm_cmple_ps((__m128)0LL, v39));
      v83.m128_i8[4 * k + 7] = (v41 & 1) == 0;
    }
    v85 = v29;
    BYTE1(v72) = v29.m128_i8[8];
    BYTE2(v72) = v29.m128_i8[4];
    HIBYTE(v72) = v29.m128_i8[0];
    v42 = 0;
    v74 = (int)v75;
    if ( v30 )
      goto LABEL_32;
LABEL_35:
    while ( v42 != 3 )
    {
      while ( *((_BYTE *)&v72 + ++v42) )
      {
LABEL_32:
        v44 = v79;
        v45 = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                collisionConnectors,
                *(RBX::Primitive **)((char *)&this->_vptr$Contact + v18),
                *(RBX::Primitive **)((char *)&this->_vptr$Contact + v79),
                RBX::Collision::FeaturePolyPair::VERTEX_FACE_PAIR);
        RBX::Collision::BlockBlockContact::updateVertexFaceCollision(
          v45,
          (const RBX::Vector3 *)(*(_QWORD *)((*(_QWORD **)((char *)&this->_vptr$Contact + v18))[18] + 72LL)
                               + 12LL * v78[v42]),
          (const RBX::Vector3 *)(*(_QWORD *)((*(_QWORD **)((char *)&this->_vptr$Contact + v44))[18] + 72LL) + 12LL * *v77),
          v42,
          otherPlaneID);
        if ( RBX::Collision::BlockBlockContact::geoFeaturesOverlap(
               this,
               bPlane,
               bOther,
               v42,
               planeID,
               otherPlaneID,
               v83.m128_f32[0])
          && v45->depth < v87.m128_f32[0] )
        {
          ++v74;
          goto LABEL_35;
        }
        *(_QWORD *)&v45->normal.x = 0;
        v45->normal.z = 0.0;
        if ( v42 == 3 )
          goto LABEL_38;
      }
    }
LABEL_38:
    if ( (_DWORD)v75 || (LODWORD(v76) = 4, v74 != 4) )
    {
      v46 = v80;
      v47 = (int *)v84;
      v48 = 1;
      v49 = 0;
      v81 += (__int64)dword_56FA50;
      LODWORD(v76) = v74;
      do
      {
        LOBYTE(v74) = v48;
        v50 = &v84[v48 & 3];
        v88 = (int *)((char *)v49 + 1);
        v83.m128_u64[0] = v81 + 4LL * (_QWORD)v49;
        v51 = 6;
        v79 = (__int64)v46;
        v78 = v47;
        v77 = v49;
        v75 = v50;
        do
        {
          v52 = v51 & 3;
          if ( v46[v51 - 3] != v80[4 * (_QWORD)v49 + v52] && LOBYTE(v47[v51 - 3]) != v50[4 * v51 - 12] )
          {
            v53 = dword_56FA50[v89 / 4 + v52];
            v54 = *(_DWORD *)v83.m128_u64[0];
            v55 = *((_QWORD *)*v90 + 18);
            if ( v53 > 11 )
            {
              v56 = (unsigned int)((int)(v53 + ((unsigned int)((v53 - 12) >> 31) >> 30) - 12) >> 2);
              v57 = v53 - 11;
            }
            else
            {
              v56 = v53 / 4;
              v57 = v53 % 4;
            }
            v58 = (const RBX::Vector3 *)(*(_QWORD *)(v55 + 72) + 12LL * dword_56F9F0[4 * v56 + v57]);
            v59 = *((_QWORD *)*v91 + 18);
            if ( v54 > 11 )
            {
              v60 = (unsigned int)((int)(v54 + ((unsigned int)((v54 - 12) >> 31) >> 30) - 12) >> 2);
              v61 = v54 - 11;
            }
            else
            {
              v60 = v54 / 4;
              v61 = v54 % 4;
            }
            v62 = (const RBX::Vector3 *)(*(_QWORD *)(v59 + 72) + 12LL * dword_56F9F0[4 * v60 + v61]);
            v63 = v53 / 4 + 3 * (v53 % 2);
            if ( v53 >= 13 )
              v63 = (v63 + 3) % 6;
            v64 = v54 / 4 + 3 * (v54 % 2);
            if ( v54 >= 13 )
              v64 = (v64 + 3) % 6;
            v65 = v63;
            pointBodya = *(_DWORD *)(v55 + 4LL * (v63 % 3) + 8);
            v66 = v64;
            planeBodya = *(_DWORD *)(v59 + 4LL * (v64 % 3) + 8);
            v67 = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                    collisionConnectors,
                    *v90,
                    *v91,
                    RBX::Collision::FeaturePolyPair::EDGE_EDGE_FACE_PAIR);
            RBX::Collision::BlockBlockContact::updateEdgeEdgeFaceCollision(
              v67,
              v58,
              v62,
              v65,
              v66,
              planeID,
              *(float *)&pointBodya,
              *(float *)&planeBodya);
            if ( v67->depth >= v87.m128_f32[0] )
            {
              *(_QWORD *)&v67->normal.x = 0;
              v67->normal.z = 0.0;
            }
            else
            {
              LODWORD(v76) = (_DWORD)v76 + 1;
            }
            v46 = (_BYTE *)v79;
            v47 = v78;
            v49 = v77;
            v50 = v75;
          }
          --v51;
        }
        while ( v51 != 2 );
        v46 += 4;
        v47 = (int *)((char *)v47 + 1);
        v48 = v74 + 1;
        v49 = v88;
      }
      while ( v88 != (int *)&instanceIdentifier );
    }
    return (unsigned int)v76;
  }
  return result;
}


// Address: 0x1e066e0 | Name: _ZN3RBX9Collision17BlockBlockContact25updateVertexFaceCollisionEPNS0_29FeaturePolyCollisionConnectorERKN3G3D7Vector3ES7_iNS_8NormalIdE
void __fastcall RBX::Collision::BlockBlockContact::updateVertexFaceCollision(
        RBX::Collision::FeaturePolyCollisionConnector *conn,
        const RBX::Vector3 *_offsetPoint,
        const RBX::Vector3 *_offsetPlane,
        int _pointID,
        RBX::NormalId _planeNormalID)
{
  float *bodyB; // rax
  __m128 x_low; // xmm2
  __m128 y_low; // xmm1
  __m128 z_low; // xmm0
  __m128 v9; // xmm5
  float y; // xmm6_4
  float v11; // xmm3_4
  float v12; // xmm4_4
  __m128 v13; // xmm8
  signed int v14; // ecx
  __int64 v15; // rdx
  __m128 v16; // xmm1
  __m128 v17; // xmm6
  __m128i v18; // xmm6

  conn->param0 = _pointID;
  conn->param1 = _planeNormalID;
  bodyB = (float *)conn->bodyB;
  x_low = (__m128)LODWORD(_offsetPoint->x);
  y_low = (__m128)LODWORD(_offsetPoint->y);
  z_low = (__m128)LODWORD(_offsetPoint->z);
  v9 = _mm_add_ps(
         _mm_mul_ps(
           _mm_shuffle_ps(z_low, z_low, 224),
           _mm_unpacklo_ps(
             (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[0][2]),
             (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[1][2]))),
         _mm_add_ps(
           _mm_mul_ps(
             _mm_shuffle_ps(y_low, y_low, 224),
             _mm_unpacklo_ps(
               (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[0][1]),
               (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[1][1]))),
           _mm_mul_ps(
             _mm_shuffle_ps(x_low, x_low, 224),
             _mm_unpacklo_ps(
               (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[0][0]),
               (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[1][0])))));
  z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * conn->bodyA->pv.position.rotation.elt[2][2])
                            + (float)((float)(y_low.m128_f32[0] * conn->bodyA->pv.position.rotation.elt[2][1])
                                    + (float)(x_low.m128_f32[0] * conn->bodyA->pv.position.rotation.elt[2][0])))
                    + conn->bodyA->pv.position.translation.z;
  y = _offsetPlane->y;
  x_low.m128_i32[0] = LODWORD(_offsetPlane->z);
  v11 = (float)((float)(bodyB[54] * x_low.m128_f32[0])
              + (float)((float)(bodyB[53] * y) + (float)(bodyB[52] * _offsetPlane->x)))
      + bodyB[61];
  v12 = (float)((float)(bodyB[57] * x_low.m128_f32[0])
              + (float)((float)(bodyB[56] * y) + (float)(bodyB[55] * _offsetPlane->x)))
      + bodyB[62];
  v13 = _mm_add_ps((__m128)*(unsigned __int64 *)&conn->bodyA->pv.position.translation.x, v9);
  x_low.m128_f32[0] = (float)((float)(x_low.m128_f32[0] * bodyB[60])
                            + (float)((float)(y * bodyB[59]) + (float)(_offsetPlane->x * bodyB[58])))
                    + bodyB[63];
  v14 = (-2 * (_planeNormalID / 3)) | 1;
  v15 = _planeNormalID % 3;
  v16 = (__m128)LODWORD(bodyB[v15 + 52]);
  v9.m128_f32[0] = (float)v14 * bodyB[v15 + 58];
  v17 = (__m128)LODWORD(bodyB[v15 + 55]);
  _mm_storel_ps((double *)&conn->contactPoint.x, v13);
  v18 = (__m128i)_mm_xor_ps(
                   _mm_mul_ps(_mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v14), 80)), _mm_unpacklo_ps(v16, v17)),
                   *(__m128 *)&stru_3E4970.x);
  LODWORD(conn->contactPoint.z) = z_low.m128_i32[0];
  *(_QWORD *)&conn->normal.x = v18.m128i_i64[0];
  conn->normal.z = -v9.m128_f32[0];
  conn->depth = (float)((float)((float)(v12 - _mm_shuffle_ps(v13, v13, 229).m128_f32[0])
                              * *(float *)_mm_shuffle_epi32(v18, 229).m128i_i32)
                      + (float)((float)(v11 - v13.m128_f32[0]) * *(float *)v18.m128i_i32))
              - (float)((float)(x_low.m128_f32[0] - z_low.m128_f32[0]) * v9.m128_f32[0]);
}


// Address: 0x1e068e0 | Name: _ZN3RBX9Collision17BlockBlockContact27updateEdgeEdgeFaceCollisionEPNS0_29FeaturePolyCollisionConnectorERKN3G3D7Vector3ES7_NS_8NormalIdES8_S8_ff
void __fastcall RBX::Collision::BlockBlockContact::updateEdgeEdgeFaceCollision(
        RBX::Collision::FeaturePolyCollisionConnector *conn,
        const RBX::Vector3 *_edge0,
        const RBX::Vector3 *_edge1,
        int _normal0,
        int _normal1,
        RBX::NormalId _planeID,
        float _edgeLength0,
        float _edgeLength1,
        double a9,
        double a10,
        double a11,
        double a12,
        __m128 a13)
{
  __m128 v13; // xmm9
  RBX::Body *bodyA; // r11
  RBX::Body *bodyB; // r10
  __m128 v16; // xmm10
  __m128 v17; // xmm15
  __m128 v18; // xmm5
  __m128 v19; // xmm8
  __m128 v20; // xmm13
  __m128 v21; // xmm14
  __int64 v22; // r14
  __m128 v23; // xmm2
  __m128 v24; // xmm3
  float v25; // xmm4_4
  __m128 v26; // xmm3
  __m128 v27; // xmm9
  __m128 v28; // xmm12
  __int32 v29; // ebx
  __int64 v30; // r8
  __m128 v31; // xmm3
  __m128 v32; // xmm2
  float v33; // xmm11_4
  __m128 v34; // xmm6
  float v35; // xmm8_4
  __m128 v36; // xmm3
  __m128 v37; // xmm13
  float x; // xmm0_4
  float v39; // xmm4_4
  float y; // xmm14_4
  float z; // xmm2_4
  float v42; // xmm5_4
  float v43; // xmm1_4
  float v44; // xmm2_4
  float v45; // xmm3_4
  float v46; // xmm0_4
  float v47; // xmm2_4
  float v48; // xmm5_4
  float v49; // xmm10_4
  float v50; // xmm2_4
  __m128 v51; // xmm3
  float v52; // xmm1_4
  float v53; // xmm7_4
  __m128 z_low; // xmm0
  __m128 v55; // xmm15
  float v56; // xmm14_4
  float v57; // xmm4_4
  __m128 v58; // xmm8
  float v59; // xmm7_4
  float v60; // xmm12_4
  __m128 v61; // xmm8
  signed int v62; // eax
  __int64 v63; // rcx
  float v64; // xmm9_4
  bool v65; // cc
  float v66; // xmm4_4
  float v67; // xmm11_4
  __m128 v68; // xmm6
  __m128 v69; // xmm13
  __m128 v70; // xmm0
  __m128 v71; // xmm2
  __m128 v72; // xmm7
  __m128 v73; // xmm1
  float v74; // xmm10_4
  float v75; // xmm5_4
  float v76; // xmm14_4
  __m128 v77; // xmm11
  __m128 v78; // xmm0
  float v79; // xmm9_4
  __m128 v80; // xmm4
  __m128 v81; // xmm1
  __m128 v82; // xmm6
  __m128 v83; // xmm2
  __m128 v84; // xmm1
  __m128 v85; // xmm11
  float v86; // xmm13_4
  float v87; // [rsp+0h] [rbp-168h]
  float v88; // [rsp+4h] [rbp-164h]
  float v89; // [rsp+8h] [rbp-160h]
  float v90; // [rsp+Ch] [rbp-15Ch]
  float v92; // [rsp+14h] [rbp-154h]
  float v93; // [rsp+18h] [rbp-150h]
  float v94; // [rsp+1Ch] [rbp-14Ch]
  float v95; // [rsp+20h] [rbp-148h]
  float v96; // [rsp+24h] [rbp-144h]
  float v98; // [rsp+2Ch] [rbp-13Ch]
  double v99; // [rsp+30h] [rbp-138h] BYREF
  float v100; // [rsp+38h] [rbp-130h]
  double v101; // [rsp+40h] [rbp-128h] BYREF
  __int32 v102; // [rsp+48h] [rbp-120h]
  __m128 v103; // [rsp+50h] [rbp-118h]
  __m128 v104; // [rsp+60h] [rbp-108h]
  __m128i v105; // [rsp+70h] [rbp-F8h]
  __m128i v106; // [rsp+80h] [rbp-E8h]
  __m128i v107; // [rsp+90h] [rbp-D8h]
  __m128 v108; // [rsp+A0h] [rbp-C8h]
  __m128 v109; // [rsp+B0h] [rbp-B8h]
  __m128 v110; // [rsp+C0h] [rbp-A8h]
  __m128 v111; // [rsp+D0h] [rbp-98h]
  __m128 v112; // [rsp+E0h] [rbp-88h]
  __m128 v113; // [rsp+F0h] [rbp-78h]
  __m128i v114; // [rsp+100h] [rbp-68h]
  __m128i v115; // [rsp+110h] [rbp-58h]
  __m128i v116; // [rsp+120h] [rbp-48h]
  __m128i v117; // [rsp+130h] [rbp-38h]
  __m128i v118; // [rsp+140h] [rbp-28h]

  conn->param0 = _normal0;
  conn->param1 = _normal1;
  bodyA = conn->bodyA;
  bodyB = conn->bodyB;
  v16 = (__m128)_mm_loadl_epi64((const __m128i *)&conn->bodyA->pv);
  v17 = (__m128)_mm_loadl_epi64((const __m128i *)conn->bodyA->pv.position.rotation.elt[1]);
  v18 = (__m128)*(unsigned __int64 *)&conn->bodyA->pv.position.rotation.elt[2][0];
  v19 = (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[0][2]);
  v20 = (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[1][2]);
  v21 = (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[2][2]);
  v13.m128_f32[0] = (float)((-2 * (_normal0 / 3)) | 1);
  v22 = _normal0 % 3;
  v23 = (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[0][v22]);
  v23.m128_f32[0] = v23.m128_f32[0] * v13.m128_f32[0];
  v24 = (__m128)LODWORD(conn->bodyA->pv.position.rotation.elt[1][v22]);
  v24.m128_f32[0] = v24.m128_f32[0] * v13.m128_f32[0];
  v13.m128_f32[0] = v13.m128_f32[0] * conn->bodyA->pv.position.rotation.elt[2][v22];
  v25 = conn->bodyA->pv.position.rotation.elt[0][2] * v23.m128_f32[0];
  v28 = v20;
  v28.m128_f32[0] = v20.m128_f32[0] * v24.m128_f32[0];
  v26 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v24, v24, 224), v17), _mm_mul_ps(_mm_shuffle_ps(v23, v23, 224), v16));
  v23.m128_f32[0] = conn->bodyA->pv.position.rotation.elt[2][2] * v13.m128_f32[0];
  v27 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v13, v13, 224), v18), v26);
  v28.m128_f32[0] = (float)(v28.m128_f32[0] + v25) + v23.m128_f32[0];
  v29 = (-2 * (_normal1 / 3)) | 1;
  v30 = _normal1 % 3;
  v31 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][v30]);
  v31.m128_f32[0] = v31.m128_f32[0] * (float)v29;
  v32 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][v30]);
  v32.m128_f32[0] = v32.m128_f32[0] * (float)v29;
  v106 = _mm_shuffle_epi32((__m128i)v16, 229);
  v107 = _mm_shuffle_epi32((__m128i)v17, 229);
  a13.m128_f32[0] = (float)v29 * bodyB->pv.position.rotation.elt[2][v30];
  v105 = _mm_shuffle_epi32((__m128i)v18, 229);
  v33 = (float)(*(float *)v105.m128i_i32 * a13.m128_f32[0])
      + (float)((float)(*(float *)v107.m128i_i32 * v32.m128_f32[0]) + (float)(*(float *)v106.m128i_i32 * v31.m128_f32[0]));
  v104 = v19;
  v108 = v20;
  v103 = v18;
  v34 = _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(a13, a13, 224), _mm_unpacklo_ps(v21, v18)),
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v32, v32, 224), _mm_unpacklo_ps(v20, v17)),
            _mm_mul_ps(_mm_shuffle_ps(v31, v31, 224), _mm_unpacklo_ps(v19, v16))));
  v35 = _mm_shuffle_ps(v27, v27, 229).m128_f32[0];
  v36 = _mm_mul_ps(_mm_unpacklo_ps(v28, v27), v34);
  v37 = _mm_shuffle_ps(v36, v36, 229);
  v37.m128_f32[0] = (float)(v37.m128_f32[0] + (float)(v35 * v33)) + v36.m128_f32[0];
  if ( fabs(fabs(v37.m128_f32[0]) + -1.0) <= 0.00001 )
    goto LABEL_4;
  v118 = _mm_loadl_epi64((const __m128i *)&bodyB->pv);
  x = _edge1->x;
  v39 = v21.m128_f32[0];
  v112 = v21;
  y = _edge1->y;
  v98 = bodyB->pv.position.rotation.elt[0][2];
  z = _edge1->z;
  v42 = (float)(v98 * z)
      + (float)((float)(*(float *)_mm_shuffle_epi32(v118, 229).m128i_i32 * y) + (float)(*(float *)v118.m128i_i32 * x));
  v117 = (__m128i)*(unsigned __int64 *)&bodyB->pv.position.rotation.elt[1][0];
  v96 = bodyB->pv.position.rotation.elt[1][2];
  v43 = (float)(z * v96)
      + (float)((float)(*(float *)_mm_shuffle_epi32(v117, 229).m128i_i32 * y) + (float)(x * *(float *)v117.m128i_i32));
  v116 = _mm_loadl_epi64((const __m128i *)bodyB->pv.position.rotation.elt[2]);
  v95 = bodyB->pv.position.rotation.elt[2][2];
  v44 = (float)(z * v95)
      + (float)((float)(*(float *)_mm_shuffle_epi32(v116, 229).m128i_i32 * y) + (float)(x * *(float *)v116.m128i_i32));
  v94 = bodyB->pv.position.translation.x;
  v93 = bodyB->pv.position.translation.y;
  v89 = v42 + v94;
  v115 = (__m128i)*(unsigned __int64 *)&bodyA->pv.position.translation.x;
  v45 = (float)(v42 + v94) - *(float *)v115.m128i_i32;
  v114 = _mm_shuffle_epi32(v115, 229);
  v88 = v43 + v93;
  v46 = (float)(v43 + v93) - *(float *)v114.m128i_i32;
  v92 = bodyB->pv.position.translation.z;
  v87 = bodyA->pv.position.translation.z;
  v90 = v44 + v92;
  v47 = (float)(v44 + v92) - v87;
  v48 = (float)(v103.m128_f32[0] * v47) + (float)((float)(v46 * v17.m128_f32[0]) + (float)(v45 * v16.m128_f32[0]));
  v113 = v16;
  v49 = (float)(*(float *)v105.m128i_i32 * v47)
      + (float)((float)(*(float *)v107.m128i_i32 * v46) + (float)(*(float *)v106.m128i_i32 * v45));
  v50 = (float)(v47 * v39) + (float)((float)(v46 * v108.m128_f32[0]) + (float)(v45 * v104.m128_f32[0]));
  v51 = (__m128)*(unsigned __int64 *)&_edge0->x;
  v52 = COERCE_FLOAT(*(_QWORD *)&_edge0->x) - v48;
  v53 = _mm_shuffle_ps(v51, v51, 229).m128_f32[0] - v49;
  z_low = (__m128)LODWORD(_edge0->z);
  v111 = v17;
  v55 = z_low;
  v56 = (float)((float)(z_low.m128_f32[0] - v50) * v28.m128_f32[0])
      + (float)((float)(v35 * v53) + (float)(v52 * v27.m128_f32[0]));
  v57 = _mm_shuffle_ps(v34, v34, 229).m128_f32[0];
  v55.m128_f32[0] = (float)((float)(z_low.m128_f32[0] - v50) * v34.m128_f32[0])
                  + (float)((float)(v53 * v33) + (float)(v52 * v57));
  v58 = v37;
  v59 = 1.0 - (float)(v37.m128_f32[0] * v37.m128_f32[0]);
  v58.m128_f32[0] = (float)((float)((float)(v37.m128_f32[0] * v55.m128_f32[0])
                                  - (float)(v37.m128_f32[0] * (float)(v56 * v37.m128_f32[0])))
                          / v59)
                  - v56;
  v60 = v28.m128_f32[0] * v58.m128_f32[0];
  v61 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v58, v58, 224), v27), v51);
  v62 = (-2 * (_planeID / 3)) | 1;
  v63 = _planeID % 3;
  v64 = (float)v62 * bodyB->pv.position.rotation.elt[2][v63];
  v28.m128_f32[0] = v60 + z_low.m128_f32[0];
  v110 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][v63]);
  v109 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][v63]);
  _mm_storel_ps(&v101, v61);
  v102 = v28.m128_i32[0];
  v65 = fabs(*((float *)&v101 + v22)) <= _edgeLength0 * 0.5 + 0.05000000074505806;
  v55.m128_f32[0] = (float)(v55.m128_f32[0] - (float)(v56 * v37.m128_f32[0])) / v59;
  v66 = (float)(v57 * v55.m128_f32[0]) + v48;
  v67 = (float)(v33 * v55.m128_f32[0]) + v49;
  v55.m128_f32[0] = (float)(v55.m128_f32[0] * v34.m128_f32[0]) + v50;
  v68 = v113;
  v69 = v104;
  v70 = v104;
  v70.m128_f32[0] = (float)(v104.m128_f32[0] * v55.m128_f32[0])
                  + (float)((float)(*(float *)v106.m128i_i32 * v67) + (float)(v113.m128_f32[0] * v66));
  v71 = v111;
  v72 = v108;
  v73 = v108;
  v73.m128_f32[0] = (float)((float)(v108.m128_f32[0] * v55.m128_f32[0])
                          + (float)((float)(*(float *)v107.m128i_i32 * v67) + (float)(v111.m128_f32[0] * v66)))
                  + *(float *)v114.m128i_i32;
  v74 = v103.m128_f32[0];
  v75 = *(float *)v105.m128i_i32;
  v76 = v112.m128_f32[0];
  v55.m128_f32[0] = (float)(v55.m128_f32[0] * v112.m128_f32[0])
                  + (float)((float)(v67 * *(float *)v105.m128i_i32) + (float)(v66 * v103.m128_f32[0]));
  v77 = (__m128)v115;
  v70.m128_f32[0] = (float)(v70.m128_f32[0] + *(float *)v115.m128i_i32) - v94;
  v73.m128_f32[0] = v73.m128_f32[0] - v93;
  v55.m128_f32[0] = (float)(v55.m128_f32[0] + v87) - v92;
  _mm_storel_ps(
    &v99,
    _mm_add_ps(
      _mm_mul_ps(_mm_shuffle_ps(v55, v55, 224), (__m128)v116),
      _mm_add_ps(
        _mm_mul_ps(_mm_shuffle_ps(v73, v73, 224), (__m128)v117),
        _mm_mul_ps(_mm_shuffle_ps(v70, v70, 224), (__m128)v118))));
  v100 = (float)((float)(v96 * v73.m128_f32[0]) + (float)(v98 * v70.m128_f32[0])) + (float)(v95 * v55.m128_f32[0]);
  if ( !v65 )
    goto LABEL_4;
  if ( fabs(*((float *)&v99 + v30)) <= _edgeLength1 * 0.5 + 0.05000000074505806 )
  {
    v78 = _mm_xor_ps(
            _mm_mul_ps(_mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v62), 80)), _mm_unpacklo_ps(v110, v109)),
            *(__m128 *)&stru_3E4970.x);
    v79 = -v64;
    v80 = v68;
    v81 = v68;
    v82 = v71;
    v83 = _mm_mul_ps(_mm_shuffle_ps(v61, v61, 224), _mm_unpacklo_ps(v81, v71));
    v84 = _mm_shuffle_ps(v61, v61, 229);
    v85 = _mm_add_ps(
            v77,
            _mm_add_ps(
              _mm_mul_ps(_mm_shuffle_ps(v28, v28, 224), _mm_shuffle_ps(_mm_shuffle_ps(v72, v69, 0), v69, 226)),
              _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(v82, v80, 17), v80, 226), v84), v83)));
    v86 = v87
        + (float)((float)((float)(v75 * v84.m128_f32[0]) + (float)(v74 * v61.m128_f32[0]))
                + (float)(v76 * v28.m128_f32[0]));
    _mm_storel_ps((double *)&conn->contactPoint.x, v85);
    conn->contactPoint.z = v86;
    _mm_storel_ps((double *)&conn->normal.x, v78);
    conn->normal.z = v79;
    conn->depth = (float)((float)(v90 - v86) * v79)
                + (float)((float)((float)(v88 - _mm_shuffle_ps(v85, v85, 229).m128_f32[0])
                                * *(float *)_mm_shuffle_epi32((__m128i)v78, 229).m128i_i32)
                        + (float)((float)(v89 - v85.m128_f32[0]) * v78.m128_f32[0]));
  }
  else
  {
LABEL_4:
    *(_QWORD *)&conn->normal.x = 0;
    conn->normal.z = 0.0;
  }
}


// Address: 0x1e070a0 | Name: _ZN3RBX9Collision17BlockBlockContact35findFeatureCollisionsUpdateContactsERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
bool __fastcall RBX::Collision::BlockBlockContact::findFeatureCollisionsUpdateContacts(
        RBX::Collision::BlockBlockContact *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors,
        __m128 a3,
        float overlapIgnored)
{
  bool result; // al
  int v6; // r13d
  int v7; // r14d
  int v8; // r8d
  __int64 v9; // rdx
  unsigned int v10; // r12d
  __int64 v11; // rsi
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // r15
  int v13; // r13d
  __int64 v14; // rcx
  const RBX::Vector3 *v15; // rsi
  signed int v16; // r8d
  __int64 v17; // rcx
  bool planeContact; // [rsp+7h] [rbp-61h] BYREF
  int v19; // [rsp+8h] [rbp-60h]
  int v20; // [rsp+Ch] [rbp-5Ch]
  __m128 v21; // [rsp+10h] [rbp-58h]
  __int64 v22; // [rsp+20h] [rbp-48h]
  RBX::NormalId _normal1[2]; // [rsp+28h] [rbp-40h]
  RBX::NormalId _normal0[14]; // [rsp+30h] [rbp-38h]

  planeContact = 0;
  v21 = a3;
  if ( !RBX::Collision::BlockBlockContact::getBestPlaneEdge(this, a3.m128_f32[0], overlapIgnored, &planeContact) )
  {
    *(_QWORD *)this->feature = -1;
    return 0;
  }
  if ( !RBX::Collision::Contact::getInContact(this) )
    RBX::Collision::BlockBlockContact::getBestPlaneEdge(this, v21.m128_f32[0], overlapIgnored, &planeContact);
  if ( planeContact )
    return RBX::Collision::BlockBlockContact::computePlaneContact(
             this,
             newCollisionConnectors,
             v21.m128_f32[0],
             overlapIgnored) > 0;
  v6 = this->feature[0];
  v7 = this->feature[1];
  v8 = v7 - 6;
  v22 = ((unsigned int)((v6 - 6) >> 31) >> 30) + v6 - 6;
  v20 = (int)v22 >> 2;
  v9 = ((int)v22 >> 2) + 3 * (v6 - ((((unsigned int)(v6 - 6) >> 31) + v6 - 6) & 0xFFFFFFFE) - 6);
  if ( v6 >= 19 )
    v9 = (unsigned int)(((int)v9 + 3) % 6);
  v10 = v8 + ((unsigned int)(v8 >> 31) >> 30);
  v19 = v8 / 4;
  v11 = (unsigned int)(v8 / 4 + 3 * (v8 % 2));
  if ( v7 >= 19 )
    v11 = (unsigned int)(((int)v11 + 3) % 6);
  *(_QWORD *)_normal1 = v11;
  *(_QWORD *)_normal0 = v9;
  CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                         newCollisionConnectors,
                         this->prim0,
                         this->prim1,
                         RBX::Collision::FeaturePolyPair::EDGE_EDGE_PAIR);
  if ( v6 > 17 )
  {
    v14 = (unsigned int)((int)(((unsigned int)((v6 - 18) >> 31) >> 30) + v6 - 18) >> 2);
    v13 = v6 - 17;
  }
  else
  {
    v13 = v6 - (v22 & 0xFFFFFFFC) - 6;
    v14 = v20;
  }
  v15 = (const RBX::Vector3 *)(*(_QWORD *)(*((_QWORD *)this->prim0 + 18) + 72LL) + 12LL * dword_56F9F0[4 * v14 + v13]);
  if ( v7 > 17 )
  {
    v17 = (unsigned int)((int)(v7 + ((unsigned int)((v7 - 18) >> 31) >> 30) - 18) >> 2);
    v16 = v7 - 17;
  }
  else
  {
    v16 = v7 - 6 - (v10 & 0xFFFFFFFC);
    v17 = v19;
  }
  RBX::Collision::BlockBlockContact::updateEdgeEdgeCollision(
    CollisionConnector,
    v15,
    (const RBX::Vector3 *)(*(_QWORD *)(*((_QWORD *)this->prim1 + 18) + 72LL) + 12LL * dword_56F9F0[4 * v17 + v16]),
    _normal0[0],
    _normal1[0]);
  result = 1;
  if ( CollisionConnector->depth >= (float)-v21.m128_f32[0] )
  {
    *(_QWORD *)&CollisionConnector->normal.x = 0;
    CollisionConnector->normal.z = 0.0;
    return 0;
  }
  return result;
}


// Address: 0x1e07310 | Name: _ZN3RBX9Collision17BlockBlockContact23updateEdgeEdgeCollisionEPNS0_29FeaturePolyCollisionConnectorERKN3G3D7Vector3ES7_NS_8NormalIdES8_
void __fastcall RBX::Collision::BlockBlockContact::updateEdgeEdgeCollision(
        RBX::Collision::FeaturePolyCollisionConnector *conn,
        const RBX::Vector3 *_edge0,
        const RBX::Vector3 *_edge1,
        RBX::NormalId _normal0,
        RBX::NormalId _normal1)
{
  RBX::Body *bodyA; // rdi
  RBX::Body *bodyB; // r9
  signed int v8; // ebx
  __int64 v9; // rax
  __m128 v10; // xmm10
  float v11; // xmm8_4
  signed int v12; // ecx
  __int64 v13; // rax
  float v14; // xmm2_4
  __m128 v15; // xmm12
  __m128 v16; // xmm1
  float v17; // xmm4_4
  float v18; // xmm13_4
  __m128 x_low; // xmm3
  __m128 y_low; // xmm1
  __m128 z_low; // xmm15
  __m128 v22; // xmm7
  __m128 v23; // xmm3
  __m128 v24; // xmm5
  __m128 v25; // xmm14
  __m128 v26; // xmm7
  __m128 v27; // xmm3
  __m128 v28; // xmm1
  float v29; // xmm8_4
  __m128 v30; // xmm1
  float v31; // xmm8_4
  float v32; // xmm2_4
  __m128 v33; // xmm3
  float v34; // xmm2_4
  __m128 v35; // xmm0
  __m128 v36; // xmm1
  G3D::Vector3 v37; // [rsp+0h] [rbp-48h] BYREF
  __m128 v38; // [rsp+10h] [rbp-38h]
  __m128 v39; // [rsp+20h] [rbp-28h]

  conn->param0 = _normal0;
  conn->param1 = _normal1;
  bodyA = conn->bodyA;
  bodyB = conn->bodyB;
  v8 = (-2 * (_normal0 / 3)) | 1;
  v9 = _normal0 % 3;
  v10 = _mm_mul_ps(
          _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v8), 80)),
          _mm_unpacklo_ps(
            (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][v9]),
            (__m128)LODWORD(bodyA->pv.position.rotation.elt[1][v9])));
  v11 = (float)v8 * bodyA->pv.position.rotation.elt[2][v9];
  v12 = (-2 * (_normal1 / 3)) | 1;
  v13 = _normal1 % 3;
  v14 = (float)v12 * bodyB->pv.position.rotation.elt[2][v13];
  v15 = _mm_mul_ps(
          _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v12), 80)),
          _mm_unpacklo_ps(
            (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][v13]),
            (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][v13])));
  v16 = _mm_mul_ps(v10, v15);
  v17 = (float)(v11 * v14) + (float)(_mm_shuffle_ps(v16, v16, 229).m128_f32[0] + v16.m128_f32[0]);
  v18 = 1.0 - (float)(v17 * v17);
  if ( v18 <= 0.000001 )
  {
    *(_QWORD *)&conn->normal.x = 0;
    conn->normal.z = 0.0;
  }
  else
  {
    x_low = (__m128)LODWORD(_edge0->x);
    y_low = (__m128)LODWORD(_edge0->y);
    z_low = (__m128)LODWORD(_edge0->z);
    v38 = _mm_add_ps(
            (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.x,
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(z_low, z_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][2]),
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[1][2]))),
              _mm_add_ps(
                _mm_mul_ps(
                  _mm_shuffle_ps(y_low, y_low, 224),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][1]),
                    (__m128)LODWORD(bodyA->pv.position.rotation.elt[1][1]))),
                _mm_mul_ps(
                  _mm_shuffle_ps(x_low, x_low, 224),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][0]),
                    (__m128)LODWORD(bodyA->pv.position.rotation.elt[1][0]))))));
    z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * bodyA->pv.position.rotation.elt[2][2])
                              + (float)((float)(y_low.m128_f32[0] * bodyA->pv.position.rotation.elt[2][1])
                                      + (float)(x_low.m128_f32[0] * bodyA->pv.position.rotation.elt[2][0])))
                      + bodyA->pv.position.translation.z;
    v22 = (__m128)LODWORD(_edge1->x);
    v23 = (__m128)LODWORD(_edge1->y);
    v24 = (__m128)LODWORD(_edge1->z);
    v25 = _mm_add_ps(
            (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(v24, v24, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]))),
              _mm_add_ps(
                _mm_mul_ps(
                  _mm_shuffle_ps(v23, v23, 224),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]),
                    (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]))),
                _mm_mul_ps(
                  _mm_shuffle_ps(v22, v22, 224),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]),
                    (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]))))));
    v24.m128_f32[0] = (float)((float)(v24.m128_f32[0] * bodyB->pv.position.rotation.elt[2][2])
                            + (float)((float)(v23.m128_f32[0] * bodyB->pv.position.rotation.elt[2][1])
                                    + (float)(v22.m128_f32[0] * bodyB->pv.position.rotation.elt[2][0])))
                    + bodyB->pv.position.translation.z;
    y_low.m128_f32[0] = _mm_shuffle_ps(v25, v25, 229).m128_f32[0] - _mm_shuffle_ps(v38, v38, 229).m128_f32[0];
    v26 = v24;
    v26.m128_f32[0] = v24.m128_f32[0] - z_low.m128_f32[0];
    v27 = v26;
    v27.m128_f32[0] = (float)((float)(v24.m128_f32[0] - z_low.m128_f32[0]) * v11)
                    + (float)((float)(_mm_shuffle_ps(v10, v10, 229).m128_f32[0] * y_low.m128_f32[0])
                            + (float)((float)(v25.m128_f32[0] - v38.m128_f32[0]) * v10.m128_f32[0]));
    v26.m128_f32[0] = (float)((float)(v24.m128_f32[0] - z_low.m128_f32[0]) * v14)
                    + (float)((float)(y_low.m128_f32[0] * _mm_shuffle_ps(v15, v15, 229).m128_f32[0])
                            + (float)((float)(v25.m128_f32[0] - v38.m128_f32[0]) * v15.m128_f32[0]));
    v28 = v27;
    v28.m128_f32[0] = (float)(v27.m128_f32[0] - (float)(v26.m128_f32[0] * v17)) * (float)(1.0 / v18);
    v27.m128_f32[0] = (float)((float)(v27.m128_f32[0] * v17) - v26.m128_f32[0]) * (float)(1.0 / v18);
    v29 = v11 * v28.m128_f32[0];
    v30 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v28, v28, 224), v10), v38);
    v31 = v29 + z_low.m128_f32[0];
    v32 = v14 * v27.m128_f32[0];
    v33 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v27, v27, 224), v15), v25);
    v34 = v32 + v24.m128_f32[0];
    v35 = _mm_add_ps(v30, v33);
    v36 = _mm_sub_ps(v30, v33);
    _mm_storel_ps((double *)&v37.x, v36);
    v37.z = v31 - v34;
    v39 = _mm_mul_ps(v35, *(__m128 *)&stru_3EB1B0.x);
    v38.m128_f32[0] = (float)(v31 + v34) * 0.5;
    v35.m128_f32[0] = G3D::Vector3::unitize(&v37, v36.m128_f32[0]);
    _mm_storel_ps((double *)&conn->contactPoint.x, v39);
    LODWORD(conn->contactPoint.z) = v38.m128_i32[0];
    conn->normal = v37;
    conn->depth = -v35.m128_f32[0];
  }
}


// Address: 0x1e076f0 | Name: _GLOBAL__sub_I_BlockBlockContact.cpp
void __cdecl GLOBAL__sub_I_BlockBlockContact_cpp()
{
  qword_2AAF740 = (__int64)boost::system::generic_category();
  qword_2AAF748 = (__int64)boost::system::generic_category();
  qword_2AAF750 = (__int64)boost::system::system_category();
}


