// Address: 0x1037e30 | Name: _ZN3RBX8Animator13loadAnimationEN5boost10shared_ptrINS_8InstanceEEE
RBX::Animator *__fastcall RBX::Animator::loadAnimation(RBX::Animator *this, boost::shared_ptr<RBX::Instance> instance)
{
  boost::detail::sp_counted_base *pi; // rbx
  unsigned int v3; // r14d
  __int64 v4; // rbp
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  int (**v6)(void); // rax
  __int64 v7; // rcx
  RBX::Instance *parent; // rbp
  float v9; // xmm0_4
  const RBX::ModelInstance *ConstLocalCharacter; // rax
  boost::shared_ptr<RBX::AnimationTrack> v11; // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::detail::sp_counted_base *v13; // rbx
  volatile signed __int32 *v14; // rbx
  boost::detail::sp_counted_base *v16; // rbp
  RBX *v17; // rbp
  RBX *exception; // rbp
  RBX *v19; // r15
  RBX::Instance *v20; // rdi
  __int64 v21; // rax
  const char *v22; // rbx
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *h; // rcx
  const char *v24; // rcx
  boost::shared_ptr<RBX::Animator> v25; // [rsp+8h] [rbp-70h] BYREF
  void *ptr; // [rsp+18h] [rbp-60h]
  RBX::Instance *context[2]; // [rsp+20h] [rbp-58h] BYREF
  boost::shared_ptr<const RBX::KeyframeSequence> args; // [rsp+30h] [rbp-48h] BYREF
  __int128 v29; // [rsp+40h] [rbp-38h]

  pi = instance.pn.pi_;
  v3 = RBX::Memory::setCurrentCategory(dword_2A04350);
  if ( !pi->_vptr$sp_counted_base
    || (v4 = *((_QWORD *)pi->_vptr$sp_counted_base + 3),
        DescriptorPtr = Class_getDescriptorPtr(0),
        *(unsigned __int16 *)(v4 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364)) )
  {
    *(_OWORD *)context = 0;
    goto LABEL_29;
  }
  v6 = pi->_vptr$sp_counted_base;
  context[0] = (RBX::Instance *)pi->_vptr$sp_counted_base;
  v7 = *(_QWORD *)&pi->use_count_;
  context[1] = (RBX::Instance *)v7;
  if ( v7 )
    _InterlockedAdd((volatile signed __int32 *)(v7 + 8), 1u);
  if ( !v6 )
  {
LABEL_29:
    exception = (RBX *)__cxa_allocate_exception(0x10u);
    RBX::runtime_error(exception, "LoadAnimation requires an Animation object");
    __cxa_throw(
      exception,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  parent = instance.px->parent;
  v9 = 50.0;
  if ( parent )
  {
    if ( stru_2A012F0.value )
    {
      ConstLocalCharacter = RBX::Players::findConstLocalCharacter(instance.px->parent);
      v9 = 50.0;
      if ( ConstLocalCharacter )
        v9 = flt_4905D8[parent->parent == (RBX::Instance *)ConstLocalCharacter];
    }
  }
  RBX::Animation::getKeyframeSequence((const RBX::Animation *)&args, context[0], v9);
  std::string::basic_string(&v25, &context[0][1]);
  if ( ((__int64)v25.px & 1) == 0 )
  {
    if ( LOBYTE(v25.px) >= 2u )
      goto LABEL_12;
LABEL_27:
    v17 = (RBX *)__cxa_allocate_exception(0x10u);
    RBX::runtime_error(v17, "LoadAnimation requires the asset id to not be empty");
    __cxa_throw(
      v17,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  v16 = v25.pn.pi_;
  operator delete(ptr);
  if ( !v16 )
    goto LABEL_27;
LABEL_12:
  if ( !args.px )
  {
    v19 = (RBX *)__cxa_allocate_exception(0x10u);
    v20 = instance.px->parent;
    if ( v20 )
      v21 = (*((__int64 (__fastcall **)(RBX::Instance *))v20->_vptr$EventSource + 5))(v20);
    else
      v21 = (*((__int64 (__fastcall **)(boost::shared_ptr<RBX::Instance>::element_type *))instance.px->_vptr$EventSource
             + 5))(instance.px);
    if ( (*(_BYTE *)v21 & 1) != 0 )
      v22 = *(const char **)(v21 + 16);
    else
      v22 = (const char *)(v21 + 1);
    if ( instance.px->parent )
    {
      RBX::Instance::getFullName((RBX::Instance *)&v25);
      if ( ((__int64)v25.px & 1) != 0 )
        v24 = (const char *)ptr;
      else
        v24 = (char *)&v25.px + 1;
    }
    else
    {
      h = instance.px->name.h.h;
      if ( (*(_BYTE *)h & 1) != 0 )
        v24 = (const char *)*((_QWORD *)h + 2);
      else
        v24 = (char *)h + 1;
    }
    RBX::runtime_error(v19, "LoadAnimation requires the %s object (%s) to be a descendant of the game object", v22, v24);
    __cxa_throw(
      v19,
      (struct type_info *)&`typeinfo for'std::runtime_error,
      (void (*)(void *))&std::runtime_error::~runtime_error);
  }
  RBX::shared_from<RBX::Animator>(&v25, (RBX::Animator *)instance.px);
  v11 = RBX::Creatable<RBX::Instance>::create<RBX::AnimationTrack,boost::shared_ptr<RBX::Animator> &,boost::shared_ptr<RBX::Animation> &,boost::shared_ptr<RBX::KeyframeSequence const> &>(
          &v25,
          (boost::shared_ptr<RBX::Animation> *)context,
          &args);
  (*(void (__fastcall **)(_QWORD, _QWORD, boost::detail::sp_counted_base *))(*(_QWORD *)v29 + 112LL))(
    v29,
    *((_QWORD *)pi->_vptr$sp_counted_base + 8),
    v11.pn.pi_);
  *(_OWORD *)this = v29;
  v12 = v25.pn.pi_;
  if ( v25.pn.pi_ )
  {
    if ( !_InterlockedSub(&v25.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 2))(v12);
      if ( !_InterlockedSub(&v12->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v12->_vptr$sp_counted_base + 3))(v12);
    }
  }
  v13 = args.pn.pi_;
  if ( args.pn.pi_ )
  {
    if ( !_InterlockedSub(&args.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
      if ( !_InterlockedSub(&v13->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
    }
  }
  v14 = (volatile signed __int32 *)context[1];
  if ( context[1] )
  {
    if ( !_InterlockedSub(
            (volatile signed __int32 *)&context[1]->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
            1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
      if ( !_InterlockedSub(v14 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 24LL))(v14);
    }
  }
  RBX::Memory::setCurrentCategory(v3);
  return this;
}


// Address: 0x10382e0 | Name: _ZN3RBX8Animator25getPlayingAnimationTracksEv
_OWORD *__fastcall RBX::Animator::getPlayingAnimationTracks(_OWORD *a1, RBX::Animator *this)
{
  _QWORD *v2; // r13
  __int64 v3; // rbp
  __int64 v4; // rbx
  unsigned __int64 v5; // r12
  const rbx::implementation::type_holder *holder; // rax
  std::vector<RBX::Reflection::Variant> *v8[2]; // [rsp+0h] [rbp-D8h]
  __m128i v9; // [rsp+20h] [rbp-B8h] BYREF
  RBX::Reflection::Variant __x; // [rsp+30h] [rbp-A8h] BYREF
  unsigned __int64 v11; // [rsp+A0h] [rbp-38h]

  v11 = __readfsqword(0x28u);
  boost::make_shared<std::vector<RBX::Reflection::Variant>>();
  v2 = (_QWORD *)*((_QWORD *)this + 38);
  if ( (_QWORD *)((char *)this + 296) != v2 )
  {
    v9 = _mm_unpacklo_epi64(
           (__m128i)(unsigned __int64)rbx::implementation::typed_holder<boost::shared_ptr<RBX::Instance>>::construct_func,
           (__m128i)(unsigned __int64)rbx::implementation::typed_holder<boost::shared_ptr<RBX::Instance>>::moveConstruct_func);
    do
    {
      v3 = v2[2];
      v4 = v2[3];
      if ( v4 )
        _InterlockedAdd((volatile signed __int32 *)(v4 + 8), 1u);
      __x._type = RBX::Reflection::Type::getSingleton<boost::shared_ptr<RBX::Instance>>();
      __x.value.holder = 0;
      *(_QWORD *)__x.value.data = v3;
      *(_QWORD *)&__x.value.data[8] = v4;
      if ( !(_BYTE)byte_29FB3C8 && __cxa_guard_acquire(&byte_29FB3C8) )
      {
        xmmword_29FB3B0 = (__int128)_mm_load_si128(&v9);
        qword_29FB3C0 = (__int64)rbx::implementation::typed_holder<boost::shared_ptr<RBX::Instance>>::destruct_func;
        __cxa_guard_release(&byte_29FB3C8);
      }
      __x.value.holder = (const rbx::implementation::type_holder *)&xmmword_29FB3B0;
      v5 = *((_QWORD *)v8[0] + 1);
      if ( v5 >= *((_QWORD *)v8[0] + 2) )
      {
        std::vector<RBX::Reflection::Variant>::__push_back_slow_path<RBX::Reflection::Variant>(v8[0], &__x);
        if ( __x.value.holder )
          __x.value.holder->destruct(__x.value.data);
      }
      else
      {
        *(_QWORD *)v5 = __x._type;
        *(_QWORD *)(v5 + 8) = 0;
        if ( __x.value.holder )
        {
          __x.value.holder->moveConstruct(__x.value.data, (char *)(v5 + 16));
          holder = __x.value.holder;
        }
        else
        {
          holder = 0;
        }
        *(_QWORD *)(v5 + 8) = holder;
        if ( __x.value.holder )
        {
          __x.value.holder->destruct(__x.value.data);
          __x.value.holder = 0;
        }
        __x._type = RBX::Reflection::Type::getSingleton<void>();
        if ( __x.value.holder )
        {
          __x.value.holder->destruct(__x.value.data);
          __x.value.holder = 0;
        }
        *((_QWORD *)v8[0] + 1) += 112LL;
      }
      v2 = (_QWORD *)v2[1];
    }
    while ( (_QWORD *)((char *)this + 296) != v2 );
  }
  *a1 = *(_OWORD *)v8;
  return a1;
}


// Address: 0x1038590 | Name: _ZN3RBX8Animator10manualStepEf
void __fastcall RBX::Animator::manualStep(RBX::Animator *this, float a2, double delta)
{
  RBX::Animator *v4; // rax
  RBX::Animator *v5; // rbx
  __int64 v6; // rbp
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  boost::shared_ptr<RBX::Instance>::element_type *px; // rax
  __int64 v9; // rax
  __int64 v10; // rbp
  unsigned __int64 v11; // r13
  __int64 v12; // rax
  __int64 (__fastcall ***v13)(_QWORD); // rdi
  _QWORD *v14; // rbx
  RBX::Primitive *v15; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer i; // rbp
  RBX::Assembly *next; // rbx
  RBX::Primitive *AssemblyPrimitive; // rax
  boost::unordered::detail::table<boost::unordered::detail::set<std::allocator<RBX::Assembly *>,RBX::Assembly *,boost::hash<RBX::Assembly *>,std::equal_to<RBX::Assembly *> > >::bucket_pointer buckets; // rbx
  size_t bucket_count; // rbp
  boost::unordered::detail::ptr_bucket::link_pointer v21; // rdi
  std::runtime_error *exception; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Assembly *>,RBX::Assembly *,boost::hash<RBX::Assembly *>,std::equal_to<RBX::Assembly *> > > v23; // [rsp+8h] [rbp-80h] BYREF
  RBX::Assembly *args; // [rsp+38h] [rbp-50h] BYREF
  _QWORD v25[2]; // [rsp+40h] [rbp-48h] BYREF
  char v26; // [rsp+50h] [rbp-38h]

  if ( this )
  {
    v4 = (RBX::Animator *)*((_QWORD *)this + 11);
    if ( v4 )
    {
      do
      {
        v5 = v4;
        v4 = (RBX::Animator *)*((_QWORD *)v4 + 11);
      }
      while ( v4 );
    }
    else
    {
      v5 = this;
    }
    v6 = *((_QWORD *)v5 + 3);
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *(unsigned __int16 *)(v6 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      px = RBX::ServiceProvider::refByClass<RBX::RunService>(v5)->px;
      if ( px )
      {
        if ( LODWORD(px[1].registry.px) == 1 )
        {
          exception = (std::runtime_error *)__cxa_allocate_exception(0x10u);
          std::runtime_error::runtime_error(
            exception,
            "Animator:StepAnimations() can only be used when the game is not running!");
          __cxa_throw(
            exception,
            (struct type_info *)&`typeinfo for'std::runtime_error,
            (void (*)(void *))&std::runtime_error::~runtime_error);
        }
      }
    }
  }
  v25[0] = 0;
  *(double *)&v25[1] = a2;
  v26 = 0;
  (*(void (__fastcall **)(RBX::Animator *, _QWORD *, double, double))(*(_QWORD *)this + 304LL))(this, v25, a2, delta);
  v23.current_ = 0;
  *(_OWORD *)&v23.bucket_count_ = 0x10u;
  v23.mlf_ = 1.0;
  *(_OWORD *)&v23.max_load_ = 0;
  v9 = *((_QWORD *)this + 31);
  if ( *((_QWORD *)this + 32) != v9 )
  {
    v10 = 0;
    v11 = 0;
    do
    {
      v12 = *(_QWORD *)(v9 + v10 + 8);
      if ( v12 )
      {
        if ( *(_DWORD *)(v12 + 8) )
        {
          v13 = *(__int64 (__fastcall ****)(_QWORD))(*((_QWORD *)this + 31) + v10 + 16);
          v14 = (_QWORD *)(**v13)(v13);
          (*(void (__fastcall **)(_QWORD *, double))(*v14 + 136LL))(v14, a2);
          v15 = (RBX::Primitive *)v14[3];
          if ( v15 )
          {
            args = RBX::Assembly::getPrimitiveAssembly(v15);
            if ( args )
              boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Assembly *>,RBX::Assembly *,boost::hash<RBX::Assembly *>,std::equal_to<RBX::Assembly *>>>::emplace_impl<RBX::Assembly * const&>(
                &v23,
                &args,
                &args);
          }
        }
      }
      ++v11;
      v9 = *((_QWORD *)this + 31);
      v10 += 32;
    }
    while ( v11 < (*((_QWORD *)this + 32) - v9) >> 5 );
    if ( v23.size_ )
    {
      for ( i = v23.buckets_[v23.bucket_count_].next_; i; i = i->next_ )
      {
        next = (RBX::Assembly *)i[2].next_;
        RBX::Assembly::notifyMovedFromExternal(next);
        if ( stru_2A01578.value )
        {
          AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(next);
          RBX::ContactManager::onAssemblyMovedFromStep(
            *(RBX::ContactManager **)(*((_QWORD *)AssemblyPrimitive + 17) + 784LL),
            next);
        }
      }
    }
  }
  buckets = v23.buckets_;
  if ( v23.buckets_ )
  {
    if ( v23.size_ )
    {
      bucket_count = v23.bucket_count_;
      v21 = v23.buckets_[v23.bucket_count_].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)v21->next_;
        operator delete(v21);
        --v23.size_;
        v21 = buckets[bucket_count].next_;
      }
      while ( v21 );
      buckets = v23.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&v23.max_load_ = 0;
  }
}


// Address: 0x10388b0 | Name: _ZN3RBX8AnimatorC2Ev
void __fastcall RBX::Animator::Animator(RBX::Animator *this)
{
  void *v1; // rdi
  boost::_bi::bind_t<void,boost::_mfi::mf7<void,RBX::Animator,RBX::ContentId,bool,float,float,float,float,int>,boost::_bi::list8<boost::_bi::value<RBX::Animator *>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6>,boost::arg<7> > > function; // [rsp+10h] [rbp-58h] BYREF
  void *ptr; // [rsp+30h] [rbp-38h]

  RBX::Instance::Instance((RBX::Instance *)this);
  *(_QWORD *)this = &off_288D6D8;
  *((_QWORD *)this + 3) = Class_getDescriptorPtr(this);
  *((_DWORD *)this + 34) = 2;
  *((_QWORD *)this + 18) = 0;
  *(_QWORD *)this = &off_288D1A0;
  *((_QWORD *)this + 16) = &off_288D2E8;
  *(_OWORD *)((char *)this + 168) = 0;
  *(_OWORD *)((char *)this + 152) = 0;
  *((RBX::Time *)this + 23) = RBX::Time::now<(RBX::Time::SampleMethod)2>();
  *((__m128i *)this + 12) = _mm_load_si128((const __m128i *)&xmmword_3E50A0);
  *(_OWORD *)((char *)this + 216) = 0;
  *((_QWORD *)this + 26) = (char *)this + 216;
  *(_OWORD *)((char *)this + 257) = 0;
  *(_OWORD *)((char *)this + 248) = 0;
  *(_OWORD *)((char *)this + 232) = 0;
  *(_OWORD *)((char *)this + 280) = 0;
  *((_QWORD *)this + 37) = (char *)this + 296;
  *((_QWORD *)this + 38) = (char *)this + 296;
  *(_OWORD *)((char *)this + 328) = 0;
  *(_OWORD *)((char *)this + 312) = 0;
  *((_QWORD *)&function.f_.f_ + 1) = 0;
  function.l_.a1_.t_ = 0;
  LOBYTE(function.f_.f_) = 16;
  *(boost::_mfi::mf7<void,RBX::Animator,RBX::ContentId,bool,float,float,float,float,int>::F *)((char *)&function.f_.f_
                                                                                             + 1) = (boost::_mfi::mf7<void,RBX::Animator,RBX::ContentId,bool,float,float,float,float,int>::F)0x726F74616D696E41LL;
  (*(void (__fastcall **)(RBX::Animator *, boost::_bi::bind_t<void,boost::_mfi::mf7<void,RBX::Animator,RBX::ContentId,bool,float,float,float,float,int>,boost::_bi::list8<boost::_bi::value<RBX::Animator *>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6>,boost::arg<7> > > *))(*(_QWORD *)this + 112LL))(
    this,
    &function);
  if ( ((__int64)function.f_.f_ & 1) != 0 )
    operator delete(function.l_.a1_.t_);
  if ( byte_2CE5418 )
    FLog::FastLog(byte_2CE5418, "Animator created - %p", this);
  function.f_ = (boost::_mfi::mf7<void,RBX::Animator,RBX::ContentId,bool,float,float,float,float,int>)(unsigned __int64)&RBX::Animator::onCombinedUpdate;
  function.l_.a1_.t_ = this;
  rbx::signal<void ()(void)>::operator()((rbx::signal<void ()> *)this + 41);
  rbx::signal<void ()(RBX::ContentId,bool,float,float,float,float,int)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf7<void,RBX::Animator,RBX::ContentId,bool,float,float,float,float,int>,boost::_bi::list8<boost::_bi::value<RBX::Animator*>,boost::arg<1>,boost::arg<2>,boost::arg<3>,boost::arg<4>,boost::arg<5>,boost::arg<6>,boost::arg<7>>>>(
    (rbx::signal<void (RBX::ContentId,bool,float,float,float,float,int)> *)this + 40,
    &function);
  v1 = ptr;
  if ( ptr )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)ptr + 1, 1u) )
      operator delete(v1);
  }
}


// Address: 0x1038cd0 | Name: _ZN3RBX8Animator16onCombinedUpdateENS_9ContentIdEbffffi
void __fastcall RBX::Animator::onCombinedUpdate(
        __int64 a1,
        const RBX::ContentId *a2,
        char a3,
        char a4,
        float a5,
        float a6,
        float a7)
{
  __int64 v9; // r12
  __int64 v10; // rbp
  __int64 v11; // rbx
  bool v12; // al
  __int64 v13; // rbp
  __int64 v14; // rbx
  bool v15; // al
  void *v16; // rdi
  __int64 v17; // r12
  RBX::Animation *Animation; // rax
  bool v19; // bl
  __int64 v20; // rbp
  __int64 v21; // r12
  __int64 v22; // rbx
  bool v23; // al
  bool v24; // zf
  __int64 v25; // rbx
  __int64 v26; // r12
  __int64 v27; // rbp
  bool v28; // al
  float v29; // [rsp+4h] [rbp-F4h]
  _BYTE v30[16]; // [rsp+20h] [rbp-D8h] BYREF
  void *v31; // [rsp+30h] [rbp-C8h]
  _BYTE v32[16]; // [rsp+38h] [rbp-C0h] BYREF
  void *v33; // [rsp+48h] [rbp-B0h]
  _BYTE v34[16]; // [rsp+50h] [rbp-A8h] BYREF
  void *v35; // [rsp+60h] [rbp-98h]
  _BYTE v36[16]; // [rsp+68h] [rbp-90h] BYREF
  void *ptr; // [rsp+78h] [rbp-80h]
  _BYTE v38[16]; // [rsp+80h] [rbp-78h] BYREF
  void *v39; // [rsp+90h] [rbp-68h]
  _BYTE v40[16]; // [rsp+98h] [rbp-60h] BYREF
  void *v41; // [rsp+A8h] [rbp-50h]
  _BYTE v42[16]; // [rsp+B0h] [rbp-48h] BYREF
  void *v43; // [rsp+C0h] [rbp-38h]

  v29 = a6;
  v9 = a1;
  if ( (a4 & 4) != 0 )
  {
    std::string::basic_string(v36, a2);
    v10 = *(_QWORD *)(a1 + 216);
    if ( v10 )
    {
      v11 = a1 + 216;
      do
      {
        v12 = RBX::operator<((const RBX::ContentId *)(v10 + 32), (const RBX::ContentId *)v36);
        if ( !v12 )
          v11 = v10;
        v10 = *(_QWORD *)(v10 + 8LL * v12);
      }
      while ( v10 );
      if ( v11 != a1 + 216
        && !RBX::operator<((const RBX::ContentId *)v36, (const RBX::ContentId *)(v11 + 32))
        && !RBX::Math::isNanInf(a6) )
      {
        RBX::AnimationTrack::localAdjustSpeed(*(RBX::AnimationTrack **)(v11 + 56), a6);
      }
    }
    if ( (v36[0] & 1) != 0 )
      operator delete(ptr);
  }
  if ( (a4 & 2) != 0 )
  {
    std::string::basic_string(v34, a2);
    v13 = *(_QWORD *)(a1 + 216);
    if ( v13 )
    {
      v14 = a1 + 216;
      do
      {
        v15 = RBX::operator<((const RBX::ContentId *)(v13 + 32), (const RBX::ContentId *)v34);
        if ( !v15 )
          v14 = v13;
        v13 = *(_QWORD *)(v13 + 8LL * v15);
      }
      while ( v13 );
      if ( v14 != a1 + 216
        && !RBX::operator<((const RBX::ContentId *)v34, (const RBX::ContentId *)(v14 + 32))
        && !RBX::Math::isNanInf(a6)
        && !RBX::Math::isNanInf(a6) )
      {
        a6 = a5;
        RBX::AnimationTrack::localAdjustWeight(*(RBX::AnimationTrack **)(v14 + 56), a5, a7);
      }
    }
    if ( (v34[0] & 1) != 0 )
      operator delete(v35);
  }
  if ( (a4 & 1) != 0 )
  {
    if ( a3 )
    {
      std::string::basic_string(v42, a2);
      a6 = v29;
      RBX::Animator::onPlay(a1, v42, a5, v29, a7);
      if ( (v42[0] & 1) == 0 )
        goto LABEL_50;
      v16 = v43;
      goto LABEL_49;
    }
    v17 = *(_QWORD *)(a1 + 304);
    if ( a1 + 296 == v17 )
    {
LABEL_35:
      std::string::basic_string(v38, a2);
      v9 = a1;
      a6 = v29;
      RBX::Animator::onPlay(a1, v38, 0.1, v29, a7);
      if ( (v38[0] & 1) != 0 )
        operator delete(v39);
    }
    else
    {
      while ( 1 )
      {
        Animation = RBX::AnimationTrack::getAnimation(*(const RBX::AnimationTrack **)(v17 + 16));
        std::string::basic_string(v40, (char *)Animation + 128);
        v19 = RBX::operator==((const RBX::ContentId *)v40, a2);
        if ( (v40[0] & 1) != 0 )
          operator delete(v41);
        if ( v19 )
          break;
        v17 = *(_QWORD *)(v17 + 8);
        if ( a1 + 296 == v17 )
          goto LABEL_35;
      }
      v9 = a1;
    }
    std::string::basic_string(v32, a2);
    v20 = *(_QWORD *)(v9 + 216);
    if ( v20 )
    {
      v21 = v9 + 216;
      v22 = v21;
      do
      {
        v23 = RBX::operator<((const RBX::ContentId *)(v20 + 32), (const RBX::ContentId *)v32);
        if ( !v23 )
          v22 = v20;
        v20 = *(_QWORD *)(v20 + 8LL * v23);
      }
      while ( v20 );
      v24 = v22 == v21;
      v9 = a1;
      if ( !v24
        && !RBX::operator<((const RBX::ContentId *)v32, (const RBX::ContentId *)(v22 + 32))
        && !RBX::Math::isNanInf(a6) )
      {
        RBX::AnimationTrack::localStop(*(RBX::AnimationTrack **)(v22 + 56), a6);
      }
    }
    if ( (v32[0] & 1) != 0 )
    {
      v16 = v33;
LABEL_49:
      operator delete(v16);
    }
  }
LABEL_50:
  if ( (a4 & 8) != 0 )
  {
    std::string::basic_string(v30, a2);
    v25 = *(_QWORD *)(v9 + 216);
    if ( v25 )
    {
      v26 = v9 + 216;
      v27 = v26;
      do
      {
        v28 = RBX::operator<((const RBX::ContentId *)(v25 + 32), (const RBX::ContentId *)v30);
        if ( !v28 )
          v27 = v25;
        v25 = *(_QWORD *)(v25 + 8LL * v28);
      }
      while ( v25 );
      if ( v27 != v26
        && !RBX::operator<((const RBX::ContentId *)v30, (const RBX::ContentId *)(v27 + 32))
        && !RBX::Math::isNanInf(a6) )
      {
        RBX::AnimationTrack::localSetTimePosition(*(RBX::AnimationTrack **)(v27 + 56), a6);
      }
    }
    if ( (v30[0] & 1) != 0 )
      operator delete(v31);
  }
}


// Address: 0x10391b0 | Name: _ZN3RBX8AnimatorD2Ev
void __fastcall RBX::Animator::~Animator(RBX::Animator *this)
{
  __int64 v2; // rax
  _QWORD *v3; // r13
  __int64 v4; // rdx
  _QWORD *v5; // r14
  volatile signed __int32 *v6; // rbx
  volatile signed __int32 *v7; // rdi
  volatile signed __int32 *v8; // rdi
  __int64 v9; // r14
  __int64 v10; // rbx
  volatile signed __int32 *v11; // rdi
  void *v12; // rdi
  volatile signed __int32 *v13; // rdi
  volatile signed __int32 *v14; // rdi
  void *v15; // rdi
  volatile signed __int32 *v16; // rdi

  *(_QWORD *)this = &off_288D1A0;
  *((_QWORD *)this + 16) = &off_288D2E8;
  if ( byte_2CE5418 )
    FLog::FastLog(byte_2CE5418, "Animator destroyed - %p", this);
  rbx::signals::signal_base::~signal_base((rbx::signals::signal_base *)this + 42);
  rbx::signals::signal_base::~signal_base((rbx::signals::signal_base *)this + 41);
  rbx::signals::signal_base::~signal_base((rbx::signals::signal_base *)this + 40);
  if ( *((_QWORD *)this + 39) )
  {
    v2 = *((_QWORD *)this + 37);
    v3 = (_QWORD *)*((_QWORD *)this + 38);
    v4 = *v3;
    *(_QWORD *)(v4 + 8) = *(_QWORD *)(v2 + 8);
    **(_QWORD **)(v2 + 8) = v4;
    *((_QWORD *)this + 39) = 0;
    while ( v3 != (_QWORD *)((char *)this + 296) )
    {
      v5 = v3;
      v3 = (_QWORD *)v3[1];
      v6 = (volatile signed __int32 *)v5[3];
      if ( v6 )
      {
        if ( !_InterlockedSub(v6 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
          if ( !_InterlockedSub(v6 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
        }
      }
      operator delete(v5);
    }
  }
  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 36);
  v7 = (volatile signed __int32 *)*((_QWORD *)this + 36);
  if ( v7 && !_InterlockedSub(v7 + 1, 1u) )
    operator delete((void *)v7);
  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 35);
  v8 = (volatile signed __int32 *)*((_QWORD *)this + 35);
  if ( v8 && !_InterlockedSub(v8 + 1, 1u) )
    operator delete((void *)v8);
  v9 = *((_QWORD *)this + 31);
  if ( v9 )
  {
    v10 = *((_QWORD *)this + 32);
    if ( v10 == v9 )
    {
      v12 = (void *)*((_QWORD *)this + 31);
    }
    else
    {
      do
      {
        v11 = *(volatile signed __int32 **)(v10 - 24);
        if ( v11 && !_InterlockedSub(v11 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
        v10 -= 32;
      }
      while ( v9 != v10 );
      v12 = (void *)*((_QWORD *)this + 31);
    }
    *((_QWORD *)this + 32) = v9;
    operator delete(v12);
  }
  v13 = (volatile signed __int32 *)*((_QWORD *)this + 30);
  if ( v13 && !_InterlockedSub(v13 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
  std::__tree<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack>>,std::__map_value_compare<RBX::ContentId,std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack>>,std::less<RBX::ContentId>,true>,std::allocator<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack>>>>::destroy(
    (std::__tree<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> >,std::__map_value_compare<RBX::ContentId,std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> >,std::less<RBX::ContentId>,true>,std::allocator<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> > > > *)((char *)this + 208),
    *((std::__tree<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> >,std::__map_value_compare<RBX::ContentId,std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> >,std::less<RBX::ContentId>,true>,std::allocator<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> > > >::__node_pointer *)this
    + 27));
  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 22);
  v14 = (volatile signed __int32 *)*((_QWORD *)this + 22);
  if ( v14 && !_InterlockedSub(v14 + 1, 1u) )
    operator delete((void *)v14);
  v15 = (void *)*((_QWORD *)this + 19);
  if ( v15 )
  {
    *((_QWORD *)this + 20) = v15;
    operator delete(v15);
  }
  *((_QWORD *)this + 16) = &off_288D438;
  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 18);
  v16 = (volatile signed __int32 *)*((_QWORD *)this + 18);
  if ( v16 && !_InterlockedSub(v16 + 1, 1u) )
    operator delete((void *)v16);
  RBX::Instance::~Instance((RBX::Instance *)this);
}


// Address: 0x10394f0 | Name: _ZThn128_N3RBX8AnimatorD1Ev
void __fastcall `non-virtual thunk to'RBX::Animator::~Animator(RBX::Animator *this)
{
  RBX::Animator::~Animator((RBX::Animator *)((char *)this - 128));
}


// Address: 0x1039500 | Name: _ZN3RBX8AnimatorD0Ev
void __fastcall RBX::Animator::~Animator(RBX::Animator *this)
{
  RBX::Animator::~Animator(this);
  operator delete(this);
}


// Address: 0x1039520 | Name: _ZThn128_N3RBX8AnimatorD0Ev
void __fastcall `non-virtual thunk to'RBX::Animator::~Animator(RBX::Animator *this)
{
  RBX::Animator::~Animator((RBX::Animator *)((char *)this - 128));
  operator delete((char *)this - 128);
}


// Address: 0x1039560 | Name: _ZN3RBX8Animator15reloadAnimationEN5boost10shared_ptrINS_14AnimationTrackEEE
void __fastcall RBX::Animator::reloadAnimation(
        RBX::Animator *this,
        boost::shared_ptr<RBX::AnimationTrack> animationTrack)
{
  unsigned __int64 v2; // r15
  char *v3; // rbx
  __int64 v4; // rax
  _QWORD *v5; // rax
  boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type *px; // rcx
  __int64 v7; // rcx

  v2 = *((_QWORD *)this + 39);
  if ( v2 <= dword_2858618 )
  {
    v3 = (char *)this + 296;
    v4 = *((_QWORD *)this + 38);
    if ( (RBX::Animator *)v4 != (RBX::Animator *)((char *)this + 296) )
    {
      while ( *(int (***)(void))(v4 + 16) != animationTrack.px->_vptr$EventSource )
      {
        v4 = *(_QWORD *)(v4 + 8);
        if ( v3 == (char *)v4 )
          goto LABEL_8;
      }
    }
    if ( (char *)v4 == v3 )
    {
LABEL_8:
      v5 = operator new(0x20u);
      *v5 = 0;
      v5[2] = animationTrack.px->_vptr$EventSource;
      px = animationTrack.px->weak_this_.px;
      v5[3] = px;
      if ( px )
      {
        _InterlockedAdd(
          (volatile signed __int32 *)&px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
          1u);
        v2 = *((_QWORD *)this + 39);
      }
      v5[1] = v3;
      v7 = *((_QWORD *)this + 37);
      *v5 = v7;
      *(_QWORD *)(v7 + 8) = v5;
      *((_QWORD *)this + 37) = v5;
      *((_QWORD *)this + 39) = v2 + 1;
    }
  }
  else
  {
    RBX::StandardOut::printf(
      MESSAGE_WARNING,
      "AnimationTrack limit of %d tracks for one Animator exceeded, new animations will not be played.",
      dword_2858618);
  }
}


// Address: 0x1039640 | Name: _ZN3RBX8Animator23calcAnimatableJointsRecEPNS_8InstanceE
void __fastcall RBX::Animator::calcAnimatableJointsRec(RBX::Animator *this, RBX::Instance *instance)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  boost::weak_ptr<RBX::Instance> v5; // xmm0
  __int64 v6; // rax
  boost::detail::sp_counted_base *pi; // rdx
  unsigned __int8 *v8; // r12
  unsigned __int8 *v9; // r15
  unsigned __int64 v10; // rax
  unsigned __int64 v11; // rax
  boost::detail::sp_counted_base *v12; // rbx
  boost::detail::sp_counted_base *v13; // rdi
  boost::detail::sp_counted_base *v14; // rdi
  __int64 **px; // rax
  __int64 *v16; // rbx
  __int64 *v17; // r15
  __int64 v18; // r12
  __int64 v19; // rbp
  RBX::Reflection::ClassDescriptor *v20; // rax
  __int64 v21; // rbp
  __int64 v22; // r12
  RBX::Reflection::ClassDescriptor *v23; // rax
  RBX::Instance ***v24; // rax
  RBX::Instance **v25; // rbx
  RBX::Instance **v26; // r14
  RBX::JointData v27; // [rsp+0h] [rbp-68h] BYREF
  boost::weak_ptr<RBX::Instance> v28; // [rsp+20h] [rbp-48h] BYREF

  if ( !instance )
    return;
  descriptor = instance->descriptor;
  DescriptorPtr = Class_getDescriptorPtr(0);
  if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
  {
    v27.jointIndexHint = -1;
    RBX::weak_from<RBX::Instance>(&v28.px, instance);
    v5 = v28;
    v28 = 0;
    v27.jointWeak = v5;
    v27.joint = (RBX::IAnimatableJoint *)&instance[1].propertyChangedSignal;
    v6 = *((_QWORD *)this + 32);
    if ( v6 == *((_QWORD *)this + 33) )
    {
      std::vector<RBX::JointData>::__push_back_slow_path<RBX::JointData const&>(
        (RBX::Animator *)((char *)this + 248),
        &v27);
    }
    else
    {
      *(_QWORD *)v6 = v27.jointWeak.px;
      pi = v27.jointWeak.pn.pi_;
      *(_QWORD *)(v6 + 8) = v27.jointWeak.pn.pi_;
      if ( pi )
        _InterlockedAdd(&pi->weak_count_, 1u);
      *(_DWORD *)(v6 + 24) = v27.jointIndexHint;
      *(_QWORD *)(v6 + 16) = v27.joint;
      *((_QWORD *)this + 32) += 32LL;
    }
    v8 = (unsigned __int8 *)(*((__int64 (__fastcall **)(RBX::Instance *))instance->_vptr$EventSource + 49))(instance);
    v9 = (unsigned __int8 *)(*((__int64 (__fastcall **)(RBX::Instance *))instance->_vptr$EventSource + 50))(instance);
    v10 = *v8;
    if ( (v10 & 1) != 0 )
    {
      if ( *((_QWORD *)v8 + 1) != 16 )
        goto LABEL_25;
    }
    else if ( v10 >> 1 != 16 )
    {
      goto LABEL_25;
    }
    if ( !(unsigned int)std::string::compare(v8, 0, -1, "HumanoidRootPart", 16) )
    {
      v11 = *v9;
      if ( (v11 & 1) != 0 )
      {
        if ( *((_QWORD *)v9 + 1) != 10 )
          goto LABEL_25;
LABEL_17:
        if ( !(unsigned int)std::string::compare(v9, 0, -1, "LowerTorso", 10) )
        {
          *((_QWORD *)this + 29) = v27.jointWeak.px;
          v12 = v27.jointWeak.pn.pi_;
          v13 = (boost::detail::sp_counted_base *)*((_QWORD *)this + 30);
          if ( v27.jointWeak.pn.pi_ != v13 )
          {
            if ( v27.jointWeak.pn.pi_ )
            {
              _InterlockedAdd(&v27.jointWeak.pn.pi_->weak_count_, 1u);
              v13 = (boost::detail::sp_counted_base *)*((_QWORD *)this + 30);
            }
            if ( v13 && !_InterlockedSub(&v13->weak_count_, 1u) )
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
            *((_QWORD *)this + 30) = v12;
          }
        }
        goto LABEL_25;
      }
      if ( v11 >> 1 == 10 )
        goto LABEL_17;
    }
LABEL_25:
    v14 = v27.jointWeak.pn.pi_;
    if ( v27.jointWeak.pn.pi_ && !_InterlockedSub(&v27.jointWeak.pn.pi_->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v14->_vptr$sp_counted_base + 3))(v14);
  }
  px = (__int64 **)instance->children.object.px;
  if ( px )
  {
    v16 = *px;
    v17 = px[1];
    if ( *px != v17 )
    {
      while ( 1 )
      {
        v18 = *v16;
        if ( *v16 != *((_QWORD *)this + 11) )
        {
          v19 = *(_QWORD *)(v18 + 24);
          v20 = Class_getDescriptorPtr(0);
          if ( v18 )
          {
            if ( *(unsigned __int16 *)(v19 + 726) - (unsigned int)*((unsigned __int16 *)v20 + 363) <= *((unsigned __int16 *)v20 + 364) )
              break;
          }
          v21 = *v16;
          v22 = *(_QWORD *)(*v16 + 24);
          v23 = Class_getDescriptorPtr(0);
          if ( v21 )
          {
            if ( *(unsigned __int16 *)(v22 + 726) - (unsigned int)*((unsigned __int16 *)v23 + 363) <= *((unsigned __int16 *)v23 + 364) )
              break;
          }
        }
        v16 += 2;
        if ( v17 == v16 )
        {
          v24 = (RBX::Instance ***)instance->children.object.px;
          v25 = *v24;
          v26 = v24[1];
          if ( *v24 != v26 )
          {
            do
            {
              RBX::Animator::calcAnimatableJointsRec(this, *v25);
              v25 += 2;
            }
            while ( v26 != v25 );
          }
          return;
        }
      }
    }
  }
}


// Address: 0x1039980 | Name: _ZN3RBX8Animator23newCalcAnimatableJointsEv
void __fastcall RBX::Animator::newCalcAnimatableJoints(RBX::Animator *this)
{
  RBX::Instance *v1; // rbx
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool IsWorldModelRefactorEnabled; // al
  const RBX::Reflection::ClassDescriptor *v5; // r15
  RBX::Reflection::ClassDescriptor *v6; // rax

  v1 = (RBX::Instance *)this;
  while ( 1 )
  {
    v1 = v1->parent;
    if ( !v1 )
      break;
    descriptor = v1->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      if ( stru_2A015D8.value
        || ((IsWorldModelRefactorEnabled = RBX::WorldRoot::IsWorldModelRefactorEnabled(),
             v5 = v1->descriptor,
             !IsWorldModelRefactorEnabled)
          ? (v6 = Class_getDescriptorPtr(0))
          : (v6 = Class_getDescriptorPtr(0)),
            *((unsigned __int16 *)v5 + 363) - (unsigned int)*((unsigned __int16 *)v6 + 363) > *((unsigned __int16 *)v6
                                                                                              + 364)) )
      {
        RBX::newCalcAnimatableJointsRec(
          v1,
          (boost::weak_ptr<RBX::Instance> *)((char *)this + 232),
          (RBX::Animator *)((char *)this + 248));
      }
      return;
    }
  }
}


// Address: 0x1039a30 | Name: _ZN3RBXL26newCalcAnimatableJointsRecEPNS_8InstanceERN5boost8weak_ptrIS0_EERNSt3__16vectorINS_9JointDataENS6_9allocatorIS8_EEEE
void __fastcall RBX::newCalcAnimatableJointsRec(
        RBX::Instance *instance,
        boost::weak_ptr<RBX::Instance> *jointRoot,
        std::vector<RBX::JointData> *animatableJoints)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  boost::weak_ptr<RBX::Instance> v7; // xmm0
  __int64 v8; // rax
  boost::detail::sp_counted_base *pi; // rdx
  unsigned __int8 *v10; // r13
  unsigned __int8 *v11; // rbx
  unsigned __int64 v12; // rax
  unsigned __int64 v13; // rax
  boost::detail::sp_counted_base *v14; // rbx
  boost::detail::sp_counted_base *v15; // rdi
  boost::detail::sp_counted_base *v16; // rdi
  RBX::Instance ***px; // rax
  RBX::Instance **v18; // rbx
  RBX::Instance **v19; // r15
  const RBX::Reflection::ClassDescriptor *v20; // rbp
  RBX::Reflection::ClassDescriptor *v21; // rax
  RBX::JointData v22; // [rsp+0h] [rbp-68h] BYREF
  boost::weak_ptr<RBX::Instance> v23; // [rsp+20h] [rbp-48h] BYREF

  if ( !instance )
    goto LABEL_28;
  descriptor = instance->descriptor;
  DescriptorPtr = Class_getDescriptorPtr(0);
  if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364) )
    goto LABEL_28;
  v22.jointIndexHint = -1;
  RBX::weak_from<RBX::Instance>(&v23.px, instance);
  v7 = v23;
  v23 = 0;
  v22.jointWeak = v7;
  v22.joint = (RBX::IAnimatableJoint *)&instance[1].propertyChangedSignal;
  v8 = *((_QWORD *)animatableJoints + 1);
  if ( v8 == *((_QWORD *)animatableJoints + 2) )
  {
    std::vector<RBX::JointData>::__push_back_slow_path<RBX::JointData const&>(animatableJoints, &v22);
  }
  else
  {
    *(_QWORD *)v8 = v22.jointWeak.px;
    pi = v22.jointWeak.pn.pi_;
    *(_QWORD *)(v8 + 8) = v22.jointWeak.pn.pi_;
    if ( pi )
      _InterlockedAdd(&pi->weak_count_, 1u);
    *(_DWORD *)(v8 + 24) = v22.jointIndexHint;
    *(_QWORD *)(v8 + 16) = v22.joint;
    *((_QWORD *)animatableJoints + 1) += 32LL;
  }
  v10 = (unsigned __int8 *)(*((__int64 (__fastcall **)(RBX::Instance *))instance->_vptr$EventSource + 49))(instance);
  v11 = (unsigned __int8 *)(*((__int64 (__fastcall **)(RBX::Instance *))instance->_vptr$EventSource + 50))(instance);
  v12 = *v10;
  if ( (v12 & 1) != 0 )
  {
    if ( *((_QWORD *)v10 + 1) != 16 )
      goto LABEL_25;
  }
  else if ( v12 >> 1 != 16 )
  {
    goto LABEL_25;
  }
  if ( !(unsigned int)std::string::compare(v10, 0, -1, "HumanoidRootPart", 16) )
  {
    v13 = *v11;
    if ( (v13 & 1) != 0 )
    {
      if ( *((_QWORD *)v11 + 1) != 10 )
        goto LABEL_25;
LABEL_17:
      if ( !(unsigned int)std::string::compare(v11, 0, -1, "LowerTorso", 10) )
      {
        jointRoot->px = v22.jointWeak.px;
        v14 = v22.jointWeak.pn.pi_;
        v15 = jointRoot->pn.pi_;
        if ( v22.jointWeak.pn.pi_ != v15 )
        {
          if ( v22.jointWeak.pn.pi_ )
          {
            _InterlockedAdd(&v22.jointWeak.pn.pi_->weak_count_, 1u);
            v15 = jointRoot->pn.pi_;
          }
          if ( v15 && !_InterlockedSub(&v15->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v15->_vptr$sp_counted_base + 3))(v15);
          jointRoot->pn.pi_ = v14;
        }
      }
      goto LABEL_25;
    }
    if ( v13 >> 1 == 10 )
      goto LABEL_17;
  }
LABEL_25:
  v16 = v22.jointWeak.pn.pi_;
  if ( v22.jointWeak.pn.pi_ && !_InterlockedSub(&v22.jointWeak.pn.pi_->weak_count_, 1u) )
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v16->_vptr$sp_counted_base + 3))(v16);
LABEL_28:
  px = (RBX::Instance ***)instance->children.object.px;
  if ( px )
  {
    v18 = *px;
    v19 = px[1];
    if ( *px != v19 )
    {
      do
      {
        v20 = (*v18)->descriptor;
        v21 = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)v20 + 363) - (unsigned int)*((unsigned __int16 *)v21 + 363) > *((unsigned __int16 *)v21
                                                                                                 + 364) )
          RBX::newCalcAnimatableJointsRec(*v18, jointRoot, animatableJoints);
        v18 += 2;
      }
      while ( v19 != v18 );
    }
  }
}


// Address: 0x1039cf0 | Name: _ZN3RBX8Animator9onSteppedERKNS_7SteppedE
void __fastcall RBX::Animator::onStepped(RBX::Animator *this, const RBX::Stepped *event)
{
  float v2; // xmm1_4
  unsigned int v3; // r14d
  RBX::Animator *v4; // rax
  char *v5; // r12
  char *v6; // r14
  __int64 v7; // r15
  RBX::Animation *Animation; // rax
  __int64 v9; // rdi
  volatile signed __int32 *v10; // rdi
  __int64 v11; // rbx
  __int64 i; // rbp
  volatile signed __int32 *v13; // rdi
  _QWORD *v14; // r15
  _QWORD *v15; // r12
  std::vector<RBX::JointData> *v16; // rcx
  __int64 v17; // r15
  __int64 v18; // rax
  char *v19; // r13
  char *v20; // rbp
  __int64 v21; // rax
  char *v22; // rbx
  volatile signed __int32 *v23; // r15
  signed __int64 v24; // r15
  __int64 v25; // rbx
  boost::detail::sp_counted_base *v26; // rcx
  unsigned __int64 v27; // rax
  __int64 v28; // rdi
  boost::detail::sp_counted_base *v29; // rsi
  __int64 v30; // rax
  RBX::Instance *v31; // rsi
  RBX::Instance *v32; // rbp
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool IsWorldModelRefactorEnabled; // al
  const RBX::Reflection::ClassDescriptor *v36; // rbx
  RBX::Reflection::ClassDescriptor *v37; // rax
  boost::detail::sp_counted_base *v38; // rcx
  bool v39; // zf
  signed __int64 v40; // rbp
  __int64 v41; // rbx
  char *v42; // rcx
  unsigned __int64 v43; // rax
  __int64 v44; // rdi
  _OWORD *v45; // rsi
  char *v46; // rcx
  volatile signed __int32 *v47; // rax
  char *v48; // r15
  std::vector<RBX::JointData> *v49; // r14
  __int64 v50; // rbp
  int v51; // ebx
  __int64 v52; // rax
  __int64 v53; // rcx
  boost::weak_ptr<RBX::Instance>::element_type *v54; // rdx
  unsigned __int64 v55; // rsi
  unsigned __int64 v56; // r15
  __int64 v57; // r13
  unsigned __int64 v58; // rbp
  float v59; // xmm2_4
  float v60; // xmm1_4
  __int64 v61; // r12
  __int64 v62; // r14
  RBX::Reflection::ClassDescriptor *v63; // rax
  float v64; // xmm1_4
  float authoredHipHeight; // xmm0_4
  float gameStep; // xmm1_4
  char *v67; // rsi
  __int64 v68; // rbx
  unsigned __int64 v69; // rbp
  __int128 v70; // xmm0
  __int64 v71; // rax
  unsigned __int64 v72; // r14
  __int64 v73; // r13
  __int64 v74; // rbx
  RBX::Reflection::ClassDescriptor *v75; // rax
  volatile signed __int32 *v76; // rbx
  signed __int32 v77; // eax
  signed __int32 v78; // ett
  __int64 v79; // rcx
  volatile signed __int32 *v80; // rsi
  __int64 *v81; // rcx
  signed __int32 v82; // eax
  signed __int32 v83; // ett
  __int64 v84; // rcx
  signed __int32 v85; // eax
  volatile signed __int32 *v86; // r15
  signed __int32 v87; // ett
  int v88; // eax
  __int64 v89; // rax
  float v90; // xmm0_4
  char *v91; // rax
  __int64 v92; // rbp
  __int64 v93; // rax
  __int64 v94; // rdi
  __int64 v95; // rdi
  boost::weak_ptr<RBX::Instance>::element_type *px; // rax
  __int64 v97; // rcx
  char *v98; // rbx
  __int64 v99; // rdx
  const char *v100; // rdx
  char *v101; // rbp
  volatile signed __int32 *v102; // rdi
  char *v103; // rdi
  boost::detail::sp_counted_base *pi; // rdi
  struct _Unwind_Exception *v105; // r14
  unsigned int category; // [rsp+14h] [rbp-E4h]
  char *v108; // [rsp+18h] [rbp-E0h]
  volatile signed __int32 *v109; // [rsp+18h] [rbp-E0h]
  boost::weak_ptr<RBX::Instance> jointRoot; // [rsp+20h] [rbp-D8h] BYREF
  void *v111; // [rsp+30h] [rbp-C8h]
  uint64_t enterTimestamp; // [rsp+40h] [rbp-B8h]
  RBX::Profiler::Token token; // [rsp+48h] [rbp-B0h]
  char *v114; // [rsp+50h] [rbp-A8h]
  std::vector<RBX::JointData> *joints; // [rsp+58h] [rbp-A0h]
  void *ptr[2]; // [rsp+60h] [rbp-98h] BYREF
  char *v117; // [rsp+70h] [rbp-88h]
  char *v118; // [rsp+78h] [rbp-80h]
  RBX::CachedPose v119; // [rsp+80h] [rbp-78h] BYREF
  _QWORD *v120; // [rsp+A0h] [rbp-58h]
  const RBX::Stepped *v121; // [rsp+A8h] [rbp-50h]
  boost::weak_ptr<RBX::Instance> v122; // [rsp+B0h] [rbp-48h] BYREF
  void *v123; // [rsp+C0h] [rbp-38h]

  v121 = event;
  v3 = RBX::Memory::setCurrentCategory(dword_2A04350);
  if ( !(_BYTE)byte_2A017B8 && __cxa_guard_acquire(&byte_2A017B8) )
  {
    qword_2A017B0 = RBX::Profiler::getToken("Physics", "Animator::onStepped", -1);
    __cxa_guard_release(&byte_2A017B8);
  }
  token = qword_2A017B0;
  enterTimestamp = RBX::Profiler::enterRegion(qword_2A017B0);
  if ( !RBX::WorldRoot::getConstWorldRootIfInWorldRoot((const RBX::Instance *)this) )
    goto LABEL_160;
  v4 = this;
  v5 = (char *)*((_QWORD *)this + 19);
  v108 = (char *)*((_QWORD *)this + 20);
  category = v3;
  if ( v5 != v108 )
  {
    v6 = (char *)this + 296;
    while ( 1 )
    {
      v7 = *((_QWORD *)this + 38);
      if ( v6 != (char *)v7 )
        break;
LABEL_15:
      v5 += 8;
      if ( v5 == v108 )
      {
        v4 = this;
        v5 = (char *)*((_QWORD *)this + 19);
        v3 = category;
        goto LABEL_17;
      }
    }
    while ( 1 )
    {
      Animation = RBX::AnimationTrack::getAnimation(*(const RBX::AnimationTrack **)(v7 + 16));
      std::string::basic_string(&jointRoot, (char *)Animation + 128);
      v123 = v111;
      v122 = jointRoot;
      jointRoot = 0;
      v111 = 0;
      v9 = *(_QWORD *)(v7 + 16);
      LODWORD(v114) = *(_DWORD *)(v9 + 260);
      LODWORD(joints) = *(_DWORD *)(v9 + 264);
      LODWORD(v118) = RBX::AnimationTrack::getSpeed((const RBX::AnimationTrack *)v9);
      LODWORD(v120) = RBX::AnimationTrack::getTimePosition(*(const RBX::AnimationTrack **)(v7 + 16));
      std::string::basic_string(&v119, &v122);
      ptr[0] = v5;
      LODWORD(ptr[1]) = 0;
      v2 = *(float *)&v114;
      RBX::Reflection::RemoteEventDesc<RBX::Animator,void ()(RBX::ContentId,bool,float,float,float,float,int),rbx::remote_signal<void ()(RBX::ContentId,bool,float,float,float,float,int)>,rbx::remote_signal<void ()(RBX::ContentId,bool,float,float,float,float,int)> RBX::Animator::*>::replicateEvent(
        qword_2858690,
        this,
        &v119,
        1,
        9,
        ptr,
        *(float *)&joints,
        *(float *)&v114,
        *(float *)&v118,
        *(float *)&v120);
      if ( (LOBYTE(v119.translation.x) & 1) != 0 )
      {
        operator delete(*(void **)&v119.rotaxisangle.y);
        if ( ((__int64)v122.px & 1) == 0 )
        {
LABEL_10:
          if ( ((__int64)jointRoot.px & 1) != 0 )
            goto LABEL_14;
          goto LABEL_7;
        }
      }
      else if ( ((__int64)v122.px & 1) == 0 )
      {
        goto LABEL_10;
      }
      operator delete(v123);
      if ( ((__int64)jointRoot.px & 1) != 0 )
LABEL_14:
        operator delete(v111);
LABEL_7:
      v7 = *(_QWORD *)(v7 + 8);
      if ( v6 == (char *)v7 )
        goto LABEL_15;
    }
  }
LABEL_17:
  *((_QWORD *)v4 + 20) = v5;
  if ( !*((_BYTE *)v4 + 272) )
  {
    v16 = (RBX::Animator *)((char *)v4 + 248);
    v15 = (_QWORD *)((char *)v4 + 256);
    goto LABEL_30;
  }
  v10 = (volatile signed __int32 *)*((_QWORD *)v4 + 30);
  *(_OWORD *)((char *)v4 + 232) = 0;
  if ( v10 && !_InterlockedSub(v10 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
  v11 = *((_QWORD *)this + 31);
  for ( i = *((_QWORD *)this + 32); v11 != i; i -= 32 )
  {
    v13 = *(volatile signed __int32 **)(i - 24);
    if ( v13 && !_InterlockedSub(v13 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
  }
  v14 = (_QWORD *)((char *)this + 248);
  v15 = (_QWORD *)((char *)this + 256);
  *((_QWORD *)this + 32) = v11;
  if ( !stru_2A015C0.value )
  {
    v30 = *((_QWORD *)this + 11);
    if ( v30 )
      v31 = *(RBX::Instance **)(v30 + 88);
    else
      v31 = 0;
    RBX::Animator::calcAnimatableJointsRec(this, v31);
    if ( !stru_2A015F0.value || byte_2A017C0 )
      goto LABEL_28;
    v32 = (RBX::Instance *)this;
    do
    {
      v32 = v32->parent;
      if ( !v32 )
        goto LABEL_28;
      descriptor = v32->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
    }
    while ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364) );
    if ( !stru_2A015D8.value )
    {
      IsWorldModelRefactorEnabled = RBX::WorldRoot::IsWorldModelRefactorEnabled();
      v36 = v32->descriptor;
      v37 = IsWorldModelRefactorEnabled ? Class_getDescriptorPtr(0) : Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)v36 + 363) - (unsigned int)*((unsigned __int16 *)v37 + 363) <= *((unsigned __int16 *)v37
                                                                                                + 364) )
        goto LABEL_28;
    }
    jointRoot = 0;
    memset(&v119, 0, 24);
    RBX::newCalcAnimatableJointsRec(v32, &jointRoot, (std::vector<RBX::JointData> *)&v119);
    if ( jointRoot.pn.pi_ && jointRoot.pn.pi_->use_count_ )
      px = jointRoot.px;
    else
      px = 0;
    v97 = *((_QWORD *)this + 30);
    if ( v97 && *(_DWORD *)(v97 + 8) )
    {
      if ( px != *((boost::weak_ptr<RBX::Instance>::element_type **)this + 29) )
        goto LABEL_178;
    }
    else if ( px )
    {
      goto LABEL_178;
    }
    v98 = *(char **)&v119.translation.x;
    if ( *(_QWORD *)&v119.translation.z - *(_QWORD *)&v119.translation.x == *v15 - *v14 )
    {
      if ( *(_QWORD *)&v119.translation.x == *(_QWORD *)&v119.translation.z )
      {
LABEL_185:
        if ( v98 )
        {
          v101 = *(char **)&v119.translation.z;
          if ( *(char **)&v119.translation.z == v98 )
          {
            v103 = v98;
          }
          else
          {
            do
            {
              v102 = (volatile signed __int32 *)*((_QWORD *)v101 - 3);
              if ( v102 && !_InterlockedSub(v102 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v102 + 24LL))(v102);
              v101 -= 32;
            }
            while ( v98 != v101 );
            v103 = *(char **)&v119.translation.x;
          }
          *(_QWORD *)&v119.translation.z = v98;
          operator delete(v103);
        }
        pi = jointRoot.pn.pi_;
        if ( jointRoot.pn.pi_ && !_InterlockedSub(&jointRoot.pn.pi_->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        goto LABEL_28;
      }
      v99 = 0;
      while ( *(_QWORD *)(*(_QWORD *)&v119.translation.x + v99 + 16) == *(_QWORD *)(*v14 + v99 + 16) )
      {
        v99 += 32;
        if ( *(_QWORD *)&v119.translation.z - *(_QWORD *)&v119.translation.x == v99 )
          goto LABEL_185;
      }
    }
LABEL_178:
    if ( (xmmword_2AB7600 & 1) != 0 )
    {
      v100 = (const char *)qword_2AB7610;
      if ( !stru_2A01608.value )
        goto LABEL_183;
    }
    else
    {
      v100 = (char *)&xmmword_2AB7600 + 1;
      if ( !stru_2A01608.value )
      {
LABEL_183:
        RBX::Analytics::Event::trackEvent("Game", "AnimatorModelSearchChange", v100, 0, 0);
        goto LABEL_184;
      }
    }
    RBX::Analytics::Event::trackEventWithoutThrottling("Game", "AnimatorModelSearchChange", v100, 0, 0, 3);
LABEL_184:
    byte_2A017C0 = 1;
    v98 = *(char **)&v119.translation.x;
    goto LABEL_185;
  }
  RBX::Animator::newCalcAnimatableJoints(this);
LABEL_28:
  *((_BYTE *)this + 272) = 0;
  v16 = (RBX::Animator *)((char *)this + 248);
LABEL_30:
  v17 = *v15;
  joints = v16;
  v18 = *(_QWORD *)v16;
  if ( v17 == *(_QWORD *)v16 || !*((_QWORD *)this + 39) )
    goto LABEL_160;
  v19 = (char *)this + 296;
  v20 = (char *)*((_QWORD *)this + 38);
  if ( (char *)this + 296 != v20 )
  {
    do
    {
      if ( RBX::AnimationTrack::isStopped(*((const RBX::AnimationTrack **)v20 + 2)) )
      {
        if ( stru_2A014A0.value && RBX::AnimationTrack::getIsPlaying(*((const RBX::AnimationTrack **)v20 + 2)) )
          RBX::AnimationTrack::stop(*((RBX::AnimationTrack **)v20 + 2), v2);
        v21 = *(_QWORD *)v20;
        v22 = (char *)*((_QWORD *)v20 + 1);
        *(_QWORD *)(v21 + 8) = v22;
        **((_QWORD **)v20 + 1) = v21;
        --*((_QWORD *)this + 39);
        v23 = (volatile signed __int32 *)*((_QWORD *)v20 + 3);
        if ( v23 )
        {
          if ( !_InterlockedSub(v23 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 16LL))(v23);
            if ( !_InterlockedSub(v23 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 24LL))(v23);
          }
        }
        operator delete(v20);
      }
      else
      {
        v22 = (char *)*((_QWORD *)v20 + 1);
      }
      v20 = v22;
    }
    while ( v19 != v22 );
    v17 = *v15;
    v18 = *(_QWORD *)joints;
  }
  jointRoot = 0;
  v111 = 0;
  v24 = v17 - v18;
  if ( v24 )
  {
    v25 = v24 >> 5;
    if ( (unsigned __int64)(v24 >> 5) >> 59 )
    {
      std::__vector_base_common<true>::__throw_length_error(&jointRoot);
    }
    else
    {
      v26 = (boost::detail::sp_counted_base *)operator new(v24);
      jointRoot.pn.pi_ = v26;
      jointRoot.px = (boost::weak_ptr<RBX::Instance>::element_type *)v26;
      v111 = &v26[2 * v25];
      v27 = v25 - 1;
      if ( (v25 & 7) != 0 )
      {
        v28 = 0;
        v29 = v26;
        do
        {
          *(_OWORD *)((char *)&v29->weak_count_ + 2) = 0;
          *v29 = 0;
          v29 += 2;
          ++v28;
        }
        while ( ((v24 >> 5) & 7) != v28 );
        v25 -= v28;
      }
      else
      {
        v29 = v26;
      }
      v38 = (boost::detail::sp_counted_base *)((char *)v26 + v24);
      if ( v27 >= 7 )
      {
        do
        {
          *(_OWORD *)((char *)&v29->weak_count_ + 2) = 0;
          *v29 = 0;
          *(_OWORD *)((char *)&v29[2].weak_count_ + 2) = 0;
          v29[2] = 0;
          *(_OWORD *)((char *)&v29[4].weak_count_ + 2) = 0;
          v29[4] = 0;
          *(_OWORD *)((char *)&v29[6].weak_count_ + 2) = 0;
          v29[6] = 0;
          *(_OWORD *)((char *)&v29[8].weak_count_ + 2) = 0;
          v29[8] = 0;
          *(_OWORD *)((char *)&v29[10].weak_count_ + 2) = 0;
          v29[10] = 0;
          *(_OWORD *)((char *)&v29[12].weak_count_ + 2) = 0;
          v29[12] = 0;
          *(_OWORD *)((char *)&v29[14].weak_count_ + 2) = 0;
          v29[14] = 0;
          v29 += 16;
          v25 -= 8;
        }
        while ( v25 );
      }
      jointRoot.pn.pi_ = v38;
      v40 = *v15 - *(_QWORD *)joints;
      v39 = *v15 == *(_QWORD *)joints;
      *(_OWORD *)ptr = 0;
      v117 = 0;
      if ( v39 )
      {
LABEL_77:
        if ( stru_2A015A8.value )
          goto LABEL_78;
        goto LABEL_79;
      }
      v41 = v40 >> 5;
      if ( (unsigned __int64)(v40 >> 5) <= 0x7FFFFFFFFFFFFFFLL )
      {
        v42 = (char *)operator new(v40);
        ptr[1] = v42;
        ptr[0] = v42;
        v117 = &v42[32 * v41];
        v43 = v41 - 1;
        if ( (v41 & 7) != 0 )
        {
          v44 = 0;
          v45 = v42;
          do
          {
            *(_OWORD *)((char *)v45 + 14) = 0;
            *v45 = 0;
            v45 += 2;
            ++v44;
          }
          while ( ((v40 >> 5) & 7) != v44 );
          v41 -= v44;
        }
        else
        {
          v45 = v42;
        }
        v46 = &v42[v40];
        if ( v43 >= 7 )
        {
          do
          {
            *(_OWORD *)((char *)v45 + 14) = 0;
            *v45 = 0;
            *(_OWORD *)((char *)v45 + 46) = 0;
            v45[2] = 0;
            *(_OWORD *)((char *)v45 + 78) = 0;
            v45[4] = 0;
            *(_OWORD *)((char *)v45 + 110) = 0;
            v45[6] = 0;
            *(_OWORD *)((char *)v45 + 142) = 0;
            v45[8] = 0;
            *(_OWORD *)((char *)v45 + 174) = 0;
            v45[10] = 0;
            *(_OWORD *)((char *)v45 + 206) = 0;
            v45[12] = 0;
            *(_OWORD *)((char *)v45 + 238) = 0;
            v45[14] = 0;
            v45 += 16;
            v41 -= 8;
          }
          while ( v41 );
        }
        ptr[1] = v46;
        goto LABEL_77;
      }
    }
    v105 = (struct _Unwind_Exception *)std::__vector_base_common<true>::__throw_length_error(ptr);
    __cxa_guard_abort(&byte_2A017B8);
    RBX::Memory::setCurrentCategory(category);
    _Unwind_Resume(v105);
  }
  *(_OWORD *)ptr = 0;
  v117 = 0;
  if ( stru_2A015A8.value )
  {
LABEL_78:
    RBX::shared_from<RBX::Animator>(&v119, this);
    v47 = *(volatile signed __int32 **)&v119.translation.z;
    goto LABEL_80;
  }
LABEL_79:
  v47 = 0;
LABEL_80:
  v109 = v47;
  v48 = (char *)&unk_4A6B50;
  v49 = joints;
  v120 = v15;
  v114 = (char *)this + 296;
  do
  {
    v50 = *((_QWORD *)this + 38);
    if ( v19 != (char *)v50 )
    {
      v51 = *(_DWORD *)v48;
      while ( RBX::AnimationTrack::getPriority(*(const RBX::AnimationTrack **)(v50 + 16)) != v51 )
      {
        v50 = *(_QWORD *)(v50 + 8);
        if ( v19 == (char *)v50 )
          goto LABEL_112;
      }
      v118 = v48;
      v52 = *v15;
      v53 = *v15;
      if ( *v15 != *(_QWORD *)v49 )
      {
        v54 = jointRoot.px;
        v55 = 0;
        do
        {
          *(boost::enable_shared_from_this<RBX::Reflection::DescribedBase> *)((char *)&v54->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>
                                                                            + 6) = 0;
          *(_OWORD *)&v54->_vptr$EventSource = 0;
          ++v55;
          v53 = *v15;
          v52 = *(_QWORD *)v49;
          v54 = (boost::weak_ptr<RBX::Instance>::element_type *)((char *)v54 + 32);
        }
        while ( v55 < (__int64)(*v15 - *(_QWORD *)v49) >> 5 );
      }
      v56 = *((_QWORD *)this + 39);
      if ( v56 )
      {
        v57 = *((_QWORD *)this + 38);
        if ( v114 != (char *)v57 )
        {
          v58 = 1;
          do
          {
            if ( RBX::AnimationTrack::getPriority(*(const RBX::AnimationTrack **)(v57 + 16)) == v51 )
            {
              if ( stru_2A035E8.value )
              {
                v61 = *((_QWORD *)this + 11);
                if ( v61 )
                {
                  v62 = *(_QWORD *)(v61 + 24);
                  v63 = Class_getDescriptorPtr(0);
                  if ( *(unsigned __int16 *)(v62 + 726) - (unsigned int)*((unsigned __int16 *)v63 + 363) > *((unsigned __int16 *)v63 + 364) )
                    v61 = 0;
                  v49 = joints;
                }
                else
                {
                  v61 = 0;
                }
                authoredHipHeight = RBX::AnimationTrack::getKeyframeSequence(*(const RBX::AnimationTrack **)(v57 + 16))->authoredHipHeight;
                v59 = 1.0;
                if ( authoredHipHeight != 0.0 )
                {
                  v59 = 1.0;
                  if ( v61 )
                  {
                    v60 = fabs(authoredHipHeight);
                    v59 = 1.0;
                    if ( (float)((float)(v60 + 1.0) * 0.000001) < v60 )
                    {
                      v59 = 1.0;
                      if ( **(_BYTE **)(v61 + 720) != (unsigned __int8)*(_QWORD *)(v61 + 720) )
                        v59 = COERCE_FLOAT(*(_QWORD *)(v61 + 688) + **(_DWORD **)(v61 + 688)) / authoredHipHeight;
                    }
                  }
                }
                gameStep = v121->gameStep;
                RBX::AnimationTrack::step(
                  *(RBX::AnimationTrack **)(v57 + 16),
                  v49,
                  (std::vector<RBX::CachedPose> *)&jointRoot,
                  v121->gameTime,
                  gameStep,
                  v59);
              }
              else
              {
                v64 = v121->gameStep;
                RBX::AnimationTrack::step(
                  *(RBX::AnimationTrack **)(v57 + 16),
                  v49,
                  (std::vector<RBX::CachedPose> *)&jointRoot,
                  v121->gameTime,
                  v64,
                  1.0);
              }
            }
            if ( v58 >= v56 )
              break;
            v57 = *(_QWORD *)(v57 + 8);
            ++v58;
          }
          while ( v114 != (char *)v57 );
          v15 = v120;
          v53 = *v120;
          v52 = *(_QWORD *)v49;
        }
      }
      v19 = v114;
      v48 = v118;
      if ( v53 != v52 )
      {
        v67 = (char *)ptr[0];
        v68 = 0;
        v69 = 0;
        do
        {
          RBX::CachedPose::blendPosesOver(
            &v119,
            (const RBX::CachedPose *)&v67[v68],
            (const RBX::CachedPose *)((char *)jointRoot.px + v68));
          v67 = (char *)ptr[0];
          v70 = *(_OWORD *)&v119.translation.x;
          *(_OWORD *)((char *)ptr[0] + v68 + 14) = *(_OWORD *)((char *)&v119.rotaxisangle.x + 2);
          *(_OWORD *)&v67[v68] = v70;
          ++v69;
          v68 += 32;
        }
        while ( v69 < (__int64)(*v15 - *(_QWORD *)v49) >> 5 );
      }
    }
LABEL_112:
    v48 += 4;
  }
  while ( v48 != "N3RBX8AnimatorE" );
  v71 = *(_QWORD *)v49;
  if ( *v15 != *(_QWORD *)v49 )
  {
    v72 = 0;
    do
    {
      v92 = 32 * v72;
      v93 = *(_QWORD *)(v71 + 32 * v72 + 8);
      if ( v93 && *(_DWORD *)(v93 + 8) )
      {
        if ( !stru_2A035E8.value )
        {
          v73 = *((_QWORD *)this + 11);
          if ( v73 )
          {
            v74 = *(_QWORD *)(v73 + 24);
            v75 = Class_getDescriptorPtr(0);
            if ( *(unsigned __int16 *)(v74 + 726) - (unsigned int)*((unsigned __int16 *)v75 + 363) <= *((unsigned __int16 *)v75 + 364)
              && **(_BYTE **)(v73 + 720) != (unsigned __int8)*(_QWORD *)(v73 + 720) )
            {
              v76 = (volatile signed __int32 *)*((_QWORD *)this + 30);
              if ( v76 )
              {
                v77 = *((_DWORD *)v76 + 2);
                while ( v77 )
                {
                  v78 = v77;
                  v77 = _InterlockedCompareExchange(v76 + 2, v77 + 1, v77);
                  if ( v78 == v77 )
                  {
                    if ( *((_QWORD *)this + 29) )
                    {
                      v79 = *((_QWORD *)this + 31);
                      v80 = *(volatile signed __int32 **)(v79 + v92 + 8);
                      if ( v80 )
                      {
                        v81 = (__int64 *)(v92 + v79);
                        v82 = *((_DWORD *)v80 + 2);
                        while ( v82 )
                        {
                          v83 = v82;
                          v82 = _InterlockedCompareExchange(v80 + 2, v82 + 1, v82);
                          if ( v83 == v82 )
                          {
                            v84 = *v81;
                            goto LABEL_129;
                          }
                        }
                      }
                      v80 = 0;
                      v84 = 0;
LABEL_129:
                      v85 = (int)this;
                      v86 = (volatile signed __int32 *)*((_QWORD *)this + 30);
                      if ( v86 )
                      {
                        v85 = *((_DWORD *)v86 + 2);
                        while ( v85 )
                        {
                          v87 = v85;
                          v85 = _InterlockedCompareExchange(v86 + 2, v85 + 1, v85);
                          if ( v87 == v85 )
                          {
                            v88 = (int)this;
                            LOBYTE(v88) = *((_QWORD *)this + 29) == v84;
                            LODWORD(v114) = v88;
                            if ( !_InterlockedSub(v86 + 2, 1u) )
                            {
                              v89 = *(_QWORD *)v86;
                              v118 = (char *)v80;
                              (*(void (__fastcall **)(volatile signed __int32 *))(v89 + 16))(v86);
                              v80 = (volatile signed __int32 *)v118;
                              if ( !_InterlockedSub(v86 + 3, 1u) )
                              {
                                (*(void (__fastcall **)(volatile signed __int32 *, volatile signed __int32 *))(*(_QWORD *)v86 + 24LL))(
                                  v86,
                                  v80);
                                v80 = (volatile signed __int32 *)v118;
                              }
                            }
                            goto LABEL_137;
                          }
                        }
                      }
                      LOBYTE(v85) = v84 == 0;
                      LODWORD(v114) = v85;
LABEL_137:
                      if ( v80 )
                      {
                        if ( !_InterlockedSub(v80 + 2, 1u) )
                        {
                          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v80 + 16LL))(v80);
                          if ( !_InterlockedSub(v80 + 3, 1u) )
                            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v80 + 24LL))(v80);
                        }
                      }
                    }
                    else
                    {
                      LODWORD(v114) = 0;
                    }
                    if ( !_InterlockedSub(v76 + 2, 1u) )
                    {
                      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v76 + 16LL))(v76);
                      if ( !_InterlockedSub(v76 + 3, 1u) )
                        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v76 + 24LL))(v76);
                    }
                    if ( (_BYTE)v114 )
                    {
                      v90 = COERCE_FLOAT(*(_QWORD *)(v73 + 688) + **(_DWORD **)(v73 + 688)) * 0.5;
                      v91 = (char *)ptr[0];
                      *((float *)ptr[0] + 8 * v72) = *((float *)ptr[0] + 8 * v72) * v90;
                      *(float *)&v91[v92 + 4] = *(float *)&v91[v92 + 4] * v90;
                      *(float *)&v91[v92 + 8] = v90 * *(float *)&v91[v92 + 8];
                    }
                    break;
                  }
                }
              }
            }
          }
        }
        v94 = *(_QWORD *)(*((_QWORD *)this + 31) + v92 + 16);
        (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v94 + 32LL))(v94, 1);
        v95 = *(_QWORD *)(*((_QWORD *)this + 31) + v92 + 16);
        (*(void (__fastcall **)(__int64, char *))(*(_QWORD *)v95 + 24LL))(v95, (char *)ptr[0] + v92);
      }
      ++v72;
      v71 = *(_QWORD *)joints;
    }
    while ( v72 < (__int64)(*v15 - *(_QWORD *)joints) >> 5 );
  }
  if ( v109 )
  {
    if ( !_InterlockedSub(v109 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v109 + 16LL))(v109);
      if ( !_InterlockedSub(v109 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v109 + 24LL))(v109);
    }
  }
  v3 = category;
  if ( ptr[0] )
  {
    ptr[1] = ptr[0];
    operator delete(ptr[0]);
  }
  if ( jointRoot.px )
  {
    jointRoot.pn.pi_ = (boost::detail::sp_counted_base *)jointRoot.px;
    operator delete(jointRoot.px);
  }
LABEL_160:
  RBX::Profiler::leaveRegion(token, enterTimestamp);
  RBX::Memory::setCurrentCategory(v3);
}


// Address: 0x103ae10 | Name: _ZN3RBX8Animator24replicateAnimationUpdateENS_9ContentIdEbffffiPKNS_13SystemAddressE
void __fastcall RBX::Animator::replicateAnimationUpdate(
        __int64 a1,
        __int64 a2,
        unsigned int a3,
        unsigned int a4,
        __int64 a5,
        float a6,
        float a7,
        float a8,
        float a9)
{
  _BYTE v12[16]; // [rsp+18h] [rbp-50h] BYREF
  void *ptr; // [rsp+28h] [rbp-40h]
  __int64 v14; // [rsp+30h] [rbp-38h] BYREF
  int v15; // [rsp+38h] [rbp-30h]

  std::string::basic_string(v12, a2);
  v14 = a5;
  v15 = 0;
  RBX::Reflection::RemoteEventDesc<RBX::Animator,void ()(RBX::ContentId,bool,float,float,float,float,int),rbx::remote_signal<void ()(RBX::ContentId,bool,float,float,float,float,int)>,rbx::remote_signal<void ()(RBX::ContentId,bool,float,float,float,float,int)> RBX::Animator::*>::replicateEvent(
    qword_2858690,
    a1,
    v12,
    a3,
    a4,
    &v14,
    a6,
    a7,
    a8,
    a9);
  if ( (v12[0] & 1) != 0 )
    operator delete(ptr);
}


// Address: 0x103aed0 | Name: _ZThn128_N3RBX8Animator9onSteppedERKNS_7SteppedE
void __fastcall `non-virtual thunk to'RBX::Animator::onStepped(RBX::Animator *this, const RBX::Stepped *event)
{
  RBX::Animator::onStepped((RBX::Animator *)((char *)this - 128), event);
}


// Address: 0x103aee0 | Name: _ZN3RBX8Animator13onPlayerAddedEN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Animator::onPlayerAdded(RBX::Animator *this, boost::shared_ptr<RBX::Instance> inst)
{
  __int64 v3; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  int (**v5)(void); // rdi
  volatile signed __int32 *px; // r14
  RBX::SystemAddress RemoteAddressAsRbxAddress; // rax
  RBX::SystemAddress *v8; // rcx
  RBX::SystemAddress __x; // [rsp+8h] [rbp-20h] BYREF

  if ( !inst.px->_vptr$EventSource )
    return;
  v3 = *((_QWORD *)inst.px->_vptr$EventSource + 3);
  DescriptorPtr = Class_getDescriptorPtr(0);
  if ( *(unsigned __int16 *)(v3 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364) )
    return;
  v5 = inst.px->_vptr$EventSource;
  px = (volatile signed __int32 *)inst.px->weak_this_.px;
  if ( px )
    _InterlockedAdd(px + 2, 1u);
  if ( v5 )
  {
    RemoteAddressAsRbxAddress = RBX::Player::getRemoteAddressAsRbxAddress((const RBX::Player *)v5);
    __x = RemoteAddressAsRbxAddress;
    v8 = (RBX::SystemAddress *)*((_QWORD *)this + 20);
    if ( v8 != *((RBX::SystemAddress **)this + 21) )
    {
      *v8 = RemoteAddressAsRbxAddress;
      *((_QWORD *)this + 20) += 8LL;
      if ( !px )
        return;
      goto LABEL_11;
    }
    std::vector<RBX::SystemAddress>::__push_back_slow_path<RBX::SystemAddress const&>(
      (RBX::Animator *)((char *)this + 152),
      &__x);
  }
  if ( !px )
    return;
LABEL_11:
  if ( !_InterlockedSub(px + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)px + 16LL))(px);
    if ( !_InterlockedSub(px + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)px + 24LL))(px);
  }
}


// Address: 0x103aff0 | Name: _ZN3RBX8Animator17onServiceProviderEPNS_15ServiceProviderES2_
void __fastcall RBX::Animator::onServiceProvider(
        RBX::Animator *this,
        RBX::ServiceProvider *oldProvider,
        RBX::ServiceProvider *newProvider)
{
  RBX::DataModel *v4; // rax
  boost::shared_ptr<RBX::Instance>::element_type *px; // r14
  rbx::signals::connection *v6; // r15
  rbx::signals::slot_base *p; // rdi
  rbx::signals::connection other; // [rsp+8h] [rbp-40h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Animator,boost::shared_ptr<RBX::Instance> >,boost::_bi::list2<boost::_bi::value<RBX::Animator *>,boost::arg<1> > > function; // [rsp+10h] [rbp-38h] BYREF

  RBX::Instance::onServiceProvider((RBX::Instance *)this, oldProvider, newProvider);
  RBX::IStepped::onServiceProviderIStepped((RBX::IStepped *)((char *)this + 128), oldProvider, newProvider);
  v4 = RBX::DataModel::get((RBX::Instance *)this);
  if ( v4 )
  {
    px = RBX::ServiceProvider::refByClass<RBX::Players>((RBX::DataModel *)((char *)v4 + 136))->px;
    if ( px )
    {
      if ( RBX::Network::Server::serverIsPresent((const RBX::Instance *)this, 1) )
      {
        function.f_ = (boost::_mfi::mf1<void,RBX::Animator,boost::shared_ptr<RBX::Instance> >)(unsigned __int64)RBX::Animator::onPlayerAdded;
        function.l_.a1_.t_ = this;
        rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::Animator,boost::shared_ptr<RBX::Instance>>,boost::_bi::list2<boost::_bi::value<RBX::Animator*>,boost::arg<1>>>>(
          (rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *)&px[5].onDemandPtr,
          &function);
        v6 = (rbx::signals::connection *)((char *)this + 176);
        if ( rbx::signals::connection::operator!=((const rbx::signals::connection *)this + 22, &other) )
        {
          rbx::signals::connection::disconnect(v6);
          rbx::signals::connection::operator=(v6, &other);
        }
        p = other.weak_slot.p_;
        if ( other.weak_slot.p_ )
        {
          if ( !_InterlockedSub(&other.weak_slot.p_->weak.v, 1u) )
            operator delete(p);
        }
      }
    }
  }
}


// Address: 0x103b100 | Name: _ZNK3RBX8Animator15verifySetParentEPKNS_8InstanceE
void __fastcall RBX::Animator::verifySetParent(const RBX::Animator *this, const RBX::Instance *instance)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  const RBX::Reflection::ClassDescriptor *v4; // rbx
  RBX::Reflection::ClassDescriptor *v5; // rax
  RBX *exception; // rbx

  if ( instance )
  {
    descriptor = instance->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) > *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      v4 = instance->descriptor;
      v5 = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)v4 + 363) - (unsigned int)*((unsigned __int16 *)v5 + 363) > *((unsigned __int16 *)v5
                                                                                             + 364) )
      {
        exception = (RBX *)__cxa_allocate_exception(0x10u);
        RBX::runtime_error(exception, "Animator has to be placed under Humanoid or AnimationController!");
        __cxa_throw(
          exception,
          (struct type_info *)&`typeinfo for'std::runtime_error,
          (void (*)(void *))&std::runtime_error::~runtime_error);
      }
    }
  }
}


// Address: 0x103b1b0 | Name: _ZN3RBX8Animator17onAncestorChangedERKNS_15AncestorChangedE
void __fastcall RBX::Animator::onAncestorChanged(RBX::Animator *this, const RBX::AncestorChanged *event)
{
  RBX::Instance *v3; // rbp
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  bool IsWorldModelRefactorEnabled; // al
  const RBX::Reflection::ClassDescriptor *v7; // r13
  RBX::Reflection::ClassDescriptor *v8; // rax
  __int64 v9; // rax
  RBX::OnDemandInstance *v10; // rax
  rbx::signals::slot_base *p; // rdi
  RBX::OnDemandInstance *v12; // rax
  rbx::signals::slot_base *v13; // rdi
  rbx::signals::connection other; // [rsp+8h] [rbp-70h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Animator>,boost::_bi::list1<boost::_bi::value<RBX::Animator *> > > function; // [rsp+10h] [rbp-68h] BYREF
  __m128i v16[4]; // [rsp+30h] [rbp-48h] BYREF

  RBX::Instance::onAncestorChanged((RBX::Instance *)this, event);
  *((_BYTE *)this + 272) = 1;
  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 35);
  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 36);
  if ( stru_2A015C0.value )
  {
    v3 = (RBX::Instance *)this;
    while ( 1 )
    {
      v3 = v3->parent;
      if ( !v3 )
        break;
      descriptor = v3->descriptor;
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        if ( !stru_2A015D8.value )
        {
          IsWorldModelRefactorEnabled = RBX::WorldRoot::IsWorldModelRefactorEnabled();
          v7 = v3->descriptor;
          v8 = IsWorldModelRefactorEnabled ? Class_getDescriptorPtr(0) : Class_getDescriptorPtr(0);
          if ( *((unsigned __int16 *)v7 + 363) - (unsigned int)*((unsigned __int16 *)v8 + 363) <= *((unsigned __int16 *)v8
                                                                                                  + 364) )
            return;
        }
        goto LABEL_13;
      }
    }
  }
  else
  {
    v9 = *((_QWORD *)this + 11);
    if ( v9 )
    {
      v3 = *(RBX::Instance **)(v9 + 88);
      if ( v3 )
      {
LABEL_13:
        RBX::Instance::onDemandRead(v3);
        v10 = RBX::Instance::onDemandWrite(v3);
        v16[0] = (__m128i)(unsigned __int64)RBX::Animator::onAnimatableJointsChanged;
        function.f_ = (boost::_mfi::mf0<void,RBX::Animator>)(unsigned __int64)RBX::Animator::onAnimatableJointsChanged;
        function.l_.a1_.t_ = this;
        rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Animator>,boost::_bi::list1<boost::_bi::value<RBX::Animator*>>>>(
          (rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *)v10 + 3,
          &function);
        if ( rbx::signals::connection::operator!=((const rbx::signals::connection *)this + 35, &other) )
        {
          rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 35);
          rbx::signals::connection::operator=((rbx::signals::connection *)this + 35, &other);
        }
        p = other.weak_slot.p_;
        if ( other.weak_slot.p_ && !_InterlockedSub(&other.weak_slot.p_->weak.v, 1u) )
          operator delete(p);
        RBX::Instance::onDemandRead(v3);
        v12 = RBX::Instance::onDemandWrite(v3);
        function.f_ = (boost::_mfi::mf0<void,RBX::Animator>)_mm_load_si128(v16);
        function.l_.a1_.t_ = this;
        rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::Animator>,boost::_bi::list1<boost::_bi::value<RBX::Animator*>>>>(
          (rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *)v12 + 4,
          &function);
        if ( rbx::signals::connection::operator!=((const rbx::signals::connection *)this + 36, &other) )
        {
          rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 36);
          rbx::signals::connection::operator=((rbx::signals::connection *)this + 36, &other);
        }
        v13 = other.weak_slot.p_;
        if ( other.weak_slot.p_ )
        {
          if ( !_InterlockedSub(&other.weak_slot.p_->weak.v, 1u) )
            operator delete(v13);
        }
      }
    }
  }
}


// Address: 0x103b3c0 | Name: _ZN3RBX8Animator25onAnimatableJointsChangedEv
void __fastcall RBX::Animator::onAnimatableJointsChanged(RBX::Animator *this)
{
  *((_BYTE *)this + 272) = 1;
}


// Address: 0x103b3d0 | Name: _ZN3RBX8Animator13onAdjustSpeedENS_9ContentIdEf
void __fastcall RBX::Animator::onAdjustSpeed(__int64 a1, const RBX::ContentId *a2, double a3, float a4)
{
  __int64 v4; // rbx
  __int64 v5; // r12
  bool v6; // al

  v4 = *(_QWORD *)(a1 + 216);
  if ( v4 )
  {
    v5 = a1 + 216;
    do
    {
      v6 = RBX::operator<((const RBX::ContentId *)(v4 + 32), a2);
      if ( !v6 )
        v5 = v4;
      v4 = *(_QWORD *)(v4 + 8LL * v6);
    }
    while ( v4 );
    if ( v5 != a1 + 216 && !RBX::operator<(a2, (const RBX::ContentId *)(v5 + 32)) && !RBX::Math::isNanInf(a4) )
      RBX::AnimationTrack::localAdjustSpeed(*(RBX::AnimationTrack **)(v5 + 56), a4);
  }
}


// Address: 0x103b470 | Name: _ZN3RBX8Animator14onAdjustWeightENS_9ContentIdEff
void __fastcall RBX::Animator::onAdjustWeight(__int64 a1, const RBX::ContentId *a2, double a3, float a4, float a5)
{
  __int64 v5; // rbx
  __int64 v6; // r12
  bool v7; // al

  v5 = *(_QWORD *)(a1 + 216);
  if ( v5 )
  {
    v6 = a1 + 216;
    do
    {
      v7 = RBX::operator<((const RBX::ContentId *)(v5 + 32), a2);
      if ( !v7 )
        v6 = v5;
      v5 = *(_QWORD *)(v5 + 8LL * v7);
    }
    while ( v5 );
    if ( v6 != a1 + 216
      && !RBX::operator<(a2, (const RBX::ContentId *)(v6 + 32))
      && !RBX::Math::isNanInf(a4)
      && !RBX::Math::isNanInf(a4) )
    {
      RBX::AnimationTrack::localAdjustWeight(*(RBX::AnimationTrack **)(v6 + 56), a4, a5);
    }
  }
}


// Address: 0x103b520 | Name: _ZN3RBX8Animator6onPlayENS_9ContentIdEfff
unsigned int __fastcall RBX::Animator::onPlay(
        __int64 a1,
        const RBX::ContentId *a2,
        double a3,
        float a4,
        float a5,
        float a6)
{
  unsigned int v6; // r14d
  __int64 **v7; // r12
  __int64 *v8; // rbp
  __int64 **v9; // rbx
  bool v10; // al
  __int64 *v11; // rbp
  bool v12; // al
  boost::detail::sp_counted_base *v13; // rbp
  _BYTE v15[16]; // [rsp+10h] [rbp-58h] BYREF
  void *ptr; // [rsp+20h] [rbp-48h]
  boost::shared_ptr<RBX::Instance> animationTrack; // [rsp+28h] [rbp-40h] BYREF

  v6 = RBX::Memory::setCurrentCategory(dword_2A04350);
  v7 = (__int64 **)(a1 + 216);
  v8 = *(__int64 **)(a1 + 216);
  if ( !v8 )
    goto LABEL_35;
  v9 = (__int64 **)(a1 + 216);
  do
  {
    v10 = RBX::operator<((const RBX::ContentId *)(v8 + 4), a2);
    if ( !v10 )
      v9 = (__int64 **)v8;
    v8 = (__int64 *)v8[v10];
  }
  while ( v8 );
  if ( v9 == v7 || RBX::operator<(a2, (const RBX::ContentId *)(v9 + 4)) )
  {
LABEL_35:
    if ( !RBX::OverflowingLeakyBucket::checkAdd((RBX::OverflowingLeakyBucket *)(a1 + 184), a4) )
    {
      RBX::OverflowingLeakyBucket::checkAdd((RBX::OverflowingLeakyBucket *)(a1 + 184), a4);
      return RBX::Memory::setCurrentCategory(v6);
    }
    std::string::basic_string(v15, a2);
    RBX::Animator::passiveLoadAnimation(a1, v15, 1.0);
    if ( (v15[0] & 1) != 0 )
      operator delete(ptr);
    v11 = *v7;
    if ( !*v7 )
      goto LABEL_24;
    v9 = (__int64 **)(a1 + 216);
    do
    {
      v12 = RBX::operator<((const RBX::ContentId *)(v11 + 4), a2);
      if ( !v12 )
        v9 = (__int64 **)v11;
      v11 = (__int64 *)v11[v12];
    }
    while ( v11 );
    if ( v9 == v7 || RBX::operator<(a2, (const RBX::ContentId *)(v9 + 4)) )
      goto LABEL_24;
  }
  if ( v9 == v7 )
    goto LABEL_24;
  if ( !RBX::OverflowingLeakyBucket::checkAdd((RBX::OverflowingLeakyBucket *)(a1 + 184), a4) )
  {
    RBX::OverflowingLeakyBucket::checkAdd((RBX::OverflowingLeakyBucket *)(a1 + 184), a4);
    return RBX::Memory::setCurrentCategory(v6);
  }
  if ( !RBX::Math::isNanInf(a4) && !RBX::Math::isNanInf(a4) && !RBX::Math::isNanInf(a4) )
  {
    RBX::AnimationTrack::localPlay((RBX::AnimationTrack *)v9[7], a4, a5, a6);
    v7 = v9;
LABEL_24:
    animationTrack.px = (boost::shared_ptr<RBX::Instance>::element_type *)v7[7];
    v13 = (boost::detail::sp_counted_base *)v7[8];
    animationTrack.pn.pi_ = v13;
    if ( v13 )
      _InterlockedAdd(&v13->use_count_, 1u);
    RBX::Animator::tellParentAnimationPlayed((RBX::Animator *)a1, &animationTrack);
    if ( v13 )
    {
      if ( !_InterlockedSub(&v13->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 2))(v13);
        if ( !_InterlockedSub(&v13->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v13->_vptr$sp_counted_base + 3))(v13);
      }
    }
  }
  return RBX::Memory::setCurrentCategory(v6);
}


// Address: 0x103b7d0 | Name: _ZN3RBX8Animator6onStopENS_9ContentIdEf
void __fastcall RBX::Animator::onStop(__int64 a1, const RBX::ContentId *a2, double a3, float a4)
{
  __int64 v4; // rbx
  __int64 v5; // r12
  bool v6; // al

  v4 = *(_QWORD *)(a1 + 216);
  if ( v4 )
  {
    v5 = a1 + 216;
    do
    {
      v6 = RBX::operator<((const RBX::ContentId *)(v4 + 32), a2);
      if ( !v6 )
        v5 = v4;
      v4 = *(_QWORD *)(v4 + 8LL * v6);
    }
    while ( v4 );
    if ( v5 != a1 + 216 && !RBX::operator<(a2, (const RBX::ContentId *)(v5 + 32)) && !RBX::Math::isNanInf(a4) )
      RBX::AnimationTrack::localStop(*(RBX::AnimationTrack **)(v5 + 56), a4);
  }
}


// Address: 0x103b870 | Name: _ZN3RBX8Animator17onSetTimePositionENS_9ContentIdEf
void __fastcall RBX::Animator::onSetTimePosition(__int64 a1, const RBX::ContentId *a2, double a3, float a4)
{
  __int64 v4; // rbx
  __int64 v5; // r12
  bool v6; // al

  v4 = *(_QWORD *)(a1 + 216);
  if ( v4 )
  {
    v5 = a1 + 216;
    do
    {
      v6 = RBX::operator<((const RBX::ContentId *)(v4 + 32), a2);
      if ( !v6 )
        v5 = v4;
      v4 = *(_QWORD *)(v4 + 8LL * v6);
    }
    while ( v4 );
    if ( v5 != a1 + 216 && !RBX::operator<(a2, (const RBX::ContentId *)(v5 + 32)) && !RBX::Math::isNanInf(a4) )
      RBX::AnimationTrack::localSetTimePosition(*(RBX::AnimationTrack **)(v5 + 56), a4);
  }
}


// Address: 0x103b910 | Name: _ZN3RBX8Animator20passiveLoadAnimationENS_9ContentIdE
void __fastcall RBX::Animator::passiveLoadAnimation(unsigned __int64 a1, const RBX::ContentId *a2)
{
  unsigned __int64 v2; // rbx
  unsigned __int64 v3; // r14
  bool v4; // al
  __int64 v5; // rbx
  __int64 v6; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  volatile signed __int32 *v8; // r14
  std::pair<std::__tree_iterator<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> >,std::__tree_node<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> >,void *> *,long>,bool> v9; // rax
  volatile signed __int32 *v10; // rbx
  volatile signed __int32 *v11; // rbx
  __int64 v12; // [rsp+0h] [rbp-98h]
  volatile signed __int32 *v13; // [rsp+8h] [rbp-90h]
  __int64 v14; // [rsp+10h] [rbp-88h] BYREF
  volatile signed __int32 *v15; // [rsp+18h] [rbp-80h]
  _BYTE v16[16]; // [rsp+20h] [rbp-78h] BYREF
  void *v17; // [rsp+30h] [rbp-68h]
  __int64 v18; // [rsp+38h] [rbp-60h]
  volatile signed __int32 *v19; // [rsp+40h] [rbp-58h]
  _BYTE v20[16]; // [rsp+48h] [rbp-50h] BYREF
  void *ptr; // [rsp+58h] [rbp-40h]
  _QWORD instance[7]; // [rsp+60h] [rbp-38h] BYREF

  v2 = *(_QWORD *)(a1 + 216);
  if ( !v2 )
    goto LABEL_8;
  v3 = a1 + 216;
  do
  {
    v4 = RBX::operator<((const RBX::ContentId *)(v2 + 32), a2);
    if ( !v4 )
      v3 = v2;
    v2 = *(_QWORD *)(v2 + 8LL * v4);
  }
  while ( v2 );
  if ( v3 == a1 + 216 || RBX::operator<(a2, (const RBX::ContentId *)(v3 + 32)) )
  {
LABEL_8:
    RBX::Creatable<RBX::Instance>::create<RBX::Animation>();
    std::string::basic_string(v20, a2);
    RBX::Animation::setAssetId(v12, v20);
    if ( (v20[0] & 1) != 0 )
      operator delete(ptr);
    instance[0] = v12;
    instance[1] = v13;
    if ( v13 )
      _InterlockedAdd(v13 + 2, 1u);
    RBX::Animator::loadAnimation((RBX::Animator *)&v14, (boost::shared_ptr<RBX::Instance>)__PAIR128__(instance, a1));
    if ( v13 )
    {
      if ( !_InterlockedSub(v13 + 2, 1u) )
      {
        (*(void (__fastcall **)())(*(_QWORD *)v13 + 16LL))();
        if ( !_InterlockedSub(v13 + 3, 1u) )
          (*(void (__fastcall **)())(*(_QWORD *)v13 + 24LL))();
      }
    }
    v5 = v14;
    if ( v14 )
    {
      v6 = *(_QWORD *)(v14 + 24);
      DescriptorPtr = Class_getDescriptorPtr(0);
      if ( *(unsigned __int16 *)(v6 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      {
        v8 = v15;
        if ( v15 )
          _InterlockedAdd(v15 + 2, 1u);
        std::string::basic_string(v16, a2);
        v18 = v5;
        v19 = v8;
        if ( v8 )
          _InterlockedAdd(v8 + 2, 1u);
        v9 = std::__tree<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack>>,std::__map_value_compare<RBX::ContentId,std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack>>,std::less<RBX::ContentId>,true>,std::allocator<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack>>>>::__emplace_unique_key_args<RBX::ContentId,std::pair<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack>>>(
               (std::__tree<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> >,std::__map_value_compare<RBX::ContentId,std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> >,std::less<RBX::ContentId>,true>,std::allocator<std::__value_type<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> > > > *)(a1 + 208),
               (const RBX::ContentId *)v16,
               (std::pair<RBX::ContentId,boost::shared_ptr<RBX::AnimationTrack> > *)v16);
        v10 = v19;
        if ( v19 )
        {
          if ( !_InterlockedSub(v19 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *, _BYTE *, _QWORD))(*(_QWORD *)v10 + 16LL))(
              v10,
              v16,
              *(_QWORD *)&v9.second);
            if ( !_InterlockedSub(v10 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
          }
        }
        if ( (v16[0] & 1) != 0 )
          operator delete(v17);
        if ( v8 )
        {
          if ( !_InterlockedSub(v8 + 2, 1u) )
          {
            (*(void (__fastcall **)(volatile signed __int32 *, _BYTE *, _QWORD))(*(_QWORD *)v8 + 16LL))(
              v8,
              v16,
              *(_QWORD *)&v9.second);
            if ( !_InterlockedSub(v8 + 3, 1u) )
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
          }
        }
      }
    }
    v11 = v15;
    if ( v15 )
    {
      if ( !_InterlockedSub(v15 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
        if ( !_InterlockedSub(v11 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
      }
    }
    if ( v13 && !_InterlockedSub(v13 + 2, 1u) )
    {
      (*(void (__fastcall **)())(*(_QWORD *)v13 + 16LL))();
      if ( !_InterlockedSub(v13 + 3, 1u) )
        (*(void (__fastcall **)())(*(_QWORD *)v13 + 24LL))();
    }
  }
}


// Address: 0x103bcc0 | Name: _ZN3RBX8Animator25tellParentAnimationPlayedERKN5boost10shared_ptrINS_8InstanceEEE
void __fastcall RBX::Animator::tellParentAnimationPlayed(
        RBX::Animator *this,
        const boost::shared_ptr<RBX::Instance> *animationTrack)
{
  unsigned __int64 v2; // rdx
  rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *v4; // rdi
  boost::detail::sp_counted_base *pi; // rax
  boost::detail::sp_counted_base *v6; // rbx
  rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *v7; // rbx
  rbx::signals::slot_base *px; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  unsigned __int64 v10; // rdx
  rbx::signals::slot_base *v11; // r15
  RBX::Reflection::ClassDescriptor *v12; // rax
  unsigned __int64 v13; // rdx
  rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *v14; // rbx
  boost::detail::sp_counted_base *v15; // rax
  volatile signed __int32 *v16; // rbx
  rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *v17; // rbx
  boost::detail::sp_counted_base *v18; // rax
  boost::detail::sp_counted_base *v19; // rbx
  boost::shared_ptr<RBX::Instance>::element_type *v20; // [rsp+0h] [rbp-48h] BYREF
  volatile signed __int32 *v21; // [rsp+8h] [rbp-40h]
  boost::shared_ptr<RBX::Instance> v22; // [rsp+10h] [rbp-38h] BYREF
  boost::shared_ptr<RBX::Instance> args; // [rsp+20h] [rbp-28h] BYREF

  if ( stru_2A01620.value )
  {
    v4 = (rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *)((char *)this + 336);
    args.px = animationTrack->px;
    pi = animationTrack->pn.pi_;
    args.pn.pi_ = pi;
    if ( pi )
      _InterlockedAdd(&pi->use_count_, 1u);
    rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>::operator()(
      v4,
      (boost::shared_ptr<RBX::Instance>)__PAIR128__(v2, &args));
    v6 = args.pn.pi_;
    if ( args.pn.pi_ )
    {
      if ( !_InterlockedSub(&args.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 2))(v6);
        if ( !_InterlockedSub(&v6->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v6->_vptr$sp_counted_base + 3))(v6);
      }
    }
  }
  v7 = (rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *)*((_QWORD *)this + 11);
  if ( v7 )
  {
    px = v7[3].head.px;
    DescriptorPtr = Class_getDescriptorPtr(0);
    v10 = *((unsigned __int16 *)DescriptorPtr + 363);
    if ( HIWORD(px[18].weak.v) - (unsigned int)v10 <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      v17 = v7 + 18;
      v22.px = animationTrack->px;
      v18 = animationTrack->pn.pi_;
      v22.pn.pi_ = v18;
      if ( v18 )
        _InterlockedAdd(&v18->use_count_, 1u);
      rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>::operator()(
        v17,
        (boost::shared_ptr<RBX::Instance>)__PAIR128__(v10, &v22));
      v19 = v22.pn.pi_;
      if ( v22.pn.pi_ )
      {
        if ( !_InterlockedSub(&v22.pn.pi_->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 2))(v19);
          if ( !_InterlockedSub(&v19->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))v19->_vptr$sp_counted_base + 3))(v19);
        }
      }
    }
    else
    {
      v11 = v7[3].head.px;
      v12 = Class_getDescriptorPtr(0);
      v13 = *((unsigned __int16 *)v12 + 363);
      if ( HIWORD(v11[18].weak.v) - (unsigned int)v13 <= *((unsigned __int16 *)v12 + 364) )
      {
        v14 = v7 + 346;
        v20 = animationTrack->px;
        v15 = animationTrack->pn.pi_;
        v21 = (volatile signed __int32 *)v15;
        if ( v15 )
          _InterlockedAdd(&v15->use_count_, 1u);
        rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>::operator()(
          v14,
          (boost::shared_ptr<RBX::Instance>)__PAIR128__(v13, &v20));
        v16 = v21;
        if ( v21 && !_InterlockedSub(v21 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 16LL))(v16);
          if ( !_InterlockedSub(v16 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v16 + 24LL))(v16);
        }
      }
    }
  }
}


// Address: 0x103bf20 | Name: _ZN3RBX8Animator13render3dAdornEPNS_5AdornE
void __fastcall RBX::Animator::render3dAdorn(RBX::Animator *this, RBX::Adorn *adorn)
{
  RBX::Humanoid *v2; // rbx
  __int64 v3; // rbp
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  RBX::PartInstance *TorsoSlow; // rax
  const RBX::PartInstance *v6; // rbx
  RBX::Instance *parent; // rax
  const RBX::PartInstance *v8; // rbp
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *v10; // rax
  boost::shared_ptr<RBX::Instance>::element_type *px; // rbp
  __m128 y_low; // xmm0
  const RBX::Camera *v13; // rax
  char *v14; // rbp
  __int64 v15; // rbx
  int v16; // r15d
  int v17; // r12d
  const char *v18; // rdx
  const char *v19; // r12
  __m128 v20; // xmm0
  size_t v21; // rax
  size_t v22; // rbx
  char *v23; // r13
  size_t v24; // r14
  const G3D::Color3 *v25; // rax
  const G3D::Color3 *v26; // rax
  __int64 v27; // r13
  const RBX::AnimationTrack *v28; // rdi
  const boost::flyweights::detail::refcounted_value<boost::flyweights::detail::default_value_policy<std::string >::rep_type,std::string > *h; // rbx
  char *v30; // rbx
  bool v31; // zf
  const char *v32; // rcx
  const char *v33; // r12
  __m128 v34; // xmm0
  size_t v35; // rax
  size_t v36; // rbp
  char *v37; // r14
  size_t v38; // rbx
  RBX::RotationAngle *v39; // rax
  const G3D::Color3 *v40; // rax
  struct _Unwind_Exception *v41; // rbx
  __int128 dest; // [rsp+0h] [rbp-138h] BYREF
  void *ptr; // [rsp+10h] [rbp-128h]
  char v44; // [rsp+18h] [rbp-120h] BYREF
  char s[15]; // [rsp+19h] [rbp-11Fh] BYREF
  void *v46; // [rsp+28h] [rbp-110h]
  G3D::Vector3 v47; // [rsp+30h] [rbp-108h] BYREF
  RBX::Color4 color; // [rsp+40h] [rbp-F8h] BYREF
  RBX::Animator *v49; // [rsp+50h] [rbp-E8h]
  char *v50; // [rsp+58h] [rbp-E0h]
  char *v51; // [rsp+60h] [rbp-D8h]
  RBX::Vector2 position; // [rsp+68h] [rbp-D0h] BYREF
  _BYTE v53[24]; // [rsp+70h] [rbp-C8h] BYREF
  RBX::Color4 outline; // [rsp+90h] [rbp-A8h] BYREF
  RBX::Vector3 point; // [rsp+A0h] [rbp-98h] BYREF
  RBX::Rotation2D rotation; // [rsp+B0h] [rbp-88h] BYREF
  RBX::Adorn *v57; // [rsp+C8h] [rbp-70h]
  double Speed; // [rsp+D0h] [rbp-68h]
  double CurrentWeight; // [rsp+D8h] [rbp-60h]
  double Length; // [rsp+E0h] [rbp-58h]
  double TimePosition; // [rsp+E8h] [rbp-50h]
  RBX::Rect2D clippingRect; // [rsp+F0h] [rbp-48h] BYREF
  RBX::Vector2 availableSpace; // [rsp+100h] [rbp-38h] BYREF
  RBX::Vector3 v64; // 0:kr00_12.12

  v57 = adorn;
  v49 = this;
  v2 = (RBX::Humanoid *)*((_QWORD *)this + 11);
  if ( v2 )
  {
    v3 = *((_QWORD *)v2 + 3);
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *(unsigned __int16 *)(v3 + 726) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      TorsoSlow = RBX::Humanoid::getTorsoSlow(v2);
      if ( TorsoSlow )
      {
        v6 = TorsoSlow;
        parent = TorsoSlow->parent;
        if ( parent )
        {
          do
          {
            v8 = (const RBX::PartInstance *)parent;
            parent = parent->parent;
          }
          while ( parent );
        }
        else
        {
          v8 = v6;
        }
        descriptor = v8->descriptor;
        v10 = Class_getDescriptorPtr(0);
        if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)v10 + 363) <= *((unsigned __int16 *)v10 + 364) )
        {
          px = RBX::ServiceProvider::refByClass<RBX::Workspace>((const RBX::ServiceProvider *)v8)->px;
          if ( px )
          {
            point = RBX::PartInstance::getCoordinateFrame(v6)->translation;
            y_low = (__m128)LODWORD(point.y);
            point.y = point.y + 1.5;
            v13 = (const RBX::Camera *)(*((__int64 (__fastcall **)(boost::shared_ptr<RBX::Instance>::element_type *))px->_vptr$EventSource
                                        + 49))(px);
            v64 = RBX::Camera::project(v13, &point);
            y_low.m128_i32[0] = LODWORD(v64.x);
            y_low.m128_i32[1] = LODWORD(v64.y);
            _mm_storel_ps((double *)&v47.x, y_low);
            v47.z = v64.z;
            if ( v64.z < INFINITY && v64.z >= 20.0 )
            {
              v14 = (char *)v49 + 296;
              v50 = (char *)&unk_4A6B50;
              v51 = (char *)v49 + 296;
              while ( 1 )
              {
                v15 = *((_QWORD *)v49 + 38);
                if ( v14 == (char *)v15 )
                  goto LABEL_58;
                v16 = *(_DWORD *)v50;
                v17 = 0;
                do
                {
                  v17 += RBX::AnimationTrack::getPriority(*(const RBX::AnimationTrack **)(v15 + 16)) == v16;
                  v15 = *(_QWORD *)(v15 + 8);
                }
                while ( v14 != (char *)v15 );
                if ( !v17 )
                  goto LABEL_58;
                if ( !(_BYTE)byte_2A01BE0 && __cxa_guard_acquire(&byte_2A01BE0) )
                {
                  RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority>::EnumDesc((RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority> *)qword_2A01B28);
                  __cxa_atexit(
                    (void (*)(void *))RBX::Reflection::EnumDesc<RBX::KeyframeSequence::Priority>::~EnumDesc,
                    qword_2A01B28,
                    &dso_handle);
                  __cxa_guard_release(&byte_2A01BE0);
                  v14 = v51;
                }
                RBX::Reflection::EnumDescriptor::_convertToString(
                  (RBX::Reflection::EnumDescriptor *)v53,
                  (int)qword_2A01B28);
                v18 = &v53[1];
                if ( (v53[0] & 1) != 0 )
                  v18 = *(const char **)&v53[16];
                RBX::format((RBX *)&v44, "%s (%d):", v18, v17);
                v19 = s;
                if ( (v44 & 1) != 0 )
                  v19 = (const char *)v46;
                v20 = 0;
                dest = 0;
                ptr = 0;
                v21 = strlen(v19);
                if ( v21 >= 0xFFFFFFFFFFFFFFF0LL )
                {
LABEL_61:
                  v41 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(&dest);
                  if ( (v44 & 1) != 0 )
                  {
                    operator delete(v46);
                    if ( (v53[0] & 1) == 0 )
                      goto LABEL_66;
                  }
                  else if ( (v53[0] & 1) == 0 )
                  {
LABEL_66:
                    _Unwind_Resume(v41);
                  }
                  operator delete(*(void **)&v53[16]);
                  _Unwind_Resume(v41);
                }
                v22 = v21;
                if ( v21 >= 0x17 )
                  break;
                LOBYTE(dest) = 2 * v21;
                v23 = (char *)&dest + 1;
                if ( v21 )
                  goto LABEL_32;
LABEL_33:
                v23[v22] = 0;
                *(G3D::Vector2 *)v20.m128_f32 = G3D::Vector3::xy(&v47);
                _mm_storel_ps((double *)&position, v20);
                v25 = G3D::Color3::white();
                color.r = v25->r;
                color.g = v25->g;
                color.b = v25->b;
                color.a = 1.0;
                v26 = G3D::Color3::black();
                outline.r = v26->r;
                outline.g = v26->g;
                outline.b = v26->b;
                outline.a = 1.0;
                _mm_storel_ps((double *)&availableSpace, (__m128)0LL);
                clippingRect = (RBX::Rect2D)xmmword_3E7230;
                *(_OWORD *)&rotation.angle.value = xmmword_3E4990;
                rotation.center.y = 0.0;
                RBX::Adorn::drawFont2D(
                  v57,
                  (const std::string *)&dest,
                  &position,
                  14.0,
                  0,
                  &color,
                  &outline,
                  RBX::Text::Font::FONT_SOURCESANS,
                  RBX::Text::XAlign::XALIGN_LEFT,
                  RBX::Text::YAlign::YALIGN_TOP,
                  &availableSpace,
                  &clippingRect,
                  &rotation,
                  1);
                if ( (dest & 1) != 0 )
                {
                  operator delete(ptr);
                  if ( (v44 & 1) == 0 )
                    goto LABEL_35;
                }
                else if ( (v44 & 1) == 0 )
                {
LABEL_35:
                  if ( (v53[0] & 1) == 0 )
                    goto LABEL_37;
LABEL_36:
                  operator delete(*(void **)&v53[16]);
                  goto LABEL_37;
                }
                operator delete(v46);
                if ( (v53[0] & 1) != 0 )
                  goto LABEL_36;
LABEL_37:
                v47.y = v47.y + 16.0;
                v27 = *((_QWORD *)v49 + 38);
                if ( v14 != (char *)v27 )
                {
                  while ( RBX::AnimationTrack::getPriority(*(const RBX::AnimationTrack **)(v27 + 16)) != v16 )
                  {
LABEL_57:
                    v27 = *(_QWORD *)(v27 + 8);
                    if ( v14 == (char *)v27 )
                      goto LABEL_58;
                  }
                  v28 = *(const RBX::AnimationTrack **)(v27 + 16);
                  h = v28->name.h.h;
                  if ( (*(_BYTE *)h & 1) != 0 )
                    v30 = (char *)*((_QWORD *)h + 2);
                  else
                    v30 = (char *)h + 1;
                  TimePosition = RBX::AnimationTrack::getTimePosition(v28);
                  Length = RBX::AnimationTrack::getLength(*(const RBX::AnimationTrack **)(v27 + 16));
                  CurrentWeight = RBX::AnimationTrack::getCurrentWeight(*(const RBX::AnimationTrack **)(v27 + 16));
                  Speed = RBX::AnimationTrack::getSpeed(*(const RBX::AnimationTrack **)(v27 + 16));
                  v31 = !RBX::AnimationTrack::getKeyframeSequence(*(const RBX::AnimationTrack **)(v27 + 16))->loop;
                  v32 = "loop";
                  if ( v31 )
                    v32 = (const char *)&uri_string;
                  RBX::format(
                    (RBX *)&v44,
                    "\t%s: %.2f/%.2f weight %.2f speed %.2f %s",
                    v30,
                    v32,
                    TimePosition,
                    Length,
                    CurrentWeight,
                    Speed);
                  v33 = s;
                  if ( (v44 & 1) != 0 )
                    v33 = (const char *)v46;
                  v34 = 0;
                  dest = 0;
                  ptr = 0;
                  v35 = strlen(v33);
                  if ( v35 >= 0xFFFFFFFFFFFFFFF0LL )
                  {
                    std::__basic_string_common<true>::__throw_length_error(&dest);
                    goto LABEL_61;
                  }
                  v36 = v35;
                  if ( v35 >= 0x17 )
                  {
                    v38 = (v35 + 16) & 0xFFFFFFFFFFFFFFF0LL;
                    v37 = (char *)operator new(v38);
                    ptr = v37;
                    *(_QWORD *)&dest = v38 | 1;
                    *((_QWORD *)&dest + 1) = v36;
                  }
                  else
                  {
                    LOBYTE(dest) = 2 * v35;
                    v37 = (char *)&dest + 1;
                    if ( !v35 )
                      goto LABEL_52;
                  }
                  memcpy(v37, v33, v36);
LABEL_52:
                  v37[v36] = 0;
                  *(G3D::Vector2 *)v34.m128_f32 = G3D::Vector3::xy(&v47);
                  _mm_storel_ps((double *)&clippingRect.min, v34);
                  v39 = (RBX::RotationAngle *)G3D::Color3::white();
                  v14 = v51;
                  rotation.angle = *v39;
                  rotation.center.x = 1.0;
                  v40 = G3D::Color3::black();
                  color.r = v40->r;
                  color.g = v40->g;
                  color.b = v40->b;
                  color.a = 1.0;
                  _mm_storel_ps((double *)&position, (__m128)0LL);
                  outline = (RBX::Color4)xmmword_3E7230;
                  *(_OWORD *)v53 = xmmword_3E4990;
                  *(_DWORD *)&v53[16] = 0;
                  RBX::Adorn::drawFont2D(
                    v57,
                    (const std::string *)&dest,
                    &clippingRect.min,
                    14.0,
                    0,
                    (const RBX::Color4 *)&rotation,
                    &color,
                    RBX::Text::Font::FONT_SOURCESANS,
                    RBX::Text::XAlign::XALIGN_LEFT,
                    RBX::Text::YAlign::YALIGN_TOP,
                    &position,
                    (const RBX::Rect2D *)&outline,
                    (const RBX::Rotation2D *)v53,
                    1);
                  if ( (dest & 1) != 0 )
                    operator delete(ptr);
                  if ( (v44 & 1) != 0 )
                    operator delete(v46);
                  v47.y = v47.y + 16.0;
                  goto LABEL_57;
                }
LABEL_58:
                v50 += 4;
                if ( v50 == "N3RBX8AnimatorE" )
                  return;
              }
              v24 = (v21 + 16) & 0xFFFFFFFFFFFFFFF0LL;
              v23 = (char *)operator new(v24);
              ptr = v23;
              *(_QWORD *)&dest = v24 | 1;
              *((_QWORD *)&dest + 1) = v22;
              v14 = v51;
LABEL_32:
              memcpy(v23, v19, v22);
              goto LABEL_33;
            }
          }
        }
      }
    }
  }
}


// Address: 0x103c760 | Name: _Z22Class_getDescriptorPtrPN3RBX8AnimatorE
RBX::Reflection::ClassDescriptor *__fastcall Class_getDescriptorPtr(RBX::Animator *a1)
{
  RBX::Reflection::ClassDescriptor *result; // rax
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::ClassDescriptor::Attributes attributes; // [rsp+0h] [rbp-48h]
  int v4; // [rsp+19h] [rbp-2Fh]
  __int16 v5; // [rsp+1Dh] [rbp-2Bh]
  char v6; // [rsp+1Fh] [rbp-29h]
  unsigned __int64 v7; // [rsp+20h] [rbp-28h]
  __int64 v8; // [rsp+30h] [rbp-18h]

  result = qword_2A017C8;
  if ( !qword_2A017C8 )
  {
    if ( !(_BYTE)byte_2A01B10 )
    {
      if ( __cxa_guard_acquire(&byte_2A01B10) )
      {
        v2 = RBX::Instance::classDescriptor();
        LOBYTE(v7) = 0;
        *(_DWORD *)((char *)&v7 + 1) = v4;
        *(_WORD *)((char *)&v7 + 5) = v5;
        HIBYTE(v7) = v6;
        LODWORD(v8) = 27;
        *(_QWORD *)&attributes.flags = v8;
        attributes.RBX::Reflection::Descriptor::Attributes = (RBX::Reflection::Descriptor::Attributes)v7;
        RBX::Reflection::ClassDescriptor::ClassDescriptor(
          (RBX::Reflection::ClassDescriptor *)&unk_2A017D0,
          v2,
          "Animator",
          0,
          attributes,
          RBX::Security::Permissions::None,
          0);
        stru_2A01B08._vptr$ICreator = (int (**)(void))&off_288D460;
        RBX::Creatable<RBX::Instance>::setCreator(qword_2A017D8, &stru_2A01B08);
        __cxa_atexit(
          (void (*)(void *))RBX::ClassRegistrar<RBX::Animator,true>::~ClassRegistrar,
          &unk_2A017D0,
          &dso_handle);
        __cxa_guard_release(&byte_2A01B10);
      }
    }
    result = (RBX::Reflection::ClassDescriptor *)&unk_2A017D0;
    qword_2A017C8 = (RBX::Reflection::ClassDescriptor *)&unk_2A017D0;
  }
  return result;
}


// Address: 0x103c8b0 | Name: _Z16Class_getNamePtrPN3RBX8AnimatorE
const RBX::Name *__fastcall Class_getNamePtr(RBX::Animator *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A01B18;
  if ( !qword_2A01B18 )
  {
    result = (const RBX::Name *)*((_QWORD *)Class_getDescriptorPtr(a1) + 1);
    qword_2A01B18 = result;
  }
  return result;
}


// Address: 0x1041d20 | Name: _GLOBAL__sub_I_Animator.cpp
void __cdecl GLOBAL__sub_I_Animator_cpp()
{
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v1; // r9
  RBX::Reflection::ClassDescriptor *v2; // rax
  RBX::Reflection::Descriptor::Attributes v3; // [rsp+38h] [rbp-30h] BYREF
  int v4; // [rsp+48h] [rbp-20h]
  RBX::Reflection::Descriptor::Attributes v5; // 0:r8.1,8:r9.8
  RBX::Reflection::Descriptor::Attributes v6; // 0:r8.1,8:r9.8

  qword_2A012C0 = (__int64)boost::system::generic_category();
  qword_2A012C8 = (__int64)boost::system::generic_category();
  qword_2A012D0 = (__int64)boost::system::system_category();
  stru_2A012D8.value = 0;
  stru_2A012D8.name = "DoNotRunAnimationEditorInPlayMode";
  dword_2A012E8 = FLog::RegisterFlag(
                    "DoNotRunAnimationEditorInPlayMode",
                    &stru_2A012D8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A012F0.value = 0;
  stru_2A012F0.name = "JoinTime_LocalUserAnimationPriority";
  dword_2A01300 = FLog::RegisterFlag(
                    "JoinTime_LocalUserAnimationPriority",
                    &stru_2A012F0,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01308.value = 0;
  stru_2A01308.name = "StudioAnimationEditorScaleKeys";
  dword_2A01318 = FLog::RegisterFlag("StudioAnimationEditorScaleKeys", &stru_2A01308, FastVarType::FASTVARTYPE_STATIC);
  stru_2A01320.value = 0;
  stru_2A01320.name = "StudioAnimationEditorIKMode";
  dword_2A01330 = FLog::RegisterFlag("StudioAnimationEditorIKMode", &stru_2A01320, FastVarType::FASTVARTYPE_STATIC);
  stru_2A01338.value = 0;
  stru_2A01338.name = "StudioAnimationEditorUsePluginBindToClose2";
  dword_2A01348 = FLog::RegisterFlag(
                    "StudioAnimationEditorUsePluginBindToClose2",
                    &stru_2A01338,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01350.value = 0;
  stru_2A01350.name = "StudioAnimationEditorFixRenameKeyOption2";
  dword_2A01360 = FLog::RegisterFlag(
                    "StudioAnimationEditorFixRenameKeyOption2",
                    &stru_2A01350,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01368.value = 0;
  stru_2A01368.name = "StudioAnimationEditorAutoAddBeginningKeyframe";
  dword_2A01378 = FLog::RegisterFlag(
                    "StudioAnimationEditorAutoAddBeginningKeyframe",
                    &stru_2A01368,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01380.value = 0;
  stru_2A01380.name = "StudioAnimationEditorLockedPartStaysAnimatable";
  dword_2A01390 = FLog::RegisterFlag(
                    "StudioAnimationEditorLockedPartStaysAnimatable",
                    &stru_2A01380,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01398.value = 0;
  stru_2A01398.name = "StudioAnimationEditorUseQWidgetsForPopups";
  dword_2A013A8 = FLog::RegisterFlag(
                    "StudioAnimationEditorUseQWidgetsForPopups",
                    &stru_2A01398,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A013B0.value = 0;
  stru_2A013B0.name = "StudioAnimationEditorSelectEventsOnEdge";
  dword_2A013C0 = FLog::RegisterFlag(
                    "StudioAnimationEditorSelectEventsOnEdge",
                    &stru_2A013B0,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A013C8.value = 0;
  stru_2A013C8.name = "StudioAnimationEditorFixAnimationsWithLongNames";
  dword_2A013D8 = FLog::RegisterFlag(
                    "StudioAnimationEditorFixAnimationsWithLongNames",
                    &stru_2A013C8,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A013E0.value = 0;
  stru_2A013E0.name = "StudioAnimationEditorFixScalingBarPosition";
  dword_2A013F0 = FLog::RegisterFlag(
                    "StudioAnimationEditorFixScalingBarPosition",
                    &stru_2A013E0,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A013F8.value = 0;
  stru_2A013F8.name = "StudioAnimationEditorEnableRigSwitching2";
  dword_2A01408 = FLog::RegisterFlag(
                    "StudioAnimationEditorEnableRigSwitching2",
                    &stru_2A013F8,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01410.value = 0;
  stru_2A01410.name = "StudioAnimationEditorFixEventsTooltips";
  dword_2A01420 = FLog::RegisterFlag(
                    "StudioAnimationEditorFixEventsTooltips",
                    &stru_2A01410,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01428.value = 0;
  stru_2A01428.name = "StudioAnimationEditorFixIKBodyPartMode2";
  dword_2A01438 = FLog::RegisterFlag(
                    "StudioAnimationEditorFixIKBodyPartMode2",
                    &stru_2A01428,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01440.value = 0;
  stru_2A01440.name = "StudioAnimationEditorCheckForSavedChanges";
  dword_2A01450 = FLog::RegisterFlag(
                    "StudioAnimationEditorCheckForSavedChanges",
                    &stru_2A01440,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01458.value = 0;
  stru_2A01458.name = "StudioAnimationEditorClearEventNames";
  dword_2A01468 = FLog::RegisterFlag(
                    "StudioAnimationEditorClearEventNames",
                    &stru_2A01458,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01470.value = 0;
  stru_2A01470.name = "StudioAnimationEdtiorOptimizationsEnabled2";
  dword_2A01480 = FLog::RegisterFlag(
                    "StudioAnimationEdtiorOptimizationsEnabled2",
                    &stru_2A01470,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01488.value = 0;
  stru_2A01488.name = "StudioAnimationEditorKeepClipboardAfterMove";
  dword_2A01498 = FLog::RegisterFlag(
                    "StudioAnimationEditorKeepClipboardAfterMove",
                    &stru_2A01488,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A014A0.value = 0;
  stru_2A014A0.name = "SignalStopForZeroWeight";
  dword_2A014B0 = FLog::RegisterFlag("SignalStopForZeroWeight", &stru_2A014A0, FastVarType::FASTVARTYPE_STATIC);
  stru_2A014B8.value = 0;
  stru_2A014B8.name = "StudioAnimationEditorContinueScrollingWithSelectionArea";
  dword_2A014C8 = FLog::RegisterFlag(
                    "StudioAnimationEditorContinueScrollingWithSelectionArea",
                    &stru_2A014B8,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A014D0.value = 0;
  stru_2A014D0.name = "StudioAnimationEditorFixWorldSpaceJointPanel";
  dword_2A014E0 = FLog::RegisterFlag(
                    "StudioAnimationEditorFixWorldSpaceJointPanel",
                    &stru_2A014D0,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A014E8.value = 0;
  stru_2A014E8.name = "StudioAnimationEditorFixRigSelection";
  dword_2A014F8 = FLog::RegisterFlag(
                    "StudioAnimationEditorFixRigSelection",
                    &stru_2A014E8,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01500.value = 0;
  stru_2A01500.name = "StudioAnimationEditorFixInterpolationSetting";
  dword_2A01510 = FLog::RegisterFlag(
                    "StudioAnimationEditorFixInterpolationSetting",
                    &stru_2A01500,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01518.value = 0;
  stru_2A01518.name = "StudioAnimationEditorShiftSelectJointsOn";
  dword_2A01528 = FLog::RegisterFlag(
                    "StudioAnimationEditorShiftSelectJointsOn",
                    &stru_2A01518,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01530.value = 0;
  stru_2A01530.name = "StudioAnimationEditorHipHeightPopFix";
  dword_2A01540 = FLog::RegisterFlag(
                    "StudioAnimationEditorHipHeightPopFix",
                    &stru_2A01530,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01548.value = 0;
  stru_2A01548.name = "StudioAnimationEditorPlayPauseHotkey";
  dword_2A01558 = FLog::RegisterFlag(
                    "StudioAnimationEditorPlayPauseHotkey",
                    &stru_2A01548,
                    FastVarType::FASTVARTYPE_STATIC);
  stru_2A01560.value = 0;
  stru_2A01560.name = "StudioAnimationEditorFixRigBugs";
  dword_2A01570 = FLog::RegisterFlag("StudioAnimationEditorFixRigBugs", &stru_2A01560, FastVarType::FASTVARTYPE_STATIC);
  stru_2A01578.value = 0;
  stru_2A01578.name = "UpdateExtentsForManualStep";
  dword_2A01588 = FLog::RegisterFlag("UpdateExtentsForManualStep", &stru_2A01578, FastVarType::FASTVARTYPE_STATIC);
  stru_2A01590.value = 0;
  stru_2A01590.name = "EnableRoactAnimationEditor2";
  dword_2A015A0 = FLog::RegisterFlag("EnableRoactAnimationEditor2", &stru_2A01590, FastVarType::FASTVARTYPE_STATIC);
  stru_2A015A8.value = 0;
  stru_2A015A8.name = "AnimatorOnSteppedKeepAlive";
  dword_2A015B8 = FLog::RegisterFlag("AnimatorOnSteppedKeepAlive", &stru_2A015A8, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A015C0.value = 0;
  stru_2A015C0.name = "AnimatorNewModelSearchEnabled";
  dword_2A015D0 = FLog::RegisterFlag("AnimatorNewModelSearchEnabled", &stru_2A015C0, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A015D8.value = 0;
  stru_2A015D8.name = "AnimatorNewModelSearchIncludeWorkspace";
  dword_2A015E8 = FLog::RegisterFlag(
                    "AnimatorNewModelSearchIncludeWorkspace",
                    &stru_2A015D8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A015F0.value = 0;
  stru_2A015F0.name = "AnimatorNewModelSearchAnalytics";
  dword_2A01600 = FLog::RegisterFlag("AnimatorNewModelSearchAnalytics", &stru_2A015F0, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A01608.value = 0;
  stru_2A01608.name = "AnimatorNewModelSearchAnalyticsUnthrottled";
  dword_2A01618 = FLog::RegisterFlag(
                    "AnimatorNewModelSearchAnalyticsUnthrottled",
                    &stru_2A01608,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A01620.value = 0;
  stru_2A01620.name = "AnimatorAnimationPlayed";
  dword_2A01630 = FLog::RegisterFlag("AnimatorAnimationPlayed", &stru_2A01620, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A01634 = FLog::RegisterInt("MaxActiveAnimationTracks", &dword_2858618, FastVarType::FASTVARTYPE_DYNAMIC);
  v3.isDeprecated = 0;
  RBX::Reflection::BoundFuncDesc<RBX::Animator,boost::shared_ptr<RBX::Instance> ()(boost::shared_ptr<RBX::Instance>),1>::BoundFuncDesc(
    (RBX::Reflection::BoundFuncDesc<RBX::Animator,boost::shared_ptr<RBX::Instance> (boost::shared_ptr<RBX::Instance>),1> *)&unk_2A01638,
    (RBX::Reflection::BoundFuncDesc<RBX::Animator,boost::shared_ptr<RBX::Instance> (boost::shared_ptr<RBX::Instance>),1>::FunctionPtr)RBX::Animator::loadAnimation,
    0,
    "LoadAnimation",
    (RBX::Security::Permissions)"animation",
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v3.isDeprecated);
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::Animator,boost::shared_ptr<RBX::Instance> ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc,
    &unk_2A01638,
    &dso_handle);
  DescriptorPtr = Class_getDescriptorPtr((RBX::Animator *)RBX::Reflection::BoundFuncDesc<RBX::Animator,boost::shared_ptr<RBX::Instance> ()(boost::shared_ptr<RBX::Instance>),1>::~BoundFuncDesc);
  v5.isDeprecated = 0;
  v5.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A016B8,
    DescriptorPtr,
    "GetPlayingAnimationTracks",
    RBX::Security::Permissions::None,
    v5);
  qword_2A016B8[0] = &off_288D4F8;
  xmmword_2A01720 = (unsigned __int64)RBX::Animator::getPlayingAnimationTracks;
  qword_2A016F8 = (__int64)RBX::Reflection::Type::getSingleton<boost::shared_ptr<std::vector<RBX::Reflection::Variant> const>>();
  __cxa_atexit((void (*)(void *))RBX::Reflection::FunctionDescriptor::~FunctionDescriptor, qword_2A016B8, &dso_handle);
  v3.isDeprecated = 0;
  RBX::Reflection::EventDesc<RBX::Animator,void ()(boost::shared_ptr<RBX::Instance>),rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)>,rbx::signal<void ()(boost::shared_ptr<RBX::Instance>)> RBX::Animator::*>::EventDesc(
    (RBX::Reflection::EventDesc<RBX::Animator,void (boost::shared_ptr<RBX::Instance>),rbx::signal<void (boost::shared_ptr<RBX::Instance>)>,rbx::signal<void (boost::shared_ptr<RBX::Instance>)> RBX::Animator::*> *)&unk_2858628,
    (rbx::signal<void (boost::shared_ptr<RBX::Instance>)> *)&inputbuff.encodingTable[18].bitLength,
    "AnimationPlayed",
    "animationTrack",
    RBX::Security::Permissions::None,
    v1,
    (RBX::Reflection::Descriptor::Attributes)*(unsigned __int64 *)&v3.isDeprecated);
  __cxa_atexit((void (*)(void *))RBX::Reflection::EventDescriptor::~EventDescriptor, &unk_2858628, &dso_handle);
  v3.isDeprecated = 0;
  v3.preferred = 0;
  v4 = 0;
  RBX::Reflection::EventDesc<RBX::Animator,void ()(RBX::ContentId,bool,float,float,float,float,int),rbx::remote_signal<void ()(RBX::ContentId,bool,float,float,float,float,int)>,rbx::remote_signal<void ()(RBX::ContentId,bool,float,float,float,float,int)> RBX::Animator::*>::EventDesc(
    (RBX::Reflection::EventDesc<RBX::Animator,void (RBX::ContentId,bool,float,float,float,float,int),rbx::remote_signal<void (RBX::ContentId,bool,float,float,float,float,int)>,rbx::remote_signal<void (RBX::ContentId,bool,float,float,float,float,int)> RBX::Animator::*> *)qword_2858690,
    (rbx::remote_signal<void (RBX::ContentId,bool,float,float,float,float,int)> *)&inputbuff.encodingTable[17].bitLength,
    "OnCombinedUpdate",
    "animation",
    "playState",
    "fadeTime",
    "weight",
    "speed",
    "timePosition",
    "valuesUpdated",
    RBX::Security::Permissions::RobloxEngine,
    (RBX::Reflection::Descriptor::Attributes)_mm_loadu_si128((const __m128i *)&v3));
  qword_2858690[0] = (__int64)&off_288D5D8;
  dword_28586F8 = 1;
  dword_28586FC = v4;
  __cxa_atexit((void (*)(void *))RBX::Reflection::EventDescriptor::~EventDescriptor, qword_2858690, &dso_handle);
  v2 = Class_getDescriptorPtr((RBX::Animator *)RBX::Reflection::EventDescriptor::~EventDescriptor);
  v6.isDeprecated = 0;
  v6.preferred = 0;
  RBX::Reflection::FunctionDescriptor::FunctionDescriptor(
    (RBX::Reflection::FunctionDescriptor *)qword_2A01730,
    v2,
    "StepAnimations",
    RBX::Security::Permissions::Plugin,
    v6);
  qword_2A01730[0] = &off_288D3E8;
  qword_2A01798 = (__int64)RBX::Animator::manualStep;
  xmmword_2A017A0 = 0;
  RBX::Reflection::BoundFuncDesc<RBX::Animator,void ()(float),1>::declareSignature(
    (RBX::Reflection::BoundFuncDesc<RBX::Animator,void (float),1> *)qword_2A01730,
    "deltaTime");
  __cxa_atexit(
    (void (*)(void *))RBX::Reflection::BoundFuncDesc<RBX::Animator,void ()(float),1>::~BoundFuncDesc,
    qword_2A01730,
    &dso_handle);
  ((void (__fastcall *)(RBX::AutoClassRegistrar *))Class_getDescriptorPtr)(&autoClassRegistrar_1);
}


