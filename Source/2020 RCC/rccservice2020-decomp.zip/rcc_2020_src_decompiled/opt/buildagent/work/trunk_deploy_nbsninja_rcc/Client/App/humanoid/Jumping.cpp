// Address: 0x10e83b0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN7JumpingE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Jumping *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08ED8;
  if ( !qword_2A08ED8 )
  {
    result = RBX::Name::declare("Jumping");
    qword_2A08ED8 = result;
  }
  return result;
}


// Address: 0x10e83e0 | Name: _ZNK3RBX5HUMAN7Jumping7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Jumping::getName(const RBX::HUMAN::Jumping *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08ED8;
  if ( !qword_2A08ED8 )
  {
    result = RBX::Name::declare("Jumping");
    qword_2A08ED8 = result;
  }
  return result;
}


// Address: 0x10e8410 | Name: _ZN3RBX5HUMAN7JumpingC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Jumping::Jumping(
        RBX::HUMAN::Jumping *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  __m128 v3; // xmm0
  RBX::PartInstance *TorsoSlow; // rax
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  float v7; // xmm5_4
  __m128 v8; // xmm1
  float v9; // xmm3_4
  float v10; // xmm4_4
  G3D::Vector3 v11; // 0:kr00_12.12

  RBX::HUMAN::Flying::Flying(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895A90;
  *(_QWORD *)((char *)this + 388) = 0x3F80000000000000LL;
  *((_DWORD *)this + 99) = 0;
  if ( priorState == RBX::HUMAN::StateType::CLIMBING )
  {
    TorsoSlow = RBX::Humanoid::getTorsoSlow(humanoid);
    CoordinateFrame = RBX::PartInstance::getCoordinateFrame(TorsoSlow);
    v11 = G3D::Matrix3::column(&CoordinateFrame->rotation, 2);
    v3.m128_i32[1] = LODWORD(v11.y);
    v7 = fsqrt((float)(v11.z * v11.z) + (float)((float)(v11.x * v11.x) + 0.0));
    v3.m128_f32[0] = (float)(v11.x * (float)(1.0 / v7)) + *((float *)this + 97);
    v8 = (__m128)*((unsigned int *)this + 98);
    v8.m128_f32[0] = v8.m128_f32[0] - (float)(0.0 * (float)(1.0 / v7));
    v9 = (float)((float)(1.0 / v7) * v11.z) + *((float *)this + 99);
    v10 = fsqrt(
            (float)(v9 * v9)
          + (float)((float)(v8.m128_f32[0] * v8.m128_f32[0]) + (float)(v3.m128_f32[0] * v3.m128_f32[0])));
    v3.m128_f32[0] = v3.m128_f32[0] * (float)(1.0 / v10);
    v8.m128_f32[0] = v8.m128_f32[0] * (float)(1.0 / v10);
    _mm_storel_ps((double *)((char *)this + 388), _mm_unpacklo_ps(v3, v8));
    *((float *)this + 99) = (float)(1.0 / v10) * v9;
  }
  else if ( priorState == RBX::HUMAN::StateType::SWIMMING )
  {
    *((_BYTE *)this + 11) = 1;
  }
  *((_DWORD *)this + 4) = 1056964608;
}


// Address: 0x10e85b0 | Name: _ZN3RBX5HUMAN7Jumping18onComputeForceImplEv
void __fastcall RBX::HUMAN::Jumping::onComputeForceImpl(RBX::HUMAN::Jumping *this)
{
  RBX::Humanoid *HumanoidConst; // rbp
  RBX::Body *RootBodyFast; // r14
  __m128 v3; // xmm2
  float v4; // xmm0_4
  float v5; // xmm1_4
  RBX::Cofm *cofm; // r15
  float *p_mass; // r15
  float v8; // xmm0_4
  RBX::Solver::SolverRigidBody *rigidBody; // rax
  __m128 v10; // xmm1
  bool IsSolid; // bp
  RBX::Primitive *FloorPrimitive; // rax
  __int64 v13; // rcx
  int *v14; // rax
  __int64 v15; // rcx
  __int64 v16; // r15
  float v17; // xmm0_4
  float v18; // xmm3_4
  float v19; // xmm5_4
  float v20; // xmm4_4
  float v21; // xmm7_4
  float v22; // xmm2_4
  float v23; // xmm6_4
  float v24; // xmm1_4
  float v25; // xmm0_4
  float v26; // xmm1_4
  float v27; // xmm2_4
  RBX::Body *root; // rax
  RBX::Solver::SolverRigidBody *v29; // r14
  float v30; // xmm2_4
  float v31; // xmm3_4
  float v32; // xmm0_4
  float v33; // [rsp+Ch] [rbp-9Ch]
  float v34; // [rsp+10h] [rbp-98h]
  float v35; // [rsp+10h] [rbp-98h]
  float v36; // [rsp+10h] [rbp-98h]
  float v37; // [rsp+30h] [rbp-78h]

  RBX::HUMAN::Flying::onComputeForceImpl(this);
  if ( !*((_BYTE *)this + 10) )
  {
    HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    RootBodyFast = RBX::Humanoid::getRootBodyFast(HumanoidConst);
    RBX::Body::updatePV(RootBodyFast);
    v3 = _mm_mul_ps(
           (__m128)*((unsigned __int64 *)this + 49),
           (__m128)*(unsigned __int64 *)&RootBodyFast->pv.velocity.linear.y);
    v4 = (float)(RootBodyFast->pv.velocity.linear.x * *((float *)this + 97)) + v3.m128_f32[0];
    v5 = (float)((float)((float)dword_2859620 * 0.0099999998) * RBX::Humanoid::calculateJumpPower(HumanoidConst))
       - (float)(_mm_shuffle_ps(v3, v3, 229).m128_f32[0] + v4);
    if ( v5 <= 0.000001 || (v34 = v5, RBX::HUMAN::Jumping::findCeiling(this)) )
    {
      *((_BYTE *)this + 10) = 1;
      return;
    }
    if ( RootBodyFast )
    {
      cofm = RootBodyFast->cofm;
      if ( cofm )
      {
        RBX::Cofm::updateIfDirty(RootBodyFast->cofm);
        p_mass = &cofm->branch.mass;
      }
      else
      {
        if ( RootBodyFast->isMassless )
        {
          v8 = 0.0;
          if ( RootBodyFast->root != RootBodyFast )
          {
LABEL_13:
            rigidBody = RootBodyFast->root->rigidBody;
            if ( rigidBody )
              v10 = (__m128)*(unsigned __int64 *)&rigidBody->force.x;
            else
              v10 = 0;
            v33 = v8;
            v35 = (float)(v34 / RBX::Constants::worldDt()) - (float)(_mm_shuffle_ps(v10, v10, 229).m128_f32[0] / v8);
            IsSolid = RBX::HUMAN::HumanoidState::computeFloorIsSolid(this);
            FloorPrimitive = RBX::HUMAN::HumanoidState::getFloorPrimitive(this);
            if ( FloorPrimitive )
            {
              v13 = *((_QWORD *)FloorPrimitive + 25);
              v14 = IsSolid ? &dword_2859728 : &dword_2859738;
              v15 = *(_QWORD *)(v13 + 48);
              v16 = *(_QWORD *)(v15 + 64);
              if ( v16 )
              {
                v17 = (float)*v14 / 100.0;
                v18 = (float)((float)(*((float *)this + 97) * v35) * v33) * v17;
                v19 = -v18;
                v20 = (float)((float)(*((float *)this + 98) * v35) * v33) * v17;
                v21 = -v20;
                v22 = (float)((float)(*((float *)this + 99) * v35) * v33) * v17;
                v23 = -v22;
                if ( *(_BYTE *)(v16 + 1) )
                {
                  v37 = (float)((float)(*((float *)this + 98) * v35) * v33) * v17;
                  RBX::Solver::SolverRigidBody::update(*(RBX::Solver::SolverRigidBody **)(v15 + 64));
                  v20 = v37;
                  v19 = -v18;
                }
                v24 = *(float *)(v16 + 244);
                *(float *)(v16 + 240) = *(float *)(v16 + 240) - v18;
                *(float *)(v16 + 244) = v24 - v20;
                *(float *)(v16 + 248) = *(float *)(v16 + 248) - v22;
                v25 = *((float *)this + 33) - *(float *)(v16 + 60);
                v26 = *((float *)this + 34) - *(float *)(v16 + 64);
                v27 = *((float *)this + 35) - *(float *)(v16 + 68);
                *(float *)(v16 + 252) = (float)((float)(v26 * v23) - (float)(v27 * v21)) + *(float *)(v16 + 252);
                *(float *)(v16 + 256) = (float)((float)(v27 * v19) - (float)(v23 * v25)) + *(float *)(v16 + 256);
                *(float *)(v16 + 260) = (float)((float)(v25 * v21) - (float)(v26 * v19)) + *(float *)(v16 + 260);
              }
            }
            root = RootBodyFast->root;
            v29 = root->rigidBody;
            if ( v29 )
            {
              v30 = (float)(*((float *)this + 97) * v35) * v33;
              v31 = (float)(*((float *)this + 98) * v35) * v33;
              v32 = (float)(v35 * *((float *)this + 99)) * v33;
              if ( v29->dirty )
              {
                v36 = (float)(v35 * *((float *)this + 99)) * v33;
                RBX::Solver::SolverRigidBody::update(root->rigidBody);
                v32 = v36;
              }
              v29->force.x = v30 + v29->force.x;
              v29->force.y = v31 + v29->force.y;
              v29->force.z = v32 + v29->force.z;
            }
            return;
          }
        }
        p_mass = &RootBodyFast->bodyMass.mass;
      }
      v8 = *p_mass;
      goto LABEL_13;
    }
  }
}


// Address: 0x10e8980 | Name: _ZN3RBX5HUMAN7Jumping11findCeilingEv
bool __fastcall RBX::HUMAN::Jumping::findCeiling(RBX::HUMAN::Jumping *this)
{
  RBX::Humanoid *HumanoidConst; // r12
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Primitive *v3; // r15
  const RBX::CoordinateFrame *CoordinateFrame; // rbx
  __int64 v5; // rax
  __m128 v6; // xmm0
  __m128 v7; // xmm3
  __m128 v8; // xmm1
  __m128 v9; // xmm2
  __m128 v10; // xmm1
  RBX::Primitive *HeadPrimitiveSlow; // rax
  float v12; // xmm0_4
  RBX::HUMAN::Jumping *v13; // rsi
  boost::shared_ptr<RBX::PartInstance> v14; // rax
  __int64 v15; // rax
  __m128 v16; // xmm0
  int v17; // r12d
  __m128 v18; // xmm0
  __m128 v19; // xmm2
  __m128i v20; // xmm0
  volatile signed __int32 *v21; // rbp
  __int64 v22; // r13
  volatile signed __int32 *v23; // rbp
  int v24; // ebp
  volatile signed __int32 *v25; // rbx
  bool result; // al
  float v27; // [rsp+4h] [rbp-D4h]
  float v28; // [rsp+8h] [rbp-D0h]
  float v29; // [rsp+Ch] [rbp-CCh]
  __m128i v30; // [rsp+10h] [rbp-C8h] BYREF
  __int64 v31; // [rsp+28h] [rbp-B0h] BYREF
  __int32 v32; // [rsp+30h] [rbp-A8h]
  __int64 v33; // [rsp+34h] [rbp-A4h]
  int v34; // [rsp+3Ch] [rbp-9Ch]
  __m128i v35; // [rsp+40h] [rbp-98h] BYREF
  __int64 v36; // [rsp+58h] [rbp-80h]
  __m128 v37; // [rsp+60h] [rbp-78h]
  __m128 v38; // [rsp+70h] [rbp-68h]
  __m128 v39; // [rsp+80h] [rbp-58h]
  __m128 v40; // [rsp+90h] [rbp-48h]

  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(HumanoidConst);
  if ( !TorsoPrimitiveSlow )
    return 0;
  v3 = TorsoPrimitiveSlow;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(TorsoPrimitiveSlow);
  v5 = *((_QWORD *)v3 + 18);
  v28 = *(float *)(v5 + 8) * 0.40000001;
  v6 = (__m128)*(unsigned int *)(v5 + 12);
  v6.m128_f32[0] = v6.m128_f32[0] * 0.40000001;
  v29 = 0.40000001 * *(float *)(v5 + 16);
  v7 = (__m128)LODWORD(CoordinateFrame->rotation.elt[0][2]);
  v8 = _mm_mul_ps(
         _mm_unpacklo_ps(
           (__m128)LODWORD(CoordinateFrame->rotation.elt[0][0]),
           (__m128)LODWORD(CoordinateFrame->rotation.elt[1][0])),
         (__m128)0LL);
  v9 = _mm_unpacklo_ps(
         (__m128)LODWORD(CoordinateFrame->rotation.elt[0][1]),
         (__m128)LODWORD(CoordinateFrame->rotation.elt[1][1]));
  v37 = _mm_xor_ps(*(__m128 *)&stru_3E4970.x, v6);
  v10 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&CoordinateFrame->translation.x,
          _mm_add_ps(
            _mm_mul_ps(_mm_unpacklo_ps(v7, (__m128)LODWORD(CoordinateFrame->rotation.elt[1][2])), (__m128)0LL),
            _mm_add_ps(_mm_mul_ps((__m128)_mm_shuffle_epi32((__m128i)v37, 80), v9), v8)));
  v9.m128_f32[0] = (float)((float)(0.0 * CoordinateFrame->rotation.elt[2][2])
                         + (float)((float)(CoordinateFrame->rotation.elt[2][0] * 0.0)
                                 - (float)(v6.m128_f32[0] * CoordinateFrame->rotation.elt[2][1])))
                 + CoordinateFrame->translation.z;
  _mm_storel_ps((double *)&v31, v10);
  v32 = v9.m128_i32[0];
  v33 = 0x3F80000000000000LL;
  v34 = 0;
  HeadPrimitiveSlow = RBX::Humanoid::getHeadPrimitiveSlow(HumanoidConst);
  if ( HeadPrimitiveSlow )
    v12 = (float)(*(float *)(*((_QWORD *)v3 + 18) + 12LL) * 1.5)
        + *(float *)(*((_QWORD *)HeadPrimitiveSlow + 18) + 12LL);
  else
    v12 = *(float *)(*((_QWORD *)v3 + 18) + 12LL) * 1.5;
  v27 = v12;
  RBX::Assembly::getPrimitiveAssembly(v3);
  v13 = this;
  v14 = RBX::HUMAN::Jumping::tryCeiling(
          (RBX::HUMAN::Jumping *)&v30,
          (const RBX::RbxRay *)this,
          v12,
          (RBX::Assembly *)&v31);
  if ( !v30.m128i_i64[0] )
  {
    v38 = _mm_shuffle_ps(v37, v37, 224);
    v15 = 0xFFFFFFFFLL;
LABEL_7:
    v36 = v15;
    v16 = 0;
    v16.m128_f32[0] = (float)(int)v15 * v28;
    v40 = v16;
    v39 = _mm_shuffle_ps(v16, v16, 224);
    v17 = -3;
    while ( 1 )
    {
      v18 = 0;
      v18.m128_f32[0] = (float)(v17 + 2) * v29;
      v19 = _mm_add_ps(
              (__m128)*(unsigned __int64 *)&CoordinateFrame->translation.x,
              _mm_add_ps(
                _mm_mul_ps(
                  _mm_shuffle_ps(v18, v18, 224),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(CoordinateFrame->rotation.elt[0][2]),
                    (__m128)LODWORD(CoordinateFrame->rotation.elt[1][2]))),
                _mm_add_ps(
                  _mm_mul_ps(
                    _mm_unpacklo_ps(
                      (__m128)LODWORD(CoordinateFrame->rotation.elt[0][1]),
                      (__m128)LODWORD(CoordinateFrame->rotation.elt[1][1])),
                    v38),
                  _mm_mul_ps(
                    _mm_unpacklo_ps(
                      (__m128)LODWORD(CoordinateFrame->rotation.elt[0][0]),
                      (__m128)LODWORD(CoordinateFrame->rotation.elt[1][0])),
                    v39))));
      v18.m128_f32[0] = (float)((float)(v18.m128_f32[0] * CoordinateFrame->rotation.elt[2][2])
                              + (float)((float)(CoordinateFrame->rotation.elt[2][1] * v37.m128_f32[0])
                                      + (float)(CoordinateFrame->rotation.elt[2][0] * v40.m128_f32[0])))
                      + CoordinateFrame->translation.z;
      _mm_storel_ps((double *)&v31, v19);
      v32 = v18.m128_i32[0];
      v33 = 0x3F80000000000000LL;
      v34 = 0;
      RBX::Assembly::getPrimitiveAssembly(v3);
      v13 = this;
      v14 = RBX::HUMAN::Jumping::tryCeiling(
              (RBX::HUMAN::Jumping *)&v35,
              (const RBX::RbxRay *)this,
              v27,
              (RBX::Assembly *)&v31);
      v20 = _mm_load_si128(&v35);
      v35 = 0;
      v21 = (volatile signed __int32 *)v30.m128i_i64[1];
      v30 = v20;
      if ( v21 )
      {
        if ( !_InterlockedSub(v21 + 2, 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *, RBX::HUMAN::Jumping *, boost::detail::sp_counted_base *))(*(_QWORD *)v21 + 16LL))(
            v21,
            this,
            v14.pn.pi_);
          if ( !_InterlockedSub(v21 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v21 + 24LL))(v21);
        }
        v22 = v30.m128i_i64[0];
      }
      else
      {
        v22 = v20.m128i_i64[0];
      }
      v23 = (volatile signed __int32 *)v35.m128i_i64[1];
      if ( v35.m128i_i64[1] )
      {
        if ( !_InterlockedSub((volatile signed __int32 *)(v35.m128i_i64[1] + 8), 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *, RBX::HUMAN::Jumping *, boost::detail::sp_counted_base *))(*(_QWORD *)v23 + 16LL))(
            v23,
            this,
            v14.pn.pi_);
          if ( !_InterlockedSub(v23 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v23 + 24LL))(v23);
        }
      }
      if ( v22 )
        break;
      v17 += 2;
      if ( v17 >= 0 )
      {
        v15 = (unsigned int)(v36 + 2);
        v24 = 0;
        if ( (int)v36 < 0 )
          goto LABEL_7;
        goto LABEL_23;
      }
    }
  }
  v24 = 1;
LABEL_23:
  v25 = (volatile signed __int32 *)v30.m128i_i64[1];
  if ( v30.m128i_i64[1] && !_InterlockedSub((volatile signed __int32 *)(v30.m128i_i64[1] + 8), 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, RBX::HUMAN::Jumping *, boost::detail::sp_counted_base *))(*(_QWORD *)v25 + 16LL))(
      v25,
      v13,
      v14.pn.pi_);
    if ( !_InterlockedSub(v25 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 24LL))(v25);
  }
  result = 1;
  if ( !v24 )
    return 0;
  return result;
}


// Address: 0x10e8d70 | Name: _ZN3RBX5HUMAN7Jumping10tryCeilingERKNS_6RbxRayEfPNS_8AssemblyE
RBX::HUMAN::Jumping *__fastcall RBX::HUMAN::Jumping::tryCeiling(
        RBX::HUMAN::Jumping *this,
        const RBX::RbxRay *ray,
        float maxDistance,
        const RBX::RbxRay *humanoidAssembly,
        RBX::Assembly *a5)
{
  const RBX::Humanoid *HumanoidConst; // rbp
  const RBX::ContactManager *v8; // r13
  int8_t v9; // al
  RBX::Primitive *HitLegacy; // rax
  RBX::Primitive *v11; // rbx
  RBX::PartInstance *v12; // rax
  float maxSearchDepth; // [rsp+Ch] [rbp-5Ch] BYREF
  RBX::Vector3 hitPointWorld; // [rsp+10h] [rbp-58h] BYREF
  float distanceToHit; // [rsp+1Ch] [rbp-4Ch] BYREF
  __int128 v17; // [rsp+20h] [rbp-48h] BYREF

  maxSearchDepth = maxDistance;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst((const RBX::HUMAN::HumanoidState *)ray);
  *(_QWORD *)&ray[11].m_origin.z = a5;
  *(_QWORD *)&hitPointWorld.x = 0;
  hitPointWorld.z = 0.0;
  v8 = *(const RBX::ContactManager **)(*((_QWORD *)HumanoidConst + 308) + 784LL);
  if ( RBX::Humanoid::getTorsoPrimitiveFast(HumanoidConst) )
    v9 = *((_BYTE *)RBX::Humanoid::getTorsoPrimitiveFast(HumanoidConst) + 599);
  else
    v9 = 0;
  HitLegacy = RBX::ContactManager::getHitLegacy(
                v8,
                humanoidAssembly,
                0,
                (const RBX::HitTestFilter *)ray,
                &hitPointWorld,
                &distanceToHit,
                &maxSearchDepth,
                1,
                v9);
  *(_OWORD *)this = 0;
  if ( HitLegacy )
  {
    v11 = HitLegacy;
    if ( RBX::Assembly::getPrimitiveAssembly(HitLegacy) != a5 )
    {
      v12 = RBX::PartInstance::fromPrimitive(v11);
      RBX::shared_from<RBX::PartInstance>((boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)&v17, v12);
      *(_OWORD *)this = v17;
    }
  }
  return this;
}


// Address: 0x10e8e70 | Name: _ZNK3RBX5HUMAN7Jumping12filterResultEPKNS_9PrimitiveE
RBX::HitTestFilter::Result __fastcall RBX::HUMAN::Jumping::filterResult(
        const RBX::HUMAN::Jumping *this,
        const RBX::Primitive *testMe)
{
  RBX::HitTestFilter::Result v2; // ebx
  const RBX::Assembly *v4; // r14
  const RBX::PartInstance *v5; // rax
  const RBX::Reflection::ClassDescriptor *descriptor; // r14
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  if ( *((_BYTE *)testMe + 594) )
    return RBX::HitTestFilter::Result::IGNORE_PRIM;
  if ( *((_BYTE *)testMe + 596) )
    return RBX::HitTestFilter::Result::IGNORE_PRIM;
  v4 = (const RBX::Assembly *)*((_QWORD *)this + 34);
  if ( v4 )
  {
    if ( v4 == RBX::Assembly::getConstPrimitiveAssembly(testMe) )
      return RBX::HitTestFilter::Result::IGNORE_PRIM;
  }
  v5 = RBX::PartInstance::fromConstPrimitive(testMe);
  v2 = RBX::HitTestFilter::Result::INCLUDE_PRIM;
  if ( v5 )
  {
    descriptor = v5->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
      return RBX::HitTestFilter::Result::IGNORE_PRIM;
  }
  return v2;
}


// Address: 0x10e8fc0 | Name: _GLOBAL__sub_I_Jumping.cpp
void __cdecl GLOBAL__sub_I_Jumping_cpp()
{
  qword_2A08EB8 = (__int64)boost::system::generic_category();
  qword_2A08EC0 = (__int64)boost::system::generic_category();
  qword_2A08EC8 = (__int64)boost::system::system_category();
  dword_2A08ED0 = FLog::RegisterInt("PGSJumpForceAdjustment", &dword_2859610, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08ED4 = FLog::RegisterInt(
                    "JumpPowerInstantControllerMultiplierPercent",
                    &dword_2859620,
                    FastVarType::FASTVARTYPE_DYNAMIC);
}


