// Address: 0x1e07720 | Name: _ZN3RBX9Collision21BlockBlockContact_New35findFeatureCollisionsUpdateContactsERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
bool __fastcall RBX::Collision::BlockBlockContact_New::findFeatureCollisionsUpdateContacts(
        RBX::Collision::BlockBlockContact_New *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors,
        float a3,
        float overlapIgnored)
{
  bool v5; // [rsp+Dh] [rbp-1Bh] BYREF
  bool isEdgePlaneContact; // [rsp+Eh] [rbp-1Ah] BYREF
  bool isParallelEdges; // [rsp+Fh] [rbp-19h] BYREF
  float minPenetration; // [rsp+10h] [rbp-18h] BYREF
  float v9; // [rsp+14h] [rbp-14h]

  v5 = 0;
  minPenetration = INFINITY;
  v9 = a3;
  if ( RBX::Collision::BlockBlockContact_New::updateMinPenetrationFacePlane(this, a3, &minPenetration, &v5)
    && (isEdgePlaneContact = 0,
        isParallelEdges = 0,
        minPenetration = minPenetration * 0.99009901,
        RBX::Collision::BlockBlockContact_New::updateMinPenetrationEdgePlane(
          this,
          v9,
          &minPenetration,
          &isParallelEdges,
          &isEdgePlaneContact)) )
  {
    v5 = !isEdgePlaneContact;
    if ( isEdgePlaneContact )
      return RBX::Collision::BlockBlockContact_New::computeEdgeContact(this, newCollisionConnectors, overlapIgnored);
    else
      return RBX::Collision::BlockBlockContact_New::computeFaceContact(this, newCollisionConnectors, overlapIgnored);
  }
  else
  {
    *(_WORD *)this->mFeature = -1;
    return 0;
  }
}


// Address: 0x1e077e0 | Name: _ZN3RBX9Collision21BlockBlockContact_New32updateMinPenetrationContactPlaneEfRb
char __fastcall RBX::Collision::BlockBlockContact_New::updateMinPenetrationContactPlane(
        RBX::Collision::BlockBlockContact_New *this,
        float a2,
        float overlapIgnored,
        bool *isFacePlaneContact)
{
  bool v5; // [rsp+Eh] [rbp-1Ah] BYREF
  bool isParallelEdges; // [rsp+Fh] [rbp-19h] BYREF
  float minPenetrationInOut; // [rsp+10h] [rbp-18h] BYREF
  float v8; // [rsp+14h] [rbp-14h]

  minPenetrationInOut = INFINITY;
  v8 = a2;
  if ( !RBX::Collision::BlockBlockContact_New::updateMinPenetrationFacePlane(
          this,
          a2,
          &minPenetrationInOut,
          isFacePlaneContact) )
    return 0;
  v5 = 0;
  isParallelEdges = 0;
  minPenetrationInOut = minPenetrationInOut * 0.99009901;
  if ( !RBX::Collision::BlockBlockContact_New::updateMinPenetrationEdgePlane(
          this,
          v8,
          &minPenetrationInOut,
          &isParallelEdges,
          &v5) )
    return 0;
  *isFacePlaneContact = !v5;
  return 1;
}


// Address: 0x1e07870 | Name: _ZN3RBX9Collision21BlockBlockContact_New18computeFaceContactERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
__int64 __fastcall RBX::Collision::BlockBlockContact_New::computeFaceContact(
        RBX::Collision::BlockBlockContact_New *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors,
        __m128 a3,
        float overlapIgnored)
{
  int8_t v4; // al
  unsigned int v5; // r15d
  unsigned int v6; // r12d
  RBX::Body *Body; // rbx
  RBX::Body *v8; // r13
  __m128 x_low; // xmm2
  __m128 y_low; // xmm1
  __m128 z_low; // xmm0
  __m128 v12; // xmm4
  float x; // xmm6_4
  float y; // xmm0_4
  float z; // xmm1_4
  RBX::Primitive **p_prim1; // rcx
  RBX::Primitive **p_prim0; // rdx
  int v18; // eax
  __int64 v19; // rbx
  __int32 v20; // edx
  float v21; // xmm7_4
  float v22; // xmm3_4
  float v23; // xmm6_4
  signed int v24; // eax
  __m128 v25; // xmm2
  __m128 v26; // xmm1
  __m128 v27; // xmm0
  __int64 v28; // r12
  RBX::Block *v29; // rbp
  RBX::NormalId ClosestObjectNormalId; // r14d
  __int64 v31; // r15
  RBX::Block *v32; // rdi
  _BYTE *v33; // rbx
  const RBX::Matrix3 *BlockFaceMat; // rax
  float v35; // xmm15_4
  float v36; // xmm14_4
  float v37; // xmm13_4
  __m128 v38; // xmm12
  float v39; // xmm11_4
  float v40; // xmm10_4
  __m128 v41; // xmm9
  float v42; // xmm7_4
  float v43; // xmm8_4
  float v44; // xmm6_4
  const RBX::Matrix3 *v45; // rbp
  int *v46; // rax
  __int64 i; // rcx
  __int64 v48; // rdx
  float v49; // xmm4_4
  float v50; // xmm3_4
  __m128 v51; // xmm0
  __m128 v52; // xmm1
  __m128 v53; // xmm2
  __m128 v54; // xmm5
  __m128 v55; // xmm0
  float v56; // xmm2_4
  __m128 v57; // xmm0
  unsigned int v58; // ebx
  __int64 j; // r15
  __int64 v60; // r14
  float v61; // xmm4_4
  float v62; // xmm3_4
  __m128 v63; // xmm0
  __m128 v64; // xmm1
  __m128 v65; // xmm2
  __m128 v66; // xmm4
  __m128 v67; // xmm2
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // rax
  float v69; // xmm0_4
  int v70; // ecx
  float v72; // [rsp+4h] [rbp-1A4h]
  int idxCount; // [rsp+8h] [rbp-1A0h] BYREF
  int polySz; // [rsp+Ch] [rbp-19Ch] BYREF
  G3D::Matrix3 v75; // [rsp+10h] [rbp-198h] BYREF
  float v76; // [rsp+34h] [rbp-174h]
  float v77; // [rsp+38h] [rbp-170h]
  float v78; // [rsp+3Ch] [rbp-16Ch]
  float v79; // [rsp+40h] [rbp-168h]
  float v80; // [rsp+44h] [rbp-164h]
  float v81; // [rsp+48h] [rbp-160h]
  float v82; // [rsp+4Ch] [rbp-15Ch]
  float v83; // [rsp+50h] [rbp-158h]
  float v84; // [rsp+54h] [rbp-154h]
  float v85; // [rsp+58h] [rbp-150h]
  RBX::NormalId v86; // [rsp+5Ch] [rbp-14Ch]
  _BYTE v87[40]; // [rsp+60h] [rbp-148h] BYREF
  float v88; // [rsp+88h] [rbp-120h]
  float v89; // [rsp+8Ch] [rbp-11Ch]
  __int64 v90; // [rsp+90h] [rbp-118h]
  int v91; // [rsp+98h] [rbp-110h]
  __int16 v92; // [rsp+9Ch] [rbp-10Ch]
  __int64 v93; // [rsp+A0h] [rbp-108h]
  int v94; // [rsp+A8h] [rbp-100h]
  __int16 v95; // [rsp+ACh] [rbp-FCh]
  __int64 v96; // [rsp+B0h] [rbp-F8h]
  int v97; // [rsp+B8h] [rbp-F0h]
  __int16 v98; // [rsp+BCh] [rbp-ECh]
  __int64 v99; // [rsp+C0h] [rbp-E8h]
  int v100; // [rsp+C8h] [rbp-E0h]
  __int16 v101; // [rsp+CCh] [rbp-DCh]
  __int64 v102; // [rsp+D0h] [rbp-D8h]
  int v103; // [rsp+D8h] [rbp-D0h]
  __int16 v104; // [rsp+DCh] [rbp-CCh]
  RBX::NormalId normalID[2]; // [rsp+E8h] [rbp-C0h]
  G3D::Matrix3 *objectR[2]; // [rsp+F0h] [rbp-B8h]
  __m128 v107; // [rsp+100h] [rbp-A8h]
  __m128 v108; // [rsp+110h] [rbp-98h]
  RBX::Primitive **v109; // [rsp+120h] [rbp-88h]
  RBX::Primitive **v110; // [rsp+128h] [rbp-80h]
  RBX::Collision::PolyCollisionConnectorArray *collisionConnectors; // [rsp+130h] [rbp-78h]
  RBX::Vector2 rect; // [rsp+138h] [rbp-70h] BYREF
  __m128 v113; // [rsp+140h] [rbp-68h]
  __m128 v114; // [rsp+150h] [rbp-58h]
  G3D::Vector4 v115; // [rsp+168h] [rbp-40h] BYREF
  G3D::Vector3 v116; // 0:kr00_12.12

  v107 = a3;
  collisionConnectors = newCollisionConnectors;
  v4 = this->mFeature[0];
  if ( v4 == -1 )
  {
    v4 = this->mFeature[1];
    v5 = 1;
    v6 = 0;
  }
  else
  {
    v5 = 0;
    v6 = 1;
  }
  *(_QWORD *)normalID = (unsigned int)v4;
  Body = RBX::Collision::Contact::getBody(this, v6);
  v8 = RBX::Collision::Contact::getBody(this, v5);
  *(_OWORD *)v87 = 0x3F800000u;
  *(_OWORD *)&v87[16] = 0x3F800000u;
  *(_DWORD *)&v87[32] = 1065353216;
  _mm_storel_ps((double *)&v87[36], (__m128)0LL);
  v89 = 0.0;
  G3D::Matrix3::transpose(&v75, &v8->pv.position.rotation);
  *(G3D::Matrix3 *)v87 = v75;
  G3D::Matrix3::operator-(&v75, (const G3D::Matrix3 *)v87);
  x_low = (__m128)LODWORD(v8->pv.position.translation.x);
  y_low = (__m128)LODWORD(v8->pv.position.translation.y);
  z_low = (__m128)LODWORD(v8->pv.position.translation.z);
  v12 = _mm_add_ps(
          _mm_mul_ps(
            _mm_shuffle_ps(z_low, z_low, 224),
            _mm_unpacklo_ps((__m128)LODWORD(v75.elt[0][2]), (__m128)LODWORD(v75.elt[1][2]))),
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(y_low, y_low, 224),
              _mm_unpacklo_ps((__m128)LODWORD(v75.elt[0][1]), (__m128)LODWORD(v75.elt[1][1]))),
            _mm_mul_ps(
              _mm_shuffle_ps(x_low, x_low, 224),
              _mm_unpacklo_ps((__m128)LODWORD(v75.elt[0][0]), (__m128)LODWORD(v75.elt[1][0])))));
  z_low.m128_f32[0] = (float)(z_low.m128_f32[0] * v75.elt[2][2])
                    + (float)((float)(y_low.m128_f32[0] * v75.elt[2][1]) + (float)(x_low.m128_f32[0] * v75.elt[2][0]));
  _mm_storel_ps((double *)&v87[36], v12);
  v89 = z_low.m128_f32[0];
  objectR[0] = &Body->pv.position.rotation;
  G3D::Matrix3::operator*(&v75, (const G3D::Matrix3 *)v87, &Body->pv.position.rotation);
  x = Body->pv.position.translation.x;
  y = Body->pv.position.translation.y;
  z = Body->pv.position.translation.z;
  p_prim1 = &this->prim1;
  p_prim0 = &this->prim1;
  if ( !v6 )
    p_prim0 = &this->prim0;
  v109 = p_prim0;
  if ( !v5 )
    p_prim1 = &this->prim0;
  v110 = p_prim1;
  v18 = SLOBYTE(normalID[0]) / 3;
  v19 = *(_QWORD *)normalID;
  v20 = normalID[0] - 3 * v18;
  v84 = v75.elt[0][1];
  v85 = v75.elt[0][0];
  v83 = v75.elt[0][2];
  v81 = v75.elt[1][1];
  v82 = v75.elt[1][0];
  v80 = v75.elt[1][2];
  v79 = v75.elt[2][0];
  v21 = (float)((float)(*(float *)v87 * x) + (float)(*(float *)&v87[4] * y)) + (float)(*(float *)&v87[8] * z);
  v108.m128_i32[0] = LODWORD(v75.elt[2][1]);
  v22 = (float)((float)(*(float *)&v87[12] * x) + (float)(*(float *)&v87[16] * y)) + (float)(*(float *)&v87[20] * z);
  v23 = (float)((float)(x * *(float *)&v87[24]) + (float)(y * *(float *)&v87[28])) + (float)(z * *(float *)&v87[32]);
  v24 = (-2 * v18) | 1;
  v25 = 0;
  v25.m128_f32[0] = (float)v24 * v8->pv.position.rotation.elt[2][v20];
  v26 = _mm_xor_ps(
          _mm_mul_ps(
            _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v24), 80)),
            _mm_unpacklo_ps(
              (__m128)LODWORD(v8->pv.position.rotation.elt[0][v20]),
              (__m128)LODWORD(v8->pv.position.rotation.elt[1][v20]))),
          *(__m128 *)&stru_3E4970.x);
  v27 = (__m128)LODWORD(v75.elt[2][2]);
  v72 = v75.elt[2][2];
  v77 = v21 + *(float *)&v87[36];
  v76 = v22 + v88;
  v78 = v23 + v89;
  v28 = *(_QWORD *)(*((_QWORD *)&this->prim0 + v6) + 144LL);
  v29 = *(RBX::Block **)(*((_QWORD *)&this->prim0 + v5) + 144LL);
  v113 = v26;
  _mm_storel_ps((double *)v87, v26);
  v114 = _mm_xor_ps(v25, *(__m128 *)&stru_3E4970.x);
  *(_DWORD *)&v87[8] = v114.m128_i32[0];
  ClosestObjectNormalId = RBX::Math::getClosestObjectNormalId((const G3D::Vector3 *)v87, objectR[0]);
  v31 = (__int64)&v29->vertices[dword_56F9F0[4 * v19]];
  v32 = v29;
  LODWORD(v29) = v19;
  *(RBX::Vector2 *)v27.m128_f32 = RBX::Block::getProjectedVertex(v32, (const RBX::Vector3 *)v31, (RBX::NormalId)v19);
  _mm_storel_ps((double *)&rect, v27);
  *(_QWORD *)v87 = 0;
  *(_DWORD *)&v87[8] = 0;
  v33 = &v87[12];
  *(_WORD *)&v87[12] = 255;
  *(_QWORD *)&v87[16] = 0;
  *(_DWORD *)&v87[24] = 0;
  *(_WORD *)&v87[28] = 255;
  *(_QWORD *)&v87[32] = 0;
  v88 = 0.0;
  LOWORD(v89) = 255;
  v90 = 0;
  v91 = 0;
  v92 = 255;
  v93 = 0;
  v94 = 0;
  v95 = 255;
  v96 = 0;
  v97 = 0;
  v98 = 255;
  v99 = 0;
  v100 = 0;
  v101 = 255;
  v102 = 0;
  v103 = 0;
  v104 = 255;
  BlockFaceMat = RBX::Collision::getBlockFaceMat((RBX::NormalId)v29);
  v35 = v76;
  v36 = v79;
  v37 = v77;
  v38 = (__m128)LODWORD(v80);
  v39 = v81;
  v40 = v82;
  v41 = (__m128)LODWORD(v83);
  v42 = v84;
  v43 = v85;
  v44 = v78;
  v45 = BlockFaceMat;
  polySz = 4;
  v86 = ClosestObjectNormalId;
  v46 = &dword_56F9F0[4 * ClosestObjectNormalId];
  for ( i = 0; i != 4; ++i )
  {
    v48 = *(_QWORD *)(v28 + 72);
    v49 = *(float *)(v48 + 12LL * v46[i]);
    v50 = *(float *)(v48 + 12LL * v46[i] + 4);
    v51 = (__m128)*(unsigned int *)(v48 + 12LL * v46[i] + 8);
    v52 = v41;
    v52.m128_f32[0] = (float)((float)(v41.m128_f32[0] * v51.m128_f32[0])
                            + (float)((float)(v42 * v50) + (float)(v43 * v49)))
                    + v37;
    v53 = v38;
    v53.m128_f32[0] = (float)((float)(v38.m128_f32[0] * v51.m128_f32[0])
                            + (float)((float)(v39 * v50) + (float)(v40 * v49)))
                    + v35;
    v51.m128_f32[0] = (float)((float)(v51.m128_f32[0] * v72)
                            + (float)((float)(v50 * v108.m128_f32[0]) + (float)(v49 * v36)))
                    + v44;
    v54 = _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(v51, v51, 224),
              _mm_unpacklo_ps((__m128)LODWORD(v45->elt[0][2]), (__m128)LODWORD(v45->elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(v53, v53, 224),
                _mm_unpacklo_ps((__m128)LODWORD(v45->elt[0][1]), (__m128)LODWORD(v45->elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(v52, v52, 224),
                _mm_unpacklo_ps((__m128)LODWORD(v45->elt[0][0]), (__m128)LODWORD(v45->elt[1][0])))));
    v51.m128_f32[0] = (float)(v51.m128_f32[0] * v45->elt[2][2])
                    + (float)((float)(v53.m128_f32[0] * v45->elt[2][1]) + (float)(v52.m128_f32[0] * v45->elt[2][0]));
    _mm_storel_ps((double *)(v33 - 12), v54);
    *((_DWORD *)v33 - 1) = v51.m128_i32[0];
    *v33 = i;
    v33 += 16;
  }
  RBX::Collision::clipQuadOnRectPlanes(&rect, (RBX::Collision::Clip *)v87, &polySz);
  v55 = _mm_mul_ps((__m128)*(unsigned __int64 *)&v45->elt[2][1], (__m128)*(unsigned __int64 *)(v31 + 4));
  v56 = (float)(*(float *)v31 * v45->elt[2][0]) + v55.m128_f32[0];
  v57 = _mm_shuffle_ps(v55, v55, 229);
  v57.m128_f32[0] = v57.m128_f32[0] + v56;
  idxCount = 0;
  *(__m128 *)objectR = v57;
  v107 = _mm_xor_ps(v107, *(__m128 *)&stru_3E4970.x);
  RBX::Collision::filterClipPoints(
    (RBX::Collision::Clip *)v87,
    polySz,
    v57.m128_f32[0],
    v107.m128_f32[0],
    (int *)&v75,
    &idxCount);
  v58 = 0;
  if ( idxCount > 0 )
  {
    for ( j = 0; j < idxCount; ++j )
    {
      v60 = 16LL * SLODWORD(v75.elt[0][j]);
      v61 = *(float *)&v87[v60];
      v62 = *(float *)&v87[v60 + 4];
      v63 = (__m128)*(unsigned int *)&v87[v60 + 8];
      v64 = (__m128)LODWORD(v45->elt[2][0]);
      v64.m128_f32[0] = (float)(v64.m128_f32[0] * v63.m128_f32[0])
                      + (float)((float)(v45->elt[1][0] * v62) + (float)(v45->elt[0][0] * v61));
      v65 = (__m128)LODWORD(v45->elt[2][1]);
      v65.m128_f32[0] = (float)(v65.m128_f32[0] * v63.m128_f32[0])
                      + (float)((float)(v45->elt[1][1] * v62) + (float)(v45->elt[0][1] * v61));
      v63.m128_f32[0] = (float)(v63.m128_f32[0] * v45->elt[2][2])
                      + (float)((float)(v62 * v45->elt[1][2]) + (float)(v61 * v45->elt[0][2]));
      v66 = _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(v63, v63, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(v8->pv.position.rotation.elt[0][2]),
                  (__m128)LODWORD(v8->pv.position.rotation.elt[1][2]))),
              _mm_add_ps(
                _mm_mul_ps(
                  _mm_shuffle_ps(v65, v65, 224),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(v8->pv.position.rotation.elt[0][1]),
                    (__m128)LODWORD(v8->pv.position.rotation.elt[1][1]))),
                _mm_mul_ps(
                  _mm_shuffle_ps(v64, v64, 224),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(v8->pv.position.rotation.elt[0][0]),
                    (__m128)LODWORD(v8->pv.position.rotation.elt[1][0])))));
      v63.m128_f32[0] = (float)((float)(v63.m128_f32[0] * v8->pv.position.rotation.elt[2][2])
                              + (float)((float)(v65.m128_f32[0] * v8->pv.position.rotation.elt[2][1])
                                      + (float)(v64.m128_f32[0] * v8->pv.position.rotation.elt[2][0])))
                      + v8->pv.position.translation.z;
      v67 = *(__m128 *)&up.x;
      v67.m128_f32[0] = v63.m128_f32[0];
      v115 = (G3D::Vector4)_mm_movelh_ps(
                             _mm_add_ps((__m128)*(unsigned __int64 *)&v8->pv.position.translation.x, v66),
                             v67);
      v116 = G3D::Vector4::xyz(&v115);
      v63.m128_i32[0] = LODWORD(v116.x);
      v63.m128_i32[1] = LODWORD(v116.y);
      v108 = v63;
      CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                             collisionConnectors,
                             *v109,
                             *v110,
                             RBX::Collision::FeaturePolyPair::VERTEX_FACE_PAIR);
      CollisionConnector->param0 = (char)v87[v60 + 12];
      CollisionConnector->param1 = normalID[0];
      v69 = *(float *)&v87[v60 + 8] - *(float *)objectR;
      _mm_storel_ps((double *)&CollisionConnector->contactPoint.x, v108);
      CollisionConnector->contactPoint.z = v116.z;
      _mm_storel_ps((double *)&CollisionConnector->normal.x, v113);
      LODWORD(CollisionConnector->normal.z) = v114.m128_i32[0];
      CollisionConnector->depth = v69;
      if ( v87[v60 + 12] == 0xFF )
      {
        CollisionConnector->pairType = RBX::Collision::FeaturePolyPair::EDGE_EDGE_FACE_PAIR;
        CollisionConnector->param0 = v86;
      }
      v70 = 1;
      if ( v69 >= v107.m128_f32[0] )
      {
        *(_QWORD *)&CollisionConnector->normal.x = 0;
        CollisionConnector->normal.z = 0.0;
        v70 = 0;
      }
      v58 += v70;
    }
    LOBYTE(v58) = v58 != 0;
  }
  return v58;
}


// Address: 0x1e08180 | Name: _ZN3RBX9Collision21BlockBlockContact_New18computeEdgeContactERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
char __fastcall RBX::Collision::BlockBlockContact_New::computeEdgeContact(
        RBX::Collision::BlockBlockContact_New *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors,
        float a3,
        float overlapIgnored)
{
  int v5; // r14d
  __int64 v6; // r8
  int v7; // edx
  int v8; // r15d
  int v9; // ebp
  unsigned int v10; // r13d
  int v11; // r12d
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // rax
  RBX::Body *bodyA; // rdi
  int v14; // r14d
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rdx
  __m128 v18; // xmm2
  __m128 v19; // xmm1
  __m128 v20; // xmm0
  __m128 v21; // xmm3
  __int64 v22; // rdx
  __m128 v23; // xmm1
  __m128 v24; // xmm2
  RBX::Body *bodyB; // rdi
  RBX::Collision::FeaturePolyCollisionConnector *v26; // rbp
  int v27; // r8d
  __int64 v28; // rdx
  __int64 v29; // rcx
  __int64 v30; // rdx
  __m128 v31; // xmm2
  __m128 v32; // xmm1
  __m128 v33; // xmm0
  __m128 v34; // xmm3
  int v35; // r12d
  __m128 v36; // xmm1
  __m128 v37; // xmm2
  float v38; // xmm1_4
  float v39; // xmm0_4
  char result; // al
  int v41; // [rsp+Ch] [rbp-BCh]
  RBX::Vector3 closestPtA; // [rsp+10h] [rbp-B8h] BYREF
  int v43; // [rsp+20h] [rbp-A8h]
  float v44; // [rsp+24h] [rbp-A4h]
  G3D::Vector3 v45; // [rsp+28h] [rbp-A0h] BYREF
  RBX::Vector3 closestPtB; // [rsp+38h] [rbp-90h] BYREF
  __int64 v47; // [rsp+48h] [rbp-80h]
  __int64 v48; // [rsp+50h] [rbp-78h]
  RBX::Vector3 dirB; // [rsp+58h] [rbp-70h] BYREF
  RBX::Vector3 ptB; // [rsp+68h] [rbp-60h] BYREF
  RBX::Vector3 dirA; // [rsp+78h] [rbp-50h] BYREF
  RBX::Vector3 ptA; // [rsp+88h] [rbp-40h] BYREF

  v5 = this->mFeature[0];
  v6 = (unsigned int)this->mFeature[1];
  v7 = v6 - 6;
  v8 = (int)(v5 + ((unsigned int)((v5 - 6) >> 31) >> 30) - 6) >> 2;
  v9 = v8 + 3 * (v5 - ((v5 + ((unsigned int)(v5 - 6) >> 31) - 6) & 0xFFFFFFFE) - 6);
  v48 = v5 + ((unsigned int)((v5 - 6) >> 31) >> 30) - 6;
  if ( v5 >= 19 )
    v9 = (v9 + 3) % 6;
  v10 = v7 + ((unsigned int)(v7 >> 31) >> 30);
  v11 = v7 / 4 + 3 * (v7 % 2);
  v44 = a3;
  v41 = v6 - 6;
  v47 = v6;
  v43 = v7 / 4;
  if ( (char)v6 >= 19 )
    v11 = (v11 + 3) % 6;
  CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                         newCollisionConnectors,
                         this->prim0,
                         this->prim1,
                         RBX::Collision::FeaturePolyPair::EDGE_EDGE_PAIR);
  CollisionConnector->param0 = v9;
  CollisionConnector->param1 = v11;
  bodyA = CollisionConnector->bodyA;
  if ( (char)v5 > 17 )
  {
    v15 = (unsigned int)((int)(v5 + ((unsigned int)((v5 - 18) >> 31) >> 30) - 18) >> 2);
    v14 = v5 - 17;
  }
  else
  {
    v14 = v5 - (v48 & 0xFFFFFFFC) - 6;
    v15 = v8;
  }
  v16 = *(_QWORD *)(*((_QWORD *)this->prim0 + 18) + 72LL);
  v17 = 3LL * dword_56F9F0[4 * v15 + v14];
  v18 = (__m128)*(unsigned int *)(v16 + 4 * v17);
  v19 = (__m128)*(unsigned int *)(v16 + 4 * v17 + 4);
  v20 = (__m128)*(unsigned int *)(v16 + 4 * v17 + 8);
  v21 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.x,
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(v20, v20, 224),
              _mm_unpacklo_ps(
                (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][2]),
                (__m128)LODWORD(bodyA->pv.position.rotation.elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(v19, v19, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][1]),
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(v18, v18, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[1][0]))))));
  v20.m128_f32[0] = (float)((float)(v20.m128_f32[0] * bodyA->pv.position.rotation.elt[2][2])
                          + (float)((float)(v19.m128_f32[0] * bodyA->pv.position.rotation.elt[2][1])
                                  + (float)(v18.m128_f32[0] * bodyA->pv.position.rotation.elt[2][0])))
                  + bodyA->pv.position.translation.z;
  _mm_storel_ps((double *)&ptA.x, v21);
  LODWORD(ptA.z) = v20.m128_i32[0];
  v22 = v9 % 3;
  v20.m128_f32[0] = (float)((-2 * (v9 / 3)) | 1);
  v23 = (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][v22]);
  v23.m128_f32[0] = v23.m128_f32[0] * v20.m128_f32[0];
  v24 = (__m128)LODWORD(bodyA->pv.position.rotation.elt[1][v22]);
  v24.m128_f32[0] = v24.m128_f32[0] * v20.m128_f32[0];
  v20.m128_f32[0] = v20.m128_f32[0] * bodyA->pv.position.rotation.elt[2][v22];
  _mm_storel_ps((double *)&dirA.x, _mm_unpacklo_ps(v23, v24));
  LODWORD(dirA.z) = v20.m128_i32[0];
  bodyB = CollisionConnector->bodyB;
  v26 = CollisionConnector;
  if ( (char)v47 > 17 )
  {
    v28 = (unsigned int)((int)(v47 + ((unsigned int)(((int)v47 - 18) >> 31) >> 30) - 18) >> 2);
    v27 = v47 - 17;
  }
  else
  {
    v27 = v41 - (v10 & 0xFFFFFFFC);
    v28 = v43;
  }
  v29 = *(_QWORD *)(*((_QWORD *)this->prim1 + 18) + 72LL);
  v30 = 3LL * dword_56F9F0[4 * v28 + v27];
  v31 = (__m128)*(unsigned int *)(v29 + 4 * v30);
  v32 = (__m128)*(unsigned int *)(v29 + 4 * v30 + 4);
  v33 = (__m128)*(unsigned int *)(v29 + 4 * v30 + 8);
  v34 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(v33, v33, 224),
              _mm_unpacklo_ps(
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(v32, v32, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(v31, v31, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]))))));
  v33.m128_f32[0] = (float)((float)(v33.m128_f32[0] * bodyB->pv.position.rotation.elt[2][2])
                          + (float)((float)(v32.m128_f32[0] * bodyB->pv.position.rotation.elt[2][1])
                                  + (float)(v31.m128_f32[0] * bodyB->pv.position.rotation.elt[2][0])))
                  + bodyB->pv.position.translation.z;
  _mm_storel_ps((double *)&ptB.x, v34);
  LODWORD(ptB.z) = v33.m128_i32[0];
  LODWORD(v29) = v11 / 3;
  v35 = v11 % 3;
  LODWORD(v29) = (-2 * v29) | 1;
  v36 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][v35]);
  v36.m128_f32[0] = v36.m128_f32[0] * (float)(int)v29;
  v37 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][v35]);
  v37.m128_f32[0] = v37.m128_f32[0] * (float)(int)v29;
  v33.m128_f32[0] = (float)(int)v29 * bodyB->pv.position.rotation.elt[2][v35];
  _mm_storel_ps((double *)&dirB.x, _mm_unpacklo_ps(v36, v37));
  LODWORD(dirB.z) = v33.m128_i32[0];
  *(_QWORD *)&closestPtA.x = 0;
  closestPtA.z = 0.0;
  *(_QWORD *)&closestPtB.x = 0;
  closestPtB.z = 0.0;
  if ( !RBX::Collision::findClosestPointsOnLines(&ptA, &ptB, &dirA, &dirB, &closestPtA, &closestPtB, 0.000001) )
    goto LABEL_13;
  v38 = closestPtA.z - closestPtB.z;
  _mm_storel_ps(
    (double *)&v45.x,
    _mm_sub_ps((__m128)*(unsigned __int64 *)&closestPtA.x, (__m128)*(unsigned __int64 *)&closestPtB.x));
  v45.z = v38;
  v39 = G3D::Vector3::unitize(&v45, v38);
  v26->contactPoint = closestPtA;
  v26->normal = v45;
  v26->depth = -v39;
  result = 1;
  if ( v44 >= v39 )
  {
LABEL_13:
    *(_QWORD *)&v26->normal.x = 0;
    v26->normal.z = 0.0;
    return 0;
  }
  return result;
}


// Address: 0x1e08660 | Name: _ZNK3RBX9Collision21BlockBlockContact_New21getCachedDataForDebugERiRNS_8NormalIdES4_PiRb
void __fastcall RBX::Collision::BlockBlockContact_New::getCachedDataForDebug(
        const RBX::Collision::BlockBlockContact_New *this,
        int *witnessId,
        RBX::NormalId *separatingAxisId,
        RBX::NormalId *face,
        int *edges,
        bool *isFaceContact)
{
  __int64 mWitnessId; // rax
  int8_t v7; // dl

  mWitnessId = this->mWitnessId;
  *witnessId = mWitnessId;
  *separatingAxisId = this->mSeparatingAxisId;
  v7 = this->mFeature[mWitnessId];
  *isFaceContact = (unsigned __int8)v7 < 6u;
  if ( (unsigned __int8)v7 > 5u )
  {
    *edges = this->mFeature[0] - 6;
    edges[1] = this->mFeature[1] - 6;
  }
  else
  {
    *face = this->mFeature[mWitnessId];
  }
}


// Address: 0x1e086c0 | Name: _ZN3RBX9Collision21BlockBlockContact_New29updateMinPenetrationFacePlaneEfRfRb
char __fastcall RBX::Collision::BlockBlockContact_New::updateMinPenetrationFacePlane(
        RBX::Collision::BlockBlockContact_New *this,
        float overlapIgnored,
        float *minPenetration,
        bool *isFacePlaneContact)
{
  unsigned int v4; // ecx
  int mSeparatingAxisId; // edx
  __int64 v6; // rcx
  int v7; // r15d
  int v8; // ebp
  RBX::Body *Body; // r12
  unsigned int *v10; // rax
  int v11; // edx
  __m128 v12; // xmm1
  __m128 v13; // xmm0
  float *v14; // r13
  __m128 v15; // xmm2
  const RBX::Matrix3 *v16; // r14
  __m128 v17; // xmm4
  __int64 v18; // rbp
  int v19; // r12d
  int v20; // r15d
  __m128i v21; // xmm2
  int v22; // eax
  float v23; // xmm0_4
  char result; // al
  bool v25; // [rsp+Bh] [rbp-ADh]
  float v26; // [rsp+Ch] [rbp-ACh]
  int8_t v27; // [rsp+10h] [rbp-A8h]
  int8_t v28; // [rsp+14h] [rbp-A4h]
  int mWitnessId; // [rsp+18h] [rbp-A0h]
  unsigned int v30; // [rsp+1Ch] [rbp-9Ch]
  int v31; // [rsp+20h] [rbp-98h]
  _DWORD v33[2]; // [rsp+30h] [rbp-88h]
  __int64 v34; // [rsp+38h] [rbp-80h]
  __int64 v35; // [rsp+40h] [rbp-78h]
  bool *v36; // [rsp+48h] [rbp-70h]
  __int64 v37; // [rsp+50h] [rbp-68h]
  __int64 v38; // [rsp+58h] [rbp-60h]
  G3D::Matrix3 *p_rotation; // [rsp+60h] [rbp-58h]
  RBX::Vector3 _vec; // [rsp+68h] [rbp-50h] BYREF
  double v41; // [rsp+78h] [rbp-40h] BYREF
  __int32 v42; // [rsp+80h] [rbp-38h]
  G3D::Vector3 v43; // 0:kr00_12.12
  RBX::Vector3 v44; // 0:kr14_12.12

  v36 = isFacePlaneContact;
  *isFacePlaneContact = 0;
  v4 = this->mFeature[0];
  v28 = this->mFeature[0];
  v33[0] = v4;
  v27 = this->mFeature[1];
  v33[1] = v27;
  v25 = v4 < 6 || (unsigned int)v27 < 6;
  mSeparatingAxisId = this->mSeparatingAxisId;
  v31 = mSeparatingAxisId + 2;
  v26 = INFINITY;
  mWitnessId = this->mWitnessId;
  v6 = (unsigned int)mWitnessId;
  v35 = (unsigned int)(mSeparatingAxisId - 1);
  while ( 2 )
  {
    v7 = (int)v6 % 2;
    v30 = v6 + 1;
    v34 = v6;
    v8 = v6 - ((v6 + ((unsigned int)(v6 + 1) >> 31) + 1) & 0xFFFFFFFE) + 1;
    Body = RBX::Collision::Contact::getBody(this, (int)v6 % 2);
    p_rotation = &Body->pv.position.rotation;
    v10 = (unsigned int *)RBX::Collision::Contact::getBody(this, v8);
    v38 = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)&this->prim0 + (v7 != 0)) + 144LL) + 72LL);
    v11 = v8;
    v12 = (__m128)v10[61];
    v13 = (__m128)v10[62];
    v12.m128_f32[0] = v12.m128_f32[0] - Body->pv.position.translation.x;
    v13.m128_f32[0] = v13.m128_f32[0] - Body->pv.position.translation.y;
    v14 = *(float **)(*(_QWORD *)(*((_QWORD *)&this->prim0 + (v8 != 0)) + 144LL) + 72LL);
    v15 = (__m128)v10[63];
    v15.m128_f32[0] = v15.m128_f32[0] - Body->pv.position.translation.z;
    v16 = (const RBX::Matrix3 *)(v10 + 52);
    v17 = _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(v15, v15, 224),
              (__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[2][0]),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(v13, v13, 224),
                (__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[1][0]),
              _mm_mul_ps(
                _mm_shuffle_ps(v12, v12, 224),
                (__m128)*(unsigned __int64 *)&Body->pv.position.rotation.elt[0][0])));
    v15.m128_f32[0] = (float)(v15.m128_f32[0] * Body->pv.position.rotation.elt[2][2])
                    + (float)((float)(v13.m128_f32[0] * Body->pv.position.rotation.elt[1][2])
                            + (float)(v12.m128_f32[0] * Body->pv.position.rotation.elt[0][2]));
    _mm_storel_ps(&v41, v17);
    v42 = v15.m128_i32[0];
    v18 = v7;
    v37 = v11;
    v19 = v35;
    do
    {
      v20 = ++v19 % 3;
      v43 = G3D::Matrix3::column(p_rotation, v19 % 3);
      v13.m128_i32[0] = LODWORD(v43.x);
      v13.m128_i32[1] = LODWORD(v43.y);
      _mm_storel_ps((double *)&_vec.x, v13);
      _vec.z = v43.z;
      v44 = RBX::Math::vectorToObjectSpace(&_vec, v16);
      v13.m128_i32[0] = LODWORD(v44.x);
      v13.m128_i32[1] = LODWORD(v44.y);
      v21 = (__m128i)_mm_and_ps(_mm_mul_ps((__m128)*(unsigned __int64 *)v14, v13), (__m128)xmmword_3E5B40);
      v12.m128_f32[0] = v44.z * v14[2];
      v12 = _mm_and_ps(v12, (__m128)xmmword_3E5B40);
      v12.m128_f32[0] = (float)((float)(v12.m128_f32[0]
                                      + (float)(*(float *)_mm_shuffle_epi32(v21, 229).m128i_i32 + *(float *)v21.m128i_i32))
                              + *(float *)(v38 + 4LL * v20))
                      - fabs(*((float *)&v41 + v20));
      if ( v12.m128_f32[0] <= overlapIgnored )
      {
        this->mWitnessId = v18;
        this->mSeparatingAxisId = v20;
        return 0;
      }
      v22 = v20 + 3;
      if ( *((float *)&v41 + v19 % 3) > 0.0 )
        v22 = v19 % 3;
      if ( v25 )
      {
        v23 = v12.m128_f32[0];
        if ( v33[v18] != v22 )
          v23 = v26;
        v26 = v23;
      }
      v13 = (__m128)*(unsigned int *)minPenetration;
      if ( v13.m128_f32[0] > v12.m128_f32[0] )
      {
        *minPenetration = v12.m128_f32[0];
        this->mFeature[v18] = v22;
        this->mFeature[v37] = -1;
        this->mWitnessId = v18;
        this->mSeparatingAxisId = v20;
        *v36 = 1;
      }
    }
    while ( v19 < v31 );
    v6 = v30;
    if ( (int)v34 <= mWitnessId )
      continue;
    break;
  }
  result = 1;
  if ( v25 && (v28 != this->mFeature[0] || v27 != this->mFeature[1]) && v26 <= (float)(*minPenetration * 1.01) )
  {
    *minPenetration = v26;
    this->mFeature[0] = v28;
    this->mFeature[1] = v27;
  }
  return result;
}


// Address: 0x1e08a10 | Name: _ZN3RBX9Collision21BlockBlockContact_New29updateMinPenetrationEdgePlaneEfRfRbS3_
char __fastcall RBX::Collision::BlockBlockContact_New::updateMinPenetrationEdgePlane(
        RBX::Collision::BlockBlockContact_New *this,
        float overlapIgnored,
        float *minPenetrationInOut,
        bool *isParallelEdges,
        bool *isEdgePlaneContact)
{
  RBX::Body *Body; // rbp
  RBX::Body *v6; // rax
  RBX::Primitive *prim0; // rcx
  RBX::Primitive *prim1; // rdx
  unsigned int *v9; // r13
  const RBX::Matrix3 *p_rotation; // r14
  __m128 z_low; // xmm0
  const RBX::Matrix3 *v12; // r15
  __m128 v13; // xmm1
  RBX::NormalId v14; // r12d
  __m128 v15; // xmm2
  __m128 v16; // xmm3
  __m128 v17; // xmm5
  float v18; // xmm0_4
  float v19; // xmm1_4
  float v20; // xmm0_4
  __m128 x_low; // xmm0
  __m128 v22; // xmm1
  __m128 v23; // xmm1
  __m128 v24; // xmm0
  float v25; // xmm2_4
  __m128 v26; // xmm4
  RBX::Collision::BlockBlockContact_New *v27; // rbx
  RBX::Block *v28; // rdi
  float v29; // xmm0_4
  RBX::Block *v30; // rdi
  __m128i v31; // xmm2
  RBX::NormalId iCol; // [rsp+4h] [rbp-104h]
  G3D::Vector3 _vec; // [rsp+8h] [rbp-100h] BYREF
  float v35; // [rsp+18h] [rbp-F0h]
  float v36; // [rsp+1Ch] [rbp-ECh]
  RBX::Vector3 crossAxis; // [rsp+20h] [rbp-E8h] BYREF
  __m128 v38; // [rsp+30h] [rbp-D8h] BYREF
  float *v39; // [rsp+48h] [rbp-C0h]
  __m128 v40; // [rsp+50h] [rbp-B8h]
  bool *v41; // [rsp+60h] [rbp-A8h]
  RBX::Collision::BlockBlockContact_New *v42; // [rsp+68h] [rbp-A0h]
  bool *v43; // [rsp+70h] [rbp-98h]
  unsigned int *v44; // [rsp+78h] [rbp-90h]
  __m128 v45; // [rsp+80h] [rbp-88h]
  __m128 v46; // [rsp+90h] [rbp-78h]
  __m128 v47; // [rsp+A0h] [rbp-68h]
  __m128 v48; // [rsp+B0h] [rbp-58h]
  __m128 v49; // [rsp+C0h] [rbp-48h]
  G3D::Vector3 v50; // 0:kr00_12.12
  G3D::Vector3 v51; // 0:kr14_12.12
  RBX::Vector3 v52; // 0:kr20_12.12
  RBX::Vector3 v53; // 0:kr34_12.12

  v39 = minPenetrationInOut;
  v36 = overlapIgnored;
  v43 = isEdgePlaneContact;
  *isEdgePlaneContact = 0;
  v41 = isParallelEdges;
  *isParallelEdges = 0;
  iCol = RBX::NormalId::NORM_X;
  Body = RBX::Collision::Contact::getBody(this, 0);
  v6 = RBX::Collision::Contact::getBody(this, 1);
  prim0 = this->prim0;
  v42 = this;
  prim1 = this->prim1;
  v44 = *(unsigned int **)(*((_QWORD *)prim0 + 18) + 72LL);
  v9 = *(unsigned int **)(*((_QWORD *)prim1 + 18) + 72LL);
  v35 = v6->pv.position.translation.x - Body->pv.position.translation.x;
  p_rotation = &v6->pv.position.rotation;
  z_low = (__m128)*(unsigned __int64 *)&Body->pv.position.translation.y;
  v12 = &Body->pv.position.rotation;
  v13 = _mm_sub_ps((__m128)*(unsigned __int64 *)&v6->pv.position.translation.y, z_low);
  v45 = v13;
LABEL_2:
  v14 = RBX::NormalId::NORM_X;
  while ( 1 )
  {
    v50 = G3D::Matrix3::column(v12, iCol);
    z_low.m128_i32[0] = LODWORD(v50.x);
    z_low.m128_i32[1] = LODWORD(v50.y);
    v13.m128_i32[0] = LODWORD(v50.z);
    v40 = z_low;
    v38 = v13;
    v51 = G3D::Matrix3::column(p_rotation, v14);
    z_low.m128_i32[0] = LODWORD(v51.x);
    z_low.m128_i32[1] = LODWORD(v51.y);
    v15 = _mm_shuffle_ps(v40, v40, 229);
    v16 = v15;
    v17 = v38;
    v18 = _mm_shuffle_ps(z_low, z_low, 229).m128_f32[0];
    v16.m128_f32[0] = (float)(v15.m128_f32[0] * v51.z) - (float)(v38.m128_f32[0] * v18);
    v19 = v51.z * v40.m128_f32[0];
    v17.m128_f32[0] = (float)(v38.m128_f32[0] * v51.x) - (float)(v51.z * v40.m128_f32[0]);
    v20 = (float)(v18 * v40.m128_f32[0]) - (float)(v15.m128_f32[0] * v51.x);
    _mm_storel_ps((double *)&_vec.x, _mm_unpacklo_ps(v16, v17));
    _vec.z = v20;
    if ( G3D::Vector3::unitize(&_vec, v19) <= 0.001 )
    {
      *v41 = 1;
      return 1;
    }
    x_low = (__m128)LODWORD(_vec.x);
    v22 = _mm_mul_ps((__m128)*(unsigned __int64 *)&_vec.y, v45);
    x_low.m128_f32[0] = (float)(_vec.x * v35) + v22.m128_f32[0];
    v23 = _mm_shuffle_ps(v22, v22, 229);
    v23.m128_f32[0] = v23.m128_f32[0] + x_low.m128_f32[0];
    v38 = v23;
    v52 = RBX::Math::vectorToObjectSpace(&_vec, v12);
    x_low.m128_i32[0] = LODWORD(v52.x);
    x_low.m128_i32[1] = LODWORD(v52.y);
    v23.m128_i32[0] = LODWORD(v52.z);
    v48 = x_low;
    v40 = v23;
    v46 = (__m128)*v44;
    v47 = (__m128)v44[1];
    v24 = (__m128)v44[2];
    v49 = v24;
    v53 = RBX::Math::vectorToObjectSpace(&_vec, p_rotation);
    v24.m128_i32[0] = LODWORD(v53.x);
    v24.m128_i32[1] = LODWORD(v53.y);
    v23.m128_i32[0] = LODWORD(v53.z);
    v25 = v38.m128_f32[0];
    v26 = _mm_add_ps(
            _mm_and_ps(
              _mm_mul_ps(_mm_unpacklo_ps(v40, v23), _mm_unpacklo_ps(v49, (__m128)v9[2])),
              (__m128)xmmword_3E5B40),
            _mm_add_ps(
              _mm_and_ps(
                _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(v24, v48, 17), v48, 226), _mm_unpacklo_ps(v47, (__m128)v9[1])),
                (__m128)xmmword_3E5B40),
              _mm_and_ps(
                _mm_mul_ps(_mm_unpacklo_ps(v48, v24), _mm_unpacklo_ps(v46, (__m128)*v9)),
                (__m128)xmmword_3E5B40)));
    z_low = _mm_shuffle_ps(v26, v26, 229);
    z_low.m128_f32[0] = (float)(z_low.m128_f32[0] + v26.m128_f32[0]) - fabs(v38.m128_f32[0]);
    if ( z_low.m128_f32[0] <= v36 )
      return 0;
    v13 = (__m128)*(unsigned int *)v39;
    if ( v13.m128_f32[0] > z_low.m128_f32[0] )
    {
      *v39 = z_low.m128_f32[0];
      v38 = (__m128)LODWORD(flt_490280[v25 > 0.0]);
      v27 = v42;
      v28 = (RBX::Block *)*((_QWORD *)v42->prim0 + 18);
      v29 = _vec.z * v38.m128_f32[0];
      _mm_storel_ps(
        (double *)&crossAxis.x,
        _mm_mul_ps(_mm_shuffle_ps(v38, v38, 224), (__m128)*(unsigned __int64 *)&_vec.x));
      crossAxis.z = v29;
      v27->mFeature[0] = RBX::Block::getClosestEdge(v28, v12, iCol, &crossAxis) + 6;
      v30 = (RBX::Block *)*((_QWORD *)v27->prim1 + 18);
      v31 = _mm_xor_si128(_mm_load_si128((const __m128i *)&v38), *(__m128i *)&stru_3E4970.x);
      v13 = _mm_mul_ps((__m128)_mm_shuffle_epi32(v31, 80), (__m128)*(unsigned __int64 *)&_vec.x);
      z_low = (__m128)LODWORD(_vec.z);
      z_low.m128_f32[0] = _vec.z * *(float *)v31.m128i_i32;
      _mm_storel_ps((double *)&crossAxis.x, v13);
      LODWORD(crossAxis.z) = z_low.m128_i32[0];
      v27->mFeature[1] = RBX::Block::getClosestEdge(v30, p_rotation, v14, &crossAxis) + 6;
      *v43 = 1;
    }
    if ( (unsigned int)++v14 >= RBX::NormalId::NORM_X_NEG )
    {
      if ( (unsigned int)++iCol < RBX::NormalId::NORM_X_NEG )
        goto LABEL_2;
      return 1;
    }
  }
}


// Address: 0x1e08dc0 | Name: _GLOBAL__sub_I_BlockBlockContact_New.cpp
void __cdecl GLOBAL__sub_I_BlockBlockContact_New_cpp()
{
  qword_2AAF758 = (__int64)boost::system::generic_category();
  qword_2AAF760 = (__int64)boost::system::generic_category();
  qword_2AAF768 = (__int64)boost::system::system_category();
}


