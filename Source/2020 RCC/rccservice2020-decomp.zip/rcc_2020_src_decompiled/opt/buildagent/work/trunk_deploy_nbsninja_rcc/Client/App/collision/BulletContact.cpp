// Address: 0x1de8780 | Name: _ZN3RBX9Collision25BulletCollisionBoxSetPool13requestBoxSetEPK33btGImpactConvexDecompositionShapeRK9btVector3
RBX::Collision::BulletCollisionBoxSetPool::BoxSetWrapper __fastcall RBX::Collision::BulletCollisionBoxSetPool::requestBoxSet(
        const btGImpactConvexDecompositionShape *shape,
        const btVector3 *size)
{
  __int64 v4; // rax
  __m128i v5; // xmm1
  __int64 v6; // rdx
  bool v7; // zf
  __m128i v8; // xmm1
  __int64 v9; // rsi
  unsigned __int64 v10; // rdi
  __int64 v11; // rcx
  __int64 v12; // rdx
  unsigned __int64 v13; // rdx
  __m128i v14; // xmm1
  __int64 v15; // rcx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage> >,unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::value_type *v16; // rax
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage> >,unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::value_type *v17; // r15
  btGImpactQuantizedBvh *bvh; // rbx
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage> >,unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::key_type key; // r14
  char *v20; // r13
  __int64 m_size; // r14
  char *v22; // rbx
  __int64 v23; // rdx
  __int64 v24; // rax
  __int64 v25; // rcx
  char *v26; // rsi
  __int64 v27; // rdx
  __int64 v28; // rdi
  __int64 v29; // rcx
  __int64 v30; // rax
  void *v31; // rdi
  __int64 v32; // rcx
  __int64 v33; // rsi
  __int64 v34; // rdi
  __int64 v35; // rcx
  __int64 v36; // rax
  __int64 v37; // rcx
  char *v38; // rdx
  __int64 v39; // r14
  __int64 v40; // rsi
  __int64 v41; // rcx
  __int64 v42; // rax
  btVector3 originalScale; // xmm0
  RBX::Collision::BulletCollisionBoxSetPool::BoxSetWrapper result; // rax
  __int64 v45; // [rsp+0h] [rbp-58h]
  int v46; // [rsp+8h] [rbp-50h]
  boost::unique_lock<boost::mutex> v47; // [rsp+10h] [rbp-48h] BYREF
  boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage> >,unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::key_type k[7]; // [rsp+20h] [rbp-38h] BYREF

  v47.m = &stru_2AAF4E8;
  v47.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v47);
  v4 = 2654435769LL;
  v5 = _mm_cvtsi32_si128(LODWORD(size->m_floats[0]));
  v6 = (unsigned int)_mm_cvtsi128_si32(v5) + 2654435769LL;
  v7 = *(float *)v5.m128i_i32 == 0.0;
  v8 = _mm_cvtsi32_si128(LODWORD(size->m_floats[1]));
  v9 = 2654435769LL;
  if ( !v7 )
    v9 = v6;
  v11 = (unsigned int)_mm_cvtsi128_si32(v8) + 2654435769LL;
  v12 = 2654435769LL;
  if ( *(float *)v8.m128i_i32 != 0.0 )
    v12 = v11;
  v10 = ((unsigned __int64)&shape[8092791].rawInitialHalfSize.m_floats[2] + ((unsigned __int64)shape >> 3) + 1)
      ^ (v9
       + (((_QWORD)shape + ((unsigned __int64)shape >> 3) + 2654435769u) << 6)
       + (((unsigned __int64)&shape[8092791].rawInitialHalfSize.m_floats[2] + ((unsigned __int64)shape >> 3) + 1) >> 2));
  v13 = v10 ^ (v12 + (v10 << 6) + (v10 >> 2));
  v14 = _mm_cvtsi32_si128(LODWORD(size->m_floats[2]));
  v15 = (unsigned int)_mm_cvtsi128_si32(v14) + 2654435769LL;
  if ( *(float *)v14.m128i_i32 != 0.0 )
    v4 = v15;
  k[0] = v13 ^ (v4 + (v13 << 6) + (v13 >> 2));
  v16 = boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<unsigned long const,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage>>,unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long>>>::operator[](
          &stru_2AAF4B8,
          k);
  v17 = v16;
  bvh = v16->second.bvh;
  if ( bvh )
  {
    key = v16->second.key;
    goto LABEL_38;
  }
  v20 = (char *)btAlignedAllocInternal(0x70u, 16);
  *(_DWORD *)v20 = shape->m_box_set.m_box_tree.m_num_nodes;
  v20[32] = 1;
  *((_QWORD *)v20 + 3) = 0;
  *(_QWORD *)(v20 + 12) = 0;
  m_size = shape->m_box_set.m_box_tree.m_node_array.m_size;
  if ( m_size > 0 )
  {
    v22 = (char *)btAlignedAllocInternal(16 * m_size, 16);
    v23 = *((int *)v20 + 3);
    if ( v23 > 0 )
    {
      v24 = v23 & 3;
      if ( (unsigned __int64)(v23 - 1) >= 3 )
      {
        v26 = v22 + 48;
        v27 = v23 - v24;
        v28 = 0;
        v25 = 0;
        do
        {
          *(_OWORD *)&v22[v28] = *(_OWORD *)(*((_QWORD *)v20 + 3) + v28);
          *(_OWORD *)&v26[v28 - 32] = *(_OWORD *)(*((_QWORD *)v20 + 3) + v28 + 16);
          *(_OWORD *)&v26[v28 - 16] = *(_OWORD *)(*((_QWORD *)v20 + 3) + v28 + 32);
          *(_OWORD *)&v26[v28] = *(_OWORD *)(*((_QWORD *)v20 + 3) + v28 + 48);
          v25 += 4;
          v28 += 64;
        }
        while ( v27 != v25 );
      }
      else
      {
        v25 = 0;
      }
      if ( v24 )
      {
        v29 = 16 * v25;
        v30 = -v24;
        do
        {
          *(_OWORD *)&v22[v29] = *(_OWORD *)(*((_QWORD *)v20 + 3) + v29);
          v29 += 16;
          ++v30;
        }
        while ( v30 );
      }
    }
    v31 = (void *)*((_QWORD *)v20 + 3);
    if ( v31 )
    {
      if ( v20[32] )
        btAlignedFreeInternal(v31);
      *((_QWORD *)v20 + 3) = 0;
    }
    v20[32] = 1;
    *((_QWORD *)v20 + 3) = v22;
    *((_DWORD *)v20 + 4) = m_size;
    if ( (_DWORD)m_size == 1 )
    {
      v32 = 0;
    }
    else
    {
      v33 = 0;
      v32 = 0;
      do
      {
        *(_DWORD *)&v22[v33 + 8] = v46;
        *(_QWORD *)&v22[v33] = v45;
        *(_DWORD *)&v22[v33 + 12] = 0;
        v34 = *((_QWORD *)v20 + 3);
        *(_DWORD *)(v34 + v33 + 24) = v46;
        *(_QWORD *)(v34 + v33 + 16) = v45;
        *(_DWORD *)(v34 + v33 + 28) = 0;
        v32 += 2;
        v22 = (char *)*((_QWORD *)v20 + 3);
        v33 += 32;
      }
      while ( m_size - (m_size & 1) != v32 );
      if ( (m_size & 1) == 0 )
      {
LABEL_29:
        *((_DWORD *)v20 + 3) = m_size;
        v36 = m_size & 3;
        if ( (unsigned __int64)(m_size - 1) >= 3 )
        {
          v38 = v22 + 48;
          v39 = m_size - v36;
          v40 = 0;
          v37 = 0;
          do
          {
            *(BT_QUANTIZED_BVH_NODE *)&v22[v40 * 16] = shape->m_box_set.m_box_tree.m_node_array.m_data[v40];
            *(BT_QUANTIZED_BVH_NODE *)&v38[v40 * 16 - 32] = shape->m_box_set.m_box_tree.m_node_array.m_data[v40 + 1];
            *(BT_QUANTIZED_BVH_NODE *)&v38[v40 * 16 - 16] = shape->m_box_set.m_box_tree.m_node_array.m_data[v40 + 2];
            *(BT_QUANTIZED_BVH_NODE *)&v38[v40 * 16] = shape->m_box_set.m_box_tree.m_node_array.m_data[v40 + 3];
            v37 += 4;
            v40 += 4;
          }
          while ( v39 != v37 );
          if ( !v36 )
            goto LABEL_37;
        }
        else
        {
          v37 = 0;
          if ( (m_size & 3) == 0 )
            goto LABEL_37;
        }
        v41 = v37;
        v42 = -v36;
        do
        {
          *(BT_QUANTIZED_BVH_NODE *)&v22[v41 * 16] = shape->m_box_set.m_box_tree.m_node_array.m_data[v41];
          ++v41;
          ++v42;
        }
        while ( v42 );
        goto LABEL_37;
      }
    }
    v35 = 16 * v32;
    *(_DWORD *)&v22[v35 + 8] = v46;
    *(_QWORD *)&v22[v35] = v45;
    *(_DWORD *)&v22[v35 + 12] = 0;
    v22 = (char *)*((_QWORD *)v20 + 3);
    goto LABEL_29;
  }
  *((_DWORD *)v20 + 3) = m_size;
LABEL_37:
  *(btVector3 *)(v20 + 40) = shape->m_box_set.m_box_tree.m_global_bound.m_min;
  *(btVector3 *)(v20 + 56) = shape->m_box_set.m_box_tree.m_global_bound.m_max;
  originalScale = shape->m_box_set.m_box_tree.originalScale;
  *(__m128i *)(v20 + 88) = _mm_loadu_si128((const __m128i *)&shape->m_box_set.m_box_tree.m_bvhQuantization);
  *(btVector3 *)(v20 + 72) = originalScale;
  *((_QWORD *)v20 + 13) = shape->m_box_set.m_primitive_manager;
  v17->second.bvh = (btGImpactQuantizedBvh *)v20;
  btGImpactQuantizedBvh::buildSet((btGImpactQuantizedBvh *)v20, size);
  key = k[0];
  v17->second.key = k[0];
  bvh = v17->second.bvh;
LABEL_38:
  ++v17->second.count;
  if ( v47.is_locked )
    boost::mutex::unlock(v47.m);
  result.key = key;
  result.bvh = bvh;
  return result;
}


// Address: 0x1de8bc0 | Name: _ZN3RBX9Collision25BulletCollisionBoxSetPool12returnBoxSetERNS1_13BoxSetWrapperE
void __fastcall RBX::Collision::BulletCollisionBoxSetPool::returnBoxSet(
        RBX::Collision::BulletCollisionBoxSetPool::BoxSetWrapper *toReturn)
{
  size_t key; // rcx
  size_t v2; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  _QWORD *p_next; // rbx
  __int64 v6; // r14
  void *v7; // rdi
  boost::unordered::detail::ptr_bucket *v8; // r15
  size_t v9; // r14
  boost::unordered::detail::ptr_bucket::link_pointer v10; // rax
  boost::unordered::detail::ptr_bucket *v11; // r12
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage> >,unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // rax
  size_t v13; // rdx
  boost::unique_lock<boost::mutex> v14; // [rsp+8h] [rbp-30h] BYREF

  v14.m = &stru_2AAF4E8;
  v14.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v14);
  key = toReturn->key;
  v2 = toReturn->key % stru_2AAF4B8.bucket_count_;
  if ( !stru_2AAF4B8.size_ )
    goto LABEL_27;
  next = stru_2AAF4B8.buckets_[v2].next_;
  if ( !next )
    goto LABEL_27;
  p_next = &next->next_->next_;
  if ( !next->next_ )
    goto LABEL_27;
  while ( p_next[1] != key )
  {
    if ( p_next[1] % stru_2AAF4B8.bucket_count_ != v2 )
      goto LABEL_27;
LABEL_5:
    p_next = (_QWORD *)*p_next;
    if ( !p_next )
      goto LABEL_27;
  }
  if ( key != p_next[2] )
    goto LABEL_5;
  if ( p_next[3]-- == 1 )
  {
    v6 = p_next[5];
    v7 = (void *)v6;
    if ( *(_QWORD *)(v6 + 24) )
    {
      if ( *(_BYTE *)(v6 + 32) )
        btAlignedFreeInternal(*(void **)(v6 + 24));
      v7 = (void *)p_next[5];
      *(_QWORD *)(v6 + 24) = 0;
    }
    *(_BYTE *)(v6 + 32) = 1;
    *(_QWORD *)(v6 + 24) = 0;
    *(_QWORD *)(v6 + 12) = 0;
    btAlignedFreeInternal(v7);
    v8 = (boost::unordered::detail::ptr_bucket *)*p_next;
    v9 = p_next[1] % stru_2AAF4B8.bucket_count_;
    v10 = stru_2AAF4B8.buckets_[v9].next_;
    do
    {
      v11 = v10;
      v10 = v10->next_;
    }
    while ( v10 != (boost::unordered::detail::ptr_bucket::link_pointer)p_next );
    do
    {
      v11->next_ = *(boost::unordered::detail::ptr_bucket::link_pointer *)p_next;
      operator delete(p_next);
      --stru_2AAF4B8.size_;
      if ( v11->next_ )
      {
        v13 = (unsigned __int64)v11->next_[1].next_ % stru_2AAF4B8.bucket_count_;
        if ( v13 == v9 )
        {
          v13 = v9;
        }
        else
        {
          buckets = stru_2AAF4B8.buckets_;
          stru_2AAF4B8.buckets_[v13].next_ = v11;
          if ( buckets[v9].next_ == v11 )
            goto LABEL_25;
        }
      }
      else
      {
        buckets = stru_2AAF4B8.buckets_;
        v13 = v9;
        if ( stru_2AAF4B8.buckets_[v9].next_ == v11 )
LABEL_25:
          buckets[v9].next_ = 0;
      }
      p_next = &v11->next_->next_;
      v9 = v13;
    }
    while ( v11->next_ != v8 );
  }
LABEL_27:
  if ( v14.is_locked )
    boost::mutex::unlock(v14.m);
}


// Address: 0x1de8dd0 | Name: _ZN3RBX9Collision24BulletCollisionInterface16computeManifoldsEPNS_5WorldEbRP20btCollisionAlgorithmR20btAlignedObjectArrayIP20btPersistentManifoldER16btManifoldResultP17btCollisionObjectSF_RK9btVector3SI_P21btGImpactQuantizedBvhSK_
void __fastcall RBX::Collision::BulletCollisionInterface::computeManifolds(
        RBX::World *world,
        bool inContact,
        btCollisionAlgorithm **algorithm,
        btManifoldArray *manifoldArray,
        btManifoldResult *resultOut,
        btCollisionObject *colObj0,
        btCollisionObject *colObj1,
        const btVector3 *obj0Scale,
        const btVector3 *obj1Scale,
        btGImpactQuantizedBvh *obj0BoxSet,
        btGImpactQuantizedBvh *obj1BoxSet)
{
  btCollisionObject *v11; // r12
  btCollisionShape *m_collisionShape; // rbp
  btTransform *p_m_worldTransform; // r14
  btCollisionShape *v17; // rdx
  _DWORD *v18; // r12
  btPersistentManifold *v19; // rax
  _DWORD *v20; // rax
  btPersistentManifold *m_manifoldPtr; // rax
  int v22; // ecx
  int v23; // r13d
  void *v24; // rbp
  __int64 v25; // rax
  __int64 v26; // rdx
  __int64 v27; // rax
  btCollisionAlgorithm **v28; // r13
  __int64 m_size; // rbp
  btPersistentManifold **m_data; // rdi
  __int64 v31; // rax
  __int64 v32; // rcx
  __int64 v33; // rbp
  btCollisionAlgorithm **v34; // [rsp+0h] [rbp-F8h]
  _DWORD *v35; // [rsp+8h] [rbp-F0h]
  btCollisionObject *v36; // [rsp+10h] [rbp-E8h]
  __int128 v37; // [rsp+18h] [rbp-E0h] BYREF
  char v38; // [rsp+28h] [rbp-D0h]
  __int64 v39; // [rsp+30h] [rbp-C8h]
  __int16 v40; // [rsp+38h] [rbp-C0h]
  char v41; // [rsp+3Ah] [rbp-BEh]
  int v42; // [rsp+3Ch] [rbp-BCh]
  char v43; // [rsp+40h] [rbp-B8h]
  int v44; // [rsp+44h] [rbp-B4h]
  _QWORD v45[6]; // [rsp+48h] [rbp-B0h] BYREF
  __int128 v46; // [rsp+78h] [rbp-80h]
  _QWORD v47[6]; // [rsp+88h] [rbp-70h] BYREF
  __int128 v48; // [rsp+B8h] [rbp-40h]

  v11 = colObj0;
  m_collisionShape = colObj0->m_collisionShape;
  p_m_worldTransform = &colObj0->m_worldTransform;
  v47[0] = 0;
  v47[1] = m_collisionShape;
  v47[2] = colObj0;
  v47[3] = obj0BoxSet;
  v47[4] = &colObj0->m_worldTransform;
  v47[5] = -1;
  v48 = (__int128)*obj0Scale;
  v17 = colObj1->m_collisionShape;
  v45[0] = 0;
  v45[1] = v17;
  v45[2] = colObj1;
  v45[3] = obj1BoxSet;
  v45[4] = &colObj1->m_worldTransform;
  v45[5] = -1;
  v46 = (__int128)*obj1Scale;
  if ( !*algorithm )
    *algorithm = (btCollisionAlgorithm *)(*(__int64 (__fastcall **)(_QWORD, _QWORD *, _QWORD *, _QWORD))(**((_QWORD **)world + 26) + 16LL))(
                                           *((_QWORD *)world + 26),
                                           v47,
                                           v45,
                                           0);
  resultOut->m_body0Wrap = (const btCollisionObjectWrapper *)v47;
  resultOut->m_body1Wrap = (const btCollisionObjectWrapper *)v45;
  resultOut->m_manifoldPtr = 0;
  v37 = xmmword_3E5FB0;
  v38 = 1;
  v39 = 0;
  v40 = 256;
  v41 = 1;
  v42 = 1025758986;
  v43 = 0;
  v44 = 0;
  if ( stru_2AAF230.value )
  {
    std::mutex::lock(&stru_2AAF490);
    v36 = v11;
    if ( (_DWORD)qword_2AAF474 )
    {
      v18 = (_DWORD *)*((_QWORD *)qword_2AAF480 + (int)qword_2AAF474 - 1);
      LODWORD(qword_2AAF474) = qword_2AAF474 - 1;
    }
    else
    {
      v20 = btAlignedAllocInternal(0x168u, 16);
      v20[77] = 953267991;
      *((_BYTE *)v20 + 332) &= 0xF0u;
      v18 = v20;
    }
    std::mutex::unlock(&stru_2AAF490);
    v35 = v18;
    (*((void (__fastcall **)(_QWORD, _QWORD *, _QWORD *, __int128 *, btManifoldResult *, _DWORD *))(*algorithm)->_vptr$btCollisionAlgorithm
     + 2))(
      *algorithm,
      v47,
      v45,
      &v37,
      resultOut,
      v18);
    m_manifoldPtr = resultOut->m_manifoldPtr;
    if ( m_manifoldPtr && m_manifoldPtr->m_cachedPoints && !inContact )
      (*((void (__fastcall **)(_QWORD, _QWORD *, _QWORD *, __int128 *, btManifoldResult *, _DWORD *))(*algorithm)->_vptr$btCollisionAlgorithm
       + 2))(
        *algorithm,
        v47,
        v45,
        &v37,
        resultOut,
        v18);
    std::mutex::lock(&stru_2AAF490);
    v22 = qword_2AAF474;
    v11 = v36;
    if ( (_DWORD)qword_2AAF474 != HIDWORD(qword_2AAF474) )
      goto LABEL_36;
    v23 = 1;
    if ( (_DWORD)qword_2AAF474 )
      v23 = 2 * qword_2AAF474;
    if ( (int)qword_2AAF474 >= v23 )
      goto LABEL_36;
    v34 = algorithm;
    if ( v23 )
    {
      v24 = btAlignedAllocInternal(8LL * v23, 16);
      v22 = qword_2AAF474;
      if ( (int)qword_2AAF474 <= 0 )
        goto LABEL_31;
    }
    else
    {
      v24 = 0;
      if ( (int)qword_2AAF474 <= 0 )
      {
LABEL_31:
        if ( qword_2AAF480 )
        {
          if ( byte_2AAF488 )
          {
            btAlignedFreeInternal(qword_2AAF480);
            v22 = qword_2AAF474;
          }
          qword_2AAF480 = 0;
        }
        byte_2AAF488 = 1;
        qword_2AAF480 = v24;
        HIDWORD(qword_2AAF474) = v23;
        algorithm = v34;
LABEL_36:
        *((_QWORD *)qword_2AAF480 + v22) = v35;
        LODWORD(qword_2AAF474) = v22 + 1;
        std::mutex::unlock(&stru_2AAF490);
        goto LABEL_37;
      }
    }
    v25 = v22 & 3;
    if ( (unsigned __int64)(v22 - 1LL) >= 3 )
    {
      v26 = 0;
      do
      {
        *((_QWORD *)v24 + v26) = *((_QWORD *)qword_2AAF480 + v26);
        *((_QWORD *)v24 + v26 + 1) = *((_QWORD *)qword_2AAF480 + v26 + 1);
        *((_QWORD *)v24 + v26 + 2) = *((_QWORD *)qword_2AAF480 + v26 + 2);
        *((_QWORD *)v24 + v26 + 3) = *((_QWORD *)qword_2AAF480 + v26 + 3);
        v26 += 4;
      }
      while ( v22 - v25 != v26 );
      if ( (v22 & 3) == 0 )
        goto LABEL_31;
    }
    else
    {
      v26 = 0;
      if ( (v22 & 3) == 0 )
        goto LABEL_31;
    }
    v27 = -v25;
    do
    {
      *((_QWORD *)v24 + v26) = *((_QWORD *)qword_2AAF480 + v26);
      ++v26;
      ++v27;
    }
    while ( v27 );
    goto LABEL_31;
  }
  (*((void (__fastcall **)(_QWORD, _QWORD *, _QWORD *, __int128 *, btManifoldResult *))(*algorithm)->_vptr$btCollisionAlgorithm
   + 3))(
    *algorithm,
    v47,
    v45,
    &v37,
    resultOut);
  v19 = resultOut->m_manifoldPtr;
  if ( v19 && v19->m_cachedPoints && !inContact )
    (*((void (__fastcall **)(_QWORD, _QWORD *, _QWORD *, __int128 *, btManifoldResult *))(*algorithm)->_vptr$btCollisionAlgorithm
     + 3))(
      *algorithm,
      v47,
      v45,
      &v37,
      resultOut);
LABEL_37:
  v28 = algorithm;
  m_size = manifoldArray->m_size;
  if ( m_size < 0 )
  {
    if ( manifoldArray->m_capacity < 0 )
    {
      m_data = manifoldArray->m_data;
      if ( m_data )
      {
        if ( manifoldArray->m_ownsMemory )
          btAlignedFreeInternal(m_data);
        manifoldArray->m_data = 0;
      }
      manifoldArray->m_ownsMemory = 1;
      manifoldArray->m_data = 0;
      manifoldArray->m_capacity = 0;
    }
    v31 = m_size;
    if ( (-(int)m_size & 7LL) != 0 )
    {
      v32 = -(-(int)m_size & 7LL);
      v31 = m_size;
      do
      {
        manifoldArray->m_data[v31++] = 0;
        ++v32;
      }
      while ( v32 );
    }
    if ( (unsigned int)m_size <= 0xFFFFFFF8 )
    {
      do
      {
        manifoldArray->m_data[v31] = 0;
        manifoldArray->m_data[v31 + 1] = 0;
        manifoldArray->m_data[v31 + 2] = 0;
        manifoldArray->m_data[v31 + 3] = 0;
        manifoldArray->m_data[v31 + 4] = 0;
        manifoldArray->m_data[v31 + 5] = 0;
        manifoldArray->m_data[v31 + 6] = 0;
        manifoldArray->m_data[v31 + 7] = 0;
        v31 += 8;
      }
      while ( v31 );
    }
  }
  manifoldArray->m_size = 0;
  (*((void (__fastcall **)(btCollisionAlgorithm *, btManifoldArray *))(*v28)->_vptr$btCollisionAlgorithm + 5))(
    *v28,
    manifoldArray);
  if ( (v11->m_collisionShape->m_shapeType == 25 || colObj1->m_collisionShape->m_shapeType == 25)
    && manifoldArray->m_size > 0 )
  {
    v33 = 0;
    do
      btPersistentManifold::refreshContactPoints(
        manifoldArray->m_data[v33++],
        p_m_worldTransform,
        &colObj1->m_worldTransform);
    while ( v33 < manifoldArray->m_size );
  }
}


// Address: 0x1de9360 | Name: _ZN3RBX9Collision24BulletCollisionInterface16computeManifoldsEPNS_5WorldEbRP20btCollisionAlgorithmR20btAlignedObjectArrayIP20btPersistentManifoldER16btManifoldResultP17btCollisionObjectSF_
void __fastcall RBX::Collision::BulletCollisionInterface::computeManifolds(
        RBX::World *world,
        bool inContact,
        btCollisionAlgorithm **algorithm,
        btManifoldArray *manifoldArray,
        btManifoldResult *resultOut,
        btCollisionObject *colObj0,
        btCollisionObject *colObj1)
{
  btCollisionObject *v7; // r12
  btCollisionAlgorithm **v10; // rbp
  btCollisionShape *m_collisionShape; // rax
  btTransform *p_m_worldTransform; // r14
  btCollisionShape *v13; // rax
  _DWORD *v14; // r12
  btPersistentManifold *v15; // rax
  _DWORD *v16; // rax
  btPersistentManifold *m_manifoldPtr; // rax
  int v18; // ecx
  int v19; // r13d
  void *v20; // rbp
  __int64 v21; // rax
  __int64 v22; // rdx
  __int64 v23; // rax
  btCollisionAlgorithm **v24; // r13
  __int64 m_size; // rbp
  btPersistentManifold **m_data; // rdi
  __int64 v27; // rax
  __int64 v28; // rcx
  __int64 v29; // rbp
  btCollisionAlgorithm **v30; // [rsp+0h] [rbp-F8h]
  _DWORD *v31; // [rsp+8h] [rbp-F0h]
  btCollisionObject *v32; // [rsp+10h] [rbp-E8h]
  __int128 v33; // [rsp+18h] [rbp-E0h] BYREF
  char v34; // [rsp+28h] [rbp-D0h]
  __int64 v35; // [rsp+30h] [rbp-C8h]
  __int16 v36; // [rsp+38h] [rbp-C0h]
  char v37; // [rsp+3Ah] [rbp-BEh]
  int v38; // [rsp+3Ch] [rbp-BCh]
  char v39; // [rsp+40h] [rbp-B8h]
  int v40; // [rsp+44h] [rbp-B4h]
  _QWORD v41[6]; // [rsp+48h] [rbp-B0h] BYREF
  __int128 v42; // [rsp+78h] [rbp-80h]
  _QWORD v43[6]; // [rsp+88h] [rbp-70h] BYREF
  __int128 v44; // [rsp+B8h] [rbp-40h]

  v7 = colObj0;
  v10 = algorithm;
  m_collisionShape = colObj0->m_collisionShape;
  p_m_worldTransform = &colObj0->m_worldTransform;
  v43[0] = 0;
  v43[1] = m_collisionShape;
  v43[2] = colObj0;
  v43[3] = 0;
  v43[4] = &colObj0->m_worldTransform;
  v43[5] = -1;
  v44 = 0;
  v13 = colObj1->m_collisionShape;
  v41[0] = 0;
  v41[1] = v13;
  v41[2] = colObj1;
  v41[3] = 0;
  v41[4] = &colObj1->m_worldTransform;
  v41[5] = -1;
  v42 = 0;
  if ( !*algorithm )
    *algorithm = (btCollisionAlgorithm *)(*(__int64 (__fastcall **)(_QWORD, _QWORD *, _QWORD *, _QWORD))(**((_QWORD **)world + 26) + 16LL))(
                                           *((_QWORD *)world + 26),
                                           v43,
                                           v41,
                                           0);
  resultOut->m_body0Wrap = (const btCollisionObjectWrapper *)v43;
  resultOut->m_body1Wrap = (const btCollisionObjectWrapper *)v41;
  resultOut->m_manifoldPtr = 0;
  v33 = xmmword_3E5FB0;
  v34 = 1;
  v35 = 0;
  v36 = 256;
  v37 = 1;
  v38 = 1025758986;
  v39 = 0;
  v40 = 0;
  if ( stru_2AAF230.value )
  {
    std::mutex::lock(&stru_2AAF490);
    v32 = v7;
    if ( (_DWORD)qword_2AAF474 )
    {
      v14 = (_DWORD *)*((_QWORD *)qword_2AAF480 + (int)qword_2AAF474 - 1);
      LODWORD(qword_2AAF474) = qword_2AAF474 - 1;
    }
    else
    {
      v16 = btAlignedAllocInternal(0x168u, 16);
      v16[77] = 953267991;
      *((_BYTE *)v16 + 332) &= 0xF0u;
      v14 = v16;
    }
    std::mutex::unlock(&stru_2AAF490);
    v31 = v14;
    (*((void (__fastcall **)(btCollisionAlgorithm *, _QWORD *, _QWORD *, __int128 *, btManifoldResult *, _DWORD *))(*v10)->_vptr$btCollisionAlgorithm
     + 2))(
      *v10,
      v43,
      v41,
      &v33,
      resultOut,
      v14);
    m_manifoldPtr = resultOut->m_manifoldPtr;
    if ( m_manifoldPtr && m_manifoldPtr->m_cachedPoints && !inContact )
      (*((void (__fastcall **)(btCollisionAlgorithm *, _QWORD *, _QWORD *, __int128 *, btManifoldResult *, _DWORD *))(*v10)->_vptr$btCollisionAlgorithm
       + 2))(
        *v10,
        v43,
        v41,
        &v33,
        resultOut,
        v14);
    std::mutex::lock(&stru_2AAF490);
    v18 = qword_2AAF474;
    v7 = v32;
    if ( (_DWORD)qword_2AAF474 != HIDWORD(qword_2AAF474) )
      goto LABEL_36;
    v19 = 1;
    if ( (_DWORD)qword_2AAF474 )
      v19 = 2 * qword_2AAF474;
    if ( (int)qword_2AAF474 >= v19 )
      goto LABEL_36;
    v30 = v10;
    if ( v19 )
    {
      v20 = btAlignedAllocInternal(8LL * v19, 16);
      v18 = qword_2AAF474;
      if ( (int)qword_2AAF474 <= 0 )
        goto LABEL_31;
    }
    else
    {
      v20 = 0;
      if ( (int)qword_2AAF474 <= 0 )
      {
LABEL_31:
        if ( qword_2AAF480 )
        {
          if ( byte_2AAF488 )
          {
            btAlignedFreeInternal(qword_2AAF480);
            v18 = qword_2AAF474;
          }
          qword_2AAF480 = 0;
        }
        byte_2AAF488 = 1;
        qword_2AAF480 = v20;
        HIDWORD(qword_2AAF474) = v19;
        v10 = v30;
LABEL_36:
        *((_QWORD *)qword_2AAF480 + v18) = v31;
        LODWORD(qword_2AAF474) = v18 + 1;
        std::mutex::unlock(&stru_2AAF490);
        goto LABEL_37;
      }
    }
    v21 = v18 & 3;
    if ( (unsigned __int64)(v18 - 1LL) >= 3 )
    {
      v22 = 0;
      do
      {
        *((_QWORD *)v20 + v22) = *((_QWORD *)qword_2AAF480 + v22);
        *((_QWORD *)v20 + v22 + 1) = *((_QWORD *)qword_2AAF480 + v22 + 1);
        *((_QWORD *)v20 + v22 + 2) = *((_QWORD *)qword_2AAF480 + v22 + 2);
        *((_QWORD *)v20 + v22 + 3) = *((_QWORD *)qword_2AAF480 + v22 + 3);
        v22 += 4;
      }
      while ( v18 - v21 != v22 );
      if ( (v18 & 3) == 0 )
        goto LABEL_31;
    }
    else
    {
      v22 = 0;
      if ( (v18 & 3) == 0 )
        goto LABEL_31;
    }
    v23 = -v21;
    do
    {
      *((_QWORD *)v20 + v22) = *((_QWORD *)qword_2AAF480 + v22);
      ++v22;
      ++v23;
    }
    while ( v23 );
    goto LABEL_31;
  }
  (*((void (__fastcall **)(btCollisionAlgorithm *, _QWORD *, _QWORD *, __int128 *, btManifoldResult *))(*v10)->_vptr$btCollisionAlgorithm
   + 3))(
    *v10,
    v43,
    v41,
    &v33,
    resultOut);
  v15 = resultOut->m_manifoldPtr;
  if ( v15 && v15->m_cachedPoints && !inContact )
    (*((void (__fastcall **)(btCollisionAlgorithm *, _QWORD *, _QWORD *, __int128 *, btManifoldResult *))(*v10)->_vptr$btCollisionAlgorithm
     + 3))(
      *v10,
      v43,
      v41,
      &v33,
      resultOut);
LABEL_37:
  v24 = v10;
  m_size = manifoldArray->m_size;
  if ( m_size < 0 )
  {
    if ( manifoldArray->m_capacity < 0 )
    {
      m_data = manifoldArray->m_data;
      if ( m_data )
      {
        if ( manifoldArray->m_ownsMemory )
          btAlignedFreeInternal(m_data);
        manifoldArray->m_data = 0;
      }
      manifoldArray->m_ownsMemory = 1;
      manifoldArray->m_data = 0;
      manifoldArray->m_capacity = 0;
    }
    v27 = m_size;
    if ( (-(int)m_size & 7LL) != 0 )
    {
      v28 = -(-(int)m_size & 7LL);
      v27 = m_size;
      do
      {
        manifoldArray->m_data[v27++] = 0;
        ++v28;
      }
      while ( v28 );
    }
    if ( (unsigned int)m_size <= 0xFFFFFFF8 )
    {
      do
      {
        manifoldArray->m_data[v27] = 0;
        manifoldArray->m_data[v27 + 1] = 0;
        manifoldArray->m_data[v27 + 2] = 0;
        manifoldArray->m_data[v27 + 3] = 0;
        manifoldArray->m_data[v27 + 4] = 0;
        manifoldArray->m_data[v27 + 5] = 0;
        manifoldArray->m_data[v27 + 6] = 0;
        manifoldArray->m_data[v27 + 7] = 0;
        v27 += 8;
      }
      while ( v27 );
    }
  }
  manifoldArray->m_size = 0;
  (*((void (__fastcall **)(btCollisionAlgorithm *, btManifoldArray *))(*v24)->_vptr$btCollisionAlgorithm + 5))(
    *v24,
    manifoldArray);
  if ( (v7->m_collisionShape->m_shapeType == 25 || colObj1->m_collisionShape->m_shapeType == 25)
    && manifoldArray->m_size > 0 )
  {
    v29 = 0;
    do
      btPersistentManifold::refreshContactPoints(
        manifoldArray->m_data[v29++],
        p_m_worldTransform,
        &colObj1->m_worldTransform);
    while ( v29 < manifoldArray->m_size );
  }
}


// Address: 0x1de98d0 | Name: _ZN3RBX9Collision24BulletCollisionInterface24matchCollisionConnectorsEPNS_5WorldER20btAlignedObjectArrayIP20btPersistentManifoldERNS_10FixedArrayIPNS0_24BulletCollisionConnectorELm4EEERNSt3__16vectorImNSE_9allocatorImEEEE
void __fastcall RBX::Collision::BulletCollisionInterface::matchCollisionConnectors(
        RBX::World *world,
        btManifoldArray *manifoldArray,
        RBX::BulletCollisionConnectorArray *collisionConnectors,
        std::vector<unsigned long> *reusableConnectorIndex)
{
  size_t v6; // rcx
  RBX::Collision::BulletCollisionConnector *v7; // rax
  size_t num; // rax
  __int64 m_size; // r9
  btPersistentManifold **m_data; // r8
  __int64 i; // rsi
  btPersistentManifold *v12; // rdi
  __int64 m_cachedPoints; // rbp
  float *p_m_userPersistentData; // rdi
  __int64 j; // rdx
  __int64 v16; // rcx
  size_t v17; // r12
  RBX::Kernel *v18; // r13
  RBX::Collision::BulletCollisionConnector *v19; // rbp
  size_t *v20; // rax
  size_t v21; // rax
  unsigned __int64 __x[7]; // [rsp+10h] [rbp-38h] BYREF

  if ( collisionConnectors->num )
  {
    v6 = 0;
    do
    {
      v7 = collisionConnectors->data.elems[v6];
      *(_QWORD *)&v7->bulletManifoldIndex = -1;
      *(_QWORD *)&v7->normal.x = 0;
      v7->normal.z = 0.0;
      ++v6;
      num = collisionConnectors->num;
    }
    while ( v6 < num );
  }
  else
  {
    num = 0;
  }
  m_size = manifoldArray->m_size;
  if ( m_size > 0 )
  {
    m_data = manifoldArray->m_data;
    for ( i = 0; i < m_size; ++i )
    {
      v12 = m_data[i];
      m_cachedPoints = v12->m_cachedPoints;
      if ( m_cachedPoints > 0 )
      {
        p_m_userPersistentData = (float *)&v12->m_pointCache[0].m_userPersistentData;
        for ( j = 0; j < m_cachedPoints; ++j )
        {
          if ( *(p_m_userPersistentData - 8) >= 0.0 )
          {
            *(_QWORD *)p_m_userPersistentData = 0;
          }
          else
          {
            v16 = *(_QWORD *)p_m_userPersistentData;
            if ( *(_QWORD *)p_m_userPersistentData )
            {
              *(_DWORD *)(v16 + 60) = i;
              *(_DWORD *)(v16 + 64) = j;
            }
          }
          p_m_userPersistentData += 48;
        }
      }
    }
  }
  if ( num )
  {
    v17 = 0;
    v18 = 0;
    do
    {
      while ( 1 )
      {
        v19 = collisionConnectors->data.elems[v17];
        if ( v19->bulletManifoldIndex != -1 || v19->bulletPointCacheIndex != -1 )
          goto LABEL_20;
        if ( v19->collisionIndex >= 0 )
          break;
LABEL_25:
        if ( stru_2AAF230.value )
          goto LABEL_26;
LABEL_32:
        v21 = collisionConnectors->num;
        collisionConnectors->data.elems[v17] = collisionConnectors->data.elems[v21 - 1];
        collisionConnectors->num = v21 - 1;
        operator delete(v19);
        if ( v17 >= collisionConnectors->num )
          return;
      }
      if ( stru_2AAF230.value )
      {
        *(_QWORD *)&v19->normal.x = 0;
        v19->normal.z = 0.0;
        goto LABEL_25;
      }
      if ( !v18 )
        v18 = (RBX::Kernel *)*((_QWORD *)world + 115);
      RBX::Kernel::removeCollision(v18, collisionConnectors->data.elems[v17]);
      if ( !stru_2AAF230.value )
        goto LABEL_32;
LABEL_26:
      if ( v19->collisionIndex < 0 )
        goto LABEL_32;
      __x[0] = v17;
      v20 = (size_t *)*((_QWORD *)reusableConnectorIndex + 1);
      if ( (unsigned __int64)v20 >= *((_QWORD *)reusableConnectorIndex + 2) )
      {
        std::vector<unsigned long>::__push_back_slow_path<unsigned long>(reusableConnectorIndex, __x);
      }
      else
      {
        *v20 = v17;
        *((_QWORD *)reusableConnectorIndex + 1) = v20 + 1;
      }
LABEL_20:
      ++v17;
    }
    while ( v17 < collisionConnectors->num );
  }
}


// Address: 0x1de9a90 | Name: _ZN3RBX9Collision24BulletCollisionInterface25createCollisionConnectorsER20btAlignedObjectArrayIP20btPersistentManifoldERNS_10FixedArrayIPNS0_24BulletCollisionConnectorELm4EEEPNS_9PrimitiveESD_RNSt3__16vectorImNSE_9allocatorImEEEE
void __fastcall RBX::Collision::BulletCollisionInterface::createCollisionConnectors(
        btManifoldArray *manifoldArray,
        RBX::BulletCollisionConnectorArray *collisionConnectors,
        RBX::Primitive *prim0,
        RBX::Primitive *prim1,
        std::vector<unsigned long> *reusableConnectorIndex)
{
  std::vector<unsigned long> *v5; // rbx
  __int64 v7; // rcx
  btPersistentManifold *v8; // r14
  float *p_m_userPersistentData; // r15
  __int64 v10; // r12
  __int64 v11; // rax
  char *v12; // rbp
  __int128 v13; // xmm0
  __int64 v14; // rax
  size_t num; // rax
  RBX::Collision::BulletCollisionConnector *v16; // rbp
  RBX::BulletCollisionConnectorArray *v17; // rbx
  bool canThrottle; // r13
  __int64 v19; // rax
  __int64 v22; // [rsp+10h] [rbp-A8h]
  int collisionIndex; // [rsp+1Ch] [rbp-9Ch]
  btManifoldArray *v24; // [rsp+20h] [rbp-98h]
  RBX::CollisionParams v26; // [rsp+30h] [rbp-88h] BYREF
  RBX::CollisionParams v27; // [rsp+50h] [rbp-68h] BYREF
  RBX::CollisionParams v28; // [rsp+70h] [rbp-48h] BYREF

  if ( manifoldArray->m_size > 0 )
  {
    v5 = reusableConnectorIndex;
    v7 = 0;
    v24 = manifoldArray;
    while ( 1 )
    {
      v8 = manifoldArray->m_data[v7];
      if ( v8->m_cachedPoints > 0 )
        break;
LABEL_16:
      ++v7;
      manifoldArray = v24;
      if ( v7 >= v24->m_size )
        return;
    }
    p_m_userPersistentData = (float *)&v8->m_pointCache[0].m_userPersistentData;
    v10 = 0;
    v22 = v7;
    while ( 1 )
    {
      if ( *(_QWORD *)p_m_userPersistentData || *(p_m_userPersistentData - 8) >= 0.0 )
        goto LABEL_15;
      if ( stru_2AAF230.value )
      {
        v11 = *((_QWORD *)v5 + 1);
        if ( v11 != *(_QWORD *)v5 )
        {
          v16 = collisionConnectors->data.elems[*(_QWORD *)(v11 - 8)];
          collisionIndex = v16->collisionIndex;
          v17 = collisionConnectors;
          canThrottle = v16->canThrottle;
          RBX::Collision::Contact::computeCollisionParams(&v28, prim0, prim1);
          v7 = v22;
          v19 = *(_QWORD *)&v28.friction;
          *(_OWORD *)&v16->bodyA = *(_OWORD *)&v28.b0;
          *(_QWORD *)&v16->friction = v19;
          *(_OWORD *)&v16->normal.x = 0;
          *(_OWORD *)&v16->contactPoint.x = 0;
          v16->canThrottle = canThrottle;
          collisionConnectors = v17;
          v16->collisionIndex = collisionIndex;
          v5 = reusableConnectorIndex;
          v16->bulletManifoldIndex = v22;
          v16->bulletPointCacheIndex = v10;
          *(_QWORD *)p_m_userPersistentData = v16;
          *((_QWORD *)reusableConnectorIndex + 1) -= 8LL;
          goto LABEL_15;
        }
        if ( collisionConnectors->num <= 3 )
        {
          v12 = (char *)operator new(0x48u);
          RBX::Collision::Contact::computeCollisionParams(&v27, prim0, prim1);
          v13 = *(_OWORD *)&v27.b0;
          v14 = *(_QWORD *)&v27.friction;
LABEL_13:
          *(_OWORD *)v12 = v13;
          *((_QWORD *)v12 + 2) = v14;
          *(_OWORD *)(v12 + 36) = 0;
          *(_OWORD *)(v12 + 24) = 0;
          *((_DWORD *)v12 + 13) = -1;
          v12[56] = 1;
          v7 = v22;
          *((_DWORD *)v12 + 15) = v22;
          *((_DWORD *)v12 + 16) = v10;
          num = collisionConnectors->num;
          collisionConnectors->data.elems[num] = (RBX::Collision::BulletCollisionConnector *)v12;
          collisionConnectors->num = num + 1;
          *(_QWORD *)p_m_userPersistentData = v12;
        }
      }
      else if ( collisionConnectors->num <= 3 )
      {
        v12 = (char *)operator new(0x48u);
        RBX::Collision::Contact::computeCollisionParams(&v26, prim0, prim1);
        v13 = *(_OWORD *)&v26.b0;
        v14 = *(_QWORD *)&v26.friction;
        goto LABEL_13;
      }
LABEL_15:
      ++v10;
      p_m_userPersistentData += 48;
      if ( v10 >= v8->m_cachedPoints )
        goto LABEL_16;
    }
  }
}


// Address: 0x1de9cc0 | Name: _ZN3RBX9Collision24BulletCollisionInterface19updateContactPointsER20btAlignedObjectArrayIP20btPersistentManifoldERNS_10FixedArrayIPNS0_24BulletCollisionConnectorELm4EEEP17btCollisionObject
float __fastcall RBX::Collision::BulletCollisionInterface::updateContactPoints(
        btManifoldArray *manifoldAraay,
        RBX::BulletCollisionConnectorArray *collisionConnectors,
        btCollisionObject *colObj0)
{
  float result; // xmm0_4
  __int64 v7; // rbx
  __m128 v8; // xmm3
  RBX::Collision::BulletCollisionConnector *v9; // rcx
  __int64 bulletManifoldIndex; // r8
  int bulletPointCacheIndex; // edx
  btPersistentManifold *v12; // rax
  __int64 v13; // rsi
  __m128 v14; // xmm1
  float v15; // xmm2_4
  unsigned int m_distance1_low; // edi
  __int64 v17; // r9
  float v18; // eax
  __int64 v19; // r9
  float v20; // eax
  __m128i v21; // xmm1
  btPersistentManifold *v22; // rdi

  if ( collisionConnectors->num )
  {
    result = -3.4028235e38;
    v7 = 0;
    v8 = *(__m128 *)&stru_3E4970.x;
    while ( 1 )
    {
      v9 = collisionConnectors->data.elems[v7];
      bulletManifoldIndex = v9->bulletManifoldIndex;
      if ( !stru_2AAF230.value )
        break;
      if ( (_DWORD)bulletManifoldIndex != -1 )
      {
        bulletPointCacheIndex = v9->bulletPointCacheIndex;
        if ( bulletPointCacheIndex != -1 )
          goto LABEL_8;
      }
LABEL_15:
      if ( ++v7 >= collisionConnectors->num )
        return result;
    }
    bulletPointCacheIndex = v9->bulletPointCacheIndex;
LABEL_8:
    v12 = manifoldAraay->m_data[bulletManifoldIndex];
    v13 = bulletPointCacheIndex;
    v14 = (__m128)*(unsigned __int64 *)v12->m_pointCache[v13].m_normalWorldOnB.m_floats;
    v15 = v12->m_pointCache[v13].m_normalWorldOnB.m_floats[2];
    m_distance1_low = LODWORD(v12->m_pointCache[v13].m_distance1);
    if ( v12->m_body0 == colObj0 )
    {
      v19 = *(_QWORD *)v12->m_pointCache[v13].m_positionWorldOnA.m_floats;
      v20 = v12->m_pointCache[v13].m_positionWorldOnA.m_floats[2];
      LODWORD(v15) ^= v8.m128_i32[0];
      *(_QWORD *)&v9->contactPoint.x = v19;
      v9->contactPoint.z = v20;
      _mm_storel_ps((double *)&v9->normal.x, _mm_xor_ps(v14, v8));
    }
    else
    {
      v17 = *(_QWORD *)v12->m_pointCache[v13].m_positionWorldOnB.m_floats;
      v18 = v12->m_pointCache[v13].m_positionWorldOnB.m_floats[2];
      *(_QWORD *)&v9->contactPoint.x = v17;
      v9->contactPoint.z = v18;
      LODWORD(v9->normal.x) = v14.m128_i32[0];
      LODWORD(v9->normal.y) = _mm_shuffle_ps(v14, v14, 229).m128_u32[0];
    }
    v9->normal.z = v15;
    LODWORD(v9->depth) = m_distance1_low;
    v21 = _mm_cvtsi32_si128(m_distance1_low);
    if ( *(float *)v21.m128i_i32 >= -0.0 )
    {
      *(_QWORD *)&v9->normal.x = 0;
      v9->normal.z = 0.0;
      if ( ((unsigned int)bulletManifoldIndex & bulletPointCacheIndex) != 0xFFFFFFFF )
      {
        v22 = manifoldAraay->m_data[bulletManifoldIndex];
        btPersistentManifold::clearUserCache(v22, &v22->m_pointCache[v13]);
        v8 = *(__m128 *)&stru_3E4970.x;
      }
    }
    else
    {
      result = fmaxf(*(float *)_mm_xor_si128(v21, (__m128i)v8).m128i_i32, result);
    }
    goto LABEL_15;
  }
  return -3.4028235e38;
}


// Address: 0x1de9e50 | Name: _ZN3RBX9Collision24BulletCollisionInterface34updateCollisionFromBulletAlgorithmEPNS0_24BulletCollisionConnectorER20btAlignedObjectArrayIP20btPersistentManifoldEP17btCollisionObject
void __fastcall RBX::Collision::BulletCollisionInterface::updateCollisionFromBulletAlgorithm(
        RBX::Collision::BulletCollisionConnector *conn,
        btManifoldArray *manifoldArray,
        btCollisionObject *colObj0)
{
  btPersistentManifold *v3; // rcx
  __int64 bulletPointCacheIndex; // rsi
  __m128 v5; // xmm1
  float v6; // xmm0_4
  float m_distance1; // eax
  __int64 v8; // rdx
  float v9; // ecx
  __int64 v10; // rdx
  float v11; // ecx

  v3 = manifoldArray->m_data[conn->bulletManifoldIndex];
  bulletPointCacheIndex = conn->bulletPointCacheIndex;
  v5 = (__m128)*(unsigned __int64 *)v3->m_pointCache[bulletPointCacheIndex].m_normalWorldOnB.m_floats;
  v6 = v3->m_pointCache[bulletPointCacheIndex].m_normalWorldOnB.m_floats[2];
  m_distance1 = v3->m_pointCache[bulletPointCacheIndex].m_distance1;
  if ( v3->m_body0 == colObj0 )
  {
    v10 = *(_QWORD *)v3->m_pointCache[bulletPointCacheIndex].m_positionWorldOnA.m_floats;
    v11 = v3->m_pointCache[bulletPointCacheIndex].m_positionWorldOnA.m_floats[2];
    v6 = -v6;
    *(_QWORD *)&conn->contactPoint.x = v10;
    conn->contactPoint.z = v11;
    _mm_storel_ps((double *)&conn->normal.x, _mm_xor_ps(v5, *(__m128 *)&stru_3E4970.x));
  }
  else
  {
    v8 = *(_QWORD *)v3->m_pointCache[bulletPointCacheIndex].m_positionWorldOnB.m_floats;
    v9 = v3->m_pointCache[bulletPointCacheIndex].m_positionWorldOnB.m_floats[2];
    *(_QWORD *)&conn->contactPoint.x = v8;
    conn->contactPoint.z = v9;
    LODWORD(conn->normal.x) = v5.m128_i32[0];
    LODWORD(conn->normal.y) = _mm_shuffle_ps(v5, v5, 229).m128_u32[0];
  }
  conn->normal.z = v6;
  conn->depth = m_distance1;
}


// Address: 0x1de9f60 | Name: _ZN3RBX9Collision24BulletCollisionInterface15deleteAlgorithmEPNS_5WorldEP20btCollisionAlgorithm
void __fastcall RBX::Collision::BulletCollisionInterface::deleteAlgorithm(
        RBX::World *world,
        btCollisionAlgorithm *algorithm)
{
  if ( algorithm )
  {
    ((void (__fastcall *)(btCollisionAlgorithm *))*algorithm->_vptr$btCollisionAlgorithm)(algorithm);
    (*(void (__fastcall **)(_QWORD, btCollisionAlgorithm *))(**((_QWORD **)world + 26) + 128LL))(
      *((_QWORD *)world + 26),
      algorithm);
  }
}


// Address: 0x1de9fa0 | Name: _ZN3RBX9Collision24BulletCollisionInterface10clearCacheER20btAlignedObjectArrayIP20btPersistentManifoldE
void __fastcall RBX::Collision::BulletCollisionInterface::clearCache(btManifoldArray *manifoldArray)
{
  int m_size; // eax
  __int64 i; // r12
  btPersistentManifold *v3; // r15
  btManifoldPoint *m_pointCache; // r13
  __int64 v5; // rbx

  m_size = manifoldArray->m_size;
  if ( m_size > 0 )
  {
    for ( i = 0; i < m_size; ++i )
    {
      v3 = manifoldArray->m_data[i];
      if ( v3->m_cachedPoints > 0 )
      {
        m_pointCache = v3->m_pointCache;
        v5 = 0;
        do
        {
          btPersistentManifold::clearUserCache(v3, m_pointCache);
          ++v5;
          ++m_pointCache;
        }
        while ( v5 < v3->m_cachedPoints );
        m_size = manifoldArray->m_size;
      }
      v3->m_cachedPoints = 0;
    }
  }
}


// Address: 0x1dea040 | Name: _ZN3RBX9Collision13BulletContact21getCollisionConnectorEj
RBX::CollisionConnector *__fastcall RBX::Collision::BulletContact::getCollisionConnector(
        RBX::Collision::BulletContact *this,
        unsigned int i)
{
  return this->collisionConnectors.data.elems[i];
}


// Address: 0x1dea050 | Name: _ZN3RBX9Collision13BulletContact24deleteCollisionConnectorEj
void __fastcall RBX::Collision::BulletContact::deleteCollisionConnector(
        RBX::Collision::BulletContact *this,
        unsigned int i)
{
  RBX::Collision::BulletCollisionConnector *v3; // rdi
  __int64 bulletManifoldIndex; // rax
  __int64 bulletPointCacheIndex; // rcx
  btPersistentManifold *v6; // rdi
  size_t num; // rax

  if ( this->collisionConnectors.num > i )
  {
    v3 = this->collisionConnectors.data.elems[i];
    bulletManifoldIndex = v3->bulletManifoldIndex;
    bulletPointCacheIndex = v3->bulletPointCacheIndex;
    if ( ((unsigned int)bulletManifoldIndex & v3->bulletPointCacheIndex) != 0xFFFFFFFF )
    {
      v6 = this->manifoldArray.m_data[bulletManifoldIndex];
      btPersistentManifold::clearUserCache(v6, &v6->m_pointCache[bulletPointCacheIndex]);
      v3 = this->collisionConnectors.data.elems[i];
    }
    if ( v3 )
      operator delete(v3);
    num = this->collisionConnectors.num;
    this->collisionConnectors.data.elems[i] = (RBX::Collision::BulletCollisionConnector *)*((_QWORD *)&this->contactManagerTransitionIndex
                                                                                          + num);
    this->collisionConnectors.num = num - 1;
  }
}


// Address: 0x1dea0c0 | Name: _ZN3RBX9Collision13BulletContact18computeIsCollidingEf
__int64 __fastcall RBX::Collision::BulletContact::computeIsColliding(
        RBX::Collision::BulletContact *this,
        float a2,
        float overlapIgnored)
{
  RBX::Primitive *prim0; // r14
  RBX::Primitive *prim1; // r15
  const RBX::Extents *FastFuzzyExtents; // rbx
  const RBX::Extents *v6; // rax
  char *v7; // rax
  RBX::World *world; // r13
  bool v9; // al
  btManifoldArray *p_manifoldArray; // r12
  btCollisionObject *v11; // r9
  __int64 v12; // rbx
  bool v14; // al
  void *ptr[2]; // [rsp+10h] [rbp-98h] BYREF
  char *v16; // [rsp+20h] [rbp-88h]
  btVector3 obj1Scale; // [rsp+28h] [rbp-80h] BYREF
  btVector3 obj0Scale; // [rsp+38h] [rbp-70h] BYREF
  btManifoldResult resultOut; // [rsp+48h] [rbp-60h] BYREF

  prim0 = this->prim0;
  prim1 = this->prim1;
  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(prim0);
  v6 = RBX::Primitive::getFastFuzzyExtents(prim1);
  if ( FastFuzzyExtents->low.x > v6->high.x
    || FastFuzzyExtents->low.y > v6->high.y
    || FastFuzzyExtents->low.z > v6->high.z
    || v6->low.y > FastFuzzyExtents->high.y
    || v6->low.x > FastFuzzyExtents->high.x
    || v6->low.z > FastFuzzyExtents->high.z )
  {
    LODWORD(v12) = 0;
  }
  else
  {
    RBX::Primitive::updateBulletCollisionObject(prim0);
    RBX::Primitive::updateBulletCollisionObject(prim1);
    v7 = (char *)operator new(0x20u);
    *(__m128i *)ptr = _mm_shuffle_epi32((__m128i)(unsigned __int64)v7, 68);
    v16 = v7 + 32;
    resultOut._vptr$Result = (int (**)(void))&off_299AC68;
    world = this->world;
    if ( stru_2AAF458.value )
    {
      v9 = RBX::Collision::Contact::getInContact(this);
      p_manifoldArray = &this->manifoldArray;
      v11 = *(btCollisionObject **)(*((_QWORD *)prim0 + 18) + 24LL);
      v12 = *(_QWORD *)(*((_QWORD *)prim1 + 18) + 24LL);
      obj0Scale.m_floats[0] = this->aScale.x;
      obj0Scale.m_floats[1] = this->aScale.y;
      obj0Scale.m_floats[2] = this->aScale.z;
      obj0Scale.m_floats[3] = 0.0;
      obj1Scale.m_floats[0] = this->bScale.x;
      obj1Scale.m_floats[1] = this->bScale.y;
      obj1Scale.m_floats[2] = this->bScale.z;
      obj1Scale.m_floats[3] = 0.0;
      RBX::Collision::BulletCollisionInterface::computeManifolds(
        world,
        v9,
        &this->algorithm,
        &this->manifoldArray,
        &resultOut,
        v11,
        (btCollisionObject *)v12,
        &obj0Scale,
        &obj1Scale,
        this->aBoxSet.bvh,
        this->bBoxSet.bvh);
    }
    else
    {
      v14 = RBX::Collision::Contact::getInContact(this);
      p_manifoldArray = &this->manifoldArray;
      v12 = *((_QWORD *)prim1 + 18);
      RBX::Collision::BulletCollisionInterface::computeManifolds(
        world,
        v14,
        &this->algorithm,
        &this->manifoldArray,
        &resultOut,
        *(btCollisionObject **)(*((_QWORD *)prim0 + 18) + 24LL),
        *(btCollisionObject **)(v12 + 24));
    }
    RBX::Collision::BulletCollisionInterface::matchCollisionConnectors(
      this->world,
      p_manifoldArray,
      &this->collisionConnectors,
      (std::vector<unsigned long> *)ptr);
    RBX::Collision::BulletCollisionInterface::createCollisionConnectors(
      p_manifoldArray,
      &this->collisionConnectors,
      prim0,
      prim1,
      (std::vector<unsigned long> *)ptr);
    LOBYTE(v12) = RBX::Collision::BulletCollisionInterface::updateContactPoints(
                    p_manifoldArray,
                    &this->collisionConnectors,
                    *(btCollisionObject **)(*((_QWORD *)prim0 + 18) + 24LL)) > a2;
    if ( ptr[0] )
    {
      ptr[1] = ptr[0];
      operator delete(ptr[0]);
    }
  }
  return (unsigned int)v12;
}


// Address: 0x1dea350 | Name: _ZN3RBX9Collision13BulletContactC2EPNS_5WorldEPNS_9PrimitiveES5_
void __fastcall RBX::Collision::BulletContact::BulletContact(
        RBX::Collision::BulletContact *this,
        RBX::World *world,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  __int64 v7; // rcx
  const btGImpactConvexDecompositionShape *v8; // rdi
  __int64 v9; // rcx
  const btGImpactConvexDecompositionShape *v10; // rdi
  btVector3 size; // [rsp+8h] [rbp-30h] BYREF

  RBX::Collision::Contact::Contact(this, p0, p1);
  this->_vptr$Contact = (int (**)(void))&off_299DB30;
  this->collisionConnectors.num = 0;
  this->world = world;
  this->algorithm = 0;
  this->manifoldArray.m_ownsMemory = 1;
  this->manifoldArray.m_data = 0;
  *(_QWORD *)&this->manifoldArray.m_size = 0;
  this->aBoxSet.key = -1;
  this->aBoxSet.bvh = 0;
  this->bBoxSet.key = -1;
  *(_OWORD *)&this->aScale.z = 0;
  *(_OWORD *)&this->bBoxSet.bvh = 0;
  if ( stru_2AAF458.value )
  {
    if ( RBX::Primitive::getGeometryType(p0) == GEOMETRY_TRI_MESH )
    {
      v7 = *((_QWORD *)p0 + 18);
      this->aScale = *(RBX::Vector3 *)(v7 + 84);
      v8 = **(const btGImpactConvexDecompositionShape ***)(v7 + 56);
      size.m_floats[0] = this->aScale.x;
      size.m_floats[1] = this->aScale.y;
      size.m_floats[2] = this->aScale.z;
      size.m_floats[3] = 0.0;
      this->aBoxSet = RBX::Collision::BulletCollisionBoxSetPool::requestBoxSet(v8, &size);
    }
    if ( RBX::Primitive::getGeometryType(p1) == GEOMETRY_TRI_MESH )
    {
      v9 = *((_QWORD *)p1 + 18);
      this->bScale.z = *(float *)(v9 + 92);
      *(_QWORD *)&this->bScale.x = *(_QWORD *)(v9 + 84);
      v10 = **(const btGImpactConvexDecompositionShape ***)(v9 + 56);
      size.m_floats[0] = this->bScale.x;
      size.m_floats[1] = this->bScale.y;
      size.m_floats[2] = this->bScale.z;
      size.m_floats[3] = 0.0;
      this->bBoxSet = RBX::Collision::BulletCollisionBoxSetPool::requestBoxSet(v10, &size);
    }
  }
}


// Address: 0x1dea520 | Name: _ZN3RBX9Collision13BulletContactD2Ev
void __fastcall RBX::Collision::BulletContact::~BulletContact(RBX::Collision::BulletContact *this)
{
  btCollisionAlgorithm *algorithm; // r14
  RBX::World *world; // r15
  btPersistentManifold **m_data; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299DB30;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
  algorithm = this->algorithm;
  if ( algorithm )
  {
    world = this->world;
    (*(void (__fastcall **)(btCollisionAlgorithm *))algorithm->_vptr$btCollisionAlgorithm)(this->algorithm);
    (*(void (__fastcall **)(_QWORD, btCollisionAlgorithm *))(**((_QWORD **)world + 26) + 128LL))(
      *((_QWORD *)world + 26),
      algorithm);
  }
  if ( stru_2AAF458.value )
  {
    if ( this->aBoxSet.bvh )
      RBX::Collision::BulletCollisionBoxSetPool::returnBoxSet(&this->aBoxSet);
    if ( this->bBoxSet.bvh )
      RBX::Collision::BulletCollisionBoxSetPool::returnBoxSet(&this->bBoxSet);
  }
  m_data = this->manifoldArray.m_data;
  if ( m_data )
  {
    if ( this->manifoldArray.m_ownsMemory )
      btAlignedFreeInternal(m_data);
    this->manifoldArray.m_data = 0;
  }
  this->manifoldArray.m_ownsMemory = 1;
  this->manifoldArray.m_data = 0;
  *(_QWORD *)&this->manifoldArray.m_size = 0;
}


// Address: 0x1dea5f0 | Name: _ZN3RBX9Collision13BulletContactD0Ev
void __fastcall RBX::Collision::BulletContact::~BulletContact(RBX::Collision::BulletContact *this)
{
  RBX::Collision::BulletContact::~BulletContact(this);
  operator delete(this);
}


// Address: 0x1dea610 | Name: _ZN3RBX9Collision13BulletContact22invalidateContactCacheEv
void __fastcall RBX::Collision::BulletContact::invalidateContactCache(RBX::Collision::BulletContact *this)
{
  int m_size; // eax
  __int64 i; // r12
  btPersistentManifold *v3; // r15
  btManifoldPoint *m_pointCache; // r13
  __int64 v5; // rbx

  m_size = this->manifoldArray.m_size;
  if ( m_size > 0 )
  {
    for ( i = 0; i < m_size; ++i )
    {
      v3 = this->manifoldArray.m_data[i];
      if ( v3->m_cachedPoints > 0 )
      {
        m_pointCache = v3->m_pointCache;
        v5 = 0;
        do
        {
          btPersistentManifold::clearUserCache(v3, m_pointCache);
          ++v5;
          ++m_pointCache;
        }
        while ( v5 < v3->m_cachedPoints );
        m_size = this->manifoldArray.m_size;
      }
      v3->m_cachedPoints = 0;
    }
  }
}


// Address: 0x1deadc0 | Name: _GLOBAL__sub_I_BulletContact.cpp
void __cdecl GLOBAL__sub_I_BulletContact_cpp()
{
  const boost::unordered::detail::false_type *v0; // rax
  __int64 v1; // rcx
  const boost::unordered::detail::false_type *v2; // rdx
  __int64 v3; // rsi
  size_t *v4; // rdx

  qword_2AAF440 = (__int64)boost::system::generic_category();
  qword_2AAF448 = (__int64)boost::system::generic_category();
  qword_2AAF450 = (__int64)boost::system::system_category();
  stru_2AAF458.value = 0;
  stru_2AAF458.name = "EnableScaleIndependentBulletCollision5";
  dword_2AAF468 = FLog::RegisterFlag(
                    "EnableScaleIndependentBulletCollision5",
                    &stru_2AAF458,
                    FastVarType::FASTVARTYPE_STATIC);
  byte_2AAF488 = 1;
  qword_2AAF480 = 0;
  qword_2AAF474 = 0;
  __cxa_atexit(
    (void (*)(void *))btAlignedObjectArray<btVoronoiSimplexSolver *>::~btAlignedObjectArray,
    &unk_2AAF470,
    &dso_handle);
  __cxa_atexit((void (*)(void *))&std::mutex::~mutex, &stru_2AAF490, &dso_handle);
  stru_2AAF4B8.current_ = 0;
  v0 = &stru_495510;
  v1 = 38;
  do
  {
    v2 = v0;
    v3 = v1 + ~(v1 / 2);
    if ( *(_QWORD *)&v0[8 * (v1 / 2)].gap0 >= 0xBu )
      v3 = v1 / 2;
    v0 += 8 * (v1 / 2) + 8;
    if ( *(_QWORD *)&v2[8 * (v1 / 2)].gap0 >= 0xBu )
      v0 = v2;
    v1 = v3;
  }
  while ( v3 );
  v4 = (size_t *)&v0[-8];
  if ( v0 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v4 = (size_t *)v0;
  stru_2AAF4B8.bucket_count_ = *v4;
  stru_2AAF4B8.size_ = 0;
  stru_2AAF4B8.mlf_ = 1.0;
  *(_OWORD *)&stru_2AAF4B8.max_load_ = 0;
  __cxa_atexit(
    (void (*)(void *))boost::unordered::unordered_map<unsigned long,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage,boost::hash<unsigned long>,std::equal_to<unsigned long>,std::allocator<std::pair<unsigned long const,RBX::Collision::BulletCollisionBoxSetPool::BoxSetStorage>>>::~unordered_map,
    &stru_2AAF4B8,
    &dso_handle);
  boost::mutex::mutex(&stru_2AAF4E8);
  __cxa_atexit((void (*)(void *))boost::mutex::~mutex, &stru_2AAF4E8, &dso_handle);
}


