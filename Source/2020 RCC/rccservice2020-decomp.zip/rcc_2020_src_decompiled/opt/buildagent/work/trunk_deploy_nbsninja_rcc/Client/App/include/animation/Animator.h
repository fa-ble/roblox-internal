// Address: 0x103de00 | Name: _ZNK3RBX8Animator12askSetParentEPKNS_8InstanceE
bool __fastcall RBX::Animator::askSetParent(const RBX::Animator *this, const RBX::Instance *instance)
{
  return 1;
}


