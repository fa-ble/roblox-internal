// Address: 0x10edf50 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN6SeatedE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Seated *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A09010;
  if ( !qword_2A09010 )
  {
    result = RBX::Name::declare("Seated");
    qword_2A09010 = result;
  }
  return result;
}


// Address: 0x10edf80 | Name: _ZNK3RBX5HUMAN6Seated7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Seated::getName(const RBX::HUMAN::Seated *this)
{
  const RBX::Name *result; // rax

  result = qword_2A09010;
  if ( !qword_2A09010 )
  {
    result = RBX::Name::declare("Seated");
    qword_2A09010 = result;
  }
  return result;
}


// Address: 0x10edfb0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN16PlatformStandingE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::PlatformStanding *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A09018;
  if ( !qword_2A09018 )
  {
    result = RBX::Name::declare("PlatformStanding");
    qword_2A09018 = result;
  }
  return result;
}


// Address: 0x10edfe0 | Name: _ZNK3RBX5HUMAN16PlatformStanding7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::PlatformStanding::getName(const RBX::HUMAN::PlatformStanding *this)
{
  const RBX::Name *result; // rax

  result = qword_2A09018;
  if ( !qword_2A09018 )
  {
    result = RBX::Name::declare("PlatformStanding");
    qword_2A09018 = result;
  }
  return result;
}


// Address: 0x10ee010 | Name: _ZN3RBX5HUMAN6SeatedC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Seated::Seated(
        RBX::HUMAN::Seated *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_2896130;
  RBX::HUMAN::HumanoidState::setCanThrottleState(this, 1);
}


// Address: 0x10ee050 | Name: _ZN3RBX5HUMAN6SeatedD2Ev
void __fastcall RBX::HUMAN::Seated::~Seated(RBX::HUMAN::Seated *this)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Humanoid *v2; // rax
  const RBX::Humanoid *v3; // rax

  *(_QWORD *)this = &off_2896130;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RBX::Humanoid::setSeatPart(HumanoidConst, 0);
  v2 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RBX::Humanoid::setSit(v2, 0);
  v3 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  rbx::signal<void ()(void)>::operator()((rbx::signal<void ()> *)v3 + 343);
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
}


// Address: 0x10ee0c0 | Name: _ZN3RBX5HUMAN6SeatedD0Ev
void __fastcall RBX::HUMAN::Seated::~Seated(RBX::HUMAN::Seated *this)
{
  RBX::HUMAN::Seated::~Seated(this);
  operator delete(this);
}


// Address: 0x10ee0e0 | Name: _ZN3RBX5HUMAN16PlatformStandingC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::PlatformStanding::PlatformStanding(
        RBX::HUMAN::PlatformStanding *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_28961C8;
  RBX::HUMAN::HumanoidState::setCanThrottleState(this, 1);
}


// Address: 0x10ee120 | Name: _ZN3RBX5HUMAN16PlatformStandingD2Ev
void __fastcall RBX::HUMAN::PlatformStanding::~PlatformStanding(RBX::HUMAN::PlatformStanding *this)
{
  RBX::Humanoid *HumanoidConst; // rax
  const RBX::Humanoid *v2; // rax

  *(_QWORD *)this = &off_28961C8;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RBX::Humanoid::setPlatformStanding(HumanoidConst, 0);
  v2 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  rbx::signal<void ()(void)>::operator()((rbx::signal<void ()> *)v2 + 344);
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
}


// Address: 0x10ee180 | Name: _ZN3RBX5HUMAN16PlatformStandingD0Ev
void __fastcall RBX::HUMAN::PlatformStanding::~PlatformStanding(RBX::HUMAN::PlatformStanding *this)
{
  RBX::HUMAN::PlatformStanding::~PlatformStanding(this);
  operator delete(this);
}


// Address: 0x10ee240 | Name: _GLOBAL__sub_I_Seated.cpp
void __cdecl GLOBAL__sub_I_Seated_cpp()
{
  qword_2A08FF8 = (__int64)boost::system::generic_category();
  qword_2A09000 = (__int64)boost::system::generic_category();
  qword_2A09008 = (__int64)boost::system::system_category();
}


