// Address: 0x1788790 | Name: _ZN3RBX12GuiDrawImageD2Ev
void __fastcall RBX::GuiDrawImage::~GuiDrawImage(RBX::GuiDrawImage *this)
{
  volatile signed __int32 *v2; // rdi
  volatile signed __int32 *v3; // rbx

  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 9);
  v2 = (volatile signed __int32 *)*((_QWORD *)this + 9);
  if ( v2 && !_InterlockedSub(v2 + 1, 1u) )
    operator delete((void *)v2);
  v3 = (volatile signed __int32 *)*((_QWORD *)this + 7);
  if ( v3 )
  {
    if ( !_InterlockedSub(v3 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
      if ( !_InterlockedSub(v3 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 24LL))(v3);
    }
  }
  if ( (*((_BYTE *)this + 24) & 1) != 0 )
    operator delete(*((void **)this + 5));
  if ( (*(_BYTE *)this & 1) != 0 )
    operator delete(*((void **)this + 2));
}


