// Address: 0x1789280 | Name: _ZN3RBX15EquationDisplayD2Ev
void __fastcall RBX::EquationDisplay::~EquationDisplay(RBX::EquationDisplay *this)
{
  *(_QWORD *)this = off_28DFB80;
  if ( (*((_BYTE *)this + 208) & 1) != 0 )
    operator delete(*((void **)this + 28));
  if ( (*((_BYTE *)this + 184) & 1) != 0 )
    operator delete(*((void **)this + 25));
  *(_QWORD *)this = off_28C95A0;
  if ( (*((_BYTE *)this + 112) & 1) != 0 )
    operator delete(*((void **)this + 16));
  RBX::GuiItem::~GuiItem(this);
}


// Address: 0x17892f0 | Name: _ZN3RBX15EquationDisplayD0Ev
void __fastcall RBX::EquationDisplay::~EquationDisplay(RBX::EquationDisplay *this)
{
  *(_QWORD *)this = off_28DFB80;
  if ( (*((_BYTE *)this + 208) & 1) != 0 )
    operator delete(*((void **)this + 28));
  if ( (*((_BYTE *)this + 184) & 1) != 0 )
    operator delete(*((void **)this + 25));
  *(_QWORD *)this = off_28C95A0;
  if ( (*((_BYTE *)this + 112) & 1) != 0 )
    operator delete(*((void **)this + 16));
  RBX::GuiItem::~GuiItem(this);
  operator delete(this);
}


