// Address: 0x1049c00 | Name: _ZNK3RBX9Animation10getAssetIdEv
RBX::Animation *__fastcall RBX::Animation::getAssetId(RBX::Animation *this, __int64 a2)
{
  std::string::basic_string(this, a2 + 128);
  return this;
}


// Address: 0x1049cb0 | Name: _ZN3RBX9AnimationD2Ev
void __fastcall RBX::Animation::~Animation(RBX::Animation *this)
{
  *(_QWORD *)this = &off_288E678;
  if ( (*((_BYTE *)this + 128) & 1) != 0 )
    operator delete(*((void **)this + 18));
  RBX::Instance::~Instance((RBX::Instance *)this);
}


// Address: 0x1049ce0 | Name: _ZN3RBX9AnimationD0Ev
void __fastcall RBX::Animation::~Animation(RBX::Animation *this)
{
  *(_QWORD *)this = &off_288E678;
  if ( (*((_BYTE *)this + 128) & 1) != 0 )
    operator delete(*((void **)this + 18));
  RBX::Instance::~Instance((RBX::Instance *)this);
  operator delete(this);
}


// Address: 0x1049d50 | Name: _ZNK3RBX9Animation21getPersistentDataCostEv
int __fastcall RBX::Animation::getPersistentDataCost(const RBX::Animation *this)
{
  int PersistentDataCost; // ebx
  unsigned __int64 v2; // rcx
  int v3; // ecx
  int v4; // ebp
  int v5; // ebp
  _BYTE v7[8]; // [rsp+0h] [rbp-28h] BYREF
  __int64 v8; // [rsp+8h] [rbp-20h]
  void *ptr; // [rsp+10h] [rbp-18h]

  PersistentDataCost = RBX::Instance::getPersistentDataCost((const RBX::Instance *)this);
  std::string::basic_string(v7, (char *)this + 128);
  if ( (v7[0] & 1) != 0 )
    LODWORD(v2) = v8;
  else
    v2 = (unsigned __int64)v7[0] >> 1;
  v3 = (int)v2 / 100;
  v4 = 1;
  if ( v3 > 0 )
    v4 = v3;
  v5 = PersistentDataCost + v4;
  if ( (v7[0] & 1) != 0 )
    operator delete(ptr);
  return v5;
}


// Address: 0x1049dc0 | Name: _ZNK3RBX9Animation12askSetParentEPKNS_8InstanceE
bool __fastcall RBX::Animation::askSetParent(const RBX::Animation *this, const RBX::Instance *instance)
{
  return 1;
}


