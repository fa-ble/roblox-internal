// Address: 0x1df00e0 | Name: _ZN3RBX9Collision16BallBlockContact16computeBallPlaneEfRKN3G3D7Vector3ENS_8NormalIdE
void __fastcall RBX::Collision::BallBlockContact::computeBallPlane(
        RBX::Collision::BallBlockContact *this,
        __m128 radius0,
        const RBX::Vector3 *offset1,
        RBX::NormalId normalId1)
{
  RBX::CollisionConnector *collisionConnector; // rax
  float *bodyB; // rdi
  float y; // xmm4_4
  float z; // xmm1_4
  float v8; // xmm9_4
  float v9; // xmm3_4
  float v10; // xmm1_4
  signed int v11; // esi
  __int64 v12; // rcx
  float v13; // xmm10_4
  __m128 v14; // xmm6
  __m128 v15; // xmm7
  __m128i v16; // xmm6
  float v17; // xmm4_4
  __m128 v18; // xmm2
  float v19; // xmm5_4
  float v20; // xmm3_4

  collisionConnector = this->collisionConnector;
  bodyB = (float *)collisionConnector->bodyB;
  y = offset1->y;
  z = offset1->z;
  v8 = (float)((float)(bodyB[54] * z) + (float)((float)(bodyB[53] * y) + (float)(bodyB[52] * offset1->x))) + bodyB[61];
  v9 = (float)((float)(bodyB[57] * z) + (float)((float)(bodyB[56] * y) + (float)(bodyB[55] * offset1->x))) + bodyB[62];
  v10 = (float)((float)(z * bodyB[60]) + (float)((float)(y * bodyB[59]) + (float)(offset1->x * bodyB[58]))) + bodyB[63];
  v11 = (-2 * (normalId1 / 3)) | 1;
  v12 = normalId1 % 3;
  v13 = (float)v11 * bodyB[v12 + 58];
  v14 = _mm_mul_ps(
          _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v11), 80)),
          _mm_unpacklo_ps((__m128)LODWORD(bodyB[v12 + 52]), (__m128)LODWORD(bodyB[v12 + 55])));
  v15 = _mm_mul_ps(_mm_shuffle_ps(radius0, radius0, 224), v14);
  v16 = (__m128i)_mm_xor_ps(v14, *(__m128 *)&stru_3E4970.x);
  v17 = *(float *)_mm_shuffle_epi32(v16, 229).m128i_i32;
  v18 = (__m128)*(unsigned __int64 *)&collisionConnector->bodyA->pv.position.translation.x;
  v19 = collisionConnector->bodyA->pv.position.translation.z;
  v20 = (float)((float)((float)(v9 - *(float *)_mm_shuffle_epi32((__m128i)v18, 229).m128i_i32) * v17)
              + (float)((float)(v8 - v18.m128_f32[0]) * *(float *)v16.m128i_i32))
      - (float)((float)(v10 - v19) * v13);
  _mm_storel_ps((double *)&collisionConnector->contactPoint.x, _mm_sub_ps(v18, v15));
  collisionConnector->contactPoint.z = v19 - (float)(v13 * radius0.m128_f32[0]);
  *(_QWORD *)&collisionConnector->normal.x = v16.m128i_i64[0];
  collisionConnector->normal.z = -v13;
  collisionConnector->depth = fsqrt(
                                (float)((float)(v20 * (float)-v13) * (float)(v20 * (float)-v13))
                              + (float)((float)((float)(v17 * v20) * (float)(v17 * v20))
                                      + (float)((float)(v20 * *(float *)v16.m128i_i32)
                                              * (float)(v20 * *(float *)v16.m128i_i32))))
                            - radius0.m128_f32[0];
}


// Address: 0x1df02a0 | Name: _ZN3RBX9Collision16BallBlockContact15computeBallEdgeEfRKN3G3D7Vector3ENS_8NormalIdE
void __fastcall RBX::Collision::BallBlockContact::computeBallEdge(
        RBX::Collision::BallBlockContact *this,
        __m128 radius0,
        const RBX::Vector3 *offset1,
        RBX::NormalId normalId1)
{
  RBX::CollisionConnector *collisionConnector; // rax
  RBX::Body *bodyA; // rbx
  RBX::Body *bodyB; // rax
  __m128 x_low; // xmm3
  __m128 y_low; // xmm2
  __m128 z_low; // xmm0
  __m128 v10; // xmm1
  __int32 v12; // edx
  int v13; // esi
  signed int v14; // edx
  __int64 v15; // rcx
  __m128 v16; // xmm2
  __m128 v17; // xmm4
  __m128 v18; // xmm1
  __m128 v19; // xmm3
  __m128 v20; // xmm1
  RBX::CollisionConnector *v21; // rax
  G3D::Vector3 v22; // [rsp+0h] [rbp-38h] BYREF
  __m128 v23; // [rsp+10h] [rbp-28h]

  v23 = radius0;
  collisionConnector = this->collisionConnector;
  bodyA = collisionConnector->bodyA;
  bodyB = collisionConnector->bodyB;
  x_low = (__m128)LODWORD(offset1->x);
  y_low = (__m128)LODWORD(offset1->y);
  z_low = (__m128)LODWORD(offset1->z);
  v10 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(z_low, z_low, 224),
              _mm_unpacklo_ps(
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(y_low, y_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(x_low, x_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]))))));
  z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][2])
                            + (float)((float)(y_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][1])
                                    + (float)(x_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][0])))
                    + bodyB->pv.position.translation.z;
  v12 = normalId1 / 3;
  v13 = 3 * v12;
  v14 = (-2 * v12) | 1;
  v15 = normalId1 - v13;
  v16 = 0;
  v17 = _mm_mul_ps(
          _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v14), 80)),
          _mm_unpacklo_ps(
            (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][v15]),
            (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][v15])));
  v16.m128_f32[0] = (float)v14 * bodyB->pv.position.rotation.elt[2][v15];
  v18 = _mm_sub_ps(v10, (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.x);
  z_low.m128_f32[0] = z_low.m128_f32[0] - bodyA->pv.position.translation.z;
  v19 = v16;
  v19.m128_f32[0] = (float)(v16.m128_f32[0] * z_low.m128_f32[0])
                  + (float)((float)(_mm_shuffle_ps(v17, v17, 229).m128_f32[0] * _mm_shuffle_ps(v18, v18, 229).m128_f32[0])
                          + (float)(v17.m128_f32[0] * v18.m128_f32[0]));
  v20 = _mm_sub_ps(v18, _mm_mul_ps(_mm_shuffle_ps(v19, v19, 224), v17));
  _mm_storel_ps((double *)&v22.x, v20);
  v22.z = z_low.m128_f32[0] - (float)(v16.m128_f32[0] * v19.m128_f32[0]);
  z_low.m128_f32[0] = G3D::Vector3::unitize(&v22, v20.m128_f32[0]);
  z_low.m128_f32[0] = z_low.m128_f32[0] - v23.m128_f32[0];
  v19.m128_f32[0] = (float)(v23.m128_f32[0] * v22.z) + bodyA->pv.position.translation.z;
  v21 = this->collisionConnector;
  _mm_storel_ps(
    (double *)&v21->contactPoint.x,
    _mm_add_ps(
      (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.x,
      _mm_mul_ps(_mm_shuffle_ps(v23, v23, 224), (__m128)*(unsigned __int64 *)&v22.x)));
  LODWORD(v21->contactPoint.z) = v19.m128_i32[0];
  v21->normal = v22;
  LODWORD(v21->depth) = z_low.m128_i32[0];
}


// Address: 0x1df0480 | Name: _ZN3RBX9Collision16BallBlockContact16computeBallPointEfRKN3G3D7Vector3ENS_8NormalIdE
void __fastcall RBX::Collision::BallBlockContact::computeBallPoint(
        RBX::Collision::BallBlockContact *this,
        float radius0,
        const RBX::Vector3 *offset1,
        RBX::NormalId normalId1)
{
  RBX::CollisionConnector *collisionConnector; // rcx
  RBX::Body *bodyA; // rax
  RBX::Body *bodyB; // rcx
  __m128 x_low; // xmm1
  __m128 y_low; // xmm0
  __m128 z_low; // xmm6
  __m128 v10; // xmm1
  __m128 v11; // xmm0
  float v12; // xmm2_4
  RBX::CollisionConnector *v13; // rax
  G3D::Vector3 v14; // [rsp+0h] [rbp-38h] BYREF
  float v15; // [rsp+Ch] [rbp-2Ch]
  __m128 v16; // [rsp+10h] [rbp-28h]
  __m128 v17; // [rsp+20h] [rbp-18h]

  v15 = radius0;
  collisionConnector = this->collisionConnector;
  bodyA = collisionConnector->bodyA;
  bodyB = collisionConnector->bodyB;
  x_low = (__m128)LODWORD(offset1->x);
  y_low = (__m128)LODWORD(offset1->y);
  z_low = (__m128)LODWORD(offset1->z);
  v17 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(z_low, z_low, 224),
              _mm_unpacklo_ps(
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(y_low, y_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(x_low, x_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]))))));
  z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][2])
                            + (float)((float)(y_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][1])
                                    + (float)(x_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][0])))
                    + bodyB->pv.position.translation.z;
  v16 = z_low;
  v10 = _mm_sub_ps(v17, (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.x);
  y_low.m128_f32[0] = z_low.m128_f32[0] - bodyA->pv.position.translation.z;
  _mm_storel_ps((double *)&v14.x, v10);
  LODWORD(v14.z) = y_low.m128_i32[0];
  v11 = (__m128)0x358637BDu;
  v11.m128_f32[0] = G3D::Vector3::unitize(&v14, v10.m128_f32[0]);
  v11.m128_f32[0] = v11.m128_f32[0] - v15;
  v12 = v16.m128_f32[0] - (float)(v14.z * v11.m128_f32[0]);
  v13 = this->collisionConnector;
  _mm_storel_ps(
    (double *)&v13->contactPoint.x,
    _mm_sub_ps(v17, _mm_mul_ps(_mm_shuffle_ps(v11, v11, 224), (__m128)*(unsigned __int64 *)&v14.x)));
  v13->contactPoint.z = v12;
  v13->normal = v14;
  LODWORD(v13->depth) = v11.m128_i32[0];
}


// Address: 0x1df05d0 | Name: _ZN3RBX9Collision16BallBlockContact24updateCollisionConnectorEfRKN3G3D7Vector3ENS_8NormalIdERKNS_11GeoPairTypeE
void __fastcall RBX::Collision::BallBlockContact::updateCollisionConnector(
        RBX::Collision::BallBlockContact *this,
        __m128 radius0,
        const RBX::Vector3 *offset1,
        RBX::NormalId normalId1,
        const RBX::GeoPairType *geoPairType)
{
  RBX::CollisionConnector *collisionConnector; // rcx
  RBX::Body *bodyA; // rax
  RBX::Body *bodyB; // rcx
  __m128 v8; // xmm2
  __m128 v9; // xmm3
  __m128 x_low; // xmm1
  __m128 y_low; // xmm0
  __m128 z_low; // xmm6
  __m128 v13; // xmm1
  __m128 v14; // xmm0
  RBX::CollisionConnector *v15; // rax
  G3D::Vector3 v16; // [rsp+0h] [rbp-38h] BYREF
  float v17; // [rsp+Ch] [rbp-2Ch]
  __m128 v18; // [rsp+10h] [rbp-28h]
  __m128 v19; // [rsp+20h] [rbp-18h]

  if ( *geoPairType == RBX::GeoPairType::BALL_EDGE_PAIR )
  {
    RBX::Collision::BallBlockContact::computeBallEdge(this, radius0, offset1, normalId1);
  }
  else if ( *geoPairType == RBX::GeoPairType::BALL_PLANE_PAIR )
  {
    RBX::Collision::BallBlockContact::computeBallPlane(this, radius0, offset1, normalId1);
  }
  else
  {
    collisionConnector = this->collisionConnector;
    bodyA = collisionConnector->bodyA;
    bodyB = collisionConnector->bodyB;
    v8 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]);
    v9 = (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]);
    x_low = (__m128)LODWORD(offset1->x);
    v17 = radius0.m128_f32[0];
    y_low = (__m128)LODWORD(offset1->y);
    z_low = (__m128)LODWORD(offset1->z);
    v19 = _mm_add_ps(
            (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(z_low, z_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]))),
              _mm_add_ps(
                _mm_mul_ps(
                  _mm_shuffle_ps(y_low, y_low, 224),
                  _mm_unpacklo_ps(v9, (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]))),
                _mm_mul_ps(
                  _mm_shuffle_ps(x_low, x_low, 224),
                  _mm_unpacklo_ps(v8, (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]))))));
    z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][2])
                              + (float)((float)(y_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][1])
                                      + (float)(x_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][0])))
                      + bodyB->pv.position.translation.z;
    v18 = z_low;
    v13 = _mm_sub_ps(v19, (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.x);
    y_low.m128_f32[0] = z_low.m128_f32[0] - bodyA->pv.position.translation.z;
    _mm_storel_ps((double *)&v16.x, v13);
    LODWORD(v16.z) = y_low.m128_i32[0];
    v14 = (__m128)0x358637BDu;
    v14.m128_f32[0] = G3D::Vector3::unitize(&v16, v13.m128_f32[0]);
    v14.m128_f32[0] = v14.m128_f32[0] - v17;
    v8.m128_f32[0] = v18.m128_f32[0] - (float)(v16.z * v14.m128_f32[0]);
    v15 = this->collisionConnector;
    _mm_storel_ps(
      (double *)&v15->contactPoint.x,
      _mm_sub_ps(v19, _mm_mul_ps(_mm_shuffle_ps(v14, v14, 224), (__m128)*(unsigned __int64 *)&v16.x)));
    LODWORD(v15->contactPoint.z) = v8.m128_i32[0];
    v15->normal = v16;
    LODWORD(v15->depth) = v14.m128_i32[0];
  }
}


// Address: 0x1df0790 | Name: _ZN3RBX9Collision16BallBlockContact16getNumCollisionsEv
unsigned int __fastcall RBX::Collision::BallBlockContact::getNumCollisions(RBX::Collision::BallBlockContact *this)
{
  return this->collisionConnector != 0;
}


// Address: 0x1df07a0 | Name: _ZN3RBX9Collision16BallBlockContact21getCollisionConnectorEj
RBX::CollisionConnector *__fastcall RBX::Collision::BallBlockContact::getCollisionConnector(
        RBX::Collision::BallBlockContact *this,
        unsigned int i)
{
  return this->collisionConnector;
}


// Address: 0x1df07b0 | Name: _ZN3RBX9Collision16BallBlockContact24deleteCollisionConnectorEj
void __fastcall RBX::Collision::BallBlockContact::deleteCollisionConnector(
        RBX::Collision::BallBlockContact *this,
        unsigned int i)
{
  RBX::CollisionConnector *collisionConnector; // rdi

  collisionConnector = this->collisionConnector;
  if ( collisionConnector )
  {
    operator delete(collisionConnector);
    this->collisionConnector = 0;
  }
}


// Address: 0x1df07d0 | Name: _ZN3RBX9Collision16BallBlockContact18computeIsCollidingEf
__int64 __fastcall RBX::Collision::BallBlockContact::computeIsColliding(
        RBX::Collision::BallBlockContact *this,
        float a2,
        float overlapIgnored)
{
  RBX::Primitive *prim1; // rbx
  const RBX::Extents *FastFuzzyExtents; // rbp
  const RBX::Extents *v6; // rax
  unsigned int *prim0; // rbx
  __m128 v8; // xmm0
  __m128 v9; // xmm1
  __m128 v10; // xmm0
  float v11; // xmm3_4
  __m128 v12; // xmm1
  __m128 v13; // xmm0
  __m128 v14; // xmm0
  __m128 v15; // xmm0
  RBX::Primitive *v16; // rbp
  char *v17; // r14
  __int64 v18; // rax
  RBX::Block *v19; // rdi
  RBX::GeoPairType BallBlockInfo; // eax
  RBX::Vector3int16 v22; // [rsp+0h] [rbp-B8h] BYREF
  RBX::NormalId normalId1; // [rsp+Ch] [rbp-ACh] BYREF
  RBX::Vector3 ray; // [rsp+10h] [rbp-A8h] BYREF
  float v25; // [rsp+1Ch] [rbp-9Ch]
  RBX::GeoPairType geoPairType; // [rsp+20h] [rbp-98h] BYREF
  int v27; // [rsp+24h] [rbp-94h] BYREF
  G3D::Matrix3 v28; // [rsp+28h] [rbp-90h] BYREF
  __m128 v29; // [rsp+50h] [rbp-68h]
  __m128 v30; // [rsp+60h] [rbp-58h]
  __m128 v31; // [rsp+70h] [rbp-48h]
  RBX::CollisionParams v32; // [rsp+80h] [rbp-38h] BYREF

  v25 = a2;
  prim1 = this->prim1;
  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(this->prim0);
  v6 = RBX::Primitive::getFastFuzzyExtents(prim1);
  if ( FastFuzzyExtents->low.x > v6->high.x
    || FastFuzzyExtents->low.y > v6->high.y
    || FastFuzzyExtents->low.z > v6->high.z
    || v6->low.y > FastFuzzyExtents->high.y
    || v6->low.x > FastFuzzyExtents->high.x
    || v6->low.z > FastFuzzyExtents->high.z )
  {
    LODWORD(v16) = 0;
  }
  else
  {
    prim0 = (unsigned int *)this->prim0;
    v16 = this->prim1;
    v8 = (__m128)prim0[99];
    v9 = (__m128)prim0[100];
    v8.m128_f32[0] = v8.m128_f32[0] - *((float *)v16 + 99);
    v30 = v8;
    v9.m128_f32[0] = v9.m128_f32[0] - *((float *)v16 + 100);
    v31 = v9;
    v10 = (__m128)prim0[101];
    v10.m128_f32[0] = v10.m128_f32[0] - *((float *)v16 + 101);
    v29 = v10;
    G3D::Matrix3::transpose(&v28, (const G3D::Matrix3 *)v16 + 10);
    v11 = (float)(v29.m128_f32[0] * v28.elt[2][2])
        + (float)((float)(v31.m128_f32[0] * v28.elt[2][1]) + (float)(v30.m128_f32[0] * v28.elt[2][0]));
    _mm_storel_ps(
      (double *)&ray.x,
      _mm_add_ps(
        _mm_mul_ps(
          _mm_shuffle_ps(v29, v29, 224),
          _mm_unpacklo_ps((__m128)LODWORD(v28.elt[0][2]), (__m128)LODWORD(v28.elt[1][2]))),
        _mm_add_ps(
          _mm_mul_ps(
            _mm_shuffle_ps(v31, v31, 224),
            _mm_unpacklo_ps((__m128)LODWORD(v28.elt[0][1]), (__m128)LODWORD(v28.elt[1][1]))),
          _mm_mul_ps(
            _mm_shuffle_ps(v30, v30, 224),
            _mm_unpacklo_ps((__m128)LODWORD(v28.elt[0][0]), (__m128)LODWORD(v28.elt[1][0]))))));
    ray.z = v11;
    *(_DWORD *)&v22.x = 0;
    v22.z = 0;
    RBX::Block::projectToFace(*((RBX::Block **)this->prim1 + 18), &ray, &v22, &v27);
    v12 = _mm_mul_ps((__m128)*((unsigned __int64 *)v16 + 47), (__m128)*(unsigned __int64 *)&ray.y);
    v12.m128_f32[0] = (float)(_mm_shuffle_ps(v12, v12, 229).m128_f32[0]
                            + (float)((float)(*((float *)v16 + 93) * ray.x) + v12.m128_f32[0]))
                    + *((float *)v16 + 100);
    v13 = _mm_sub_ps(
            _mm_add_ps(
              _mm_unpacklo_ps((__m128)*((unsigned int *)v16 + 99), (__m128)*((unsigned int *)v16 + 101)),
              _mm_add_ps(
                _mm_mul_ps(
                  (__m128)_mm_shuffle_epi32((__m128i)*(unsigned __int64 *)&ray.y, 229),
                  _mm_unpacklo_ps((__m128)*((unsigned int *)v16 + 92), (__m128)*((unsigned int *)v16 + 98))),
                _mm_add_ps(
                  _mm_mul_ps(
                    (__m128)_mm_shuffle_epi32((__m128i)*(unsigned __int64 *)&ray.y, 224),
                    _mm_unpacklo_ps((__m128)*((unsigned int *)v16 + 91), (__m128)*((unsigned int *)v16 + 97))),
                  _mm_mul_ps(
                    _mm_shuffle_ps((__m128)LODWORD(ray.x), (__m128)LODWORD(ray.x), 224),
                    _mm_unpacklo_ps((__m128)*((unsigned int *)v16 + 90), (__m128)*((unsigned int *)v16 + 96)))))),
            _mm_unpacklo_ps((__m128)prim0[99], (__m128)prim0[101]));
    v14 = _mm_mul_ps(v13, v13);
    v12.m128_f32[0] = (float)((float)(v12.m128_f32[0] - *((float *)prim0 + 100))
                            * (float)(v12.m128_f32[0] - *((float *)prim0 + 100)))
                    + v14.m128_f32[0];
    v15 = _mm_shuffle_ps(v14, v14, 229);
    v29.m128_i32[0] = fsqrt(v15.m128_f32[0] + v12.m128_f32[0]);
    v15.m128_f32[0] = (*(float (__fastcall **)(_QWORD))(**((_QWORD **)this->prim0 + 18) + 56LL))(*((_QWORD *)this->prim0
                                                                                                 + 18));
    v15.m128_f32[0] = v15.m128_f32[0] - v25;
    LOBYTE(v16) = v15.m128_f32[0] > v29.m128_f32[0];
    if ( v15.m128_f32[0] > v29.m128_f32[0] )
    {
      if ( !this->collisionConnector )
      {
        v17 = (char *)operator new(0x40u);
        RBX::Collision::Contact::computeCollisionParams(&v32, this->prim0, this->prim1);
        v18 = *(_QWORD *)&v32.friction;
        *(_OWORD *)v17 = *(_OWORD *)&v32.b0;
        *((_QWORD *)v17 + 2) = v18;
        v15 = 0;
        *(_OWORD *)(v17 + 36) = 0;
        *(_OWORD *)(v17 + 24) = 0;
        *((_DWORD *)v17 + 13) = -1;
        v17[56] = 1;
        this->collisionConnector = (RBX::CollisionConnector *)v17;
      }
      v19 = (RBX::Block *)*((_QWORD *)this->prim1 + 18);
      if ( v27 )
        BallBlockInfo = (unsigned int)RBX::Block::getBallBlockInfo(
                                        v19,
                                        v27,
                                        *(unsigned int *)&v22.x | ((unsigned __int64)(unsigned __int16)v22.z << 32),
                                        (const RBX::Vector3 **)&v28,
                                        &normalId1);
      else
        BallBlockInfo = RBX::Block::getBallInsideInfo(v19, &ray, (const RBX::Vector3 **)&v28, &normalId1);
      geoPairType = BallBlockInfo;
      *(double *)v15.m128_u64 = (*(double (__fastcall **)(_QWORD))(**((_QWORD **)this->prim0 + 18) + 56LL))(*((_QWORD *)this->prim0 + 18));
      RBX::Collision::BallBlockContact::updateCollisionConnector(
        this,
        v15,
        *(const RBX::Vector3 **)&v28.elt[0][0],
        normalId1,
        &geoPairType);
    }
  }
  return (unsigned int)v16;
}


// Address: 0x1df0b70 | Name: _ZN3RBX9Collision16BallBlockContactC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::BallBlockContact::BallBlockContact(
        RBX::Collision::BallBlockContact *this,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  RBX::Collision::Contact::Contact(this, p0, p1);
  this->_vptr$Contact = (int (**)(void))&off_299E210;
  this->collisionConnector = 0;
}


// Address: 0x1df0b90 | Name: _ZN3RBX9Collision16BallBlockContactD2Ev
void __fastcall RBX::Collision::BallBlockContact::~BallBlockContact(RBX::Collision::BallBlockContact *this)
{
  this->_vptr$Contact = (int (**)(void))&off_299E210;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
}


// Address: 0x1df0bb0 | Name: _ZN3RBX9Collision16BallBlockContactD0Ev
void __fastcall RBX::Collision::BallBlockContact::~BallBlockContact(RBX::Collision::BallBlockContact *this)
{
  this->_vptr$Contact = (int (**)(void))&off_299E210;
  RBX::Collision::Contact::deleteAllCollisionConnectors(this);
  operator delete(this);
}


// Address: 0x1df0be0 | Name: _GLOBAL__sub_I_BallBlockContact.cpp
void __cdecl GLOBAL__sub_I_BallBlockContact_cpp()
{
  qword_2AAF588 = (__int64)boost::system::generic_category();
  qword_2AAF590 = (__int64)boost::system::generic_category();
  qword_2AAF598 = (__int64)boost::system::system_category();
}


