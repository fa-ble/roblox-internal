// Address: 0x10e5a10 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN6FlyingE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Flying *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08E18;
  if ( !qword_2A08E18 )
  {
    result = RBX::Name::declare("Flying");
    qword_2A08E18 = result;
  }
  return result;
}


// Address: 0x10e5a40 | Name: _ZNK3RBX5HUMAN6Flying7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Flying::getName(const RBX::HUMAN::Flying *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08E18;
  if ( !qword_2A08E18 )
  {
    result = RBX::Name::declare("Flying");
    qword_2A08E18 = result;
  }
  return result;
}


// Address: 0x10e5a70 | Name: _ZN3RBX5HUMAN6FlyingC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Flying::Flying(
        RBX::HUMAN::Flying *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::Balancing::Balancing(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895790;
  *((_DWORD *)this + 78) = 1167867904;
}


// Address: 0x10e5a90 | Name: _ZN3RBX5HUMAN6Flying19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::Flying::onSimulatorStepImpl(RBX::HUMAN::Flying *this, double a2, float stepDt)
{
  ;
}


// Address: 0x10e5aa0 | Name: _ZN3RBX5HUMAN6Flying18onComputeForceImplEv
void __fastcall RBX::HUMAN::Flying::onComputeForceImpl(RBX::HUMAN::Flying *this)
{
  ;
}


// Address: 0x10e5c00 | Name: _GLOBAL__sub_I_Flying.cpp
void __cdecl GLOBAL__sub_I_Flying_cpp()
{
  qword_2A08E00 = (__int64)boost::system::generic_category();
  qword_2A08E08 = (__int64)boost::system::generic_category();
  qword_2A08E10 = (__int64)boost::system::system_category();
}


