// Address: 0x10e5ab0 | Name: _ZN3RBX5HUMAN9BalancingD2Ev
void __fastcall RBX::HUMAN::Balancing::~Balancing(RBX::HUMAN::Balancing *this)
{
  __int64 v2; // r15
  __int64 v3; // rbx
  volatile signed __int32 *v4; // rdi
  void *v5; // rdi

  *(_QWORD *)this = &off_2895850;
  v2 = *((_QWORD *)this + 44);
  if ( v2 )
  {
    v3 = *((_QWORD *)this + 45);
    if ( v3 == v2 )
    {
      v5 = (void *)*((_QWORD *)this + 44);
    }
    else
    {
      do
      {
        v4 = *(volatile signed __int32 **)(v3 - 8);
        if ( v4 && !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
        v3 -= 16;
      }
      while ( v2 != v3 );
      v5 = (void *)*((_QWORD *)this + 44);
    }
    *((_QWORD *)this + 45) = v2;
    operator delete(v5);
  }
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
}


// Address: 0x10e70b0 | Name: _ZN3RBX5HUMAN9BalancingD0Ev
void __fastcall __noreturn RBX::HUMAN::Balancing::~Balancing(RBX::HUMAN::Balancing *this)
{
  BUG();
}


