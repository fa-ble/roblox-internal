// Address: 0x1df1ee0 | Name: _ZN3RBX9Collision9CellCoord4HashC2ERKS1_
void __fastcall RBX::Collision::CellCoord::Hash::Hash(
        RBX::Collision::CellCoord::Hash *this,
        const RBX::Collision::CellCoord *c)
{
  this->h = (73856093 * c->v[0]) ^ (19349663 * c->v[1]) ^ (83492791 * c->v[2]);
}


// Address: 0x1df1f00 | Name: _ZN3RBX9Collision9LevelGridC2EmPNS0_16SpatialHashPoolsEb
void __fastcall RBX::Collision::LevelGrid::LevelGrid(
        RBX::Collision::LevelGrid *this,
        size_t binCount,
        RBX::Collision::SpatialHashPools *pools,
        bool levelWithChildren)
{
  RBX::ArrayDynamic<RBX::Collision::LevelGrid::Bin> *p_bins; // r12
  RBX::Collision::LevelGrid::CellChidrenContainer *p_children; // rdi
  size_t v10; // rsi
  unsigned __int8 *Aligned; // rax
  unsigned __int8 *v12; // r15
  unsigned __int8 *mData; // rsi
  size_t mSize; // rdx
  __int64 v15; // rax
  size_t v16; // rdi
  char v17; // bp
  RBX::Collision::LevelGrid::Bin *v18; // rax
  RBX::Collision::LevelGrid::Bin *v19; // r15
  RBX::Collision::LevelGrid::Bin *v20; // rax
  size_t v21; // rcx
  __int64 v22; // rdx
  RBX::Collision::LevelGrid::Bin *v23; // rdi
  RBX::Collision::LevelGrid::Bin *v24; // rax
  __int64 v25; // rcx
  __int64 v26; // rax
  size_t v27; // rdi

  *(_OWORD *)((char *)&this->sizes.mSize + 1) = 0;
  this->sizes.RBX::ArrayBase<unsigned char> = 0;
  this->sizes.mAlignment = 16;
  p_bins = &this->bins;
  *(_OWORD *)((char *)&this->bins.mSize + 1) = 0;
  this->bins.RBX::ArrayBase<RBX::Collision::LevelGrid::Bin> = 0;
  this->bins.mAlignment = 16;
  p_children = &this->children;
  v10 = 0;
  if ( levelWithChildren )
    v10 = binCount;
  RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4>::OptimizedBinContainer(p_children, v10);
  this->hasChildren = levelWithChildren;
  *(_OWORD *)&this->cellCount = 0;
  *(_OWORD *)&this->primitiveCount = 0;
  this->largeBinSizeReported = 0;
  this->pools = pools;
  this->emptyBinCount = binCount;
  this->sizes.mSize = 0;
  if ( this->sizes.mCapacity < binCount )
  {
    Aligned = (unsigned __int8 *)RBX::Memory::allocateAligned(binCount, this->sizes.mAlignment);
    v12 = Aligned;
    if ( !Aligned )
      goto LABEL_20;
    mData = this->sizes.mData;
    mSize = this->sizes.mSize;
    if ( this->sizes.mNoInit )
    {
      if ( mSize <= 0x10 )
      {
        if ( mSize )
        {
          v15 = 0;
          if ( (mSize & 3) != 0 )
          {
            v16 = -(this->sizes.mSize & 3);
            do
            {
              v12[v15] = mData[v15];
              ++v15;
              ++v16;
            }
            while ( v16 );
          }
          if ( mSize - 1 >= 3 )
          {
            do
            {
              v12[v15] = mData[v15];
              v12[v15 + 1] = mData[v15 + 1];
              v12[v15 + 2] = mData[v15 + 2];
              v12[v15 + 3] = mData[v15 + 3];
              v15 += 4;
            }
            while ( mSize != v15 );
          }
        }
        goto LABEL_16;
      }
    }
    else if ( mSize <= 0x10 )
    {
      if ( mSize )
      {
        v26 = 0;
        if ( (mSize & 3) != 0 )
        {
          v27 = -(this->sizes.mSize & 3);
          do
          {
            v12[v26] = mData[v26];
            ++v26;
            ++v27;
          }
          while ( v27 );
        }
        if ( mSize - 1 >= 3 )
        {
          do
          {
            v12[v26] = mData[v26];
            v12[v26 + 1] = mData[v26 + 1];
            v12[v26 + 2] = mData[v26 + 2];
            v12[v26 + 3] = mData[v26 + 3];
            v26 += 4;
          }
          while ( mSize != v26 );
        }
      }
      goto LABEL_16;
    }
    memcpy(Aligned, mData, mSize);
LABEL_16:
    if ( this->sizes.mCapacity )
      RBX::Memory::deallocateAligned(this->sizes.mData);
    this->sizes.mData = v12;
    this->sizes.mCapacity = binCount;
  }
  if ( !binCount )
  {
    v17 = 1;
    goto LABEL_22;
  }
LABEL_20:
  v17 = 0;
  memset(this->sizes.mData, 0, binCount);
LABEL_22:
  this->sizes.mSize = binCount;
  this->bins.mSize = 0;
  if ( this->bins.mCapacity < binCount )
  {
    if ( 16 * binCount )
    {
      v18 = (RBX::Collision::LevelGrid::Bin *)RBX::Memory::allocateAligned(16 * binCount, this->bins.mAlignment);
      v19 = v18;
      if ( v18 )
      {
        memcpy(v18, this->bins.mData, 16 * this->bins.mSize);
        if ( this->bins.mCapacity )
          RBX::Memory::deallocateAligned(p_bins->mData);
        this->bins.mData = v19;
        this->bins.mCapacity = binCount;
      }
    }
  }
  if ( !v17 )
  {
    v20 = p_bins->mData;
    v21 = binCount & 7;
    if ( binCount - 1 < 7 )
    {
      v22 = 0;
      if ( (binCount & 7) == 0 )
        goto LABEL_37;
      goto LABEL_35;
    }
    v23 = v20 + 7;
    v22 = 0;
    do
    {
      v23[-7] = 0;
      v23[-6] = 0;
      v23[-5] = 0;
      v23[-4] = 0;
      v23[-3] = 0;
      v23[-2] = 0;
      v23[-1] = 0;
      *v23 = 0;
      v22 += 8;
      v23 += 8;
    }
    while ( binCount - v21 != v22 );
    if ( (binCount & 7) != 0 )
    {
LABEL_35:
      v24 = &v20[v22];
      v25 = -(__int64)v21;
      do
      {
        *v24++ = 0;
        ++v25;
      }
      while ( v25 );
    }
  }
LABEL_37:
  this->bins.mSize = binCount;
}


// Address: 0x1df24a0 | Name: _ZN3RBX9Collision9LevelGridD2Ev
void __fastcall RBX::Collision::LevelGrid::~LevelGrid(RBX::Collision::LevelGrid *this)
{
  size_t mSize; // rax
  unsigned __int8 *mData; // rcx
  size_t i; // r15
  RBX::Collision::LevelGrid::CellIndex cellIndex; // [rsp+8h] [rbp-30h] BYREF

  if ( this->cellCount )
  {
    mSize = this->sizes.mSize;
    if ( mSize )
    {
      mData = this->sizes.mData;
      for ( i = 0; i < mSize; ++i )
      {
        if ( mData[i] )
        {
          do
          {
            cellIndex.valid = 1;
            cellIndex.binIndex.data = i;
            cellIndex.nodeIndex = 0;
            RBX::Collision::CellPrimitives::clear(
              this->bins.mData[(unsigned int)i].prims,
              &this->pools->primitiveArrayPool);
            RBX::Collision::LevelGrid::freeCell(this, &cellIndex);
            mData = this->sizes.mData;
          }
          while ( this->sizes.mData[i] );
          mSize = this->sizes.mSize;
        }
      }
    }
  }
  RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4>::~OptimizedBinContainer(&this->children);
  this->bins.mSize = 0;
  if ( this->bins.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->bins.mData);
    this->bins.mCapacity = 0;
    this->bins.mData = 0;
  }
  this->sizes.mSize = 0;
  if ( this->sizes.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->sizes.mData);
    this->sizes.mCapacity = 0;
    this->sizes.mData = 0;
  }
}


// Address: 0x1df25d0 | Name: _ZN3RBX9Collision9LevelGrid8freeCellERKNS1_9CellIndexE
void __fastcall RBX::Collision::LevelGrid::freeCell(
        RBX::Collision::LevelGrid *this,
        const RBX::Collision::LevelGrid::CellIndex *cellIndex)
{
  __int64 data; // r11
  unsigned __int8 *mData; // r10
  RBX::Collision::LevelGrid::Bin *v5; // r15
  __int64 v6; // r13
  RBX::Collision::CellPrimitives **p_prims; // r12
  __int64 nodeIndex; // rax
  unsigned __int64 v9; // rcx
  RBX::Collision::CellCoord *coords; // rdx
  __int64 v11; // rcx
  __int64 v12; // rdi
  __int64 v13; // rcx
  RBX::Collision::CellPrimitives *v14; // rdx
  __int64 v15; // rax
  RBX::Collision::ShortArrayOfPrimitivePtrs groundedPrims; // xmm0
  unsigned __int64 v17; // rcx
  __int64 v18; // r8
  RBX::Collision::CellChildren *v19; // r8
  __int64 v20; // rbp
  unsigned __int8 *v21; // rbx
  RBX::Collision::LevelGrid::Bin *v22; // r15
  unsigned __int8 v23; // r13
  bool v24; // zf
  unsigned __int8 v25; // r13
  RBX::Collision::CellCoord *v26; // rbp
  RBX::Collision::SpatialHashPools *pools; // r15
  RBX::Collision::CellCoord *v28; // rax
  unsigned __int8 *v29; // r8
  __int64 v30; // rdi
  RBX::Collision::CellCoord *v31; // rbx
  __int64 v32; // rcx
  RBX::Collision::CellCoord *v33; // rbp
  RBX::ArrayDynamic<void *> *v34; // rbx
  size_t mSize; // rax
  size_t mCapacity; // rcx
  size_t v37; // rax
  __int64 v38; // rdx
  __int64 v39; // rcx
  size_t v40; // rsi
  RBX::Collision::CellPrimitives *v41; // rbp
  RBX::ArrayDynamic<void *> *v42; // rbx
  size_t v43; // rax
  size_t v44; // rcx
  size_t v45; // rax
  __int64 v46; // rdx
  __int64 v47; // rcx
  size_t v48; // rsi
  size_t bucket_count; // rbp
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  _QWORD *p_next; // rbx
  __int64 v52; // r9
  std::array<RBX::Collision::CellChildren,2>::value_type *v53; // rcx
  size_t v54; // rbp
  boost::unordered::detail::ptr_bucket::link_pointer v55; // rax
  _QWORD *v56; // rbx
  __int64 v57; // rdx
  __int64 v58; // rax
  RBX::ArrayDynamic<void *> *v59; // r15
  size_t v60; // rax
  size_t v61; // rcx
  size_t v62; // rax
  __int64 v63; // rdx
  __int64 v64; // rcx
  size_t v65; // rsi
  RBX::Collision::CellPrimitives *v66; // rbp
  size_t v67; // r12
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives> *p_cellPrimitiveArrayPool; // rbx
  RBX::Collision::CellPrimitives *v69; // rax
  RBX::Collision::CellPrimitives *v70; // r14
  RBX::ArrayDynamic<void *> *v71; // rbx
  size_t v72; // rax
  size_t v73; // rcx
  size_t v74; // rax
  __int64 v75; // rdx
  __int64 v76; // rcx
  size_t v77; // rsi
  unsigned __int8 *v78; // [rsp+0h] [rbp-68h]
  __int64 v79; // [rsp+8h] [rbp-60h]
  RBX::Collision::CellPrimitives **v80; // [rsp+10h] [rbp-58h]
  _QWORD v81[2]; // [rsp+20h] [rbp-48h] BYREF
  RBX::Collision::LevelGrid::Bin *v82; // [rsp+30h] [rbp-38h]

  --this->cellCount;
  data = cellIndex->binIndex.data;
  mData = this->sizes.mData;
  v5 = this->bins.mData;
  v6 = data;
  p_prims = &v5[data].prims;
  nodeIndex = cellIndex->nodeIndex;
  v9 = this->sizes.mData[data];
  if ( nodeIndex + 1 >= v9 )
  {
    if ( !this->hasChildren )
      goto LABEL_8;
    goto LABEL_7;
  }
  coords = v5[cellIndex->binIndex.data].coords;
  v11 = v9;
  v12 = nodeIndex;
  coords[v12].v[0] = coords[v11 - 1].v[0];
  coords[v12].v[1] = coords[v11 - 1].v[1];
  coords[v12].v[2] = coords[v11 - 1].v[2];
  v13 = mData[data];
  v14 = *p_prims;
  v15 = nodeIndex;
  groundedPrims = (*p_prims)[v13 - 1].groundedPrims;
  v14[v15].dynamicPrims = (*p_prims)[v13 - 1].dynamicPrims;
  v14[v15].groundedPrims = groundedPrims;
  if ( !this->hasChildren )
    goto LABEL_8;
  v17 = cellIndex->binIndex.data;
  v18 = mData[data];
  if ( v18 == 1 )
  {
    v19 = &this->children.element0.mData[v17];
    goto LABEL_34;
  }
  if ( (unsigned __int64)mData[data] - 1 <= 2 )
  {
    v19 = &this->children.firstOverflow.mData[v17 - 1].__elems_[v18];
    goto LABEL_34;
  }
  if ( !this->children.secondOverflow.table_.size_
    || (bucket_count = this->children.secondOverflow.table_.bucket_count_,
        (next = this->children.secondOverflow.table_.buckets_[v17 % bucket_count].next_) == 0)
    || (p_next = &next->next_->next_) == 0 )
  {
LABEL_33:
    std::logic_error::logic_error((std::logic_error *)v81, "Unable to find key in unordered_map.");
    v81[0] = (char *)&`vtable for'std::out_of_range + 16;
    boost::throw_exception<std::out_of_range>((const std::out_of_range *)v81);
  }
  while ( 1 )
  {
    if ( p_next[1] != v17 )
    {
      if ( p_next[1] % bucket_count != v17 % bucket_count )
        goto LABEL_33;
      goto LABEL_32;
    }
    if ( p_next[2] == v17 )
      break;
LABEL_32:
    p_next = (_QWORD *)*p_next;
    if ( !p_next )
      goto LABEL_33;
  }
  v19 = (RBX::Collision::CellChildren *)(p_next[3] + v18 - 4);
LABEL_34:
  v52 = cellIndex->nodeIndex;
  if ( !cellIndex->nodeIndex )
  {
    v53 = &this->children.element0.mData[v17];
    goto LABEL_47;
  }
  if ( (unsigned __int8)v52 <= 2u )
  {
    v53 = &this->children.firstOverflow.mData[v17 - 1].__elems_[v52 + 1];
    goto LABEL_47;
  }
  if ( !this->children.secondOverflow.table_.size_
    || (v54 = this->children.secondOverflow.table_.bucket_count_,
        (v55 = this->children.secondOverflow.table_.buckets_[v17 % v54].next_) == 0)
    || (v56 = &v55->next_->next_) == 0 )
  {
LABEL_46:
    std::logic_error::logic_error((std::logic_error *)v81, "Unable to find key in unordered_map.");
    v81[0] = (char *)&`vtable for'std::out_of_range + 16;
    boost::throw_exception<std::out_of_range>((const std::out_of_range *)v81);
  }
  while ( 2 )
  {
    if ( v56[1] != v17 )
    {
      if ( v56[1] % v54 != v17 % v54 )
        goto LABEL_46;
LABEL_45:
      v56 = (_QWORD *)*v56;
      if ( !v56 )
        goto LABEL_46;
      continue;
    }
    break;
  }
  if ( v56[2] != v17 )
    goto LABEL_45;
  v53 = (std::array<RBX::Collision::CellChildren,2>::value_type *)(v56[3] + v52 - 3);
LABEL_47:
  v53->childMask = v19->childMask;
  if ( this->hasChildren )
  {
LABEL_7:
    v20 = data;
    v21 = mData;
    RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4>::decreaseBinSize(
      &this->children,
      cellIndex->binIndex.data,
      mData[data]);
    mData = v21;
    data = v20;
  }
LABEL_8:
  v22 = &v5[v6];
  v23 = mData[data];
  v24 = v23 == 1;
  v25 = v23 - 1;
  mData[data] = v25;
  if ( v24 )
  {
    ++this->emptyBinCount;
    v33 = v22->coords;
    v34 = (RBX::ArrayDynamic<void *> *)*((_QWORD *)this->pools->coordArrayPool.pools.mData + 1);
    mSize = v34[1].mSize;
    mCapacity = v34[1].mCapacity;
    if ( mCapacity == mSize )
    {
      v24 = mCapacity == 0;
      v37 = mCapacity + 1;
      v38 = 2 * mCapacity;
      v39 = 2;
      if ( !v24 )
        v39 = v38;
      do
      {
        v40 = v39;
        v39 *= 2;
      }
      while ( v40 < v37 );
      RBX::ArrayDynamic<void *>::reserve(v34 + 1, v40);
      mSize = v34[1].mSize;
    }
    v34[1].mData[mSize] = v33;
    v34[1].mSize = mSize + 1;
    v41 = *p_prims;
    v42 = (RBX::ArrayDynamic<void *> *)*((_QWORD *)this->pools->cellPrimitiveArrayPool.pools.mData + 1);
    v43 = v42[1].mSize;
    v44 = v42[1].mCapacity;
    if ( v44 == v43 )
    {
      v24 = v44 == 0;
      v45 = v44 + 1;
      v46 = 2 * v44;
      v47 = 2;
      if ( !v24 )
        v47 = v46;
      do
      {
        v48 = v47;
        v47 *= 2;
      }
      while ( v48 < v45 );
      RBX::ArrayDynamic<void *>::reserve(v42 + 1, v48);
      v43 = v42[1].mSize;
    }
    v42[1].mData[v43] = v41;
    v42[1].mSize = v43 + 1;
    *v22 = 0;
  }
  else if ( (v25 & (unsigned __int8)(v25 - 1)) == 0 )
  {
    v80 = p_prims;
    v82 = v22;
    v26 = v22->coords;
    pools = this->pools;
    v79 = data;
    v78 = mData;
    v28 = (RBX::Collision::CellCoord *)RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::allocate(
                                         &pools->coordArrayPool,
                                         v25);
    v29 = v78;
    v30 = v79;
    v31 = v28;
    if ( v26 )
    {
      if ( v25 == 1 )
      {
        v32 = 0;
        goto LABEL_52;
      }
      v32 = 0;
      v57 = 5;
      do
      {
        *(_DWORD *)((char *)&v28[-1] + v57 * 4 - 8) = *(_DWORD *)((char *)&v26[-1] + v57 * 4 - 8);
        *(_DWORD *)((char *)&v28[-1] + v57 * 4 - 4) = *(_DWORD *)((char *)&v26[-1] + v57 * 4 - 4);
        v28[-1].v[v57] = v26[-1].v[v57];
        v28->v[v57 - 2] = v26->v[v57 - 2];
        v28->v[v57 - 1] = v26->v[v57 - 1];
        v28->v[v57] = v26->v[v57];
        v32 += 2;
        v57 += 6;
      }
      while ( v25 - (unsigned __int64)(v25 & 1) != v32 );
      if ( (v25 & 1) != 0 )
      {
LABEL_52:
        v58 = v32;
        v31[v58].v[0] = v26[v58].v[0];
        v31[v58].v[1] = v26[v58].v[1];
        v31[v58].v[2] = v26[v58].v[2];
      }
      v59 = (RBX::ArrayDynamic<void *> *)pools->coordArrayPool.pools.mData[2 * v25];
      v60 = v59[1].mSize;
      v61 = v59[1].mCapacity;
      if ( v61 == v60 )
      {
        v24 = v61 == 0;
        v62 = v61 + 1;
        v63 = 2 * v61;
        v64 = 2;
        if ( !v24 )
          v64 = v63;
        do
        {
          v65 = v64;
          v64 *= 2;
        }
        while ( v65 < v62 );
        RBX::ArrayDynamic<void *>::reserve(v59 + 1, v65);
        v60 = v59[1].mSize;
        v30 = v79;
        v29 = v78;
      }
      v59[1].mData[v60] = v26;
      v59[1].mSize = v60 + 1;
    }
    v82->coords = v31;
    v66 = *p_prims;
    v67 = v29[v30];
    p_cellPrimitiveArrayPool = &this->pools->cellPrimitiveArrayPool;
    v69 = (RBX::Collision::CellPrimitives *)RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::allocate(
                                              p_cellPrimitiveArrayPool,
                                              v67);
    v70 = v69;
    if ( v66 )
    {
      memcpy(v69, v66, 32 * v67);
      if ( (_BYTE)v67 )
      {
        v71 = (RBX::ArrayDynamic<void *> *)p_cellPrimitiveArrayPool->pools.mData[2 * v67];
        v72 = v71[1].mSize;
        v73 = v71[1].mCapacity;
        if ( v73 == v72 )
        {
          v24 = v73 == 0;
          v74 = v73 + 1;
          v75 = 2 * v73;
          v76 = 2;
          if ( !v24 )
            v76 = v75;
          do
          {
            v77 = v76;
            v76 *= 2;
          }
          while ( v77 < v74 );
          RBX::ArrayDynamic<void *>::reserve(v71 + 1, v77);
          v72 = v71[1].mSize;
        }
        v71[1].mData[v72] = v66;
        v71[1].mSize = v72 + 1;
      }
    }
    *v80 = v70;
  }
}


// Address: 0x1df2b90 | Name: _ZN3RBX9Collision9LevelGrid12CellIterator7releaseEv
void __fastcall RBX::Collision::LevelGrid::CellIterator::release(RBX::Collision::LevelGrid::CellIterator *this)
{
  RBX::Collision::LevelGrid::freeCell(this->container, &this->index);
  this->container = 0;
  this->index.valid = 0;
}


// Address: 0x1df2be0 | Name: _ZNK3RBX9Collision9LevelGrid15nextNonEmptyBinERNS1_8BinIndexE
bool __fastcall RBX::Collision::LevelGrid::nextNonEmptyBin(
        const RBX::Collision::LevelGrid *this,
        RBX::Collision::LevelGrid::BinIndex *bin)
{
  size_t v2; // rax

  v2 = bin->data + 1LL;
  while ( v2 < this->sizes.mSize )
  {
    if ( this->sizes.mData[v2++] != 0 )
    {
      bin->data = v2 - 1;
      return 1;
    }
  }
  return 0;
}


// Address: 0x1df2c10 | Name: _ZNK3RBX9Collision9LevelGrid10totalCellsEv
size_t __fastcall RBX::Collision::LevelGrid::totalCells(const RBX::Collision::LevelGrid *this)
{
  return this->cellCount;
}


// Address: 0x1df2c20 | Name: _ZNK3RBX9Collision9LevelGrid16getBinSizeCountsERNS_12ArrayDynamicImEE
size_t __fastcall RBX::Collision::LevelGrid::getBinSizeCounts(
        const RBX::Collision::LevelGrid *this,
        RBX::ArrayDynamic<unsigned long> *stats)
{
  unsigned __int8 *mData; // rax
  size_t v4; // r14
  size_t v5; // r13
  size_t v6; // rbp
  size_t mSize; // rax
  size_t v8; // r15
  __int64 v9; // r12
  __int64 v10; // rcx
  bool v11; // zf
  size_t v12; // rax
  size_t v13; // rsi

  if ( !this->sizes.mSize )
    return 0;
  mData = this->sizes.mData;
  v4 = 0;
  v5 = 0;
  do
  {
    v6 = mData[v5];
    mSize = stats->mSize;
    if ( mSize <= v6 )
    {
      v8 = v6 + 1 - mSize;
      if ( v6 + 1 != mSize )
      {
        v9 = 0;
        do
        {
          if ( stats->mCapacity == mSize )
          {
            v10 = 2 * mSize;
            v11 = mSize == 0;
            v12 = mSize + 1;
            if ( v11 )
              v10 = 2;
            do
            {
              v13 = v10;
              v10 *= 2;
            }
            while ( v13 < v12 );
            RBX::ArrayDynamic<unsigned long>::reserve(stats, v13);
            mSize = stats->mSize;
          }
          stats->mData[mSize] = 0;
          mSize = stats->mSize + 1;
          stats->mSize = mSize;
          ++v9;
        }
        while ( v9 != v8 );
      }
    }
    mData = this->sizes.mData;
    ++stats->mData[this->sizes.mData[v5]];
    v4 += v6;
    ++v5;
  }
  while ( v5 < this->sizes.mSize );
  return v4;
}


// Address: 0x1df2d10 | Name: _ZNK3RBX9Collision9LevelGrid16getMedianBinSizeEv
size_t __fastcall RBX::Collision::LevelGrid::getMedianBinSize(const RBX::Collision::LevelGrid *this)
{
  __int64 v1; // rax
  bool mNoInit; // bp
  size_t mSize; // r14
  _BYTE *Aligned; // rbx
  size_t v6; // rdx
  unsigned __int8 *mData; // rsi
  __int64 v8; // rax
  __int64 v9; // rdi
  size_t v10; // rbp
  size_t v11; // rcx
  __int64 v12; // rbp
  unsigned __int64 v13; // rax
  size_t v14; // r15
  __int64 v15; // rdx
  __int64 v17; // rax
  __int64 v18; // rdi
  __int64 v19; // [rsp-8h] [rbp-28h] BYREF

  v19 = v1;
  mNoInit = this->sizes.mNoInit;
  mSize = this->sizes.mSize;
  if ( mSize )
  {
    Aligned = RBX::Memory::allocateAligned(this->sizes.mSize, this->sizes.mAlignment);
    if ( !Aligned )
      mSize = 0;
    v6 = this->sizes.mSize;
  }
  else
  {
    v6 = 0;
    mSize = 0;
    Aligned = 0;
  }
  mData = this->sizes.mData;
  if ( mNoInit )
  {
    if ( v6 <= 0x10 )
    {
      if ( v6 )
      {
        v8 = 0;
        if ( (v6 & 3) != 0 )
        {
          v9 = -(__int64)(v6 & 3);
          do
          {
            Aligned[v8] = mData[v8];
            ++v8;
            ++v9;
          }
          while ( v9 );
        }
        if ( v6 - 1 >= 3 )
        {
          do
          {
            Aligned[v8] = mData[v8];
            Aligned[v8 + 1] = mData[v8 + 1];
            Aligned[v8 + 2] = mData[v8 + 2];
            Aligned[v8 + 3] = mData[v8 + 3];
            v8 += 4;
          }
          while ( v6 != v8 );
        }
      }
      goto LABEL_17;
    }
LABEL_16:
    memcpy(Aligned, mData, v6);
    goto LABEL_17;
  }
  if ( v6 > 0x10 )
    goto LABEL_16;
  if ( v6 )
  {
    v17 = 0;
    if ( (v6 & 3) != 0 )
    {
      v18 = -(__int64)(v6 & 3);
      do
      {
        Aligned[v17] = mData[v17];
        ++v17;
        ++v18;
      }
      while ( v18 );
    }
    if ( v6 - 1 >= 3 )
    {
      do
      {
        Aligned[v17] = mData[v17];
        Aligned[v17 + 1] = mData[v17 + 1];
        Aligned[v17 + 2] = mData[v17 + 2];
        Aligned[v17 + 3] = mData[v17 + 3];
        v17 += 4;
      }
      while ( v6 != v17 );
    }
  }
LABEL_17:
  v10 = this->sizes.mSize;
  std::__sort<std::__less<unsigned char,unsigned char> &,unsigned char *>(Aligned, &Aligned[v10], &v19);
  if ( v10 )
  {
    v11 = v10 >> 1;
    v12 = -(__int64)v10;
    v13 = 1;
    v14 = 0;
    while ( v13 < v11 )
    {
      v15 = v13 + v12 + 1;
      ++v13;
      if ( v15 == 1 )
      {
        if ( mSize )
          goto LABEL_26;
        return v14;
      }
    }
    v14 = (unsigned __int8)Aligned[v13 - 1];
    if ( !mSize )
      return v14;
  }
  else
  {
    v14 = 0;
    if ( !mSize )
      return v14;
  }
LABEL_26:
  RBX::Memory::deallocateAligned(Aligned);
  return v14;
}


// Address: 0x1df31e0 | Name: _ZNK3RBX9Collision9LevelGrid18getPrimitiveCountsERNS_12ArrayDynamicImEE
size_t __fastcall RBX::Collision::LevelGrid::getPrimitiveCounts(
        const RBX::Collision::LevelGrid *this,
        RBX::ArrayDynamic<unsigned long> *stats)
{
  size_t mSize; // rcx
  unsigned __int8 *mData; // rax
  size_t v5; // r15
  size_t v6; // rdx
  unsigned __int64 v7; // rbp
  RBX::Collision::CellPrimitives *prims; // rax
  unsigned __int64 v9; // r14
  size_t v10; // rax
  unsigned __int64 v11; // r12
  __int64 i; // r13
  __int64 v13; // rcx
  bool v14; // zf
  size_t v15; // rax
  size_t v16; // rsi
  const RBX::Collision::LevelGrid *v18; // [rsp+8h] [rbp-40h]
  size_t v19; // [rsp+10h] [rbp-38h]

  mSize = this->sizes.mSize;
  if ( !mSize )
    return 0;
  mData = this->sizes.mData;
  v5 = 0;
  v6 = 0;
  v18 = this;
  do
  {
    if ( mData[v6] )
    {
      v7 = 0;
      v19 = v6;
      do
      {
        prims = this->bins.mData[v6].prims;
        v9 = prims[v7].groundedPrims.count + (unsigned __int64)prims[v7].dynamicPrims.count;
        v10 = stats->mSize;
        if ( v10 <= v9 )
        {
          v11 = v9 + 1 - v10;
          if ( v11 )
          {
            for ( i = 0; i != v11; ++i )
            {
              if ( stats->mCapacity == v10 )
              {
                v13 = 2 * v10;
                v14 = v10 == 0;
                v15 = v10 + 1;
                if ( v14 )
                  v13 = 2;
                do
                {
                  v16 = v13;
                  v13 *= 2;
                }
                while ( v16 < v15 );
                RBX::ArrayDynamic<unsigned long>::reserve(stats, v16);
                v10 = stats->mSize;
              }
              stats->mData[v10] = 0;
              v10 = stats->mSize + 1;
              stats->mSize = v10;
            }
          }
        }
        v5 += v9;
        ++stats->mData[v9];
        ++v7;
        this = v18;
        mData = v18->sizes.mData;
        v6 = v19;
      }
      while ( v7 < v18->sizes.mData[v19] );
      mSize = v18->sizes.mSize;
    }
    ++v6;
  }
  while ( v6 < mSize );
  return v5;
}


// Address: 0x1df3320 | Name: _ZN3RBX9Collision9LevelGrid19removeAllPrimitivesEv
void __fastcall RBX::Collision::LevelGrid::removeAllPrimitives(RBX::Collision::LevelGrid *this)
{
  RBX::Collision::LevelGrid *v1; // rbx
  size_t mSize; // rcx
  unsigned __int8 *mData; // rax
  size_t v4; // rbp
  __int64 v5; // r13
  unsigned __int8 v6; // r12
  RBX::Collision::LevelGrid::Bin *v7; // rax
  RBX::Collision::CellPrimitives *prims; // rdi
  __int64 v9; // r14
  unsigned __int64 count; // rax
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *p_heapArray; // r15
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *v12; // rbp
  RBX::Primitive **heapArray; // rbx
  unsigned __int64 v14; // rax
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *v15; // rbp
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *v16; // r15
  RBX::Primitive **v17; // rbx
  unsigned __int64 v18; // rcx
  unsigned __int64 v19; // rdx
  bool v20; // zf
  size_t v21; // r13
  RBX::Collision::LevelGrid::CellIndex cellIndex; // [rsp+8h] [rbp-60h] BYREF
  RBX::Collision::LevelGrid *v23; // [rsp+18h] [rbp-50h]
  RBX::Collision::LevelGrid *v24; // [rsp+20h] [rbp-48h]
  __int64 v25; // [rsp+28h] [rbp-40h]
  size_t v26; // [rsp+30h] [rbp-38h]

  v1 = this;
  mSize = this->sizes.mSize;
  if ( !mSize )
    goto LABEL_32;
  mData = this->sizes.mData;
  v4 = 0;
  while ( !mData[v4] )
  {
    if ( ++v4 >= mSize )
      goto LABEL_32;
  }
  v24 = this;
LABEL_7:
  v5 = (unsigned int)v4;
  if ( !mData[(unsigned int)v4] )
  {
    v20 = 1;
    goto LABEL_27;
  }
  v26 = v4;
  v6 = 0;
  do
  {
    v7 = v1->bins.mData;
    v25 = 16 * v5;
    prims = v7[v5].prims;
    v9 = v6;
    count = prims[v9].groundedPrims.count;
    p_heapArray = (RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *)&prims[v9].groundedPrims.heapArray;
    if ( count >= 2 )
    {
      p_heapArray = (RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *)p_heapArray->heapArray;
    }
    else if ( !(_DWORD)count )
    {
      goto LABEL_16;
    }
    v12 = &p_heapArray[count];
    do
    {
      heapArray = p_heapArray->heapArray;
      *(RBX::ExtentsInt32 *)(heapArray + 11) = *RBX::ExtentsInt32::empty();
      *((_BYTE *)heapArray + 112) = -1;
      ++p_heapArray;
    }
    while ( v12 != p_heapArray );
    v1 = v24;
    prims = v24->bins.mData[(unsigned __int64)v25 / 0x10].prims;
LABEL_16:
    v14 = prims[v9].dynamicPrims.count;
    v15 = (RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *)&prims[v9].dynamicPrims.heapArray;
    if ( v14 >= 2 )
    {
      v15 = (RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *)v15->heapArray;
    }
    else if ( !(_DWORD)v14 )
    {
      goto LABEL_23;
    }
    v16 = &v15[v14];
    do
    {
      v17 = v15->heapArray;
      *(RBX::ExtentsInt32 *)(v17 + 11) = *RBX::ExtentsInt32::empty();
      *((_BYTE *)v17 + 112) = -1;
      ++v15;
    }
    while ( v16 != v15 );
    v1 = v24;
    prims = v24->bins.mData[(unsigned __int64)v25 / 0x10].prims;
LABEL_23:
    RBX::Collision::CellPrimitives::clear(&prims[v9], &v1->pools->primitiveArrayPool);
    mData = v1->sizes.mData;
    v18 = v1->sizes.mData[v5];
    v19 = ++v6;
  }
  while ( v19 < v18 );
  LODWORD(v4) = v26;
  v20 = (_BYTE)v18 == 0;
LABEL_27:
  while ( 1 )
  {
    cellIndex.valid = !v20;
    cellIndex.binIndex.data = v4;
    cellIndex.nodeIndex = 0;
    v23 = v1;
    if ( v20 )
      break;
    RBX::Collision::LevelGrid::freeCell(v1, &cellIndex);
    mData = v1->sizes.mData;
    v20 = v1->sizes.mData[v5] == 0;
  }
  v21 = v5 + 1;
  while ( v21 < v1->sizes.mSize )
  {
    v20 = mData[v21++] == 0;
    if ( !v20 )
    {
      v4 = v21 - 1;
      goto LABEL_7;
    }
  }
LABEL_32:
  if ( stru_2AAF660.value )
    *(_OWORD *)&v1->primitiveCount = 0;
}


// Address: 0x1df3560 | Name: _ZN3RBX9Collision9LevelGrid15allocateCellImpERKNS0_16CellCoordAndHashE
__int64 __fastcall RBX::Collision::LevelGrid::allocateCellImp(
        __int64 a1,
        RBX::Collision::LevelGrid *this,
        const RBX::Collision::CellCoordAndHash *coord,
        double a4,
        double a5)
{
  const RBX::Collision::CellCoordAndHash *v5; // rbx
  __int64 v7; // r14
  size_t v8; // r13
  size_t v9; // r12
  RBX::Collision::LevelGrid::Bin *mData; // rbp
  RBX::Collision::LevelGrid::Bin *v11; // rdx
  unsigned __int8 v12; // al
  RBX::Collision::CellCoord *coords; // rbx
  RBX::Collision::SpatialHashPools *pools; // r14
  RBX::Collision::CellCoord *v15; // rbp
  __int64 v16; // rcx
  __int64 v17; // rsi
  __int64 v18; // rax
  RBX::ArrayDynamic<void *> *v19; // r14
  size_t v20; // rax
  size_t v21; // rcx
  bool v22; // zf
  size_t v23; // rax
  __int64 v24; // rdx
  __int64 v25; // rcx
  size_t v26; // rsi
  const void **p_prims; // rbx
  const void *v28; // rbp
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives> *p_cellPrimitiveArrayPool; // r14
  void *v30; // rax
  RBX::ArrayDynamic<void *> *v31; // rbx
  size_t mSize; // rdx
  size_t mCapacity; // rcx
  size_t v34; // rax
  __int64 v35; // rdx
  __int64 v36; // rcx
  size_t v37; // rsi
  std::array<RBX::Collision::CellChildren,2>::value_type *v38; // rax
  size_t bucket_count; // rsi
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  _QWORD *p_next; // rdi
  RBX::Collision::CellCoord *v42; // rax
  __int64 v43; // rcx
  RBX::Collision::CellPrimitives *prims; // rax
  __int64 v45; // rcx
  RBX::Collision::LevelGrid::Bin *v47; // [rsp+8h] [rbp-80h]
  RBX::Collision::LevelGrid::Bin *v48; // [rsp+10h] [rbp-78h]
  size_t size; // [rsp+18h] [rbp-70h]
  size_t sizea; // [rsp+18h] [rbp-70h]
  __int128 v51; // [rsp+20h] [rbp-68h] BYREF
  void *ptr; // [rsp+30h] [rbp-58h]
  __int64 v53; // [rsp+38h] [rbp-50h]
  const void **v54; // [rsp+40h] [rbp-48h]
  const RBX::Collision::CellCoordAndHash *v55; // [rsp+48h] [rbp-40h]
  __int64 v56; // [rsp+50h] [rbp-38h]

  v5 = coord;
  v7 = a1;
  v8 = coord->hashData.h & (unsigned int)(LODWORD(this->sizes.mSize) - 1);
  v9 = this->sizes.mData[v8];
  mData = this->bins.mData;
  if ( v9 >= 0x7F && !this->largeBinSizeReported )
  {
    this->largeBinSizeReported = 1;
    ptr = operator new(0x20u);
    v51 = xmmword_3E8C30;
    strcpy((char *)ptr, "level-grid-max-bin-size");
    RBX::Analytics::EphemeralCounter::reportStats((const std::string *)&v51, (double)(unsigned __int8)v9, a5, 0);
    if ( (v51 & 1) != 0 )
      operator delete(ptr);
  }
  v53 = 16 * v8;
  v11 = &mData[v8];
  v48 = mData;
  v47 = v11;
  if ( ((unsigned __int8)v9 & (unsigned __int8)(v9 - 1)) == 0 )
  {
    v56 = a1;
    v12 = 1;
    if ( 2 * (_BYTE)v9 )
      v12 = 2 * v9;
    v55 = v5;
    coords = v11->coords;
    pools = this->pools;
    size = v12;
    v15 = (RBX::Collision::CellCoord *)RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::allocate(
                                         &pools->coordArrayPool,
                                         v12);
    if ( !coords || !(_BYTE)v9 )
    {
LABEL_24:
      v47->coords = v15;
      p_prims = (const void **)&v48[(unsigned __int64)v53 / 0x10].prims;
      v28 = *p_prims;
      p_cellPrimitiveArrayPool = &this->pools->cellPrimitiveArrayPool;
      v30 = RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::allocate(p_cellPrimitiveArrayPool, size);
      if ( v28 )
      {
        sizea = (size_t)v30;
        memcpy(v30, v28, 32 * v9);
        v30 = (void *)sizea;
        if ( (_BYTE)v9 )
        {
          v54 = p_prims;
          v31 = (RBX::ArrayDynamic<void *> *)p_cellPrimitiveArrayPool->pools.mData[v9];
          mSize = v31[1].mSize;
          mCapacity = v31[1].mCapacity;
          if ( mCapacity == mSize )
          {
            v22 = mCapacity == 0;
            v34 = mCapacity + 1;
            v35 = 2 * mCapacity;
            v36 = 2;
            if ( !v22 )
              v36 = v35;
            do
            {
              v37 = v36;
              v36 *= 2;
            }
            while ( v37 < v34 );
            RBX::ArrayDynamic<void *>::reserve(v31 + 1, v37);
            mSize = v31[1].mSize;
            v30 = (void *)sizea;
          }
          v31[1].mData[mSize] = (void *)v28;
          v31[1].mSize = mSize + 1;
          p_prims = v54;
        }
      }
      *p_prims = v30;
      v7 = v56;
      v5 = v55;
      mData = v48;
      v11 = v47;
      if ( !this->hasChildren )
        goto LABEL_47;
      goto LABEL_33;
    }
    if ( (_BYTE)v9 == 1 )
    {
      v16 = 0;
    }
    else
    {
      v16 = 0;
      v17 = 5;
      do
      {
        *(_DWORD *)((char *)&v15[-1] + v17 * 4 - 8) = *(_DWORD *)((char *)&coords[-1] + v17 * 4 - 8);
        *(_DWORD *)((char *)&v15[-1] + v17 * 4 - 4) = *(_DWORD *)((char *)&coords[-1] + v17 * 4 - 4);
        v15[-1].v[v17] = coords[-1].v[v17];
        v15->v[v17 - 2] = coords->v[v17 - 2];
        v15->v[v17 - 1] = coords->v[v17 - 1];
        v15->v[v17] = coords->v[v17];
        v16 += 2;
        v17 += 6;
      }
      while ( v9 - (v9 & 1) != v16 );
      if ( (v9 & 1) == 0 )
        goto LABEL_18;
    }
    v18 = v16;
    v15[v18].v[0] = coords[v18].v[0];
    v15[v18].v[1] = coords[v18].v[1];
    v15[v18].v[2] = coords[v18].v[2];
LABEL_18:
    v19 = (RBX::ArrayDynamic<void *> *)pools->coordArrayPool.pools.mData[v9];
    v20 = v19[1].mSize;
    v21 = v19[1].mCapacity;
    if ( v21 == v20 )
    {
      v22 = v21 == 0;
      v23 = v21 + 1;
      v24 = 2 * v21;
      v25 = 2;
      if ( !v22 )
        v25 = v24;
      do
      {
        v26 = v25;
        v25 *= 2;
      }
      while ( v26 < v23 );
      RBX::ArrayDynamic<void *>::reserve(v19 + 1, v26);
      v20 = v19[1].mSize;
    }
    v19[1].mData[v20] = coords;
    v19[1].mSize = v20 + 1;
    goto LABEL_24;
  }
  if ( !this->hasChildren )
    goto LABEL_47;
LABEL_33:
  RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4>::increaseBinSize(&this->children, v8, v9);
  if ( !(_BYTE)v9 )
  {
    v38 = &this->children.element0.mData[v8];
    mData = v48;
    goto LABEL_46;
  }
  if ( (unsigned __int8)v9 <= 2u )
  {
    v38 = &this->children.firstOverflow.mData[v8 - 1].__elems_[v9 + 1];
    mData = v48;
    goto LABEL_46;
  }
  mData = v48;
  if ( !this->children.secondOverflow.table_.size_
    || (bucket_count = this->children.secondOverflow.table_.bucket_count_,
        (next = this->children.secondOverflow.table_.buckets_[v8 % bucket_count].next_) == 0)
    || (p_next = &next->next_->next_) == 0 )
  {
LABEL_45:
    std::logic_error::logic_error((std::logic_error *)&v51, "Unable to find key in unordered_map.");
    *(_QWORD *)&v51 = (char *)&`vtable for'std::out_of_range + 16;
    boost::throw_exception<std::out_of_range>((const std::out_of_range *)&v51);
  }
  while ( 1 )
  {
    if ( p_next[1] != v8 )
    {
      if ( p_next[1] % bucket_count != v8 % bucket_count )
        goto LABEL_45;
      goto LABEL_44;
    }
    if ( p_next[2] == v8 )
      break;
LABEL_44:
    p_next = (_QWORD *)*p_next;
    if ( !p_next )
      goto LABEL_45;
  }
  v38 = (std::array<RBX::Collision::CellChildren,2>::value_type *)(v9 + p_next[3] - 3);
LABEL_46:
  v11 = v47;
  v38->childMask = 0;
LABEL_47:
  v42 = v11->coords;
  v43 = v9;
  v42[v43].v[0] = v5->coordData.v[0];
  v42[v43].v[1] = v5->coordData.v[1];
  v42[v43].v[2] = v5->coordData.v[2];
  prims = mData[(unsigned __int64)v53 / 0x10].prims;
  v45 = v9;
  prims[v45].dynamicPrims = 0;
  prims[v45].groundedPrims = 0;
  ++this->sizes.mData[v8];
  ++this->cellCount;
  if ( !(_BYTE)v9 )
    --this->emptyBinCount;
  *(_BYTE *)v7 = 1;
  *(_DWORD *)(v7 + 4) = v8;
  *(_BYTE *)(v7 + 8) = v9;
  return v7;
}


// Address: 0x1df3a00 | Name: _ZNK3RBX9Collision9LevelGrid14firstCellIndexENS1_8BinIndexE
const RBX::Collision::LevelGrid *__fastcall RBX::Collision::LevelGrid::firstCellIndex(
        const RBX::Collision::LevelGrid *this,
        _QWORD *bin,
        unsigned int *a3)
{
  __int64 v3; // rax
  _BYTE *p_mSize; // rax

  v3 = *a3;
  if ( *(_BYTE *)(*bin + v3) )
  {
    LOBYTE(this->sizes.mData) = 1;
    HIDWORD(this->sizes.mData) = v3;
    p_mSize = &this->sizes.mSize;
  }
  else
  {
    p_mSize = this;
  }
  *p_mSize = 0;
  return this;
}


// Address: 0x1df3a30 | Name: _ZNK3RBX9Collision9LevelGrid13nextCellIndexERKNS1_9CellIndexE
__int64 __fastcall RBX::Collision::LevelGrid::nextCellIndex(
        __int64 a1,
        const RBX::Collision::LevelGrid *this,
        const RBX::Collision::LevelGrid::CellIndex *n)
{
  __int64 data; // r8
  __int64 nodeIndex; // rcx

  data = n->binIndex.data;
  nodeIndex = n->nodeIndex;
  if ( nodeIndex + 1 >= (unsigned __int64)this->sizes.mData[data] )
  {
    *(_BYTE *)a1 = 0;
  }
  else
  {
    *(_BYTE *)a1 = n->valid;
    *(_DWORD *)(a1 + 4) = data;
    *(_BYTE *)(a1 + 8) = nodeIndex + 1;
  }
  return a1;
}


// Address: 0x1df3b30 | Name: _ZNK3RBX9Collision9LevelGrid16nextNonEmptyCellERKNS1_9CellIndexE
__int64 __fastcall RBX::Collision::LevelGrid::nextNonEmptyCell(
        __int64 a1,
        const RBX::Collision::LevelGrid *this,
        const RBX::Collision::LevelGrid::CellIndex *index)
{
  int nodeIndex; // r10d
  __int64 data; // r8
  size_t v6; // rcx

  nodeIndex = index->nodeIndex;
  data = index->binIndex.data;
  if ( nodeIndex + 1 >= (unsigned int)this->sizes.mData[data] )
  {
    v6 = data + 1;
    while ( v6 < this->sizes.mSize )
    {
      if ( this->sizes.mData[v6++] != 0 )
      {
        *(_BYTE *)a1 = 1;
        *(_DWORD *)(a1 + 4) = v6 - 1;
        *(_BYTE *)(a1 + 8) = 0;
        return a1;
      }
    }
    *(_BYTE *)a1 = 0;
    return a1;
  }
  else
  {
    *(_BYTE *)a1 = index->valid;
    *(_DWORD *)(a1 + 4) = data;
    *(_BYTE *)(a1 + 8) = nodeIndex + 1;
    return a1;
  }
}


// Address: 0x1df3ba0 | Name: _ZN3RBX9Collision9LevelGrid6rehashEmPNS0_16SpatialHashPoolsE
RBX::Collision::LevelGrid *__fastcall RBX::Collision::LevelGrid::rehash(
        RBX::Collision::LevelGrid *this,
        size_t newBinCount,
        RBX::Collision::SpatialHashPools *pools)
{
  RBX::Collision::CellBinIndexType v3; // r15d
  double v4; // xmm0_8
  double v5; // xmm1_8
  char *v7; // r14
  size_t mSize; // rcx
  size_t v9; // rax
  RBX::Collision::LevelGrid::BinSizeType v10; // bp
  RBX::Collision::CellBinIndexType data; // eax
  RBX::Collision::LevelGrid::BinSizeType nodeIndex; // cl
  RBX::Collision::CellChildren *Children; // rbx
  RBX::Collision::LevelGrid *v14; // rdx
  RBX::Collision::CellPrimitives *prims; // rax
  RBX::Collision::CellPrimitives *v16; // rdx
  __int64 v17; // rsi
  uint32_t count; // ebx
  __int64 v19; // rcx
  uint32_t v20; // ebx
  char valid; // cl
  RBX::Collision::LevelGrid::CellIndex v24; // [rsp+0h] [rbp-78h] BYREF
  RBX::Collision::LevelGrid::CellIndex n; // [rsp+10h] [rbp-68h] BYREF
  RBX::Collision::LevelGrid *v26; // [rsp+20h] [rbp-58h]
  RBX::Collision::LevelGrid::CellIndex v27; // [rsp+28h] [rbp-50h] BYREF
  RBX::Collision::CellCoordAndHash coord; // [rsp+38h] [rbp-40h] BYREF

  v7 = (char *)operator new(0xE8u);
  RBX::Collision::LevelGrid::LevelGrid((RBX::Collision::LevelGrid *)v7, newBinCount, pools, this->hasChildren);
  mSize = this->sizes.mSize;
  if ( mSize )
  {
    v9 = 0;
    while ( !this->sizes.mData[v9] )
    {
      if ( ++v9 >= mSize )
        goto LABEL_25;
    }
    v24.valid = 1;
    v24.binIndex.data = v9;
    v24.nodeIndex = 0;
    v10 = 0;
    while ( 1 )
    {
      coord.coordData = this->bins.mData[(unsigned int)v9].coords[v10];
      coord.hashData.h = (73856093 * coord.coordData.v[0])
                       ^ (19349663 * coord.coordData.v[1])
                       ^ (83492791 * coord.coordData.v[2]);
      RBX::Collision::LevelGrid::allocateCellImp((__int64)&v27, (RBX::Collision::LevelGrid *)v7, &coord, v4, v5);
      n = v27;
      data = v27.binIndex.data;
      nodeIndex = v27.nodeIndex;
      v26 = (RBX::Collision::LevelGrid *)v7;
      if ( this->hasChildren )
      {
        Children = RBX::Collision::LevelGrid::getChildren(this, &v24);
        RBX::Collision::LevelGrid::getChildren(v26, &n)->childMask = Children->childMask;
        v14 = v26;
        data = n.binIndex.data;
        nodeIndex = n.nodeIndex;
      }
      else
      {
        v14 = (RBX::Collision::LevelGrid *)v7;
      }
      prims = v14->bins.mData[data].prims;
      v16 = this->bins.mData[v24.binIndex.data].prims;
      v17 = v24.nodeIndex;
      count = v16[v17].groundedPrims.count;
      v19 = nodeIndex;
      prims[v19].groundedPrims.count = count;
      if ( count )
      {
        prims[v19].groundedPrims.heapArray = v16[v17].groundedPrims.heapArray;
        if ( count != 1 )
          v16[v17].groundedPrims.heapArray = 0;
      }
      v16[v17].groundedPrims.count = 0;
      v20 = v16[v17].dynamicPrims.count;
      prims[v19].dynamicPrims.count = v20;
      if ( v20 )
      {
        prims[v19].dynamicPrims.heapArray = v16[v17].dynamicPrims.heapArray;
        if ( v20 != 1 )
          v16[v17].dynamicPrims.heapArray = 0;
      }
      v16[v17].dynamicPrims.count = 0;
      LODWORD(v9) = v24.binIndex.data;
      if ( (unsigned int)v24.nodeIndex + 1 >= this->sizes.mData[v24.binIndex.data] )
        break;
      valid = v24.valid;
      v10 = v24.nodeIndex + 1;
LABEL_22:
      v24.binIndex.data = v9;
      v24.nodeIndex = v10;
      v24.valid = valid;
      v3 = v9;
      if ( !valid )
        goto LABEL_26;
    }
    v9 = v24.binIndex.data + 1LL;
    while ( v9 < this->sizes.mSize )
    {
      if ( this->sizes.mData[v9++] != 0 )
      {
        LODWORD(v9) = v9 - 1;
        valid = 1;
        v10 = 0;
        goto LABEL_22;
      }
    }
    v24.binIndex.data = v3;
    v24.nodeIndex = v10;
  }
LABEL_25:
  v24.valid = 0;
LABEL_26:
  if ( stru_2AAF660.value )
  {
    *(_OWORD *)(v7 + 184) = *(_OWORD *)&this->primitiveCount;
    *(_OWORD *)&this->primitiveCount = 0;
  }
  return (RBX::Collision::LevelGrid *)v7;
}


// Address: 0x1df3e50 | Name: _ZN3RBX9Collision9LevelGrid13render3dAdornEPNS_5AdornERKN3G3D6Color4Ef
void __fastcall RBX::Collision::LevelGrid::render3dAdorn(
        RBX::Collision::LevelGrid *this,
        RBX::Adorn *adorn,
        const RBX::Color4 *color,
        float cellSize)
{
  size_t mSize; // rax
  size_t v6; // rbx
  unsigned __int8 i; // bp
  RBX::Collision::LevelGrid::Bin *mData; // rax
  RBX::Collision::CellPrimitives *prims; // rdx
  RBX::Collision::CellCoord *coords; // rax
  __m128 v11; // xmm0
  __m128 v12; // xmm4
  float v13; // xmm1_4
  __m128 v14; // xmm2
  __m128 v15; // xmm5
  float v16; // xmm9_4
  float v17; // xmm7_4
  float v18; // xmm8_4
  __int64 v21; // [rsp+10h] [rbp-48h] BYREF
  float v22; // [rsp+18h] [rbp-40h]
  __int64 v23; // [rsp+1Ch] [rbp-3Ch] BYREF
  float v24; // [rsp+24h] [rbp-34h]

  mSize = this->sizes.mSize;
  if ( mSize )
  {
    v6 = 0;
    while ( !this->sizes.mData[v6] )
    {
      if ( ++v6 >= mSize )
        return;
    }
LABEL_6:
    for ( i = 0; ; ++i )
    {
      mData = this->bins.mData;
      prims = mData[(unsigned int)v6].prims;
      if ( prims[i].groundedPrims.count + (unsigned __int64)prims[i].dynamicPrims.count )
      {
        coords = mData[(unsigned int)v6].coords;
        v11 = 0;
        v12 = 0;
        v11.m128_f32[0] = (float)coords[i].v[0] * cellSize;
        v12.m128_f32[0] = (float)coords[i].v[1] * cellSize;
        v13 = (float)coords[i].v[2] * cellSize;
        v14 = v11;
        v14.m128_f32[0] = v11.m128_f32[0] + cellSize;
        v15 = v12;
        v15.m128_f32[0] = v12.m128_f32[0] + cellSize;
        v16 = (float)(v11.m128_f32[0] + (float)(v11.m128_f32[0] + cellSize)) * 0.5;
        v17 = (float)(v12.m128_f32[0] + (float)(v12.m128_f32[0] + cellSize)) * 0.5;
        v18 = (float)(v13 + (float)(v13 + cellSize)) * 0.5;
        v11.m128_f32[0] = (float)((float)(v11.m128_f32[0] - v16) * 0.99000001) + v16;
        v12.m128_f32[0] = (float)((float)(v12.m128_f32[0] - v17) * 0.99000001) + v17;
        v14.m128_f32[0] = (float)((float)(v14.m128_f32[0] - v16) * 0.99000001) + v16;
        v15.m128_f32[0] = (float)((float)(v15.m128_f32[0] - v17) * 0.99000001) + v17;
        _mm_storel_ps((double *)&v21, _mm_unpacklo_ps(v11, v12));
        v22 = (float)((float)(v13 - v18) * 0.99000001) + v18;
        _mm_storel_ps((double *)&v23, _mm_unpacklo_ps(v14, v15));
        v24 = (float)((float)((float)(v13 + cellSize) - v18) * 0.99000001) + v18;
        (*(void (__fastcall **)(RBX::Adorn *, __int64 *, const RBX::Color4 *))(*(_QWORD *)adorn + 184LL))(
          adorn,
          &v21,
          color);
      }
      if ( (unsigned int)i + 1 >= this->sizes.mData[(unsigned int)v6] )
        break;
    }
    v6 = (unsigned int)v6 + 1LL;
    while ( v6 < this->sizes.mSize )
    {
      if ( this->sizes.mData[v6++] != 0 )
      {
        LODWORD(v6) = v6 - 1;
        goto LABEL_6;
      }
    }
  }
}


// Address: 0x1df4030 | Name: _ZN3RBX9Collision13GridHierarchyC2Emi
void __fastcall RBX::Collision::GridHierarchy::GridHierarchy(
        RBX::Collision::GridHierarchy *this,
        size_t levelCount,
        int initBinCountLowestLevel)
{
  double v3; // xmm2_8
  RBX::Collision::GridHierarchy *v4; // r12
  char *v5; // rax
  bool v6; // cf
  size_t v7; // rbx
  int *v8; // r13
  RBX::Collision::LevelGrid *v9; // rbp
  size_t v10; // rsi
  size_t v11; // rbp
  __int64 v12; // rax
  __int64 v13; // rax
  _BYTE *v14; // rsi
  unsigned __int64 v15; // rdx
  int *v16; // r12
  __int64 v17; // rax
  RBX::Collision::StatReporter *v18; // r13
  __int64 v19; // rax
  RBX::Collision::StatReporter *v20; // rbp
  __int64 v21; // rax
  __int64 v22; // rax
  _BYTE *v23; // rsi
  unsigned __int64 v24; // rdx
  __int64 v25; // rax
  __int64 v26; // rax
  __int64 v27; // rax
  __int64 v28; // rax
  _BYTE *v29; // rsi
  unsigned __int64 v30; // rdx
  __int64 v31; // rax
  __int64 v32; // rax
  __int64 v33; // rax
  __int64 v34; // rax
  _BYTE *v35; // rsi
  unsigned __int64 v36; // rdx
  __int64 v37; // rax
  __int64 v38; // rax
  __int64 v39; // rax
  __int64 v40; // rax
  _BYTE *v41; // rsi
  unsigned __int64 v42; // rdx
  __int64 v43; // rax
  __int64 v44; // rax
  __int64 v45; // rax
  __int64 v46; // rax
  unsigned __int8 v47; // [rsp+8h] [rbp-2C0h] BYREF
  _BYTE v48[7]; // [rsp+9h] [rbp-2BFh] BYREF
  unsigned __int64 v49; // [rsp+10h] [rbp-2B8h]
  void *v50; // [rsp+18h] [rbp-2B0h]
  __int128 v51; // [rsp+20h] [rbp-2A8h] BYREF
  void *v52; // [rsp+30h] [rbp-298h]
  __int128 v53; // [rsp+40h] [rbp-288h] BYREF
  void *v54; // [rsp+50h] [rbp-278h]
  __int128 v55; // [rsp+60h] [rbp-268h] BYREF
  void *v56; // [rsp+70h] [rbp-258h]
  RBX::Collision::GridHierarchy *v57; // [rsp+80h] [rbp-248h]
  int v58; // [rsp+88h] [rbp-240h] BYREF
  void *v59; // [rsp+98h] [rbp-230h]
  RBX::Collision::StatReporter *p_levelStatReporter; // [rsp+A0h] [rbp-228h]
  size_t v61; // [rsp+A8h] [rbp-220h]
  __int128 v62; // [rsp+B0h] [rbp-218h] BYREF
  void *v63; // [rsp+C0h] [rbp-208h]
  __int128 v64; // [rsp+D0h] [rbp-1F8h] BYREF
  void *v65; // [rsp+E0h] [rbp-1E8h]
  __int128 v66; // [rsp+F0h] [rbp-1D8h] BYREF
  void *v67; // [rsp+100h] [rbp-1C8h]
  __int128 v68; // [rsp+110h] [rbp-1B8h] BYREF
  void *ptr; // [rsp+120h] [rbp-1A8h]
  __int128 v70; // [rsp+130h] [rbp-198h] BYREF
  void *v71; // [rsp+140h] [rbp-188h]
  __int128 v72; // [rsp+150h] [rbp-178h] BYREF
  void *v73; // [rsp+160h] [rbp-168h]
  RBX::Collision::StatReporter *p_computeExtentsDtReporter; // [rsp+168h] [rbp-160h]
  _QWORD v75[4]; // [rsp+170h] [rbp-158h] BYREF
  _QWORD *v76; // [rsp+190h] [rbp-138h]
  _QWORD v77[4]; // [rsp+1A0h] [rbp-128h] BYREF
  _QWORD *v78; // [rsp+1C0h] [rbp-108h]
  _QWORD v79[4]; // [rsp+1D0h] [rbp-F8h] BYREF
  _QWORD *v80; // [rsp+1F0h] [rbp-D8h]
  _QWORD v81[4]; // [rsp+200h] [rbp-C8h] BYREF
  _QWORD *v82; // [rsp+220h] [rbp-A8h]
  _QWORD v83[4]; // [rsp+230h] [rbp-98h] BYREF
  _QWORD *v84; // [rsp+250h] [rbp-78h]
  _QWORD v85[4]; // [rsp+260h] [rbp-68h] BYREF
  _QWORD *v86; // [rsp+280h] [rbp-48h]
  unsigned __int64 v87; // [rsp+290h] [rbp-38h]

  v4 = this;
  v87 = __readfsqword(0x28u);
  *(_OWORD *)((char *)&this->levels.mSize + 1) = 0;
  this->levels.RBX::ArrayBase<RBX::Collision::LevelGrid *> = 0;
  this->levels.mAlignment = 16;
  this->lowestLevelInitBinCount = initBinCountLowestLevel;
  this->levelExpansionFactor = 4;
  *(_QWORD *)&this->highestDensityThreshold = 0x3E4CCCCD3F99999ALL;
  RBX::Collision::StatReporter::StatReporter(&this->computeExtentsDtReporter, (double)dword_2868B98, v3, attemptRate);
  *(_OWORD *)&this->computeExtentsDtAverager.average = 0;
  *(_OWORD *)&this->computeExtentsDtAverager.minValue = xmmword_3E6E10;
  p_levelStatReporter = &this->levelStatReporter;
  RBX::Collision::StatReporter::StatReporter(&this->levelStatReporter, (double)dword_2868B98, v3, dword_2868BA8);
  this->maxNumberOfBinsInLevel = 1LL << byte_2868B58;
  v5 = (char *)operator new(0x60u);
  *(_OWORD *)(v5 + 9) = 0;
  *(_OWORD *)v5 = 0;
  *((_DWORD *)v5 + 7) = 16;
  *(_OWORD *)(v5 + 41) = 0;
  *((_OWORD *)v5 + 2) = 0;
  *((_DWORD *)v5 + 15) = 16;
  *(_OWORD *)(v5 + 73) = 0;
  *((_OWORD *)v5 + 4) = 0;
  *((_DWORD *)v5 + 23) = 16;
  this->pools = (RBX::Collision::SpatialHashPools *)v5;
  v6 = this->levels.mSize < levelCount;
  v57 = this;
  p_computeExtentsDtReporter = &this->computeExtentsDtReporter;
  if ( v6 )
  {
    if ( this->levels.mCapacity >= levelCount
      || (RBX::ArrayDynamic<RBX::Collision::LevelGrid *>::reserve(&this->levels, levelCount),
          this->levels.mCapacity >= levelCount) )
    {
      this->levels.mSize = levelCount;
    }
    else if ( !this->levels.mSize )
    {
      goto LABEL_118;
    }
    goto LABEL_9;
  }
  this->levels.mSize = levelCount;
  if ( levelCount )
  {
LABEL_9:
    v7 = 0;
    v8 = &v58;
    do
    {
      v9 = (RBX::Collision::LevelGrid *)operator new(0xE8u);
      v10 = 1;
      if ( v4->lowestLevelInitBinCount >> v7 > 1 )
        v10 = v4->lowestLevelInitBinCount >> v7;
      if ( !stru_2A95018.value )
        v10 = v4->lowestLevelInitBinCount >> v7;
      RBX::Collision::LevelGrid::LevelGrid(v9, v10, v4->pools, v7 != 0);
      v4->levels.mData[v7] = v9;
      if ( !stru_2AAF660.value )
        goto LABEL_117;
      v11 = v7;
      if ( stru_2AAF618.value )
        v11 = (int)v7 + dword_2868B08 - 3;
      std::to_string((int)v8);
      v12 = std::string::insert(v8, 0, "SH-Level-");
      v56 = *(void **)(v12 + 16);
      v55 = *(_OWORD *)v12;
      *(_OWORD *)v12 = 0;
      *(_QWORD *)(v12 + 16) = 0;
      v13 = std::string::append(&v55, "-Bin-Count-");
      v54 = *(void **)(v13 + 16);
      v53 = *(_OWORD *)v13;
      *(_OWORD *)v13 = 0;
      *(_QWORD *)(v13 + 16) = 0;
      RBX::SystemUtil::osPlatform((RBX::SystemUtil *)&v47);
      if ( (v47 & 1) != 0 )
      {
        v14 = v50;
        v15 = v49;
      }
      else
      {
        v15 = (unsigned __int64)v47 >> 1;
        v14 = v48;
      }
      v16 = v8;
      v17 = std::string::append(&v53, v14, v15);
      v18 = p_levelStatReporter;
      v52 = *(void **)(v17 + 16);
      v51 = *(_OWORD *)v17;
      *(_OWORD *)v17 = 0;
      *(_QWORD *)(v17 + 16) = 0;
      v19 = std::string::append(&v51, "-RCC");
      v73 = *(void **)(v19 + 16);
      v72 = *(_OWORD *)v19;
      *(_OWORD *)v19 = 0;
      *(_QWORD *)(v19 + 16) = 0;
      v85[0] = &off_299E4E8;
      v85[1] = v57;
      v85[2] = v7;
      v86 = v85;
      RBX::Collision::StatReporter::addStat(v18, &v72, v85);
      v61 = v11;
      if ( v85 == v86 )
      {
        (*(void (__fastcall **)(_QWORD *))(*v86 + 32LL))(v86);
        v20 = v18;
      }
      else
      {
        v20 = v18;
        if ( v86 )
          (*(void (**)(void))(*v86 + 40LL))();
      }
      v8 = v16;
      if ( (v72 & 1) != 0 )
        operator delete(v73);
      v4 = v57;
      if ( (v51 & 1) != 0 )
      {
        operator delete(v52);
        if ( (v47 & 1) == 0 )
        {
LABEL_49:
          if ( (v53 & 1) == 0 )
            goto LABEL_50;
          goto LABEL_57;
        }
      }
      else if ( (v47 & 1) == 0 )
      {
        goto LABEL_49;
      }
      operator delete(v50);
      if ( (v53 & 1) == 0 )
      {
LABEL_50:
        if ( (v55 & 1) == 0 )
          goto LABEL_51;
        goto LABEL_58;
      }
LABEL_57:
      operator delete(v54);
      if ( (v55 & 1) == 0 )
      {
LABEL_51:
        if ( (v58 & 1) == 0 )
          goto LABEL_53;
LABEL_52:
        operator delete(v59);
        goto LABEL_53;
      }
LABEL_58:
      operator delete(v56);
      if ( (v58 & 1) != 0 )
        goto LABEL_52;
LABEL_53:
      std::to_string((int)v8);
      v21 = std::string::insert(v8, 0, "SH-Level-");
      v56 = *(void **)(v21 + 16);
      v55 = *(_OWORD *)v21;
      *(_OWORD *)v21 = 0;
      *(_QWORD *)(v21 + 16) = 0;
      v22 = std::string::append(&v55, "-Cell-Count-");
      v54 = *(void **)(v22 + 16);
      v53 = *(_OWORD *)v22;
      *(_OWORD *)v22 = 0;
      *(_QWORD *)(v22 + 16) = 0;
      RBX::SystemUtil::osPlatform((RBX::SystemUtil *)&v47);
      if ( (v47 & 1) != 0 )
      {
        v23 = v50;
        v24 = v49;
      }
      else
      {
        v24 = (unsigned __int64)v47 >> 1;
        v23 = v48;
      }
      v25 = std::string::append(&v53, v23, v24);
      v52 = *(void **)(v25 + 16);
      v51 = *(_OWORD *)v25;
      *(_OWORD *)v25 = 0;
      *(_QWORD *)(v25 + 16) = 0;
      v26 = std::string::append(&v51, "-RCC");
      v71 = *(void **)(v26 + 16);
      v70 = *(_OWORD *)v26;
      *(_OWORD *)v26 = 0;
      *(_QWORD *)(v26 + 16) = 0;
      v83[0] = &off_299E568;
      v83[1] = v4;
      v83[2] = v7;
      v84 = v83;
      RBX::Collision::StatReporter::addStat(v20, &v70, v83);
      if ( v83 == v84 )
      {
        (*(void (__fastcall **)(_QWORD *))(*v84 + 32LL))(v84);
      }
      else if ( v84 )
      {
        (*(void (**)(void))(*v84 + 40LL))();
      }
      if ( (v70 & 1) != 0 )
        operator delete(v71);
      if ( (v51 & 1) != 0 )
      {
        operator delete(v52);
        if ( (v47 & 1) == 0 )
        {
LABEL_69:
          if ( (v53 & 1) == 0 )
            goto LABEL_70;
          goto LABEL_77;
        }
      }
      else if ( (v47 & 1) == 0 )
      {
        goto LABEL_69;
      }
      operator delete(v50);
      if ( (v53 & 1) == 0 )
      {
LABEL_70:
        if ( (v55 & 1) == 0 )
          goto LABEL_71;
        goto LABEL_78;
      }
LABEL_77:
      operator delete(v54);
      if ( (v55 & 1) == 0 )
      {
LABEL_71:
        if ( (v58 & 1) == 0 )
          goto LABEL_73;
LABEL_72:
        operator delete(v59);
        goto LABEL_73;
      }
LABEL_78:
      operator delete(v56);
      if ( (v58 & 1) != 0 )
        goto LABEL_72;
LABEL_73:
      std::to_string((int)v8);
      v27 = std::string::insert(v8, 0, "SH-Level-");
      v56 = *(void **)(v27 + 16);
      v55 = *(_OWORD *)v27;
      *(_OWORD *)v27 = 0;
      *(_QWORD *)(v27 + 16) = 0;
      v28 = std::string::append(&v55, "-Cell-Prim-Count-");
      v54 = *(void **)(v28 + 16);
      v53 = *(_OWORD *)v28;
      *(_OWORD *)v28 = 0;
      *(_QWORD *)(v28 + 16) = 0;
      RBX::SystemUtil::osPlatform((RBX::SystemUtil *)&v47);
      if ( (v47 & 1) != 0 )
      {
        v29 = v50;
        v30 = v49;
      }
      else
      {
        v30 = (unsigned __int64)v47 >> 1;
        v29 = v48;
      }
      v31 = std::string::append(&v53, v29, v30);
      v52 = *(void **)(v31 + 16);
      v51 = *(_OWORD *)v31;
      *(_OWORD *)v31 = 0;
      *(_QWORD *)(v31 + 16) = 0;
      v32 = std::string::append(&v51, "-RCC");
      ptr = *(void **)(v32 + 16);
      v68 = *(_OWORD *)v32;
      *(_OWORD *)v32 = 0;
      *(_QWORD *)(v32 + 16) = 0;
      v81[0] = &off_299E5E8;
      v81[1] = v4;
      v81[2] = v7;
      v82 = v81;
      RBX::Collision::StatReporter::addStat(p_levelStatReporter, &v68, v81);
      if ( v81 == v82 )
      {
        (*(void (__fastcall **)(_QWORD *))(*v82 + 32LL))(v82);
        if ( (v68 & 1) != 0 )
          goto LABEL_11;
      }
      else
      {
        if ( v82 )
          (*(void (**)(void))(*v82 + 40LL))();
        if ( (v68 & 1) != 0 )
        {
LABEL_11:
          operator delete(ptr);
          if ( (v51 & 1) != 0 )
            goto LABEL_12;
          goto LABEL_86;
        }
      }
      if ( (v51 & 1) != 0 )
      {
LABEL_12:
        operator delete(v52);
        if ( (v47 & 1) != 0 )
          goto LABEL_13;
        goto LABEL_87;
      }
LABEL_86:
      if ( (v47 & 1) != 0 )
      {
LABEL_13:
        operator delete(v50);
        if ( (v53 & 1) != 0 )
          goto LABEL_14;
        goto LABEL_88;
      }
LABEL_87:
      if ( (v53 & 1) != 0 )
      {
LABEL_14:
        operator delete(v54);
        if ( (v55 & 1) == 0 )
          goto LABEL_89;
        goto LABEL_15;
      }
LABEL_88:
      if ( (v55 & 1) == 0 )
      {
LABEL_89:
        if ( (v58 & 1) == 0 )
          goto LABEL_91;
LABEL_90:
        operator delete(v59);
        goto LABEL_91;
      }
LABEL_15:
      operator delete(v56);
      if ( (v58 & 1) != 0 )
        goto LABEL_90;
LABEL_91:
      std::to_string((int)v8);
      v33 = std::string::insert(v8, 0, "SH-Level-");
      v56 = *(void **)(v33 + 16);
      v55 = *(_OWORD *)v33;
      *(_OWORD *)v33 = 0;
      *(_QWORD *)(v33 + 16) = 0;
      v34 = std::string::append(&v55, "-Prim-Count-");
      v54 = *(void **)(v34 + 16);
      v53 = *(_OWORD *)v34;
      *(_OWORD *)v34 = 0;
      *(_QWORD *)(v34 + 16) = 0;
      RBX::SystemUtil::osPlatform((RBX::SystemUtil *)&v47);
      if ( (v47 & 1) != 0 )
      {
        v35 = v50;
        v36 = v49;
      }
      else
      {
        v36 = (unsigned __int64)v47 >> 1;
        v35 = v48;
      }
      v37 = std::string::append(&v53, v35, v36);
      v52 = *(void **)(v37 + 16);
      v51 = *(_OWORD *)v37;
      *(_OWORD *)v37 = 0;
      *(_QWORD *)(v37 + 16) = 0;
      v38 = std::string::append(&v51, "-RCC");
      v67 = *(void **)(v38 + 16);
      v66 = *(_OWORD *)v38;
      *(_OWORD *)v38 = 0;
      *(_QWORD *)(v38 + 16) = 0;
      v79[0] = &off_299E668;
      v79[1] = v4;
      v79[2] = v7;
      v80 = v79;
      RBX::Collision::StatReporter::addStat(p_levelStatReporter, &v66, v79);
      if ( v79 == v80 )
      {
        (*(void (__fastcall **)(_QWORD *))(*v80 + 32LL))(v80);
        if ( (v66 & 1) != 0 )
          goto LABEL_18;
      }
      else
      {
        if ( v80 )
          (*(void (**)(void))(*v80 + 40LL))();
        if ( (v66 & 1) != 0 )
        {
LABEL_18:
          operator delete(v67);
          if ( (v51 & 1) != 0 )
            goto LABEL_19;
          goto LABEL_99;
        }
      }
      if ( (v51 & 1) != 0 )
      {
LABEL_19:
        operator delete(v52);
        if ( (v47 & 1) != 0 )
          goto LABEL_20;
        goto LABEL_100;
      }
LABEL_99:
      if ( (v47 & 1) != 0 )
      {
LABEL_20:
        operator delete(v50);
        if ( (v53 & 1) != 0 )
          goto LABEL_21;
        goto LABEL_101;
      }
LABEL_100:
      if ( (v53 & 1) != 0 )
      {
LABEL_21:
        operator delete(v54);
        if ( (v55 & 1) == 0 )
          goto LABEL_102;
        goto LABEL_22;
      }
LABEL_101:
      if ( (v55 & 1) == 0 )
      {
LABEL_102:
        if ( (v58 & 1) == 0 )
          goto LABEL_104;
LABEL_103:
        operator delete(v59);
        goto LABEL_104;
      }
LABEL_22:
      operator delete(v56);
      if ( (v58 & 1) != 0 )
        goto LABEL_103;
LABEL_104:
      std::to_string((int)v8);
      v39 = std::string::insert(v8, 0, "SH-Level-");
      v56 = *(void **)(v39 + 16);
      v55 = *(_OWORD *)v39;
      *(_OWORD *)v39 = 0;
      *(_QWORD *)(v39 + 16) = 0;
      v40 = std::string::append(&v55, "-Occupancy-");
      v54 = *(void **)(v40 + 16);
      v53 = *(_OWORD *)v40;
      *(_OWORD *)v40 = 0;
      *(_QWORD *)(v40 + 16) = 0;
      RBX::SystemUtil::osPlatform((RBX::SystemUtil *)&v47);
      if ( (v47 & 1) != 0 )
      {
        v41 = v50;
        v42 = v49;
      }
      else
      {
        v42 = (unsigned __int64)v47 >> 1;
        v41 = v48;
      }
      v43 = std::string::append(&v53, v41, v42);
      v52 = *(void **)(v43 + 16);
      v51 = *(_OWORD *)v43;
      *(_OWORD *)v43 = 0;
      *(_QWORD *)(v43 + 16) = 0;
      v44 = std::string::append(&v51, "-RCC");
      v65 = *(void **)(v44 + 16);
      v64 = *(_OWORD *)v44;
      *(_OWORD *)v44 = 0;
      *(_QWORD *)(v44 + 16) = 0;
      v77[0] = &off_299E6E8;
      v77[1] = v4;
      v77[2] = v7;
      v78 = v77;
      RBX::Collision::StatReporter::addStat(p_levelStatReporter, &v64, v77);
      if ( v77 == v78 )
      {
        (*(void (__fastcall **)(_QWORD *))(*v78 + 32LL))(v78);
        if ( (v64 & 1) != 0 )
          goto LABEL_25;
      }
      else
      {
        if ( v78 )
          (*(void (**)(void))(*v78 + 40LL))();
        if ( (v64 & 1) != 0 )
        {
LABEL_25:
          operator delete(v65);
          if ( (v51 & 1) != 0 )
            goto LABEL_26;
          goto LABEL_112;
        }
      }
      if ( (v51 & 1) != 0 )
      {
LABEL_26:
        operator delete(v52);
        if ( (v47 & 1) != 0 )
          goto LABEL_27;
        goto LABEL_113;
      }
LABEL_112:
      if ( (v47 & 1) != 0 )
      {
LABEL_27:
        operator delete(v50);
        if ( (v53 & 1) != 0 )
          goto LABEL_28;
        goto LABEL_114;
      }
LABEL_113:
      if ( (v53 & 1) != 0 )
      {
LABEL_28:
        operator delete(v54);
        if ( (v55 & 1) != 0 )
          goto LABEL_29;
        goto LABEL_115;
      }
LABEL_114:
      if ( (v55 & 1) != 0 )
      {
LABEL_29:
        operator delete(v56);
        if ( (v58 & 1) == 0 )
          goto LABEL_117;
LABEL_116:
        operator delete(v59);
        goto LABEL_117;
      }
LABEL_115:
      if ( (v58 & 1) != 0 )
        goto LABEL_116;
LABEL_117:
      ++v7;
    }
    while ( v7 < v4->levels.mSize );
  }
LABEL_118:
  if ( !stru_2AAF648.value )
    return;
  RBX::SystemUtil::osPlatform((RBX::SystemUtil *)&v53);
  v45 = std::string::insert(&v53, 0, "SH-Compute-Extents-");
  v52 = *(void **)(v45 + 16);
  v51 = *(_OWORD *)v45;
  *(_OWORD *)v45 = 0;
  *(_QWORD *)(v45 + 16) = 0;
  v46 = std::string::append(&v51, "-RCC");
  v63 = *(void **)(v46 + 16);
  v62 = *(_OWORD *)v46;
  *(_OWORD *)v46 = 0;
  *(_QWORD *)(v46 + 16) = 0;
  v75[0] = &off_299E768;
  v75[1] = v4;
  v76 = v75;
  RBX::Collision::StatReporter::addStat(p_computeExtentsDtReporter, &v62, v75);
  if ( v75 == v76 )
  {
    (*(void (__fastcall **)(_QWORD *))(*v76 + 32LL))(v76);
    if ( (v62 & 1) == 0 )
      goto LABEL_123;
  }
  else
  {
    if ( v76 )
      (*(void (**)(void))(*v76 + 40LL))();
    if ( (v62 & 1) == 0 )
    {
LABEL_123:
      if ( (v51 & 1) == 0 )
        goto LABEL_124;
      goto LABEL_129;
    }
  }
  operator delete(v63);
  if ( (v51 & 1) == 0 )
  {
LABEL_124:
    if ( (v53 & 1) == 0 )
      return;
    goto LABEL_125;
  }
LABEL_129:
  operator delete(v52);
  if ( (v53 & 1) == 0 )
    return;
LABEL_125:
  operator delete(v54);
}


// Address: 0x1df5410 | Name: _ZN3RBX9Collision12StatReporter7addStatENSt3__112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS2_8functionIFdvEEE
unsigned __int64 __fastcall RBX::Collision::StatReporter::addStat(
        RBX::ArrayDynamic<std::pair<std::string,std::function<double ()> > > *a1,
        __int64 a2,
        __int64 a3)
{
  __int64 v5; // rdi
  size_t mSize; // rcx
  size_t mCapacity; // rdx
  bool v8; // zf
  size_t v9; // rax
  __int64 v10; // rdx
  __int64 v11; // rcx
  size_t v12; // rsi
  std::pair<std::string,std::function<double ()> > *mData; // rax
  __int64 v14; // rcx
  _BYTE *v15; // rdi
  __int128 v17; // [rsp+0h] [rbp-78h] BYREF
  void *ptr; // [rsp+10h] [rbp-68h]
  _BYTE v19[32]; // [rsp+20h] [rbp-58h] BYREF
  _BYTE *v20; // [rsp+40h] [rbp-38h]
  unsigned __int64 v21; // [rsp+58h] [rbp-20h]

  v21 = __readfsqword(0x28u);
  std::string::basic_string(&v17, a2);
  v5 = *(_QWORD *)(a3 + 32);
  if ( v5 )
  {
    if ( a3 == v5 )
    {
      v20 = v19;
      (*(void (__fastcall **)(__int64, _BYTE *))(*(_QWORD *)v5 + 24LL))(v5, v19);
    }
    else
    {
      v20 = (_BYTE *)(*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v5 + 16LL))(v5);
    }
  }
  else
  {
    v20 = 0;
  }
  mSize = a1[1].mSize;
  mCapacity = a1[1].mCapacity;
  if ( mCapacity == mSize )
  {
    v8 = mCapacity == 0;
    v9 = mCapacity + 1;
    v10 = 2 * mCapacity;
    v11 = 2;
    if ( !v8 )
      v11 = v10;
    do
    {
      v12 = v11;
      v11 *= 2;
    }
    while ( v12 < v9 );
    RBX::ArrayDynamic<std::pair<std::string,std::function<double ()(void)>>>::reserve(a1 + 1, v12);
    mSize = a1[1].mSize;
  }
  mData = a1[1].mData;
  v14 = 80 * mSize;
  *(_QWORD *)((char *)mData + v14 + 16) = ptr;
  *(_OWORD *)((char *)mData + v14) = v17;
  v17 = 0;
  ptr = 0;
  if ( v20 )
  {
    if ( v19 != v20 )
    {
      *(_QWORD *)((char *)mData + v14 + 64) = v20;
      v20 = 0;
      ++a1[1].mSize;
      if ( (v17 & 1) == 0 )
        return __readfsqword(0x28u);
      goto LABEL_21;
    }
    *(_QWORD *)((char *)mData + v14 + 64) = (char *)mData + v14 + 32;
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v20 + 24LL))(v20);
  }
  else
  {
    *(_QWORD *)((char *)mData + v14 + 64) = 0;
  }
  v15 = v20;
  ++a1[1].mSize;
  if ( v19 == v15 )
  {
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v15 + 32LL))(v15);
    if ( (v17 & 1) == 0 )
      return __readfsqword(0x28u);
    goto LABEL_21;
  }
  if ( v15 )
    (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v15 + 40LL))(v15);
  if ( (v17 & 1) != 0 )
LABEL_21:
    operator delete(ptr);
  return __readfsqword(0x28u);
}


// Address: 0x1df55f0 | Name: _ZN3RBX9Collision13GridHierarchyD2Ev
void __fastcall RBX::Collision::GridHierarchy::~GridHierarchy(RBX::Collision::GridHierarchy *this)
{
  size_t mSize; // rax
  size_t i; // rbx
  RBX::Collision::LevelGrid *v4; // r15
  RBX::Collision::SpatialHashPools *pools; // rbx
  size_t v6; // r15
  char *v7; // rbx
  char *v8; // rdi
  size_t v9; // r15
  char *v10; // rbx
  char *v11; // rdi

  mSize = this->levels.mSize;
  if ( mSize )
  {
    for ( i = 0; i < mSize; ++i )
    {
      v4 = this->levels.mData[i];
      if ( v4 )
      {
        RBX::Collision::LevelGrid::~LevelGrid(this->levels.mData[i]);
        operator delete(v4);
        mSize = this->levels.mSize;
      }
    }
  }
  this->levels.mSize = 0;
  pools = this->pools;
  if ( pools )
  {
    RBX::Collision::SpatialHashPools::~SpatialHashPools(this->pools);
    operator delete(pools);
  }
  if ( !this->levelStatReporter.stats.mNoInit )
  {
    v6 = this->levelStatReporter.stats.mSize;
    if ( v6 )
    {
      v7 = (char *)this->levelStatReporter.stats.mData + 32;
      do
      {
        v8 = (char *)*((_QWORD *)v7 + 4);
        if ( v7 == v8 )
        {
          (*(void (__fastcall **)(char *))(*(_QWORD *)v8 + 32LL))(v8);
          if ( (*(v7 - 32) & 1) == 0 )
            goto LABEL_18;
        }
        else
        {
          if ( v8 )
            (*(void (__fastcall **)(char *))(*(_QWORD *)v8 + 40LL))(v8);
          if ( (*(v7 - 32) & 1) == 0 )
            goto LABEL_18;
        }
        operator delete(*((void **)v7 - 2));
LABEL_18:
        v7 += 80;
        --v6;
      }
      while ( v6 );
    }
  }
  this->levelStatReporter.stats.mSize = 0;
  if ( this->levelStatReporter.stats.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->levelStatReporter.stats.mData);
    this->levelStatReporter.stats.mCapacity = 0;
    this->levelStatReporter.stats.mData = 0;
  }
  if ( !this->computeExtentsDtReporter.stats.mNoInit )
  {
    v9 = this->computeExtentsDtReporter.stats.mSize;
    if ( v9 )
    {
      v10 = (char *)this->computeExtentsDtReporter.stats.mData + 32;
      do
      {
        v11 = (char *)*((_QWORD *)v10 + 4);
        if ( v10 == v11 )
        {
          (*(void (__fastcall **)(char *))(*(_QWORD *)v11 + 32LL))(v11);
          if ( (*(v10 - 32) & 1) == 0 )
            goto LABEL_31;
        }
        else
        {
          if ( v11 )
            (*(void (__fastcall **)(char *))(*(_QWORD *)v11 + 40LL))(v11);
          if ( (*(v10 - 32) & 1) == 0 )
            goto LABEL_31;
        }
        operator delete(*((void **)v10 - 2));
LABEL_31:
        v10 += 80;
        --v9;
      }
      while ( v9 );
    }
  }
  this->computeExtentsDtReporter.stats.mSize = 0;
  if ( this->computeExtentsDtReporter.stats.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->computeExtentsDtReporter.stats.mData);
    this->computeExtentsDtReporter.stats.mCapacity = 0;
    this->computeExtentsDtReporter.stats.mData = 0;
  }
  this->levels.mSize = 0;
  if ( this->levels.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->levels.mData);
    this->levels.mCapacity = 0;
    this->levels.mData = 0;
  }
}


// Address: 0x1df57d0 | Name: _ZN3RBX9Collision13GridHierarchy19removeAllPrimitivesEv
void __fastcall RBX::Collision::GridHierarchy::removeAllPrimitives(RBX::Collision::GridHierarchy *this)
{
  size_t v1; // rbx

  if ( this->levels.mSize )
  {
    v1 = 0;
    do
      RBX::Collision::LevelGrid::removeAllPrimitives(this->levels.mData[v1++]);
    while ( v1 < this->levels.mSize );
  }
}


// Address: 0x1df5800 | Name: _ZN3RBX9Collision13GridHierarchy6rehashEmm
void __fastcall RBX::Collision::GridHierarchy::rehash(
        RBX::Collision::GridHierarchy *this,
        size_t level,
        size_t newBinCount)
{
  RBX::Collision::LevelGrid *v3; // r15
  RBX::Collision::LevelGrid *v4; // r12

  v3 = RBX::Collision::LevelGrid::rehash(this->levels.mData[level], newBinCount, this->pools);
  v4 = this->levels.mData[level];
  if ( v4 )
  {
    RBX::Collision::LevelGrid::~LevelGrid(this->levels.mData[level]);
    operator delete(v4);
  }
  this->levels.mData[level] = v3;
}


// Address: 0x1df5860 | Name: _ZN3RBX9Collision13GridHierarchy23addContactsFromChildrenEPNS_14ContactManagerEiRKNS0_9LevelGrid12CellIteratorEPNS_9PrimitiveE
// local variable allocation has failed, the output may be wrong!
void __fastcall RBX::Collision::GridHierarchy::addContactsFromChildren(
        RBX::Collision::GridHierarchy *this,
        RBX::ContactManager *contactManager,
        int level,
        const RBX::Collision::CellIterator *cell,
        RBX::Primitive *p)
{
  RBX::Collision::LevelGrid *v6; // r13
  uint8_t childMask; // r12
  RBX::Collision::CellCoord *coords; // rax
  int v9; // r9d
  int v10; // r15d
  int v11; // r14d
  unsigned int i; // ebp
  int v13; // ebx
  int v14; // eax
  int v15; // ecx
  int v16; // edx
  __int64 v17; // r8
  int32_t *v18; // rbx
  unsigned __int64 v19; // rsi
  int v20; // [rsp+Ch] [rbp-6Ch]
  RBX::Collision::CellIterator n; // [rsp+20h] [rbp-58h] BYREF
  RBX::Collision::GridHierarchy *v24; // [rsp+38h] [rbp-40h]
  __int64 v25; // [rsp+40h] [rbp-38h]

  v20 = level - 1;
  v25 = *(_QWORD *)&level;
  v24 = this;
  v6 = this->levels.mData[level - 1];
  childMask = RBX::Collision::LevelGrid::getChildren(cell->container, &cell->index)->childMask;
  coords = cell->container->bins.mData[cell->index.binIndex.data].coords;
  v9 = 2 * coords[cell->index.nodeIndex].v[0];
  v10 = 2 * coords[cell->index.nodeIndex].v[1];
  v11 = 2 * coords[cell->index.nodeIndex].v[2];
  for ( i = 0; i != 8; ++i )
  {
    if ( ((unsigned __int8)(1 << i) & childMask) != 0 )
    {
      v14 = v9 | i & 1;
      v15 = v10 | (i >> 1) & 1;
      v16 = v11 | (i >> 2) & 1;
      v17 = ((73856093 * v14) ^ (19349663 * v15) ^ (83492791 * v16)) & (unsigned int)(LODWORD(v6->sizes.mSize) - 1);
      if ( v6->sizes.mData[v17] )
      {
        v18 = &v6->bins.mData[v17].coords->v[2];
        v19 = 0;
        while ( *(v18 - 2) != v14 || *(v18 - 1) != v15 || *v18 != v16 )
        {
          ++v19;
          v18 += 3;
          if ( v19 >= v6->sizes.mData[v17] )
            goto LABEL_11;
        }
        n.index.valid = 1;
        n.index.binIndex.data = v17;
        n.index.nodeIndex = v19;
        n.container = v6;
        v13 = v9;
        RBX::Collision::addContactsWithCell(contactManager, p, &n);
        v9 = v13;
        if ( (int)v25 >= 2 )
        {
          RBX::Collision::GridHierarchy::addContactsFromChildren(v24, contactManager, v20, &n, p);
          v9 = v13;
        }
      }
      else
      {
LABEL_11:
        n.index.valid = 0;
        n.index.binIndex.data = v17;
        n.container = v6;
      }
    }
  }
}


// Address: 0x1df5a10 | Name: _ZN3RBX9CollisionL19addContactsWithCellEPNS_14ContactManagerEPNS_9PrimitiveERKNS0_9LevelGrid12CellIteratorE
void __fastcall RBX::Collision::addContactsWithCell(
        RBX::ContactManager *contactManager,
        RBX::Primitive *p,
        const RBX::Collision::CellIterator *cell)
{
  char v3; // al
  __int64 count; // rbp
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *p_heapArray; // r12
  __int64 v6; // rbp
  unsigned __int64 v7; // r13
  RBX::Primitive *local; // rbx
  __int64 v9; // r13
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *v10; // r12
  __int64 v11; // r13
  unsigned __int64 v12; // rbp
  RBX::Primitive *v13; // rbx
  RBX::Collision::CellPrimitives *prims; // [rsp+8h] [rbp-40h]
  __int64 nodeIndex; // [rsp+10h] [rbp-38h]

  prims = cell->container->bins.mData[cell->index.binIndex.data].prims;
  nodeIndex = cell->index.nodeIndex;
  v3 = *((_BYTE *)p + 113);
  if ( v3 != 1 )
  {
    if ( v3 )
      return;
    count = prims[nodeIndex].groundedPrims.count;
    if ( prims[nodeIndex].groundedPrims.count )
    {
      p_heapArray = (RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *)&prims[nodeIndex].groundedPrims.heapArray;
      if ( (_DWORD)count != 1 )
        p_heapArray = (RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *)p_heapArray->heapArray;
      v6 = 8 * count;
      v7 = 0;
      do
      {
        local = p_heapArray[v7 / 8].local;
        if ( local != p && !RBX::Primitive::getContactNew(p, p_heapArray[v7 / 8].local) )
          RBX::ContactManager::onNewPair(contactManager, p, local);
        v7 += 8LL;
      }
      while ( v6 != v7 );
    }
  }
  v9 = prims[nodeIndex].dynamicPrims.count;
  if ( prims[nodeIndex].dynamicPrims.count )
  {
    v10 = (RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *)&prims[nodeIndex].dynamicPrims.heapArray;
    if ( (_DWORD)v9 != 1 )
      v10 = (RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::$56B62B6F8EDA225842E30EAA690F6A34 *)v10->heapArray;
    v11 = 8 * v9;
    v12 = 0;
    do
    {
      v13 = v10[v12 / 8].local;
      if ( v13 != p && !RBX::Primitive::getContactNew(p, v10[v12 / 8].local) )
        RBX::ContactManager::onNewPair(contactManager, p, v13);
      v12 += 8LL;
    }
    while ( v11 != v12 );
  }
}


// Address: 0x1df5b30 | Name: _ZN3RBX9Collision13GridHierarchy18addPrimitiveToCellEPNS_14ContactManagerEPNS_9PrimitiveEmNS0_16CellCoordAndHashEb
void __fastcall RBX::Collision::GridHierarchy::addPrimitiveToCell(
        RBX::Collision::GridHierarchy *this,
        unsigned __int64 contactManager,
        RBX::Primitive *p,
        size_t level,
        RBX::Collision::CellCoordAndHash coord,
        double a6,
        double a7)
{
  RBX::Collision::LevelGrid **mData; // r10
  RBX::Collision::LevelGrid *v10; // r14
  __int64 data; // r11
  RBX::Collision::LevelGrid::Bin *v12; // r9
  int32_t *v13; // rbp
  bool v14; // cl
  char v15; // bp
  __int64 mSize; // rsi
  __int64 cellCount; // rax
  float v18; // xmm0_4
  __int64 v19; // rcx
  __int64 v20; // rax
  size_t v21; // rsi
  RBX::Collision::LevelGrid *v22; // rax
  RBX::Collision::GridHierarchy *v23; // rcx
  RBX::Collision::LevelGrid *v24; // r14
  RBX::Collision::LevelGrid *v25; // r15
  RBX::Collision::CellPrimitives *prims; // rdi
  char v27; // cl
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive> *p_groundedPrims; // rdi
  RBX::Collision::GridHierarchy *v29; // rdi
  RBX::Collision::CellCoordAndHash *v30; // rdx
  int v31; // ebx
  int v32; // r15d
  int v33; // r14d
  size_t v34; // r13
  char v35; // r10
  int v36; // ebx
  int v37; // r15d
  int v38; // r14d
  int v39; // esi
  int v40; // eax
  int v41; // ecx
  int v42; // r11d
  int v43; // r12d
  RBX::Collision::LevelGrid **v44; // r8
  RBX::Collision::LevelGrid *v45; // r9
  __int64 v46; // rax
  int32_t *v47; // rbp
  unsigned __int64 v48; // rcx
  RBX::Collision::LevelGrid *v49; // r15
  __int64 v50; // rsi
  __int64 v51; // rax
  float v52; // xmm0_4
  __int64 v53; // rcx
  __int64 v54; // rax
  size_t v55; // rsi
  char v56; // bp
  RBX::Collision::LevelGrid *v57; // rax
  RBX::Collision::GridHierarchy *v58; // rcx
  RBX::Collision::LevelGrid *v59; // r15
  RBX::Collision::LevelGrid *v60; // r14
  char v61; // bl
  char v62; // r14
  int v63; // ebx
  int v64; // ebp
  int v65; // r12d
  char v66; // bl
  RBX::Collision::CellChildren *Children; // rax
  int v68; // [rsp+4h] [rbp-C4h]
  RBX::Collision::CellCoordAndHash *coorda; // [rsp+10h] [rbp-B8h]
  int v71; // [rsp+1Ch] [rbp-ACh]
  RBX::Collision::CellIterator v72; // [rsp+20h] [rbp-A8h] BYREF
  int32_t v73; // [rsp+3Ch] [rbp-8Ch]
  RBX::ContactManager *v74; // [rsp+40h] [rbp-88h]
  int v75; // [rsp+48h] [rbp-80h]
  int v76; // [rsp+4Ch] [rbp-7Ch]
  RBX::Collision::CellIterator cell; // [rsp+50h] [rbp-78h] BYREF
  bool v78[4]; // [rsp+68h] [rbp-60h] BYREF
  RBX::Collision::CellBinIndexType v79; // [rsp+6Ch] [rbp-5Ch]
  RBX::Collision::LevelGrid::BinSizeType v80; // [rsp+70h] [rbp-58h]
  RBX::Primitive *v81; // [rsp+78h] [rbp-50h]
  __int64 v82; // [rsp+80h] [rbp-48h]
  __int64 v83; // [rsp+88h] [rbp-40h]
  __int64 v84; // [rsp+90h] [rbp-38h]

  v73 = coord.coordData.v[2];
  v74 = (RBX::ContactManager *)contactManager;
  mData = this->levels.mData;
  v10 = this->levels.mData[level];
  data = *(_DWORD *)(*(_QWORD *)coord.coordData.v + 12LL) & (unsigned int)(LODWORD(v10->sizes.mSize) - 1);
  v12 = v10->bins.mData;
  if ( v10->sizes.mData[data] )
  {
    v13 = &v12[data].coords->v[2];
    contactManager = 0;
    while ( *(v13 - 2) != **(_DWORD **)coord.coordData.v
         || *(v13 - 1) != *(_DWORD *)(*(_QWORD *)coord.coordData.v + 4LL)
         || *v13 != *(_DWORD *)(*(_QWORD *)coord.coordData.v + 8LL) )
    {
      ++contactManager;
      v13 += 3;
      if ( contactManager >= v10->sizes.mData[data] )
        goto LABEL_7;
    }
    v14 = 1;
  }
  else
  {
LABEL_7:
    v14 = 0;
  }
  cell.index.valid = v14;
  cell.index.binIndex.data = data;
  cell.index.nodeIndex = contactManager;
  cell.container = v10;
  coorda = *(RBX::Collision::CellCoordAndHash **)coord.coordData.v;
  if ( v14 )
  {
    v15 = 0;
    goto LABEL_22;
  }
  v10 = mData[(int)level];
  mSize = v10->sizes.mSize;
  cellCount = v10->cellCount;
  if ( cellCount < 0 )
  {
    v20 = (v10->cellCount >> 1) | v10->cellCount & 1;
    v18 = (float)(int)v20 + (float)(int)v20;
    if ( mSize < 0 )
      goto LABEL_12;
  }
  else
  {
    v18 = (float)(int)cellCount;
    if ( mSize < 0 )
    {
LABEL_12:
      v19 = (v10->sizes.mSize >> 1) | v10->sizes.mSize & 1;
      *(float *)&a7 = (float)(int)v19 + (float)(int)v19;
      goto LABEL_15;
    }
  }
  *(float *)&a7 = (float)(int)mSize;
LABEL_15:
  *(float *)&a6 = v18 / *(float *)&a7;
  if ( *(float *)&a6 > this->highestDensityThreshold )
  {
    v21 = this->levelExpansionFactor * mSize;
    if ( v21 <= this->maxNumberOfBinsInLevel )
    {
      v22 = RBX::Collision::LevelGrid::rehash(mData[(int)level], v21, this->pools);
      v23 = this;
      v24 = v22;
      v25 = this->levels.mData[(int)level];
      if ( v25 )
      {
        RBX::Collision::LevelGrid::~LevelGrid(this->levels.mData[(int)level]);
        operator delete(v25);
        v23 = this;
      }
      *(_QWORD *)coord.coordData.v = coorda;
      this->levels.mData[(int)level] = v24;
      v10 = v23->levels.mData[(int)level];
    }
  }
  RBX::Collision::LevelGrid::allocateCellImp(
    (__int64)&v72,
    v10,
    *(const RBX::Collision::CellCoordAndHash **)coord.coordData.v,
    a6,
    a7);
  data = v72.index.binIndex.data;
  LOBYTE(contactManager) = v72.index.nodeIndex;
  cell.index.binIndex.data = v72.index.binIndex.data;
  cell.index.nodeIndex = v72.index.nodeIndex;
  cell.index.valid = v72.index.valid;
  cell.container = v10;
  v12 = v10->bins.mData;
  v15 = 1;
LABEL_22:
  prims = v12[data].prims;
  v27 = *((_BYTE *)p + 113);
  if ( v27 == 1 )
  {
    p_groundedPrims = &prims[(unsigned __int8)contactManager].groundedPrims;
  }
  else
  {
    if ( v27 )
      goto LABEL_27;
    p_groundedPrims = &prims[(unsigned __int8)contactManager].dynamicPrims;
  }
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::push_back(p_groundedPrims, p, &v10->pools->primitiveArrayPool);
LABEL_27:
  v29 = this;
  if ( stru_2AAF660.value )
    ++this->levels.mData[level]->cellPrimitiveCount;
  v30 = coorda;
  v31 = coorda->coordData.v[0];
  v32 = coorda->coordData.v[1];
  v33 = coorda->coordData.v[2];
  if ( (_BYTE)v73 )
  {
    RBX::Collision::addContactsWithCell(v74, p, &cell);
    v29 = this;
    v30 = coorda;
    if ( level )
    {
      RBX::Collision::GridHierarchy::addContactsFromChildren(this, v74, level, &cell, p);
      v29 = this;
      v30 = coorda;
    }
  }
  v81 = p;
  v34 = level + 1;
  if ( v34 < v29->levels.mSize )
  {
    v35 = v15;
    v36 = v31 >> 1;
    v37 = v32 >> 1;
    v38 = v33 >> 1;
    v39 = (73856093 * v36) ^ (19349663 * v37) ^ (83492791 * v38);
    v40 = v36;
    v41 = v37;
    v42 = v38;
    do
    {
      v83 = (unsigned int)v30->coordData.v[0];
      v82 = (unsigned int)v30->coordData.v[1];
      v84 = (unsigned int)v30->coordData.v[2];
      v30->coordData.v[0] = v36;
      v30->coordData.v[1] = v37;
      v30->coordData.v[2] = v38;
      v30->hashData.h = v39;
      v42 >>= 1;
      v76 = v40 >> 1;
      v68 = 73856093 * (v40 >> 1);
      v75 = v41 >> 1;
      v43 = 19349663 * (v41 >> 1);
      v44 = v29->levels.mData;
      v45 = v29->levels.mData[v34];
      v46 = v39 & (unsigned int)(LODWORD(v45->sizes.mSize) - 1);
      v71 = v42;
      if ( v45->sizes.mData[v46] )
      {
        v47 = &v45->bins.mData[v46].coords->v[2];
        v48 = 0;
        while ( *(v47 - 2) != v36 || *(v47 - 1) != v37 || *v47 != v38 )
        {
          ++v48;
          v47 += 3;
          if ( v48 >= v45->sizes.mData[v46] )
            goto LABEL_40;
        }
        v72.index.valid = 1;
        v72.index.binIndex.data = v46;
        v72.index.nodeIndex = v48;
        v72.container = v45;
        if ( (_BYTE)v73 )
        {
          v61 = v35;
          RBX::Collision::addContactsWithCell(v74, v81, &v72);
          v42 = v71;
          v35 = v61;
          v29 = this;
        }
        v62 = 0;
        v63 = v68;
        goto LABEL_55;
      }
LABEL_40:
      v72.index.valid = 0;
      v72.index.binIndex.data = v46;
      v72.container = v45;
      v49 = v44[(int)v34];
      v50 = v49->sizes.mSize;
      v51 = v49->cellCount;
      if ( v51 < 0 )
      {
        v54 = (v49->cellCount >> 1) | v49->cellCount & 1;
        v52 = (float)(int)v54 + (float)(int)v54;
        if ( v50 < 0 )
        {
LABEL_42:
          v53 = (v49->sizes.mSize >> 1) | v49->sizes.mSize & 1;
          *(float *)&a7 = (float)(int)v53 + (float)(int)v53;
          goto LABEL_45;
        }
      }
      else
      {
        v52 = (float)(int)v51;
        if ( v50 < 0 )
          goto LABEL_42;
      }
      *(float *)&a7 = (float)(int)v50;
LABEL_45:
      *(float *)&a6 = v52 / *(float *)&a7;
      if ( *(float *)&a6 > v29->highestDensityThreshold
        && (v55 = v29->levelExpansionFactor * v50, v55 <= v29->maxNumberOfBinsInLevel) )
      {
        v56 = v35;
        v57 = RBX::Collision::LevelGrid::rehash(v44[(int)v34], v55, v29->pools);
        v58 = this;
        v59 = v57;
        v60 = this->levels.mData[(int)v34];
        if ( v60 )
        {
          RBX::Collision::LevelGrid::~LevelGrid(this->levels.mData[(int)v34]);
          operator delete(v60);
          v58 = this;
        }
        v30 = coorda;
        this->levels.mData[(int)v34] = v59;
        v49 = v58->levels.mData[(int)v34];
      }
      else
      {
        v56 = v35;
      }
      v63 = v68;
      RBX::Collision::LevelGrid::allocateCellImp((__int64)v78, v49, v30, a6, a7);
      v72.index.binIndex.data = v79;
      v72.index.nodeIndex = v80;
      v72.index.valid = v78[0];
      v72.container = v49;
      v62 = 1;
      v29 = this;
      v35 = v56;
      v42 = v71;
LABEL_55:
      v64 = 83492791 * v42;
      v65 = v63 ^ v43;
      if ( (v35 & 1) != 0 )
      {
        v66 = (v83 & 1) + 2 * (v82 & 1) + 4 * (v84 & 1);
        Children = RBX::Collision::LevelGrid::getChildren(v72.container, &v72.index);
        v42 = v71;
        v29 = this;
        Children->childMask |= 1 << v66;
      }
      ++v34;
      v35 = v62;
      v39 = v64 ^ v65;
      v38 = v42;
      v41 = v75;
      v37 = v75;
      v40 = v76;
      v36 = v76;
      v30 = coorda;
    }
    while ( v34 < v29->levels.mSize );
  }
}


// Address: 0x1df60a0 | Name: _ZN3RBX9Collision13GridHierarchy12addPrimitiveEPNS_14ContactManagerEPNS_9PrimitiveEb
void __fastcall RBX::Collision::GridHierarchy::addPrimitive(
        RBX::Collision::GridHierarchy *this,
        RBX::ContactManager *contactManager,
        RBX::Primitive *p,
        bool createContacts)
{
  const RBX::Extents *FastFuzzyExtents; // rbx
  __int128 v7; // xmm0
  int v8; // ebx
  __m128 v9; // xmm0
  __m128 v10; // xmm1
  __m128 v11; // xmm3
  __m128 v12; // xmm2
  __m128 v13; // xmm6
  __m128 v14; // xmm7
  __m128 v15; // xmm6
  __m128 v16; // xmm7
  __m128 v17; // xmm7
  size_t v18; // r8
  __m128 v19; // xmm0
  __m128 v20; // xmm2
  __m128 v21; // xmm0
  int v22; // ebx
  __m128 v23; // xmm3
  __m128 v24; // xmm1
  __m128 v25; // xmm3
  __m128i v26; // xmm1
  __m128i v27; // xmm2
  char v28; // al
  __m128i v29; // xmm3
  __m128i v30; // xmm0
  int v31; // ecx
  int32_t v32; // eax
  RBX::Primitive *v33; // rdx
  RBX::ContactManager *v34; // rsi
  RBX::Collision::GridHierarchy *v35; // rdi
  int v36; // ebp
  int32_t v37; // r14d
  size_t v38; // r15
  size_t v39; // rcx
  int v40; // eax
  bool v41[4]; // [rsp+0h] [rbp-B8h]
  int v42; // [rsp+4h] [rbp-B4h]
  int v43; // [rsp+8h] [rbp-B0h]
  int v44; // [rsp+Ch] [rbp-ACh]
  int32_t v45; // [rsp+10h] [rbp-A8h]
  int v46; // [rsp+24h] [rbp-94h]
  int v47; // [rsp+28h] [rbp-90h]
  int v48; // [rsp+2Ch] [rbp-8Ch]
  RBX::Extents extents; // [rsp+30h] [rbp-88h] BYREF
  RBX::ContactManager *v50; // [rsp+50h] [rbp-68h]
  RBX::Primitive *v51; // [rsp+58h] [rbp-60h]
  __m128 v52; // [rsp+60h] [rbp-58h]
  RBX::Collision::CellCoordAndHash coord; // [rsp+70h] [rbp-48h] BYREF
  RBX::Collision::GridHierarchy *v54; // [rsp+80h] [rbp-38h]
  RBX::Collision::CellCoordAndHash v55; // 0:r8.16

  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(p);
  if ( RBX::Math::isNanInfVector3(&FastFuzzyExtents->low) || RBX::Math::isNanInfVector3(&FastFuzzyExtents->high) )
  {
    *(_QWORD *)&extents.high.y = *(_QWORD *)&byte_29FC388[16];
    v7 = *(_OWORD *)byte_29FC388;
  }
  else
  {
    *(_QWORD *)&extents.high.y = *(_QWORD *)&FastFuzzyExtents->high.y;
    v7 = *(_OWORD *)&FastFuzzyExtents->low.x;
  }
  *(_OWORD *)&extents.low.x = v7;
  v8 = RBX::Collision::computeLevel(p, &extents);
  *((_BYTE *)p + 112) = v8;
  v9 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << v8), 0));
  v10 = _mm_rcp_ps(v9);
  v11 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v10, v9)), v10);
  v12 = _mm_and_ps(v11, (__m128)xmmword_3E5B40);
  v13 = _mm_and_ps((__m128)xmmword_3E5B40, v9);
  v14 = _mm_and_ps(_mm_cmpeq_ps(v13, (__m128)xmmword_3EB1D0), v9);
  v15 = _mm_and_ps(
          _mm_cmpneq_ps(v13, (__m128)xmmword_3EB1D0),
          _mm_or_ps(
            _mm_and_ps(_mm_cmpnlt_ps(v12, (__m128)xmmword_3EB1D0), v10),
            _mm_and_ps(_mm_cmplt_ps(v12, (__m128)xmmword_3EB1D0), v11)));
  v16 = _mm_and_ps(v14, *(__m128 *)&stru_3E4970.x);
  if ( !(_BYTE)byte_29FEDE8 )
  {
    v52 = v15;
    v40 = __cxa_guard_acquire(&byte_29FEDE8);
    v15 = v52;
    if ( v40 )
    {
      *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
      *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
      __cxa_guard_release(&byte_29FEDE8);
      v15 = v52;
    }
  }
  v17 = _mm_or_ps(v16, v15);
  if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
  {
    qword_29FEE08 = 0x8000000080000000LL;
    dword_29FEE10 = 0x80000000;
    __cxa_guard_release(&byte_29FEE18);
  }
  v50 = contactManager;
  v18 = v8;
  v19 = _mm_mul_ps(
          _mm_min_ps(
            (__m128)xmmword_3E8210,
            _mm_max_ps(
              (__m128)xmmword_3E5450,
              _mm_unpacklo_ps(
                _mm_unpacklo_ps((__m128)LODWORD(extents.low.x), (__m128)LODWORD(extents.low.z)),
                (__m128)LODWORD(extents.low.y)))),
          v17);
  v20 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v19));
  v21 = (__m128)_mm_cvttps_epi32(_mm_sub_ps(v20, _mm_and_ps(_mm_cmplt_ps(v19, v20), (__m128)stru_3E5460)));
  v22 = _mm_cvtsi128_si32((__m128i)v21);
  v23 = _mm_mul_ps(
          _mm_min_ps(
            (__m128)xmmword_3E8210,
            _mm_max_ps(
              (__m128)xmmword_3E5450,
              _mm_unpacklo_ps(
                _mm_unpacklo_ps((__m128)LODWORD(extents.high.x), (__m128)LODWORD(extents.high.z)),
                (__m128)LODWORD(extents.high.y)))),
          v17);
  v24 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v23));
  v25 = (__m128)_mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v24, v23), (__m128)stru_3E5460), v24));
  *(_DWORD *)v41 = _mm_cvtsi128_si32((__m128i)v25);
  v26 = _mm_shuffle_epi32((__m128i)v25, 229);
  v27 = _mm_shuffle_epi32((__m128i)v25, 78);
  *(__m128 *)((char *)p + 88) = _mm_shuffle_ps(v21, _mm_shuffle_ps(v25, v21, 32), 36);
  *((_DWORD *)p + 26) = _mm_cvtsi128_si32(v26);
  *((_DWORD *)p + 27) = _mm_cvtsi128_si32(v27);
  if ( stru_2AAF660.value )
    ++this->levels.mData[v18]->primitiveCount;
  v54 = this;
  v28 = *((_BYTE *)p + 114);
  v51 = p;
  *((_BYTE *)p + 113) = v28;
  if ( v22 < *(int *)v41 )
  {
    v29 = _mm_shuffle_epi32((__m128i)v21, 229);
    v30 = _mm_shuffle_epi32((__m128i)v21, 78);
    v42 = _mm_cvtsi128_si32(v29);
    v43 = _mm_cvtsi128_si32(v26);
    v31 = _mm_cvtsi128_si32(v27);
    v44 = _mm_cvtsi128_si32(v30);
    v47 = v31;
    do
    {
      if ( v42 < v43 )
      {
        v46 = 73856093 * v22;
        v32 = v42;
        v48 = v22;
        do
        {
          v33 = v51;
          v34 = v50;
          v35 = v54;
          if ( v44 < v31 )
          {
            v52.m128_i32[0] = v46 ^ (19349663 * v32);
            v36 = 83492791 * v44;
            v37 = v44;
            v45 = v32;
            do
            {
              coord.coordData.v[0] = v22;
              coord.coordData.v[1] = v32;
              coord.coordData.v[2] = v37;
              coord.hashData.h = v36 ^ v52.m128_i32[0];
              v38 = v18;
              v39 = v18;
              *(_QWORD *)v55.coordData.v = &coord;
              *(_QWORD *)&v55.coordData.v[2] = createContacts;
              RBX::Collision::GridHierarchy::addPrimitiveToCell(
                v35,
                (unsigned __int64)v34,
                v33,
                v39,
                v55,
                *(double *)v30.m128i_i64,
                *(double *)v26.m128i_i64);
              v34 = v50;
              v32 = v45;
              v31 = v47;
              v22 = v48;
              v18 = v38;
              v33 = v51;
              ++v37;
              v36 += 83492791;
            }
            while ( v47 != v37 );
          }
          ++v32;
        }
        while ( v32 != v43 );
      }
      ++v22;
    }
    while ( v22 != *(_DWORD *)v41 );
  }
}


// Address: 0x1df6600 | Name: _ZN3RBX9Collision13GridHierarchy25movePrimitiveBetweenBoxesEPNS_14ContactManagerEPNS_9PrimitiveERKNS_12ExtentsInt32ES8_b
void __fastcall RBX::Collision::GridHierarchy::movePrimitiveBetweenBoxes(
        RBX::Collision::GridHierarchy *this,
        RBX::ContactManager *contactManager,
        RBX::Primitive *p,
        const RBX::ExtentsInt32 *oldBox,
        const RBX::ExtentsInt32 *newBox,
        bool createContacts)
{
  double v6; // xmm0_8
  double v7; // xmm1_8
  int32_t x; // r12d
  int y; // edx
  int32_t v12; // ebp
  int z; // eax
  int32_t i; // ebx
  int32_t v15; // r12d
  int v16; // edx
  int32_t v17; // ebp
  int v18; // eax
  int32_t v19; // r13d
  int v20; // r14d
  bool v21; // [rsp+Ch] [rbp-7Ch]
  size_t level; // [rsp+10h] [rbp-78h]
  const RBX::ExtentsInt32 *v24; // [rsp+28h] [rbp-60h]
  RBX::Collision::CellCoord cellCoord; // [rsp+30h] [rbp-58h] BYREF
  RBX::Collision::CellCoordAndHash coord; // [rsp+40h] [rbp-48h] BYREF
  RBX::ContactManager *v27; // [rsp+50h] [rbp-38h]
  RBX::Collision::CellCoordAndHash v28; // 0:r8.16

  v27 = contactManager;
  level = *((char *)p + 112);
  x = oldBox->low.x;
  v24 = oldBox;
  if ( oldBox->low.x < oldBox->high.x )
  {
    y = oldBox->high.y;
    do
    {
      v12 = oldBox->low.y;
      if ( v12 < y )
      {
        z = oldBox->high.z;
        do
        {
          for ( i = oldBox->low.z; i < z; ++i )
          {
            if ( newBox->high.x <= x
              || newBox->low.x > x
              || newBox->low.y > v12
              || newBox->low.z > i
              || newBox->high.y <= v12
              || newBox->high.z <= i )
            {
              cellCoord.v[0] = x;
              cellCoord.v[1] = v12;
              cellCoord.v[2] = i;
              RBX::Collision::GridHierarchy::removePrimitiveFromCell(this, p, level, &cellCoord);
              oldBox = v24;
              z = v24->high.z;
            }
          }
          ++v12;
          y = oldBox->high.y;
        }
        while ( v12 < y );
      }
      ++x;
    }
    while ( x < oldBox->high.x );
  }
  v15 = newBox->low.x;
  v21 = createContacts;
  if ( newBox->low.x < newBox->high.x )
  {
    v16 = newBox->high.y;
    do
    {
      v17 = newBox->low.y;
      if ( v17 < v16 )
      {
        v18 = newBox->high.z;
        do
        {
          v19 = newBox->low.z;
          if ( v19 < v18 )
          {
            v20 = 83492791 * v19;
            do
            {
              if ( oldBox->low.x > v15
                || oldBox->low.y > v17
                || oldBox->low.z > v19
                || oldBox->high.x <= v15
                || oldBox->high.y <= v17
                || oldBox->high.z <= v19 )
              {
                coord.coordData.v[0] = v15;
                coord.coordData.v[1] = v17;
                coord.coordData.v[2] = v19;
                coord.hashData.h = v20 ^ (73856093 * v15) ^ (19349663 * v17);
                *(_QWORD *)&v28.coordData.v[2] = v21;
                *(_QWORD *)v28.coordData.v = &coord;
                RBX::Collision::GridHierarchy::addPrimitiveToCell(this, (unsigned __int64)v27, p, level, v28, v6, v7);
                oldBox = v24;
                v18 = newBox->high.z;
              }
              ++v19;
              v20 += 83492791;
            }
            while ( v19 < v18 );
          }
          ++v17;
          v16 = newBox->high.y;
        }
        while ( v17 < v16 );
      }
      ++v15;
    }
    while ( v15 < newBox->high.x );
  }
}


// Address: 0x1df6800 | Name: _ZN3RBX9Collision13GridHierarchy23removePrimitiveFromCellEPKNS_9PrimitiveEmRKNS0_9CellCoordE
void __fastcall RBX::Collision::GridHierarchy::removePrimitiveFromCell(
        RBX::Collision::GridHierarchy *this,
        const RBX::Primitive *p,
        size_t level,
        const RBX::Collision::CellCoord *cellCoord)
{
  RBX::Collision::LevelGrid *v6; // r12
  int32_t v7; // eax
  int32_t v8; // r11d
  int32_t v9; // r8d
  __int64 v10; // r13
  RBX::Collision::LevelGrid::Bin *mData; // r10
  int32_t *v12; // rdx
  __int64 v13; // rcx
  unsigned __int64 v14; // rbx
  RBX::Collision::CellPrimitives *prims; // rdi
  char v16; // al
  RBX::Collision::ShortArrayOfPointers<RBX::Primitive> *p_groundedPrims; // rdi
  RBX::Collision::CellIterator v18; // [rsp+0h] [rbp-48h]

  v6 = this->levels.mData[level];
  v7 = cellCoord->v[0];
  v8 = cellCoord->v[1];
  v9 = cellCoord->v[2];
  v10 = ((73856093 * cellCoord->v[0])
       ^ (19349663 * v8)
       ^ (83492791 * v9))
      & (unsigned int)(LODWORD(v6->sizes.mSize) - 1);
  if ( !v6->sizes.mData[v10] )
    return;
  mData = v6->bins.mData;
  v12 = &mData[v10].coords->v[2];
  v13 = 0;
  v14 = 0;
  while ( *(v12 - 2) != v7 || *(v12 - 1) != v8 || *v12 != v9 )
  {
    ++v14;
    ++v13;
    v12 += 3;
    if ( v14 >= v6->sizes.mData[v10] )
      return;
  }
  prims = mData[v10].prims;
  v16 = *((_BYTE *)p + 113);
  if ( v16 == 1 )
  {
    p_groundedPrims = &prims[v13].groundedPrims;
    goto LABEL_12;
  }
  if ( !v16 )
  {
    p_groundedPrims = &prims[v13].dynamicPrims;
LABEL_12:
    RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::remove(p_groundedPrims, p, &v6->pools->primitiveArrayPool);
  }
  if ( stru_2AAF660.value )
    --this->levels.mData[level]->cellPrimitiveCount;
  v18.index.nodeIndex = 1;
  *((_DWORD *)&v18.index + 3) = v10;
  LOBYTE(v18.container) = v14;
  RBX::Collision::GridHierarchy::cleanupCellAndItsAncestors(this, level, v18);
}


// Address: 0x1df6910 | Name: _ZN3RBX9Collision13GridHierarchy31primitiveExtentsChangedInternalEPNS_14ContactManagerEPNS_9PrimitiveEiRKNS_7ExtentsEb
void __fastcall RBX::Collision::GridHierarchy::primitiveExtentsChangedInternal(
        RBX::Collision::GridHierarchy *this,
        RBX::ContactManager *contactManager,
        RBX::Primitive *p,
        int newLevel,
        const RBX::Extents *newExtents,
        bool createContacts)
{
  bool v6; // r13
  RBX::ContactManager *v7; // r12
  int v8; // eax
  size_t v9; // rbp
  int v10; // r14d
  int v11; // r12d
  int v12; // r15d
  int v13; // r13d
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm3
  __m128 v18; // xmm2
  __m128 v19; // xmm6
  __m128 v20; // xmm7
  __m128 v21; // xmm6
  __m128 v22; // xmm7
  RBX::ExtentsInt32 *v23; // r14
  __m128 v24; // xmm7
  __m128 v25; // xmm0
  __m128 v26; // xmm1
  __m128i v27; // xmm0
  __m128 v28; // xmm3
  __m128 v29; // xmm4
  __m128i v30; // xmm3
  RBX::Primitive *v31; // rbp
  size_t v32; // r15
  int32_t v33; // r13d
  int v34; // r12d
  int32_t v35; // ebp
  int32_t v36; // ebx
  int v37; // eax
  int v38; // eax
  bool v40; // [rsp+4h] [rbp-C4h]
  int v41; // [rsp+8h] [rbp-C0h]
  int32_t v42; // [rsp+8h] [rbp-C0h]
  int v43; // [rsp+Ch] [rbp-BCh]
  int32_t v44; // [rsp+Ch] [rbp-BCh]
  RBX::Collision::GridHierarchy *v45; // [rsp+10h] [rbp-B8h]
  RBX::Primitive *v46; // [rsp+18h] [rbp-B0h]
  int v47; // [rsp+20h] [rbp-A8h]
  int32_t v48; // [rsp+20h] [rbp-A8h]
  RBX::ExtentsInt32 cellCoord; // [rsp+38h] [rbp-90h] BYREF
  RBX::ExtentsInt32 oldBox; // [rsp+50h] [rbp-78h] BYREF
  RBX::ContactManager *v51; // [rsp+68h] [rbp-60h]
  __m128 v52; // [rsp+70h] [rbp-58h]
  RBX::Collision::CellCoord v53; // [rsp+88h] [rbp-40h] BYREF

  v6 = createContacts;
  v7 = contactManager;
  v8 = *((char *)p + 112);
  v46 = p;
  v45 = this;
  if ( (unsigned int)(newLevel + 1 - v8) < 2 )
  {
    v15 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << v8), 0));
    v16 = _mm_rcp_ps(v15);
    v17 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v16, v15)), v16);
    v18 = _mm_and_ps(v17, (__m128)xmmword_3E5B40);
    v19 = _mm_and_ps((__m128)xmmword_3E5B40, v15);
    v20 = _mm_and_ps(_mm_cmpeq_ps(v19, (__m128)xmmword_3EB1D0), v15);
    v21 = _mm_and_ps(
            _mm_cmpneq_ps(v19, (__m128)xmmword_3EB1D0),
            _mm_or_ps(
              _mm_and_ps(_mm_cmpnlt_ps(v18, (__m128)xmmword_3EB1D0), v16),
              _mm_and_ps(_mm_cmplt_ps(v18, (__m128)xmmword_3EB1D0), v17)));
    v22 = _mm_and_ps(v20, *(__m128 *)&stru_3E4970.x);
    if ( !(_BYTE)byte_29FEDE8 )
    {
      v52 = v21;
      v37 = __cxa_guard_acquire(&byte_29FEDE8);
      p = v46;
      if ( v37 )
      {
        *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
        *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
        __cxa_guard_release(&byte_29FEDE8);
        v21 = v52;
        p = v46;
      }
    }
    v23 = (RBX::ExtentsInt32 *)((char *)p + 88);
    v24 = _mm_or_ps(v22, v21);
    cellCoord.low = *(RBX::Vector3int32 *)byte_29FEDD8;
    if ( !(_BYTE)byte_29FEE18 )
    {
      v38 = __cxa_guard_acquire(&byte_29FEE18);
      p = v46;
      if ( v38 )
      {
        qword_29FEE08 = 0x8000000080000000LL;
        dword_29FEE10 = 0x80000000;
        __cxa_guard_release(&byte_29FEE18);
        p = v46;
      }
    }
    v25 = _mm_mul_ps(
            _mm_min_ps(
              (__m128)xmmword_3E8210,
              _mm_max_ps(
                (__m128)xmmword_3E5450,
                _mm_unpacklo_ps(
                  _mm_unpacklo_ps((__m128)LODWORD(newExtents->low.x), (__m128)LODWORD(newExtents->low.z)),
                  (__m128)LODWORD(newExtents->low.y)))),
            v24);
    v26 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v25));
    v27 = _mm_cvttps_epi32(_mm_sub_ps(v26, _mm_and_ps(_mm_cmplt_ps(v25, v26), (__m128)stru_3E5460)));
    *(_QWORD *)&cellCoord.low.x = __PAIR64__(_mm_cvtsi128_si32(_mm_shuffle_epi32(v27, 229)), _mm_cvtsi128_si32(v27));
    cellCoord.low.z = _mm_cvtsi128_si32(_mm_shuffle_epi32(v27, 78));
    v28 = _mm_mul_ps(
            _mm_min_ps(
              (__m128)xmmword_3E8210,
              _mm_max_ps(
                (__m128)xmmword_3E5450,
                _mm_unpacklo_ps(
                  _mm_unpacklo_ps((__m128)LODWORD(newExtents->high.x), (__m128)LODWORD(newExtents->high.z)),
                  (__m128)LODWORD(newExtents->high.y)))),
            v24);
    v29 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v28));
    v30 = _mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v29, v28), (__m128)stru_3E5460), v29));
    cellCoord.high.x = _mm_cvtsi128_si32(v30);
    cellCoord.high.y = _mm_cvtsi128_si32(_mm_shuffle_epi32(v30, 229));
    cellCoord.high.z = _mm_cvtsi128_si32(_mm_shuffle_epi32(v30, 78));
    oldBox = *v23;
    if ( *(_QWORD *)&oldBox.low.x != *(_QWORD *)&cellCoord.low.x
      || oldBox.low.z != cellCoord.low.z
      || oldBox.high.x != cellCoord.high.x
      || oldBox.high.y != cellCoord.high.y
      || oldBox.high.z != cellCoord.high.z )
    {
      if ( oldBox.high.x <= cellCoord.low.x
        || oldBox.high.y <= cellCoord.low.y
        || oldBox.high.z <= cellCoord.low.z
        || oldBox.low.y >= cellCoord.high.y
        || oldBox.low.x >= cellCoord.high.x
        || oldBox.low.z >= cellCoord.high.z )
      {
        v32 = *((char *)p + 112);
        if ( v32 != -1 )
        {
          v40 = v6;
          v51 = contactManager;
          v33 = *((_DWORD *)p + 22);
          v44 = *((_DWORD *)p + 25);
          if ( v33 < v44 )
          {
            v42 = *((_DWORD *)p + 23);
            v52.m128_i32[0] = *((_DWORD *)p + 24);
            v48 = *((_DWORD *)p + 26);
            v34 = *((_DWORD *)p + 27);
            do
            {
              v35 = v42;
              if ( v42 < v48 )
              {
                do
                {
                  v36 = v52.m128_i32[0];
                  if ( v52.m128_i32[0] < v34 )
                  {
                    do
                    {
                      v53.v[0] = v33;
                      v53.v[1] = v35;
                      v53.v[2] = v36;
                      RBX::Collision::GridHierarchy::removePrimitiveFromCell(this, p, v32, &v53);
                      this = v45;
                      p = v46;
                      ++v36;
                    }
                    while ( v34 != v36 );
                  }
                  ++v35;
                }
                while ( v35 != v48 );
              }
              ++v33;
            }
            while ( v33 != v44 );
          }
          if ( stru_2AAF660.value )
            --this->levels.mData[v32]->primitiveCount;
          *((_WORD *)p + 56) = 767;
          v7 = v51;
          v6 = v40;
        }
        RBX::Collision::GridHierarchy::addPrimitive(this, v7, p, v6);
      }
      else
      {
        v31 = p;
        RBX::Collision::GridHierarchy::movePrimitiveBetweenBoxes(this, contactManager, p, &oldBox, &cellCoord, v6);
        v23->low = cellCoord.low;
        *(RBX::Vector3int32 *)((char *)v31 + 100) = cellCoord.high;
      }
    }
  }
  else
  {
    if ( (_BYTE)v8 != 0xFF )
    {
      v51 = contactManager;
      v9 = v8;
      v10 = *((_DWORD *)p + 22);
      v43 = *((_DWORD *)p + 25);
      if ( v10 < v43 )
      {
        v41 = *((_DWORD *)p + 23);
        v52.m128_i32[0] = *((_DWORD *)p + 24);
        v47 = *((_DWORD *)p + 26);
        v11 = *((_DWORD *)p + 27);
        do
        {
          v12 = v41;
          if ( v41 < v47 )
          {
            do
            {
              v13 = v52.m128_i32[0];
              if ( v52.m128_i32[0] < v11 )
              {
                do
                {
                  cellCoord.low.x = v10;
                  cellCoord.low.y = v12;
                  cellCoord.low.z = v13;
                  RBX::Collision::GridHierarchy::removePrimitiveFromCell(
                    this,
                    p,
                    v9,
                    (const RBX::Collision::CellCoord *)&cellCoord);
                  this = v45;
                  p = v46;
                  ++v13;
                }
                while ( v11 != v13 );
              }
              ++v12;
            }
            while ( v12 != v47 );
          }
          ++v10;
        }
        while ( v10 != v43 );
      }
      if ( stru_2AAF660.value )
        --this->levels.mData[v9]->primitiveCount;
      *((_WORD *)p + 56) = 767;
      v7 = v51;
      v6 = createContacts;
    }
    RBX::Collision::GridHierarchy::addPrimitive(this, v7, p, v6);
  }
}


// Address: 0x1df6e50 | Name: _ZN3RBX9Collision13GridHierarchy15removePrimitiveEPNS_14ContactManagerEPNS_9PrimitiveE
void __fastcall RBX::Collision::GridHierarchy::removePrimitive(
        RBX::Collision::GridHierarchy *this,
        RBX::ContactManager *contactManager,
        RBX::Primitive *p)
{
  size_t v3; // rbp
  int32_t v5; // r13d
  int32_t v6; // r12d
  int32_t v7; // eax
  int32_t v8; // r14d
  size_t v9; // rdx
  int32_t v10; // ebp
  int32_t v11; // [rsp+0h] [rbp-58h]
  int32_t v12; // [rsp+4h] [rbp-54h]
  int32_t v13; // [rsp+8h] [rbp-50h]
  int32_t v14; // [rsp+Ch] [rbp-4Ch]
  RBX::Collision::CellCoord cellCoord; // [rsp+10h] [rbp-48h] BYREF
  size_t v16; // [rsp+20h] [rbp-38h]

  v3 = *((char *)p + 112);
  if ( v3 != -1 )
  {
    v5 = *((_DWORD *)p + 22);
    v13 = *((_DWORD *)p + 25);
    if ( v5 < v13 )
    {
      v12 = *((_DWORD *)p + 23);
      v14 = *((_DWORD *)p + 24);
      v11 = *((_DWORD *)p + 26);
      v6 = *((_DWORD *)p + 27);
      v16 = *((char *)p + 112);
      do
      {
        v7 = v12;
        if ( v12 < v11 )
        {
          do
          {
            v8 = v14;
            if ( v14 < v6 )
            {
              do
              {
                cellCoord.v[0] = v5;
                cellCoord.v[1] = v7;
                cellCoord.v[2] = v8;
                v9 = v3;
                v10 = v7;
                RBX::Collision::GridHierarchy::removePrimitiveFromCell(this, p, v9, &cellCoord);
                v7 = v10;
                v3 = v16;
                ++v8;
              }
              while ( v6 != v8 );
            }
            ++v7;
          }
          while ( v7 != v11 );
        }
        ++v5;
      }
      while ( v5 != v13 );
    }
    if ( stru_2AAF660.value )
      --this->levels.mData[v3]->primitiveCount;
    *((_WORD *)p + 56) = 767;
  }
}


// Address: 0x1df6f50 | Name: _ZN3RBX9Collision13GridHierarchy23primitiveExtentsChangedEPNS_14ContactManagerEPNS_9PrimitiveE
void __fastcall RBX::Collision::GridHierarchy::primitiveExtentsChanged(
        RBX::Collision::GridHierarchy *this,
        RBX::ContactManager *contactManager,
        RBX::Primitive *p)
{
  const RBX::Extents *FastFuzzyExtents; // rbx
  __int128 v5; // xmm0
  int v6; // eax
  RBX::Extents v7[2]; // [rsp+0h] [rbp-38h] BYREF

  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(p);
  if ( RBX::Math::isNanInfVector3(&FastFuzzyExtents->low) || RBX::Math::isNanInfVector3(&FastFuzzyExtents->high) )
  {
    *(_QWORD *)&v7[0].high.y = *(_QWORD *)&byte_29FC388[16];
    v5 = *(_OWORD *)byte_29FC388;
  }
  else
  {
    *(_QWORD *)&v7[0].high.y = *(_QWORD *)&FastFuzzyExtents->high.y;
    v5 = *(_OWORD *)&FastFuzzyExtents->low.x;
  }
  *(_OWORD *)&v7[0].low.x = v5;
  v6 = RBX::Collision::computeLevel(p, v7);
  RBX::Collision::GridHierarchy::primitiveExtentsChangedInternal(this, contactManager, p, v6, v7, 1);
}


// Address: 0x1df6fe0 | Name: _ZNK3RBX9Collision13GridHierarchy35updatePrimitiveNewExtentsAndLevelMTEPNS_9PrimitiveERNS_7ExtentsERiRbRNS_12ExtentsInt32E
bool __fastcall RBX::Collision::GridHierarchy::updatePrimitiveNewExtentsAndLevelMT(
        const RBX::Collision::GridHierarchy *this,
        RBX::Primitive *p,
        RBX::Extents *newExtents,
        int *newLevel,
        bool *levelChanged,
        RBX::ExtentsInt32 *newGridExtents)
{
  const RBX::Extents *FastFuzzyExtents; // rbp
  __int128 v11; // xmm0
  int v12; // eax
  int v13; // edx
  bool result; // al
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm3
  __m128 v18; // xmm2
  __m128 v19; // xmm6
  __m128 v20; // xmm7
  __m128 v21; // xmm6
  __m128 v22; // xmm7
  __m128 v23; // xmm7
  __m128 v24; // xmm0
  __m128 v25; // xmm1
  __m128i v26; // xmm2
  __m128i v27; // xmm1
  __m128 v28; // xmm8
  __m128 v29; // xmm3
  __m128 v30; // xmm0
  __m128 v31; // xmm5
  __m128i v32; // xmm4
  __m128i v33; // xmm3
  __int64 v34; // [rsp+20h] [rbp-58h]

  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(p);
  if ( RBX::Math::isNanInfVector3(&FastFuzzyExtents->low) || RBX::Math::isNanInfVector3(&FastFuzzyExtents->high) )
  {
    v34 = *(_QWORD *)&byte_29FC388[16];
    v11 = *(_OWORD *)byte_29FC388;
  }
  else
  {
    v34 = *(_QWORD *)&FastFuzzyExtents->high.y;
    v11 = *(_OWORD *)&FastFuzzyExtents->low.x;
  }
  *(_QWORD *)&newExtents->high.y = v34;
  *(_OWORD *)&newExtents->low.x = v11;
  v12 = RBX::Collision::computeLevel(p, newExtents);
  *newLevel = v12;
  v13 = *((char *)p + 112);
  if ( (unsigned int)(v12 + 1 - v13) < 2 )
  {
    *levelChanged = 0;
    v15 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << v13), 0));
    v16 = _mm_rcp_ps(v15);
    v17 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v16, v15)), v16);
    v18 = _mm_and_ps(v17, (__m128)xmmword_3E5B40);
    v19 = _mm_and_ps((__m128)xmmword_3E5B40, v15);
    v20 = _mm_and_ps(_mm_cmpeq_ps(v19, (__m128)xmmword_3EB1D0), v15);
    v21 = _mm_and_ps(
            _mm_cmpneq_ps(v19, (__m128)xmmword_3EB1D0),
            _mm_or_ps(
              _mm_and_ps(_mm_cmpnlt_ps(v18, (__m128)xmmword_3EB1D0), v16),
              _mm_and_ps(_mm_cmplt_ps(v18, (__m128)xmmword_3EB1D0), v17)));
    v22 = _mm_and_ps(v20, *(__m128 *)&stru_3E4970.x);
    if ( !(_BYTE)byte_29FEDE8 && __cxa_guard_acquire(&byte_29FEDE8) )
    {
      *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
      *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
      __cxa_guard_release(&byte_29FEDE8);
    }
    v23 = _mm_or_ps(v22, v21);
    if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
    {
      qword_29FEE08 = 0x8000000080000000LL;
      dword_29FEE10 = 0x80000000;
      __cxa_guard_release(&byte_29FEE18);
    }
    v24 = _mm_mul_ps(
            _mm_min_ps(
              (__m128)xmmword_3E8210,
              _mm_max_ps(
                (__m128)xmmword_3E5450,
                _mm_unpacklo_ps(
                  _mm_unpacklo_ps((__m128)LODWORD(newExtents->low.x), (__m128)LODWORD(newExtents->low.z)),
                  (__m128)LODWORD(newExtents->low.y)))),
            v23);
    v25 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v24));
    v26 = _mm_cvttps_epi32(_mm_sub_ps(v25, _mm_and_ps(_mm_cmplt_ps(v24, v25), (__m128)stru_3E5460)));
    v27 = _mm_shuffle_epi32(v26, 229);
    v28 = (__m128)_mm_shuffle_epi32(v26, 78);
    v29 = _mm_mul_ps(
            _mm_min_ps(
              (__m128)xmmword_3E8210,
              _mm_max_ps(
                (__m128)xmmword_3E5450,
                _mm_unpacklo_ps(
                  _mm_unpacklo_ps((__m128)LODWORD(newExtents->high.x), (__m128)LODWORD(newExtents->high.z)),
                  (__m128)LODWORD(newExtents->high.y)))),
            v23);
    v30 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v29));
    v31 = (__m128)_mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v30, v29), (__m128)stru_3E5460), v30));
    v32 = _mm_shuffle_epi32((__m128i)v31, 229);
    v33 = _mm_shuffle_epi32((__m128i)v31, 78);
    *(__m128 *)&newGridExtents->low.x = _mm_shuffle_ps(
                                          (__m128)_mm_unpacklo_epi32(v26, v27),
                                          _mm_shuffle_ps(v31, v28, 0),
                                          36);
    newGridExtents->high.y = _mm_cvtsi128_si32(v32);
    newGridExtents->high.z = _mm_cvtsi128_si32(v33);
    result = 1;
    if ( !*levelChanged
      && *((_DWORD *)p + 22) == _mm_cvtsi128_si32(v26)
      && *((_DWORD *)p + 23) == _mm_cvtsi128_si32(v27)
      && *((_DWORD *)p + 24) == _mm_cvtsi128_si32((__m128i)v28)
      && *((_DWORD *)p + 25) == _mm_cvtsi128_si32((__m128i)v31)
      && *((_DWORD *)p + 26) == _mm_cvtsi128_si32(v32) )
    {
      return *((_DWORD *)p + 27) != _mm_cvtsi128_si32(v33);
    }
  }
  else
  {
    *levelChanged = 1;
    return 1;
  }
  return result;
}


// Address: 0x1df72e0 | Name: _ZN3RBX9Collision13GridHierarchy29primitiveExtentsChangedPostMTEPNS_14ContactManagerEPNS_9PrimitiveERKNS_7ExtentsEbRKNS_12ExtentsInt32E
void __fastcall RBX::Collision::GridHierarchy::primitiveExtentsChangedPostMT(
        RBX::Collision::GridHierarchy *this,
        RBX::ContactManager *contactManager,
        RBX::Primitive *p,
        const RBX::Extents *newExtents,
        bool levelChanged,
        const RBX::ExtentsInt32 *newGridExtents)
{
  RBX::Primitive *v6; // rbp
  size_t v7; // rdx
  int v8; // r14d
  int v9; // r12d
  int v10; // r13d
  int v11; // r15d
  const RBX::Primitive *v12; // rsi
  size_t v13; // rbp
  _QWORD *v15; // r14
  size_t v16; // rdx
  int32_t v17; // r14d
  int32_t v18; // r12d
  int32_t v19; // r13d
  int32_t v20; // ebx
  const RBX::Primitive *v21; // rsi
  size_t v22; // rbp
  int v23; // [rsp+8h] [rbp-80h]
  int32_t v24; // [rsp+8h] [rbp-80h]
  int v25; // [rsp+Ch] [rbp-7Ch]
  int32_t v26; // [rsp+Ch] [rbp-7Ch]
  int v27; // [rsp+10h] [rbp-78h]
  int32_t v28; // [rsp+10h] [rbp-78h]
  int v29; // [rsp+14h] [rbp-74h]
  int32_t v30; // [rsp+14h] [rbp-74h]
  RBX::ExtentsInt32 cellCoord; // [rsp+20h] [rbp-68h] BYREF
  RBX::ContactManager *v32; // [rsp+38h] [rbp-50h]
  RBX::Primitive *v33; // [rsp+40h] [rbp-48h]
  RBX::Collision::CellCoord v34; // [rsp+48h] [rbp-40h] BYREF

  v6 = p;
  v33 = p;
  if ( levelChanged )
  {
    v7 = *((char *)p + 112);
    if ( v7 != -1 )
    {
      v32 = contactManager;
      v8 = *((_DWORD *)v6 + 22);
      v27 = *((_DWORD *)v6 + 25);
      if ( v8 < v27 )
      {
        v25 = *((_DWORD *)v6 + 23);
        v29 = *((_DWORD *)v6 + 24);
        v23 = *((_DWORD *)v6 + 26);
        v9 = *((_DWORD *)v6 + 27);
        do
        {
          v10 = v25;
          if ( v25 < v23 )
          {
            do
            {
              v11 = v29;
              if ( v29 < v9 )
              {
                do
                {
                  cellCoord.low.x = v8;
                  cellCoord.low.y = v10;
                  cellCoord.low.z = v11;
                  v12 = v6;
                  v13 = v7;
                  RBX::Collision::GridHierarchy::removePrimitiveFromCell(
                    this,
                    v12,
                    v7,
                    (const RBX::Collision::CellCoord *)&cellCoord);
                  v7 = v13;
                  v6 = v33;
                  ++v11;
                }
                while ( v9 != v11 );
              }
              ++v10;
            }
            while ( v10 != v23 );
          }
          ++v8;
        }
        while ( v8 != v27 );
      }
      if ( stru_2AAF660.value )
        --this->levels.mData[v7]->primitiveCount;
      *((_WORD *)v6 + 56) = 767;
      contactManager = v32;
    }
    RBX::Collision::GridHierarchy::addPrimitive(this, contactManager, v6, 1);
  }
  else
  {
    cellCoord = *(RBX::ExtentsInt32 *)((char *)p + 88);
    if ( newGridExtents->low.x >= cellCoord.high.x
      || newGridExtents->low.y >= cellCoord.high.y
      || newGridExtents->low.z >= cellCoord.high.z
      || newGridExtents->high.y <= cellCoord.low.y
      || newGridExtents->high.x <= cellCoord.low.x
      || newGridExtents->high.z <= cellCoord.low.z )
    {
      v16 = *((char *)p + 112);
      if ( v16 != -1 )
      {
        v32 = contactManager;
        v17 = *((_DWORD *)v6 + 22);
        v28 = *((_DWORD *)v6 + 25);
        if ( v17 < v28 )
        {
          v26 = *((_DWORD *)v6 + 23);
          v30 = *((_DWORD *)v6 + 24);
          v24 = *((_DWORD *)v6 + 26);
          v18 = *((_DWORD *)v6 + 27);
          do
          {
            v19 = v26;
            if ( v26 < v24 )
            {
              do
              {
                v20 = v30;
                if ( v30 < v18 )
                {
                  do
                  {
                    v34.v[0] = v17;
                    v34.v[1] = v19;
                    v34.v[2] = v20;
                    v21 = v6;
                    v22 = v16;
                    RBX::Collision::GridHierarchy::removePrimitiveFromCell(this, v21, v16, &v34);
                    v16 = v22;
                    v6 = v33;
                    ++v20;
                  }
                  while ( v18 != v20 );
                }
                ++v19;
              }
              while ( v19 != v24 );
            }
            ++v17;
          }
          while ( v17 != v28 );
        }
        if ( stru_2AAF660.value )
          --this->levels.mData[v16]->primitiveCount;
        *((_WORD *)v6 + 56) = 767;
        contactManager = v32;
      }
      RBX::Collision::GridHierarchy::addPrimitive(this, contactManager, v6, 1);
    }
    else
    {
      v15 = (_QWORD *)((char *)p + 88);
      RBX::Collision::GridHierarchy::movePrimitiveBetweenBoxes(this, contactManager, p, &cellCoord, newGridExtents, 1);
      *((_DWORD *)v6 + 24) = newGridExtents->low.z;
      *v15 = *(_QWORD *)&newGridExtents->low.x;
      *((_DWORD *)v6 + 27) = newGridExtents->high.z;
      *(_QWORD *)((char *)v6 + 100) = *(_QWORD *)&newGridExtents->high.x;
    }
  }
}


// Address: 0x1df7580 | Name: _ZN3RBX9Collision13GridHierarchy24addContactsWithPrimitiveEPNS_14ContactManagerEPNS_9PrimitiveE
void __fastcall RBX::Collision::GridHierarchy::addContactsWithPrimitive(
        RBX::Collision::GridHierarchy *this,
        RBX::ContactManager *contactManager,
        RBX::Primitive *p)
{
  RBX::Primitive *v3; // r14
  const RBX::Extents *FastFuzzyExtents; // rbx
  __int128 v5; // xmm0
  unsigned int v6; // ebx
  int v7; // eax
  __m128 v8; // xmm1
  __m128 v9; // xmm0
  __m128 v10; // xmm3
  __m128 v11; // xmm2
  __m128 v12; // xmm5
  __m128 v13; // xmm0
  __m128 v14; // xmm1
  __m128 v15; // xmm2
  __m128i v16; // xmm1
  int v17; // ebx
  int v18; // ecx
  __m128 v19; // xmm1
  __m128 v20; // xmm0
  __m128i v21; // xmm0
  int v22; // r8d
  __int64 v23; // r9
  int v24; // r14d
  int v25; // r12d
  int v26; // ebp
  __int64 v27; // r13
  RBX::Collision::LevelGrid *v28; // rax
  __int64 v29; // rcx
  int32_t *v30; // rsi
  unsigned __int64 v31; // rbp
  size_t i; // r8
  size_t v33; // rbx
  int v34; // r12d
  int v35; // r14d
  RBX::Collision::CellBinIndexType v36; // r13d
  int v37; // r15d
  int v38; // eax
  __m128 v39; // xmm1
  int v40; // eax
  __m128 v41; // xmm0
  __m128 v42; // xmm1
  __m128 v43; // xmm3
  __m128 v44; // xmm2
  __m128 v45; // xmm4
  __m128 v46; // xmm1
  __m128 v47; // xmm7
  __m128 v48; // xmm7
  __m128 v49; // xmm0
  __m128 v50; // xmm1
  __m128i v51; // xmm0
  int v52; // ebx
  __m128 v53; // xmm1
  __m128 v54; // xmm2
  __m128i v55; // xmm1
  int v56; // r12d
  int v57; // r14d
  int v58; // r15d
  RBX::Collision::LevelGrid *v59; // rax
  __int64 v60; // rcx
  int32_t *v61; // rsi
  unsigned __int64 v62; // rbp
  int v63; // [rsp+8h] [rbp-C0h]
  signed int v64; // [rsp+8h] [rbp-C0h]
  int v65[2]; // [rsp+8h] [rbp-C0h]
  RBX::Collision::GridHierarchy *v66; // [rsp+10h] [rbp-B8h]
  int v67; // [rsp+1Ch] [rbp-ACh]
  int v68; // [rsp+1Ch] [rbp-ACh]
  signed int v69; // [rsp+20h] [rbp-A8h]
  int v70; // [rsp+24h] [rbp-A4h]
  int v71; // [rsp+24h] [rbp-A4h]
  RBX::Primitive *v72; // [rsp+28h] [rbp-A0h]
  RBX::Primitive *v73; // [rsp+28h] [rbp-A0h]
  int v74; // [rsp+30h] [rbp-98h]
  int v75; // [rsp+30h] [rbp-98h]
  int v76; // [rsp+30h] [rbp-98h]
  RBX::Collision::CellIterator cell; // [rsp+48h] [rbp-80h] BYREF
  RBX::Extents extents; // [rsp+60h] [rbp-68h] BYREF
  __m128 v79; // [rsp+80h] [rbp-48h]
  RBX::ContactManager *v80; // [rsp+90h] [rbp-38h]

  v3 = p;
  v80 = contactManager;
  v66 = this;
  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(p);
  if ( RBX::Math::isNanInfVector3(&FastFuzzyExtents->low) || RBX::Math::isNanInfVector3(&FastFuzzyExtents->high) )
  {
    *(_QWORD *)&extents.high.y = *(_QWORD *)&byte_29FC388[16];
    v5 = *(_OWORD *)byte_29FC388;
  }
  else
  {
    *(_QWORD *)&extents.high.y = *(_QWORD *)&FastFuzzyExtents->high.y;
    v5 = *(_OWORD *)&FastFuzzyExtents->low.x;
  }
  *(_OWORD *)&extents.low.x = v5;
  v63 = RBX::Collision::computeLevel(v3, &extents);
  v6 = 1 << dword_2868B08 << v63;
  if ( !(_BYTE)byte_29FEDE8 && __cxa_guard_acquire(&byte_29FEDE8) )
  {
    *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
    *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
    __cxa_guard_release(&byte_29FEDE8);
  }
  if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
  {
    qword_29FEE08 = 0x8000000080000000LL;
    dword_29FEE10 = 0x80000000;
    __cxa_guard_release(&byte_29FEE18);
  }
  v7 = *((char *)v3 + 112);
  if ( *((_BYTE *)v3 + 113) != *((_BYTE *)v3 + 114) )
    goto LABEL_35;
  if ( v63 != v7 )
    goto LABEL_35;
  v8 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v6), 0));
  v9 = _mm_rcp_ps(v8);
  v10 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v9, v8)), v9);
  v11 = _mm_and_ps(v10, (__m128)xmmword_3E5B40);
  v12 = _mm_and_ps(v8, (__m128)xmmword_3E5B40);
  v13 = _mm_or_ps(
          _mm_and_ps(_mm_and_ps(_mm_cmpeq_ps(v12, (__m128)xmmword_3EB1D0), v8), *(__m128 *)&stru_3E4970.x),
          _mm_and_ps(
            _mm_cmpneq_ps(v12, (__m128)xmmword_3EB1D0),
            _mm_or_ps(
              _mm_and_ps(_mm_cmpnlt_ps(v11, (__m128)xmmword_3EB1D0), v9),
              _mm_and_ps(_mm_cmplt_ps(v11, (__m128)xmmword_3EB1D0), v10))));
  v14 = _mm_mul_ps(
          _mm_min_ps(
            (__m128)xmmword_3E8210,
            _mm_max_ps(
              (__m128)xmmword_3E5450,
              _mm_unpacklo_ps(
                _mm_unpacklo_ps((__m128)LODWORD(extents.low.x), (__m128)LODWORD(extents.low.z)),
                (__m128)LODWORD(extents.low.y)))),
          v13);
  v15 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v14));
  v16 = _mm_cvttps_epi32(_mm_sub_ps(v15, _mm_and_ps(_mm_cmplt_ps(v14, v15), (__m128)stru_3E5460)));
  v17 = _mm_cvtsi128_si32(v16);
  if ( v17 != *((_DWORD *)v3 + 22) )
    goto LABEL_35;
  v18 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v16, 229));
  if ( v18 != *((_DWORD *)v3 + 23) )
    goto LABEL_35;
  v74 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v16, 78));
  if ( v74 == *((_DWORD *)v3 + 24)
    && (v19 = _mm_mul_ps(
                _mm_min_ps(
                  (__m128)xmmword_3E8210,
                  _mm_max_ps(
                    (__m128)xmmword_3E5450,
                    _mm_unpacklo_ps(
                      _mm_unpacklo_ps((__m128)LODWORD(extents.high.x), (__m128)LODWORD(extents.high.z)),
                      (__m128)LODWORD(extents.high.y)))),
                v13),
        v20 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v19)),
        v21 = _mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v20, v19), (__m128)stru_3E5460), v20)),
        v67 = _mm_cvtsi128_si32(v21),
        v67 == *((_DWORD *)v3 + 25))
    && (v79.m128_i32[0] = _mm_cvtsi128_si32(_mm_shuffle_epi32(v21, 229)), v79.m128_i32[0] == *((_DWORD *)v3 + 26))
    && (v22 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v21, 78)), v22 == *((_DWORD *)v3 + 27)) )
  {
    v72 = v3;
    if ( v17 < v67 )
    {
      v23 = v63;
      v70 = v18;
      do
      {
        if ( v18 < v79.m128_i32[0] )
        {
          v24 = v70;
          do
          {
            if ( v74 < v22 )
            {
              v25 = v74;
              do
              {
                v28 = this->levels.mData[v23];
                v29 = ((73856093 * v17)
                     ^ (19349663 * v24)
                     ^ (83492791 * v25))
                    & (unsigned int)(LODWORD(v28->sizes.mSize) - 1);
                if ( v28->sizes.mData[v29] )
                {
                  v30 = &v28->bins.mData[v29].coords->v[2];
                  v31 = 0;
                  while ( *(v30 - 2) != v17 || *(v30 - 1) != v24 || *v30 != v25 )
                  {
                    ++v31;
                    v30 += 3;
                    if ( v31 >= v28->sizes.mData[v29] )
                      goto LABEL_29;
                  }
                  cell.index.valid = 1;
                  cell.index.binIndex.data = v29;
                  cell.index.nodeIndex = v31;
                  cell.container = v28;
                  v26 = v22;
                  v27 = v23;
                  RBX::Collision::addContactsWithCell(v80, v72, &cell);
                  v23 = v27;
                  v22 = v26;
                  this = v66;
                  if ( v63 > 0 )
                  {
                    RBX::Collision::GridHierarchy::addContactsFromChildren(v66, v80, v63, &cell, v72);
                    v23 = v27;
                    v22 = v26;
                    this = v66;
                  }
                }
                else
                {
LABEL_29:
                  cell.index.valid = 0;
                  cell.index.binIndex.data = v29;
                  cell.container = v28;
                }
                ++v25;
              }
              while ( v25 != v22 );
            }
            ++v24;
          }
          while ( v24 != v79.m128_i32[0] );
        }
        ++v17;
        v18 = v70;
      }
      while ( v17 != v67 );
    }
    for ( i = v63 + 1; i < this->levels.mSize; ++i )
    {
      v41 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << i), 0));
      v42 = _mm_rcp_ps(v41);
      v43 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v42, v41)), v42);
      v44 = _mm_and_ps(v43, (__m128)xmmword_3E5B40);
      v45 = _mm_or_ps(
              _mm_and_ps(_mm_cmpnlt_ps(v44, (__m128)xmmword_3EB1D0), v42),
              _mm_and_ps(_mm_cmplt_ps(v44, (__m128)xmmword_3EB1D0), v43));
      v46 = _mm_and_ps(v41, (__m128)xmmword_3E5B40);
      v47 = _mm_and_ps(_mm_and_ps(_mm_cmpeq_ps(v46, (__m128)xmmword_3EB1D0), v41), *(__m128 *)&stru_3E4970.x);
      v39 = _mm_and_ps(_mm_cmpneq_ps(v46, (__m128)xmmword_3EB1D0), v45);
      *(_QWORD *)v65 = i;
      if ( !(_BYTE)byte_29FEDE8 )
      {
        v79 = v39;
        v38 = __cxa_guard_acquire(&byte_29FEDE8);
        v39 = v79;
        i = *(_QWORD *)v65;
        this = v66;
        if ( v38 )
        {
          *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
          *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
          __cxa_guard_release(&byte_29FEDE8);
          v39 = v79;
          i = *(_QWORD *)v65;
          this = v66;
        }
      }
      v48 = _mm_or_ps(v47, v39);
      if ( !(_BYTE)byte_29FEE18 )
      {
        v40 = __cxa_guard_acquire(&byte_29FEE18);
        i = *(_QWORD *)v65;
        this = v66;
        if ( v40 )
        {
          qword_29FEE08 = 0x8000000080000000LL;
          dword_29FEE10 = 0x80000000;
          __cxa_guard_release(&byte_29FEE18);
          i = *(_QWORD *)v65;
          this = v66;
        }
      }
      v49 = _mm_mul_ps(
              _mm_min_ps(
                (__m128)xmmword_3E8210,
                _mm_max_ps(
                  (__m128)xmmword_3E5450,
                  _mm_unpacklo_ps(
                    _mm_unpacklo_ps((__m128)LODWORD(extents.low.x), (__m128)LODWORD(extents.low.z)),
                    (__m128)LODWORD(extents.low.y)))),
              v48);
      v50 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v49));
      v51 = _mm_cvttps_epi32(_mm_sub_ps(v50, _mm_and_ps(_mm_cmplt_ps(v49, v50), (__m128)stru_3E5460)));
      v52 = _mm_cvtsi128_si32(v51);
      v53 = _mm_mul_ps(
              _mm_min_ps(
                (__m128)xmmword_3E8210,
                _mm_max_ps(
                  (__m128)xmmword_3E5450,
                  _mm_unpacklo_ps(
                    _mm_unpacklo_ps((__m128)LODWORD(extents.high.x), (__m128)LODWORD(extents.high.z)),
                    (__m128)LODWORD(extents.high.y)))),
              v48);
      v54 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v53));
      v55 = _mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v54, v53), (__m128)stru_3E5460), v54));
      v71 = _mm_cvtsi128_si32(v55);
      if ( v52 < v71 )
      {
        v68 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v51, 229));
        v76 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v51, 78));
        v79.m128_i32[0] = _mm_cvtsi128_si32(_mm_shuffle_epi32(v55, 229));
        v56 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v55, 78));
        do
        {
          if ( v68 < v79.m128_i32[0] )
          {
            v57 = v68;
            do
            {
              if ( v76 < v56 )
              {
                v58 = v76;
                do
                {
                  v59 = this->levels.mData[i];
                  v60 = ((73856093 * v52)
                       ^ (19349663 * v57)
                       ^ (83492791 * v58))
                      & (unsigned int)(LODWORD(v59->sizes.mSize) - 1);
                  if ( v59->sizes.mData[v60] )
                  {
                    v61 = &v59->bins.mData[v60].coords->v[2];
                    v62 = 0;
                    while ( *(v61 - 2) != v52 || *(v61 - 1) != v57 || *v61 != v58 )
                    {
                      ++v62;
                      v61 += 3;
                      if ( v62 >= v59->sizes.mData[v60] )
                        goto LABEL_70;
                    }
                    cell.index.valid = 1;
                    cell.index.binIndex.data = v60;
                    cell.index.nodeIndex = v62;
                    cell.container = v59;
                    RBX::Collision::addContactsWithCell(v80, v72, &cell);
                    i = *(_QWORD *)v65;
                    this = v66;
                  }
                  else
                  {
LABEL_70:
                    cell.index.valid = 0;
                    cell.index.binIndex.data = v60;
                    cell.container = v59;
                  }
                  ++v58;
                }
                while ( v58 != v56 );
              }
              ++v57;
            }
            while ( v57 != v79.m128_i32[0] );
          }
          ++v52;
        }
        while ( v52 != v71 );
      }
    }
  }
  else
  {
LABEL_35:
    v33 = v7;
    if ( (v7 & 0x80u) == 0 )
    {
      v34 = *((_DWORD *)v3 + 22);
      v73 = v3;
      v79.m128_i32[0] = *((_DWORD *)v3 + 25);
      if ( v34 < v79.m128_i32[0] )
      {
        v69 = *((_DWORD *)v3 + 23);
        v75 = *((_DWORD *)v3 + 24);
        v64 = *((_DWORD *)v3 + 26);
        v35 = *((_DWORD *)v3 + 27);
        do
        {
          v36 = v69;
          if ( v69 < v64 )
          {
            do
            {
              v37 = v75;
              if ( v75 < v35 )
              {
                do
                {
                  *(_DWORD *)&cell.index.valid = v34;
                  cell.index.binIndex.data = v36;
                  *(_DWORD *)&cell.index.nodeIndex = v37;
                  RBX::Collision::GridHierarchy::removePrimitiveFromCell(
                    this,
                    v73,
                    v33,
                    (const RBX::Collision::CellCoord *)&cell);
                  this = v66;
                  ++v37;
                }
                while ( v35 != v37 );
              }
              ++v36;
            }
            while ( v36 != v64 );
          }
          ++v34;
        }
        while ( v34 != v79.m128_i32[0] );
      }
      if ( stru_2AAF660.value )
        --this->levels.mData[v33]->primitiveCount;
      v3 = v73;
      *((_WORD *)v73 + 56) = 767;
    }
    RBX::Collision::GridHierarchy::addPrimitive(this, v80, v3, 1);
  }
}


// Address: 0x1df7e50 | Name: _ZN3RBX9Collision13GridHierarchy26cleanupCellAndItsAncestorsEmNS0_9LevelGrid12CellIteratorE
void __fastcall RBX::Collision::GridHierarchy::cleanupCellAndItsAncestors(
        RBX::Collision::GridHierarchy *this,
        size_t level,
        __int64 a3)
{
  RBX::Collision::LevelGrid *v3; // rbx
  RBX::Collision::LevelGrid *mCapacity; // rdi
  __int64 mData_high; // rax
  RBX::Collision::LevelGrid::Bin *mData; // r8
  __int64 mSize_low; // rbp
  RBX::Collision::CellCoord *coords; // rax
  int v10; // r13d
  int v11; // ebp
  size_t v12; // rcx
  RBX::Collision::LevelGrid *v13; // rdi
  __int64 mSize; // rax
  __int64 cellCount; // rcx
  float v16; // xmm0_4
  __int64 v17; // rdx
  float v18; // xmm1_4
  __int64 v19; // rcx
  RBX::Collision::LevelGrid *v20; // r15
  RBX::Collision::LevelGrid *v21; // rdi
  __int64 v22; // r8
  int32_t *v23; // rax
  RBX::Collision::LevelGrid::BinSizeType v24; // al
  RBX::Collision::CellChildren *Children; // rax
  RBX::Collision::CellIterator v26; // [rsp+0h] [rbp-68h] BYREF
  RBX::Collision::LevelGrid *v27; // [rsp+18h] [rbp-50h]
  RBX::Collision::LevelGrid::CellIndex n; // [rsp+20h] [rbp-48h]
  RBX::Collision::LevelGrid *v29; // [rsp+30h] [rbp-38h]

  v3 = (RBX::Collision::LevelGrid *)a3;
  mCapacity = *(RBX::Collision::LevelGrid **)(a3 + 16);
  mData_high = *(unsigned int *)(a3 + 4);
  mData = mCapacity->bins.mData;
  mSize_low = *(unsigned __int8 *)(a3 + 8);
  if ( mData[mData_high].prims[mSize_low].groundedPrims.count
     + (unsigned __int64)mData[mData_high].prims[mSize_low].dynamicPrims.count )
  {
    return;
  }
  if ( level )
  {
    if ( RBX::Collision::LevelGrid::getChildren(mCapacity, (const RBX::Collision::LevelGrid::CellIndex *)a3)->childMask )
      return;
    mCapacity = (RBX::Collision::LevelGrid *)v3->sizes.mCapacity;
    mData_high = HIDWORD(v3->sizes.mData);
    mData = mCapacity->bins.mData;
    mSize_low = LOBYTE(v3->sizes.mSize);
  }
  coords = mData[mData_high].coords;
  *(_QWORD *)&v26.index.valid = (unsigned int)coords[mSize_low].v[0];
  v10 = coords[mSize_low].v[1];
  v11 = coords[mSize_low].v[2];
  RBX::Collision::LevelGrid::freeCell(mCapacity, (const RBX::Collision::LevelGrid::CellIndex *)v3);
  v3->sizes.mCapacity = 0;
  LOBYTE(v3->sizes.mData) = 0;
  v12 = 1;
  if ( this->lowestLevelInitBinCount >> level > 1 )
    v12 = this->lowestLevelInitBinCount >> level;
  v13 = this->levels.mData[level];
  mSize = v13->sizes.mSize;
  if ( !stru_2A95018.value )
    v12 = this->lowestLevelInitBinCount >> level;
  if ( mSize > v12 )
  {
    cellCount = v13->cellCount;
    if ( cellCount < 0 )
    {
      v19 = (v13->cellCount >> 1) | v13->cellCount & 1;
      v16 = (float)(int)v19 + (float)(int)v19;
      if ( mSize < 0 )
        goto LABEL_12;
    }
    else
    {
      v16 = (float)(int)cellCount;
      if ( mSize < 0 )
      {
LABEL_12:
        v17 = (v13->sizes.mSize >> 1) | v13->sizes.mSize & 1;
        v18 = (float)(int)v17 + (float)(int)v17;
        goto LABEL_15;
      }
    }
    v18 = (float)(int)mSize;
LABEL_15:
    if ( this->lowestDensityThreshold > (float)(v16 / v18) )
    {
      v20 = RBX::Collision::LevelGrid::rehash(v13, mSize / this->levelExpansionFactor, this->pools);
      v3 = this->levels.mData[level];
      if ( v3 )
      {
        RBX::Collision::LevelGrid::~LevelGrid(this->levels.mData[level]);
        operator delete(v3);
      }
      this->levels.mData[level] = v20;
    }
  }
  if ( level + 1 < this->levels.mSize )
  {
    v21 = this->levels.mData[level + 1];
    v22 = ((73856093 * (*(int *)&v26.index.valid >> 1))
         ^ (19349663 * (v10 >> 1))
         ^ (83492791 * (v11 >> 1)))
        & (unsigned int)(LODWORD(v21->sizes.mSize) - 1);
    if ( v21->sizes.mData[v22] )
    {
      v23 = &v21->bins.mData[v22].coords->v[2];
      v3 = 0;
      while ( *(v23 - 2) != *(int *)&v26.index.valid >> 1 || *(v23 - 1) != v10 >> 1 || *v23 != v11 >> 1 )
      {
        v3 = (RBX::Collision::LevelGrid *)((char *)v3 + 1);
        v23 += 3;
        if ( (unsigned __int64)v3 >= v21->sizes.mData[v22] )
          goto LABEL_26;
      }
      v24 = 1;
    }
    else
    {
LABEL_26:
      v24 = 0;
    }
    v26.index.nodeIndex = v24;
    *((_DWORD *)&v26.index + 3) = v22;
    LOBYTE(v26.container) = (_BYTE)v3;
    v27 = v21;
    Children = RBX::Collision::LevelGrid::getChildren(
                 v21,
                 (const RBX::Collision::LevelGrid::CellIndex *)&v26.index.nodeIndex);
    Children->childMask &= __ROL1__(-2, v26.index.valid + 2 * (v10 & 1) + 4 * (v11 & 1));
    n = *(RBX::Collision::LevelGrid::CellIndex *)&v26.index.nodeIndex;
    v29 = v27;
    RBX::Collision::GridHierarchy::cleanupCellAndItsAncestors(this, level + 1, v26);
  }
}


// Address: 0x1df80e0 | Name: _ZN3RBX9Collision13GridHierarchy14computeExtentsEv
RBX::Extents *__fastcall RBX::Collision::GridHierarchy::computeExtents(
        RBX::Extents *__return_ptr retstr,
        RBX::Collision::GridHierarchy *this)
{
  RBX::Time v4; // xmm0_8
  size_t mSize; // rax
  RBX::Collision::LevelGrid *v6; // rsi
  size_t v7; // r10
  float v8; // xmm8_4
  unsigned __int64 v9; // rcx
  double v10; // xmm0_8
  double count; // xmm1_8
  double minValue; // xmm2_8
  double v13; // xmm3_8
  double v14; // xmm1_8
  double *p_maxValue; // rax
  double *p_minValue; // rdx
  unsigned __int8 *mData; // r9
  __m128 v19; // xmm3
  __m128 v20; // xmm10
  __m128 v21; // xmm9
  __m128 v22; // xmm5
  float v23; // xmm4_4
  float v24; // xmm6_4
  RBX::Collision::CellCoord *coords; // rdi
  unsigned __int8 i; // bl
  float v27; // xmm7_4
  float v28; // xmm2_4
  float v29; // xmm1_4
  _QWORD v31[4]; // [rsp+8h] [rbp-20h] BYREF

  v4.sec = RBX::Time::now<(RBX::Time::SampleMethod)2>().sec;
  *(_QWORD *)&retstr->low.x = 0x7F7FFFFF7F7FFFFFLL;
  retstr->low.z = 3.4028235e38;
  *(_QWORD *)&retstr->high.x = 0xFF7FFFFFFF7FFFFFLL;
  retstr->high.z = -3.4028235e38;
  mSize = this->levels.mSize;
  v6 = this->levels.mData[mSize - 1];
  v7 = v6->sizes.mSize;
  if ( !v7 )
  {
LABEL_5:
    if ( !stru_2AAF648.value )
      return retstr;
    goto LABEL_6;
  }
  v8 = (float)(1 << dword_2868B08 << (mSize - 1));
  v9 = 0;
  while ( !v6->sizes.mData[v9] )
  {
    if ( ++v9 >= v7 )
      goto LABEL_5;
  }
  mData = v6->sizes.mData;
  v19 = (__m128)0x7F7FFFFFu;
  v20 = (__m128)0xFF7FFFFF;
  v21 = (__m128)0xFF7FFFFF;
  v22 = (__m128)0x7F7FFFFFu;
  v23 = -3.4028235e38;
  v24 = 3.4028235e38;
LABEL_13:
  coords = v6->bins.mData[(unsigned int)v9].coords;
  for ( i = 0; ; ++i )
  {
    v27 = (float)coords[i].v[0] * v8;
    v28 = (float)coords[i].v[1] * v8;
    v29 = (float)coords[i].v[2] * v8;
    v24 = fminf(v24, v29);
    v23 = fmaxf(v23, v29 + v8);
    v22.m128_f32[0] = fminf(v22.m128_f32[0], v27);
    v19.m128_f32[0] = fminf(v19.m128_f32[0], v28);
    v21.m128_f32[0] = fmaxf(v21.m128_f32[0], v27 + v8);
    v20.m128_f32[0] = fmaxf(v20.m128_f32[0], v28 + v8);
    if ( (unsigned int)i + 1 >= mData[(unsigned int)v9] )
      break;
  }
  v9 = (unsigned int)v9 + 1LL;
  while ( v9 < v7 )
  {
    if ( mData[v9++] != 0 )
    {
      LODWORD(v9) = v9 - 1;
      goto LABEL_13;
    }
  }
  _mm_storel_ps((double *)&retstr->low.x, _mm_unpacklo_ps(v22, v19));
  _mm_storel_ps((double *)&retstr->high.x, _mm_unpacklo_ps(v21, v20));
  retstr->low.z = v24;
  retstr->high.z = v23;
  if ( stru_2AAF648.value )
  {
LABEL_6:
    v10 = (RBX::Time::now<(RBX::Time::SampleMethod)2>().sec - v4.sec) * 1000.0;
    *(double *)v31 = v10;
    count = this->computeExtentsDtAverager.count;
    minValue = this->computeExtentsDtAverager.minValue;
    v13 = this->computeExtentsDtAverager.average * count;
    v14 = count + 1.0;
    this->computeExtentsDtAverager.count = v14;
    this->computeExtentsDtAverager.average = (v13 + v10) / v14;
    p_maxValue = &this->computeExtentsDtAverager.maxValue;
    if ( v10 > this->computeExtentsDtAverager.maxValue )
      p_maxValue = (double *)v31;
    p_minValue = &this->computeExtentsDtAverager.minValue;
    if ( minValue > v10 )
      p_minValue = (double *)v31;
    this->computeExtentsDtAverager.maxValue = *p_maxValue;
    this->computeExtentsDtAverager.minValue = *p_minValue;
    RBX::Collision::StatReporter::update(&this->computeExtentsDtReporter);
  }
  return retstr;
}


// Address: 0x1df8330 | Name: _ZN3RBX9Collision12StatReporter6updateEv
void __fastcall RBX::Collision::StatReporter::update(RBX::Collision::StatReporter *this)
{
  uint32_t v1; // eax
  RBX::Time v2; // xmm0_8
  double v3; // xmm1_8
  size_t mSize; // rax
  __int64 v5; // r12
  char *v6; // rbx
  char *v7; // rdi
  __int64 v8; // rax
  double v9; // xmm0_8
  _QWORD *exception; // rax
  _BYTE v11[16]; // [rsp+0h] [rbp-78h] BYREF
  void *ptr; // [rsp+10h] [rbp-68h]
  _BYTE v13[32]; // [rsp+20h] [rbp-58h] BYREF
  _BYTE *v14; // [rsp+40h] [rbp-38h]
  unsigned __int64 v15; // [rsp+50h] [rbp-28h]

  v15 = __readfsqword(0x28u);
  if ( this->enabled )
  {
    v1 = this->counter + 1;
    this->counter = v1;
    if ( v1 >= this->attemptRate )
    {
      this->counter = 0;
      v2.sec = RBX::Time::now<(RBX::Time::SampleMethod)2>().sec;
      v3 = v2.sec - this->lastReportTime.sec;
      if ( v3 > this->delayInSeconds )
      {
        this->lastReportTime.sec = v2.sec;
        mSize = this->stats.mSize;
        if ( mSize )
        {
          v5 = 80 * mSize;
          v6 = (char *)this->stats.mData + 32;
          do
          {
            std::string::basic_string(v11, v6 - 32);
            v7 = (char *)*((_QWORD *)v6 + 4);
            if ( !v7 )
            {
              v14 = 0;
LABEL_21:
              exception = __cxa_allocate_exception(8u);
              *exception = off_28852C8;
              __cxa_throw(
                exception,
                (struct type_info *)&`typeinfo for'std::bad_function_call,
                (void (*)(void *))&std::exception::~exception);
            }
            if ( v6 == v7 )
            {
              v14 = v13;
              (*(void (__fastcall **)(_QWORD, _BYTE *))(**((_QWORD **)v6 + 4) + 24LL))(*((_QWORD *)v6 + 4), v13);
              v8 = (__int64)v14;
              if ( !v14 )
                goto LABEL_21;
            }
            else
            {
              v8 = (*(__int64 (__fastcall **)(char *))(*(_QWORD *)v7 + 16LL))(v7);
              v14 = (_BYTE *)v8;
              if ( !v8 )
                goto LABEL_21;
            }
            v9 = (*(double (__fastcall **)(__int64))(*(_QWORD *)v8 + 48LL))(v8);
            RBX::Analytics::EphemeralCounter::reportStats((const std::string *)v11, v9, v3, 0);
            if ( v13 == v14 )
            {
              (*(void (__fastcall **)(_BYTE *))(*(_QWORD *)v14 + 32LL))(v14);
              if ( (v11[0] & 1) == 0 )
                goto LABEL_18;
            }
            else
            {
              if ( v14 )
                (*(void (**)(void))(*(_QWORD *)v14 + 40LL))();
              if ( (v11[0] & 1) == 0 )
                goto LABEL_18;
            }
            operator delete(ptr);
LABEL_18:
            v6 += 80;
            v5 -= 80;
          }
          while ( v5 );
        }
      }
    }
  }
}


// Address: 0x1df8540 | Name: _ZN3RBX9Collision13GridHierarchy11reportStatsEv
void __fastcall RBX::Collision::GridHierarchy::reportStats(RBX::Collision::GridHierarchy *this)
{
  RBX::Collision::StatReporter::update(&this->levelStatReporter);
}


// Address: 0x1df8550 | Name: _ZN3RBX9Collision13GridHierarchy10printStatsEv
void __fastcall RBX::Collision::GridHierarchy::printStats(RBX::Collision::GridHierarchy *this)
{
  __int128 v1; // xmm1
  double v2; // xmm2_8
  double v3; // xmm3_8
  RBX::Collision::GridHierarchy *v4; // rbx
  __int64 v5; // rcx
  __int64 v6; // rax
  __int64 v7; // r8
  __int64 v8; // rdi
  __int64 v9; // rax
  __int64 v10; // r8
  __int64 v11; // rdi
  size_t v12; // rbp
  __int128 v13; // xmm1
  __int128 v14; // xmm1
  __int128 v15; // xmm1
  __m128i v16; // xmm1
  __int64 v17; // rbp
  __int64 v18; // rdi
  __int64 v19; // r8
  __int64 v20; // rcx
  __m128i v21; // xmm1
  size_t v22; // rbp
  __int128 v23; // xmm1
  __int128 v24; // xmm1
  __int128 v25; // xmm1
  __m128i v26; // xmm1
  __int64 v27; // rbp
  __int64 v28; // rdi
  __int64 v29; // r8
  __int64 v30; // rcx
  __m128i v31; // xmm1
  RBX::Collision::LevelGrid **mData; // rax
  RBX::Collision::LevelGrid *v33; // rbp
  char *Aligned; // rax
  char *v35; // rdi
  unsigned __int64 v36; // r13
  bool v37; // zf
  unsigned __int8 *v38; // rax
  char *v39; // r14
  char *v40; // rdx
  unsigned __int64 v41; // r8
  unsigned __int8 *v42; // rsi
  unsigned __int64 v43; // rax
  unsigned __int64 v44; // r9
  unsigned __int64 v45; // r10
  unsigned __int64 v46; // r11
  unsigned __int64 v47; // rbx
  __int64 v48; // r15
  unsigned __int64 v49; // rsi
  __int64 v50; // r12
  __int64 v51; // rbp
  __int64 v52; // rax
  char v53; // r14
  unsigned __int64 v54; // rax
  __int64 v55; // rcx
  __int128 v56; // xmm1
  __int128 v57; // xmm1
  __int128 v58; // xmm1
  __int64 v59; // r14
  __int64 v60; // rbp
  __int64 v61; // rcx
  __int64 v62; // rsi
  char *v63; // rsi
  char *v64; // r14
  __int64 cellCount; // r15
  unsigned __int64 mSize; // rbx
  unsigned __int64 primitiveCount; // r12
  size_t cellPrimitiveCount; // rdx
  float v69; // xmm0_4
  __int64 v70; // rcx
  _QWORD *v71; // rcx
  unsigned __int64 v72; // rax
  float v73; // xmm0_4
  const char *v74; // rsi
  const char *v75; // rsi
  int v76; // edx
  int v77; // ecx
  double v78; // xmm4_8
  double v79; // xmm5_8
  char *v80; // rax
  __int64 *v81; // rsi
  const char *v82; // r14
  float v83; // xmm1_4
  float v84; // xmm2_4
  float v85; // xmm3_4
  size_t v86; // rax
  signed __int64 v87; // rcx
  float v88; // xmm0_4
  size_t v89; // rcx
  float v90; // xmm0_4
  __int64 v91; // rax
  float v92; // xmm0_4
  __int64 v93; // rcx
  float v94; // xmm0_4
  __int64 v95; // rax
  float v96; // xmm0_4
  __int64 v97; // rax
  __int64 v98; // rax
  float v99; // xmm0_4
  size_t MedianBinSize; // rdx
  double v101; // xmm0_8
  size_t v102; // rcx
  unsigned __int8 *v103; // rax
  size_t v104; // rsi
  unsigned __int64 v105; // rcx
  size_t v106; // rdi
  __int64 i; // rdi
  const char *v108; // rsi
  const char *v109; // rsi
  char *v110; // rsi
  float v111; // xmm1_4
  float v112; // xmm0_4
  double v113; // xmm2_8
  double v114; // xmm0_8
  unsigned __int64 *v115; // rax
  unsigned __int64 *v116; // rbx
  unsigned __int64 *v117; // rsi
  size_t v118; // rdx
  RBX::Collision::LevelGrid *v119; // r14
  unsigned __int64 v120; // rcx
  __int64 v121; // rdi
  size_t v122; // rcx
  __int64 v123; // rsi
  size_t v124; // r8
  size_t v125; // rcx
  __int64 v126; // rsi
  __m128i v127; // xmm0
  __int64 v128; // rdi
  __m128i v129; // xmm1
  size_t v130; // rbp
  unsigned __int64 *v131; // rdx
  __int64 v132; // rsi
  unsigned __int64 v133; // rdi
  __m128i v134; // xmm0
  float v135; // xmm0_4
  float v136; // xmm0_4
  __int64 v137; // rsi
  size_t v138; // r8
  size_t v139; // rsi
  __int64 v140; // rdi
  __int64 v141; // rbp
  __m128i v142; // xmm0
  __int64 v143; // rbx
  __m128i v144; // xmm1
  size_t v145; // rdi
  __int64 v146; // rbp
  unsigned __int64 v147; // rdi
  __m128i v148; // xmm0
  float v149; // xmm0_4
  float v150; // xmm0_4
  __int64 v151; // rsi
  __int64 v152; // rdi
  __int64 v153; // rbp
  __int64 v154; // rbx
  unsigned __int64 v155; // r14
  __int64 v156; // r10
  __int64 v157; // r11
  float v158; // xmm3_4
  float v159; // xmm0_4
  __int64 v160; // rax
  __int64 v161; // rsi
  __int64 v162; // rdi
  __int64 v163; // rdi
  signed __int64 v164; // rdx
  __int64 v165; // r12
  __int64 v166; // rbp
  unsigned __int64 v167; // rcx
  __int64 v168; // rdi
  __int64 v169; // rbp
  unsigned __int64 v170; // rax
  unsigned __int64 v171; // r15
  unsigned __int64 v172; // rdx
  unsigned __int64 v173; // rsi
  __int64 v174; // rax
  unsigned __int64 v175; // rdx
  unsigned __int64 v176; // rsi
  size_t v177; // rax
  __int64 v178; // r12
  unsigned __int64 v179; // rsi
  float v180; // xmm3_4
  float v181; // xmm0_4
  float v182; // xmm0_4
  float v183; // xmm1_4
  float v184; // xmm0_4
  unsigned __int64 v185; // [rsp+8h] [rbp-110h]
  unsigned __int64 v186; // [rsp+10h] [rbp-108h]
  float v187; // [rsp+10h] [rbp-108h]
  unsigned __int64 v188; // [rsp+18h] [rbp-100h]
  float v189; // [rsp+18h] [rbp-100h]
  unsigned __int64 v190; // [rsp+20h] [rbp-F8h]
  float v191; // [rsp+20h] [rbp-F8h]
  unsigned __int64 v192; // [rsp+28h] [rbp-F0h]
  float v193; // [rsp+28h] [rbp-F0h]
  unsigned __int64 v194; // [rsp+30h] [rbp-E8h]
  float v195; // [rsp+30h] [rbp-E8h]
  __int64 v196; // [rsp+38h] [rbp-E0h]
  unsigned __int64 v197; // [rsp+38h] [rbp-E0h]
  RBX::ArrayDynamic<unsigned long> stats; // [rsp+40h] [rbp-D8h] BYREF
  RBX::Collision::LevelGrid *v199; // [rsp+60h] [rbp-B8h]
  unsigned __int64 v200; // [rsp+68h] [rbp-B0h]
  char format[16]; // [rsp+70h] [rbp-A8h] BYREF
  char *v202; // [rsp+80h] [rbp-98h]
  void *v203; // [rsp+90h] [rbp-88h]
  char *v204; // [rsp+98h] [rbp-80h]
  __int64 v205; // [rsp+A0h] [rbp-78h]
  void *v206; // [rsp+A8h] [rbp-70h]
  unsigned __int64 v207; // [rsp+B0h] [rbp-68h]
  __int64 v208; // [rsp+B8h] [rbp-60h]
  __int64 v209; // [rsp+C0h] [rbp-58h]
  char *v210; // [rsp+C8h] [rbp-50h]
  void *src; // [rsp+D0h] [rbp-48h]
  void *ptr; // [rsp+D8h] [rbp-40h]
  RBX::Collision::GridHierarchy *v213; // [rsp+E0h] [rbp-38h]

  v4 = this;
  RBX::StandardOut::printf(MESSAGE_OUTPUT, "--- Spatial Hash Stats ---");
  if ( this->levels.mSize )
  {
    v5 = 0;
    v213 = this;
    while ( 1 )
    {
      mData = v4->levels.mData;
      v209 = v5;
      v33 = mData[v5];
      Aligned = (char *)RBX::Memory::allocateAligned(0x20u, 0x10u);
      v35 = Aligned;
      *((_OWORD *)Aligned + 1) = 0;
      *(_OWORD *)Aligned = 0;
      v36 = 4LL * (Aligned != 0);
      v37 = v33->sizes.mSize == 0;
      v199 = v33;
      if ( !v37 )
      {
        v38 = v33->sizes.mData;
        v39 = v35;
        v206 = v35;
        ptr = v35;
        src = v35;
        v210 = v35;
        v40 = v35;
        v41 = 4;
        v42 = 0;
        while ( 1 )
        {
          v43 = v42[(_QWORD)v38];
          v203 = v42;
          if ( v41 <= v43 )
          {
            v44 = v43 + 1 - v41;
            if ( v44 )
              break;
          }
          v35 = v39;
          v47 = v41;
LABEL_64:
          v33 = v199;
          v38 = v199->sizes.mData;
          v63 = (char *)v203;
          ++*(_QWORD *)&v40[8 * v199->sizes.mData[(unsigned __int64)v203]];
          v42 = (unsigned __int8 *)(v63 + 1);
          v39 = v35;
          v41 = v47;
          if ( (unsigned __int64)v42 >= v33->sizes.mSize )
            goto LABEL_67;
        }
        v45 = v41 - 1;
        v46 = v41 - 4;
        v47 = v41;
        v48 = 0;
        v192 = v41;
        v190 = v43 + 1 - v41;
        v188 = v41 - 1;
        while ( 2 )
        {
          v49 = v47++;
          if ( v36 == v49 )
          {
            v50 = -(__int64)(v49 & 3);
            v205 = 32LL * (((unsigned __int8)(v46 >> 2) + 1) & 3);
            v51 = (((unsigned __int8)(v46 >> 2) + 1) & 3) - 1LL - (v46 >> 2);
            v207 = v41 + v48 - 4;
            v208 = (v207 >> 2) + 1;
            v186 = v41 + v48;
            v196 = 8 * (v41 + v48);
            v52 = 2;
            if ( v49 )
              v52 = 2 * v49;
            do
            {
              v36 = v52;
              v52 *= 2;
            }
            while ( v36 < v47 );
            if ( v49 < v36 && (v200 = v45 + v48, 8 * v36) )
            {
              v185 = v49;
              v194 = v46;
              v204 = v40;
              v35 = (char *)RBX::Memory::allocateAligned(8 * v36, 0x10u);
              v40 = v204;
              v41 = v192;
              v44 = v190;
              v45 = v188;
              v46 = v194;
              if ( v35 )
              {
                if ( v49 > 0x10 )
                {
                  memcpy(v35, src, 8 * v49);
                  goto LABEL_59;
                }
                if ( v49 )
                {
                  v53 = v186;
                  if ( v186 <= 3 || v35 < &v204[8 * v186] && v210 < &v35[v196] )
                  {
                    v54 = 0;
                    goto LABEL_45;
                  }
                  if ( v207 >= 0xC )
                  {
                    v55 = 0;
                    do
                    {
                      v56 = *(_OWORD *)&v40[8 * v55 + 16];
                      *(_OWORD *)&v35[8 * v55] = *(_OWORD *)&v40[8 * v55];
                      *(_OWORD *)&v35[8 * v55 + 16] = v56;
                      v57 = *(_OWORD *)&v40[8 * v55 + 48];
                      *(_OWORD *)&v35[8 * v55 + 32] = *(_OWORD *)&v40[8 * v55 + 32];
                      *(_OWORD *)&v35[8 * v55 + 48] = v57;
                      v58 = *(_OWORD *)&v40[8 * v55 + 80];
                      *(_OWORD *)&v35[8 * v55 + 64] = *(_OWORD *)&v40[8 * v55 + 64];
                      *(_OWORD *)&v35[8 * v55 + 80] = v58;
                      v1 = *(_OWORD *)&v40[8 * v55 + 112];
                      *(__m128i *)&v35[8 * v55 + 96] = _mm_loadu_si128((const __m128i *)&v40[8 * v55 + 96]);
                      *(_OWORD *)&v35[8 * v55 + 112] = v1;
                      v55 += 16;
                      v51 += 4;
                    }
                    while ( v51 );
                  }
                  else
                  {
                    v55 = 0;
                  }
                  v54 = v186 & 0xFFFFFFFFFFFFFFFCLL;
                  v59 = v205;
                  if ( (v208 & 3) != 0 )
                  {
                    v60 = (__int64)&v40[8 * v55 + 16];
                    v61 = (__int64)&v35[8 * v55 + 16];
                    v62 = 0;
                    do
                    {
                      v1 = *(_OWORD *)(v60 + v62);
                      *(__m128i *)(v61 + v62 - 16) = _mm_loadu_si128((const __m128i *)(v60 + v62 - 16));
                      *(_OWORD *)(v61 + v62) = v1;
                      v62 += 32;
                    }
                    while ( v59 != v62 );
                  }
                  v53 = v186;
                  v49 = v185;
                  if ( v186 != v54 )
                  {
LABEL_45:
                    v200 -= v54;
                    if ( (v53 & 3) != 0 )
                    {
                      do
                      {
                        *(_QWORD *)&v35[8 * v54] = *(_QWORD *)&v40[8 * v54];
                        ++v54;
                        ++v50;
                      }
                      while ( v50 );
                    }
                    if ( v200 >= 3 )
                    {
                      do
                      {
                        *(_QWORD *)&v35[8 * v54] = *(_QWORD *)&v40[8 * v54];
                        *(_QWORD *)&v35[8 * v54 + 8] = *(_QWORD *)&v40[8 * v54 + 8];
                        *(_QWORD *)&v35[8 * v54 + 16] = *(_QWORD *)&v40[8 * v54 + 16];
                        *(_QWORD *)&v35[8 * v54 + 24] = *(_QWORD *)&v40[8 * v54 + 24];
                        v54 += 4LL;
                      }
                      while ( v49 != v54 );
                    }
                  }
                  if ( v49 )
                  {
LABEL_59:
                    RBX::Memory::deallocateAligned(ptr);
                    v49 = v185;
                    v46 = v194;
                    v45 = v188;
                    v44 = v190;
                    v41 = v192;
                  }
                }
                v206 = v35;
                ptr = v35;
                src = v35;
                v210 = v35;
                v40 = v35;
              }
              else
              {
                v35 = v39;
                v36 = v49;
              }
            }
            else
            {
              v35 = v39;
              v36 = v49;
            }
          }
          else
          {
            v35 = v39;
          }
          *(_QWORD *)&v40[8 * v49] = 0;
          ++v48;
          ++v46;
          v39 = v35;
          if ( v48 == v44 )
            goto LABEL_64;
          continue;
        }
      }
      v206 = Aligned;
      v40 = Aligned;
LABEL_67:
      v64 = v40;
      v203 = v35;
      RBX::StandardOut::printf(MESSAGE_OUTPUT, "Level: %d [%d^3]", v209, (int)(float)(1 << dword_2868B08 << v209));
      cellCount = v33->cellCount;
      mSize = v33->sizes.mSize;
      primitiveCount = v33->primitiveCount;
      cellPrimitiveCount = v33->cellPrimitiveCount;
      if ( cellCount < 0 )
      {
        v70 = (v33->cellCount >> 1) | v33->cellCount & 1;
        v69 = (float)(int)v70 + (float)(int)v70;
      }
      else
      {
        v69 = (float)(int)cellCount;
      }
      v71 = v64;
      v187 = v69;
      v72 = mSize - *(_QWORD *)v64;
      v197 = v33->cellPrimitiveCount;
      if ( (v72 & 0x8000000000000000LL) != 0LL )
      {
        v71 = (_QWORD *)(v72 >> 1);
        v73 = (float)(int)((v72 >> 1) | v72 & 1) + (float)(int)((v72 >> 1) | v72 & 1);
      }
      else
      {
        v73 = (float)(int)v72;
      }
      *(float *)&v205 = v73;
      *(_OWORD *)format = 0;
      v202 = 0;
      format[0] = 8;
      strcpy(&format[1], "    ");
      std::string::append(format, "Bin Count: ", cellPrimitiveCount, v71);
      v74 = "%.1f K";
      if ( mSize < 0x400 )
        v74 = "%.0f";
      std::string::append(format, v74);
      std::string::append(format, ", Cell Count: ");
      v75 = "%.1f K";
      if ( (unsigned __int64)cellCount < 0x400 )
        v75 = "%.0f";
      std::string::append(format, v75);
      std::string::append(
        format,
        ", Density: %.2f, 0-Bins: %.0f%%, 1-Bins: %.0f%%, 2-Bins: %.0f%%, 3-Bins: %.0f%%, Median: %d, Max: %d, Collisions: %.1f",
        0.0,
        *(double *)&v1,
        v2,
        v3,
        v78,
        v76,
        v77,
        v79);
      v80 = &format[1];
      if ( (format[0] & 1) != 0 )
        v80 = v202;
      v81 = (__int64 *)v64;
      v82 = v80;
      if ( (mSize & 0x8000000000000000LL) != 0LL )
        v83 = (float)(int)((mSize >> 1) | mSize & 1) + (float)(int)((mSize >> 1) | mSize & 1);
      else
        v83 = (float)(int)mSize;
      v84 = v83;
      if ( mSize >= 0x400 )
        v84 = v83 * 0.0009765625;
      v85 = v187;
      if ( (unsigned __int64)cellCount >= 0x400 )
        v85 = v187 * 0.0009765625;
      v86 = v199->sizes.mSize;
      v87 = v199->cellCount;
      if ( v87 < 0 )
      {
        v89 = (v199->cellCount >> 1) | v199->cellCount & 1;
        v88 = (float)(int)v89 + (float)(int)v89;
      }
      else
      {
        v88 = (float)(int)v87;
      }
      v195 = v88;
      if ( (v86 & 0x8000000000000000LL) != 0LL )
        v90 = (float)(int)((v86 >> 1) | v86 & 1) + (float)(int)((v86 >> 1) | v86 & 1);
      else
        v90 = (float)(int)v86;
      *(float *)&v204 = v90;
      v91 = v81[1];
      if ( *v81 < 0 )
      {
        v93 = ((unsigned __int64)*v81 >> 1) | *v81 & 1;
        v92 = (float)(int)v93 + (float)(int)v93;
      }
      else
      {
        v92 = (float)(int)*v81;
      }
      *(float *)&v200 = v92;
      if ( v91 < 0 )
        v94 = (float)(int)(((unsigned __int64)v91 >> 1) | v91 & 1)
            + (float)(int)(((unsigned __int64)v91 >> 1) | v91 & 1);
      else
        v94 = (float)(int)v91;
      v193 = v94;
      v95 = v81[2];
      if ( v95 < 0 )
      {
        v97 = ((unsigned __int64)v81[2] >> 1) | v81[2] & 1;
        v96 = (float)(int)v97 + (float)(int)v97;
      }
      else
      {
        v96 = (float)(int)v95;
      }
      v191 = v96;
      v98 = v81[3];
      *(float *)&v208 = v83;
      *(float *)&v207 = v84;
      if ( v98 < 0 )
        v99 = (float)(int)(((unsigned __int64)v98 >> 1) | v98 & 1)
            + (float)(int)(((unsigned __int64)v98 >> 1) | v98 & 1);
      else
        v99 = (float)(int)v98;
      v189 = v99;
      MedianBinSize = RBX::Collision::LevelGrid::getMedianBinSize(v199);
      v101 = *(float *)&v207;
      v102 = v199->sizes.mSize;
      if ( !v102 )
      {
        v105 = 0;
        goto LABEL_132;
      }
      v103 = v199->sizes.mData;
      v104 = v199->sizes.mSize & 7;
      if ( v102 - 1 < 7 )
        break;
      v106 = v104 - v102;
      v105 = 0;
      do
      {
        if ( v105 <= *v103 )
          v105 = *v103;
        if ( v105 <= v103[1] )
          v105 = v103[1];
        if ( v105 <= v103[2] )
          v105 = v103[2];
        if ( v105 <= v103[3] )
          v105 = v103[3];
        if ( v105 <= v103[4] )
          v105 = v103[4];
        if ( v105 <= v103[5] )
          v105 = v103[5];
        if ( v105 <= v103[6] )
          v105 = v103[6];
        if ( v105 <= v103[7] )
          v105 = v103[7];
        v103 += 8;
        v106 += 8LL;
      }
      while ( v106 );
      if ( v104 )
        goto LABEL_128;
LABEL_132:
      RBX::StandardOut::printf(
        MESSAGE_OUTPUT,
        v82,
        MedianBinSize,
        v105,
        v101,
        v85,
        (float)(v195 / *(float *)&v204),
        (float)((float)(*(float *)&v200 * 100.0) / *(float *)&v208),
        (float)((float)(v193 * 100.0) / *(float *)&v208),
        (float)((float)(v191 * 100.0) / *(float *)&v208),
        (float)((float)(v189 * 100.0) / *(float *)&v208),
        (float)((float)(v187 / *(float *)&v205) + -1.0));
      std::string::assign(format, "    ");
      std::string::append(format, "Prim Count: ");
      v108 = "%.1f K";
      if ( primitiveCount < 0x400 )
        v108 = "%.0f";
      std::string::append(format, v108);
      std::string::append(format, ", Cell Prim Count: ");
      v109 = "%.1f K";
      if ( v197 < 0x400 )
        v109 = "%.0f";
      std::string::append(format, v109);
      std::string::append(format, ", Occupancy: %.1f", v101);
      v110 = &format[1];
      if ( (format[0] & 1) != 0 )
        v110 = v202;
      if ( (v197 & 0x8000000000000000LL) != 0LL )
        v111 = (float)(int)((v197 >> 1) | v197 & 1) + (float)(int)((v197 >> 1) | v197 & 1);
      else
        v111 = (float)(int)v197;
      if ( (primitiveCount & 0x8000000000000000LL) != 0LL )
      {
        v112 = (float)(int)((primitiveCount >> 1) | primitiveCount & 1)
             + (float)(int)((primitiveCount >> 1) | primitiveCount & 1);
LABEL_145:
        v113 = (float)(v111 / v112);
        goto LABEL_146;
      }
      v112 = (float)(int)primitiveCount;
      v113 = 0.0;
      if ( primitiveCount )
        goto LABEL_145;
LABEL_146:
      if ( primitiveCount >= 0x400 )
        v112 = v112 * 0.0009765625;
      v114 = v112;
      if ( v197 >= 0x400 )
        v111 = v111 * 0.0009765625;
      RBX::StandardOut::printf(MESSAGE_OUTPUT, v110, v114, v111, v113);
      memset(&stats, 0, 25);
      stats.mAlignment = 16;
      v115 = (unsigned __int64 *)RBX::Memory::allocateAligned(0x18u, 0x10u);
      v116 = v115;
      if ( !v115 )
      {
        v116 = stats.mData;
        v119 = v199;
        goto LABEL_170;
      }
      v117 = stats.mData;
      v118 = stats.mSize;
      v119 = v199;
      if ( !stats.mNoInit )
      {
        if ( stats.mSize > 0x10 )
        {
LABEL_166:
          memcpy(v115, stats.mData, 8 * stats.mSize);
          goto LABEL_167;
        }
        if ( !stats.mSize )
          goto LABEL_167;
        if ( stats.mSize <= 3 || v115 < &stats.mData[stats.mSize] && &v115[stats.mSize] > stats.mData )
        {
          v9 = 0;
LABEL_250:
          v167 = v118 + ~v9;
          if ( (v118 & 3) != 0 )
          {
            v168 = -(__int64)(v118 & 3);
            do
            {
              v116[v9] = v117[v9];
              ++v9;
              ++v168;
            }
            while ( v168 );
          }
          if ( v167 >= 3 )
          {
            do
            {
              v116[v9] = v117[v9];
              v116[v9 + 1] = v117[v9 + 1];
              v116[v9 + 2] = v117[v9 + 2];
              v116[v9 + 3] = v117[v9 + 3];
              v9 += 4;
            }
            while ( v118 != v9 );
          }
          goto LABEL_167;
        }
        v9 = stats.mSize & 0x1C;
        v10 = ((unsigned __int8)(((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3;
        if ( (stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4 >= 0xC )
        {
          v22 = v10 - ((((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1);
          v11 = 0;
          do
          {
            v23 = *(_OWORD *)&v117[v11 + 2];
            *(_OWORD *)&v116[v11] = *(_OWORD *)&v117[v11];
            *(_OWORD *)&v116[v11 + 2] = v23;
            v24 = *(_OWORD *)&v117[v11 + 6];
            *(_OWORD *)&v116[v11 + 4] = *(_OWORD *)&v117[v11 + 4];
            *(_OWORD *)&v116[v11 + 6] = v24;
            v25 = *(_OWORD *)&v117[v11 + 10];
            *(_OWORD *)&v116[v11 + 8] = *(_OWORD *)&v117[v11 + 8];
            *(_OWORD *)&v116[v11 + 10] = v25;
            v26 = _mm_loadu_si128((const __m128i *)&v117[v11 + 14]);
            *(__m128i *)&v116[v11 + 12] = _mm_loadu_si128((const __m128i *)&v117[v11 + 12]);
            *(__m128i *)&v116[v11 + 14] = v26;
            v11 += 16;
            v22 += 4LL;
          }
          while ( v22 );
          if ( (((unsigned __int8)(((v118 & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3) != 0 )
            goto LABEL_19;
        }
        else
        {
          v11 = 0;
          if ( (((unsigned __int8)(((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3) == 0 )
            goto LABEL_21;
LABEL_19:
          v27 = (__int64)&v117[v11 + 2];
          v28 = (__int64)&v116[v11 + 2];
          v29 = 32 * v10;
          v30 = 0;
          do
          {
            v31 = _mm_loadu_si128((const __m128i *)(v27 + v30));
            *(__m128i *)(v28 + v30 - 16) = _mm_loadu_si128((const __m128i *)(v27 + v30 - 16));
            *(__m128i *)(v28 + v30) = v31;
            v30 += 32;
          }
          while ( v29 != v30 );
        }
LABEL_21:
        if ( v118 != v9 )
          goto LABEL_250;
        goto LABEL_167;
      }
      if ( stats.mSize > 0x10 )
        goto LABEL_166;
      if ( stats.mSize )
      {
        if ( stats.mSize <= 3 || v115 < &stats.mData[stats.mSize] && &v115[stats.mSize] > stats.mData )
        {
          v6 = 0;
LABEL_158:
          v120 = v118 + ~v6;
          if ( (v118 & 3) != 0 )
          {
            v121 = -(__int64)(v118 & 3);
            do
            {
              v116[v6] = v117[v6];
              ++v6;
              ++v121;
            }
            while ( v121 );
          }
          if ( v120 >= 3 )
          {
            do
            {
              v116[v6] = v117[v6];
              v116[v6 + 1] = v117[v6 + 1];
              v116[v6 + 2] = v117[v6 + 2];
              v116[v6 + 3] = v117[v6 + 3];
              v6 += 4;
            }
            while ( v118 != v6 );
          }
          goto LABEL_167;
        }
        v6 = stats.mSize & 0x1C;
        v7 = ((unsigned __int8)(((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3;
        if ( (stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4 >= 0xC )
        {
          v12 = v7 - ((((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1);
          v8 = 0;
          do
          {
            v13 = *(_OWORD *)&v117[v8 + 2];
            *(_OWORD *)&v116[v8] = *(_OWORD *)&v117[v8];
            *(_OWORD *)&v116[v8 + 2] = v13;
            v14 = *(_OWORD *)&v117[v8 + 6];
            *(_OWORD *)&v116[v8 + 4] = *(_OWORD *)&v117[v8 + 4];
            *(_OWORD *)&v116[v8 + 6] = v14;
            v15 = *(_OWORD *)&v117[v8 + 10];
            *(_OWORD *)&v116[v8 + 8] = *(_OWORD *)&v117[v8 + 8];
            *(_OWORD *)&v116[v8 + 10] = v15;
            v16 = _mm_loadu_si128((const __m128i *)&v117[v8 + 14]);
            *(__m128i *)&v116[v8 + 12] = _mm_loadu_si128((const __m128i *)&v117[v8 + 12]);
            *(__m128i *)&v116[v8 + 14] = v16;
            v8 += 16;
            v12 += 4LL;
          }
          while ( v12 );
          if ( (((unsigned __int8)(((v118 & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3) != 0 )
            goto LABEL_12;
        }
        else
        {
          v8 = 0;
          if ( (((unsigned __int8)(((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3) == 0 )
            goto LABEL_14;
LABEL_12:
          v17 = (__int64)&v117[v8 + 2];
          v18 = (__int64)&v116[v8 + 2];
          v19 = 32 * v7;
          v20 = 0;
          do
          {
            v21 = _mm_loadu_si128((const __m128i *)(v17 + v20));
            *(__m128i *)(v18 + v20 - 16) = _mm_loadu_si128((const __m128i *)(v17 + v20 - 16));
            *(__m128i *)(v18 + v20) = v21;
            v20 += 32;
          }
          while ( v19 != v20 );
        }
LABEL_14:
        if ( v118 != v6 )
          goto LABEL_158;
      }
LABEL_167:
      if ( stats.mCapacity )
        RBX::Memory::deallocateAligned(stats.mData);
      stats.mData = v116;
      stats.mCapacity = 3;
LABEL_170:
      *(_OWORD *)v116 = 0;
      v116[2] = 0;
      stats.mSize = 3;
      RBX::Collision::LevelGrid::getPrimitiveCounts(v119, &stats);
      if ( stats.mSize )
      {
        if ( stats.mSize <= 3 )
        {
          v122 = 0;
          v123 = 0;
          do
LABEL_183:
            v123 += stats.mData[v122++];
          while ( stats.mSize != v122 );
LABEL_184:
          if ( v123 < 0 )
            v135 = (float)(int)(((unsigned __int64)v123 >> 1) | v123 & 1)
                 + (float)(int)(((unsigned __int64)v123 >> 1) | v123 & 1);
          else
            v135 = (float)(int)v123;
          v136 = v135 * 0.5;
          v125 = 0;
          v137 = 0;
          do
          {
            v137 += stats.mData[v125];
            if ( v137 < 0 )
            {
              if ( (float)((float)(int)(((unsigned __int64)v137 >> 1) | v137 & 1)
                         + (float)(int)(((unsigned __int64)v137 >> 1) | v137 & 1)) >= v136 )
                goto LABEL_194;
            }
            else if ( (float)(int)v137 >= v136 )
            {
              goto LABEL_194;
            }
            ++v125;
          }
          while ( v125 < stats.mSize );
          LODWORD(v125) = stats.mSize;
LABEL_194:
          v138 = 1;
          if ( stats.mSize > 1 )
            v138 = stats.mSize;
          if ( v138 <= 3 )
          {
            v139 = 0;
            v140 = 0;
            do
LABEL_207:
              v140 += stats.mData[v139++];
            while ( v139 < stats.mSize );
LABEL_208:
            if ( v140 < 0 )
              v149 = (float)(int)(((unsigned __int64)v140 >> 1) | v140 & 1)
                   + (float)(int)(((unsigned __int64)v140 >> 1) | v140 & 1);
            else
              v149 = (float)(int)v140;
            v150 = v149 * 0.89999998;
            v124 = 0;
            v151 = 0;
            do
            {
              v151 += stats.mData[v124];
              if ( v151 < 0 )
              {
                if ( (float)((float)(int)(((unsigned __int64)v151 >> 1) | v151 & 1)
                           + (float)(int)(((unsigned __int64)v151 >> 1) | v151 & 1)) >= v150 )
                  goto LABEL_218;
              }
              else if ( (float)(int)v151 >= v150 )
              {
                goto LABEL_218;
              }
              ++v124;
            }
            while ( v124 < stats.mSize );
            LODWORD(v124) = stats.mSize;
LABEL_218:
            v152 = stats.mSize & 3;
            if ( stats.mSize - 1 >= 3 )
            {
              v153 = 0;
              v154 = 0;
              do
              {
                if ( stats.mData[v153] )
                  v154 = v153;
                v160 = v153 + 1;
                if ( !stats.mData[v153 + 1] )
                  v160 = v154;
                v161 = v153 + 2;
                if ( !stats.mData[v153 + 2] )
                  v161 = v160;
                v154 = v153 + 3;
                if ( !stats.mData[v153 + 3] )
                  v154 = v161;
                v153 += 4;
              }
              while ( stats.mSize - v152 != v153 );
              if ( (stats.mSize & 3) != 0 )
                goto LABEL_234;
            }
            else
            {
              v153 = 0;
              LODWORD(v154) = 0;
              if ( (stats.mSize & 3) == 0 )
                goto LABEL_238;
LABEL_234:
              v162 = -v152;
              do
              {
                if ( stats.mData[v153] )
                  LODWORD(v154) = v153;
                ++v153;
                ++v162;
              }
              while ( v162 );
            }
LABEL_238:
            v155 = *stats.mData;
            v156 = stats.mData[1];
            v157 = stats.mData[2];
            if ( stats.mSize == 1 )
            {
              v163 = 0;
              v164 = *stats.mData;
              if ( !v155 )
                goto LABEL_240;
              goto LABEL_262;
            }
            v165 = (LOBYTE(stats.mSize) - 1) & 3;
            if ( stats.mSize - 2 >= 3 )
            {
              v169 = 2;
              v164 = *stats.mData;
              v163 = 0;
              do
              {
                v170 = stats.mData[v169 - 1];
                v171 = stats.mData[v169];
                v172 = v171 + v170 + v164;
                v173 = stats.mData[v169 + 1];
                v174 = v163 + v170 * (v169 - 1) + v169 * v171 + v173 * (v169 + 1);
                v175 = v173 + v172;
                v176 = stats.mData[v169 + 2];
                v163 = v174 + v176 * (v169 + 2);
                v164 = v176 + v175;
                v177 = v165 + 1 - stats.mSize + v169 + 4;
                v169 += 4;
              }
              while ( v177 != 2 );
              v166 = v169 - 1;
              v155 = *stats.mData;
              if ( ((LOBYTE(stats.mSize) - 1) & 3) != 0 )
                goto LABEL_259;
            }
            else
            {
              v166 = 1;
              v164 = *stats.mData;
              v163 = 0;
              if ( ((LOBYTE(stats.mSize) - 1) & 3) == 0 )
                goto LABEL_261;
LABEL_259:
              v178 = -v165;
              do
              {
                v179 = stats.mData[v166];
                v164 += v179;
                v163 += v166 * v179;
                ++v166;
                ++v178;
              }
              while ( v178 );
            }
LABEL_261:
            if ( !v164 )
            {
LABEL_240:
              v158 = 0.0;
              if ( v157 < 0 )
                goto LABEL_268;
              goto LABEL_222;
            }
LABEL_262:
            if ( v163 < 0 )
            {
              v180 = (float)(int)(((unsigned __int64)v163 >> 1) | v163 & 1)
                   + (float)(int)(((unsigned __int64)v163 >> 1) | v163 & 1);
              if ( v164 >= 0 )
                goto LABEL_266;
LABEL_264:
              v181 = (float)(int)(((unsigned __int64)v164 >> 1) | v164 & 1)
                   + (float)(int)(((unsigned __int64)v164 >> 1) | v164 & 1);
            }
            else
            {
              v180 = (float)(int)v163;
              if ( v164 < 0 )
                goto LABEL_264;
LABEL_266:
              v181 = (float)(int)v164;
            }
            v158 = v180 / v181;
            if ( v157 < 0 )
              goto LABEL_268;
            goto LABEL_222;
          }
          v139 = v138 & 0xFFFFFFFFFFFFFFFCLL;
          v141 = ((unsigned __int8)(((v138 & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3;
          if ( (v138 & 0xFFFFFFFFFFFFFFFCLL) - 4 >= 0xC )
          {
            v145 = v141 - ((((v138 & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1);
            v142 = 0;
            v143 = 0;
            v144 = 0;
            do
            {
              v142 = _mm_add_epi64(
                       _mm_loadu_si128((const __m128i *)&stats.mData[v143 + 12]),
                       _mm_add_epi64(
                         _mm_add_epi64(
                           _mm_loadu_si128((const __m128i *)&stats.mData[v143 + 8]),
                           _mm_loadu_si128((const __m128i *)&stats.mData[v143 + 4])),
                         _mm_add_epi64(_mm_loadu_si128((const __m128i *)&stats.mData[v143]), v142)));
              v144 = _mm_add_epi64(
                       _mm_loadu_si128((const __m128i *)&stats.mData[v143 + 14]),
                       _mm_add_epi64(
                         _mm_add_epi64(
                           _mm_loadu_si128((const __m128i *)&stats.mData[v143 + 10]),
                           _mm_loadu_si128((const __m128i *)&stats.mData[v143 + 6])),
                         _mm_add_epi64(_mm_loadu_si128((const __m128i *)&stats.mData[v143 + 2]), v144)));
              v143 += 16;
              v145 += 4LL;
            }
            while ( v145 );
            if ( (((unsigned __int8)(((v138 & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3) != 0 )
              goto LABEL_204;
          }
          else
          {
            v142 = 0;
            v143 = 0;
            v144 = 0;
            if ( (((unsigned __int8)(((v138 & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3) == 0 )
              goto LABEL_206;
LABEL_204:
            v146 = 32 * v141;
            v147 = 0;
            do
            {
              v142 = _mm_add_epi64(v142, _mm_loadu_si128((const __m128i *)&stats.mData[v143 + v147 / 8]));
              v144 = _mm_add_epi64(v144, _mm_loadu_si128((const __m128i *)&stats.mData[v143 + 2 + v147 / 8]));
              v147 += 32LL;
            }
            while ( v146 != v147 );
          }
LABEL_206:
          v148 = _mm_add_epi64(v142, v144);
          v140 = _mm_add_epi64(_mm_shuffle_epi32(v148, 78), v148).m128i_u64[0];
          if ( v138 != v139 )
            goto LABEL_207;
          goto LABEL_208;
        }
        v122 = stats.mSize & 0xFFFFFFFFFFFFFFFCLL;
        v126 = ((unsigned __int8)(((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3;
        if ( (stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4 >= 0xC )
        {
          v130 = v126 - ((((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1);
          v127 = 0;
          v128 = 0;
          v129 = 0;
          do
          {
            v127 = _mm_add_epi64(
                     _mm_loadu_si128((const __m128i *)&stats.mData[v128 + 12]),
                     _mm_add_epi64(
                       _mm_add_epi64(
                         _mm_loadu_si128((const __m128i *)&stats.mData[v128 + 8]),
                         _mm_loadu_si128((const __m128i *)&stats.mData[v128 + 4])),
                       _mm_add_epi64(_mm_loadu_si128((const __m128i *)&stats.mData[v128]), v127)));
            v129 = _mm_add_epi64(
                     _mm_loadu_si128((const __m128i *)&stats.mData[v128 + 14]),
                     _mm_add_epi64(
                       _mm_add_epi64(
                         _mm_loadu_si128((const __m128i *)&stats.mData[v128 + 10]),
                         _mm_loadu_si128((const __m128i *)&stats.mData[v128 + 6])),
                       _mm_add_epi64(_mm_loadu_si128((const __m128i *)&stats.mData[v128 + 2]), v129)));
            v128 += 16;
            v130 += 4LL;
          }
          while ( v130 );
          if ( (((unsigned __int8)(((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3) != 0 )
            goto LABEL_180;
        }
        else
        {
          v127 = 0;
          v128 = 0;
          v129 = 0;
          if ( (((unsigned __int8)(((stats.mSize & 0xFFFFFFFFFFFFFFFCLL) - 4) >> 2) + 1) & 3) == 0 )
            goto LABEL_182;
LABEL_180:
          v131 = &stats.mData[v128 + 2];
          v132 = 32 * v126;
          v133 = 0;
          do
          {
            v127 = _mm_add_epi64(v127, _mm_loadu_si128((const __m128i *)&v131[v133 / 8 - 2]));
            v129 = _mm_add_epi64(v129, _mm_loadu_si128((const __m128i *)&v131[v133 / 8]));
            v133 += 32LL;
          }
          while ( v132 != v133 );
        }
LABEL_182:
        v134 = _mm_add_epi64(v127, v129);
        v123 = _mm_add_epi64(_mm_shuffle_epi32(v134, 78), v134).m128i_u64[0];
        if ( stats.mSize != v122 )
          goto LABEL_183;
        goto LABEL_184;
      }
      LODWORD(v124) = 0;
      LODWORD(v125) = 0;
      v155 = *stats.mData;
      v156 = stats.mData[1];
      v157 = stats.mData[2];
      v158 = 0.0;
      LODWORD(v154) = 0;
      if ( v157 < 0 )
      {
LABEL_268:
        v159 = (float)(int)(((unsigned __int64)v157 >> 1) | v157 & 1)
             + (float)(int)(((unsigned __int64)v157 >> 1) | v157 & 1);
        goto LABEL_269;
      }
LABEL_222:
      v159 = (float)(int)v157;
LABEL_269:
      v182 = (float)(v159 * 100.0) / v187;
      if ( v156 < 0 )
        v183 = (float)(int)(((unsigned __int64)v156 >> 1) | v156 & 1)
             + (float)(int)(((unsigned __int64)v156 >> 1) | v156 & 1);
      else
        v183 = (float)(int)v156;
      v2 = v182;
      *(double *)&v1 = (float)((float)(v183 * 100.0) / v187);
      if ( (v155 & 0x8000000000000000LL) != 0LL )
        v184 = (float)(int)((v155 >> 1) | v155 & 1) + (float)(int)((v155 >> 1) | v155 & 1);
      else
        v184 = (float)(int)v155;
      v3 = v158;
      RBX::StandardOut::printf(
        MESSAGE_OUTPUT,
        "    Primitive distribution: 0-cells: %.0f%%, 1-cells: %.0f%%, 2-cells: %.0f%%, largest: %d-cell, median: %d-cell"
        ", 90%%: %d-cells, average: %.2f",
        (float)((float)(v184 * 100.0) / v187),
        *(double *)&v1,
        v2,
        v154,
        v125,
        v124,
        v3);
      stats.mSize = 0;
      if ( stats.mCapacity )
      {
        RBX::Memory::deallocateAligned(stats.mData);
        stats.mCapacity = 0;
        stats.mData = 0;
      }
      if ( (format[0] & 1) != 0 )
        operator delete(v202);
      if ( v36 )
        RBX::Memory::deallocateAligned(v206);
      v5 = v209 + 1;
      v4 = v213;
      if ( v209 + 1 >= v213->levels.mSize )
        return;
    }
    v105 = 0;
    if ( !v104 )
      goto LABEL_132;
LABEL_128:
    for ( i = 0; i != v104; ++i )
    {
      if ( v105 <= v103[i] )
        v105 = v103[i];
    }
    goto LABEL_132;
  }
}


// Address: 0x1df9c40 | Name: _ZN3RBX9Collision13GridHierarchy13render3dAdornEPNS_5AdornE
void __fastcall RBX::Collision::GridHierarchy::render3dAdorn(RBX::Collision::GridHierarchy *this, RBX::Adorn *adorn)
{
  float *p_b; // r13
  size_t v4; // rbx
  float v5; // xmm0_4
  float v6; // xmm0_4
  RBX::Collision::LevelGrid *v7; // rdi
  RBX::Color4 v8[2]; // [rsp+0h] [rbp-58h] BYREF
  int v9; // [rsp+20h] [rbp-38h]
  __int64 v10; // [rsp+24h] [rbp-34h] BYREF
  int v11; // [rsp+2Ch] [rbp-2Ch]

  if ( !(_BYTE)byte_2AAF700 && __cxa_guard_acquire(&byte_2AAF700) )
  {
    byte_2AAF6A0[0] = *G3D::Color3::green();
    *(G3D::Color3 *)byte_2AAF6AC = *G3D::Color3::red();
    *(G3D::Color3 *)byte_2AAF6B8 = *G3D::Color3::blue();
    *(G3D::Color3 *)byte_2AAF6C4 = *G3D::Color3::orange();
    *(G3D::Color3 *)byte_2AAF6D0 = *G3D::Color3::yellow();
    *(G3D::Color3 *)byte_2AAF6DC = *G3D::Color3::cyan();
    *(G3D::Color3 *)byte_2AAF6E8 = *G3D::Color3::purple();
    *(G3D::Color3 *)byte_2AAF6F4 = *G3D::Color3::white();
    __cxa_guard_release(&byte_2AAF700);
  }
  v8[0] = (RBX::Color4)0x3F800000u;
  v8[1] = (RBX::Color4)0x3F800000u;
  v9 = 1065353216;
  _mm_storel_ps((double *)&v10, (__m128)0LL);
  v11 = 0;
  (*(void (__fastcall **)(RBX::Adorn *, RBX::Color4 *))(*(_QWORD *)adorn + 176LL))(adorn, v8);
  *((_DWORD *)adorn + 7) = 7;
  if ( this->levels.mSize )
  {
    p_b = &byte_2AAF6A0[0].b;
    v4 = 0;
    do
    {
      if ( (v4 & 0x8000000000000000LL) != 0LL )
        v5 = (float)(int)((v4 >> 1) | v4 & 1) + (float)(int)((v4 >> 1) | v4 & 1);
      else
        v5 = (float)(int)v4;
      v6 = fminf(v5 * 0.25, 1.0);
      v7 = this->levels.mData[v4];
      *(_QWORD *)&v8[0].r = *((_QWORD *)p_b - 1);
      v8[0].b = *p_b;
      v8[0].a = (float)(v6 * 0.050000001) + (float)((float)(1.0 - v6) * 0.30000001);
      RBX::Collision::LevelGrid::render3dAdorn(v7, adorn, v8, (float)(1 << dword_2868B08 << v4++));
      p_b += 3;
    }
    while ( v4 < this->levels.mSize );
  }
}


// Address: 0x1df9e80 | Name: _ZN3RBX9Collision23SpatialHashHierarchicalC2EPNS_14ContactManagerEii
void __fastcall RBX::Collision::SpatialHashHierarchical::SpatialHashHierarchical(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::ContactManager *contactManager,
        int maxCellsPerPrimitive,
        int gridHierarchyLowestLevelInitBinCount)
{
  RBX::Collision::GridHierarchy *v5; // rbp

  *(_QWORD *)this = off_299E400;
  *((_DWORD *)this + 2) = 0;
  *(_OWORD *)((char *)this + 28) = 0;
  *((_OWORD *)this + 1) = 0;
  *((_DWORD *)this + 12) = maxCellsPerPrimitive;
  *((_QWORD *)this + 7) = contactManager;
  *((_OWORD *)this + 6) = 0;
  *((_OWORD *)this + 5) = 0;
  *((_QWORD *)this + 14) = 0;
  v5 = (RBX::Collision::GridHierarchy *)operator new(0xE8u);
  RBX::Collision::GridHierarchy::GridHierarchy(v5, dword_2868B18, gridHierarchyLowestLevelInitBinCount);
  *((_QWORD *)this + 8) = v5;
}


// Address: 0x1df9f40 | Name: _ZN3RBX9Collision23SpatialHashHierarchicalD2Ev
void __fastcall RBX::Collision::SpatialHashHierarchical::~SpatialHashHierarchical(
        RBX::Collision::SpatialHashHierarchical *this)
{
  void *v2; // r14
  void *v3; // rdi

  *(_QWORD *)this = off_299E400;
  v2 = (void *)*((_QWORD *)this + 8);
  if ( v2 )
  {
    RBX::Collision::GridHierarchy::~GridHierarchy(*((RBX::Collision::GridHierarchy **)this + 8));
    operator delete(v2);
  }
  v3 = (void *)*((_QWORD *)this + 12);
  if ( v3 )
  {
    *((_QWORD *)this + 13) = v3;
    operator delete(v3);
  }
  RBX::Memory::deallocate(*((void **)this + 10));
  *((_OWORD *)this + 5) = 0;
  if ( (*((_BYTE *)this + 16) & 1) != 0 )
    operator delete(*((void **)this + 4));
}


// Address: 0x1df9fc0 | Name: _ZN3RBX9Collision23SpatialHashHierarchicalD0Ev
void __fastcall RBX::Collision::SpatialHashHierarchical::~SpatialHashHierarchical(
        RBX::Collision::SpatialHashHierarchical *this)
{
  RBX::Collision::SpatialHashHierarchical::~SpatialHashHierarchical(this);
  operator delete(this);
}


// Address: 0x1df9fe0 | Name: _ZN3RBX9Collision23SpatialHashHierarchical16onPrimitiveAddedEPNS_9PrimitiveEb
void __fastcall RBX::Collision::SpatialHashHierarchical::onPrimitiveAdded(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Primitive *p,
        bool createContacts)
{
  int v4; // esi
  int v5; // ebx
  unsigned __int64 v6; // rdx
  __int64 v7; // rbx
  __int64 i; // r12
  RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo v9; // [rsp+8h] [rbp-60h] BYREF

  RBX::Collision::GridHierarchy::addPrimitive(
    *((RBX::Collision::GridHierarchy **)this + 8),
    *((RBX::ContactManager **)this + 7),
    p,
    createContacts);
  if ( *((_QWORD *)this + 12) != *((_QWORD *)this + 13) )
  {
    RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateInfo(&v9);
    v9.updateType = RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateType::UPDATE_TYPE_Insert;
    v9.newLevel_deprecated = -1;
    v4 = *((_DWORD *)p + 24) << (*((_BYTE *)p + 112) + dword_2868B08);
    v5 = *((_DWORD *)p + 27) << (*((_BYTE *)p + 112) + dword_2868B08);
    v6 = ((unsigned __int64)(unsigned int)(*((_DWORD *)p + 26) << (*((_BYTE *)p + 112) + dword_2868B08)) << 32)
       | (unsigned int)(*((_DWORD *)p + 25) << (*((_BYTE *)p + 112) + dword_2868B08));
    v9.newSpatialExtents.low.y = *((_DWORD *)p + 23) << (*((_BYTE *)p + 112) + dword_2868B08);
    v9.newSpatialExtents.low.x = *((_DWORD *)p + 22) << (*((_BYTE *)p + 112) + dword_2868B08);
    v9.newSpatialExtents.low.z = v4;
    *(_QWORD *)&v9.newSpatialExtents.high.x = v6;
    v9.newSpatialExtents.high.z = v5;
    v7 = *((_QWORD *)this + 12);
    for ( i = *((_QWORD *)this + 13); i != v7; v7 += 16 )
    {
      if ( (*(_BYTE *)(v7 + 8) & 4) != 0 )
        (***(void (__fastcall ****)(_QWORD, RBX::Primitive *, RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo *))v7)(
          *(_QWORD *)v7,
          p,
          &v9);
    }
  }
}


// Address: 0x1dfa0c0 | Name: _ZN3RBX9Collision23SpatialHashHierarchical9fastClearEv
void __fastcall RBX::Collision::SpatialHashHierarchical::fastClear(RBX::Collision::SpatialHashHierarchical *this)
{
  _QWORD *v1; // r14
  unsigned __int64 v2; // rbx

  v1 = (_QWORD *)*((_QWORD *)this + 8);
  if ( v1[1] )
  {
    v2 = 0;
    do
      RBX::Collision::LevelGrid::removeAllPrimitives(*(RBX::Collision::LevelGrid **)(*v1 + 8 * v2++));
    while ( v2 < v1[1] );
  }
}


// Address: 0x1dfa100 | Name: _ZN3RBX9Collision23SpatialHashHierarchical23checkAndReleaseContactsEPNS_9PrimitiveE
void __fastcall RBX::Collision::SpatialHashHierarchical::checkAndReleaseContacts(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Primitive *p)
{
  RBX::Collision::Contact *FirstContactNew; // rax
  RBX::Collision::Contact *NextContactNew; // rbx
  RBX::Primitive *prim0; // rax
  char v6; // cl
  RBX::Primitive *v7; // rax
  char v8; // dl
  bool v9; // cc
  RBX::Primitive *v10; // rdx
  char v11; // cl
  int v12; // r8d
  int v13; // r10d
  int v14; // r9d
  __int64 v15; // rsi
  int v16; // edx
  __int64 v17; // rbx
  RBX::Primitive *value; // [rsp+8h] [rbp-30h] BYREF

  G3D::Array<RBX::Primitive *,10,32ul>::resize((G3D::Array<RBX::Primitive *,10,32> *)this + 5, 0, 1);
  FirstContactNew = RBX::Primitive::getFirstContactNew(p);
  if ( FirstContactNew )
  {
    NextContactNew = FirstContactNew;
    do
    {
      prim0 = NextContactNew->prim0;
      if ( prim0 == p )
        prim0 = NextContactNew->prim1;
      value = prim0;
      NextContactNew = RBX::Primitive::getNextContactNew(p, NextContactNew);
      if ( RBX::ContactManager::primitiveIsExcludedFromSpatialHash(*((RBX::ContactManager **)this + 7), value) )
        continue;
      v6 = *((_BYTE *)p + 112);
      if ( v6 != -1 )
      {
        v7 = value;
        v8 = *((_BYTE *)value + 112);
        if ( v8 != -1 )
        {
          v9 = v6 <= v8;
          if ( v6 == v8 )
          {
            if ( *((_DWORD *)p + 22) < *((_DWORD *)value + 25)
              && *((_DWORD *)p + 23) < *((_DWORD *)value + 26)
              && *((_DWORD *)p + 24) < *((_DWORD *)value + 27)
              && *((_DWORD *)p + 26) > *((_DWORD *)value + 23)
              && *((_DWORD *)p + 25) > *((_DWORD *)value + 22)
              && *((_DWORD *)p + 27) > *((_DWORD *)value + 24) )
            {
              continue;
            }
          }
          else
          {
            v10 = p;
            if ( !v9 )
            {
              v10 = value;
              v7 = p;
            }
            v11 = *((_BYTE *)v7 + 112) - *((_BYTE *)v10 + 112);
            v12 = *((int *)v10 + 22) >> v11;
            v13 = *((int *)v10 + 23) >> v11;
            v14 = *((int *)v10 + 24) >> v11;
            v15 = *(_QWORD *)((char *)v10 + 100);
            v16 = *((int *)v10 + 27) >> v11;
            if ( *((_DWORD *)v7 + 22) <= (int)v15 >> v11
              && *((_DWORD *)v7 + 23) <= SHIDWORD(v15) >> v11
              && *((_DWORD *)v7 + 24) <= v16
              && *((_DWORD *)v7 + 26) > v13
              && *((_DWORD *)v7 + 25) > v12
              && *((_DWORD *)v7 + 27) > v14 )
            {
              continue;
            }
          }
        }
      }
      G3D::Array<RBX::Primitive *,10,32ul>::append((G3D::Array<RBX::Primitive *,10,32> *)this + 5, &value);
    }
    while ( NextContactNew );
  }
  if ( *((int *)this + 22) > 0 )
  {
    v17 = 0;
    do
      RBX::ContactManager::releasePair(
        *((RBX::ContactManager **)this + 7),
        p,
        *(RBX::Primitive **)(*((_QWORD *)this + 10) + 8 * v17++));
    while ( v17 < *((int *)this + 22) );
  }
}


// Address: 0x1dfa2a0 | Name: _ZN3RBX9Collision23SpatialHashHierarchical18onPrimitiveRemovedEPNS_9PrimitiveE
void __fastcall RBX::Collision::SpatialHashHierarchical::onPrimitiveRemoved(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Primitive *p)
{
  RBX::Collision::SpatialHashHierarchical *v2; // r14
  int v3; // r12d
  RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateType v4; // r15d
  RBX::Collision::GridHierarchy *v5; // rbp
  int v6; // r12d
  int v7; // r14d
  int v8; // ebp
  __int64 v9; // rbx
  char v10; // r12
  __int64 v11; // rbp
  __int64 i; // rbx
  int v13; // [rsp+10h] [rbp-A8h]
  int v14; // [rsp+14h] [rbp-A4h]
  RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateType v15; // [rsp+18h] [rbp-A0h]
  int v16; // [rsp+20h] [rbp-98h]
  char v17; // [rsp+2Ch] [rbp-8Ch]
  RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateType v18; // [rsp+30h] [rbp-88h]
  int v19; // [rsp+38h] [rbp-80h]
  RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo cellCoord; // [rsp+48h] [rbp-70h] BYREF

  v2 = this;
  v3 = *((char *)p + 112);
  v4 = *((_DWORD *)p + 22);
  v19 = *((_DWORD *)p + 23);
  v14 = *((_DWORD *)p + 24);
  v15 = *((_DWORD *)p + 25);
  v16 = *((_DWORD *)p + 26);
  v13 = *((_DWORD *)p + 27);
  if ( v3 >= 0 )
  {
    v5 = (RBX::Collision::GridHierarchy *)*((_QWORD *)this + 8);
    v17 = *((_BYTE *)p + 112);
    v18 = *((_DWORD *)p + 22);
    if ( v4 < v15 )
    {
      do
      {
        v6 = v19;
        if ( v19 < v16 )
        {
          do
          {
            v7 = v14;
            if ( v14 < v13 )
            {
              do
              {
                cellCoord.updateType = v4;
                cellCoord.oldLevel_deprecated = v6;
                cellCoord.oldSpatialExtents.low.x = v7;
                RBX::Collision::GridHierarchy::removePrimitiveFromCell(
                  v5,
                  p,
                  v17,
                  (const RBX::Collision::CellCoord *)&cellCoord);
                ++v7;
              }
              while ( v13 != v7 );
            }
            ++v6;
          }
          while ( v6 != v16 );
        }
        ++v4;
      }
      while ( v4 != v15 );
    }
    if ( stru_2AAF660.value )
      --v5->levels.mData[v17]->primitiveCount;
    *((_WORD *)p + 56) = 767;
    v2 = this;
    v4 = v18;
    LOBYTE(v3) = v17;
  }
  G3D::Array<RBX::Primitive *,10,32ul>::resize((G3D::Array<RBX::Primitive *,10,32> *)v2 + 5, 0, 1);
  if ( (int)((*((_QWORD *)p + 59) - *((_QWORD *)p + 58)) >> 4) > 0 )
  {
    v8 = 0;
    do
    {
      *(_QWORD *)&cellCoord.updateType = RBX::ContactList::getOther((RBX::Primitive *)((char *)p + 456), v8);
      G3D::Array<RBX::Primitive *,10,32ul>::append(
        (G3D::Array<RBX::Primitive *,10,32> *)v2 + 5,
        (RBX::Primitive *const *)&cellCoord);
      ++v8;
    }
    while ( v8 < (int)((*((_QWORD *)p + 59) - *((_QWORD *)p + 58)) >> 4) );
  }
  if ( *((int *)v2 + 22) > 0 )
  {
    v9 = 0;
    do
      RBX::ContactManager::releasePair(
        *((RBX::ContactManager **)v2 + 7),
        p,
        *(RBX::Primitive **)(*((_QWORD *)v2 + 10) + 8 * v9++));
    while ( v9 < *((int *)v2 + 22) );
  }
  if ( *((_QWORD *)v2 + 12) != *((_QWORD *)v2 + 13) )
  {
    RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateInfo(&cellCoord);
    v10 = dword_2868B08 + v3;
    *(_QWORD *)&cellCoord.updateType = 0xFFFFFFFF00000002LL;
    cellCoord.oldSpatialExtents.low.y = v19 << v10;
    cellCoord.oldSpatialExtents.low.x = v4 << v10;
    cellCoord.oldSpatialExtents.low.z = v14 << v10;
    cellCoord.oldSpatialExtents.high.y = v16 << v10;
    cellCoord.oldSpatialExtents.high.x = v15 << v10;
    cellCoord.oldSpatialExtents.high.z = v13 << v10;
    v11 = *((_QWORD *)v2 + 12);
    for ( i = *((_QWORD *)v2 + 13); i != v11; v11 += 16 )
    {
      if ( (*(_BYTE *)(v11 + 8) & 8) != 0 )
        (***(void (__fastcall ****)(_QWORD, RBX::Primitive *, RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo *))v11)(
          *(_QWORD *)v11,
          p,
          &cellCoord);
    }
  }
}


// Address: 0x1dfa570 | Name: _ZNK3RBX9Collision23SpatialHashHierarchical30processCoarseMovementCallbacksEPNS_9PrimitiveEiRKNS_12ExtentsInt32EiS6_
void __fastcall RBX::Collision::SpatialHashHierarchical::processCoarseMovementCallbacks(
        const RBX::Collision::SpatialHashHierarchical *this,
        RBX::Primitive *p,
        int oldLevel,
        const RBX::ExtentsInt32 *preUpdateSpatialExtents,
        int newLevel,
        const RBX::ExtentsInt32 *postUpdateSpatialExtents)
{
  int v11; // edi
  unsigned __int64 v12; // rdx
  __int64 v13; // rsi
  __int64 v14; // rbp
  int v15; // ebx
  int v16; // edi
  int v17; // ebx
  unsigned __int64 v18; // rsi
  __int64 v19; // r15
  __int64 i; // rbx
  int v21; // eax
  int v22; // [rsp+4h] [rbp-84h]
  int v24; // [rsp+10h] [rbp-78h]
  RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo v25; // [rsp+18h] [rbp-70h] BYREF

  if ( *((_QWORD *)this + 12) != *((_QWORD *)this + 13) )
  {
    RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateInfo(&v25);
    *(_QWORD *)&v25.updateType = 0xFFFFFFFF00000001LL;
    v24 = oldLevel;
    v11 = preUpdateSpatialExtents->low.z << (dword_2868B08 + oldLevel);
    v12 = ((unsigned __int64)(unsigned int)(preUpdateSpatialExtents->low.y << (dword_2868B08 + oldLevel)) << 32)
        | (unsigned int)(preUpdateSpatialExtents->low.x << (dword_2868B08 + oldLevel));
    v13 = (unsigned int)(preUpdateSpatialExtents->high.x << (dword_2868B08 + oldLevel));
    v14 = (unsigned int)(preUpdateSpatialExtents->high.y << (dword_2868B08 + oldLevel));
    v15 = preUpdateSpatialExtents->high.z << (dword_2868B08 + oldLevel);
    *(_QWORD *)&v25.oldSpatialExtents.low.x = v12;
    v25.oldSpatialExtents.low.z = v11;
    *(_QWORD *)&v25.oldSpatialExtents.high.x = (v14 << 32) | v13;
    v25.oldSpatialExtents.high.z = v15;
    v25.newLevel_deprecated = -1;
    v22 = newLevel;
    v16 = postUpdateSpatialExtents->low.z << (newLevel + dword_2868B08);
    v17 = postUpdateSpatialExtents->high.z << (newLevel + dword_2868B08);
    v18 = ((unsigned __int64)(unsigned int)(postUpdateSpatialExtents->high.y << (newLevel + dword_2868B08)) << 32)
        | (unsigned int)(postUpdateSpatialExtents->high.x << (newLevel + dword_2868B08));
    v25.newSpatialExtents.low.y = postUpdateSpatialExtents->low.y << (newLevel + dword_2868B08);
    v25.newSpatialExtents.low.x = postUpdateSpatialExtents->low.x << (newLevel + dword_2868B08);
    v25.newSpatialExtents.low.z = v16;
    *(_QWORD *)&v25.newSpatialExtents.high.x = v18;
    v25.newSpatialExtents.high.z = v17;
    v19 = *((_QWORD *)this + 12);
    for ( i = *((_QWORD *)this + 13); i != v19; v19 += 16 )
    {
      v21 = *(_DWORD *)(v19 + 8);
      if ( (v21 & 2) != 0
        || (v21 & 1) != 0
        && (v22 != v24
         || preUpdateSpatialExtents->low.x != postUpdateSpatialExtents->low.x
         || preUpdateSpatialExtents->low.y != postUpdateSpatialExtents->low.y
         || preUpdateSpatialExtents->low.z != postUpdateSpatialExtents->low.z
         || preUpdateSpatialExtents->high.x != postUpdateSpatialExtents->high.x
         || preUpdateSpatialExtents->high.y != postUpdateSpatialExtents->high.y
         || preUpdateSpatialExtents->high.z != postUpdateSpatialExtents->high.z) )
      {
        (***(void (__fastcall ****)(_QWORD, RBX::Primitive *, RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo *))v19)(
          *(_QWORD *)v19,
          p,
          &v25);
      }
    }
  }
}


// Address: 0x1dfa710 | Name: _ZN3RBX9Collision23SpatialHashHierarchical25onPrimitiveExtentsChangedEPNS_9PrimitiveE
void __fastcall RBX::Collision::SpatialHashHierarchical::onPrimitiveExtentsChanged(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Primitive *p)
{
  int v2; // r14d
  RBX::ContactManager *v3; // r15
  RBX::Collision::GridHierarchy *v4; // r12
  const RBX::Extents *FastFuzzyExtents; // rbp
  __int128 v6; // xmm0
  int v7; // eax
  RBX::Extents v8; // [rsp+0h] [rbp-68h] BYREF
  RBX::ExtentsInt32 preUpdateSpatialExtents; // [rsp+20h] [rbp-48h] BYREF

  v2 = *((char *)p + 112);
  preUpdateSpatialExtents = *(RBX::ExtentsInt32 *)((char *)p + 88);
  v3 = (RBX::ContactManager *)*((_QWORD *)this + 7);
  v4 = (RBX::Collision::GridHierarchy *)*((_QWORD *)this + 8);
  FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(p);
  if ( RBX::Math::isNanInfVector3(&FastFuzzyExtents->low) || RBX::Math::isNanInfVector3(&FastFuzzyExtents->high) )
  {
    *(_QWORD *)&v8.high.y = *(_QWORD *)&byte_29FC388[16];
    v6 = *(_OWORD *)byte_29FC388;
  }
  else
  {
    *(_QWORD *)&v8.high.y = *(_QWORD *)&FastFuzzyExtents->high.y;
    v6 = *(_OWORD *)&FastFuzzyExtents->low.x;
  }
  *(_OWORD *)&v8.low.x = v6;
  v7 = RBX::Collision::computeLevel(p, &v8);
  RBX::Collision::GridHierarchy::primitiveExtentsChangedInternal(v4, v3, p, v7, &v8, 1);
  RBX::Collision::SpatialHashHierarchical::checkAndReleaseContacts(this, p);
  v8 = *(RBX::Extents *)((char *)p + 88);
  RBX::Collision::SpatialHashHierarchical::processCoarseMovementCallbacks(
    this,
    p,
    v2,
    &preUpdateSpatialExtents,
    *((char *)p + 112),
    (const RBX::ExtentsInt32 *)&v8);
}


// Address: 0x1dfa810 | Name: _ZN3RBX9Collision23SpatialHashHierarchical28onPrimitiveCanCollideChangedEPNS_9PrimitiveE
void __fastcall RBX::Collision::SpatialHashHierarchical::onPrimitiveCanCollideChanged(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Primitive *p)
{
  int v4; // r8d
  unsigned __int64 v5; // rdx
  int v6; // esi
  unsigned __int64 v7; // rdi
  __int64 v8; // rbx
  __int64 i; // r12
  RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo v10; // [rsp+8h] [rbp-60h] BYREF

  if ( !RBX::ContactManager::primitiveIsExcludedFromSpatialHash(*((RBX::ContactManager **)this + 7), p)
    && *((_BYTE *)p + 112) != 0xFF
    && *((_QWORD *)this + 12) != *((_QWORD *)this + 13) )
  {
    RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo::UpdateInfo(&v10);
    *(_QWORD *)&v10.updateType = 0xFFFFFFFF00000003LL;
    v10.newLevel_deprecated = -1;
    v4 = *((_DWORD *)p + 24) << (*((_BYTE *)p + 112) + dword_2868B08);
    v5 = (unsigned __int64)(unsigned int)(*((_DWORD *)p + 23) << (*((_BYTE *)p + 112) + dword_2868B08)) << 32;
    v6 = *((_DWORD *)p + 27) << (*((_BYTE *)p + 112) + dword_2868B08);
    v7 = ((unsigned __int64)(unsigned int)(*((_DWORD *)p + 26) << (*((_BYTE *)p + 112) + dword_2868B08)) << 32)
       | (unsigned int)(*((_DWORD *)p + 25) << (*((_BYTE *)p + 112) + dword_2868B08));
    *(_QWORD *)&v10.newSpatialExtents.low.x = v5
                                            | (unsigned int)(*((_DWORD *)p + 22) << (*((_BYTE *)p + 112) + dword_2868B08));
    v10.newSpatialExtents.low.z = v4;
    *(_QWORD *)&v10.newSpatialExtents.high.x = v7;
    v10.newSpatialExtents.high.z = v6;
    v10.oldSpatialExtents.low.z = v4;
    *(_QWORD *)&v10.oldSpatialExtents.low.x = *(_QWORD *)&v10.newSpatialExtents.low.x;
    v10.oldSpatialExtents.high.z = v6;
    *(_QWORD *)&v10.oldSpatialExtents.high.x = v7;
    v8 = *((_QWORD *)this + 12);
    for ( i = *((_QWORD *)this + 13); i != v8; v8 += 16 )
    {
      if ( (*(_BYTE *)(v8 + 8) & 0x10) != 0 )
        (***(void (__fastcall ****)(_QWORD, RBX::Primitive *, RBX::Collision::SpatialHashBase::MovementCallback::UpdateInfo *))v8)(
          *(_QWORD *)v8,
          p,
          &v10);
    }
  }
}


// Address: 0x1dfa920 | Name: _ZNK3RBX9Collision23SpatialHashHierarchical39onPrimitiveExtentsChangedMTCacheExtentsEPNS_9PrimitiveERNS0_28PrimitiveExtentsChangedCacheE
bool __fastcall RBX::Collision::SpatialHashHierarchical::onPrimitiveExtentsChangedMTCacheExtents(
        const RBX::Collision::SpatialHashHierarchical *this,
        RBX::Primitive *p,
        RBX::Collision::PrimitiveExtentsChangedCache *extentsChangedCache)
{
  extentsChangedCache->primitive = p;
  return RBX::Collision::GridHierarchy::updatePrimitiveNewExtentsAndLevelMT(
           (const RBX::Collision::GridHierarchy *)this,
           p,
           &extentsChangedCache->newExtents,
           &extentsChangedCache->newLevel,
           &extentsChangedCache->levelChanged,
           &extentsChangedCache->newGridExtents);
}


// Address: 0x1dfa940 | Name: _ZN3RBX9Collision23SpatialHashHierarchical28processPrimitiveExtentsCacheERKNS0_28PrimitiveExtentsChangedCacheE
void __fastcall RBX::Collision::SpatialHashHierarchical::processPrimitiveExtentsCache(
        RBX::Collision::SpatialHashHierarchical *this,
        const RBX::Collision::PrimitiveExtentsChangedCache *extentsChangedCache)
{
  const RBX::Extents *v2; // rcx
  RBX::Primitive *primitive; // rbx
  int v4; // r14d
  bool value; // bp
  int newLevel; // r12d
  int v7; // ebp
  int v8; // ebp
  RBX::ExtentsInt32 v9; // [rsp+0h] [rbp-68h] BYREF
  RBX::ExtentsInt32 preUpdateSpatialExtents; // [rsp+20h] [rbp-48h] BYREF

  primitive = extentsChangedCache->primitive;
  v4 = *((char *)primitive + 112);
  value = stru_2AAF680.value;
  newLevel = extentsChangedCache->newLevel;
  preUpdateSpatialExtents = *(RBX::ExtentsInt32 *)((char *)primitive + 88);
  RBX::Collision::GridHierarchy::primitiveExtentsChangedPostMT(
    *((RBX::Collision::GridHierarchy **)this + 8),
    *((RBX::ContactManager **)this + 7),
    primitive,
    v2,
    extentsChangedCache->levelChanged,
    &extentsChangedCache->newGridExtents);
  v7 = -!value;
  if ( stru_2AAF680.value )
    v8 = *((char *)primitive + 112);
  else
    v8 = newLevel | ~v7;
  RBX::Collision::SpatialHashHierarchical::checkAndReleaseContacts(this, primitive);
  v9 = *(RBX::ExtentsInt32 *)((char *)primitive + 88);
  RBX::Collision::SpatialHashHierarchical::processCoarseMovementCallbacks(
    this,
    primitive,
    v4,
    &preUpdateSpatialExtents,
    v8,
    &v9);
}


// Address: 0x1dfaa00 | Name: _ZN3RBX9Collision23SpatialHashHierarchical26createNewPrimitiveContactsEPNS_9PrimitiveE
void __fastcall RBX::Collision::SpatialHashHierarchical::createNewPrimitiveContacts(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Primitive *p)
{
  int v2; // ebp
  int v3; // r8d
  RBX::ExtentsInt32 v4; // [rsp+0h] [rbp-58h] BYREF
  RBX::ExtentsInt32 preUpdateSpatialExtents; // [rsp+20h] [rbp-38h] BYREF

  if ( !RBX::ContactManager::primitiveIsExcludedFromSpatialHash(*((RBX::ContactManager **)this + 7), p) )
  {
    v2 = *((char *)p + 112);
    if ( v2 != -1 )
    {
      preUpdateSpatialExtents = *(RBX::ExtentsInt32 *)((char *)p + 88);
      RBX::Collision::GridHierarchy::addContactsWithPrimitive(
        *((RBX::Collision::GridHierarchy **)this + 8),
        *((RBX::ContactManager **)this + 7),
        p);
      v3 = *((char *)p + 112);
      v4 = *(RBX::ExtentsInt32 *)((char *)p + 88);
      RBX::Collision::SpatialHashHierarchical::processCoarseMovementCallbacks(
        this,
        p,
        v2,
        &preUpdateSpatialExtents,
        v3,
        &v4);
    }
  }
}


// Address: 0x1dfaa90 | Name: _ZN3RBX9Collision23SpatialHashHierarchical26getPrimitivesTouchingGridsERKNS_7ExtentsEPKNS_9PrimitiveEmRN5boost9unordered13unordered_setIPS5_NS8_4hashISB_EENSt3__18equal_toISB_EENSE_9allocatorISB_EEEE
void __fastcall RBX::Collision::SpatialHashHierarchical::getPrimitivesTouchingGrids(
        RBX::Collision::SpatialHashHierarchical *this,
        const RBX::Extents *extents,
        const RBX::Primitive *ignore,
        size_t maxCount,
        boost::unordered::unordered_set<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>,std::allocator<RBX::Primitive *> > *answer)
{
  _QWORD *v5; // r14
  __int64 v6; // rbp
  int v7; // eax
  __m128 v8; // xmm1
  __m128 v9; // xmm0
  __m128 v10; // xmm1
  __m128 v11; // xmm3
  __m128 v12; // xmm2
  __m128 v13; // xmm4
  __m128 v14; // xmm1
  __m128 v15; // xmm2
  __m128 v16; // xmm2
  __m128 y_low; // xmm10
  __m128 z_low; // xmm8
  __m128 v19; // xmm0
  __m128 v20; // xmm3
  __m128i v21; // xmm0
  int v22; // ebx
  int v23; // edx
  float x; // xmm3_4
  __m128 v25; // xmm4
  __m128 v26; // xmm9
  __m128 v27; // xmm0
  __m128 v28; // xmm6
  __m128i v29; // xmm0
  int v30; // esi
  int v31; // edi
  float v32; // xmm6_4
  float v33; // xmm0_4
  float v34; // xmm7_4
  float v35; // xmm0_4
  float v36; // xmm7_4
  float v37; // xmm2_4
  int v38; // ebp
  int v39; // edx
  __int64 v40; // r15
  unsigned __int64 v41; // rcx
  __int64 v42; // rcx
  RBX::Primitive **v43; // r15
  RBX::Primitive *v44; // r13
  const RBX::Extents *v45; // rbx
  bool v46; // al
  float *v47; // rdx
  float *v48; // rdi
  float *v49; // rsi
  float *v50; // r8
  float *v51; // r9
  float *v52; // rcx
  bool v53; // al
  unsigned __int64 v54; // rax
  __int64 v55; // r12
  RBX::Primitive **v56; // r15
  RBX::Primitive **v57; // r12
  int v58; // r14d
  RBX::Primitive *v59; // r13
  const RBX::Extents *FastFuzzyExtents; // rbp
  bool isNanInfVector3; // al
  float *v62; // rdx
  float *v63; // rdi
  float *p_x; // rsi
  float *p_z; // r8
  float *p_y; // r9
  float *v67; // rcx
  bool v68; // al
  __int64 v69; // r12
  unsigned __int64 v70; // rcx
  __int64 v71; // r12
  __int64 v72; // r8
  _DWORD *v73; // rsi
  __int64 v74; // rax
  __int64 v75; // r14
  unsigned __int64 v76; // rdi
  int v78; // [rsp+8h] [rbp-C0h]
  int v79; // [rsp+Ch] [rbp-BCh]
  bool v80; // [rsp+10h] [rbp-B8h]
  int v81; // [rsp+2Ch] [rbp-9Ch]
  unsigned int category; // [rsp+30h] [rbp-98h]
  int v83; // [rsp+34h] [rbp-94h]
  int v84; // [rsp+38h] [rbp-90h]
  int v85; // [rsp+3Ch] [rbp-8Ch]
  size_t v88; // [rsp+48h] [rbp-80h]
  __int64 v89; // [rsp+50h] [rbp-78h]
  RBX::Primitive *args; // [rsp+58h] [rbp-70h] BYREF
  int v91; // [rsp+60h] [rbp-68h]
  int v92; // [rsp+64h] [rbp-64h]
  int v93; // [rsp+68h] [rbp-60h]
  int v94; // [rsp+6Ch] [rbp-5Ch]
  __m128 v95; // [rsp+70h] [rbp-58h]
  const RBX::Primitive *v96; // [rsp+80h] [rbp-48h]
  __int64 v97; // [rsp+88h] [rbp-40h]
  _QWORD *v98; // [rsp+90h] [rbp-38h]

  v96 = ignore;
  category = RBX::Memory::setCurrentCategory(dword_2AAF1D4);
  v5 = (_QWORD *)*((_QWORD *)this + 8);
  if ( !v5[1] )
    goto LABEL_75;
  v88 = maxCount - 1;
  v6 = 0;
  while ( 1 )
  {
    v89 = *(_QWORD *)(*v5 + 8 * v6);
    if ( *(_QWORD *)(v89 + 200) )
    {
      v9 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << v6), 0));
      v10 = _mm_rcp_ps(v9);
      v11 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v10, v9)), v10);
      v12 = _mm_and_ps(v11, (__m128)xmmword_3E5B40);
      v13 = _mm_or_ps(
              _mm_and_ps(_mm_cmpnlt_ps(v12, (__m128)xmmword_3EB1D0), v10),
              _mm_and_ps(_mm_cmplt_ps(v12, (__m128)xmmword_3EB1D0), v11));
      v14 = _mm_and_ps(v9, (__m128)xmmword_3E5B40);
      v15 = _mm_and_ps(_mm_and_ps(_mm_cmpeq_ps(v14, (__m128)xmmword_3EB1D0), v9), *(__m128 *)&stru_3E4970.x);
      v8 = _mm_and_ps(_mm_cmpneq_ps(v14, (__m128)xmmword_3EB1D0), v13);
      if ( !(_BYTE)byte_29FEDE8 )
      {
        v95 = v8;
        v7 = __cxa_guard_acquire(&byte_29FEDE8);
        v8 = v95;
        if ( v7 )
        {
          *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
          *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
          __cxa_guard_release(&byte_29FEDE8);
          v8 = v95;
        }
      }
      v16 = _mm_or_ps(v15, v8);
      if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
      {
        qword_29FEE08 = 0x8000000080000000LL;
        dword_29FEE10 = 0x80000000;
        __cxa_guard_release(&byte_29FEE18);
      }
      y_low = (__m128)LODWORD(extents->low.y);
      z_low = (__m128)LODWORD(extents->low.z);
      v19 = _mm_mul_ps(
              _mm_min_ps(
                (__m128)xmmword_3E8210,
                _mm_max_ps(
                  (__m128)xmmword_3E5450,
                  _mm_unpacklo_ps(_mm_unpacklo_ps((__m128)LODWORD(extents->low.x), z_low), y_low))),
              v16);
      v20 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v19));
      v21 = _mm_cvttps_epi32(_mm_sub_ps(v20, _mm_and_ps(_mm_cmplt_ps(v19, v20), (__m128)stru_3E5460)));
      v22 = _mm_cvtsi128_si32(v21);
      v23 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v21, 229));
      v78 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v21, 78));
      x = extents->high.x;
      v25 = (__m128)LODWORD(extents->high.y);
      v26 = (__m128)LODWORD(extents->high.z);
      v27 = _mm_mul_ps(
              _mm_min_ps(
                (__m128)xmmword_3E8210,
                _mm_max_ps((__m128)xmmword_3E5450, _mm_unpacklo_ps(_mm_unpacklo_ps((__m128)LODWORD(x), v26), v25))),
              v16);
      v28 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v27));
      v29 = _mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v28, v27), (__m128)stru_3E5460), v28));
      v30 = _mm_cvtsi128_si32(v29);
      v31 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v29, 229));
      v32 = (float)(1 << dword_2868B08 << v6);
      v79 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v29, 78));
      v33 = (float)v22 * v32;
      v80 = 0;
      if ( v33 >= extents->low.x )
      {
        v34 = (float)v23 * v32;
        if ( v34 >= y_low.m128_f32[0] )
        {
          v80 = 0;
          if ( v25.m128_f32[0] >= v34 && x >= v33 )
          {
            v35 = (float)v78 * v32;
            if ( v35 >= z_low.m128_f32[0] )
            {
              v36 = (float)v31 * v32;
              v80 = 0;
              if ( v36 >= y_low.m128_f32[0] )
              {
                v37 = (float)v30 * v32;
                if ( v37 >= extents->low.x && v26.m128_f32[0] >= v35 )
                  v80 = (float)((float)v79 * v32) >= z_low.m128_f32[0]
                     && x >= v37
                     && v25.m128_f32[0] >= v36
                     && v26.m128_f32[0] >= (float)((float)v79 * v32);
              }
            }
          }
        }
      }
      if ( v22 < v30 )
        break;
    }
LABEL_74:
    if ( (unsigned __int64)++v6 >= v5[1] )
      goto LABEL_75;
  }
  v98 = v5;
  v97 = v6;
  v81 = v23;
  v91 = v30;
  v93 = v31;
  while ( v23 >= v31 )
  {
LABEL_73:
    ++v22;
    v5 = v98;
    v6 = v97;
    v23 = v81;
    if ( v22 >= v91 )
      goto LABEL_74;
  }
  v92 = 73856093 * v22;
  v38 = v81;
  v84 = v22;
  while ( v78 >= v79 )
  {
LABEL_72:
    ++v38;
    v31 = v93;
    if ( v38 >= v93 )
      goto LABEL_73;
  }
  v94 = v92 ^ (19349663 * v38);
  v39 = v78;
  v85 = v38;
  while ( 1 )
  {
    v69 = (v94 ^ (83492791 * v39)) & (unsigned int)(*(_DWORD *)(v89 + 8) - 1);
    v70 = *(unsigned __int8 *)(*(_QWORD *)v89 + v69);
    if ( !*(_BYTE *)(*(_QWORD *)v89 + v69) )
      goto LABEL_71;
    v71 = 16 * v69;
    v72 = *(_QWORD *)(v89 + 32);
    v73 = (_DWORD *)(*(_QWORD *)(v72 + v71) + 8LL);
    v74 = 24;
    v75 = 8;
    v76 = 0;
    while ( *(v73 - 2) != v22 || *(v73 - 1) != v38 || *v73 != v39 )
    {
      ++v76;
      v75 += 32;
      v74 += 32;
      v73 += 3;
      if ( v76 >= v70 )
        goto LABEL_71;
    }
    v40 = *(_QWORD *)(v72 + v71 + 8);
    v41 = *(unsigned int *)(v40 + v74 - 8);
    if ( v41 >= 2 )
      break;
    if ( (_DWORD)v41 )
    {
      v83 = v39;
      v42 = v40 + 8 * v41;
      v43 = (RBX::Primitive **)(v74 + v40);
      v95.m128_u64[0] = v74 + v42;
      goto LABEL_35;
    }
LABEL_45:
    v54 = *(unsigned int *)(v40 + v75 - 8);
    if ( v54 >= 2 )
    {
      v56 = *(RBX::Primitive ***)(v40 + v75);
      v57 = &v56[v54];
LABEL_55:
      while ( 1 )
      {
        v58 = v39;
        v59 = *v56;
        if ( v80 )
          goto LABEL_78;
        FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(v59);
        isNanInfVector3 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->low);
        v62 = (float *)&byte_29FC388[20];
        v63 = (float *)&byte_29FC388[16];
        p_x = (float *)&byte_29FC388[12];
        p_z = (float *)&byte_29FC388[8];
        p_y = (float *)&byte_29FC388[4];
        v67 = (float *)byte_29FC388;
        if ( !isNanInfVector3 )
        {
          v68 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->high);
          v62 = (float *)&byte_29FC388[20];
          v63 = (float *)&byte_29FC388[16];
          p_x = (float *)&byte_29FC388[12];
          p_z = (float *)&byte_29FC388[8];
          p_y = (float *)&byte_29FC388[4];
          v67 = (float *)byte_29FC388;
          if ( !v68 )
          {
            p_y = &FastFuzzyExtents->low.y;
            p_z = &FastFuzzyExtents->low.z;
            v63 = &FastFuzzyExtents->high.y;
            v62 = &FastFuzzyExtents->high.z;
            p_x = &FastFuzzyExtents->high.x;
            v67 = &FastFuzzyExtents->low.x;
          }
        }
        if ( extents->low.x <= *p_x
          && extents->low.y <= *v63
          && extents->low.z <= *v62
          && *p_y <= extents->high.y
          && *v67 <= extents->high.x
          && *p_z <= extents->high.z )
        {
LABEL_78:
          args = v59;
          if ( v59 != v96 )
          {
            boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive *>,RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>>::emplace_impl<RBX::Primitive * const&>(
              &answer->table_,
              &args,
              &args);
            if ( v88 < answer->table_.size_ )
              goto LABEL_75;
          }
        }
        ++v56;
        v22 = v84;
        v38 = v85;
        v39 = v58;
        if ( v57 == v56 )
          goto LABEL_71;
      }
    }
    if ( (_DWORD)v54 )
    {
      v55 = v40 + 8 * v54;
      v56 = (RBX::Primitive **)(v75 + v40);
      v57 = (RBX::Primitive **)(v75 + v55);
      goto LABEL_55;
    }
LABEL_71:
    if ( ++v39 >= v79 )
      goto LABEL_72;
  }
  v83 = v39;
  v43 = *(RBX::Primitive ***)(v40 + v74);
  v95.m128_u64[0] = (unsigned __int64)&v43[v41];
LABEL_35:
  while ( 1 )
  {
    v44 = *v43;
    if ( v80 )
      goto LABEL_79;
    v45 = RBX::Primitive::getFastFuzzyExtents(v44);
    v46 = RBX::Math::isNanInfVector3(&v45->low);
    v47 = (float *)&byte_29FC388[20];
    v48 = (float *)&byte_29FC388[16];
    v49 = (float *)&byte_29FC388[12];
    v50 = (float *)&byte_29FC388[8];
    v51 = (float *)&byte_29FC388[4];
    v52 = (float *)byte_29FC388;
    if ( !v46 )
    {
      v53 = RBX::Math::isNanInfVector3(&v45->high);
      v47 = (float *)&byte_29FC388[20];
      v48 = (float *)&byte_29FC388[16];
      v49 = (float *)&byte_29FC388[12];
      v50 = (float *)&byte_29FC388[8];
      v51 = (float *)&byte_29FC388[4];
      v52 = (float *)byte_29FC388;
      if ( !v53 )
      {
        v51 = &v45->low.y;
        v50 = &v45->low.z;
        v48 = &v45->high.y;
        v47 = &v45->high.z;
        v49 = &v45->high.x;
        v52 = &v45->low.x;
      }
    }
    if ( extents->low.x <= *v49
      && extents->low.y <= *v48
      && extents->low.z <= *v47
      && *v51 <= extents->high.y
      && *v52 <= extents->high.x
      && *v50 <= extents->high.z )
    {
LABEL_79:
      args = v44;
      if ( v44 != v96 )
      {
        boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive *>,RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>>::emplace_impl<RBX::Primitive * const&>(
          &answer->table_,
          &args,
          &args);
        if ( v88 < answer->table_.size_ )
          break;
      }
    }
    if ( (RBX::Primitive **)v95.m128_u64[0] == ++v43 )
    {
      v40 = *(_QWORD *)(*(_QWORD *)(v89 + 32) + v71 + 8);
      v22 = v84;
      v38 = v85;
      v39 = v83;
      goto LABEL_45;
    }
  }
LABEL_75:
  RBX::Memory::setCurrentCategory(category);
}


// Address: 0x1dfb2e0 | Name: _ZN3RBX9Collision23SpatialHashHierarchical26getPrimitivesTouchingGridsERKNS_7ExtentsERKN5boost9unordered13unordered_setIPKNS_9PrimitiveENS5_4hashISA_EENSt3__18equal_toISA_EENSD_9allocatorISA_EEEEmRNS7_IPS8_NSB_ISL_EENSE_ISL_EENSG_ISL_EEEEb
void __fastcall RBX::Collision::SpatialHashHierarchical::getPrimitivesTouchingGrids(
        RBX::Collision::SpatialHashHierarchical *this,
        const RBX::Extents *extents,
        const boost::unordered::unordered_set<const RBX::Primitive *,boost::hash<const RBX::Primitive *>,std::equal_to<const RBX::Primitive *>,std::allocator<const RBX::Primitive *> > *ignoreSet,
        size_t maxCount,
        boost::unordered::unordered_set<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>,std::allocator<RBX::Primitive *> > *answer,
        bool ignoreIsWhitelist)
{
  _QWORD *v6; // r14
  unsigned __int64 v7; // rbp
  int v8; // eax
  __m128 v9; // xmm1
  __m128 v10; // xmm0
  __m128 v11; // xmm1
  __m128 v12; // xmm3
  __m128 v13; // xmm2
  __m128 v14; // xmm4
  __m128 v15; // xmm1
  __m128 v16; // xmm2
  __m128 v17; // xmm2
  __m128 y_low; // xmm10
  __m128 z_low; // xmm8
  __m128 v20; // xmm0
  __m128 v21; // xmm3
  __m128i v22; // xmm0
  int v23; // ebx
  int v24; // edx
  float x; // xmm3_4
  __m128 v26; // xmm4
  __m128 v27; // xmm9
  __m128 v28; // xmm0
  __m128 v29; // xmm6
  __m128i v30; // xmm0
  int v31; // esi
  int v32; // edi
  float v33; // xmm6_4
  float v34; // xmm0_4
  float v35; // xmm7_4
  float v36; // xmm0_4
  float v37; // xmm7_4
  float v38; // xmm2_4
  int v39; // ebp
  int v40; // edx
  __int64 v41; // r15
  unsigned __int64 v42; // rcx
  __int64 v43; // rcx
  RBX::Primitive **v44; // r15
  RBX::Primitive *v45; // r14
  unsigned __int64 v46; // rax
  size_t v47; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rsi
  boost::unordered::detail::ptr_bucket::link_pointer v49; // rdi
  const RBX::Extents *FastFuzzyExtents; // rbp
  bool isNanInfVector3; // al
  float *v52; // rdx
  float *v53; // rdi
  float *p_x; // rsi
  float *p_z; // r8
  float *p_y; // r9
  float *v57; // rcx
  bool v58; // al
  unsigned __int64 v59; // rax
  __int64 v60; // r12
  RBX::Primitive **v61; // r15
  RBX::Primitive **v62; // r12
  int v63; // r13d
  RBX::Primitive *v64; // r14
  unsigned __int64 v65; // rax
  size_t v66; // rdx
  boost::unordered::detail::ptr_bucket::link_pointer v67; // rsi
  boost::unordered::detail::ptr_bucket::link_pointer v68; // rdi
  const RBX::Extents *v69; // rbx
  bool v70; // al
  float *v71; // rdx
  float *v72; // rdi
  float *v73; // rsi
  float *v74; // r8
  float *v75; // r9
  float *v76; // rcx
  bool v77; // al
  __int64 v78; // r12
  unsigned __int64 v79; // rcx
  __int64 v80; // r12
  __int64 v81; // r8
  _DWORD *v82; // rsi
  __int64 v83; // rax
  __int64 v84; // r13
  unsigned __int64 v85; // rdi
  int v88; // [rsp+18h] [rbp-C0h]
  int v89; // [rsp+1Ch] [rbp-BCh]
  bool v90; // [rsp+20h] [rbp-B8h]
  int v91; // [rsp+34h] [rbp-A4h]
  unsigned int category; // [rsp+38h] [rbp-A0h]
  int v93; // [rsp+3Ch] [rbp-9Ch]
  int v94; // [rsp+40h] [rbp-98h]
  int v95; // [rsp+44h] [rbp-94h]
  size_t v99; // [rsp+58h] [rbp-80h]
  __int64 v100; // [rsp+60h] [rbp-78h]
  RBX::Primitive *args; // [rsp+68h] [rbp-70h] BYREF
  int v102; // [rsp+70h] [rbp-68h]
  int v103; // [rsp+74h] [rbp-64h]
  int v104; // [rsp+78h] [rbp-60h]
  int v105; // [rsp+7Ch] [rbp-5Ch]
  __m128 v106; // [rsp+80h] [rbp-58h]
  unsigned __int64 v107; // [rsp+98h] [rbp-40h]
  _QWORD *v108; // [rsp+A0h] [rbp-38h]

  category = RBX::Memory::setCurrentCategory(dword_2AAF1D4);
  v6 = (_QWORD *)*((_QWORD *)this + 8);
  if ( v6[1] )
  {
    v99 = maxCount - 1;
    v7 = 0;
    do
    {
      v100 = *(_QWORD *)(*v6 + 8 * v7);
      if ( *(_QWORD *)(v100 + 200) )
      {
        v10 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << v7), 0));
        v11 = _mm_rcp_ps(v10);
        v12 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v11, v10)), v11);
        v13 = _mm_and_ps(v12, (__m128)xmmword_3E5B40);
        v14 = _mm_or_ps(
                _mm_and_ps(_mm_cmpnlt_ps(v13, (__m128)xmmword_3EB1D0), v11),
                _mm_and_ps(_mm_cmplt_ps(v13, (__m128)xmmword_3EB1D0), v12));
        v15 = _mm_and_ps(v10, (__m128)xmmword_3E5B40);
        v16 = _mm_and_ps(_mm_and_ps(_mm_cmpeq_ps(v15, (__m128)xmmword_3EB1D0), v10), *(__m128 *)&stru_3E4970.x);
        v9 = _mm_and_ps(_mm_cmpneq_ps(v15, (__m128)xmmword_3EB1D0), v14);
        if ( !(_BYTE)byte_29FEDE8 )
        {
          v106 = v9;
          v8 = __cxa_guard_acquire(&byte_29FEDE8);
          v9 = v106;
          if ( v8 )
          {
            *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
            *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
            __cxa_guard_release(&byte_29FEDE8);
            v9 = v106;
          }
        }
        v17 = _mm_or_ps(v16, v9);
        if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
        {
          qword_29FEE08 = 0x8000000080000000LL;
          dword_29FEE10 = 0x80000000;
          __cxa_guard_release(&byte_29FEE18);
        }
        y_low = (__m128)LODWORD(extents->low.y);
        z_low = (__m128)LODWORD(extents->low.z);
        v20 = _mm_mul_ps(
                _mm_min_ps(
                  (__m128)xmmword_3E8210,
                  _mm_max_ps(
                    (__m128)xmmword_3E5450,
                    _mm_unpacklo_ps(_mm_unpacklo_ps((__m128)LODWORD(extents->low.x), z_low), y_low))),
                v17);
        v21 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v20));
        v22 = _mm_cvttps_epi32(_mm_sub_ps(v21, _mm_and_ps(_mm_cmplt_ps(v20, v21), (__m128)stru_3E5460)));
        v23 = _mm_cvtsi128_si32(v22);
        v24 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v22, 229));
        v88 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v22, 78));
        x = extents->high.x;
        v26 = (__m128)LODWORD(extents->high.y);
        v27 = (__m128)LODWORD(extents->high.z);
        v28 = _mm_mul_ps(
                _mm_min_ps(
                  (__m128)xmmword_3E8210,
                  _mm_max_ps((__m128)xmmword_3E5450, _mm_unpacklo_ps(_mm_unpacklo_ps((__m128)LODWORD(x), v27), v26))),
                v17);
        v29 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v28));
        v30 = _mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v29, v28), (__m128)stru_3E5460), v29));
        v31 = _mm_cvtsi128_si32(v30);
        v32 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v30, 229));
        v33 = (float)(1 << dword_2868B08 << v7);
        v89 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v30, 78));
        v34 = (float)v23 * v33;
        v90 = 0;
        if ( v34 >= extents->low.x )
        {
          v35 = (float)v24 * v33;
          if ( v35 >= y_low.m128_f32[0] )
          {
            v90 = 0;
            if ( v26.m128_f32[0] >= v35 && x >= v34 )
            {
              v36 = (float)v88 * v33;
              if ( v36 >= z_low.m128_f32[0] )
              {
                v37 = (float)v32 * v33;
                v90 = 0;
                if ( v37 >= y_low.m128_f32[0] )
                {
                  v38 = (float)v31 * v33;
                  if ( v38 >= extents->low.x && v27.m128_f32[0] >= v36 )
                    v90 = (float)((float)v89 * v33) >= z_low.m128_f32[0]
                       && x >= v38
                       && v26.m128_f32[0] >= v37
                       && v27.m128_f32[0] >= (float)((float)v89 * v33);
                }
              }
            }
          }
        }
        if ( v23 < v31 )
        {
          v108 = v6;
          v107 = v7;
          v91 = v24;
          v102 = v31;
          v104 = v32;
          do
          {
            if ( v24 < v32 )
            {
              v103 = 73856093 * v23;
              v39 = v91;
              v94 = v23;
              do
              {
                if ( v88 < v89 )
                {
                  v105 = v103 ^ (19349663 * v39);
                  v40 = v88;
                  v95 = v39;
                  do
                  {
                    v78 = (v105 ^ (83492791 * v40)) & (unsigned int)(*(_DWORD *)(v100 + 8) - 1);
                    v79 = *(unsigned __int8 *)(*(_QWORD *)v100 + v78);
                    if ( *(_BYTE *)(*(_QWORD *)v100 + v78) )
                    {
                      v80 = 16 * v78;
                      v81 = *(_QWORD *)(v100 + 32);
                      v82 = (_DWORD *)(*(_QWORD *)(v81 + v80) + 8LL);
                      v83 = 24;
                      v84 = 8;
                      v85 = 0;
                      while ( *(v82 - 2) != v23 || *(v82 - 1) != v39 || *v82 != v40 )
                      {
                        ++v85;
                        v84 += 32;
                        v83 += 32;
                        v82 += 3;
                        if ( v85 >= v79 )
                          goto LABEL_89;
                      }
                      v41 = *(_QWORD *)(v81 + v80 + 8);
                      v42 = *(unsigned int *)(v41 + v83 - 8);
                      if ( v42 >= 2 )
                      {
                        v93 = v40;
                        v44 = *(RBX::Primitive ***)(v41 + v83);
                        v106.m128_u64[0] = (unsigned __int64)&v44[v42];
                        do
                        {
LABEL_37:
                          v45 = *v44;
                          if ( v90 )
                            goto LABEL_96;
                          FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(v45);
                          isNanInfVector3 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->low);
                          v52 = (float *)&byte_29FC388[20];
                          v53 = (float *)&byte_29FC388[16];
                          p_x = (float *)&byte_29FC388[12];
                          p_z = (float *)&byte_29FC388[8];
                          p_y = (float *)&byte_29FC388[4];
                          v57 = (float *)byte_29FC388;
                          if ( !isNanInfVector3 )
                          {
                            v58 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->high);
                            v52 = (float *)&byte_29FC388[20];
                            v53 = (float *)&byte_29FC388[16];
                            p_x = (float *)&byte_29FC388[12];
                            p_z = (float *)&byte_29FC388[8];
                            p_y = (float *)&byte_29FC388[4];
                            v57 = (float *)byte_29FC388;
                            if ( !v58 )
                            {
                              p_y = &FastFuzzyExtents->low.y;
                              p_z = &FastFuzzyExtents->low.z;
                              v53 = &FastFuzzyExtents->high.y;
                              v52 = &FastFuzzyExtents->high.z;
                              p_x = &FastFuzzyExtents->high.x;
                              v57 = &FastFuzzyExtents->low.x;
                            }
                          }
                          if ( extents->low.x <= *p_x
                            && extents->low.y <= *v53
                            && extents->low.z <= *v52
                            && *p_y <= extents->high.y
                            && *v57 <= extents->high.x
                            && *p_z <= extents->high.z )
                          {
LABEL_96:
                            args = v45;
                            if ( ignoreSet->table_.size_ )
                            {
                              v46 = 2147483649u
                                  * ((21
                                    * ((265
                                      * ((~((unsigned __int64)v45 + ((unsigned __int64)v45 >> 3))
                                        + (((_QWORD)v45 + ((unsigned __int64)v45 >> 3)) << 21))
                                       ^ ((~((unsigned __int64)v45 + ((unsigned __int64)v45 >> 3))
                                         + (((_QWORD)v45 + ((unsigned __int64)v45 >> 3)) << 21)) >> 24)))
                                     ^ ((265
                                       * ((~((unsigned __int64)v45 + ((unsigned __int64)v45 >> 3))
                                         + (((_QWORD)v45 + ((unsigned __int64)v45 >> 3)) << 21))
                                        ^ ((~((unsigned __int64)v45 + ((unsigned __int64)v45 >> 3))
                                          + (((_QWORD)v45 + ((unsigned __int64)v45 >> 3)) << 21)) >> 24))) >> 14)))
                                   ^ ((21
                                     * ((265
                                       * ((~((unsigned __int64)v45 + ((unsigned __int64)v45 >> 3))
                                         + (((_QWORD)v45 + ((unsigned __int64)v45 >> 3)) << 21))
                                        ^ ((~((unsigned __int64)v45 + ((unsigned __int64)v45 >> 3))
                                          + (((_QWORD)v45 + ((unsigned __int64)v45 >> 3)) << 21)) >> 24)))
                                      ^ ((265
                                        * ((~((unsigned __int64)v45 + ((unsigned __int64)v45 >> 3))
                                          + (((_QWORD)v45 + ((unsigned __int64)v45 >> 3)) << 21))
                                         ^ ((~((unsigned __int64)v45 + ((unsigned __int64)v45 >> 3))
                                           + (((_QWORD)v45 + ((unsigned __int64)v45 >> 3)) << 21)) >> 24))) >> 14))) >> 28));
                              v47 = v46 & (ignoreSet->table_.bucket_count_ - 1);
                              next = ignoreSet->table_.buckets_[v47].next_;
                              if ( next )
                              {
                                while ( 1 )
                                {
                                  next = next->next_;
                                  if ( !next )
                                    break;
                                  v49 = next[1].next_;
                                  if ( v49 == (boost::unordered::detail::ptr_bucket::link_pointer)v46 )
                                  {
                                    if ( (RBX::Primitive *)next[2].next_ == v45 )
                                    {
                                      if ( ignoreIsWhitelist )
                                        goto LABEL_46;
                                      goto LABEL_52;
                                    }
                                  }
                                  else if ( ((ignoreSet->table_.bucket_count_ - 1) & (unsigned __int64)v49) != v47 )
                                  {
                                    break;
                                  }
                                }
                              }
                            }
                            if ( !ignoreIsWhitelist )
                            {
LABEL_46:
                              boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive *>,RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>>::emplace_impl<RBX::Primitive * const&>(
                                &answer->table_,
                                &args,
                                &args);
                              if ( v99 < answer->table_.size_ )
                                goto LABEL_93;
                            }
                          }
LABEL_52:
                          ++v44;
                        }
                        while ( v44 != (RBX::Primitive **)v106.m128_u64[0] );
                        v41 = *(_QWORD *)(*(_QWORD *)(v100 + 32) + v80 + 8);
                        v23 = v94;
                        v39 = v95;
                        v40 = v93;
                      }
                      else if ( (_DWORD)v42 )
                      {
                        v93 = v40;
                        v43 = v41 + 8 * v42;
                        v44 = (RBX::Primitive **)(v83 + v41);
                        v106.m128_u64[0] = v83 + v43;
                        goto LABEL_37;
                      }
                      v59 = *(unsigned int *)(v41 + v84 - 8);
                      if ( v59 >= 2 )
                      {
                        v61 = *(RBX::Primitive ***)(v41 + v84);
                        v62 = &v61[v59];
                        do
                        {
LABEL_66:
                          v63 = v40;
                          v64 = *v61;
                          if ( v90 )
                            goto LABEL_97;
                          v69 = RBX::Primitive::getFastFuzzyExtents(v64);
                          v70 = RBX::Math::isNanInfVector3(&v69->low);
                          v71 = (float *)&byte_29FC388[20];
                          v72 = (float *)&byte_29FC388[16];
                          v73 = (float *)&byte_29FC388[12];
                          v74 = (float *)&byte_29FC388[8];
                          v75 = (float *)&byte_29FC388[4];
                          v76 = (float *)byte_29FC388;
                          if ( !v70 )
                          {
                            v77 = RBX::Math::isNanInfVector3(&v69->high);
                            v71 = (float *)&byte_29FC388[20];
                            v72 = (float *)&byte_29FC388[16];
                            v73 = (float *)&byte_29FC388[12];
                            v74 = (float *)&byte_29FC388[8];
                            v75 = (float *)&byte_29FC388[4];
                            v76 = (float *)byte_29FC388;
                            if ( !v77 )
                            {
                              v75 = &v69->low.y;
                              v74 = &v69->low.z;
                              v72 = &v69->high.y;
                              v71 = &v69->high.z;
                              v73 = &v69->high.x;
                              v76 = &v69->low.x;
                            }
                          }
                          if ( extents->low.x <= *v73
                            && extents->low.y <= *v72
                            && extents->low.z <= *v71
                            && *v75 <= extents->high.y
                            && *v76 <= extents->high.x
                            && *v74 <= extents->high.z )
                          {
LABEL_97:
                            args = v64;
                            if ( ignoreSet->table_.size_ )
                            {
                              v65 = 2147483649u
                                  * ((21
                                    * ((265
                                      * ((~((unsigned __int64)v64 + ((unsigned __int64)v64 >> 3))
                                        + (((_QWORD)v64 + ((unsigned __int64)v64 >> 3)) << 21))
                                       ^ ((~((unsigned __int64)v64 + ((unsigned __int64)v64 >> 3))
                                         + (((_QWORD)v64 + ((unsigned __int64)v64 >> 3)) << 21)) >> 24)))
                                     ^ ((265
                                       * ((~((unsigned __int64)v64 + ((unsigned __int64)v64 >> 3))
                                         + (((_QWORD)v64 + ((unsigned __int64)v64 >> 3)) << 21))
                                        ^ ((~((unsigned __int64)v64 + ((unsigned __int64)v64 >> 3))
                                          + (((_QWORD)v64 + ((unsigned __int64)v64 >> 3)) << 21)) >> 24))) >> 14)))
                                   ^ ((21
                                     * ((265
                                       * ((~((unsigned __int64)v64 + ((unsigned __int64)v64 >> 3))
                                         + (((_QWORD)v64 + ((unsigned __int64)v64 >> 3)) << 21))
                                        ^ ((~((unsigned __int64)v64 + ((unsigned __int64)v64 >> 3))
                                          + (((_QWORD)v64 + ((unsigned __int64)v64 >> 3)) << 21)) >> 24)))
                                      ^ ((265
                                        * ((~((unsigned __int64)v64 + ((unsigned __int64)v64 >> 3))
                                          + (((_QWORD)v64 + ((unsigned __int64)v64 >> 3)) << 21))
                                         ^ ((~((unsigned __int64)v64 + ((unsigned __int64)v64 >> 3))
                                           + (((_QWORD)v64 + ((unsigned __int64)v64 >> 3)) << 21)) >> 24))) >> 14))) >> 28));
                              v66 = v65 & (ignoreSet->table_.bucket_count_ - 1);
                              v67 = ignoreSet->table_.buckets_[v66].next_;
                              if ( v67 )
                              {
                                while ( 1 )
                                {
                                  v67 = v67->next_;
                                  if ( !v67 )
                                    break;
                                  v68 = v67[1].next_;
                                  if ( v68 == (boost::unordered::detail::ptr_bucket::link_pointer)v65 )
                                  {
                                    if ( (RBX::Primitive *)v67[2].next_ == v64 )
                                    {
                                      if ( ignoreIsWhitelist )
                                        goto LABEL_75;
                                      goto LABEL_81;
                                    }
                                  }
                                  else if ( ((ignoreSet->table_.bucket_count_ - 1) & (unsigned __int64)v68) != v66 )
                                  {
                                    break;
                                  }
                                }
                              }
                            }
                            if ( !ignoreIsWhitelist )
                            {
LABEL_75:
                              boost::unordered::detail::table_impl<boost::unordered::detail::set<std::allocator<RBX::Primitive *>,RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>>::emplace_impl<RBX::Primitive * const&>(
                                &answer->table_,
                                &args,
                                &args);
                              if ( v99 < answer->table_.size_ )
                                goto LABEL_93;
                            }
                          }
LABEL_81:
                          ++v61;
                          v23 = v94;
                          v39 = v95;
                          v40 = v63;
                        }
                        while ( v61 != v62 );
                      }
                      else if ( (_DWORD)v59 )
                      {
                        v60 = v41 + 8 * v59;
                        v61 = (RBX::Primitive **)(v84 + v41);
                        v62 = (RBX::Primitive **)(v84 + v60);
                        goto LABEL_66;
                      }
                    }
LABEL_89:
                    ++v40;
                  }
                  while ( v40 < v89 );
                }
                ++v39;
                v32 = v104;
              }
              while ( v39 < v104 );
            }
            ++v23;
            v6 = v108;
            v7 = v107;
            v24 = v91;
          }
          while ( v23 < v102 );
        }
      }
      ++v7;
    }
    while ( v7 < v6[1] );
  }
LABEL_93:
  RBX::Memory::setCurrentCategory(category);
}


// Address: 0x1dfbcf0 | Name: _ZN3RBX9Collision23SpatialHashHierarchical24getPrimitivesOverlappingERKNS_7ExtentsERNS_12DenseHashSetIPNS_9PrimitiveEN5boost4hashIS7_EENSt3__18equal_toIS7_EEEE
void __fastcall RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlapping(
        RBX::Collision::SpatialHashHierarchical *this,
        const RBX::Extents *extents,
        RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > *answer)
{
  _QWORD *v3; // rax
  RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > *v4; // r12
  __int64 v5; // rcx
  __m128 v6; // xmm0
  __m128 v7; // xmm1
  __m128 v8; // xmm3
  __m128 v9; // xmm2
  __m128 v10; // xmm4
  __m128 v11; // xmm1
  __m128 v12; // xmm2
  __m128 v13; // xmm1
  __m128 v14; // xmm2
  __m128 y_low; // xmm10
  __m128 z_low; // xmm8
  __m128 v17; // xmm0
  __m128 v18; // xmm3
  __m128i v19; // xmm0
  int v20; // r9d
  int v21; // edx
  float x; // xmm3_4
  __m128 v23; // xmm4
  __m128 v24; // xmm9
  __m128 v25; // xmm0
  __m128 v26; // xmm6
  __m128i v27; // xmm0
  float v28; // xmm6_4
  float v29; // xmm0_4
  float v30; // xmm7_4
  float v31; // xmm0_4
  float v32; // xmm7_4
  float v33; // xmm2_4
  int v34; // ebx
  int v35; // edx
  __int64 v36; // r15
  unsigned __int64 v37; // rcx
  __int64 v38; // r14
  RBX::Primitive **v39; // r15
  RBX::Primitive **v40; // r14
  RBX::Primitive *v41; // rbp
  __int64 v42; // rax
  __int64 v43; // rcx
  unsigned __int64 v44; // rcx
  __int64 v45; // rdx
  __int64 v46; // rdi
  __int64 v47; // rdx
  RBX::Primitive *v48; // rbx
  const RBX::Extents *v49; // r12
  bool v50; // al
  float *v51; // rdx
  float *v52; // rdi
  float *v53; // rcx
  float *v54; // r8
  float *v55; // rsi
  float *v56; // rbx
  bool v57; // al
  unsigned __int64 v58; // rax
  __int64 v59; // r14
  RBX::Primitive **v60; // r15
  RBX::Primitive **v61; // r14
  int v62; // r13d
  RBX::Primitive *v63; // rbp
  __int64 v64; // rax
  __int64 v65; // rcx
  unsigned __int64 v66; // rcx
  __int64 v67; // rdx
  __int64 v68; // rdi
  __int64 v69; // rdx
  RBX::Primitive *v70; // rbx
  const RBX::Extents *FastFuzzyExtents; // rbx
  bool isNanInfVector3; // al
  float *v73; // rdx
  float *v74; // rdi
  float *p_x; // rsi
  float *p_z; // r8
  float *p_y; // r9
  float *v78; // rcx
  bool v79; // al
  __int64 v80; // rbp
  unsigned __int64 v81; // rcx
  __int64 v82; // rbp
  __int64 v83; // r8
  _DWORD *v84; // rsi
  __int64 v85; // rax
  __int64 v86; // r13
  unsigned __int64 v87; // rdi
  int v89; // [rsp+10h] [rbp-A8h]
  int v90; // [rsp+14h] [rbp-A4h]
  int v91; // [rsp+18h] [rbp-A0h]
  int v92; // [rsp+1Ch] [rbp-9Ch]
  bool v93; // [rsp+20h] [rbp-98h]
  int v94; // [rsp+34h] [rbp-84h]
  int v95; // [rsp+38h] [rbp-80h]
  int v96; // [rsp+3Ch] [rbp-7Ch]
  __int64 v97; // [rsp+40h] [rbp-78h]
  int v98; // [rsp+48h] [rbp-70h]
  int v99; // [rsp+4Ch] [rbp-6Ch]
  int v100; // [rsp+50h] [rbp-68h]
  __int64 v101; // [rsp+60h] [rbp-58h]
  _QWORD *v103; // [rsp+70h] [rbp-48h]
  __int64 v104; // [rsp+78h] [rbp-40h]
  RBX::Primitive **v105; // [rsp+80h] [rbp-38h]

  v3 = (_QWORD *)*((_QWORD *)this + 8);
  if ( v3[1] )
  {
    v4 = answer;
    v5 = 0;
    v103 = (_QWORD *)*((_QWORD *)this + 8);
    while ( 1 )
    {
      v101 = v5;
      v97 = *(_QWORD *)(*v3 + 8 * v5);
      if ( *(_QWORD *)(v97 + 200) )
      {
        v6 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << v5), 0));
        v7 = _mm_rcp_ps(v6);
        v8 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v7, v6)), v7);
        v9 = _mm_and_ps(v8, (__m128)xmmword_3E5B40);
        v10 = _mm_or_ps(
                _mm_and_ps(_mm_cmpnlt_ps(v9, (__m128)xmmword_3EB1D0), v7),
                _mm_and_ps(_mm_cmplt_ps(v9, (__m128)xmmword_3EB1D0), v8));
        v11 = _mm_and_ps(v6, (__m128)xmmword_3E5B40);
        v12 = _mm_and_ps(_mm_and_ps(_mm_cmpeq_ps(v11, (__m128)xmmword_3EB1D0), v6), *(__m128 *)&stru_3E4970.x);
        v13 = _mm_and_ps(_mm_cmpneq_ps(v11, (__m128)xmmword_3EB1D0), v10);
        if ( !(_BYTE)byte_29FEDE8 && __cxa_guard_acquire(&byte_29FEDE8) )
        {
          *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
          *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
          __cxa_guard_release(&byte_29FEDE8);
        }
        v14 = _mm_or_ps(v12, v13);
        if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
        {
          qword_29FEE08 = 0x8000000080000000LL;
          dword_29FEE10 = 0x80000000;
          __cxa_guard_release(&byte_29FEE18);
        }
        y_low = (__m128)LODWORD(extents->low.y);
        z_low = (__m128)LODWORD(extents->low.z);
        v17 = _mm_mul_ps(
                _mm_min_ps(
                  (__m128)xmmword_3E8210,
                  _mm_max_ps(
                    (__m128)xmmword_3E5450,
                    _mm_unpacklo_ps(_mm_unpacklo_ps((__m128)LODWORD(extents->low.x), z_low), y_low))),
                v14);
        v18 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v17));
        v19 = _mm_cvttps_epi32(_mm_sub_ps(v18, _mm_and_ps(_mm_cmplt_ps(v17, v18), (__m128)stru_3E5460)));
        v20 = _mm_cvtsi128_si32(v19);
        v21 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v19, 229));
        v91 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v19, 78));
        x = extents->high.x;
        v23 = (__m128)LODWORD(extents->high.y);
        v24 = (__m128)LODWORD(extents->high.z);
        v25 = _mm_mul_ps(
                _mm_min_ps(
                  (__m128)xmmword_3E8210,
                  _mm_max_ps((__m128)xmmword_3E5450, _mm_unpacklo_ps(_mm_unpacklo_ps((__m128)LODWORD(x), v24), v23))),
                v14);
        v26 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v25));
        v27 = _mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v26, v25), (__m128)stru_3E5460), v26));
        v89 = _mm_cvtsi128_si32(v27);
        v90 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v27, 229));
        v28 = (float)(1 << dword_2868B08 << v101);
        v92 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v27, 78));
        v29 = (float)v20 * v28;
        v93 = 0;
        if ( v29 >= extents->low.x )
        {
          v30 = (float)v21 * v28;
          if ( v30 >= y_low.m128_f32[0] )
          {
            v93 = 0;
            if ( v23.m128_f32[0] >= v30 && x >= v29 )
            {
              v31 = (float)v91 * v28;
              if ( v31 >= z_low.m128_f32[0] )
              {
                v32 = (float)v90 * v28;
                v93 = 0;
                if ( v32 >= y_low.m128_f32[0] )
                {
                  v33 = (float)v89 * v28;
                  if ( v33 >= extents->low.x && v24.m128_f32[0] >= v31 )
                    v93 = (float)((float)v92 * v28) >= z_low.m128_f32[0]
                       && x >= v33
                       && v23.m128_f32[0] >= v32
                       && v24.m128_f32[0] >= (float)((float)v92 * v28);
                }
              }
            }
          }
        }
        if ( v20 < v89 )
          break;
      }
LABEL_85:
      v5 = v101 + 1;
      v3 = v103;
      if ( (unsigned __int64)(v101 + 1) >= v103[1] )
        return;
    }
    v94 = v21;
    while ( v21 >= v90 )
    {
LABEL_84:
      ++v20;
      v21 = v94;
      if ( v20 == v89 )
        goto LABEL_85;
    }
    v98 = 73856093 * v20;
    v34 = v94;
    v96 = v20;
    while ( v91 >= v92 )
    {
LABEL_83:
      if ( ++v34 == v90 )
        goto LABEL_84;
    }
    v99 = v98 ^ (19349663 * v34);
    v35 = v91;
    v100 = v34;
    while ( 1 )
    {
      v80 = (v99 ^ (83492791 * v35)) & (unsigned int)(*(_DWORD *)(v97 + 8) - 1);
      v81 = *(unsigned __int8 *)(*(_QWORD *)v97 + v80);
      if ( !*(_BYTE *)(*(_QWORD *)v97 + v80) )
        goto LABEL_82;
      v82 = 16 * v80;
      v83 = *(_QWORD *)(v97 + 32);
      v84 = (_DWORD *)(*(_QWORD *)(v83 + v82) + 8LL);
      v85 = 24;
      v86 = 8;
      v87 = 0;
      while ( *(v84 - 2) != v20 || *(v84 - 1) != v34 || *v84 != v35 )
      {
        ++v87;
        v86 += 32;
        v85 += 32;
        v84 += 3;
        if ( v87 >= v81 )
          goto LABEL_82;
      }
      v104 = v82;
      v36 = *(_QWORD *)(v83 + v82 + 8);
      v37 = *(unsigned int *)(v36 + v85 - 8);
      if ( v37 >= 2 )
        break;
      if ( (_DWORD)v37 )
      {
        v95 = v35;
        v38 = v36 + 8 * v37;
        v39 = (RBX::Primitive **)(v85 + v36);
        v40 = (RBX::Primitive **)(v85 + v38);
        goto LABEL_29;
      }
LABEL_51:
      v58 = *(unsigned int *)(v36 + v86 - 8);
      if ( v58 >= 2 )
      {
        v60 = *(RBX::Primitive ***)(v36 + v86);
        v61 = &v60[v58];
        goto LABEL_55;
      }
      if ( (_DWORD)v58 )
      {
        v59 = v36 + 8 * v58;
        v60 = (RBX::Primitive **)(v86 + v36);
        v61 = (RBX::Primitive **)(v86 + v59);
        do
        {
LABEL_55:
          v62 = v35;
          v63 = *v60;
          if ( v93 )
            goto LABEL_56;
          FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(v63);
          isNanInfVector3 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->low);
          v73 = (float *)&byte_29FC388[20];
          v74 = (float *)&byte_29FC388[16];
          p_x = (float *)&byte_29FC388[12];
          p_z = (float *)&byte_29FC388[8];
          p_y = (float *)&byte_29FC388[4];
          v78 = (float *)byte_29FC388;
          if ( !isNanInfVector3 )
          {
            v79 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->high);
            v73 = (float *)&byte_29FC388[20];
            v74 = (float *)&byte_29FC388[16];
            p_x = (float *)&byte_29FC388[12];
            p_z = (float *)&byte_29FC388[8];
            p_y = (float *)&byte_29FC388[4];
            v78 = (float *)byte_29FC388;
            if ( !v79 )
            {
              p_y = &FastFuzzyExtents->low.y;
              p_z = &FastFuzzyExtents->low.z;
              v74 = &FastFuzzyExtents->high.y;
              v73 = &FastFuzzyExtents->high.z;
              p_x = &FastFuzzyExtents->high.x;
              v78 = &FastFuzzyExtents->low.x;
            }
          }
          v4 = answer;
          if ( extents->low.x <= *p_x
            && extents->low.y <= *v74
            && extents->low.z <= *v73
            && *p_y <= extents->high.y
            && *v78 <= extents->high.x
            && *p_z <= extents->high.z )
          {
LABEL_56:
            v64 = *(_QWORD *)v4;
            v65 = (__int64)(*((_QWORD *)v4 + 1) - *(_QWORD *)v4) >> 3;
            if ( *((_QWORD *)v4 + 3) >= (unsigned __int64)(3 * v65) >> 2 )
            {
              RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>::rehash(v4);
              v64 = *(_QWORD *)v4;
              v65 = (__int64)(*((_QWORD *)v4 + 1) - *(_QWORD *)v4) >> 3;
            }
            v66 = v65 - 1;
            v67 = (__int64)v63 + ((unsigned __int64)v63 >> 3);
            v68 = 0;
            while ( 1 )
            {
              v69 = v66 & v67;
              v70 = *(RBX::Primitive **)(v64 + 8 * v69);
              if ( v70 == *((RBX::Primitive **)v4 + 4) )
                break;
              if ( v70 != v63 )
              {
                v67 = v68 + v69 + 1;
                if ( ++v68 <= v66 )
                  continue;
              }
              goto LABEL_74;
            }
            *(_QWORD *)(v64 + 8 * v69) = v63;
            ++*((_QWORD *)v4 + 3);
          }
LABEL_74:
          ++v60;
          v20 = v96;
          v34 = v100;
          v35 = v62;
        }
        while ( v60 != v61 );
      }
LABEL_82:
      if ( ++v35 == v92 )
        goto LABEL_83;
    }
    v95 = v35;
    v39 = *(RBX::Primitive ***)(v36 + v85);
    v40 = &v39[v37];
LABEL_29:
    v105 = v40;
    do
    {
      v41 = *v39;
      if ( v93 )
        goto LABEL_31;
      v49 = RBX::Primitive::getFastFuzzyExtents(v41);
      v50 = RBX::Math::isNanInfVector3(&v49->low);
      v51 = (float *)&byte_29FC388[20];
      v52 = (float *)&byte_29FC388[16];
      v53 = (float *)&byte_29FC388[12];
      v54 = (float *)&byte_29FC388[8];
      v55 = (float *)&byte_29FC388[4];
      v56 = (float *)byte_29FC388;
      if ( !v50 )
      {
        v57 = RBX::Math::isNanInfVector3(&v49->high);
        v51 = (float *)&byte_29FC388[20];
        v52 = (float *)&byte_29FC388[16];
        v53 = (float *)&byte_29FC388[12];
        v54 = (float *)&byte_29FC388[8];
        v55 = (float *)&byte_29FC388[4];
        v56 = (float *)byte_29FC388;
        if ( !v57 )
        {
          v55 = &v49->low.y;
          v54 = &v49->low.z;
          v52 = &v49->high.y;
          v51 = &v49->high.z;
          v53 = &v49->high.x;
          v56 = &v49->low.x;
        }
      }
      v4 = answer;
      v40 = v105;
      if ( extents->low.x <= *v53
        && extents->low.y <= *v52
        && extents->low.z <= *v51
        && *v55 <= extents->high.y
        && *v56 <= extents->high.x
        && *v54 <= extents->high.z )
      {
LABEL_31:
        v42 = *(_QWORD *)v4;
        v43 = (__int64)(*((_QWORD *)v4 + 1) - *(_QWORD *)v4) >> 3;
        if ( *((_QWORD *)v4 + 3) >= (unsigned __int64)(3 * v43) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>::rehash(v4);
          v42 = *(_QWORD *)v4;
          v43 = (__int64)(*((_QWORD *)v4 + 1) - *(_QWORD *)v4) >> 3;
        }
        v44 = v43 - 1;
        v45 = (__int64)v41 + ((unsigned __int64)v41 >> 3);
        v46 = 0;
        while ( 1 )
        {
          v47 = v44 & v45;
          v48 = *(RBX::Primitive **)(v42 + 8 * v47);
          if ( v48 == *((RBX::Primitive **)v4 + 4) )
            break;
          if ( v48 != v41 )
          {
            v45 = v46 + v47 + 1;
            if ( ++v46 <= v44 )
              continue;
          }
          goto LABEL_49;
        }
        *(_QWORD *)(v42 + 8 * v47) = v41;
        ++*((_QWORD *)v4 + 3);
      }
LABEL_49:
      ++v39;
    }
    while ( v39 != v40 );
    v36 = *(_QWORD *)(*(_QWORD *)(v97 + 32) + v104 + 8);
    v20 = v96;
    v34 = v100;
    v35 = v95;
    goto LABEL_51;
  }
}


// Address: 0x1dfc590 | Name: _ZN3RBX9Collision23SpatialHashHierarchical27getPrimitivesOverlappingRecERKNS_7ExtentsERNS_12DenseHashSetIPNS_9PrimitiveEN5boost4hashIS7_EENSt3__18equal_toIS7_EEEE
void __fastcall RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlappingRec(
        RBX::Collision::SpatialHashHierarchical *this,
        const RBX::Extents *extents,
        RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > *answer)
{
  int v3; // r9d
  _QWORD *v4; // rbp
  __m128 v5; // xmm1
  float v6; // xmm0_4
  int v7; // eax
  unsigned __int64 v8; // rsi
  __int64 v9; // rcx
  __int64 v10; // rbx
  __m128 v11; // xmm0
  __m128 v12; // xmm1
  __m128 v13; // xmm3
  __m128 v14; // xmm2
  __m128 v15; // xmm6
  __m128 v16; // xmm7
  __m128 v17; // xmm6
  __m128 v18; // xmm7
  __m128 v19; // xmm7
  __m128 v20; // xmm0
  __m128 v21; // xmm2
  __m128i v22; // xmm0
  int v23; // ebp
  __m128 v24; // xmm3
  __m128 v25; // xmm1
  __m128i v26; // xmm1
  int v27; // r12d
  int v28; // r13d
  int v29; // r14d
  int v30; // r15d
  float v31; // xmm0_4
  __int64 v32; // rax
  _DWORD *v33; // rsi
  unsigned __int64 v34; // rcx
  RBX::Collision::GridHierarchy *v35; // rax
  size_t v36; // rcx
  unsigned int *v37; // r13
  __m128 v38; // xmm0
  __m128 v39; // xmm1
  __m128 v40; // xmm3
  __m128 v41; // xmm2
  __m128 v42; // xmm4
  __m128 v43; // xmm1
  __m128 v44; // xmm7
  __m128 v45; // xmm1
  __m128 v46; // xmm7
  __m128 v47; // xmm0
  __m128 v48; // xmm1
  __m128i v49; // xmm0
  int v50; // ebp
  __m128 v51; // xmm1
  __m128 v52; // xmm2
  __m128i v53; // xmm1
  int v54; // ebx
  int v55; // edx
  __int64 v56; // r14
  unsigned __int64 v57; // rcx
  __int64 v58; // rcx
  RBX::Primitive **v59; // r14
  RBX::Primitive *v60; // rbp
  const RBX::Extents *v61; // r13
  bool v62; // al
  float *v63; // r8
  float *v64; // rsi
  float *v65; // rbx
  float *v66; // rcx
  float *v67; // rdx
  float *v68; // rdi
  bool v69; // al
  __int64 v70; // rax
  __int64 v71; // rcx
  unsigned __int64 v72; // rcx
  __int64 v73; // rdx
  __int64 v74; // rdi
  __int64 v75; // rdx
  RBX::Primitive *v76; // rbx
  unsigned __int64 v77; // rax
  __int64 v78; // r15
  RBX::Primitive **v79; // r14
  RBX::Primitive **v80; // r15
  int v81; // r12d
  RBX::Primitive *v82; // rbp
  const RBX::Extents *FastFuzzyExtents; // rbx
  bool isNanInfVector3; // al
  float *v85; // r8
  float *v86; // rsi
  float *p_x; // rcx
  float *p_z; // rdx
  float *p_y; // r9
  float *v90; // rdi
  bool v91; // al
  __int64 v92; // rax
  __int64 v93; // rcx
  unsigned __int64 v94; // rcx
  __int64 v95; // rdx
  __int64 v96; // rdi
  __int64 v97; // rdx
  RBX::Primitive *v98; // rbx
  __int64 v99; // r9
  unsigned __int64 v100; // rcx
  __int64 v101; // r9
  __int64 v102; // r8
  _DWORD *v103; // rsi
  __int64 v104; // rax
  __int64 v105; // r12
  unsigned __int64 v106; // rdi
  __m256i v107; // [rsp+0h] [rbp-E8h]
  int v108; // [rsp+8h] [rbp-E0h]
  int v109; // [rsp+Ch] [rbp-DCh]
  int v110; // [rsp+10h] [rbp-D8h]
  int v111; // [rsp+20h] [rbp-C8h]
  int v112; // [rsp+20h] [rbp-C8h]
  float v113; // [rsp+24h] [rbp-C4h]
  int v114; // [rsp+24h] [rbp-C4h]
  int v115; // [rsp+28h] [rbp-C0h]
  RBX::Extents *v116; // [rsp+28h] [rbp-C0h]
  signed int v117; // [rsp+30h] [rbp-B8h]
  int v118; // [rsp+30h] [rbp-B8h]
  float v119; // [rsp+34h] [rbp-B4h]
  int v120; // [rsp+34h] [rbp-B4h]
  RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > *results; // [rsp+38h] [rbp-B0h]
  RBX::Extents *v122; // [rsp+40h] [rbp-A8h]
  int v123; // [rsp+48h] [rbp-A0h]
  int v124; // [rsp+4Ch] [rbp-9Ch]
  float v125; // [rsp+50h] [rbp-98h]
  int v126; // [rsp+50h] [rbp-98h]
  size_t v127; // [rsp+60h] [rbp-88h]
  size_t v128; // [rsp+60h] [rbp-88h]
  RBX::Collision::GridHierarchy *v129; // [rsp+68h] [rbp-80h]
  int v130; // [rsp+70h] [rbp-78h]
  __int64 v131; // [rsp+70h] [rbp-78h]
  float v132; // [rsp+78h] [rbp-70h]
  RBX::Primitive **v133; // [rsp+78h] [rbp-70h]
  int v134; // [rsp+84h] [rbp-64h]
  char v135; // [rsp+88h] [rbp-60h] BYREF
  int v136; // [rsp+8Ch] [rbp-5Ch]
  char v137; // [rsp+90h] [rbp-58h]
  __int64 v138; // [rsp+98h] [rbp-50h]
  int level; // [rsp+A0h] [rbp-48h]
  int v140; // [rsp+A4h] [rbp-44h]
  char v141; // [rsp+A8h] [rbp-40h]
  __int64 v142; // [rsp+B0h] [rbp-38h]

  results = answer;
  v4 = (_QWORD *)*((_QWORD *)this + 8);
  v5 = _mm_sub_ps((__m128)*(unsigned __int64 *)&extents->high.x, (__m128)*(unsigned __int64 *)&extents->low.x);
  v122 = (RBX::Extents *)extents;
  v6 = fmaxf(extents->high.z - extents->low.z, fmaxf(_mm_shuffle_ps(v5, v5, 229).m128_f32[0], v5.m128_f32[0]));
  v7 = 1 << dword_2868B08;
  v8 = 0;
  do
    v9 = v8++;
  while ( v8 < v4[1] && (float)(v7 << v9) < v6 );
  v129 = (RBX::Collision::GridHierarchy *)*((_QWORD *)this + 8);
  v10 = *(_QWORD *)(*v4 + 8 * v9);
  v115 = v9;
  v127 = v9 + 1;
  if ( *(_QWORD *)(v10 + 200) )
  {
    v11 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(v7 << v9), 0));
    v12 = _mm_rcp_ps(v11);
    v13 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v11, v12)), v12);
    v14 = _mm_and_ps(v13, (__m128)xmmword_3E5B40);
    v15 = _mm_and_ps((__m128)xmmword_3E5B40, v11);
    v16 = _mm_and_ps(_mm_cmpeq_ps(v15, (__m128)xmmword_3EB1D0), v11);
    v17 = _mm_and_ps(
            _mm_cmpneq_ps(v15, (__m128)xmmword_3EB1D0),
            _mm_or_ps(
              _mm_and_ps(_mm_cmpnlt_ps(v14, (__m128)xmmword_3EB1D0), v12),
              _mm_and_ps(_mm_cmplt_ps(v14, (__m128)xmmword_3EB1D0), v13)));
    v18 = _mm_and_ps(v16, *(__m128 *)&stru_3E4970.x);
    if ( !(_BYTE)byte_29FEDE8 )
    {
      *(__m128 *)&v107.m256i_u64[2] = v18;
      if ( __cxa_guard_acquire(&byte_29FEDE8) )
      {
        *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
        *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
        __cxa_guard_release(&byte_29FEDE8);
      }
    }
    v19 = _mm_or_ps(v18, v17);
    if ( !(_BYTE)byte_29FEE18 )
    {
      *(__m128 *)&v107.m256i_u64[2] = v19;
      if ( __cxa_guard_acquire(&byte_29FEE18) )
      {
        qword_29FEE08 = 0x8000000080000000LL;
        dword_29FEE10 = 0x80000000;
        __cxa_guard_release(&byte_29FEE18);
      }
    }
    v20 = _mm_mul_ps(
            _mm_min_ps(
              (__m128)xmmword_3E8210,
              _mm_max_ps(
                (__m128)xmmword_3E5450,
                _mm_unpacklo_ps(
                  _mm_unpacklo_ps((__m128)LODWORD(v122->low.x), (__m128)LODWORD(v122->low.z)),
                  (__m128)LODWORD(v122->low.y)))),
            v19);
    v21 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v20));
    v22 = _mm_cvttps_epi32(_mm_sub_ps(v21, _mm_and_ps(_mm_cmplt_ps(v20, v21), (__m128)stru_3E5460)));
    v23 = _mm_cvtsi128_si32(v22);
    v24 = _mm_mul_ps(
            _mm_min_ps(
              (__m128)xmmword_3E8210,
              _mm_max_ps(
                (__m128)xmmword_3E5450,
                _mm_unpacklo_ps(
                  _mm_unpacklo_ps((__m128)LODWORD(v122->high.x), (__m128)LODWORD(v122->high.z)),
                  (__m128)LODWORD(v122->high.y)))),
            v19);
    v25 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v24));
    v26 = _mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v25, v24), (__m128)stru_3E5460), v25));
    v117 = _mm_cvtsi128_si32(v26);
    if ( v23 < v117 )
    {
      v107.m256i_i32[2] = _mm_cvtsi128_si32(_mm_shuffle_epi32(v22, 229));
      v130 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v22, 78));
      v107.m256i_i32[3] = _mm_cvtsi128_si32(_mm_shuffle_epi32(v26, 229));
      *(float *)&v107.m256i_i32[4] = (float)(1 << dword_2868B08 << v115);
      v27 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v26, 78));
      do
      {
        if ( v107.m256i_i32[2] < v107.m256i_i32[3] )
        {
          v111 = 73856093 * v23;
          v132 = (float)v23 * *(float *)&v107.m256i_i32[4];
          v119 = v132 + *(float *)&v107.m256i_i32[4];
          v28 = v107.m256i_i32[2];
          do
          {
            if ( v130 < v27 )
            {
              v29 = v111 ^ (19349663 * v28);
              v125 = (float)v28 * *(float *)&v107.m256i_i32[4];
              v113 = v125 + *(float *)&v107.m256i_i32[4];
              v30 = v130;
              do
              {
                v32 = (v29 ^ (83492791 * v30)) & (unsigned int)(*(_DWORD *)(v10 + 8) - 1);
                if ( *(_BYTE *)(*(_QWORD *)v10 + v32) )
                {
                  v33 = (_DWORD *)(*(_QWORD *)(*(_QWORD *)(v10 + 32) + 16 * v32) + 8LL);
                  v34 = 0;
                  while ( *(v33 - 2) != v23 || *(v33 - 1) != v28 || *v33 != v30 )
                  {
                    ++v34;
                    v33 += 3;
                    if ( v34 >= *(unsigned __int8 *)(*(_QWORD *)v10 + v32) )
                      goto LABEL_27;
                  }
                  if ( v132 < v122->low.x
                    || v125 < v122->low.y
                    || (v31 = (float)v30 * *(float *)&v107.m256i_i32[4], v31 < v122->low.z)
                    || v122->high.x < v119
                    || v122->high.y < v113
                    || v122->high.z < (float)(v31 + *(float *)&v107.m256i_i32[4]) )
                  {
                    v135 = 1;
                    v136 = v32;
                    v137 = v34;
                    v138 = v10;
                    RBX::Collision::GridHierarchy::getPrimitivesInBoxDepthFirstInternalDoOverlapTest<RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlappingRec(RBX::Extents const&,RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>> &)::$_9>(
                      (_DWORD)v129,
                      (_DWORD)results,
                      (_DWORD)v122,
                      v115,
                      (unsigned int)&v135,
                      v3,
                      *(RBX::Collision::CellIterator *)v107.m256i_i8,
                      v107.m256i_i32[6],
                      v111,
                      v115,
                      v117,
                      (_DWORD)results,
                      (uint32_t)v122,
                      v123,
                      LODWORD(v125));
                  }
                  else
                  {
                    LOBYTE(level) = 1;
                    v140 = v32;
                    v141 = v34;
                    v142 = v10;
                    RBX::Collision::GridHierarchy::getPrimitivesInBoxDepthFirstInternalSkipOverlapTest<RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlappingRec(RBX::Extents const&,RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>> &)::$_9>(*(RBX::Collision::CellIterator *)v107.m256i_i8);
                  }
                }
LABEL_27:
                ++v30;
              }
              while ( v30 != v27 );
            }
            ++v28;
          }
          while ( v28 != v107.m256i_i32[3] );
        }
        ++v23;
      }
      while ( v23 != v117 );
    }
  }
  v35 = v129;
  v36 = v127;
  v37 = (unsigned int *)v122;
  if ( v127 < v129->levels.mSize )
  {
    while ( 1 )
    {
      v128 = v36;
      v116 = (RBX::Extents *)v35->levels.mData[v36];
      if ( *(_QWORD *)&v116[8].low.z )
      {
        v38 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << v36), 0));
        v39 = _mm_rcp_ps(v38);
        v40 = _mm_mul_ps(_mm_sub_ps((__m128)xmmword_3E9290, _mm_mul_ps(v39, v38)), v39);
        v41 = _mm_and_ps(v40, (__m128)xmmword_3E5B40);
        v42 = _mm_or_ps(
                _mm_and_ps(_mm_cmpnlt_ps(v41, (__m128)xmmword_3EB1D0), v39),
                _mm_and_ps(_mm_cmplt_ps(v41, (__m128)xmmword_3EB1D0), v40));
        v43 = _mm_and_ps(v38, (__m128)xmmword_3E5B40);
        v44 = _mm_and_ps(_mm_and_ps(_mm_cmpeq_ps(v43, (__m128)xmmword_3EB1D0), v38), *(__m128 *)&stru_3E4970.x);
        v45 = _mm_and_ps(_mm_cmpneq_ps(v43, (__m128)xmmword_3EB1D0), v42);
        if ( !(_BYTE)byte_29FEDE8 && __cxa_guard_acquire(&byte_29FEDE8) )
        {
          *(_QWORD *)byte_29FEDD8 = 0x7FFFFFFF7FFFFFFFLL;
          *(_DWORD *)&byte_29FEDD8[8] = 0x7FFFFFFF;
          __cxa_guard_release(&byte_29FEDE8);
        }
        v46 = _mm_or_ps(v44, v45);
        if ( !(_BYTE)byte_29FEE18 && __cxa_guard_acquire(&byte_29FEE18) )
        {
          qword_29FEE08 = 0x8000000080000000LL;
          dword_29FEE10 = 0x80000000;
          __cxa_guard_release(&byte_29FEE18);
        }
        v47 = _mm_mul_ps(
                _mm_min_ps(
                  (__m128)xmmword_3E8210,
                  _mm_max_ps(
                    (__m128)xmmword_3E5450,
                    _mm_unpacklo_ps(_mm_unpacklo_ps((__m128)*v37, (__m128)v37[2]), (__m128)v37[1]))),
                v46);
        v48 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v47));
        v49 = _mm_cvttps_epi32(_mm_sub_ps(v48, _mm_and_ps(_mm_cmplt_ps(v47, v48), (__m128)stru_3E5460)));
        v50 = _mm_cvtsi128_si32(v49);
        v51 = _mm_mul_ps(
                _mm_min_ps(
                  (__m128)xmmword_3E8210,
                  _mm_max_ps(
                    (__m128)xmmword_3E5450,
                    _mm_unpacklo_ps(_mm_unpacklo_ps((__m128)v37[3], (__m128)v37[5]), (__m128)v37[4]))),
                v46);
        v52 = _mm_cvtepi32_ps(_mm_cvttps_epi32(v51));
        v53 = _mm_cvttps_epi32(_mm_add_ps(_mm_and_ps(_mm_cmplt_ps(v52, v51), (__m128)stru_3E5460), v52));
        v134 = _mm_cvtsi128_si32(v53);
        if ( v50 < v134 )
          break;
      }
LABEL_100:
      v36 = v128 + 1;
      v35 = v129;
      if ( v128 + 1 >= v129->levels.mSize )
        return;
    }
    v124 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v49, 229));
    v112 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v49, 78));
    v108 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v53, 229));
    v114 = _mm_cvtsi128_si32(_mm_shuffle_epi32(v53, 78));
    while ( v124 >= v108 )
    {
LABEL_99:
      if ( ++v50 == v134 )
        goto LABEL_100;
    }
    v118 = 73856093 * v50;
    v54 = v124;
    v126 = v50;
    while ( v112 >= v114 )
    {
LABEL_98:
      if ( ++v54 == v108 )
        goto LABEL_99;
    }
    v120 = v118 ^ (19349663 * v54);
    v55 = v112;
    v110 = v54;
    while ( 1 )
    {
      v99 = (v120 ^ (83492791 * v55)) & (unsigned int)(LODWORD(v116->low.z) - 1);
      v100 = *(unsigned __int8 *)(*(_QWORD *)&v116->low.x + v99);
      if ( !*(_BYTE *)(*(_QWORD *)&v116->low.x + v99) )
        goto LABEL_97;
      v101 = 16 * v99;
      v102 = *(_QWORD *)&v116[1].low.z;
      v103 = (_DWORD *)(*(_QWORD *)(v102 + v101) + 8LL);
      v104 = 24;
      v105 = 8;
      v106 = 0;
      while ( *(v103 - 2) != v50 || *(v103 - 1) != v54 || *v103 != v55 )
      {
        ++v106;
        v105 += 32;
        v104 += 32;
        v103 += 3;
        if ( v106 >= v100 )
          goto LABEL_97;
      }
      v131 = v101;
      v56 = *(_QWORD *)(v102 + v101 + 8);
      v57 = *(unsigned int *)(v56 + v104 - 8);
      if ( v57 >= 2 )
        break;
      if ( (_DWORD)v57 )
      {
        v109 = v55;
        v58 = v56 + 8 * v57;
        v59 = (RBX::Primitive **)(v104 + v56);
        v133 = (RBX::Primitive **)(v104 + v58);
        goto LABEL_49;
      }
LABEL_68:
      v77 = *(unsigned int *)(v56 + v105 - 8);
      if ( v77 >= 2 )
      {
        v79 = *(RBX::Primitive ***)(v56 + v105);
        v80 = &v79[v77];
        goto LABEL_72;
      }
      if ( (_DWORD)v77 )
      {
        v78 = v56 + 8 * v77;
        v79 = (RBX::Primitive **)(v105 + v56);
        v80 = (RBX::Primitive **)(v105 + v78);
        do
        {
LABEL_72:
          v81 = v55;
          v82 = *v79;
          FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(*v79);
          isNanInfVector3 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->low);
          v85 = (float *)&byte_29FC388[20];
          v86 = (float *)&byte_29FC388[16];
          p_x = (float *)&byte_29FC388[12];
          p_z = (float *)&byte_29FC388[8];
          p_y = (float *)&byte_29FC388[4];
          v90 = (float *)byte_29FC388;
          if ( !isNanInfVector3 )
          {
            v91 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->high);
            v85 = (float *)&byte_29FC388[20];
            v86 = (float *)&byte_29FC388[16];
            p_x = (float *)&byte_29FC388[12];
            p_z = (float *)&byte_29FC388[8];
            p_y = (float *)&byte_29FC388[4];
            v90 = (float *)byte_29FC388;
            if ( !v91 )
            {
              p_y = &FastFuzzyExtents->low.y;
              p_z = &FastFuzzyExtents->low.z;
              v86 = &FastFuzzyExtents->high.y;
              v85 = &FastFuzzyExtents->high.z;
              p_x = &FastFuzzyExtents->high.x;
              v90 = &FastFuzzyExtents->low.x;
            }
          }
          v37 = (unsigned int *)v122;
          if ( *p_z <= v122->high.z
            && v122->low.x <= *p_x
            && v122->low.y <= *v86
            && v122->low.z <= *v85
            && *p_y <= v122->high.y
            && *v90 <= v122->high.x )
          {
            v92 = *(_QWORD *)results;
            v93 = (__int64)(*((_QWORD *)results + 1) - *(_QWORD *)results) >> 3;
            if ( *((_QWORD *)results + 3) >= (unsigned __int64)(3 * v93) >> 2 )
            {
              RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>::rehash(results);
              v92 = *(_QWORD *)results;
              v93 = (__int64)(*((_QWORD *)results + 1) - *(_QWORD *)results) >> 3;
            }
            v94 = v93 - 1;
            v95 = (__int64)v82 + ((unsigned __int64)v82 >> 3);
            v96 = 0;
            while ( 1 )
            {
              v97 = v94 & v95;
              v98 = *(RBX::Primitive **)(v92 + 8 * v97);
              if ( v98 == *((RBX::Primitive **)results + 4) )
                break;
              if ( v98 != v82 )
              {
                v95 = v96 + v97 + 1;
                if ( ++v96 <= v94 )
                  continue;
              }
              goto LABEL_89;
            }
            *(_QWORD *)(v92 + 8 * v97) = v82;
            ++*((_QWORD *)results + 3);
          }
LABEL_89:
          ++v79;
          v50 = v126;
          v54 = v110;
          v55 = v81;
        }
        while ( v79 != v80 );
      }
LABEL_97:
      if ( ++v55 == v114 )
        goto LABEL_98;
    }
    v109 = v55;
    v59 = *(RBX::Primitive ***)(v56 + v104);
    v133 = &v59[v57];
    do
    {
LABEL_49:
      v60 = *v59;
      v61 = RBX::Primitive::getFastFuzzyExtents(*v59);
      v62 = RBX::Math::isNanInfVector3(&v61->low);
      v63 = (float *)&byte_29FC388[20];
      v64 = (float *)&byte_29FC388[16];
      v65 = (float *)&byte_29FC388[12];
      v66 = (float *)&byte_29FC388[8];
      v67 = (float *)&byte_29FC388[4];
      v68 = (float *)byte_29FC388;
      if ( !v62 )
      {
        v69 = RBX::Math::isNanInfVector3(&v61->high);
        v63 = (float *)&byte_29FC388[20];
        v64 = (float *)&byte_29FC388[16];
        v65 = (float *)&byte_29FC388[12];
        v66 = (float *)&byte_29FC388[8];
        v67 = (float *)&byte_29FC388[4];
        v68 = (float *)byte_29FC388;
        if ( !v69 )
        {
          v67 = &v61->low.y;
          v66 = &v61->low.z;
          v64 = &v61->high.y;
          v63 = &v61->high.z;
          v65 = &v61->high.x;
          v68 = &v61->low.x;
        }
      }
      v37 = (unsigned int *)v122;
      if ( *v66 <= v122->high.z
        && v122->low.x <= *v65
        && v122->low.y <= *v64
        && v122->low.z <= *v63
        && *v67 <= v122->high.y
        && *v68 <= v122->high.x )
      {
        v70 = *(_QWORD *)results;
        v71 = (__int64)(*((_QWORD *)results + 1) - *(_QWORD *)results) >> 3;
        if ( *((_QWORD *)results + 3) >= (unsigned __int64)(3 * v71) >> 2 )
        {
          RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>::rehash(results);
          v70 = *(_QWORD *)results;
          v71 = (__int64)(*((_QWORD *)results + 1) - *(_QWORD *)results) >> 3;
        }
        v72 = v71 - 1;
        v73 = (__int64)v60 + ((unsigned __int64)v60 >> 3);
        v74 = 0;
        while ( 1 )
        {
          v75 = v72 & v73;
          v76 = *(RBX::Primitive **)(v70 + 8 * v75);
          if ( v76 == *((RBX::Primitive **)results + 4) )
            break;
          if ( v76 != v60 )
          {
            v73 = v74 + v75 + 1;
            if ( ++v74 <= v72 )
              continue;
          }
          goto LABEL_66;
        }
        *(_QWORD *)(v70 + 8 * v75) = v60;
        ++*((_QWORD *)results + 3);
      }
LABEL_66:
      ++v59;
    }
    while ( v59 != v133 );
    v56 = *(_QWORD *)(*(_QWORD *)&v116[1].low.z + v131 + 8);
    v50 = v126;
    v54 = v110;
    v55 = v109;
    goto LABEL_68;
  }
}


// Address: 0x1dfd1b0 | Name: _ZN3RBX9Collision23SpatialHashHierarchical19getPrimitivesInGridERKNS_12Vector3int32ERN3G3D5ArrayIPNS_9PrimitiveELi10ELm32EEE
void __fastcall RBX::Collision::SpatialHashHierarchical::getPrimitivesInGrid(
        RBX::Collision::SpatialHashHierarchical *this,
        const RBX::Vector3int32 *grid,
        G3D::Array<RBX::Primitive *,10,32> *found)
{
  __int64 *v3; // rax
  int z; // ebp
  int x; // ebx
  int y; // r13d
  __int64 v7; // rcx
  __int64 v8; // r15
  unsigned __int64 v9; // rcx
  __int64 v10; // rbp
  RBX::Primitive **v11; // r15
  RBX::Primitive **v12; // rbp
  G3D::Array<RBX::Primitive *,10,32> *v13; // r14
  unsigned __int64 v14; // rax
  __int64 v15; // r14
  RBX::Primitive **v16; // r15
  RBX::Primitive **v17; // r14
  __int64 v18; // rax
  __int64 v19; // r9
  __int64 v20; // r10
  unsigned __int64 v21; // rcx
  __int64 v22; // r10
  __int64 v23; // r8
  _DWORD *v24; // rdx
  __int64 v25; // rax
  __int64 v26; // r12
  unsigned __int64 v27; // rdi
  int v28; // [rsp+4h] [rbp-64h]
  RBX::Primitive *value; // [rsp+8h] [rbp-60h] BYREF
  __int64 v30; // [rsp+10h] [rbp-58h]
  __int64 v31; // [rsp+18h] [rbp-50h]
  G3D::Array<RBX::Primitive *,10,32> *v32; // [rsp+20h] [rbp-48h]
  __int64 *v33; // [rsp+28h] [rbp-40h]
  __int64 v34; // [rsp+30h] [rbp-38h]

  v32 = found;
  v3 = (__int64 *)*((_QWORD *)this + 8);
  if ( v3[1] )
  {
    z = grid->z;
    x = grid->x;
    y = grid->y;
    v7 = 0;
    v33 = (__int64 *)*((_QWORD *)this + 8);
    while ( 1 )
    {
      v18 = *v3;
      v34 = v7;
      v19 = *(_QWORD *)(v18 + 8 * v7);
      v20 = ((73856093 * x) ^ (19349663 * y) ^ (83492791 * z)) & (unsigned int)(*(_DWORD *)(v19 + 8) - 1);
      v21 = *(unsigned __int8 *)(*(_QWORD *)v19 + v20);
      if ( !*(_BYTE *)(*(_QWORD *)v19 + v20) )
        goto LABEL_22;
      v22 = 16 * v20;
      v23 = *(_QWORD *)(v19 + 32);
      v24 = (_DWORD *)(*(_QWORD *)(v23 + v22) + 8LL);
      v25 = 24;
      v26 = 8;
      v27 = 0;
      while ( *(v24 - 2) != x || *(v24 - 1) != y || *v24 != z )
      {
        ++v27;
        v26 += 32;
        v25 += 32;
        v24 += 3;
        if ( v27 >= v21 )
          goto LABEL_22;
      }
      v8 = *(_QWORD *)(v23 + v22 + 8);
      v9 = *(unsigned int *)(v8 + v25 - 8);
      if ( v9 >= 2 )
        break;
      if ( (_DWORD)v9 )
      {
        v30 = v22;
        v31 = v19;
        v28 = z;
        v10 = v8 + 8 * v9;
        v11 = (RBX::Primitive **)(v25 + v8);
        v12 = (RBX::Primitive **)(v25 + v10);
        goto LABEL_7;
      }
LABEL_10:
      v14 = *(unsigned int *)(v8 + v26 - 8);
      if ( v14 >= 2 )
      {
        v16 = *(RBX::Primitive ***)(v8 + v26);
        v17 = &v16[v14];
        do
        {
LABEL_14:
          value = *v16;
          G3D::Array<RBX::Primitive *,10,32ul>::append(v32, &value);
          ++v16;
        }
        while ( v17 != v16 );
        goto LABEL_22;
      }
      if ( (_DWORD)v14 )
      {
        v15 = v8 + 8 * v14;
        v16 = (RBX::Primitive **)(v26 + v8);
        v17 = (RBX::Primitive **)(v26 + v15);
        goto LABEL_14;
      }
LABEL_22:
      x >>= 1;
      y >>= 1;
      z >>= 1;
      v7 = v34 + 1;
      v3 = v33;
      if ( v34 + 1 >= (unsigned __int64)v33[1] )
        return;
    }
    v30 = v22;
    v31 = v19;
    v28 = z;
    v11 = *(RBX::Primitive ***)(v8 + v25);
    v12 = &v11[v9];
LABEL_7:
    v13 = v32;
    do
    {
      value = *v11;
      G3D::Array<RBX::Primitive *,10,32ul>::append(v13, &value);
      ++v11;
    }
    while ( v12 != v11 );
    v8 = *(_QWORD *)(*(_QWORD *)(v31 + 32) + v30 + 8);
    z = v28;
    goto LABEL_10;
  }
}


// Address: 0x1dfd390 | Name: _ZN3RBX9Collision23SpatialHashHierarchical11getNextGridERNS_12Vector3int32ERKNS_6RbxRayEf
char __fastcall RBX::Collision::SpatialHashHierarchical::getNextGrid(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Vector3int32 *grid,
        const RBX::RbxRay *unitRay,
        float maxDistance)
{
  float x; // xmm2_4
  int v5; // esi
  int v6; // ebp
  float y; // xmm2_4
  int v8; // ebx
  float z; // xmm2_4
  int v10; // eax
  int v11; // edx
  int v12; // ecx
  int v13; // ebp
  int v14; // edi
  int v15; // edi
  int v16; // r15d
  int v17; // eax
  float v18; // xmm5_4
  __m128 v19; // xmm4
  int v20; // ecx
  int v21; // r14d
  int v22; // ebx
  int v23; // r13d
  __m128 v24; // xmm4
  __m128 v25; // xmm0
  float v26; // xmm1_4
  __m128 v27; // xmm0
  __m128 v28; // xmm1
  float v29; // xmm3_4
  float v30; // xmm2_4
  char v31; // al
  __m128 v32; // xmm0
  __m128 v33; // xmm0
  bool v34; // cc
  RBX::Vector3int32 *v35; // rax
  bool Inside; // [rsp+7h] [rbp-C1h] BYREF
  __int64 v38; // [rsp+8h] [rbp-C0h]
  float v39; // [rsp+14h] [rbp-B4h]
  G3D::Vector3 location; // [rsp+18h] [rbp-B0h] BYREF
  int v41; // [rsp+28h] [rbp-A0h]
  float i; // [rsp+2Ch] [rbp-9Ch]
  int v43; // [rsp+30h] [rbp-98h]
  int v44; // [rsp+34h] [rbp-94h]
  int v45; // [rsp+38h] [rbp-90h]
  int v46; // [rsp+3Ch] [rbp-8Ch]
  int v47; // [rsp+40h] [rbp-88h]
  int v48; // [rsp+44h] [rbp-84h]
  int v49; // [rsp+48h] [rbp-80h]
  int v50; // [rsp+4Ch] [rbp-7Ch]
  RBX::Vector3int32 *v51; // [rsp+50h] [rbp-78h]
  G3D::Vector3 *origin; // [rsp+58h] [rbp-70h]
  G3D::Vector3 *dir; // [rsp+60h] [rbp-68h]
  G3D::AABox box; // [rsp+68h] [rbp-60h] BYREF
  __m128 v55; // [rsp+80h] [rbp-48h]

  v51 = grid;
  dir = &unitRay->m_direction;
  x = unitRay->m_direction.x;
  v5 = -(x < 0.0);
  v6 = x > 0.0;
  v48 = v5;
  v45 = v6;
  y = unitRay->m_direction.y;
  v49 = -(y < 0.0);
  v8 = y > 0.0;
  v46 = v8;
  origin = &unitRay->m_origin;
  z = unitRay->m_direction.z;
  v10 = z > 0.0;
  v50 = -(z < 0.0);
  v47 = v10;
  v11 = 1;
  for ( i = (float)((float)((float)(1 << dword_2868B08) + (float)(1 << dword_2868B08)) + maxDistance)
          * (float)((float)((float)(1 << dword_2868B08) + (float)(1 << dword_2868B08)) + maxDistance); v48 > v6; v5 = v48 )
  {
LABEL_4:
    if ( (unsigned int)++v11 > 3 )
      return 0;
  }
  v43 = v11;
  while ( 1 )
  {
    v38 = (unsigned int)v49;
    if ( v49 <= v8 )
      break;
LABEL_28:
    v34 = v5++ < v6;
    if ( !v34 )
      goto LABEL_4;
  }
  v12 = -v5;
  if ( -v5 < 1 )
    v12 = v5;
  v41 = v12;
  while ( 1 )
  {
    v13 = v50;
    if ( v50 <= v10 )
      break;
LABEL_25:
    v34 = (int)v38 < v8;
    v38 = (unsigned int)(v38 + 1);
    if ( !v34 )
    {
      v6 = v45;
      goto LABEL_28;
    }
  }
  v14 = -(int)v38;
  if ( -(int)v38 < 1 )
    v14 = v38;
  v15 = v41 + v14;
  v16 = -v50;
  v44 = v15;
  while ( 1 )
  {
    v20 = v13;
    if ( v13 < 0 )
      v20 = v16;
    if ( v15 + v20 != v11 )
      goto LABEL_23;
    v21 = v5 + v51->x;
    v22 = v38 + v51->y;
    v23 = v51->z;
    v24 = 0;
    v25 = 0;
    v26 = (float)(1 << dword_2868B08);
    v24.m128_f32[0] = (float)v21 * v26;
    v25.m128_f32[0] = (float)v22 * v26;
    v19 = _mm_unpacklo_ps(v24, v25);
    v18 = (float)(v13 + v23) * v26;
    if ( !(_BYTE)byte_29FEE00 )
    {
      v55 = v19;
      v39 = (float)(v13 + v23) * v26;
      v17 = __cxa_guard_acquire(&byte_29FEE00);
      v18 = v39;
      v19 = v55;
      if ( v17 )
      {
        qword_29FEDF0 = 0x100000001LL;
        dword_29FEDF8 = 1;
        __cxa_guard_release(&byte_29FEE00);
        v18 = v39;
        v19 = v55;
      }
    }
    v27 = 0;
    v28 = 0;
    v29 = (float)(1 << dword_2868B08);
    v27.m128_f32[0] = (float)(qword_29FEDF0 + v21) * v29;
    v28.m128_f32[0] = (float)(HIDWORD(qword_29FEDF0) + v22) * v29;
    v30 = (float)(v13 + dword_29FEDF8 + v23) * v29;
    _mm_storel_ps((double *)&box.lo.x, v19);
    box.lo.z = v18;
    _mm_storel_ps((double *)&box.hi.x, _mm_unpacklo_ps(v27, v28));
    box.hi.z = v30;
    *(_QWORD *)&location.x = 0;
    location.z = 0.0;
    v31 = G3D::CollisionDetection::collisionLocationForMovingPointFixedAABox(
            origin,
            dir,
            &box,
            &location,
            &Inside,
            &stru_2AD5994);
    if ( (!Inside & (unsigned __int8)~v31) == 0 )
    {
      v32 = _mm_sub_ps(
              _mm_unpacklo_ps((__m128)LODWORD(location.x), (__m128)LODWORD(location.z)),
              _mm_unpacklo_ps((__m128)LODWORD(origin->x), (__m128)LODWORD(origin->z)));
      v33 = _mm_mul_ps(v32, v32);
      if ( i > (float)(_mm_shuffle_ps(v33, v33, 229).m128_f32[0]
                     + (float)((float)((float)(location.y - origin->y) * (float)(location.y - origin->y))
                             + v33.m128_f32[0])) )
        break;
    }
    v10 = v47;
    v11 = v43;
    v15 = v44;
LABEL_23:
    --v16;
    v34 = v13++ < v10;
    if ( !v34 )
    {
      v8 = v46;
      goto LABEL_25;
    }
  }
  v35 = v51;
  *(_QWORD *)&v51->x = ((unsigned __int64)(unsigned int)(v51->y + v38) << 32) | (unsigned int)(v51->x + v5);
  v35->z -= v16;
  return 1;
}


// Address: 0x1dfd730 | Name: _ZNK3RBX9Collision23SpatialHashHierarchical7doStatsEv
void __fastcall RBX::Collision::SpatialHashHierarchical::doStats(const RBX::Collision::SpatialHashHierarchical *this)
{
  ;
}


// Address: 0x1dfd760 | Name: _ZN3RBX9Collision23SpatialHashHierarchical24registerMovementCallbackEPNS0_15SpatialHashBase16MovementCallbackEi
void __fastcall RBX::Collision::SpatialHashHierarchical::registerMovementCallback(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Collision::SpatialHashBase::MovementCallback *callback,
        int reportingMode)
{
  RBX::Collision::SpatialHashHierarchical::MovementCallbackData *v3; // rax
  RBX::Collision::SpatialHashHierarchical::MovementCallbackData __x; // [rsp+8h] [rbp-10h] BYREF

  __x.callback = callback;
  __x.reportingMode = reportingMode;
  v3 = (RBX::Collision::SpatialHashHierarchical::MovementCallbackData *)*((_QWORD *)this + 13);
  if ( v3 == *((RBX::Collision::SpatialHashHierarchical::MovementCallbackData **)this + 14) )
  {
    std::vector<RBX::Collision::SpatialHashHierarchical::MovementCallbackData>::__push_back_slow_path<RBX::Collision::SpatialHashHierarchical::MovementCallbackData const&>(
      (RBX::Collision::SpatialHashHierarchical *)((char *)this + 96),
      &__x);
  }
  else
  {
    *v3 = __x;
    *((_QWORD *)this + 13) += 16LL;
  }
}


// Address: 0x1dfd7a0 | Name: _ZN3RBX9Collision23SpatialHashHierarchical26unregisterMovementCallbackEPNS0_15SpatialHashBase16MovementCallbackE
void __fastcall RBX::Collision::SpatialHashHierarchical::unregisterMovementCallback(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Collision::SpatialHashBase::MovementCallback *callback)
{
  RBX::Collision::SpatialHashBase::MovementCallback **v3; // rsi
  char *v4; // rdx
  __int64 v5; // rbx
  bool v6; // zf
  signed __int64 v7; // rdx
  __int64 v8; // r15

  v3 = (RBX::Collision::SpatialHashBase::MovementCallback **)*((_QWORD *)this + 12);
  v4 = (char *)*((_QWORD *)this + 13);
  v5 = 16LL - (_QWORD)v3;
  while ( v4 != (char *)v3 )
  {
    v5 -= 16;
    v6 = *v3 == callback;
    v3 += 2;
    if ( v6 )
    {
      v7 = v4 - (char *)v3;
      v8 = v7 >> 4;
      if ( v7 )
        memmove(v3 - 2, v3, v7);
      *((_QWORD *)this + 13) = 16 * v8 - v5;
      return;
    }
  }
}


// Address: 0x1dfd800 | Name: _ZN3RBX9Collision23SpatialHashHierarchical14computeExtentsEv
RBX::Extents *__fastcall RBX::Collision::SpatialHashHierarchical::computeExtents(
        RBX::Extents *__return_ptr retstr,
        RBX::Collision::SpatialHashHierarchical *this)
{
  RBX::Collision::GridHierarchy::computeExtents(retstr, *((RBX::Collision::GridHierarchy **)this + 8));
  return retstr;
}


// Address: 0x1dfd820 | Name: _ZN3RBX9Collision23SpatialHashHierarchical13render3dAdornEPNS_5AdornE
void __fastcall RBX::Collision::SpatialHashHierarchical::render3dAdorn(
        RBX::Collision::SpatialHashHierarchical *this,
        RBX::Adorn *adorn)
{
  RBX::Collision::GridHierarchy::render3dAdorn(*((RBX::Collision::GridHierarchy **)this + 8), adorn);
}


// Address: 0x1dfd830 | Name: _ZN3RBX9Collision12StatReporterC2Eddj
void __fastcall RBX::Collision::StatReporter::StatReporter(
        RBX::Collision::StatReporter *this,
        double a2,
        double throttlingPercentage,
        double delayInSeconds,
        uint32_t attemptRate)
{
  RBX::Random v5; // [rsp+10h] [rbp-28h] BYREF

  this->counter = 0;
  this->attemptRate = attemptRate;
  this->lastReportTime.sec = 0.0;
  this->delayInSeconds = throttlingPercentage;
  *(_OWORD *)((char *)&this->stats.mSize + 1) = 0;
  this->stats.RBX::ArrayBase<std::pair<std::string,std::function<double ()> > > = 0;
  this->stats.mAlignment = 16;
  RBX::Random::Random(&v5);
  this->enabled = a2 >= RBX::Random::nextNumber(&v5, delayInSeconds, 100.0);
  this->lastReportTime = RBX::Time::now<(RBX::Time::SampleMethod)2>();
}


// Address: 0x1dfdec0 | Name: _ZN3RBX9Collision13GridHierarchy51getPrimitivesInBoxDepthFirstInternalSkipOverlapTestIZNS0_23SpatialHashHierarchical27getPrimitivesOverlappingRecERKNS_7ExtentsERNS_12DenseHashSetIPNS_9PrimitiveEN5boost4hashIS9_EENSt3__18equal_toIS9_EEEEE3$_9EEvT_S6_iNS0_9LevelGrid12CellIteratorE
unsigned __int64 __fastcall RBX::Collision::GridHierarchy::getPrimitivesInBoxDepthFirstInternalSkipOverlapTest<RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlappingRec(RBX::Extents const&,RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>> &)::$_9>(
        _QWORD *a1,
        RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > *a2,
        int a3,
        __int64 a4)
{
  unsigned __int64 result; // rax
  __int64 v6; // rcx
  unsigned __int64 v7; // rdx
  RBX::Collision::CellChildren *v8; // r12
  RBX::Collision::CellChildren *v9; // r15
  unsigned __int64 v10; // rbx
  unsigned __int64 v11; // rax
  __int64 v12; // rcx
  unsigned __int64 v13; // rcx
  __int64 v14; // rdx
  __int64 v15; // rdi
  __int64 v16; // rdx
  RBX::Collision::CellChildren *v17; // rbp
  __int64 v18; // rcx
  unsigned __int64 v19; // rdx
  RBX::Collision::CellChildren *v20; // r12
  RBX::Collision::CellChildren *v21; // r15
  unsigned __int64 v22; // rbx
  __int64 v23; // rcx
  unsigned __int64 v24; // rcx
  __int64 v25; // rdx
  __int64 v26; // rdi
  __int64 v27; // rdx
  RBX::Collision::CellChildren *v28; // rbp
  __int64 v29; // r13
  uint8_t childMask; // r12
  __int64 v31; // rax
  int v32; // r9d
  int v33; // r15d
  int v34; // r11d
  unsigned int v35; // ebp
  int v36; // ecx
  int v37; // edx
  __int64 v38; // r8
  _DWORD *v39; // rbx
  unsigned __int64 v40; // rsi
  int v41; // ebx
  RBX::Collision::CellIterator v42; // [rsp+0h] [rbp-68h]

  result = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(a4 + 16) + 32LL) + 16LL * *(unsigned int *)(a4 + 4) + 8);
  *(_QWORD *)&v42.index.nodeIndex = a4;
  v6 = *(unsigned __int8 *)(a4 + 8);
  v7 = *(unsigned int *)(result + 32 * v6 + 16);
  v8 = (RBX::Collision::CellChildren *)(result + 32 * v6 + 24);
  if ( v7 >= 2 )
  {
    v8 = *(RBX::Collision::CellChildren **)&v8->childMask;
  }
  else if ( !(_DWORD)v7 )
  {
    goto LABEL_16;
  }
  v9 = &v8[8 * v7];
  do
  {
    v10 = *(_QWORD *)&v8->childMask;
    v11 = *(_QWORD *)a2;
    v12 = (__int64)(*((_QWORD *)a2 + 1) - *(_QWORD *)a2) >> 3;
    if ( *((_QWORD *)a2 + 3) >= (unsigned __int64)(3 * v12) >> 2 )
    {
      RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>::rehash(a2);
      v11 = *(_QWORD *)a2;
      v12 = (__int64)(*((_QWORD *)a2 + 1) - *(_QWORD *)a2) >> 3;
    }
    v13 = v12 - 1;
    v14 = v10 + (v10 >> 3);
    v15 = 0;
    while ( 1 )
    {
      v16 = v13 & v14;
      v17 = *(RBX::Collision::CellChildren **)(v11 + 8 * v16);
      if ( v17 == *((RBX::Collision::CellChildren **)a2 + 4) )
        break;
      if ( v17 != (RBX::Collision::CellChildren *)v10 )
      {
        v14 = v15 + v16 + 1;
        if ( ++v15 <= v13 )
          continue;
      }
      goto LABEL_14;
    }
    *(_QWORD *)(v11 + 8 * v16) = v10;
    ++*((_QWORD *)a2 + 3);
LABEL_14:
    v8 += 8;
  }
  while ( v8 != v9 );
  result = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(*(_QWORD *)&v42.index.nodeIndex + 16LL) + 32LL)
                     + 16LL * *(unsigned int *)(*(_QWORD *)&v42.index.nodeIndex + 4LL)
                     + 8);
  v6 = *(unsigned __int8 *)(*(_QWORD *)&v42.index.nodeIndex + 8LL);
LABEL_16:
  v18 = 32 * v6;
  v19 = *(unsigned int *)(result + v18);
  v20 = (RBX::Collision::CellChildren *)(result + v18 + 8);
  if ( v19 >= 2 )
  {
    v20 = *(RBX::Collision::CellChildren **)&v20->childMask;
  }
  else if ( !(_DWORD)v19 )
  {
    goto LABEL_30;
  }
  v21 = &v20[8 * v19];
  do
  {
    v22 = *(_QWORD *)&v20->childMask;
    result = *(_QWORD *)a2;
    v23 = (__int64)(*((_QWORD *)a2 + 1) - *(_QWORD *)a2) >> 3;
    if ( *((_QWORD *)a2 + 3) >= (unsigned __int64)(3 * v23) >> 2 )
    {
      RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>::rehash(a2);
      result = *(_QWORD *)a2;
      v23 = (__int64)(*((_QWORD *)a2 + 1) - *(_QWORD *)a2) >> 3;
    }
    v24 = v23 - 1;
    v25 = v22 + (v22 >> 3);
    v26 = 0;
    while ( 1 )
    {
      v27 = v24 & v25;
      v28 = *(RBX::Collision::CellChildren **)(result + 8 * v27);
      if ( v28 == *((RBX::Collision::CellChildren **)a2 + 4) )
        break;
      if ( v28 != (RBX::Collision::CellChildren *)v22 )
      {
        v25 = v26 + v27 + 1;
        if ( ++v26 <= v24 )
          continue;
      }
      goto LABEL_29;
    }
    *(_QWORD *)(result + 8 * v27) = v22;
    ++*((_QWORD *)a2 + 3);
LABEL_29:
    v20 += 8;
  }
  while ( v20 != v21 );
LABEL_30:
  if ( a3 > 0 )
  {
    result = (unsigned __int64)RBX::Collision::LevelGrid::getChildren(
                                 *(RBX::Collision::LevelGrid **)(*(_QWORD *)&v42.index.nodeIndex + 16LL),
                                 *(const RBX::Collision::LevelGrid::CellIndex **)&v42.index.nodeIndex);
    if ( *(_BYTE *)result )
    {
      HIDWORD(v42.container) = a3 - 1;
      v29 = *(_QWORD *)(*a1 + 8LL * a3 - 8);
      childMask = RBX::Collision::LevelGrid::getChildren(
                    *(RBX::Collision::LevelGrid **)(*(_QWORD *)&v42.index.nodeIndex + 16LL),
                    *(const RBX::Collision::LevelGrid::CellIndex **)&v42.index.nodeIndex)->childMask;
      v31 = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(*(_QWORD *)&v42.index.nodeIndex + 16LL) + 32LL)
                      + 16LL * *(unsigned int *)(*(_QWORD *)&v42.index.nodeIndex + 4LL));
      v32 = 2 * *(_DWORD *)(v31 + 12LL * *(unsigned __int8 *)(*(_QWORD *)&v42.index.nodeIndex + 8LL));
      v33 = 2 * *(_DWORD *)(v31 + 12LL * *(unsigned __int8 *)(*(_QWORD *)&v42.index.nodeIndex + 8LL) + 4);
      v34 = 2 * *(_DWORD *)(v31 + 12LL * *(unsigned __int8 *)(*(_QWORD *)&v42.index.nodeIndex + 8LL) + 8);
      v35 = 0;
      *(_DWORD *)&v42.index.nodeIndex = v34;
      do
      {
        result = (unsigned int)(1 << v35);
        if ( ((unsigned __int8)result & childMask) != 0 )
        {
          result = v32 | v35 & 1;
          v36 = v33 | (v35 >> 1) & 1;
          v37 = v34 | (v35 >> 2) & 1;
          v38 = ((73856093 * (_DWORD)result)
               ^ (19349663 * v36)
               ^ (83492791 * v37))
              & (unsigned int)(*(_DWORD *)(v29 + 8) - 1);
          if ( *(_BYTE *)(*(_QWORD *)v29 + v38) )
          {
            v39 = (_DWORD *)(*(_QWORD *)(*(_QWORD *)(v29 + 32) + 16 * v38) + 8LL);
            v40 = 0;
            while ( *((_QWORD *)v39 - 1) != __PAIR64__(v36, result) || *v39 != v37 )
            {
              ++v40;
              v39 += 3;
              if ( v40 >= *(unsigned __int8 *)(*(_QWORD *)v29 + v38) )
                goto LABEL_41;
            }
            v41 = v32;
            result = RBX::Collision::GridHierarchy::getPrimitivesInBoxDepthFirstInternalSkipOverlapTest<RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlappingRec(RBX::Extents const&,RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>> &)::$_9>(v42);
            v34 = *(_DWORD *)&v42.index.nodeIndex;
            v32 = v41;
          }
        }
LABEL_41:
        ++v35;
      }
      while ( v35 != 8 );
    }
  }
  return result;
}


// Address: 0x1dfe220 | Name: _ZN3RBX9Collision13GridHierarchy49getPrimitivesInBoxDepthFirstInternalDoOverlapTestIZNS0_23SpatialHashHierarchical27getPrimitivesOverlappingRecERKNS_7ExtentsERNS_12DenseHashSetIPNS_9PrimitiveEN5boost4hashIS9_EENSt3__18equal_toIS9_EEEEE3$_9EEvT_S6_iNS0_9LevelGrid12CellIteratorE
char __fastcall RBX::Collision::GridHierarchy::getPrimitivesInBoxDepthFirstInternalDoOverlapTest<RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlappingRec(RBX::Extents const&,RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>> &)::$_9>(
        RBX::Collision::GridHierarchy *a1,
        RBX::Collision::LevelGrid *a2,
        float *a3,
        int a4,
        __int64 a5)
{
  RBX::Collision::CellChildren *Children; // rax
  __int64 v7; // rcx
  unsigned __int64 v8; // rdx
  RBX::Primitive **v9; // r12
  unsigned __int8 *mData; // rax
  __int64 v11; // rcx
  unsigned __int64 v12; // rcx
  __int64 v13; // rdx
  __int64 v14; // rdi
  __int64 v15; // rdx
  RBX::Collision::LevelGrid::Bin *v16; // rbx
  RBX::Primitive *v17; // rbp
  const RBX::Extents *FastFuzzyExtents; // r15
  bool isNanInfVector3; // al
  float *p_x; // r8
  float *p_y; // rdx
  float *p_z; // rbx
  float *v23; // rcx
  float *v24; // rdi
  float *v25; // rsi
  bool v26; // al
  __int64 v27; // rcx
  unsigned __int64 v28; // rdx
  RBX::Primitive **v29; // rbp
  RBX::Primitive **v30; // r13
  __int64 v31; // rcx
  unsigned __int64 v32; // rcx
  __int64 v33; // rdx
  __int64 v34; // rdi
  __int64 v35; // rdx
  RBX::Collision::LevelGrid::Bin *v36; // rbx
  RBX::Primitive *v37; // r12
  const RBX::Extents *v38; // rbx
  float *v39; // r8
  float *v40; // r9
  float *v41; // rcx
  float *v42; // rdx
  float *v43; // rdi
  float *v44; // rsi
  __m128 v45; // xmm0
  __int64 v46; // rbx
  RBX::Collision::LevelGrid *v47; // rdi
  RBX::Collision::CellCoord *coords; // rax
  __m128 v49; // xmm2
  __m128 v50; // xmm1
  __m128 v51; // xmm0
  __m128 v52; // xmm3
  __m128 v53; // xmm4
  __m128 v54; // xmm5
  __m128 v55; // xmm0
  __m128 v56; // xmm3
  __m128 v57; // xmm1
  __m128 v58; // xmm2
  __m128 v59; // xmm5
  __m128 v60; // xmm3
  __int64 v61; // rax
  RBX::Collision::LevelGrid *v62; // r12
  uint8_t childMask; // r15
  __int64 v64; // rax
  int v65; // r13d
  unsigned int i; // ebp
  __int64 v67; // rax
  _BOOL8 v68; // r9
  __int64 v69; // r9
  __int64 v70; // r10
  __int64 v71; // r11
  __int64 v72; // r8
  int32_t *v73; // rcx
  unsigned __int64 v74; // rdi
  RBX::Collision::CellIterator v76; // [rsp+0h] [rbp-C8h]
  int na; // [rsp+18h] [rbp-B0h]
  RBX::Primitive **v79; // [rsp+20h] [rbp-A8h]
  int v80; // [rsp+20h] [rbp-A8h]
  RBX::Collision::GridHierarchy *v81; // [rsp+28h] [rbp-A0h]
  __m128 v82; // [rsp+30h] [rbp-98h]
  __m128 v83; // [rsp+40h] [rbp-88h]
  __m128 v84; // [rsp+50h] [rbp-78h]
  char v85; // [rsp+68h] [rbp-60h] BYREF
  int v86; // [rsp+6Ch] [rbp-5Ch]
  char v87; // [rsp+70h] [rbp-58h]
  RBX::Collision::LevelGrid *v88; // [rsp+78h] [rbp-50h]
  int v89[2]; // [rsp+80h] [rbp-48h] BYREF
  char v90; // [rsp+88h] [rbp-40h]
  RBX::Collision::LevelGrid *v91; // [rsp+90h] [rbp-38h]

  *((_DWORD *)&v76.index + 3) = a4;
  v76.container = a2;
  v81 = a1;
  Children = *(RBX::Collision::CellChildren **)(*(_QWORD *)(*(_QWORD *)(a5 + 16) + 32LL)
                                              + 16LL * *(unsigned int *)(a5 + 4)
                                              + 8);
  v7 = *(unsigned __int8 *)(a5 + 8);
  v8 = *(unsigned int *)&Children[32 * v7 + 16].childMask;
  v9 = (RBX::Primitive **)&Children[32 * v7 + 24];
  if ( v8 >= 2 )
  {
    v9 = (RBX::Primitive **)*v9;
  }
  else if ( !(_DWORD)v8 )
  {
    goto LABEL_25;
  }
  v79 = &v9[v8];
  do
  {
    v17 = *v9;
    FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(*v9);
    isNanInfVector3 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->low);
    p_x = (float *)byte_29FC388;
    p_y = (float *)&byte_29FC388[4];
    p_z = (float *)&byte_29FC388[8];
    v23 = (float *)&byte_29FC388[12];
    v24 = (float *)&byte_29FC388[16];
    v25 = (float *)&byte_29FC388[20];
    if ( !isNanInfVector3 )
    {
      v26 = RBX::Math::isNanInfVector3(&FastFuzzyExtents->high);
      p_x = (float *)byte_29FC388;
      p_y = (float *)&byte_29FC388[4];
      p_z = (float *)&byte_29FC388[8];
      v23 = (float *)&byte_29FC388[12];
      v24 = (float *)&byte_29FC388[16];
      v25 = (float *)&byte_29FC388[20];
      if ( !v26 )
      {
        p_y = &FastFuzzyExtents->low.y;
        p_z = &FastFuzzyExtents->low.z;
        v24 = &FastFuzzyExtents->high.y;
        v25 = &FastFuzzyExtents->high.z;
        p_x = &FastFuzzyExtents->low.x;
        v23 = &FastFuzzyExtents->high.x;
      }
    }
    if ( *a3 <= *v23 && *p_z <= a3[5] && a3[1] <= *v24 && a3[2] <= *v25 && *p_y <= a3[4] && *p_x <= a3[3] )
    {
      mData = v76.container->sizes.mData;
      v11 = (__int64)(v76.container->sizes.mSize - (unsigned __int64)v76.container->sizes.mData) >> 3;
      if ( *(_QWORD *)&v76.container->sizes.mNoInit >= (unsigned __int64)(3 * v11) >> 2 )
      {
        RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>::rehash((RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > *)v76.container);
        mData = v76.container->sizes.mData;
        v11 = (__int64)(v76.container->sizes.mSize - (unsigned __int64)v76.container->sizes.mData) >> 3;
      }
      v12 = v11 - 1;
      v13 = (__int64)v17 + ((unsigned __int64)v17 >> 3);
      v14 = 0;
      while ( 1 )
      {
        v15 = v12 & v13;
        v16 = *(RBX::Collision::LevelGrid::Bin **)&mData[8 * v15];
        if ( v16 == v76.container->bins.mData )
          break;
        if ( v16 != (RBX::Collision::LevelGrid::Bin *)v17 )
        {
          v13 = v14 + v15 + 1;
          if ( ++v14 <= v12 )
            continue;
        }
        goto LABEL_23;
      }
      *(_QWORD *)&mData[8 * v15] = v17;
      ++*(_QWORD *)&v76.container->sizes.mNoInit;
    }
LABEL_23:
    ++v9;
  }
  while ( v9 != v79 );
  Children = *(RBX::Collision::CellChildren **)(*(_QWORD *)(*(_QWORD *)(a5 + 16) + 32LL)
                                              + 16LL * *(unsigned int *)(a5 + 4)
                                              + 8);
  v7 = *(unsigned __int8 *)(a5 + 8);
LABEL_25:
  v27 = 32 * v7;
  v28 = *(unsigned int *)&Children[v27].childMask;
  v29 = (RBX::Primitive **)&Children[v27 + 8];
  if ( v28 >= 2 )
  {
    v29 = (RBX::Primitive **)*v29;
  }
  else if ( !(_DWORD)v28 )
  {
    goto LABEL_48;
  }
  v30 = &v29[v28];
  do
  {
    v37 = *v29;
    v38 = RBX::Primitive::getFastFuzzyExtents(*v29);
    LOBYTE(Children) = RBX::Math::isNanInfVector3(&v38->low);
    v39 = (float *)byte_29FC388;
    v40 = (float *)&byte_29FC388[4];
    v41 = (float *)&byte_29FC388[8];
    v42 = (float *)&byte_29FC388[12];
    v43 = (float *)&byte_29FC388[16];
    v44 = (float *)&byte_29FC388[20];
    if ( !(_BYTE)Children )
    {
      LOBYTE(Children) = RBX::Math::isNanInfVector3(&v38->high);
      v39 = (float *)byte_29FC388;
      v40 = (float *)&byte_29FC388[4];
      v41 = (float *)&byte_29FC388[8];
      v42 = (float *)&byte_29FC388[12];
      v43 = (float *)&byte_29FC388[16];
      v44 = (float *)&byte_29FC388[20];
      if ( !(_BYTE)Children )
      {
        v40 = &v38->low.y;
        v41 = &v38->low.z;
        v43 = &v38->high.y;
        v44 = &v38->high.z;
        v39 = &v38->low.x;
        v42 = &v38->high.x;
      }
    }
    if ( *a3 <= *v42 && *v41 <= a3[5] && a3[1] <= *v43 && a3[2] <= *v44 && *v40 <= a3[4] && *v39 <= a3[3] )
    {
      Children = (RBX::Collision::CellChildren *)v76.container->sizes.mData;
      v31 = (__int64)(v76.container->sizes.mSize - (unsigned __int64)v76.container->sizes.mData) >> 3;
      if ( *(_QWORD *)&v76.container->sizes.mNoInit >= (unsigned __int64)(3 * v31) >> 2 )
      {
        RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>>::rehash((RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > *)v76.container);
        Children = (RBX::Collision::CellChildren *)v76.container->sizes.mData;
        v31 = (__int64)(v76.container->sizes.mSize - (unsigned __int64)v76.container->sizes.mData) >> 3;
      }
      v32 = v31 - 1;
      v33 = (__int64)v37 + ((unsigned __int64)v37 >> 3);
      v34 = 0;
      while ( 1 )
      {
        v35 = v32 & v33;
        v36 = *(RBX::Collision::LevelGrid::Bin **)&Children[8 * v35].childMask;
        if ( v36 == v76.container->bins.mData )
          break;
        if ( v36 != (RBX::Collision::LevelGrid::Bin *)v37 )
        {
          v33 = v34 + v35 + 1;
          if ( ++v34 <= v32 )
            continue;
        }
        goto LABEL_47;
      }
      *(_QWORD *)&Children[8 * v35].childMask = v37;
      LOBYTE(Children) = v76.container;
      ++*(_QWORD *)&v76.container->sizes.mNoInit;
    }
LABEL_47:
    ++v29;
  }
  while ( v29 != v30 );
LABEL_48:
  if ( *((int *)&v76.index + 3) > 0 )
  {
    Children = RBX::Collision::LevelGrid::getChildren(
                 *(RBX::Collision::LevelGrid **)(a5 + 16),
                 (const RBX::Collision::LevelGrid::CellIndex *)a5);
    if ( Children->childMask )
    {
      v45 = _mm_cvtepi32_ps(_mm_shuffle_epi32(_mm_cvtsi32_si128(1 << dword_2868B08 << *((char *)&v76.index + 12)), 0));
      v46 = a5;
      v47 = *(RBX::Collision::LevelGrid **)(a5 + 16);
      coords = v47->bins.mData[*(unsigned int *)(a5 + 4)].coords;
      v49 = _mm_mul_ps(
              _mm_cvtepi32_ps((__m128i)_mm_unpacklo_ps(
                                         _mm_unpacklo_ps(
                                           (__m128)(unsigned int)coords[*(unsigned __int8 *)(a5 + 8)].v[0],
                                           (__m128)(unsigned int)coords[*(unsigned __int8 *)(a5 + 8)].v[2]),
                                         (__m128)(unsigned int)coords[*(unsigned __int8 *)(a5 + 8)].v[1])),
              v45);
      v50 = _mm_add_ps(v45, v49);
      v51 = _mm_add_ps(_mm_mul_ps(v45, (__m128)xmmword_3E72A0), v49);
      v52 = _mm_unpacklo_ps(
              _mm_unpacklo_ps((__m128)*(unsigned int *)a3, (__m128)*((unsigned int *)a3 + 2)),
              (__m128)*((unsigned int *)a3 + 1));
      v53 = _mm_unpacklo_ps(
              _mm_unpacklo_ps((__m128)*((unsigned int *)a3 + 3), (__m128)*((unsigned int *)a3 + 5)),
              (__m128)*((unsigned int *)a3 + 4));
      v54 = _mm_cmple_ps(v52, v51);
      v55 = _mm_cmple_ps(v51, v53);
      v56 = _mm_cmple_ps(v52, v49);
      v57 = _mm_cmple_ps(v50, v53);
      v58 = _mm_unpacklo_ps(v54, v56);
      v59 = _mm_unpackhi_ps(v54, v56);
      v60 = _mm_unpacklo_ps(v55, v57);
      v84 = _mm_unpacklo_ps(v58, v60);
      v83 = _mm_unpackhi_ps(v58, v60);
      v82 = _mm_unpacklo_ps(v59, _mm_unpackhi_ps(v55, v57));
      v61 = *((int *)&v76.index + 3);
      --*((_DWORD *)&v76.index + 3);
      v62 = v81->levels.mData[v61 - 1];
      childMask = RBX::Collision::LevelGrid::getChildren(v47, (const RBX::Collision::LevelGrid::CellIndex *)a5)->childMask;
      v64 = *(_QWORD *)(*(_QWORD *)(*(_QWORD *)(v46 + 16) + 32LL) + 16LL * *(unsigned int *)(v46 + 4));
      v80 = 2 * *(_DWORD *)(v64 + 12LL * *(unsigned __int8 *)(a5 + 8));
      na = 2 * *(_DWORD *)(v64 + 12LL * *(unsigned __int8 *)(a5 + 8) + 4);
      v65 = 2 * *(_DWORD *)(v64 + 12LL * *(unsigned __int8 *)(v46 + 8) + 8);
      for ( i = 0; i != 8; ++i )
      {
        LODWORD(Children) = 1 << i;
        if ( ((unsigned __int8)(1 << i) & childMask) != 0 )
        {
          v69 = i & 1;
          v70 = (i >> 1) & 1;
          LODWORD(Children) = v84.m128_i32[v69] & v83.m128_i32[v70];
          v71 = (i >> 2) & 1;
          if ( ((unsigned int)Children & v82.m128_i32[v71]) != 0 )
          {
            v72 = ((73856093 * (v80 | (unsigned int)v69))
                 ^ (19349663 * (na | (unsigned int)v70))
                 ^ (83492791 * (v65 | (unsigned int)v71)))
                & (LODWORD(v62->sizes.mSize) - 1);
            Children = (RBX::Collision::CellChildren *)v62->sizes.mData[v72];
            if ( v62->sizes.mData[v72] )
            {
              v73 = &v62->bins.mData[v72].coords->v[2];
              v74 = 0;
              while ( *(v73 - 2) != (v80 | (unsigned int)v69)
                   || *(v73 - 1) != (na | (unsigned int)v70)
                   || *v73 != (v65 | (unsigned int)v71) )
              {
                ++v74;
                v73 += 3;
                if ( v74 >= (unsigned __int64)Children )
                  goto LABEL_62;
              }
              v67 = (unsigned int)(v69 + 2);
              v68 = !(i & 1);
              if ( (v82.m128_i32[((i >> 2) & 1) + 2]
                  & v83.m128_i32[(i & 2) == 0]
                  & v83.m128_i32[((i >> 1) & 1) + 2]
                  & v84.m128_i32[v67]
                  & v84.m128_i32[v68]
                  & v82.m128_i32[(i & 4) == 0]) != 0 )
              {
                LOBYTE(v89[0]) = 1;
                v89[1] = v72;
                v90 = v74;
                v91 = v62;
                LOBYTE(Children) = RBX::Collision::GridHierarchy::getPrimitivesInBoxDepthFirstInternalSkipOverlapTest<RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlappingRec(RBX::Extents const&,RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>> &)::$_9>(
                                     v81,
                                     (RBX::detail::DenseHashTable<RBX::Primitive *,RBX::Primitive *,RBX::detail::ItemInterfaceSet<RBX::Primitive *>,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *> > *)v76.container,
                                     *((int *)&v76.index + 3),
                                     (__int64)v89);
              }
              else
              {
                v85 = 1;
                v86 = v72;
                v87 = v74;
                v88 = v62;
                LOBYTE(Children) = RBX::Collision::GridHierarchy::getPrimitivesInBoxDepthFirstInternalDoOverlapTest<RBX::Collision::SpatialHashHierarchical::getPrimitivesOverlappingRec(RBX::Extents const&,RBX::DenseHashSet<RBX::Primitive *,boost::hash<RBX::Primitive *>,std::equal_to<RBX::Primitive *>> &)::$_9>(
                                     (_DWORD)v81,
                                     v76.container,
                                     (_DWORD)a3,
                                     *((_DWORD *)&v76.index + 3),
                                     (unsigned int)&v85,
                                     v68,
                                     v76,
                                     na,
                                     v80,
                                     (_DWORD)v81,
                                     v82.m128_u32[0],
                                     v82.m128_i32[2],
                                     v83.m128_u32[0],
                                     v83.m128_i32[2],
                                     v84.m128_u32[0]);
              }
            }
          }
        }
LABEL_62:
        ;
      }
    }
  }
  return (char)Children;
}


// Address: 0x1dfe910 | Name: _ZN3RBX9Collision21OptimizedBinContainerINS0_12CellChildrenELi2ELi4EEC2Em
void __fastcall RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4>::OptimizedBinContainer(
        RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4> *this,
        size_t binCount)
{
  const boost::unordered::detail::false_type *v3; // rax
  __int64 v4; // rcx
  const boost::unordered::detail::false_type *v5; // rdx
  __int64 v6; // rsi
  size_t *v7; // rdx
  RBX::Collision::CellChildren *Aligned; // rax
  RBX::Collision::CellChildren *v9; // r15
  size_t mCapacity; // rax
  std::array<RBX::Collision::CellChildren,2> *v11; // rax
  std::array<RBX::Collision::CellChildren,2> *v12; // r15

  *(_OWORD *)((char *)&this->element0.mSize + 1) = 0;
  this->element0.RBX::ArrayBase<RBX::Collision::CellChildren> = 0;
  this->element0.mAlignment = 16;
  *(_OWORD *)((char *)&this->firstOverflow.mSize + 1) = 0;
  this->firstOverflow.RBX::ArrayBase<std::array<RBX::Collision::CellChildren,2> > = 0;
  this->firstOverflow.mAlignment = 16;
  this->secondOverflow.table_.current_ = 0;
  v3 = &stru_495510;
  v4 = 38;
  do
  {
    v5 = v3;
    v6 = v4 + ~(v4 / 2);
    if ( *(_QWORD *)&v3[8 * (v4 / 2)].gap0 >= 0xBu )
      v6 = v4 / 2;
    v3 += 8 * (v4 / 2) + 8;
    if ( *(_QWORD *)&v5[8 * (v4 / 2)].gap0 >= 0xBu )
      v3 = v5;
    v4 = v6;
  }
  while ( v6 );
  v7 = (size_t *)&v3[-8];
  if ( v3 != (const boost::unordered::detail::false_type *)"N5boost3_bi6bind_tIvNS_4_mfi3mf0IvN3RBX13RCCMonitoringEEENS0_"
                                                           "5list1INS0_5valueIPS5_EEEEEE" )
    v7 = (size_t *)v3;
  this->secondOverflow.table_.bucket_count_ = *v7;
  this->secondOverflow.table_.size_ = 0;
  this->secondOverflow.table_.mlf_ = 1.0;
  *(_OWORD *)&this->secondOverflow.table_.max_load_ = 0;
  if ( !binCount )
    goto LABEL_15;
  Aligned = (RBX::Collision::CellChildren *)RBX::Memory::allocateAligned(binCount, 0x10u);
  v9 = Aligned;
  if ( Aligned )
  {
    memcpy(Aligned, this->element0.mData, this->element0.mSize);
    if ( this->element0.mCapacity )
      RBX::Memory::deallocateAligned(this->element0.mData);
    this->element0.mData = v9;
    this->element0.mCapacity = binCount;
    goto LABEL_15;
  }
  if ( this->element0.mCapacity >= binCount )
LABEL_15:
    this->element0.mSize = binCount;
  if ( this->firstOverflow.mSize < binCount )
  {
    mCapacity = this->firstOverflow.mCapacity;
    if ( mCapacity < binCount )
    {
      if ( 2 * binCount )
      {
        v11 = (std::array<RBX::Collision::CellChildren,2> *)RBX::Memory::allocateAligned(
                                                              2 * binCount,
                                                              this->firstOverflow.mAlignment);
        v12 = v11;
        if ( v11 )
        {
          memcpy(v11, this->firstOverflow.mData, 2 * this->firstOverflow.mSize);
          if ( this->firstOverflow.mCapacity )
            RBX::Memory::deallocateAligned(this->firstOverflow.mData);
          this->firstOverflow.mData = v12;
          this->firstOverflow.mCapacity = binCount;
          goto LABEL_25;
        }
        mCapacity = this->firstOverflow.mCapacity;
      }
      if ( mCapacity < binCount )
        return;
    }
  }
LABEL_25:
  this->firstOverflow.mSize = binCount;
}


// Address: 0x1dfeaa0 | Name: _ZN3RBX9Collision21OptimizedBinContainerINS0_12CellChildrenELi2ELi4EED2Ev
void __fastcall RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4>::~OptimizedBinContainer(
        RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4> *this)
{
  boost::unordered::detail::ptr_bucket::link_pointer i; // rbx
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::CellChildren *> >,unsigned long,RBX::Collision::CellChildren *,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // r15
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket *next; // rdi

  if ( this->secondOverflow.table_.size_ )
  {
    for ( i = this->secondOverflow.table_.buckets_[this->secondOverflow.table_.bucket_count_].next_; i; i = i->next_ )
      RBX::Memory::deallocate(i[3].next_);
  }
  buckets = this->secondOverflow.table_.buckets_;
  if ( buckets )
  {
    if ( this->secondOverflow.table_.size_ )
    {
      bucket_count = this->secondOverflow.table_.bucket_count_;
      next = buckets[bucket_count].next_;
      do
      {
        buckets[bucket_count] = (boost::unordered::detail::ptr_bucket)next->next_;
        operator delete(next);
        --this->secondOverflow.table_.size_;
        next = buckets[bucket_count].next_;
      }
      while ( next );
      buckets = this->secondOverflow.table_.buckets_;
    }
    operator delete(buckets);
    *(_OWORD *)&this->secondOverflow.table_.max_load_ = 0;
  }
  this->firstOverflow.mSize = 0;
  if ( this->firstOverflow.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->firstOverflow.mData);
    this->firstOverflow.mCapacity = 0;
    this->firstOverflow.mData = 0;
  }
  this->element0.mSize = 0;
  if ( this->element0.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->element0.mData);
    this->element0.mCapacity = 0;
    this->element0.mData = 0;
  }
}


// Address: 0x1dfec40 | Name: _ZN3RBX9Collision14CellPrimitives5clearERNS0_9ArrayPoolIPNS_9PrimitiveEEE
void __fastcall RBX::Collision::CellPrimitives::clear(
        RBX::Collision::CellPrimitives *this,
        RBX::Collision::ArrayPool<RBX::Primitive *> *pool)
{
  RBX::Primitive **heapArray; // r15
  uint32_t v4; // eax
  unsigned int v5; // eax
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *v6; // rbx
  size_t mSize; // rax
  size_t mCapacity; // rcx
  bool v9; // zf
  size_t v10; // rax
  __int64 v11; // rdx
  __int64 v12; // rcx
  size_t v13; // rsi
  uint32_t count; // eax
  RBX::Primitive **v15; // r15
  unsigned int v16; // eax
  unsigned int v17; // eax
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *v18; // rbx
  size_t v19; // rax
  size_t v20; // rcx
  size_t v21; // rax
  __int64 v22; // rdx
  __int64 v23; // rcx
  size_t v24; // rsi

  if ( this->groundedPrims.count >= 2 )
  {
    heapArray = this->groundedPrims.heapArray;
    v4 = (this->groundedPrims.count - 1)
       | ((this->groundedPrims.count - 1) >> 1)
       | (((this->groundedPrims.count - 1) | ((this->groundedPrims.count - 1) >> 1)) >> 2);
    v5 = v4 | (v4 >> 4) | ((v4 | (v4 >> 4)) >> 8);
    v6 = pool->pools.mData[((v5 | HIWORD(v5)) + 1) << ((((v5 | HIWORD(v5)) + 1) & 0x55555555) == 0)];
    mSize = v6->freePool.mSize;
    mCapacity = v6->freePool.mCapacity;
    if ( mCapacity == mSize )
    {
      v9 = mCapacity == 0;
      v10 = mCapacity + 1;
      v11 = 2 * mCapacity;
      v12 = 2;
      if ( !v9 )
        v12 = v11;
      do
      {
        v13 = v12;
        v12 *= 2;
      }
      while ( v13 < v10 );
      RBX::ArrayDynamic<void *>::reserve(&v6->freePool, v13);
      mSize = v6->freePool.mSize;
    }
    v6->freePool.mData[mSize] = heapArray;
    v6->freePool.mSize = mSize + 1;
  }
  this->groundedPrims.count = 0;
  count = this->dynamicPrims.count;
  if ( count >= 2 )
  {
    v15 = this->dynamicPrims.heapArray;
    v16 = (count - 1) | ((count - 1) >> 1) | (((count - 1) | ((count - 1) >> 1)) >> 2);
    v17 = v16 | (v16 >> 4) | ((v16 | (v16 >> 4)) >> 8);
    v18 = pool->pools.mData[((v17 | HIWORD(v17)) + 1) << ((((v17 | HIWORD(v17)) + 1) & 0x55555555) == 0)];
    v19 = v18->freePool.mSize;
    v20 = v18->freePool.mCapacity;
    if ( v20 == v19 )
    {
      v9 = v20 == 0;
      v21 = v20 + 1;
      v22 = 2 * v20;
      v23 = 2;
      if ( !v9 )
        v23 = v22;
      do
      {
        v24 = v23;
        v23 *= 2;
      }
      while ( v24 < v21 );
      RBX::ArrayDynamic<void *>::reserve(&v18->freePool, v24);
      v19 = v18->freePool.mSize;
    }
    v18->freePool.mData[v19] = v15;
    v18->freePool.mSize = v19 + 1;
  }
  this->dynamicPrims.count = 0;
}


// Address: 0x1dfeea0 | Name: _ZN3RBX9Collision21OptimizedBinContainerINS0_12CellChildrenELi2ELi4EE15increaseBinSizeEmm
void __fastcall RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4>::increaseBinSize(
        RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4> *this,
        size_t bin,
        size_t oldSize)
{
  size_t v4; // r15
  boost::unordered::detail::ptr_bucket *v5; // r14
  size_t bucket_count; // rsi
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  boost::unordered::detail::ptr_bucket::link_pointer i; // rbx
  std::pair<const unsigned long,RBX::Collision::CellChildren *> args; // [rsp+8h] [rbp-30h] BYREF

  if ( oldSize >= 3 )
  {
    if ( oldSize == 3 )
    {
      args.first = bin;
      args.second = (RBX::Collision::CellChildren *)RBX::Memory::allocate(4u);
      boost::unordered::detail::table_impl<boost::unordered::detail::map<std::allocator<std::pair<unsigned long const,RBX::Collision::CellChildren *>>,unsigned long,RBX::Collision::CellChildren *,boost::hash<unsigned long>,std::equal_to<unsigned long>>>::emplace_impl<std::pair<unsigned long const,RBX::Collision::CellChildren *>>(
        &this->secondOverflow.table_,
        &args.first,
        &args);
    }
    else
    {
      v4 = oldSize - 3;
      if ( oldSize - 3 >= 4 && (v4 & (oldSize - 4)) == 0 )
      {
        v5 = (boost::unordered::detail::ptr_bucket *)RBX::Memory::allocate(2 * v4);
        bucket_count = this->secondOverflow.table_.bucket_count_;
        if ( this->secondOverflow.table_.size_ )
        {
          next = this->secondOverflow.table_.buckets_[bin % bucket_count].next_;
          if ( next )
          {
            for ( i = next->next_; i; i = i->next_ )
            {
              if ( i[1].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)bin )
              {
                if ( i[2].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)bin )
                  goto LABEL_16;
              }
              else if ( (size_t)i[1].next_ % bucket_count != bin % bucket_count )
              {
                break;
              }
            }
          }
        }
        i = 0;
LABEL_16:
        memcpy(v5, i[3].next_, v4);
        RBX::Memory::deallocate(i[3].next_);
        i[3].next_ = v5;
      }
    }
  }
}


// Address: 0x1dfef90 | Name: _ZN3RBX9Collision21OptimizedBinContainerINS0_12CellChildrenELi2ELi4EE15decreaseBinSizeEmm
void __fastcall RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4>::decreaseBinSize(
        RBX::Collision::OptimizedBinContainer<RBX::Collision::CellChildren,2,4> *this,
        size_t bin,
        size_t oldSize)
{
  size_t bucket_count; // rdi
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  boost::unordered::detail::ptr_bucket::link_pointer i; // r13
  boost::unordered::detail::ptr_bucket *v7; // r12
  size_t v8; // r15
  boost::unordered::detail::ptr_bucket::link_pointer v9; // rax
  boost::unordered::detail::ptr_bucket *v10; // rbx
  boost::unordered::detail::table<boost::unordered::detail::map<std::allocator<std::pair<const unsigned long,RBX::Collision::CellChildren *> >,unsigned long,RBX::Collision::CellChildren *,boost::hash<unsigned long>,std::equal_to<unsigned long> > >::bucket_pointer buckets; // rax
  size_t v12; // rdx

  if ( oldSize == 4 )
  {
    bucket_count = this->secondOverflow.table_.bucket_count_;
    if ( this->secondOverflow.table_.size_ )
    {
      next = this->secondOverflow.table_.buckets_[bin % bucket_count].next_;
      if ( next )
      {
        for ( i = next->next_; i; i = i->next_ )
        {
          if ( i[1].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)bin )
          {
            if ( i[2].next_ == (boost::unordered::detail::ptr_bucket::link_pointer)bin )
              goto LABEL_12;
          }
          else if ( (size_t)i[1].next_ % bucket_count != bin % bucket_count )
          {
            break;
          }
        }
      }
    }
    i = 0;
LABEL_12:
    RBX::Memory::deallocate(i[3].next_);
    v7 = i->next_;
    v8 = (unsigned __int64)i[1].next_ % this->secondOverflow.table_.bucket_count_;
    v9 = this->secondOverflow.table_.buckets_[v8].next_;
    do
    {
      v10 = v9;
      v9 = v9->next_;
    }
    while ( v9 != i );
    do
    {
      v10->next_ = i->next_;
      operator delete(i);
      --this->secondOverflow.table_.size_;
      if ( v10->next_ )
      {
        v12 = (unsigned __int64)v10->next_[1].next_ % this->secondOverflow.table_.bucket_count_;
        if ( v12 == v8 )
        {
          v12 = v8;
        }
        else
        {
          buckets = this->secondOverflow.table_.buckets_;
          buckets[v12].next_ = v10;
          if ( buckets[v8].next_ == v10 )
            goto LABEL_21;
        }
      }
      else
      {
        buckets = this->secondOverflow.table_.buckets_;
        v12 = v8;
        if ( buckets[v8].next_ == v10 )
LABEL_21:
          buckets[v8].next_ = 0;
      }
      i = v10->next_;
      v8 = v12;
    }
    while ( v10->next_ != v7 );
  }
}


// Address: 0x1dff0b0 | Name: _ZN3RBX9Collision9LevelGrid11getChildrenERKNS1_9CellIndexE
RBX::Collision::CellChildren *__fastcall RBX::Collision::LevelGrid::getChildren(
        RBX::Collision::LevelGrid *this,
        const RBX::Collision::LevelGrid::CellIndex *n)
{
  unsigned __int64 data; // rcx
  __int64 nodeIndex; // r8
  size_t bucket_count; // rbx
  boost::unordered::detail::ptr_bucket::link_pointer next; // rax
  _QWORD *p_next; // rdi
  _QWORD v9[3]; // [rsp+0h] [rbp-18h] BYREF

  data = n->binIndex.data;
  nodeIndex = n->nodeIndex;
  if ( !n->nodeIndex )
    return &this->children.element0.mData[data];
  if ( (unsigned __int8)nodeIndex > 2u )
  {
    if ( !this->children.secondOverflow.table_.size_
      || (bucket_count = this->children.secondOverflow.table_.bucket_count_,
          (next = this->children.secondOverflow.table_.buckets_[data % bucket_count].next_) == 0)
      || (p_next = &next->next_->next_) == 0 )
    {
LABEL_13:
      std::logic_error::logic_error((std::logic_error *)v9, "Unable to find key in unordered_map.");
      v9[0] = (char *)&`vtable for'std::out_of_range + 16;
      boost::throw_exception<std::out_of_range>((const std::out_of_range *)v9);
    }
    while ( 1 )
    {
      if ( p_next[1] == data )
      {
        if ( p_next[2] == data )
          return (RBX::Collision::CellChildren *)(p_next[3] + nodeIndex - 3);
      }
      else if ( p_next[1] % bucket_count != data % bucket_count )
      {
        goto LABEL_13;
      }
      p_next = (_QWORD *)*p_next;
      if ( !p_next )
        goto LABEL_13;
    }
  }
  return &this->children.firstOverflow.mData[data - 1].__elems_[nodeIndex + 1];
}


// Address: 0x1dff1b0 | Name: _ZN3RBX9Collision16SpatialHashPoolsD2Ev
void __fastcall RBX::Collision::SpatialHashPools::~SpatialHashPools(RBX::Collision::SpatialHashPools *this)
{
  size_t mSize; // r15
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool **mData; // r12
  __int64 v3; // r15
  unsigned __int64 v4; // rbx
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *v5; // r13
  size_t v6; // r15
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool **v7; // r12
  __int64 v8; // r15
  unsigned __int64 v9; // rbx
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool *v10; // r13
  size_t v11; // r15
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool **v12; // r12
  __int64 v13; // r15
  unsigned __int64 v14; // rbx
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool *v15; // r13

  mSize = this->primitiveArrayPool.pools.mSize;
  if ( mSize )
  {
    mData = this->primitiveArrayPool.pools.mData;
    v3 = 8 * mSize;
    v4 = 0;
    do
    {
      v5 = mData[v4 / 8];
      if ( v5 )
      {
        RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::~Pool(mData[v4 / 8]);
        operator delete(v5);
      }
      v4 += 8LL;
    }
    while ( v3 != v4 );
  }
  this->primitiveArrayPool.pools.mSize = 0;
  if ( this->primitiveArrayPool.pools.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->primitiveArrayPool.pools.mData);
    this->primitiveArrayPool.pools.mCapacity = 0;
    this->primitiveArrayPool.pools.mData = 0;
  }
  v6 = this->cellPrimitiveArrayPool.pools.mSize;
  if ( v6 )
  {
    v7 = this->cellPrimitiveArrayPool.pools.mData;
    v8 = 8 * v6;
    v9 = 0;
    do
    {
      v10 = v7[v9 / 8];
      if ( v10 )
      {
        RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::~Pool(v7[v9 / 8]);
        operator delete(v10);
      }
      v9 += 8LL;
    }
    while ( v8 != v9 );
  }
  this->cellPrimitiveArrayPool.pools.mSize = 0;
  if ( this->cellPrimitiveArrayPool.pools.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->cellPrimitiveArrayPool.pools.mData);
    this->cellPrimitiveArrayPool.pools.mCapacity = 0;
    this->cellPrimitiveArrayPool.pools.mData = 0;
  }
  v11 = this->coordArrayPool.pools.mSize;
  if ( v11 )
  {
    v12 = this->coordArrayPool.pools.mData;
    v13 = 8 * v11;
    v14 = 0;
    do
    {
      v15 = v12[v14 / 8];
      if ( v15 )
      {
        RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::~Pool(v12[v14 / 8]);
        operator delete(v15);
      }
      v14 += 8LL;
    }
    while ( v13 != v14 );
  }
  this->coordArrayPool.pools.mSize = 0;
  if ( this->coordArrayPool.pools.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->coordArrayPool.pools.mData);
    this->coordArrayPool.pools.mCapacity = 0;
    this->coordArrayPool.pools.mData = 0;
  }
}


// Address: 0x1dff4d0 | Name: _ZN3RBX9Collision9ArrayPoolINS0_14CellPrimitivesEE4PoolD2Ev
void __fastcall RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::~Pool(
        RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool *this)
{
  size_t mSize; // r14
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *mData; // r12
  __int64 v3; // r14
  unsigned __int64 v4; // rbx

  mSize = this->buckets.mSize;
  if ( mSize )
  {
    mData = this->buckets.mData;
    v3 = 16 * mSize;
    v4 = 0;
    do
    {
      RBX::Memory::deallocate(mData[v4 / 0x10].memory);
      mData[v4 / 0x10] = 0;
      v4 += 16LL;
    }
    while ( v3 != v4 );
  }
  this->freePool.mSize = 0;
  if ( this->freePool.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->freePool.mData);
    this->freePool.mCapacity = 0;
    this->freePool.mData = 0;
  }
  this->buckets.mSize = 0;
  if ( this->buckets.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->buckets.mData);
    this->buckets.mCapacity = 0;
    this->buckets.mData = 0;
  }
}


// Address: 0x1dff610 | Name: _ZN3RBX9Collision9ArrayPoolINS0_9CellCoordEE4PoolD2Ev
void __fastcall RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::~Pool(
        RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool *this)
{
  size_t mSize; // r14
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *mData; // r12
  __int64 v3; // r14
  unsigned __int64 v4; // rbx

  mSize = this->buckets.mSize;
  if ( mSize )
  {
    mData = this->buckets.mData;
    v3 = 16 * mSize;
    v4 = 0;
    do
    {
      RBX::Memory::deallocate(mData[v4 / 0x10].memory);
      mData[v4 / 0x10] = 0;
      v4 += 16LL;
    }
    while ( v3 != v4 );
  }
  this->freePool.mSize = 0;
  if ( this->freePool.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->freePool.mData);
    this->freePool.mCapacity = 0;
    this->freePool.mData = 0;
  }
  this->buckets.mSize = 0;
  if ( this->buckets.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->buckets.mData);
    this->buckets.mCapacity = 0;
    this->buckets.mData = 0;
  }
}


// Address: 0x1dff710 | Name: _ZN3RBX9Collision9ArrayPoolIPNS_9PrimitiveEE4PoolD2Ev
void __fastcall RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::~Pool(
        RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *this)
{
  size_t mSize; // r14
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *mData; // r12
  __int64 v3; // r14
  unsigned __int64 v4; // rbx

  mSize = this->buckets.mSize;
  if ( mSize )
  {
    mData = this->buckets.mData;
    v3 = 16 * mSize;
    v4 = 0;
    do
    {
      RBX::Memory::deallocate(mData[v4 / 0x10].memory);
      mData[v4 / 0x10] = 0;
      v4 += 16LL;
    }
    while ( v3 != v4 );
  }
  this->freePool.mSize = 0;
  if ( this->freePool.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->freePool.mData);
    this->freePool.mCapacity = 0;
    this->freePool.mData = 0;
  }
  this->buckets.mSize = 0;
  if ( this->buckets.mCapacity )
  {
    RBX::Memory::deallocateAligned(this->buckets.mData);
    this->buckets.mCapacity = 0;
    this->buckets.mData = 0;
  }
}


// Address: 0x1dff810 | Name: _ZN3RBX9Collision20ShortArrayOfPointersINS_9PrimitiveEE9push_backEPS2_RNS0_9ArrayPoolIS4_EE
void __fastcall RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::push_back(
        RBX::Collision::ShortArrayOfPointers<RBX::Primitive> *this,
        RBX::Primitive *p,
        RBX::Collision::ArrayPool<RBX::Primitive *> *pool)
{
  RBX::Primitive **v4; // r14
  uint32_t v5; // esi
  RBX::Primitive **heapArray; // r15
  RBX::Primitive **v7; // rax
  void *v8; // r15
  RBX::Primitive **v9; // r13
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *v10; // r12
  size_t mSize; // rax
  size_t mCapacity; // rcx
  bool v13; // zf
  unsigned __int64 v14; // rax
  __int64 v15; // rdx
  __int64 v16; // rcx

  v4 = (RBX::Primitive **)p;
  LODWORD(p) = this->count;
  if ( this->count == 1 )
  {
    heapArray = this->heapArray;
    v7 = (RBX::Primitive **)RBX::Collision::ArrayPool<RBX::Primitive *>::allocate(pool, 4u);
    this->heapArray = v7;
    *v7 = (RBX::Primitive *)heapArray;
    *((_QWORD *)this->heapArray + 1) = v4;
    LODWORD(p) = this->count;
LABEL_15:
    v5 = (_DWORD)p + 1;
    goto LABEL_16;
  }
  if ( (_DWORD)p )
  {
    if ( ((unsigned int)p & 0x55555555) == 0 || ((unsigned int)p & ((_DWORD)p - 1)) != 0 )
    {
      v8 = this->heapArray;
    }
    else
    {
      v8 = RBX::Collision::ArrayPool<RBX::Primitive *>::allocate(pool, (unsigned int)(4 * (_DWORD)p));
      memcpy(v8, this->heapArray, 8LL * this->count);
      v9 = this->heapArray;
      p = (RBX::Primitive *)this->count;
      v10 = pool->pools.mData[(_QWORD)p];
      mSize = v10->freePool.mSize;
      mCapacity = v10->freePool.mCapacity;
      if ( mCapacity == mSize )
      {
        v13 = mCapacity == 0;
        v14 = mCapacity + 1;
        v15 = 2 * mCapacity;
        v16 = 2;
        if ( !v13 )
          v16 = v15;
        do
        {
          p = (RBX::Primitive *)v16;
          v16 *= 2;
        }
        while ( (unsigned __int64)p < v14 );
        RBX::ArrayDynamic<void *>::reserve(&v10->freePool, (size_t)p);
        mSize = v10->freePool.mSize;
        LODWORD(p) = this->count;
      }
      v10->freePool.mData[mSize] = v9;
      v10->freePool.mSize = mSize + 1;
      this->heapArray = (RBX::Primitive **)v8;
    }
    *((_QWORD *)v8 + (unsigned int)p) = v4;
    goto LABEL_15;
  }
  this->heapArray = v4;
  v5 = 1;
LABEL_16:
  this->count = v5;
}


// Address: 0x1dff920 | Name: _ZN3RBX9Collision9ArrayPoolIPNS_9PrimitiveEE8allocateEm
void *__fastcall RBX::Collision::ArrayPool<RBX::Primitive *>::allocate(
        RBX::Collision::ArrayPool<RBX::Primitive *> *this,
        size_t size)
{
  size_t i; // rbx
  char *v4; // r13
  unsigned __int64 v5; // rax
  __int64 v6; // rax
  size_t v7; // rsi

  for ( i = this->pools.mSize; i <= size; this->pools.mSize = i )
  {
    v4 = (char *)operator new(0x50u);
    *(_OWORD *)(v4 + 9) = 0;
    *(_OWORD *)v4 = 0;
    *((_DWORD *)v4 + 7) = 16;
    *(_OWORD *)(v4 + 41) = 0;
    *((_OWORD *)v4 + 2) = 0;
    *((_DWORD *)v4 + 15) = 16;
    *((_DWORD *)v4 + 16) = i;
    if ( (int)i <= 0 )
      v5 = 0;
    else
      v5 = 8LL * (int)i * (0x400uLL / (8LL * (int)i) + 1);
    *((_QWORD *)v4 + 9) = v5;
    if ( this->pools.mCapacity == i )
    {
      v6 = 2 * i;
      if ( !i )
        v6 = 2;
      do
      {
        v7 = v6;
        v6 *= 2;
      }
      while ( v7 < i + 1 );
      RBX::ArrayDynamic<RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *>::reserve(&this->pools, v7);
      i = this->pools.mSize;
    }
    this->pools.mData[i++] = (RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *)v4;
  }
  return RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::allocate(this->pools.mData[size]);
}


// Address: 0x1dffa10 | Name: _ZN3RBX9Collision9ArrayPoolIPNS_9PrimitiveEE4Pool8allocateEv
void *__fastcall RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::allocate(
        RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *this)
{
  size_t mSize; // rcx
  void *result; // rax
  size_t v4; // rax
  void *v5; // r14
  size_t mCapacity; // rax
  __int64 v7; // rdx
  size_t v8; // rbx
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *Aligned; // rax
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *v10; // r15
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *mData; // rax
  size_t v12; // rcx
  size_t v13; // rax
  size_t bucketMemorySize; // rdi
  __int64 v15; // r12
  void *v16; // r14
  size_t v17; // rax
  __int64 v18; // rdx
  size_t v19; // rbx
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *v20; // rax
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *v21; // r15
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *v22; // rax
  size_t v23; // rcx
  size_t v24; // rcx
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *v25; // rcx

  mSize = this->freePool.mSize;
  if ( mSize )
  {
    result = this->freePool.mData[mSize - 1];
    this->freePool.mSize = mSize - 1;
  }
  else
  {
    v4 = this->buckets.mSize;
    if ( !v4 )
    {
      v5 = RBX::Memory::allocate(this->bucketMemorySize);
      mCapacity = this->buckets.mCapacity;
      if ( mCapacity == this->buckets.mSize )
      {
        v7 = 2;
        if ( mCapacity )
          v7 = 2 * mCapacity;
        do
        {
          v8 = v7;
          v7 *= 2;
        }
        while ( v8 < mCapacity + 1 );
        if ( mCapacity < v8 )
        {
          if ( 16 * v8 )
          {
            Aligned = (RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *)RBX::Memory::allocateAligned(
                                                                                     16 * v8,
                                                                                     this->buckets.mAlignment);
            v10 = Aligned;
            if ( Aligned )
            {
              memcpy(Aligned, this->buckets.mData, 16 * this->buckets.mSize);
              if ( this->buckets.mCapacity )
                RBX::Memory::deallocateAligned(this->buckets.mData);
              this->buckets.mData = v10;
              this->buckets.mCapacity = v8;
            }
          }
        }
      }
      mData = this->buckets.mData;
      v12 = this->buckets.mSize;
      mData[v12].memory = v5;
      mData[v12].current = v5;
      v4 = this->buckets.mSize + 1;
      this->buckets.mSize = v4;
    }
    v13 = v4;
    bucketMemorySize = this->bucketMemorySize;
    v15 = 8LL * this->arraySizes;
    if ( (char *)this->buckets.mData[v13 - 1].current + v15 <= (char *)this->buckets.mData[v13 - 1].memory
                                                             + bucketMemorySize )
    {
      v25 = &this->buckets.mData[v13 - 1];
    }
    else
    {
      v16 = RBX::Memory::allocate(bucketMemorySize);
      v17 = this->buckets.mCapacity;
      if ( v17 == this->buckets.mSize )
      {
        v18 = 2;
        if ( v17 )
          v18 = 2 * v17;
        do
        {
          v19 = v18;
          v18 *= 2;
        }
        while ( v19 < v17 + 1 );
        if ( v17 < v19 )
        {
          if ( 16 * v19 )
          {
            v20 = (RBX::Collision::ArrayPool<RBX::Primitive *>::Pool::Bucket *)RBX::Memory::allocateAligned(
                                                                                 16 * v19,
                                                                                 this->buckets.mAlignment);
            v21 = v20;
            if ( v20 )
            {
              memcpy(v20, this->buckets.mData, 16 * this->buckets.mSize);
              if ( this->buckets.mCapacity )
                RBX::Memory::deallocateAligned(this->buckets.mData);
              this->buckets.mData = v21;
              this->buckets.mCapacity = v19;
            }
          }
        }
      }
      v22 = this->buckets.mData;
      v23 = this->buckets.mSize;
      v22[v23].memory = v16;
      v22[v23].current = v16;
      v24 = this->buckets.mSize;
      this->buckets.mSize = v24 + 1;
      v25 = &this->buckets.mData[v24];
    }
    result = v25->current;
    v25->current = (char *)result + v15;
  }
  return result;
}


// Address: 0x1dfff90 | Name: _ZN3RBX9Collision20ShortArrayOfPointersINS_9PrimitiveEE6removeEPKS2_RNS0_9ArrayPoolIPS2_EE
void __fastcall RBX::Collision::ShortArrayOfPointers<RBX::Primitive>::remove(
        RBX::Collision::ShortArrayOfPointers<RBX::Primitive> *this,
        const RBX::Primitive *p,
        RBX::Collision::ArrayPool<RBX::Primitive *> *pool)
{
  uint32_t count; // eax
  __int64 v6; // rcx
  __int64 v7; // rdx
  RBX::Primitive **heapArray; // rdi
  uint32_t v9; // esi
  RBX::Primitive **v10; // r12
  RBX::Primitive **v11; // r15
  RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *v12; // r14
  size_t mSize; // rax
  size_t mCapacity; // rcx
  RBX::ArrayDynamic<void *> *p_freePool; // rdi
  bool v16; // zf
  size_t v17; // rax
  __int64 v18; // rdx
  __int64 v19; // rcx
  size_t v20; // rsi
  RBX::Primitive **v21; // rax
  __int64 v22; // rax
  size_t v23; // rcx
  size_t v24; // rax
  __int64 v25; // rdx
  __int64 v26; // rcx

  count = this->count;
  if ( this->count )
  {
    if ( count == 1 )
    {
      if ( this->local == p )
        this->count = 0;
      return;
    }
    v6 = 0;
    do
    {
      v7 = v6;
      if ( (unsigned int)v6 >= count )
        return;
      heapArray = this->heapArray;
      ++v6;
    }
    while ( heapArray[(unsigned int)v7] != p );
    v9 = count - 1;
    if ( (unsigned int)v6 < count )
      heapArray[v7] = heapArray[v9];
    this->count = v9;
    if ( count == 2 )
    {
      v10 = this->heapArray;
      v11 = (RBX::Primitive **)*v10;
      v12 = (RBX::Collision::ArrayPool<RBX::Primitive *>::Pool *)*((_QWORD *)pool->pools.mData + 4);
      mSize = v12->freePool.mSize;
      mCapacity = v12->freePool.mCapacity;
      if ( mCapacity != mSize )
      {
LABEL_16:
        v12->freePool.mData[mSize] = v10;
        v12->freePool.mSize = mSize + 1;
        this->heapArray = v11;
        return;
      }
      p_freePool = &v12->freePool;
      v16 = mCapacity == 0;
      v17 = mCapacity + 1;
      v18 = 2 * mCapacity;
      v19 = 2;
      if ( !v16 )
        v19 = v18;
      do
      {
        v20 = v19;
        v19 *= 2;
      }
      while ( v20 < v17 );
LABEL_15:
      RBX::ArrayDynamic<void *>::reserve(p_freePool, v20);
      mSize = v12->freePool.mSize;
      goto LABEL_16;
    }
    if ( v9 >= 4 && (v9 & 0x55555555) != 0 && (v9 & (count - 2)) == 0 )
    {
      v21 = (RBX::Primitive **)RBX::Collision::ArrayPool<RBX::Primitive *>::allocate(pool, v9);
      v11 = v21;
      if ( this->count )
      {
        memcpy(v21, this->heapArray, 8LL * this->count);
        v22 = 4 * this->count;
      }
      else
      {
        v22 = 0;
      }
      v10 = this->heapArray;
      v12 = pool->pools.mData[v22];
      mSize = v12->freePool.mSize;
      v23 = v12->freePool.mCapacity;
      if ( v23 != mSize )
        goto LABEL_16;
      p_freePool = &v12->freePool;
      v16 = v23 == 0;
      v24 = v23 + 1;
      v25 = 2 * v23;
      v26 = 2;
      if ( !v16 )
        v26 = v25;
      do
      {
        v20 = v26;
        v26 *= 2;
      }
      while ( v20 < v24 );
      goto LABEL_15;
    }
  }
}


// Address: 0x1e001f0 | Name: _ZN3RBX9Collision9ArrayPoolINS0_9CellCoordEE8allocateEm
void *__fastcall RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::allocate(
        RBX::Collision::ArrayPool<RBX::Collision::CellCoord> *this,
        size_t size)
{
  size_t i; // rbx
  char *v4; // r13
  unsigned __int64 v5; // rax
  __int64 v6; // rax
  size_t v7; // rsi

  for ( i = this->pools.mSize; i <= size; this->pools.mSize = i )
  {
    v4 = (char *)operator new(0x50u);
    *(_OWORD *)(v4 + 9) = 0;
    *(_OWORD *)v4 = 0;
    *((_DWORD *)v4 + 7) = 16;
    *(_OWORD *)(v4 + 41) = 0;
    *((_OWORD *)v4 + 2) = 0;
    *((_DWORD *)v4 + 15) = 16;
    *((_DWORD *)v4 + 16) = i;
    if ( (int)i <= 0 )
      v5 = 0;
    else
      v5 = 12LL * (int)i * (0x400uLL / (12LL * (int)i) + 1);
    *((_QWORD *)v4 + 9) = v5;
    if ( this->pools.mCapacity == i )
    {
      v6 = 2 * i;
      if ( !i )
        v6 = 2;
      do
      {
        v7 = v6;
        v6 *= 2;
      }
      while ( v7 < i + 1 );
      RBX::ArrayDynamic<RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool *>::reserve(&this->pools, v7);
      i = this->pools.mSize;
    }
    this->pools.mData[i++] = (RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool *)v4;
  }
  return RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::allocate(this->pools.mData[size]);
}


// Address: 0x1e002f0 | Name: _ZN3RBX9Collision9ArrayPoolINS0_9CellCoordEE4Pool8allocateEv
void *__fastcall RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::allocate(
        RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool *this)
{
  size_t mSize; // rcx
  void *result; // rax
  size_t v4; // rax
  void *v5; // r14
  size_t mCapacity; // rax
  __int64 v7; // rdx
  size_t v8; // rbx
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *Aligned; // rax
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *v10; // r15
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *mData; // rax
  size_t v12; // rcx
  size_t v13; // rax
  size_t bucketMemorySize; // rdi
  __int64 v15; // r12
  void *v16; // r14
  size_t v17; // rax
  __int64 v18; // rdx
  size_t v19; // rbx
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *v20; // rax
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *v21; // r15
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *v22; // rax
  size_t v23; // rcx
  size_t v24; // rcx
  RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *v25; // rcx

  mSize = this->freePool.mSize;
  if ( mSize )
  {
    result = this->freePool.mData[mSize - 1];
    this->freePool.mSize = mSize - 1;
  }
  else
  {
    v4 = this->buckets.mSize;
    if ( !v4 )
    {
      v5 = RBX::Memory::allocate(this->bucketMemorySize);
      mCapacity = this->buckets.mCapacity;
      if ( mCapacity == this->buckets.mSize )
      {
        v7 = 2;
        if ( mCapacity )
          v7 = 2 * mCapacity;
        do
        {
          v8 = v7;
          v7 *= 2;
        }
        while ( v8 < mCapacity + 1 );
        if ( mCapacity < v8 )
        {
          if ( 16 * v8 )
          {
            Aligned = (RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *)RBX::Memory::allocateAligned(
                                                                                              16 * v8,
                                                                                              this->buckets.mAlignment);
            v10 = Aligned;
            if ( Aligned )
            {
              memcpy(Aligned, this->buckets.mData, 16 * this->buckets.mSize);
              if ( this->buckets.mCapacity )
                RBX::Memory::deallocateAligned(this->buckets.mData);
              this->buckets.mData = v10;
              this->buckets.mCapacity = v8;
            }
          }
        }
      }
      mData = this->buckets.mData;
      v12 = this->buckets.mSize;
      mData[v12].memory = v5;
      mData[v12].current = v5;
      v4 = this->buckets.mSize + 1;
      this->buckets.mSize = v4;
    }
    v13 = v4;
    bucketMemorySize = this->bucketMemorySize;
    v15 = 12LL * this->arraySizes;
    if ( (char *)this->buckets.mData[v13 - 1].current + v15 <= (char *)this->buckets.mData[v13 - 1].memory
                                                             + bucketMemorySize )
    {
      v25 = &this->buckets.mData[v13 - 1];
    }
    else
    {
      v16 = RBX::Memory::allocate(bucketMemorySize);
      v17 = this->buckets.mCapacity;
      if ( v17 == this->buckets.mSize )
      {
        v18 = 2;
        if ( v17 )
          v18 = 2 * v17;
        do
        {
          v19 = v18;
          v18 *= 2;
        }
        while ( v19 < v17 + 1 );
        if ( v17 < v19 )
        {
          if ( 16 * v19 )
          {
            v20 = (RBX::Collision::ArrayPool<RBX::Collision::CellCoord>::Pool::Bucket *)RBX::Memory::allocateAligned(
                                                                                          16 * v19,
                                                                                          this->buckets.mAlignment);
            v21 = v20;
            if ( v20 )
            {
              memcpy(v20, this->buckets.mData, 16 * this->buckets.mSize);
              if ( this->buckets.mCapacity )
                RBX::Memory::deallocateAligned(this->buckets.mData);
              this->buckets.mData = v21;
              this->buckets.mCapacity = v19;
            }
          }
        }
      }
      v22 = this->buckets.mData;
      v23 = this->buckets.mSize;
      v22[v23].memory = v16;
      v22[v23].current = v16;
      v24 = this->buckets.mSize;
      this->buckets.mSize = v24 + 1;
      v25 = &this->buckets.mData[v24];
    }
    result = v25->current;
    v25->current = (char *)result + v15;
  }
  return result;
}


// Address: 0x1e00870 | Name: _ZN3RBX9Collision9ArrayPoolINS0_14CellPrimitivesEE8allocateEm
void *__fastcall RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::allocate(
        RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives> *this,
        size_t size)
{
  size_t i; // rbx
  char *v4; // r13
  unsigned __int64 v5; // rax
  __int64 v6; // rax
  size_t v7; // rsi

  for ( i = this->pools.mSize; i <= size; this->pools.mSize = i )
  {
    v4 = (char *)operator new(0x50u);
    *(_OWORD *)(v4 + 9) = 0;
    *(_OWORD *)v4 = 0;
    *((_DWORD *)v4 + 7) = 16;
    *(_OWORD *)(v4 + 41) = 0;
    *((_OWORD *)v4 + 2) = 0;
    *((_DWORD *)v4 + 15) = 16;
    *((_DWORD *)v4 + 16) = i;
    if ( (int)i <= 0 )
      v5 = 0;
    else
      v5 = 32LL * (int)i * (0x400uLL / (32LL * (int)i) + 1);
    *((_QWORD *)v4 + 9) = v5;
    if ( this->pools.mCapacity == i )
    {
      v6 = 2 * i;
      if ( !i )
        v6 = 2;
      do
      {
        v7 = v6;
        v6 *= 2;
      }
      while ( v7 < i + 1 );
      RBX::ArrayDynamic<RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool *>::reserve(&this->pools, v7);
      i = this->pools.mSize;
    }
    this->pools.mData[i++] = (RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool *)v4;
  }
  return RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::allocate(this->pools.mData[size]);
}


// Address: 0x1e00960 | Name: _ZN3RBX9Collision9ArrayPoolINS0_14CellPrimitivesEE4Pool8allocateEv
void *__fastcall RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::allocate(
        RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool *this)
{
  size_t mSize; // rcx
  void *result; // rax
  size_t v4; // rax
  void *v5; // r14
  size_t mCapacity; // rax
  __int64 v7; // rdx
  size_t v8; // rbx
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *Aligned; // rax
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *v10; // r15
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *mData; // rax
  size_t v12; // rcx
  size_t v13; // rax
  size_t bucketMemorySize; // rdi
  __int64 v15; // r12
  void *v16; // r14
  size_t v17; // rax
  __int64 v18; // rdx
  size_t v19; // rbx
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *v20; // rax
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *v21; // r15
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *v22; // rax
  size_t v23; // rcx
  size_t v24; // rcx
  RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *v25; // rcx

  mSize = this->freePool.mSize;
  if ( mSize )
  {
    result = this->freePool.mData[mSize - 1];
    this->freePool.mSize = mSize - 1;
  }
  else
  {
    v4 = this->buckets.mSize;
    if ( !v4 )
    {
      v5 = RBX::Memory::allocate(this->bucketMemorySize);
      mCapacity = this->buckets.mCapacity;
      if ( mCapacity == this->buckets.mSize )
      {
        v7 = 2;
        if ( mCapacity )
          v7 = 2 * mCapacity;
        do
        {
          v8 = v7;
          v7 *= 2;
        }
        while ( v8 < mCapacity + 1 );
        if ( mCapacity < v8 )
        {
          if ( 16 * v8 )
          {
            Aligned = (RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *)RBX::Memory::allocateAligned(
                                                                                                   16 * v8,
                                                                                                   this->buckets.mAlignment);
            v10 = Aligned;
            if ( Aligned )
            {
              memcpy(Aligned, this->buckets.mData, 16 * this->buckets.mSize);
              if ( this->buckets.mCapacity )
                RBX::Memory::deallocateAligned(this->buckets.mData);
              this->buckets.mData = v10;
              this->buckets.mCapacity = v8;
            }
          }
        }
      }
      mData = this->buckets.mData;
      v12 = this->buckets.mSize;
      mData[v12].memory = v5;
      mData[v12].current = v5;
      v4 = this->buckets.mSize + 1;
      this->buckets.mSize = v4;
    }
    v13 = v4;
    bucketMemorySize = this->bucketMemorySize;
    v15 = 32LL * this->arraySizes;
    if ( (char *)this->buckets.mData[v13 - 1].current + v15 <= (char *)this->buckets.mData[v13 - 1].memory
                                                             + bucketMemorySize )
    {
      v25 = &this->buckets.mData[v13 - 1];
    }
    else
    {
      v16 = RBX::Memory::allocate(bucketMemorySize);
      v17 = this->buckets.mCapacity;
      if ( v17 == this->buckets.mSize )
      {
        v18 = 2;
        if ( v17 )
          v18 = 2 * v17;
        do
        {
          v19 = v18;
          v18 *= 2;
        }
        while ( v19 < v17 + 1 );
        if ( v17 < v19 )
        {
          if ( 16 * v19 )
          {
            v20 = (RBX::Collision::ArrayPool<RBX::Collision::CellPrimitives>::Pool::Bucket *)RBX::Memory::allocateAligned(
                                                                                               16 * v19,
                                                                                               this->buckets.mAlignment);
            v21 = v20;
            if ( v20 )
            {
              memcpy(v20, this->buckets.mData, 16 * this->buckets.mSize);
              if ( this->buckets.mCapacity )
                RBX::Memory::deallocateAligned(this->buckets.mData);
              this->buckets.mData = v21;
              this->buckets.mCapacity = v19;
            }
          }
        }
      }
      v22 = this->buckets.mData;
      v23 = this->buckets.mSize;
      v22[v23].memory = v16;
      v22[v23].current = v16;
      v24 = this->buckets.mSize;
      this->buckets.mSize = v24 + 1;
      v25 = &this->buckets.mData[v24];
    }
    result = v25->current;
    v25->current = (char *)result + v15;
  }
  return result;
}


// Address: 0x1e01a40 | Name: _GLOBAL__sub_I_SpatialHashHierarchical.cpp
void __cdecl GLOBAL__sub_I_SpatialHashHierarchical_cpp()
{
  qword_2AAF5D0 = (__int64)boost::system::generic_category();
  qword_2AAF5D8 = (__int64)boost::system::generic_category();
  qword_2AAF5E0 = (__int64)boost::system::system_category();
  stru_2AAF5E8.value = 0;
  stru_2AAF5E8.name = "SHUseNewComputeLevel";
  dword_2AAF5F8 = FLog::RegisterFlag("SHUseNewComputeLevel", &stru_2AAF5E8, FastVarType::FASTVARTYPE_STATIC);
  stru_2AAF600.value = 0;
  stru_2AAF600.name = "SHUseNewComputeLevelUsesOBB";
  dword_2AAF610 = FLog::RegisterFlag("SHUseNewComputeLevelUsesOBB", &stru_2AAF600, FastVarType::FASTVARTYPE_STATIC);
  stru_2AAF618.value = 0;
  stru_2AAF618.name = "SHAnalyticsAdjustLevelId";
  dword_2AAF628 = FLog::RegisterFlag("SHAnalyticsAdjustLevelId", &stru_2AAF618, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF62C = FLog::RegisterInt("SHCellMinSizeAsBitShift", &dword_2868B08, FastVarType::FASTVARTYPE_STATIC);
  dword_2AAF630 = FLog::RegisterInt("SHLevelCount", &dword_2868B18, FastVarType::FASTVARTYPE_STATIC);
  dword_2AAF634 = FLog::RegisterInt(
                    "SHNewComputeLevelFixedScaleFactor",
                    &dword_2868B28,
                    FastVarType::FASTVARTYPE_STATIC);
  dword_2AAF638 = FLog::RegisterInt(
                    "SHNewComputeLevelNonFixedScaleFactor",
                    &dword_2868B38,
                    FastVarType::FASTVARTYPE_STATIC);
  dword_2AAF63C = FLog::RegisterInt(
                    "SHNewComputeLevelFatLayerThickness",
                    &dword_2868B48,
                    FastVarType::FASTVARTYPE_STATIC);
  dword_2AAF640 = FLog::RegisterInt("SHMaxNumberOfBinsPowerOf2", &byte_2868B58, FastVarType::FASTVARTYPE_STATIC);
  stru_2AAF648.value = 0;
  stru_2AAF648.name = (char *)&stru_456C2E.userPlatformAPI + 3;
  dword_2AAF658 = FLog::RegisterFlag(
                    (const char *)&stru_456C2E.userPlatformAPI + 3,
                    &stru_2AAF648,
                    FastVarType::FASTVARTYPE_STATIC);
  dword_2AAF65C = FLog::RegisterInt(
                    "SHComputeExtentsTimeReportingAttemptRate",
                    (int *)&attemptRate,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2AAF660.value = 0;
  stru_2AAF660.name = "SHStatReportingEnabled";
  dword_2AAF670 = FLog::RegisterFlag("SHStatReportingEnabled", &stru_2AAF660, FastVarType::FASTVARTYPE_STATIC);
  dword_2AAF674 = FLog::RegisterInt("SHStatReportingThrottlePercent", &dword_2868B88, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF678 = FLog::RegisterInt("SHStatReportingDelaySeconds", &dword_2868B98, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2AAF67C = FLog::RegisterInt(
                    "SHStatReportingAttemptRate",
                    (int *)&dword_2868BA8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2AAF680.value = 0;
  stru_2AAF680.name = "FixParallelCoarseMovementCallbacks";
  dword_2AAF690 = FLog::RegisterFlag(
                    "FixParallelCoarseMovementCallbacks",
                    &stru_2AAF680,
                    FastVarType::FASTVARTYPE_DYNAMIC);
}


