// Address: 0x1e076d0 | Name: _ZN3RBX9Collision17BlockBlockContactD0Ev
void __fastcall RBX::Collision::BlockBlockContact::~BlockBlockContact(RBX::Collision::BlockBlockContact *this)
{
  RBX::Collision::FeaturePolyContact::~FeaturePolyContact(this);
  operator delete(this);
}


