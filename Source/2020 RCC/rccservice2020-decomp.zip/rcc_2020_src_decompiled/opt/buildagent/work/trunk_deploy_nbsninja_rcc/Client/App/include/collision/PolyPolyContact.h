// Address: 0x1e02690 | Name: _ZN3RBX9Collision12FaceFacePairC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::FaceFacePair::FaceFacePair(
        RBX::Collision::FaceFacePair *this,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  this->primitive[0] = p0;
  this->primitive[1] = p1;
  this->_vptr$PolyPair = (int (**)(void))&off_299E800;
  this->mainFace = *(const RBX::POLY::Face **)(*(_QWORD *)(*((_QWORD *)p0 + 18) + 40LL) + 48LL);
  *(_OWORD *)&this->otherFace = 0;
}


// Address: 0x1e04220 | Name: _ZN3RBX9Collision12EdgeEdgePairC2EPNS_9PrimitiveES3_
void __fastcall RBX::Collision::EdgeEdgePair::EdgeEdgePair(
        RBX::Collision::EdgeEdgePair *this,
        RBX::Primitive *p0,
        RBX::Primitive *p1)
{
  this->primitive[0] = p0;
  this->primitive[1] = p1;
  this->_vptr$PolyPair = (int (**)(void))&off_299E840;
  this->bestEdge0 = *(const RBX::POLY::Edge **)(*(_QWORD *)(*((_QWORD *)p0 + 18) + 40LL) + 24LL);
  this->bestEdge1 = *(const RBX::POLY::Edge **)(*(_QWORD *)(*((_QWORD *)p1 + 18) + 40LL) + 24LL);
}


// Address: 0x1e04ef0 | Name: _ZN3RBX9Collision15PolyPolyContactD2Ev
void __fastcall RBX::Collision::PolyPolyContact::~PolyPolyContact(RBX::Collision::PolyPolyContact *this)
{
  RBX::Collision::PolyPair *bestPair; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299E880;
  bestPair = this->bestPair;
  if ( bestPair )
  {
    (*((void (__fastcall **)(RBX::Collision::PolyPair *))bestPair->_vptr$PolyPair + 2))(bestPair);
    this->bestPair = 0;
  }
  RBX::Collision::FeaturePolyContact::~FeaturePolyContact(this);
}


// Address: 0x1e04f20 | Name: _ZN3RBX9Collision15PolyPolyContactD0Ev
void __fastcall RBX::Collision::PolyPolyContact::~PolyPolyContact(RBX::Collision::PolyPolyContact *this)
{
  RBX::Collision::PolyPair *bestPair; // rdi

  this->_vptr$Contact = (int (**)(void))&off_299E880;
  bestPair = this->bestPair;
  if ( bestPair )
  {
    (*((void (__fastcall **)(RBX::Collision::PolyPair *))bestPair->_vptr$PolyPair + 2))(bestPair);
    this->bestPair = 0;
  }
  RBX::Collision::FeaturePolyContact::~FeaturePolyContact(this);
  operator delete(this);
}


// Address: 0x1e04f60 | Name: _ZNK3RBX9Collision12FaceFacePair10isFaceFaceEv
bool __fastcall RBX::Collision::FaceFacePair::isFaceFace(const RBX::Collision::FaceFacePair *this)
{
  return 1;
}


// Address: 0x1e04f70 | Name: _ZN3RBX9Collision12FaceFacePairD0Ev
// Alternative name is 'j__ZdlPv_1667'
// attributes: thunk
void __fastcall RBX::Collision::FaceFacePair::~FaceFacePair(RBX::Collision::FaceFacePair *this)
{
  operator delete(this);
}


// Address: 0x1e04f80 | Name: _ZNK3RBX9Collision12EdgeEdgePair10isFaceFaceEv
bool __fastcall RBX::Collision::EdgeEdgePair::isFaceFace(const RBX::Collision::EdgeEdgePair *this)
{
  return 0;
}


// Address: 0x1e04f90 | Name: _ZN3RBX9Collision12EdgeEdgePairD0Ev
// Alternative name is 'j__ZdlPv_1668'
// attributes: thunk
void __fastcall RBX::Collision::EdgeEdgePair::~EdgeEdgePair(RBX::Collision::EdgeEdgePair *this)
{
  operator delete(this);
}


// Address: 0x1e04fa0 | Name: _ZN3RBX9Collision8PolyPairD2Ev
void __fastcall RBX::Collision::PolyPair::~PolyPair(RBX::Collision::PolyPair *this)
{
  ;
}


