// Address: 0x1e01ca0 | Name: _ZN3RBX9Collision15PolyPolyContact13resetBestPairEPNS0_8PolyPairE
void __fastcall RBX::Collision::PolyPolyContact::resetBestPair(
        RBX::Collision::PolyPolyContact *this,
        RBX::Collision::PolyPair *pairOnStack)
{
  RBX::Collision::PolyPair *bestPair; // rdi

  bestPair = this->bestPair;
  if ( bestPair )
  {
    (*((void (__fastcall **)(RBX::Collision::PolyPair *))bestPair->_vptr$PolyPair + 2))(bestPair);
    this->bestPair = 0;
  }
  if ( pairOnStack )
    this->bestPair = (RBX::Collision::PolyPair *)(*((__int64 (__fastcall **)(RBX::Collision::PolyPair *))pairOnStack->_vptr$PolyPair
                                                  + 3))(pairOnStack);
}


// Address: 0x1e01ce0 | Name: _ZN3RBX9Collision26getBestPairChangeThresholdEv
float __cdecl RBX::Collision::getBestPairChangeThreshold()
{
  return *(float *)&dword_2A08A88;
}


// Address: 0x1e01cf0 | Name: _ZN3RBX9Collision15PolyPolyContact12findBestPairEv
void __fastcall RBX::Collision::PolyPolyContact::findBestPair(RBX::Collision::PolyPolyContact *this)
{
  __m128 v1; // xmm0
  RBX::Collision::PolyPair *bestPair; // rdi
  RBX::Primitive *prim0; // rax
  RBX::Primitive *prim1; // rcx
  RBX::Primitive *v6; // rcx
  RBX::Collision::PolyPair *v7; // rbx
  char v8; // bp
  __int64 (__fastcall ***v9)(RBX::Collision::FaceFacePair *__hidden); // rbx
  __m128 v10; // xmm0
  __m128 v11; // xmm1
  __m128 v12; // xmm1
  unsigned __int32 v13; // xmm1_4
  __int64 (__fastcall ***v14)(RBX::Collision::FaceFacePair *__hidden); // r14
  RBX::Collision::PolyPair *v15; // rbx
  char v16; // bp
  float v17; // xmm0_4
  RBX::Collision::PolyPair *v18; // rdi
  RBX::Collision::PolyPair *v19; // rax
  RBX::Collision::PolyPair *v20; // rdi
  __m128 v21; // [rsp+0h] [rbp-98h]
  __int64 (__fastcall **v22)(RBX::Collision::FaceFacePair *__hidden); // [rsp+18h] [rbp-80h] BYREF
  RBX::Primitive *v23; // [rsp+20h] [rbp-78h]
  RBX::Primitive *v24; // [rsp+28h] [rbp-70h]
  __int64 v25; // [rsp+30h] [rbp-68h]
  __int128 v26; // [rsp+38h] [rbp-60h]
  __int64 (__fastcall **v27)(RBX::Collision::FaceFacePair *__hidden); // [rsp+48h] [rbp-50h] BYREF
  RBX::Primitive *v28; // [rsp+50h] [rbp-48h]
  RBX::Primitive *v29; // [rsp+58h] [rbp-40h]
  __int64 v30; // [rsp+60h] [rbp-38h]
  __int128 v31; // [rsp+68h] [rbp-30h]

  bestPair = this->bestPair;
  if ( !bestPair )
  {
    bestPair = (RBX::Collision::PolyPair *)operator new(0x30u);
    prim0 = this->prim0;
    prim1 = this->prim1;
    bestPair->primitive[0] = prim0;
    bestPair->primitive[1] = prim1;
    bestPair->_vptr$PolyPair = (int (**)(void))&off_299E800;
    bestPair[1]._vptr$PolyPair = *(int (***)(void))(*(_QWORD *)(*((_QWORD *)prim0 + 18) + 40LL) + 48LL);
    v1 = 0;
    *(_OWORD *)bestPair[1].primitive = 0;
    this->bestPair = bestPair;
  }
  v1.m128_f32[0] = (*((float (__fastcall **)(RBX::Collision::PolyPair *))bestPair->_vptr$PolyPair + 4))(bestPair);
  if ( v1.m128_f32[0] <= 0.0 )
  {
    v21 = v1;
    v6 = this->prim1;
    v28 = this->prim0;
    v29 = v6;
    v27 = &off_299E800;
    v30 = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)v28 + 18) + 40LL) + 48LL);
    v31 = 0;
    v23 = v6;
    v24 = v28;
    v22 = &off_299E800;
    v25 = *(_QWORD *)(*(_QWORD *)(*((_QWORD *)v6 + 18) + 40LL) + 48LL);
    v26 = 0;
    v7 = this->bestPair;
    v8 = (*(__int64 (__fastcall **)(RBX::Collision::PolyPair *))v7->_vptr$PolyPair)(v7);
    if ( v8 == RBX::Collision::FaceFacePair::isFaceFace((const RBX::Collision::FaceFacePair *)&v27)
      && v7->primitive[0] == v28 )
    {
      v14 = 0;
    }
    else
    {
      v9 = &v27;
      v10.m128_f32[0] = ((float (__fastcall *)(__int64 (__fastcall ***)(RBX::Collision::FaceFacePair *__hidden)))v27[4])(&v27);
      if ( v10.m128_f32[0] > 0.0 )
      {
LABEL_14:
        v18 = this->bestPair;
        if ( v18 )
        {
          (*((void (__fastcall **)(RBX::Collision::PolyPair *))v18->_vptr$PolyPair + 2))(v18);
          this->bestPair = 0;
        }
        v19 = (RBX::Collision::PolyPair *)(*v9)[3]((RBX::Collision::FaceFacePair *)v9);
LABEL_23:
        this->bestPair = v19;
        return;
      }
      v11 = (__m128)(unsigned int)dword_2A08A88;
      v11.m128_f32[0] = *(float *)&dword_2A08A88 + v21.m128_f32[0];
      v12 = _mm_cmplt_ss(v11, v10);
      v13 = _mm_andnot_ps(v12, v21).m128_u32[0] | v12.m128_i32[0] & v10.m128_i32[0];
      v14 = &v27;
      if ( v10.m128_f32[0] <= (float)(*(float *)&dword_2A08A88 + v21.m128_f32[0]) )
        v14 = 0;
      v21.m128_i32[0] = v13;
    }
    v15 = this->bestPair;
    v16 = (*(__int64 (__fastcall **)(RBX::Collision::PolyPair *))v15->_vptr$PolyPair)(v15);
    if ( v16 == (unsigned __int8)(*v22)((RBX::Collision::FaceFacePair *)&v22) && v15->primitive[0] == v23 )
      goto LABEL_19;
    v9 = &v22;
    v17 = ((float (__fastcall *)(__int64 (__fastcall ***)(RBX::Collision::FaceFacePair *__hidden)))v22[4])(&v22);
    if ( v17 > 0.0 )
      goto LABEL_14;
    if ( v17 <= (float)(v21.m128_f32[0] + *(float *)&dword_2A08A88) )
    {
LABEL_19:
      if ( !v14 )
        return;
    }
    else
    {
      v14 = &v22;
    }
    v20 = this->bestPair;
    if ( v20 )
    {
      (*((void (__fastcall **)(RBX::Collision::PolyPair *))v20->_vptr$PolyPair + 2))(v20);
      this->bestPair = 0;
    }
    v19 = (RBX::Collision::PolyPair *)(*v14)[3]((RBX::Collision::FaceFacePair *)v14);
    goto LABEL_23;
  }
}


// Address: 0x1e01f20 | Name: _ZN3RBX9Collision15PolyPolyContact35findFeatureCollisionsUpdateContactsERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
char __fastcall RBX::Collision::PolyPolyContact::findFeatureCollisionsUpdateContacts(
        RBX::Collision::PolyPolyContact *this,
        RBX::Collision::PolyCollisionConnectorArray *newCollisionConnectors,
        float a3,
        float overlapIgnored)
{
  char v5; // bl
  RBX::Collision::PolyPair *bestPair; // rdi
  RBX::Primitive *v7; // rax
  char result; // al

  RBX::Collision::PolyPolyContact::findBestPair(this);
  v5 = (*((__int64 (__fastcall **)(RBX::Collision::PolyPair *, RBX::Collision::PolyCollisionConnectorArray *, float, float))this->bestPair->_vptr$PolyPair
        + 5))(
         this->bestPair,
         newCollisionConnectors,
         a3,
         overlapIgnored);
  if ( ((__int64 (__fastcall *)(RBX::Collision::PolyPair *))*this->bestPair->_vptr$PolyPair)(this->bestPair) && !v5 )
  {
    bestPair = this->bestPair;
    v7 = bestPair[1].primitive[1];
    if ( !v7 )
      goto LABEL_7;
    bestPair[1].primitive[0] = v7;
    v5 = (*((__int64 (__fastcall **)(RBX::Collision::PolyPair *, RBX::Collision::PolyCollisionConnectorArray *, float))bestPair->_vptr$PolyPair
          + 5))(
           bestPair,
           newCollisionConnectors,
           a3);
  }
  result = 1;
  if ( v5 )
    return result;
  bestPair = this->bestPair;
LABEL_7:
  if ( bestPair )
  {
    (*((void (__fastcall **)(RBX::Collision::PolyPair *))bestPair->_vptr$PolyPair + 2))(bestPair);
    this->bestPair = 0;
  }
  return 0;
}


// Address: 0x1e01fb0 | Name: _ZN3RBX9Collision12FaceFacePair23updateFaceEdgeCollisionEPNS0_29FeaturePolyCollisionConnectorERKN3G3D5PlaneES7_NS4_4LineES8_ii
void __fastcall RBX::Collision::FaceFacePair::updateFaceEdgeCollision(
        RBX::Collision::FaceFacePair *this,
        RBX::Collision::FeaturePolyCollisionConnector *conn,
        const RBX::Plane *facePlane,
        const RBX::Plane *sideFacePlane,
        const G3D::Line *faceId,
        const G3D::Line *edgeId,
        RBX::Line faceLine)
{
  RBX::Body *bodyA; // rbp
  RBX::PV *p_pv; // rbx
  __m128 v11; // xmm1
  float v12; // xmm0_4
  float v13; // xmm0_4
  __m128 x_low; // xmm4
  __m128 v15; // xmm2
  __m128 v16; // xmm1
  __m128 v17; // xmm3
  float *v18; // rax
  float v19; // xmm1_4
  float *v20; // rax
  float z; // [rsp+Ch] [rbp-BCh]
  G3D::Vector3 v22; // [rsp+10h] [rbp-B8h] BYREF
  G3D::Vector3 p1; // [rsp+20h] [rbp-A8h] BYREF
  G3D::Vector3 p0; // [rsp+30h] [rbp-98h] BYREF
  __m128 v25; // [rsp+40h] [rbp-88h]
  G3D::Line line1; // [rsp+58h] [rbp-70h] BYREF
  G3D::Line line0; // [rsp+78h] [rbp-50h] BYREF

  conn->param0 = (int)faceLine._vptr$Line;
  conn->param1 = LODWORD(faceLine._point.x);
  bodyA = conn->bodyA;
  p_pv = &conn->bodyB->pv;
  G3D::CoordinateFrame::toWorldSpace(&line0, &conn->bodyA->pv.position, faceId);
  G3D::CoordinateFrame::toWorldSpace(&line1, &p_pv->position, edgeId);
  *(_QWORD *)&p0.x = 0;
  p0.z = 0.0;
  *(_QWORD *)&p1.x = 0;
  p1.z = 0.0;
  if ( !G3D::Line::closestPoints(&line0, &line1, &p0, &p1) )
    goto LABEL_15;
  v25 = (__m128)*(unsigned __int64 *)&p0.x;
  v11 = _mm_sub_ps((__m128)*(unsigned __int64 *)&p0.x, (__m128)*(unsigned __int64 *)&p1.x);
  z = p0.z;
  v12 = p0.z - p1.z;
  _mm_storel_ps((double *)&v22.x, v11);
  v22.z = v12;
  v13 = G3D::Vector3::unitize(&v22, v11.m128_f32[0]);
  x_low = (__m128)LODWORD(facePlane->_normal.x);
  v15 = (__m128)*(unsigned __int64 *)&facePlane->_normal.y;
  v16 = _mm_mul_ps((__m128)*(unsigned __int64 *)&bodyA->pv.position.rotation.elt[1][1], v15);
  v17 = _mm_mul_ps(
          _mm_unpacklo_ps((__m128)LODWORD(v22.x), (__m128)LODWORD(v22.z)),
          _mm_add_ps(
            _mm_mul_ps(
              (__m128)_mm_shuffle_epi32((__m128i)v15, 229),
              _mm_unpacklo_ps(
                (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][2]),
                (__m128)LODWORD(bodyA->pv.position.rotation.elt[2][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                (__m128)_mm_shuffle_epi32((__m128i)v15, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][1]),
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[2][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(x_low, x_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(bodyA->pv.position.rotation.elt[2][0]))))));
  if ( (float)(_mm_shuffle_ps(v17, v17, 229).m128_f32[0]
             + (float)((float)((float)(_mm_shuffle_ps(v16, v16, 229).m128_f32[0]
                                     + (float)((float)(bodyA->pv.position.rotation.elt[1][0] * x_low.m128_f32[0])
                                             + v16.m128_f32[0]))
                             * v22.y)
                     + v17.m128_f32[0])) <= 0.0 )
    goto LABEL_15;
  v18 = (float *)this->primitive[0];
  if ( v25.m128_f32[0] >= v18[136]
    && (v19 = _mm_shuffle_ps(v25, v25, 229).m128_f32[0], v19 >= v18[137])
    && z >= v18[138]
    && v18[139] >= v25.m128_f32[0]
    && v18[140] >= v19
    && v18[141] >= z
    && (v20 = (float *)this->primitive[1], v25.m128_f32[0] >= v20[136])
    && v19 >= v20[137]
    && z >= v20[138]
    && v20[139] >= v25.m128_f32[0]
    && v20[140] >= v19
    && v20[141] >= z )
  {
    LODWORD(conn->contactPoint.x) = v25.m128_i32[0];
    conn->contactPoint.y = v19;
    conn->contactPoint.z = z;
    conn->normal = v22;
    conn->depth = -v13;
  }
  else
  {
LABEL_15:
    *(_QWORD *)&conn->normal.x = 0;
    conn->normal.z = 0.0;
  }
}


// Address: 0x1e02280 | Name: _ZN3RBX9Collision12FaceFacePair25updateFaceVertexCollisionEPNS0_29FeaturePolyCollisionConnectorERKN3G3D5PlaneERKNS4_7Vector3Eii
void __fastcall RBX::Collision::FaceFacePair::updateFaceVertexCollision(
        RBX::Collision::FaceFacePair *this,
        RBX::Collision::FeaturePolyCollisionConnector *conn,
        const RBX::Plane *facePlane,
        const RBX::Vector3 *vertexOffset,
        int planeId,
        int vertexId)
{
  __m128 v6; // xmm0
  __m128 v7; // xmm1
  G3D::Plane v9; // kr00_16
  RBX::Body *bodyB; // rax
  __m128 x_low; // xmm8
  __m128 y_low; // xmm3
  __m128 z_low; // xmm2
  __m128 v14; // xmm4

  conn->param0 = planeId;
  conn->param1 = vertexId;
  v9 = G3D::CoordinateFrame::toWorldSpace(&conn->bodyA->pv.position, facePlane);
  v7.m128_u64[0] = *(_QWORD *)&v9._normal.z;
  v6.m128_u64[0] = *(_QWORD *)&v9._normal.x;
  bodyB = conn->bodyB;
  x_low = (__m128)LODWORD(vertexOffset->x);
  y_low = (__m128)LODWORD(vertexOffset->y);
  z_low = (__m128)LODWORD(vertexOffset->z);
  v14 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(z_low, z_low, 224),
              _mm_unpacklo_ps(
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(y_low, y_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(x_low, x_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]))))));
  z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][2])
                            + (float)((float)(y_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][1])
                                    + (float)(x_low.m128_f32[0] * bodyB->pv.position.rotation.elt[2][0])))
                    + bodyB->pv.position.translation.z;
  _mm_storel_ps((double *)&conn->contactPoint.x, v14);
  LODWORD(conn->contactPoint.z) = z_low.m128_i32[0];
  _mm_storel_ps((double *)&conn->normal.x, v6);
  conn->normal.z = v9._normal.z;
  conn->depth = (float)((float)(v9._normal.z * z_low.m128_f32[0])
                      + (float)((float)(_mm_shuffle_ps(v6, v6, 229).m128_f32[0]
                                      * _mm_shuffle_ps(v14, v14, 229).m128_f32[0])
                              + (float)(v9._normal.x * v14.m128_f32[0])))
              - _mm_shuffle_ps(v7, v7, 229).m128_f32[0];
}


// Address: 0x1e023a0 | Name: _ZN3RBX9Collision12EdgeEdgePair23updateEdgeEdgeCollisionEPNS0_29FeaturePolyCollisionConnectorEN3G3D4LineES5_ii
void __fastcall RBX::Collision::EdgeEdgePair::updateEdgeEdgeCollision(
        RBX::Collision::EdgeEdgePair *this,
        RBX::Collision::FeaturePolyCollisionConnector *conn,
        const G3D::Line *edgeId0,
        const G3D::Line *edgeId1,
        int a5,
        int a6,
        __m128 a7)
{
  RBX::Body *bodyA; // r12
  RBX::Body *bodyB; // r13
  __m128 v10; // xmm2
  float v11; // xmm2_4
  float v12; // xmm9_4
  float v13; // xmm3_4
  __m128 v14; // xmm6
  __m128 v15; // xmm5
  __m128 v16; // xmm3
  float v17; // xmm1_4
  float v18; // xmm0_4
  __m128 v19; // xmm3
  float v20; // [rsp+4h] [rbp-B4h]
  G3D::Vector3 v21; // [rsp+8h] [rbp-B0h] BYREF
  float v22; // [rsp+18h] [rbp-A0h]
  float z; // [rsp+1Ch] [rbp-9Ch]
  __m128 v24; // [rsp+20h] [rbp-98h]
  __m128 v25; // [rsp+30h] [rbp-88h]
  __m128 v26; // [rsp+40h] [rbp-78h]
  G3D::Line v27; // [rsp+50h] [rbp-68h] BYREF
  G3D::Line v28; // [rsp+70h] [rbp-48h] BYREF
  G3D::Vector3 v31; // 0:kr00_12.12
  G3D::Vector3 v32; // 0:kr14_12.12
  G3D::Vector3 v33; // 0:kr20_12.12
  G3D::Vector3 v34; // 0:kr34_12.12

  conn->param0 = a5;
  conn->param1 = a6;
  bodyA = conn->bodyA;
  bodyB = conn->bodyB;
  G3D::CoordinateFrame::toWorldSpace(&v28, &conn->bodyA->pv.position, edgeId0);
  G3D::CoordinateFrame::toWorldSpace(&v27, &bodyB->pv.position, edgeId1);
  v31 = G3D::Line::point(&v28);
  a7.m128_i32[0] = LODWORD(v31.x);
  a7.m128_i32[1] = LODWORD(v31.y);
  v26 = a7;
  z = v31.z;
  v32 = G3D::Line::point(&v27);
  a7.m128_i32[0] = LODWORD(v32.x);
  a7.m128_i32[1] = LODWORD(v32.y);
  v25 = a7;
  v22 = v32.z;
  v33 = G3D::Line::direction(&v28);
  a7.m128_i32[0] = LODWORD(v33.x);
  a7.m128_i32[1] = LODWORD(v33.y);
  v24 = a7;
  v34 = G3D::Line::direction(&v27);
  a7.m128_i32[0] = LODWORD(v34.x);
  a7.m128_i32[1] = LODWORD(v34.y);
  v10 = _mm_mul_ps(v24, a7);
  v11 = (float)(v33.z * v34.z) + (float)(_mm_shuffle_ps(v10, v10, 229).m128_f32[0] + v10.m128_f32[0]);
  v12 = 1.0 - (float)(v11 * v11);
  if ( v12 <= 0.000001 )
    goto LABEL_4;
  v13 = _mm_shuffle_ps(v25, v25, 229).m128_f32[0] - _mm_shuffle_ps(v26, v26, 229).m128_f32[0];
  v14 = (__m128)LODWORD(v22);
  v14.m128_f32[0] = v22 - z;
  v15 = v14;
  v15.m128_f32[0] = (float)((float)(v22 - z) * v33.z)
                  + (float)((float)(_mm_shuffle_ps(v24, v24, 229).m128_f32[0] * v13)
                          + (float)((float)(v25.m128_f32[0] - v26.m128_f32[0]) * v24.m128_f32[0]));
  v14.m128_f32[0] = (float)((float)(v22 - z) * v34.z)
                  + (float)((float)(v13 * _mm_shuffle_ps(a7, a7, 229).m128_f32[0])
                          + (float)((float)(v25.m128_f32[0] - v26.m128_f32[0]) * v34.x));
  v16 = v15;
  v16.m128_f32[0] = (float)(v15.m128_f32[0] - (float)(v14.m128_f32[0] * v11)) * (float)(1.0 / v12);
  v15.m128_f32[0] = (float)((float)(v15.m128_f32[0] * v11) - v14.m128_f32[0]) * (float)(1.0 / v12);
  v17 = (float)(v34.z * v15.m128_f32[0]) + v22;
  v24 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v16, v16, 224), v24), v26);
  v20 = (float)(v33.z * v16.m128_f32[0]) + z;
  _mm_storel_ps((double *)&v21.x, _mm_sub_ps(v24, _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v15, v15, 224), a7), v25)));
  v21.z = v20 - v17;
  v18 = G3D::Vector3::unitize(&v21, v17);
  v19 = _mm_mul_ps(
          (__m128)*(unsigned __int64 *)&v21.y,
          _mm_sub_ps(
            (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.y,
            (__m128)*(unsigned __int64 *)&bodyA->pv.position.translation.y));
  if ( (float)(_mm_shuffle_ps(v19, v19, 229).m128_f32[0]
             + (float)((float)((float)(bodyB->pv.position.translation.x - bodyA->pv.position.translation.x) * v21.x)
                     + v19.m128_f32[0])) <= 0.0 )
  {
LABEL_4:
    *(_QWORD *)&conn->normal.x = 0;
    conn->normal.z = 0.0;
  }
  else
  {
    _mm_storel_ps((double *)&conn->contactPoint.x, v24);
    conn->contactPoint.z = v20;
    conn->normal = v21;
    conn->depth = -v18;
  }
}


// Address: 0x1e02670 | Name: _ZNK3RBX9Collision8PolyPair5poly0Ev
const RBX::Poly *__fastcall RBX::Collision::PolyPair::poly0(const RBX::Collision::PolyPair *this)
{
  return (const RBX::Poly *)*((_QWORD *)this->primitive[0] + 18);
}


// Address: 0x1e02680 | Name: _ZNK3RBX9Collision8PolyPair5poly1Ev
const RBX::Poly *__fastcall RBX::Collision::PolyPair::poly1(const RBX::Collision::PolyPair *this)
{
  return (const RBX::Poly *)*((_QWORD *)this->primitive[1] + 18);
}


// Address: 0x1e026c0 | Name: _ZN3RBX9Collision12FaceFacePair13allocateCloneEv
RBX::Collision::PolyPair *__fastcall RBX::Collision::FaceFacePair::allocateClone(RBX::Collision::FaceFacePair *this)
{
  RBX::Collision::PolyPair *result; // rax

  result = (RBX::Collision::PolyPair *)operator new(0x30u);
  *(_OWORD *)result->primitive = *(_OWORD *)this->primitive;
  result->_vptr$PolyPair = (int (**)(void))&off_299E800;
  result[1].primitive[1] = this->nextBestOtherFace;
  *(_OWORD *)&result[1]._vptr$PolyPair = *(_OWORD *)&this->mainFace;
  return result;
}


// Address: 0x1e02700 | Name: _ZN3RBX9Collision12FaceFacePair4testEv
float __fastcall RBX::Collision::FaceFacePair::test(RBX::Collision::FaceFacePair *this)
{
  const RBX::CoordinateFrame *CoordinateFrame; // rbx
  const RBX::CoordinateFrame *v3; // rax
  __int64 *v4; // rax
  __int64 v5; // rcx
  float result; // xmm0_4
  __int64 v7; // rsi
  unsigned __int64 v8; // rsi
  __m128 v9; // xmm8
  __m128 v10; // xmm9
  __m128 v11; // xmm10
  __m128 v12; // xmm11
  float v13; // xmm12_4
  float v14; // xmm13_4
  float v15; // xmm6_4
  float z; // xmm7_4
  __int64 v17; // rdx
  __int64 v18; // rbp
  unsigned __int64 v19; // rax
  __int64 v20; // rdi
  __m128 v21; // xmm3
  __m128 v22; // xmm4
  __m128 v23; // xmm5
  __int64 v24; // rdi
  const RBX::POLY::Face *mainFace; // r8
  __int64 v26; // rdx
  unsigned int *v27; // rbx
  __int64 v28; // rax
  const RBX::POLY::Vertex *v29; // rsi
  __m128i v30; // xmm4
  float v31; // xmm5_4
  __m128 v32; // xmm4
  __m128 v33; // xmm3
  float v34; // xmm3_4
  const RBX::POLY::Face *OtherFace; // rax
  __int64 v36; // rax
  __int64 v37; // r11
  __int64 v38; // r9
  unsigned __int64 v39; // r9
  __int64 v40; // rdi
  unsigned __int64 i; // r13
  __int64 v42; // rdx
  const RBX::POLY::Face *v43; // r15
  float v44; // xmm1_4
  float v45; // xmm4_4
  __m128 v46; // xmm5
  unsigned int *v47; // rbx
  __int64 v48; // rbp
  __int64 v49; // r10
  const RBX::POLY::Vertex *v50; // rdx
  float v51; // xmm2_4
  __m128i v52; // xmm7
  float v53; // xmm3_4
  __m128 v54; // xmm7
  __m128 v55; // xmm6
  float v56; // xmm6_4
  G3D::CoordinateFrame v57; // [rsp+10h] [rbp-C8h] BYREF
  _OWORD v58[6]; // [rsp+40h] [rbp-98h] BYREF
  __int64 v59; // [rsp+A0h] [rbp-38h]

  CoordinateFrame = RBX::Primitive::getCoordinateFrame(this->primitive[0]);
  v3 = RBX::Primitive::getCoordinateFrame(this->primitive[1]);
  G3D::CoordinateFrame::toObjectSpace(&v57, CoordinateFrame, v3);
  memset(v58, 0, sizeof(v58));
  v59 = 0;
  v4 = *(__int64 **)(*((_QWORD *)this->primitive[1] + 18) + 40LL);
  v5 = *v4;
  result = 3.4028235e38;
  v7 = v4[1] - *v4;
  if ( !v7 )
    goto LABEL_10;
  v8 = 0xAAAAAAAAAAAAAAABLL * (v7 >> 4);
  v9 = _mm_unpacklo_ps((__m128)LODWORD(v57.rotation.elt[0][0]), (__m128)LODWORD(v57.rotation.elt[1][0]));
  v10 = _mm_unpacklo_ps((__m128)LODWORD(v57.rotation.elt[0][1]), (__m128)LODWORD(v57.rotation.elt[1][1]));
  v11 = _mm_unpacklo_ps((__m128)LODWORD(v57.rotation.elt[0][2]), (__m128)LODWORD(v57.rotation.elt[1][2]));
  v12 = (__m128)*(unsigned __int64 *)&v57.translation.x;
  v13 = v57.rotation.elt[2][0];
  v14 = v57.rotation.elt[2][1];
  v15 = v57.rotation.elt[2][2];
  z = v57.translation.z;
  v17 = 0;
  v18 = 0;
  v19 = 0;
  do
  {
    v20 = 48 * (v17 >> 32);
    v21 = (__m128)*(unsigned int *)(v5 + v20 + 8);
    v22 = (__m128)*(unsigned int *)(v5 + v20 + 12);
    v23 = (__m128)*(unsigned int *)(v5 + v20 + 16);
    _mm_storel_ps(
      (double *)((char *)v58 + 12 * v18),
      _mm_add_ps(
        _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(v23, v23, 224), v11),
          _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v22, v22, 224), v10), _mm_mul_ps(_mm_shuffle_ps(v21, v21, 224), v9))),
        v12));
    *((float *)v58 + 3 * v18 + 2) = (float)((float)(v23.m128_f32[0] * v15)
                                          + (float)((float)(v22.m128_f32[0] * v14) + (float)(v21.m128_f32[0] * v13)))
                                  + z;
    v24 = v59;
    v18 = ++v59;
    ++v19;
    v17 += 0x100000000LL;
  }
  while ( v19 < v8 );
  if ( !v18 )
    goto LABEL_10;
  mainFace = this->mainFace;
  v26 = v24 + 1;
  v27 = (unsigned int *)v58 + 2;
  result = 3.4028235e38;
  v28 = 0;
  v29 = 0;
  do
  {
    v30 = (__m128i)*((unsigned __int64 *)v27 - 1);
    v31 = *((float *)mainFace + 8) * *(float *)v30.m128i_i32;
    v32 = (__m128)_mm_shuffle_epi32(v30, 229);
    v33 = _mm_mul_ps(
            _mm_shuffle_ps(_mm_shuffle_ps((__m128)*v27, v32, 0), v32, 226),
            (__m128)*(unsigned __int64 *)((char *)mainFace + 36));
    v34 = (float)(_mm_shuffle_ps(v33, v33, 229).m128_f32[0] + (float)(v31 + v33.m128_f32[0]))
        - *((float *)mainFace + 11);
    if ( result > v34 )
    {
      v29 = (const RBX::POLY::Vertex *)(v5 + 48 * (v28 >> 32));
      result = v34;
    }
    v28 += 0x100000000LL;
    v27 += 3;
    --v26;
  }
  while ( v26 );
  if ( result <= 0.0 )
  {
    v36 = *(_QWORD *)(*((_QWORD *)this->primitive[0] + 18) + 40LL);
    v37 = *(_QWORD *)(v36 + 48);
    v38 = *(_QWORD *)(v36 + 56) - v37;
    if ( v38 )
    {
      v39 = 0xAAAAAAAAAAAAAAABLL * (v38 >> 4);
      v40 = v24 + 1;
      OtherFace = 0;
      for ( i = 0; i < v39; ++i )
      {
        v42 = 48LL * (int)i;
        v43 = (const RBX::POLY::Face *)(v37 + v42);
        if ( (const RBX::POLY::Face *)(v37 + v42) != mainFace )
        {
          v44 = *(float *)(v37 + v42 + 32);
          v45 = *(float *)(v37 + v42 + 44);
          v46 = (__m128)*(unsigned __int64 *)(v37 + v42 + 36);
          v47 = (unsigned int *)v58 + 2;
          v48 = v40;
          v49 = 0;
          v50 = 0;
          v51 = 3.4028235e38;
          do
          {
            v52 = (__m128i)*((unsigned __int64 *)v47 - 1);
            v53 = v44 * *(float *)v52.m128i_i32;
            v54 = (__m128)_mm_shuffle_epi32(v52, 229);
            v55 = _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps((__m128)*v47, v54, 0), v54, 226), v46);
            v56 = (float)(_mm_shuffle_ps(v55, v55, 229).m128_f32[0] + (float)(v53 + v55.m128_f32[0])) - v45;
            if ( v51 > v56 )
            {
              v50 = (const RBX::POLY::Vertex *)(v5 + 48 * (v49 >> 32));
              v51 = v56;
            }
            v49 += 0x100000000LL;
            v47 += 3;
            --v48;
          }
          while ( v48 );
          if ( v51 > result )
          {
            this->mainFace = v43;
            if ( v51 > 0.0 )
            {
              result = v51;
              goto LABEL_11;
            }
            mainFace = v43;
            v29 = v50;
            result = v51;
          }
        }
      }
    }
    OtherFace = RBX::Collision::FaceFacePair::findOtherFace(this, v29);
  }
  else
  {
LABEL_10:
    OtherFace = 0;
  }
LABEL_11:
  this->otherFace = OtherFace;
  return result;
}


// Address: 0x1e02a80 | Name: _ZN3RBX9Collision12FaceFacePair15computeVerticesERNS_10FixedArrayIN3G3D7Vector3ELm8EEERKNS3_15CoordinateFrameE
void __fastcall RBX::Collision::FaceFacePair::computeVertices(
        RBX::Collision::FaceFacePair *this,
        RBX::FixedArray<G3D::Vector3,8> *verticesInObject,
        const RBX::CoordinateFrame *otherInMe)
{
  __int64 *v3; // r10
  __int64 v4; // rcx
  size_t num; // rdi
  __int64 v6; // r11
  unsigned __int64 v7; // rax
  __int64 v8; // rbx
  __m128 v9; // xmm2
  __m128 v10; // xmm1
  __m128 v11; // xmm0
  __m128 v12; // xmm3

  v3 = *(__int64 **)(*((_QWORD *)this->primitive[1] + 18) + 40LL);
  v4 = *v3;
  if ( v3[1] != *v3 )
  {
    num = verticesInObject->num;
    v6 = 0;
    v7 = 0;
    do
    {
      v8 = 48 * (v6 >> 32);
      v9 = (__m128)*(unsigned int *)(v4 + v8 + 8);
      v10 = (__m128)*(unsigned int *)(v4 + v8 + 12);
      v11 = (__m128)*(unsigned int *)(v4 + v8 + 16);
      v12 = _mm_add_ps(
              (__m128)*(unsigned __int64 *)&otherInMe->translation.x,
              _mm_add_ps(
                _mm_mul_ps(
                  _mm_shuffle_ps(v11, v11, 224),
                  _mm_unpacklo_ps(
                    (__m128)LODWORD(otherInMe->rotation.elt[0][2]),
                    (__m128)LODWORD(otherInMe->rotation.elt[1][2]))),
                _mm_add_ps(
                  _mm_mul_ps(
                    _mm_shuffle_ps(v10, v10, 224),
                    _mm_unpacklo_ps(
                      (__m128)LODWORD(otherInMe->rotation.elt[0][1]),
                      (__m128)LODWORD(otherInMe->rotation.elt[1][1]))),
                  _mm_mul_ps(
                    _mm_shuffle_ps(v9, v9, 224),
                    _mm_unpacklo_ps(
                      (__m128)LODWORD(otherInMe->rotation.elt[0][0]),
                      (__m128)LODWORD(otherInMe->rotation.elt[1][0]))))));
      v11.m128_f32[0] = (float)((float)(v11.m128_f32[0] * otherInMe->rotation.elt[2][2])
                              + (float)((float)(v10.m128_f32[0] * otherInMe->rotation.elt[2][1])
                                      + (float)(v9.m128_f32[0] * otherInMe->rotation.elt[2][0])))
                      + otherInMe->translation.z;
      _mm_storel_ps((double *)&verticesInObject->data.elems[num].x, v12);
      LODWORD(verticesInObject->data.elems[num].z) = v11.m128_i32[0];
      num = verticesInObject->num + 1;
      verticesInObject->num = num;
      ++v7;
      v4 = *v3;
      v6 += 0x100000000LL;
    }
    while ( v7 < 0xAAAAAAAAAAAAAAABLL * ((v3[1] - *v3) >> 4) );
  }
}


// Address: 0x1e02c50 | Name: _ZN3RBX9Collision12FaceFacePair13findOtherFaceEPKNS_4POLY6VertexE
const RBX::POLY::Face *__fastcall RBX::Collision::FaceFacePair::findOtherFace(
        RBX::Collision::FaceFacePair *this,
        const RBX::POLY::Vertex *closeVertex)
{
  __m128 v2; // xmm0
  const RBX::CoordinateFrame *CoordinateFrame; // rbx
  const RBX::CoordinateFrame *v4; // rax
  G3D::Plane v5; // kr00_16
  const RBX::POLY::Face *result; // rax
  float v7; // xmm0_4
  const RBX::POLY::Face *v8; // r12
  size_t v9; // rbx
  float v10; // xmm2_4
  __m128 v11; // xmm1
  float v12; // [rsp+Ch] [rbp-7Ch]
  __m128 v13; // [rsp+20h] [rbp-68h]
  G3D::CoordinateFrame v14; // [rsp+38h] [rbp-50h] BYREF

  this->nextBestOtherFace = 0;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(this->primitive[1]);
  v4 = RBX::Primitive::getCoordinateFrame(this->primitive[0]);
  G3D::CoordinateFrame::toObjectSpace(&v14, CoordinateFrame, v4);
  v5 = G3D::CoordinateFrame::toWorldSpace(&v14, (const G3D::Plane *)this->mainFace + 2);
  v2.m128_u64[0] = *(_QWORD *)&v5._normal.x;
  v13 = v2;
  if ( *((_QWORD *)closeVertex + 4) == *((_QWORD *)closeVertex + 3) )
    return 0;
  v7 = -2.0;
  v8 = 0;
  v9 = 0;
  do
  {
    v12 = v7;
    result = RBX::POLY::Vertex::getFace(closeVertex, v9);
    v10 = v7;
    v11 = _mm_mul_ps((__m128)*((unsigned __int64 *)result + 4), v13);
    v7 = (float)((float)-_mm_shuffle_ps(v11, v11, 229).m128_f32[0] - v11.m128_f32[0])
       - (float)(*((float *)result + 10) * v5._normal.z);
    if ( v7 <= v10 )
    {
      v7 = v12;
      result = v8;
    }
    else if ( v10 > 0.30000001 && fabs(v7 - v10) < 0.40000001 )
    {
      this->nextBestOtherFace = v8;
    }
    ++v9;
    v8 = result;
  }
  while ( v9 < (__int64)(*((_QWORD *)closeVertex + 4) - *((_QWORD *)closeVertex + 3)) >> 3 );
  return result;
}


// Address: 0x1e02d80 | Name: _ZN3RBX9Collision12FaceFacePair12vertexInPolyEPKNS_4POLY4FaceEPKNS2_4MeshEPKNS2_6VertexERKN3G3D15CoordinateFrameE
void __fastcall RBX::Collision::FaceFacePair::vertexInPoly(
        RBX::Collision::FaceFacePair *this,
        const RBX::POLY::Face *planeFace,
        const RBX::POLY::Mesh *planeMesh,
        const RBX::POLY::Vertex *vertex,
        const RBX::CoordinateFrame *otherInMe)
{
  __m128 v5; // xmm4
  __m128 v6; // xmm3
  __m128 v7; // xmm0
  float v8; // xmm7_4
  __m128 v9; // xmm0
  __m128 v10; // xmm1
  __m128 v11; // xmm2
  __m128 v12; // xmm7
  __m128 v13; // xmm3
  float v14; // xmm5_4
  __m128 v15; // xmm3
  __m128 v16; // xmm0
  __m128 v17; // xmm5
  __m128 v18; // xmm1
  float v19; // [rsp+Ch] [rbp-2Ch]
  RBX::Vector3 point; // [rsp+10h] [rbp-28h] BYREF
  __m128 v21; // [rsp+20h] [rbp-18h]

  v5 = (__m128)*((unsigned int *)vertex + 2);
  v6 = (__m128)*(unsigned __int64 *)((char *)vertex + 12);
  v7 = _mm_mul_ps((__m128)*(unsigned __int64 *)&otherInMe->rotation.elt[1][1], v6);
  v8 = (float)(otherInMe->rotation.elt[1][0] * v5.m128_f32[0]) + v7.m128_f32[0];
  v9 = _mm_shuffle_ps(v7, v7, 229);
  v9.m128_f32[0] = (float)(v9.m128_f32[0] + v8) + otherInMe->translation.y;
  v10 = _mm_add_ps(
          _mm_unpacklo_ps((__m128)LODWORD(otherInMe->translation.x), (__m128)LODWORD(otherInMe->translation.z)),
          _mm_add_ps(
            _mm_mul_ps(
              (__m128)_mm_shuffle_epi32((__m128i)v6, 229),
              _mm_unpacklo_ps(
                (__m128)LODWORD(otherInMe->rotation.elt[0][2]),
                (__m128)LODWORD(otherInMe->rotation.elt[2][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                (__m128)_mm_shuffle_epi32((__m128i)v6, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(otherInMe->rotation.elt[0][1]),
                  (__m128)LODWORD(otherInMe->rotation.elt[2][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(v5, v5, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(otherInMe->rotation.elt[0][0]),
                  (__m128)LODWORD(otherInMe->rotation.elt[2][0]))))));
  v11 = (__m128)_mm_loadl_epi64((const __m128i *)planeFace + 2);
  v5.m128_f32[0] = *(float *)_mm_shuffle_epi32((__m128i)v11, 229).m128i_i32;
  v12 = (__m128)*((unsigned int *)planeFace + 10);
  v19 = *((float *)planeFace + 11);
  v13 = _mm_mul_ps(
          _mm_shuffle_ps(_mm_shuffle_ps(v12, v11, 0), v11, 226),
          _mm_min_ps(*(__m128 *)&stru_3E61A0.x, _mm_max_ps((__m128)xmmword_3E7600, v10)));
  v14 = (float)(fminf(3.4028235e38, fmaxf(-3.4028235e38, v9.m128_f32[0])) * v5.m128_f32[0]) + v13.m128_f32[0];
  v15 = _mm_shuffle_ps(v13, v13, 229);
  v15.m128_f32[0] = v15.m128_f32[0] + v14;
  v21 = v15;
  v5.m128_f32[0] = v5.m128_f32[0] * v9.m128_f32[0];
  v16 = _mm_shuffle_ps(_mm_shuffle_ps(v9, v10, 0), v10, 226);
  v5.m128_f32[0] = v5.m128_f32[0] + (float)(v10.m128_f32[0] * v11.m128_f32[0]);
  v17 = _mm_shuffle_ps(v10, v10, 229);
  v18 = v17;
  v18.m128_f32[0] = (float)((float)(v17.m128_f32[0] * v12.m128_f32[0]) + v5.m128_f32[0]) - v19;
  _mm_storel_ps(
    (double *)&point.x,
    _mm_add_ps(v16, _mm_mul_ps((__m128)_mm_shuffle_epi32((__m128i)_mm_xor_ps(v18, *(__m128 *)&stru_3E4970.x), 80), v11)));
  point.z = v17.m128_f32[0] - (float)(v12.m128_f32[0] * v18.m128_f32[0]);
  RBX::POLY::Face::pointInFaceBorders(planeFace, &point);
}


// Address: 0x1e02f00 | Name: _ZN3RBX9Collision12FaceFacePair19updatePairInContactERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
bool __fastcall RBX::Collision::FaceFacePair::updatePairInContact(
        RBX::Collision::FaceFacePair *this,
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        float a3,
        float overlapIgnored)
{
  RBX::Collision::FaceFacePair::VertexStatusArray *v4; // r15
  _BYTE *v5; // rbx
  __int64 v6; // r13
  int v7; // r14d
  RBX::Collision::FaceFacePair *v8; // rbp
  const RBX::CoordinateFrame *CoordinateFrame; // r12
  const RBX::CoordinateFrame *v10; // rax
  __int128 v11; // xmm0
  bool v12; // al
  const RBX::POLY::Face *otherFace; // rsi
  __int64 v15; // rbx
  unsigned __int64 v16; // rbx
  unsigned __int64 v17; // r15
  __int64 v18; // rbp
  unsigned __int64 v19; // rcx
  __int64 v20; // rdx
  __int64 v21; // rax
  const RBX::POLY::Vertex **v22; // rax
  __int64 v23; // rdx
  _BOOL8 v24; // rdi
  const RBX::POLY::Vertex *v25; // rax
  const RBX::POLY::Vertex *v26; // rdx
  boost::array<RBX::Collision::FaceFacePair::VertexStatus,8>::$DB43E7B79C293B467434A0ADAC2C3718 v27; // ecx
  bool v28; // al
  int v29; // ecx
  RBX::Collision::FaceFacePair *v30; // rdi
  const RBX::POLY::Vertex *v31; // rsi
  bool resultOut; // [rsp+Bh] [rbp-12Dh] BYREF
  float v33; // [rsp+Ch] [rbp-12Ch]
  RBX::Collision::FaceFacePair *v34; // [rsp+10h] [rbp-128h]
  RBX::Collision::PolyCollisionConnectorArray *v35; // [rsp+18h] [rbp-120h]
  _BYTE otherInMe[60]; // [rsp+20h] [rbp-118h] BYREF
  __int128 v37; // [rsp+5Ch] [rbp-DCh]
  __int64 v38; // [rsp+6Ch] [rbp-CCh]
  __int64 v39; // [rsp+74h] [rbp-C4h] BYREF
  int v40; // [rsp+7Ch] [rbp-BCh]
  G3D::CoordinateFrame v41; // [rsp+80h] [rbp-B8h] BYREF
  RBX::Collision::FaceFacePair::VertexStatusArray v42; // [rsp+B0h] [rbp-88h] BYREF
  __int64 v43; // [rsp+F8h] [rbp-40h]

  v33 = a3;
  v35 = collisionConnectors;
  v34 = this;
  if ( !this->otherFace )
    return 0;
  v42.num = 0;
  v43 = 0;
  *(_OWORD *)otherInMe = 0x3F800000u;
  *(_OWORD *)&otherInMe[16] = 0x3F800000u;
  *(_DWORD *)&otherInMe[32] = 1065353216;
  _mm_storel_ps((double *)&otherInMe[36], (__m128)0LL);
  *(_OWORD *)&otherInMe[44] = *(_OWORD *)&up.x;
  v37 = *(_OWORD *)&up.x;
  v38 = 0x3F80000000000000LL;
  _mm_storel_ps((double *)&v39, (__m128)0LL);
  v40 = 0;
  resultOut = 0;
  v4 = &v42;
  v5 = otherInMe;
  v6 = 1;
  do
  {
    v7 = v6 - 1;
    if ( (unsigned __int64)(v6 - 1) > 1 )
    {
      otherFace = v34->otherFace;
      v15 = *((_QWORD *)otherFace + 2) - *((_QWORD *)otherFace + 1);
      if ( !v15 )
        return resultOut;
      v16 = v15 >> 3;
      LOBYTE(v7) = resultOut;
      v17 = 1;
      v18 = 0;
      while ( 1 )
      {
        v19 = v17 % v16;
        v20 = *((_QWORD *)otherFace + 1);
        v21 = *(_QWORD *)(v20 + (v18 >> 29));
        if ( otherFace )
        {
          v22 = (const RBX::POLY::Vertex **)(v21 + 8LL * (*(_QWORD *)(v21 + 24) != (_QWORD)otherFace) + 8);
          v23 = *(_QWORD *)(v20 + 8LL * (int)v19);
          v24 = *(_QWORD *)(v23 + 24) != (_QWORD)otherFace;
        }
        else
        {
          v22 = (const RBX::POLY::Vertex **)(v21 + 8);
          v23 = *(_QWORD *)(v20 + 8LL * (int)v19);
          v24 = 0;
        }
        v25 = *v22;
        v26 = *(const RBX::POLY::Vertex **)(v23 + 8 * v24 + 8);
        v27 = v42.data.elems[v19];
        switch ( *((_DWORD *)&v41.translation.z + v17) )
        {
          case 0:
            if ( v27 == BELOW_OUTSIDE )
              goto LABEL_24;
            goto LABEL_31;
          case 1:
            if ( v27 == BELOW_OUTSIDE )
            {
LABEL_23:
              v28 = RBX::Collision::FaceFacePair::checkTwoSideIntersections(
                      v34,
                      v25,
                      v26,
                      (const RBX::CoordinateFrame *)otherInMe,
                      v35,
                      v33);
              goto LABEL_28;
            }
            if ( v27 == BELOW_INSIDE )
              goto LABEL_24;
            goto LABEL_31;
          case 2:
            if ( v27 == BELOW_OUTSIDE )
            {
              v30 = v34;
              v31 = v25;
LABEL_27:
              v28 = RBX::Collision::FaceFacePair::validateOneSideIntersection(
                      v30,
                      v31,
                      v26,
                      (const RBX::CoordinateFrame *)otherInMe,
                      v35,
                      v33);
            }
            else
            {
              if ( v27 != ABOVE_OUTSIDE )
                goto LABEL_31;
LABEL_24:
              v28 = RBX::Collision::FaceFacePair::checkOneSideIntersection(
                      v34,
                      v25,
                      v26,
                      (const RBX::CoordinateFrame *)otherInMe,
                      v35,
                      v33);
            }
LABEL_28:
            LOBYTE(v29) = 1;
            if ( !v28 )
              v29 = v7;
            v7 = v29;
LABEL_31:
            if ( v17 >= v16 )
              return v7;
            otherFace = v34->otherFace;
            ++v17;
            v18 += 0x100000000LL;
            break;
          case 3:
            switch ( v27 )
            {
              case ABOVE_INSIDE:
                goto LABEL_24;
              case ABOVE_OUTSIDE:
              case BELOW_OUTSIDE:
                goto LABEL_23;
              case BELOW_INSIDE:
                v30 = v34;
                v31 = v26;
                v26 = v25;
                goto LABEL_27;
              default:
                goto LABEL_31;
            }
            goto LABEL_31;
          default:
            goto LABEL_31;
        }
      }
    }
    v8 = v34;
    CoordinateFrame = RBX::Primitive::getCoordinateFrame(*((const RBX::Primitive **)&v34->_vptr$PolyPair + v6));
    v10 = RBX::Primitive::getCoordinateFrame(v8->primitive[v6 & 1]);
    G3D::CoordinateFrame::toObjectSpace(&v41, CoordinateFrame, v10);
    *((_DWORD *)v5 + 8) = LODWORD(v41.rotation.elt[2][2]);
    v11 = *(_OWORD *)&v41.rotation.elt[0][0];
    *((_OWORD *)v5 + 1) = *(_OWORD *)&v41.rotation.elt[1][1];
    *(_OWORD *)v5 = v11;
    *((G3D::Vector3 *)v5 + 3) = v41.translation;
    v12 = RBX::Collision::FaceFacePair::testVerticesInside(
            v8,
            v6 - 1,
            v4++,
            (const RBX::CoordinateFrame *)v5,
            v35,
            &resultOut,
            v33);
    v5 += 48;
    ++v6;
  }
  while ( !v12 );
  return resultOut;
}


// Address: 0x1e03240 | Name: _ZN3RBX9Collision12FaceFacePair12loadVerticesEPNS_10FixedArrayINS1_12VertexStatusELm8EEEPN3G3D15CoordinateFrameERNS2_IPNS0_29FeaturePolyCollisionConnectorELm8EEERbf
char __fastcall RBX::Collision::FaceFacePair::loadVertices(
        RBX::Collision::FaceFacePair *this,
        RBX::Collision::FaceFacePair::VertexStatusArray *vertexStatus,
        RBX::CoordinateFrame *vertexInFace,
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        bool *resultOut,
        float overlapIgnored)
{
  __int64 i; // r15
  const RBX::CoordinateFrame *CoordinateFrame; // r14
  const RBX::CoordinateFrame *v10; // rax
  __int128 v11; // xmm0
  G3D::CoordinateFrame v17; // [rsp+18h] [rbp-60h] BYREF

  for ( i = 1; (unsigned __int64)(i - 1) <= 1; ++i )
  {
    CoordinateFrame = RBX::Primitive::getCoordinateFrame(*((const RBX::Primitive **)&this->_vptr$PolyPair + i));
    v10 = RBX::Primitive::getCoordinateFrame(this->primitive[i & 1]);
    G3D::CoordinateFrame::toObjectSpace(&v17, CoordinateFrame, v10);
    vertexInFace->rotation.elt[2][2] = v17.rotation.elt[2][2];
    v11 = *(_OWORD *)&v17.rotation.elt[0][0];
    *(_OWORD *)&vertexInFace->rotation.elt[1][1] = *(_OWORD *)&v17.rotation.elt[1][1];
    *(_OWORD *)&vertexInFace->rotation.elt[0][0] = v11;
    vertexInFace->translation = v17.translation;
    if ( RBX::Collision::FaceFacePair::testVerticesInside(
           this,
           i - 1,
           vertexStatus++,
           vertexInFace++,
           collisionConnectors,
           resultOut,
           overlapIgnored) )
    {
      return 1;
    }
  }
  return 0;
}


// Address: 0x1e03330 | Name: _ZN3RBX9Collision12FaceFacePair24checkOneSideIntersectionEPKNS_4POLY6VertexES5_RKN3G3D15CoordinateFrameERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
__int64 __fastcall RBX::Collision::FaceFacePair::checkOneSideIntersection(
        RBX::Collision::FaceFacePair *this,
        const RBX::POLY::Vertex *v0,
        const RBX::POLY::Vertex *v1,
        const RBX::CoordinateFrame *otherInMe,
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        __m128 overlapIgnored)
{
  __m128 v9; // xmm4
  __m128 v10; // xmm7
  __m128 v11; // xmm0
  __m128 v12; // xmm2
  __m128 v13; // xmm1
  __m128 v14; // xmm9
  __m128 v15; // xmm8
  __m128 v16; // xmm5
  float v17; // xmm6_4
  float v18; // xmm3_4
  float z; // xmm10_4
  __m128 v20; // xmm0
  __m128 v21; // xmm5
  __m128 v22; // xmm7
  int InternalExtrusionIntersection; // eax
  int (**v24)(void); // r14
  const RBX::POLY::Edge *v25; // r12
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // r15
  const RBX::Plane *mainFace; // rdi
  __int64 v28; // rax
  __int64 v29; // rcx
  __int64 v30; // rax
  __m128 v31; // xmm3
  float v32; // xmm1_4
  float v33; // xmm2_4
  float v34; // xmm4_4
  __m128 v35; // xmm0
  __m128 v36; // xmm2
  float v37; // xmm1_4
  __m128 v38; // xmm2
  float v39; // xmm4_4
  __m128 v40; // xmm4
  const RBX::POLY::Vertex *v41; // rcx
  const RBX::POLY::Vertex *v42; // rdx
  __m128 v43; // xmm3
  float v44; // xmm1_4
  __m128 v45; // xmm2
  float v46; // xmm1_4
  __m128 v47; // xmm2
  unsigned int v48; // ecx
  RBX::Line v50; // [rsp-10h] [rbp-B8h] BYREF
  RBX::Vector3 p0; // [rsp+10h] [rbp-98h] BYREF
  G3D::Line edgeId; // [rsp+20h] [rbp-88h] BYREF
  G3D::Line faceId; // [rsp+40h] [rbp-68h] BYREF
  __m128 v54; // [rsp+60h] [rbp-48h]

  v54 = overlapIgnored;
  v9 = (__m128)*((unsigned int *)v0 + 2);
  v10 = (__m128)*((unsigned int *)v0 + 3);
  v11 = (__m128)*((unsigned int *)v0 + 4);
  v12 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][0]), (__m128)LODWORD(otherInMe->rotation.elt[1][0]));
  v13 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][1]), (__m128)LODWORD(otherInMe->rotation.elt[1][1]));
  v14 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][2]), (__m128)LODWORD(otherInMe->rotation.elt[1][2]));
  v15 = (__m128)*(unsigned __int64 *)&otherInMe->translation.x;
  v16 = _mm_add_ps(
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v11, v11, 224), v14),
            _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v10, v10, 224), v13), _mm_mul_ps(_mm_shuffle_ps(v9, v9, 224), v12))),
          v15);
  v17 = otherInMe->rotation.elt[2][0];
  v18 = otherInMe->rotation.elt[2][1];
  v10.m128_f32[0] = (float)(v10.m128_f32[0] * v18) + (float)(v9.m128_f32[0] * v17);
  v9.m128_i32[0] = LODWORD(otherInMe->rotation.elt[2][2]);
  z = otherInMe->translation.z;
  _mm_storel_ps((double *)&p0.x, v16);
  p0.z = (float)((float)(v11.m128_f32[0] * v9.m128_f32[0]) + v10.m128_f32[0]) + z;
  v20 = (__m128)*((unsigned int *)v1 + 2);
  v21 = (__m128)*((unsigned int *)v1 + 3);
  v22 = (__m128)*((unsigned int *)v1 + 4);
  _mm_storel_ps(
    (double *)&v50._point.z,
    _mm_add_ps(
      _mm_add_ps(
        _mm_mul_ps(_mm_shuffle_ps(v22, v22, 224), v14),
        _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v21, v21, 224), v13), _mm_mul_ps(_mm_shuffle_ps(v20, v20, 224), v12))),
      v15));
  v50._direction.y = (float)((float)((float)(v18 * v21.m128_f32[0]) + (float)(v17 * v20.m128_f32[0]))
                           + (float)(v9.m128_f32[0] * v22.m128_f32[0]))
                   + z;
  InternalExtrusionIntersection = RBX::POLY::Face::findInternalExtrusionIntersection(
                                    this->mainFace,
                                    &p0,
                                    (const RBX::Vector3 *)&v50._point.z);
  if ( InternalExtrusionIntersection < 0 )
    return 0;
  v24 = (int (**)(void))(unsigned int)InternalExtrusionIntersection;
  v25 = RBX::POLY::Vertex::recoverEdge(v0, v1);
  CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                         collisionConnectors,
                         this->primitive[0],
                         this->primitive[1],
                         RBX::Collision::FeaturePolyPair::FACE_EDGE_PAIR);
  mainFace = (const RBX::Plane *)this->mainFace;
  RBX::POLY::Face::getSidePlane((const RBX::POLY::Face *)mainFace, (int)v24);
  v28 = *(_QWORD *)(*((_QWORD *)this->mainFace + 1) + 8LL * (int)v24);
  v29 = *(_QWORD *)(v28 + 8);
  v30 = *(_QWORD *)(v28 + 16);
  v31 = _mm_sub_ps((__m128)*(unsigned __int64 *)(v30 + 8), (__m128)*(unsigned __int64 *)(v29 + 8));
  v32 = *(float *)(v30 + 16) - *(float *)(v29 + 16);
  v33 = _mm_shuffle_ps(v31, v31, 229).m128_f32[0];
  v34 = fsqrt((float)(v32 * v32) + (float)((float)(v33 * v33) + (float)(v31.m128_f32[0] * v31.m128_f32[0])));
  v35 = (__m128)0x3F800000u;
  v36 = (__m128)0x3F800000u;
  v36.m128_f32[0] = 1.0 / v34;
  v37 = v32 * (float)(1.0 / v34);
  v38 = _mm_mul_ps(_mm_shuffle_ps(v36, v36, 224), v31);
  faceId._vptr$Line = (int (**)(void))&edgeLine1;
  faceId._point = *(G3D::Vector3 *)(v29 + 8);
  v39 = _mm_shuffle_ps(v38, v38, 229).m128_f32[0];
  v31.m128_f32[0] = fsqrt((float)(v37 * v37) + (float)((float)(v39 * v39) + (float)(v38.m128_f32[0] * v38.m128_f32[0])));
  v40 = (__m128)0x3F800000u;
  v40.m128_f32[0] = 1.0 / v31.m128_f32[0];
  _mm_storel_ps((double *)&faceId._direction.x, _mm_mul_ps(_mm_shuffle_ps(v40, v40, 224), v38));
  faceId._direction.z = v37 * (float)(1.0 / v31.m128_f32[0]);
  v41 = v25->vertex[0];
  v42 = v25->vertex[1];
  v43 = _mm_sub_ps((__m128)*((unsigned __int64 *)v42 + 1), (__m128)*((unsigned __int64 *)v41 + 1));
  v44 = *((float *)v42 + 4) - *((float *)v41 + 4);
  v40.m128_f32[0] = _mm_shuffle_ps(v43, v43, 229).m128_f32[0];
  v45 = (__m128)0x3F800000u;
  v45.m128_f32[0] = 1.0
                  / fsqrt(
                      (float)(v44 * v44)
                    + (float)((float)(v40.m128_f32[0] * v40.m128_f32[0]) + (float)(v43.m128_f32[0] * v43.m128_f32[0])));
  v46 = v44 * v45.m128_f32[0];
  v47 = _mm_mul_ps(_mm_shuffle_ps(v45, v45, 224), v43);
  edgeId._vptr$Line = (int (**)(void))&edgeLine1;
  edgeId._point = *(G3D::Vector3 *)((char *)v41 + 8);
  v40.m128_f32[0] = _mm_shuffle_ps(v47, v47, 229).m128_f32[0];
  v35.m128_f32[0] = 1.0
                  / fsqrt(
                      (float)(v46 * v46)
                    + (float)((float)(v40.m128_f32[0] * v40.m128_f32[0]) + (float)(v47.m128_f32[0] * v47.m128_f32[0])));
  _mm_storel_ps((double *)&edgeId._direction.x, _mm_mul_ps(_mm_shuffle_ps(v35, v35, 224), v47));
  edgeId._direction.z = v46 * v35.m128_f32[0];
  *(_QWORD *)&v50._point.x = LODWORD(v25->id);
  v50._vptr$Line = v24;
  RBX::Collision::FaceFacePair::updateFaceEdgeCollision(
    this,
    CollisionConnector,
    mainFace + 2,
    (const RBX::Plane *)v41,
    &faceId,
    &edgeId,
    v50);
  LOBYTE(v48) = 1;
  if ( CollisionConnector->depth >= (float)-v54.m128_f32[0] )
  {
    *(_QWORD *)&CollisionConnector->normal.x = 0;
    CollisionConnector->normal.z = 0.0;
    return 0;
  }
  return v48;
}


// Address: 0x1e03680 | Name: _ZN3RBX9Collision12FaceFacePair25checkTwoSideIntersectionsEPKNS_4POLY6VertexES5_RKN3G3D15CoordinateFrameERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
__int64 __fastcall RBX::Collision::FaceFacePair::checkTwoSideIntersections(
        RBX::Collision::FaceFacePair *this,
        const RBX::POLY::Vertex *v0,
        const RBX::POLY::Vertex *v1,
        const RBX::CoordinateFrame *otherInMe,
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        __m128 overlapIgnored)
{
  __m128 v10; // xmm4
  __m128 v11; // xmm7
  __m128 v12; // xmm0
  __m128 v13; // xmm2
  __m128 v14; // xmm1
  __m128 v15; // xmm9
  __m128 v16; // xmm8
  __m128 v17; // xmm5
  float v18; // xmm6_4
  float v19; // xmm3_4
  float z; // xmm10_4
  __m128 v21; // xmm0
  __m128 v22; // xmm5
  __m128 v23; // xmm7
  const RBX::POLY::Edge *v24; // r14
  RBX::Primitive *v25; // rsi
  RBX::Primitive *v26; // rdx
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // r13
  const RBX::Plane *mainFace; // rdi
  int (**x_low)(void); // rax
  __int64 v30; // rcx
  __int64 v31; // rdx
  __int64 v32; // rcx
  __m128 v33; // xmm3
  float v34; // xmm1_4
  float v35; // xmm2_4
  float v36; // xmm4_4
  __m128 v37; // xmm0
  __m128 v38; // xmm2
  float v39; // xmm1_4
  __m128 v40; // xmm2
  float v41; // xmm4_4
  __m128 v42; // xmm4
  const RBX::POLY::Vertex *v43; // rdx
  const RBX::POLY::Vertex *v44; // rsi
  __m128 v45; // xmm3
  float v46; // xmm1_4
  __m128 v47; // xmm2
  float v48; // xmm1_4
  __m128 v49; // xmm2
  unsigned int v50; // ecx
  unsigned int v51; // r13d
  const RBX::POLY::Edge *v52; // r12
  RBX::Collision::FeaturePolyCollisionConnector *v53; // r14
  const RBX::Plane *v54; // rdi
  int (**z_low)(void); // rax
  __int64 v56; // rcx
  __int64 v57; // rdx
  __int64 v58; // rcx
  __m128 v59; // xmm3
  float v60; // xmm1_4
  float v61; // xmm2_4
  float v62; // xmm4_4
  __m128 v63; // xmm0
  __m128 v64; // xmm2
  float v65; // xmm1_4
  __m128 v66; // xmm2
  float v67; // xmm4_4
  __m128 v68; // xmm4
  const RBX::POLY::Vertex *v69; // rdx
  const RBX::POLY::Vertex *v70; // rsi
  __m128 v71; // xmm3
  float v72; // xmm1_4
  __m128 v73; // xmm2
  float v74; // xmm1_4
  __m128 v75; // xmm2
  RBX::Line v77; // [rsp-10h] [rbp-108h] BYREF
  RBX::Vector3 p1; // [rsp+10h] [rbp-E8h] BYREF
  RBX::Vector3 p0; // [rsp+20h] [rbp-D8h] BYREF
  __m128 v80; // [rsp+30h] [rbp-C8h]
  G3D::Line v81; // [rsp+48h] [rbp-B0h] BYREF
  G3D::Line v82; // [rsp+68h] [rbp-90h] BYREF
  G3D::Line edgeId; // [rsp+88h] [rbp-70h] BYREF
  G3D::Line faceId[2]; // [rsp+A8h] [rbp-50h] BYREF

  v80 = overlapIgnored;
  v10 = (__m128)*((unsigned int *)v0 + 2);
  v11 = (__m128)*((unsigned int *)v0 + 3);
  v12 = (__m128)*((unsigned int *)v0 + 4);
  v13 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][0]), (__m128)LODWORD(otherInMe->rotation.elt[1][0]));
  v14 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][1]), (__m128)LODWORD(otherInMe->rotation.elt[1][1]));
  v15 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][2]), (__m128)LODWORD(otherInMe->rotation.elt[1][2]));
  v16 = (__m128)*(unsigned __int64 *)&otherInMe->translation.x;
  v17 = _mm_add_ps(
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v12, v12, 224), v15),
            _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v11, v11, 224), v14), _mm_mul_ps(_mm_shuffle_ps(v10, v10, 224), v13))),
          v16);
  v18 = otherInMe->rotation.elt[2][0];
  v19 = otherInMe->rotation.elt[2][1];
  v11.m128_f32[0] = (float)(v11.m128_f32[0] * v19) + (float)(v10.m128_f32[0] * v18);
  v10.m128_i32[0] = LODWORD(otherInMe->rotation.elt[2][2]);
  z = otherInMe->translation.z;
  _mm_storel_ps((double *)&p0.x, v17);
  p0.z = (float)((float)(v12.m128_f32[0] * v10.m128_f32[0]) + v11.m128_f32[0]) + z;
  v21 = (__m128)*((unsigned int *)v1 + 2);
  v22 = (__m128)*((unsigned int *)v1 + 3);
  v23 = (__m128)*((unsigned int *)v1 + 4);
  _mm_storel_ps(
    (double *)&p1.x,
    _mm_add_ps(
      _mm_add_ps(
        _mm_mul_ps(_mm_shuffle_ps(v23, v23, 224), v15),
        _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v22, v22, 224), v14), _mm_mul_ps(_mm_shuffle_ps(v21, v21, 224), v13))),
      v16));
  p1.z = (float)((float)((float)(v19 * v22.m128_f32[0]) + (float)(v18 * v21.m128_f32[0]))
               + (float)(v10.m128_f32[0] * v23.m128_f32[0]))
       + z;
  v77._direction.x = NAN;
  v77._point.z = NAN;
  RBX::POLY::Face::findInternalExtrusionIntersections(
    this->mainFace,
    &p0,
    &p1,
    (int *)&v77._direction,
    (int *)&v77._point.z);
  if ( LODWORD(v77._direction.x) == -1 )
    goto LABEL_4;
  v24 = RBX::POLY::Vertex::recoverEdge(v0, v1);
  v25 = this->primitive[0];
  v26 = this->primitive[1];
  *(_QWORD *)&v77._direction.y = collisionConnectors;
  CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                         collisionConnectors,
                         v25,
                         v26,
                         RBX::Collision::FeaturePolyPair::FACE_EDGE_PAIR);
  mainFace = (const RBX::Plane *)this->mainFace;
  RBX::POLY::Face::getSidePlane((const RBX::POLY::Face *)mainFace, SLODWORD(v77._direction.x));
  x_low = (int (**)(void))SLODWORD(v77._direction.x);
  v30 = *(_QWORD *)(*((_QWORD *)this->mainFace + 1) + 8LL * SLODWORD(v77._direction.x));
  v31 = *(_QWORD *)(v30 + 8);
  v32 = *(_QWORD *)(v30 + 16);
  v33 = _mm_sub_ps((__m128)*(unsigned __int64 *)(v32 + 8), (__m128)*(unsigned __int64 *)(v31 + 8));
  v34 = *(float *)(v32 + 16) - *(float *)(v31 + 16);
  v35 = _mm_shuffle_ps(v33, v33, 229).m128_f32[0];
  v36 = fsqrt((float)(v34 * v34) + (float)((float)(v35 * v35) + (float)(v33.m128_f32[0] * v33.m128_f32[0])));
  v37 = (__m128)0x3F800000u;
  v38 = (__m128)0x3F800000u;
  v38.m128_f32[0] = 1.0 / v36;
  v39 = v34 * (float)(1.0 / v36);
  v40 = _mm_mul_ps(_mm_shuffle_ps(v38, v38, 224), v33);
  faceId[0]._vptr$Line = (int (**)(void))&edgeLine1;
  faceId[0]._point = *(G3D::Vector3 *)(v31 + 8);
  v41 = _mm_shuffle_ps(v40, v40, 229).m128_f32[0];
  v33.m128_f32[0] = fsqrt((float)(v39 * v39) + (float)((float)(v41 * v41) + (float)(v40.m128_f32[0] * v40.m128_f32[0])));
  v42 = (__m128)0x3F800000u;
  v42.m128_f32[0] = 1.0 / v33.m128_f32[0];
  _mm_storel_ps((double *)&faceId[0]._direction.x, _mm_mul_ps(_mm_shuffle_ps(v42, v42, 224), v40));
  faceId[0]._direction.z = v39 * (float)(1.0 / v33.m128_f32[0]);
  v43 = v24->vertex[0];
  v44 = v24->vertex[1];
  v45 = _mm_sub_ps((__m128)*((unsigned __int64 *)v44 + 1), (__m128)*((unsigned __int64 *)v43 + 1));
  v46 = *((float *)v44 + 4) - *((float *)v43 + 4);
  v42.m128_f32[0] = _mm_shuffle_ps(v45, v45, 229).m128_f32[0];
  v47 = (__m128)0x3F800000u;
  v47.m128_f32[0] = 1.0
                  / fsqrt(
                      (float)(v46 * v46)
                    + (float)((float)(v42.m128_f32[0] * v42.m128_f32[0]) + (float)(v45.m128_f32[0] * v45.m128_f32[0])));
  v48 = v46 * v47.m128_f32[0];
  v49 = _mm_mul_ps(_mm_shuffle_ps(v47, v47, 224), v45);
  edgeId._vptr$Line = (int (**)(void))&edgeLine1;
  edgeId._point = *(G3D::Vector3 *)((char *)v43 + 8);
  v42.m128_f32[0] = _mm_shuffle_ps(v49, v49, 229).m128_f32[0];
  v37.m128_f32[0] = 1.0
                  / fsqrt(
                      (float)(v48 * v48)
                    + (float)((float)(v42.m128_f32[0] * v42.m128_f32[0]) + (float)(v49.m128_f32[0] * v49.m128_f32[0])));
  _mm_storel_ps((double *)&edgeId._direction.x, _mm_mul_ps(_mm_shuffle_ps(v37, v37, 224), v49));
  edgeId._direction.z = v48 * v37.m128_f32[0];
  *(_QWORD *)&v77._point.x = LODWORD(v24->id);
  v77._vptr$Line = x_low;
  RBX::Collision::FaceFacePair::updateFaceEdgeCollision(
    this,
    CollisionConnector,
    mainFace + 2,
    (const RBX::Plane *)LODWORD(v24->id),
    faceId,
    &edgeId,
    v77);
  LOBYTE(v50) = 1;
  collisionConnectors = *(RBX::Collision::PolyCollisionConnectorArray **)&v77._direction.y;
  if ( CollisionConnector->depth >= (float)-v80.m128_f32[0] )
  {
    *(_QWORD *)&CollisionConnector->normal.x = 0;
    CollisionConnector->normal.z = 0.0;
LABEL_4:
    v50 = 0;
  }
  if ( LODWORD(v77._point.z) != -1 )
  {
    v51 = v50;
    v52 = RBX::POLY::Vertex::recoverEdge(v0, v1);
    v53 = RBX::Collision::FeaturePolyContact::createCollisionConnector(
            collisionConnectors,
            this->primitive[0],
            this->primitive[1],
            RBX::Collision::FeaturePolyPair::FACE_EDGE_PAIR);
    v54 = (const RBX::Plane *)this->mainFace;
    RBX::POLY::Face::getSidePlane((const RBX::POLY::Face *)v54, SLODWORD(v77._point.z));
    z_low = (int (**)(void))SLODWORD(v77._point.z);
    v56 = *(_QWORD *)(*((_QWORD *)this->mainFace + 1) + 8LL * SLODWORD(v77._point.z));
    v57 = *(_QWORD *)(v56 + 8);
    v58 = *(_QWORD *)(v56 + 16);
    v59 = _mm_sub_ps((__m128)*(unsigned __int64 *)(v58 + 8), (__m128)*(unsigned __int64 *)(v57 + 8));
    v60 = *(float *)(v58 + 16) - *(float *)(v57 + 16);
    v61 = _mm_shuffle_ps(v59, v59, 229).m128_f32[0];
    v62 = fsqrt((float)(v60 * v60) + (float)((float)(v61 * v61) + (float)(v59.m128_f32[0] * v59.m128_f32[0])));
    v63 = (__m128)0x3F800000u;
    v64 = (__m128)0x3F800000u;
    v64.m128_f32[0] = 1.0 / v62;
    v65 = v60 * (float)(1.0 / v62);
    v66 = _mm_mul_ps(_mm_shuffle_ps(v64, v64, 224), v59);
    v82._vptr$Line = (int (**)(void))&edgeLine1;
    v82._point = *(G3D::Vector3 *)(v57 + 8);
    v67 = _mm_shuffle_ps(v66, v66, 229).m128_f32[0];
    v59.m128_f32[0] = fsqrt((float)(v65 * v65) + (float)((float)(v67 * v67) + (float)(v66.m128_f32[0] * v66.m128_f32[0])));
    v68 = (__m128)0x3F800000u;
    v68.m128_f32[0] = 1.0 / v59.m128_f32[0];
    _mm_storel_ps((double *)&v82._direction.x, _mm_mul_ps(_mm_shuffle_ps(v68, v68, 224), v66));
    v82._direction.z = v65 * (float)(1.0 / v59.m128_f32[0]);
    v69 = v52->vertex[0];
    v70 = v52->vertex[1];
    v71 = _mm_sub_ps((__m128)*((unsigned __int64 *)v70 + 1), (__m128)*((unsigned __int64 *)v69 + 1));
    v72 = *((float *)v70 + 4) - *((float *)v69 + 4);
    v68.m128_f32[0] = _mm_shuffle_ps(v71, v71, 229).m128_f32[0];
    v73 = (__m128)0x3F800000u;
    v73.m128_f32[0] = 1.0
                    / fsqrt(
                        (float)(v72 * v72)
                      + (float)((float)(v68.m128_f32[0] * v68.m128_f32[0]) + (float)(v71.m128_f32[0] * v71.m128_f32[0])));
    v74 = v72 * v73.m128_f32[0];
    v75 = _mm_mul_ps(_mm_shuffle_ps(v73, v73, 224), v71);
    v81._vptr$Line = (int (**)(void))&edgeLine1;
    v81._point = *(G3D::Vector3 *)((char *)v69 + 8);
    v68.m128_f32[0] = _mm_shuffle_ps(v75, v75, 229).m128_f32[0];
    v63.m128_f32[0] = 1.0
                    / fsqrt(
                        (float)(v74 * v74)
                      + (float)((float)(v68.m128_f32[0] * v68.m128_f32[0]) + (float)(v75.m128_f32[0] * v75.m128_f32[0])));
    _mm_storel_ps((double *)&v81._direction.x, _mm_mul_ps(_mm_shuffle_ps(v63, v63, 224), v75));
    v81._direction.z = v74 * v63.m128_f32[0];
    *(_QWORD *)&v77._point.x = LODWORD(v52->id);
    v77._vptr$Line = z_low;
    RBX::Collision::FaceFacePair::updateFaceEdgeCollision(
      this,
      v53,
      v54 + 2,
      (const RBX::Plane *)LODWORD(v52->id),
      &v82,
      &v81,
      v77);
    LOBYTE(v50) = 1;
    if ( v53->depth >= (float)-v80.m128_f32[0] )
    {
      *(_QWORD *)&v53->normal.x = 0;
      v53->normal.z = 0.0;
      return v51;
    }
  }
  return v50;
}


// Address: 0x1e03c40 | Name: _ZN3RBX9Collision12FaceFacePair27validateOneSideIntersectionEPKNS_4POLY6VertexES5_RKN3G3D15CoordinateFrameERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
__int64 __fastcall RBX::Collision::FaceFacePair::validateOneSideIntersection(
        RBX::Collision::FaceFacePair *this,
        const RBX::POLY::Vertex *belowInside,
        const RBX::POLY::Vertex *belowOutside,
        const RBX::CoordinateFrame *otherInMe,
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        __m128 overlapIgnored)
{
  __m128 v9; // xmm4
  __m128 v10; // xmm7
  __m128 v11; // xmm0
  __m128 v12; // xmm2
  __m128 v13; // xmm1
  __m128 v14; // xmm9
  __m128 v15; // xmm8
  __m128 v16; // xmm5
  float v17; // xmm6_4
  float v18; // xmm3_4
  float z; // xmm10_4
  __m128 v20; // xmm0
  __m128 v21; // xmm5
  __m128 v22; // xmm7
  int InternalExtrusionIntersection; // eax
  int (**v24)(void); // r14
  const RBX::POLY::Edge *v25; // r12
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // r15
  const RBX::Plane *mainFace; // rdi
  __int64 v28; // rax
  __int64 v29; // rcx
  __int64 v30; // rax
  __m128 v31; // xmm3
  float v32; // xmm1_4
  float v33; // xmm2_4
  float v34; // xmm4_4
  __m128 v35; // xmm0
  __m128 v36; // xmm2
  float v37; // xmm1_4
  __m128 v38; // xmm2
  float v39; // xmm4_4
  __m128 v40; // xmm4
  const RBX::POLY::Vertex *v41; // rcx
  const RBX::POLY::Vertex *v42; // rdx
  __m128 v43; // xmm3
  float v44; // xmm1_4
  __m128 v45; // xmm2
  float v46; // xmm1_4
  __m128 v47; // xmm2
  unsigned int v48; // ecx
  RBX::Line v50; // [rsp-10h] [rbp-B8h] BYREF
  RBX::Vector3 pBelowInside; // [rsp+10h] [rbp-98h] BYREF
  G3D::Line edgeId; // [rsp+20h] [rbp-88h] BYREF
  G3D::Line faceId; // [rsp+40h] [rbp-68h] BYREF
  __m128 v54; // [rsp+60h] [rbp-48h]

  v54 = overlapIgnored;
  v9 = (__m128)*((unsigned int *)belowInside + 2);
  v10 = (__m128)*((unsigned int *)belowInside + 3);
  v11 = (__m128)*((unsigned int *)belowInside + 4);
  v12 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][0]), (__m128)LODWORD(otherInMe->rotation.elt[1][0]));
  v13 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][1]), (__m128)LODWORD(otherInMe->rotation.elt[1][1]));
  v14 = _mm_unpacklo_ps((__m128)LODWORD(otherInMe->rotation.elt[0][2]), (__m128)LODWORD(otherInMe->rotation.elt[1][2]));
  v15 = (__m128)*(unsigned __int64 *)&otherInMe->translation.x;
  v16 = _mm_add_ps(
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v11, v11, 224), v14),
            _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v10, v10, 224), v13), _mm_mul_ps(_mm_shuffle_ps(v9, v9, 224), v12))),
          v15);
  v17 = otherInMe->rotation.elt[2][0];
  v18 = otherInMe->rotation.elt[2][1];
  v10.m128_f32[0] = (float)(v10.m128_f32[0] * v18) + (float)(v9.m128_f32[0] * v17);
  v9.m128_i32[0] = LODWORD(otherInMe->rotation.elt[2][2]);
  z = otherInMe->translation.z;
  _mm_storel_ps((double *)&pBelowInside.x, v16);
  pBelowInside.z = (float)((float)(v11.m128_f32[0] * v9.m128_f32[0]) + v10.m128_f32[0]) + z;
  v20 = (__m128)*((unsigned int *)belowOutside + 2);
  v21 = (__m128)*((unsigned int *)belowOutside + 3);
  v22 = (__m128)*((unsigned int *)belowOutside + 4);
  _mm_storel_ps(
    (double *)&v50._point.z,
    _mm_add_ps(
      _mm_add_ps(
        _mm_mul_ps(_mm_shuffle_ps(v22, v22, 224), v14),
        _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v21, v21, 224), v13), _mm_mul_ps(_mm_shuffle_ps(v20, v20, 224), v12))),
      v15));
  v50._direction.y = (float)((float)((float)(v18 * v21.m128_f32[0]) + (float)(v17 * v20.m128_f32[0]))
                           + (float)(v9.m128_f32[0] * v22.m128_f32[0]))
                   + z;
  InternalExtrusionIntersection = RBX::POLY::Face::getInternalExtrusionIntersection(
                                    this->mainFace,
                                    &pBelowInside,
                                    (const RBX::Vector3 *)&v50._point.z);
  if ( InternalExtrusionIntersection < 0 )
    return 0;
  v24 = (int (**)(void))(unsigned int)InternalExtrusionIntersection;
  v25 = RBX::POLY::Vertex::recoverEdge(belowInside, belowOutside);
  CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                         collisionConnectors,
                         this->primitive[0],
                         this->primitive[1],
                         RBX::Collision::FeaturePolyPair::FACE_EDGE_PAIR);
  mainFace = (const RBX::Plane *)this->mainFace;
  RBX::POLY::Face::getSidePlane((const RBX::POLY::Face *)mainFace, (int)v24);
  v28 = *(_QWORD *)(*((_QWORD *)this->mainFace + 1) + 8LL * (int)v24);
  v29 = *(_QWORD *)(v28 + 8);
  v30 = *(_QWORD *)(v28 + 16);
  v31 = _mm_sub_ps((__m128)*(unsigned __int64 *)(v30 + 8), (__m128)*(unsigned __int64 *)(v29 + 8));
  v32 = *(float *)(v30 + 16) - *(float *)(v29 + 16);
  v33 = _mm_shuffle_ps(v31, v31, 229).m128_f32[0];
  v34 = fsqrt((float)(v32 * v32) + (float)((float)(v33 * v33) + (float)(v31.m128_f32[0] * v31.m128_f32[0])));
  v35 = (__m128)0x3F800000u;
  v36 = (__m128)0x3F800000u;
  v36.m128_f32[0] = 1.0 / v34;
  v37 = v32 * (float)(1.0 / v34);
  v38 = _mm_mul_ps(_mm_shuffle_ps(v36, v36, 224), v31);
  faceId._vptr$Line = (int (**)(void))&edgeLine1;
  faceId._point = *(G3D::Vector3 *)(v29 + 8);
  v39 = _mm_shuffle_ps(v38, v38, 229).m128_f32[0];
  v31.m128_f32[0] = fsqrt((float)(v37 * v37) + (float)((float)(v39 * v39) + (float)(v38.m128_f32[0] * v38.m128_f32[0])));
  v40 = (__m128)0x3F800000u;
  v40.m128_f32[0] = 1.0 / v31.m128_f32[0];
  _mm_storel_ps((double *)&faceId._direction.x, _mm_mul_ps(_mm_shuffle_ps(v40, v40, 224), v38));
  faceId._direction.z = v37 * (float)(1.0 / v31.m128_f32[0]);
  v41 = v25->vertex[0];
  v42 = v25->vertex[1];
  v43 = _mm_sub_ps((__m128)*((unsigned __int64 *)v42 + 1), (__m128)*((unsigned __int64 *)v41 + 1));
  v44 = *((float *)v42 + 4) - *((float *)v41 + 4);
  v40.m128_f32[0] = _mm_shuffle_ps(v43, v43, 229).m128_f32[0];
  v45 = (__m128)0x3F800000u;
  v45.m128_f32[0] = 1.0
                  / fsqrt(
                      (float)(v44 * v44)
                    + (float)((float)(v40.m128_f32[0] * v40.m128_f32[0]) + (float)(v43.m128_f32[0] * v43.m128_f32[0])));
  v46 = v44 * v45.m128_f32[0];
  v47 = _mm_mul_ps(_mm_shuffle_ps(v45, v45, 224), v43);
  edgeId._vptr$Line = (int (**)(void))&edgeLine1;
  edgeId._point = *(G3D::Vector3 *)((char *)v41 + 8);
  v40.m128_f32[0] = _mm_shuffle_ps(v47, v47, 229).m128_f32[0];
  v35.m128_f32[0] = 1.0
                  / fsqrt(
                      (float)(v46 * v46)
                    + (float)((float)(v40.m128_f32[0] * v40.m128_f32[0]) + (float)(v47.m128_f32[0] * v47.m128_f32[0])));
  _mm_storel_ps((double *)&edgeId._direction.x, _mm_mul_ps(_mm_shuffle_ps(v35, v35, 224), v47));
  edgeId._direction.z = v46 * v35.m128_f32[0];
  *(_QWORD *)&v50._point.x = LODWORD(v25->id);
  v50._vptr$Line = v24;
  RBX::Collision::FaceFacePair::updateFaceEdgeCollision(
    this,
    CollisionConnector,
    mainFace + 2,
    (const RBX::Plane *)v41,
    &faceId,
    &edgeId,
    v50);
  LOBYTE(v48) = 1;
  if ( CollisionConnector->depth >= (float)-v54.m128_f32[0] )
  {
    *(_QWORD *)&CollisionConnector->normal.x = 0;
    CollisionConnector->normal.z = 0.0;
    return 0;
  }
  return v48;
}


// Address: 0x1e03f90 | Name: _ZN3RBX9Collision12FaceFacePair18testVerticesInsideEmRNS_10FixedArrayINS1_12VertexStatusELm8EEERKN3G3D15CoordinateFrameERNS2_IPNS0_29FeaturePolyCollisionConnectorELm8EEERbf
bool __fastcall RBX::Collision::FaceFacePair::testVerticesInside(
        RBX::Collision::FaceFacePair *this,
        size_t faceId,
        RBX::Collision::FaceFacePair::VertexStatusArray *vertexStatus,
        const RBX::CoordinateFrame *vertexInFace,
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        bool *resultOut,
        float overlapIgnored)
{
  __int64 v8; // rcx
  __int64 v9; // r14
  __int64 v10; // rax
  __int64 v11; // rdx
  const RBX::POLY::Face *v12; // r15
  __int64 v13; // r12
  unsigned __int64 v14; // rbp
  const RBX::POLY::Vertex *v15; // r13
  size_t num; // rcx
  boost::array<RBX::Collision::FaceFacePair::VertexStatus,8>::$DB43E7B79C293B467434A0ADAC2C3718 v17; // eax
  char v19; // [rsp+0h] [rbp-68h]
  _BOOL8 v21; // [rsp+18h] [rbp-50h]

  v8 = 0;
  v21 = (faceId & 1) == 0;
  v9 = *((_QWORD *)&this->mainFace + v21);
  v10 = *(_QWORD *)(v9 + 8);
  v19 = 1;
  if ( *(_QWORD *)(v9 + 16) != v10 )
  {
    LOBYTE(v8) = faceId != 0;
    v11 = (__int64)this;
    v12 = (const RBX::POLY::Face *)*((_QWORD *)&this->mainFace + v8);
    v19 = 1;
    v13 = 0;
    v14 = 0;
    do
    {
      v15 = *(const RBX::POLY::Vertex **)(*(_QWORD *)(v10 + (v13 >> 29))
                                        + 8LL * (*(_QWORD *)(*(_QWORD *)(v10 + (v13 >> 29)) + 24LL) != v9)
                                        + 8);
      RBX::Collision::FaceFacePair::vertexInPoly(this, v12, (const RBX::POLY::Mesh *)v11, v15, vertexInFace);
      num = vertexStatus->num;
      vertexStatus->data.elems[num] = v17;
      vertexStatus->num = num + 1;
      if ( v17 == BELOW_INSIDE )
      {
        if ( RBX::Collision::FaceFacePair::vertexInside(
               this,
               this->primitive[faceId],
               this->primitive[v21],
               v15,
               v12,
               collisionConnectors,
               overlapIgnored) )
        {
          *resultOut = 1;
        }
      }
      else
      {
        v19 = 0;
      }
      ++v14;
      v10 = *(_QWORD *)(v9 + 8);
      v11 = 0x100000000LL;
      v13 += 0x100000000LL;
    }
    while ( v14 < (*(_QWORD *)(v9 + 16) - v10) >> 3 );
  }
  return v19 & 1;
}


// Address: 0x1e040e0 | Name: _ZN3RBX9Collision12FaceFacePair12vertexInsideEPNS_9PrimitiveES3_PKNS_4POLY6VertexEPKNS4_4FaceERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
char __fastcall RBX::Collision::FaceFacePair::vertexInside(
        RBX::Collision::FaceFacePair *this,
        RBX::Primitive *pFace,
        RBX::Primitive *pVertex,
        const RBX::POLY::Vertex *inside,
        const G3D::Plane *planeFace,
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        __m128 overlapIgnored,
        __m128 a8)
{
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // rbx
  int v11; // ecx
  G3D::Plane v12; // kr00_16
  RBX::Body *bodyB; // rax
  __m128 v14; // xmm2
  __m128 v15; // xmm6
  __m128 v16; // xmm3
  __m128 v17; // xmm4
  __m128 v18; // xmm0
  float v19; // xmm1_4
  char result; // al
  float v21; // [rsp+0h] [rbp-28h]

  v21 = overlapIgnored.m128_f32[0];
  CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                         collisionConnectors,
                         pFace,
                         pVertex,
                         RBX::Collision::FeaturePolyPair::FACE_VERTEX_POLY_PAIR);
  v11 = *(_DWORD *)inside;
  CollisionConnector->param0 = LODWORD(planeFace->_normal.x);
  CollisionConnector->param1 = v11;
  v12 = G3D::CoordinateFrame::toWorldSpace(&CollisionConnector->bodyA->pv.position, planeFace + 2);
  a8.m128_u64[0] = *(_QWORD *)&v12._normal.z;
  overlapIgnored.m128_u64[0] = *(_QWORD *)&v12._normal.x;
  bodyB = CollisionConnector->bodyB;
  v14 = (__m128)*((unsigned int *)inside + 2);
  v15 = (__m128)_mm_loadl_epi64((const __m128i *)((char *)inside + 12));
  v16 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&bodyB->pv.position.translation.x,
          _mm_add_ps(
            _mm_mul_ps(
              (__m128)_mm_shuffle_epi32((__m128i)v15, 229),
              _mm_unpacklo_ps(
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][2]),
                (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                (__m128)_mm_shuffle_epi32((__m128i)v15, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][1]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(v14, v14, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[0][0]),
                  (__m128)LODWORD(bodyB->pv.position.rotation.elt[1][0]))))));
  v17 = _mm_mul_ps((__m128)*(unsigned __int64 *)&bodyB->pv.position.rotation.elt[2][1], v15);
  v17.m128_f32[0] = (float)(_mm_shuffle_ps(v17, v17, 229).m128_f32[0]
                          + (float)((float)(v14.m128_f32[0] * bodyB->pv.position.rotation.elt[2][0]) + v17.m128_f32[0]))
                  + bodyB->pv.position.translation.z;
  _mm_storel_ps((double *)&CollisionConnector->contactPoint.x, v16);
  LODWORD(CollisionConnector->contactPoint.z) = v17.m128_i32[0];
  _mm_storel_ps((double *)&CollisionConnector->normal.x, overlapIgnored);
  v18 = _mm_mul_ps(overlapIgnored, v16);
  CollisionConnector->normal.z = v12._normal.z;
  v19 = (float)((float)(v12._normal.z * v17.m128_f32[0])
              + (float)(_mm_shuffle_ps(v18, v18, 229).m128_f32[0] + v18.m128_f32[0]))
      - _mm_shuffle_ps(a8, a8, 229).m128_f32[0];
  CollisionConnector->depth = v19;
  result = 1;
  if ( v19 >= (float)-v21 )
  {
    *(_QWORD *)&CollisionConnector->normal.x = 0;
    CollisionConnector->normal.z = 0.0;
    return 0;
  }
  return result;
}


// Address: 0x1e04260 | Name: _ZN3RBX9Collision12EdgeEdgePair13allocateCloneEv
RBX::Collision::PolyPair *__fastcall RBX::Collision::EdgeEdgePair::allocateClone(RBX::Collision::EdgeEdgePair *this)
{
  RBX::Collision::PolyPair *result; // rax

  result = (RBX::Collision::PolyPair *)operator new(0x28u);
  *(_OWORD *)result->primitive = *(_OWORD *)this->primitive;
  result->_vptr$PolyPair = (int (**)(void))&off_299E840;
  *(_OWORD *)&result[1]._vptr$PolyPair = *(_OWORD *)&this->bestEdge0;
  return result;
}


// Address: 0x1e04290 | Name: _ZN3RBX9Collision12EdgeEdgePair4testEv
float __fastcall RBX::Collision::EdgeEdgePair::test(RBX::Collision::EdgeEdgePair *this)
{
  RBX::CoordinateFrame *CoordinateFrame; // rbp
  const RBX::CoordinateFrame *v2; // rax
  float x; // xmm9_4
  float y; // xmm8_4
  __m128 x_low; // xmm12
  __m128 y_low; // xmm0
  __m128 v7; // xmm3
  __m128 v8; // xmm4
  float z; // xmm10_4
  __m128 z_low; // xmm2
  __m128 v11; // xmm1
  __m128 v12; // xmm5
  const G3D::CoordinateFrame *v13; // rbp
  __m128 v14; // xmm3
  const RBX::POLY::Vertex *v15; // r15
  __int64 *v16; // rcx
  size_t id; // rsi
  __int64 v18; // r14
  size_t v19; // rdx
  __int64 *v20; // rsi
  size_t v21; // rcx
  __int64 v22; // rdi
  unsigned __int64 v23; // rdi
  float result; // xmm0_4
  size_t v25; // rcx
  __int64 v26; // rbx
  __int64 v27; // rax
  const RBX::POLY::Vertex *v28; // rcx
  bool v29; // zf
  __m128 v30; // xmm2
  float v31; // xmm0_4
  float v32; // xmm3_4
  __m128 v33; // xmm1
  float v34; // xmm0_4
  __m128 v35; // xmm1
  float v36; // xmm3_4
  __m128 v37; // xmm3
  size_t v38; // r15
  const RBX::POLY::Vertex *v39; // rbx
  __int64 v40; // r13
  __int64 v41; // r14
  __int64 v42; // rax
  const RBX::POLY::Vertex *v43; // rcx
  __m128 v44; // xmm2
  __m128 v45; // xmm0
  float v46; // xmm3_4
  __m128 v47; // xmm1
  float v48; // xmm3_4
  __m128 v49; // xmm3
  __m128 v50; // xmm2
  __m128 v51; // xmm3
  float v52; // xmm4_4
  __m128 v53; // xmm7
  __m128 v54; // xmm1
  float v55; // xmm4_4
  __m128 v56; // xmm0
  G3D::Plane v57; // kr20_16
  G3D::Plane v58; // kr30_16
  __int64 v59; // rax
  float v60; // xmm2_4
  float v61; // xmm3_4
  __int64 v62; // r8
  unsigned __int64 v63; // r8
  float v64; // xmm4_4
  __m128 v65; // xmm7
  int v66; // ebp
  int v67; // ecx
  __int64 v68; // rdx
  unsigned __int64 v69; // rsi
  __int64 v70; // rdi
  __m128 v71; // xmm5
  float v72; // xmm6_4
  __m128i v73; // xmm5
  int v74; // edi
  float v75; // ebx
  __int64 v76; // rax
  float v77; // xmm5_4
  float v78; // xmm6_4
  __int64 v79; // r8
  unsigned __int64 v80; // r8
  float v81; // xmm8_4
  __m128 v82; // xmm1
  int v83; // ebp
  int v84; // ecx
  __int64 v85; // rdx
  unsigned __int64 v86; // rsi
  __int64 v87; // rdi
  __m128 v88; // xmm7
  float v89; // xmm4_4
  __m128i v90; // xmm7
  int v91; // edi
  float v92; // ebx
  int *v93; // rax
  float v94; // xmm0_4
  int *v95; // rax
  float v96; // xmm1_4
  RBX::Collision::EdgeEdgePair *v97; // rcx
  char v98; // al
  float v99; // [rsp+0h] [rbp-168h]
  float v100; // [rsp+0h] [rbp-168h]
  int v101; // [rsp+4h] [rbp-164h] BYREF
  int v102; // [rsp+8h] [rbp-160h] BYREF
  int v103; // [rsp+Ch] [rbp-15Ch] BYREF
  int v104; // [rsp+10h] [rbp-158h] BYREF
  float v105; // [rsp+14h] [rbp-154h]
  G3D::Vector3 v106; // [rsp+18h] [rbp-150h] BYREF
  const RBX::POLY::Vertex *v107; // [rsp+28h] [rbp-140h]
  G3D::CoordinateFrame *v108; // [rsp+30h] [rbp-138h]
  __int64 *v109; // [rsp+38h] [rbp-130h]
  unsigned __int64 v110; // [rsp+40h] [rbp-128h]
  __int64 *v111; // [rsp+48h] [rbp-120h]
  G3D::Line v112; // [rsp+50h] [rbp-118h] BYREF
  __m128 v113; // [rsp+70h] [rbp-F8h]
  __m128 v114; // [rsp+80h] [rbp-E8h]
  const RBX::POLY::Vertex *v115; // [rsp+90h] [rbp-D8h]
  size_t v116; // [rsp+98h] [rbp-D0h]
  unsigned __int64 v117; // [rsp+A0h] [rbp-C8h]
  unsigned __int64 v118; // [rsp+A8h] [rbp-C0h]
  RBX::Collision::EdgeEdgePair *v119; // [rsp+B0h] [rbp-B8h]
  const RBX::POLY::Edge *v120; // [rsp+B8h] [rbp-B0h]
  size_t v121; // [rsp+C0h] [rbp-A8h]
  const G3D::CoordinateFrame *v122; // [rsp+C8h] [rbp-A0h]
  unsigned __int64 v123; // [rsp+D0h] [rbp-98h]
  RBX::Vector3 v124; // [rsp+D8h] [rbp-90h] BYREF
  RBX::Vector3 direction; // [rsp+E8h] [rbp-80h] BYREF
  G3D::Line l; // [rsp+F8h] [rbp-70h] BYREF
  G3D::Line v127; // [rsp+118h] [rbp-50h] BYREF
  G3D::Vector3 v128; // 0:kr00_12.12
  G3D::Vector3 v129; // 0:kr14_12.12

  CoordinateFrame = (RBX::CoordinateFrame *)RBX::Primitive::getCoordinateFrame(this->primitive[0]);
  v2 = RBX::Primitive::getCoordinateFrame(this->primitive[1]);
  x = v2->translation.x;
  y = v2->translation.y;
  x_low = (__m128)LODWORD(CoordinateFrame->translation.x);
  y_low = (__m128)LODWORD(CoordinateFrame->translation.y);
  v7 = (__m128)LODWORD(x);
  v7.m128_f32[0] = x - x_low.m128_f32[0];
  v8 = (__m128)LODWORD(y);
  v8.m128_f32[0] = y - y_low.m128_f32[0];
  z = v2->translation.z;
  z_low = (__m128)LODWORD(CoordinateFrame->translation.z);
  v11 = (__m128)LODWORD(z);
  v11.m128_f32[0] = z - z_low.m128_f32[0];
  v12 = _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(v11, v11, 224), (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[2][0]),
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(v8, v8, 224), (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[1][0]),
            _mm_mul_ps(_mm_shuffle_ps(v7, v7, 224), (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[0][0])));
  v8.m128_f32[0] = (float)((float)(y - y_low.m128_f32[0]) * CoordinateFrame->rotation.elt[1][2])
                 + (float)((float)(x - x_low.m128_f32[0]) * CoordinateFrame->rotation.elt[0][2]);
  v108 = CoordinateFrame;
  v11.m128_f32[0] = (float)(z - z_low.m128_f32[0]) * CoordinateFrame->rotation.elt[2][2];
  v13 = v2;
  _mm_storel_ps((double *)&direction.x, v12);
  direction.z = v11.m128_f32[0] + v8.m128_f32[0];
  x_low.m128_f32[0] = x_low.m128_f32[0] - x;
  y_low.m128_f32[0] = y_low.m128_f32[0] - y;
  z_low.m128_f32[0] = z_low.m128_f32[0] - z;
  v14 = _mm_add_ps(
          _mm_mul_ps(_mm_shuffle_ps(z_low, z_low, 224), (__m128)*(unsigned __int64 *)&v2->rotation.elt[2][0]),
          _mm_add_ps(
            _mm_mul_ps(_mm_shuffle_ps(y_low, y_low, 224), (__m128)*(unsigned __int64 *)&v2->rotation.elt[1][0]),
            _mm_mul_ps(_mm_shuffle_ps(x_low, x_low, 224), (__m128)*(unsigned __int64 *)&v2->rotation.elt[0][0])));
  z_low.m128_f32[0] = (float)(z_low.m128_f32[0] * v2->rotation.elt[2][2])
                    + (float)((float)(y_low.m128_f32[0] * v2->rotation.elt[1][2])
                            + (float)(x_low.m128_f32[0] * v2->rotation.elt[0][2]));
  _mm_storel_ps((double *)&v124.x, v14);
  LODWORD(v124.z) = z_low.m128_i32[0];
  v15 = RBX::POLY::Mesh::farthestVertex(
          *(const RBX::POLY::Mesh **)(*((_QWORD *)this->primitive[0] + 18) + 40LL),
          &direction);
  v107 = RBX::POLY::Mesh::farthestVertex(
           *(const RBX::POLY::Mesh **)(*((_QWORD *)this->primitive[1] + 18) + 40LL),
           &v124);
  v16 = *(__int64 **)(*((_QWORD *)this->primitive[0] + 18) + 40LL);
  id = this->bestEdge0->id;
  v18 = v16[3];
  v109 = v16;
  v118 = 0xCCCCCCCCCCCCCCCDLL * ((v16[4] - v18) >> 3);
  v117 = v118 + id;
  if ( id >= v118 + id )
    return -3.4028235e38;
  v19 = id;
  v20 = *(__int64 **)(*((_QWORD *)this->primitive[1] + 18) + 40LL);
  v119 = this;
  v21 = this->bestEdge1->id;
  v22 = v20[4];
  v111 = v20;
  v23 = 0xCCCCCCCCCCCCCCCDLL * ((v22 - v20[3]) >> 3);
  v116 = v21;
  v123 = v23;
  v110 = v23 + v21;
  result = -3.4028235e38;
  v25 = v19;
  v122 = v13;
  v115 = v15;
  while ( 1 )
  {
    v121 = v25;
    v26 = 5LL * (int)(v25 % v118);
    v27 = *(_QWORD *)(v18 + 40LL * (int)(v25 % v118) + 8);
    v28 = *(const RBX::POLY::Vertex **)(v18 + 40LL * (int)(v25 % v118) + 16);
    if ( (const RBX::POLY::Vertex *)v27 == v15 || (v29 = v28 == v15, v28 = v15, v29) )
    {
      v99 = result;
      v30 = _mm_sub_ps((__m128)*((unsigned __int64 *)v28 + 1), (__m128)*(unsigned __int64 *)(v27 + 8));
      v31 = *((float *)v28 + 4) - *(float *)(v27 + 16);
      v32 = _mm_shuffle_ps(v30, v30, 229).m128_f32[0];
      v33 = (__m128)0x3F800000u;
      v33.m128_f32[0] = 1.0
                      / fsqrt((float)(v31 * v31) + (float)((float)(v32 * v32)
                                                         + (float)(v30.m128_f32[0] * v30.m128_f32[0])));
      v34 = v31 * v33.m128_f32[0];
      v35 = _mm_mul_ps(_mm_shuffle_ps(v33, v33, 224), v30);
      l._vptr$Line = (int (**)(void))&edgeLine1;
      l._point = *(G3D::Vector3 *)(v27 + 8);
      v36 = _mm_shuffle_ps(v35, v35, 229).m128_f32[0];
      v30.m128_f32[0] = fsqrt((float)(v34 * v34) + (float)((float)(v36 * v36)
                                                         + (float)(v35.m128_f32[0] * v35.m128_f32[0])));
      v37 = (__m128)0x3F800000u;
      v37.m128_f32[0] = 1.0 / v30.m128_f32[0];
      _mm_storel_ps((double *)&l._direction.x, _mm_mul_ps(_mm_shuffle_ps(v37, v37, 224), v35));
      l._direction.z = v34 * (float)(1.0 / v30.m128_f32[0]);
      G3D::CoordinateFrame::toWorldSpace(&v127, v108, &l);
      v38 = v116;
      if ( v116 < v110 )
      {
        v120 = (const RBX::POLY::Edge *)(v18 + 8 * v26);
        v39 = v107;
        result = v99;
        while ( 1 )
        {
          v40 = v111[3];
          v41 = 5LL * (int)(v38 % v123);
          v42 = *(_QWORD *)(v40 + 40LL * (int)(v38 % v123) + 8);
          v43 = *(const RBX::POLY::Vertex **)(v40 + 40LL * (int)(v38 % v123) + 16);
          if ( (const RBX::POLY::Vertex *)v42 != v39 )
          {
            v29 = v43 == v39;
            v43 = v39;
            if ( !v29 )
              goto LABEL_36;
          }
          v100 = result;
          v44 = _mm_sub_ps((__m128)*((unsigned __int64 *)v43 + 1), (__m128)*(unsigned __int64 *)(v42 + 8));
          v45 = (__m128)*((unsigned int *)v43 + 4);
          v45.m128_f32[0] = v45.m128_f32[0] - *(float *)(v42 + 16);
          v46 = _mm_shuffle_ps(v44, v44, 229).m128_f32[0];
          v47 = (__m128)0x3F800000u;
          v47.m128_f32[0] = 1.0
                          / fsqrt(
                              (float)(v45.m128_f32[0] * v45.m128_f32[0])
                            + (float)((float)(v46 * v46) + (float)(v44.m128_f32[0] * v44.m128_f32[0])));
          v45.m128_f32[0] = v45.m128_f32[0] * v47.m128_f32[0];
          v54 = _mm_mul_ps(_mm_shuffle_ps(v47, v47, 224), v44);
          v112._vptr$Line = (int (**)(void))&edgeLine1;
          v112._point = *(G3D::Vector3 *)(v42 + 8);
          v48 = _mm_shuffle_ps(v54, v54, 229).m128_f32[0];
          v44.m128_f32[0] = fsqrt(
                              (float)(v45.m128_f32[0] * v45.m128_f32[0])
                            + (float)((float)(v48 * v48) + (float)(v54.m128_f32[0] * v54.m128_f32[0])));
          v49 = (__m128)0x3F800000u;
          v49.m128_f32[0] = 1.0 / v44.m128_f32[0];
          _mm_storel_ps((double *)&v112._direction.x, _mm_mul_ps(_mm_shuffle_ps(v49, v49, 224), v54));
          v112._direction.z = v45.m128_f32[0] * (float)(1.0 / v44.m128_f32[0]);
          G3D::CoordinateFrame::toWorldSpace(&l, v13, &v112);
          v128 = G3D::Line::direction(&v127);
          v45.m128_i32[0] = LODWORD(v128.x);
          v45.m128_i32[1] = LODWORD(v128.y);
          v54.m128_i32[0] = LODWORD(v128.z);
          v114 = v45;
          v113 = v54;
          v129 = G3D::Line::direction(&l);
          v45.m128_i32[0] = LODWORD(v129.x);
          v45.m128_i32[1] = LODWORD(v129.y);
          v50 = _mm_shuffle_ps(v114, v114, 229);
          v51 = v50;
          v52 = _mm_shuffle_ps(v45, v45, 229).m128_f32[0];
          v53 = v113;
          v51.m128_f32[0] = (float)(v50.m128_f32[0] * v129.z) - (float)(v113.m128_f32[0] * v52);
          v54.m128_f32[0] = v129.z * v114.m128_f32[0];
          v53.m128_f32[0] = (float)(v113.m128_f32[0] * v129.x) - (float)(v129.z * v114.m128_f32[0]);
          v55 = (float)(v52 * v114.m128_f32[0]) - (float)(v50.m128_f32[0] * v129.x);
          _mm_storel_ps((double *)&v106.x, _mm_unpacklo_ps(v51, v53));
          v106.z = v55;
          v56 = (__m128)0x358637BDu;
          if ( G3D::Vector3::unitize(&v106, v54.m128_f32[0]) <= 0.001 )
          {
            result = v100;
            goto LABEL_36;
          }
          *(G3D::Vector3 *)&v112._vptr$Line = v106;
          v112._point.y = 0.0;
          v57 = G3D::CoordinateFrame::toObjectSpace(v108, (const G3D::Plane *)&v112);
          v54.m128_u64[0] = *(_QWORD *)&v57._normal.z;
          v56.m128_u64[0] = *(_QWORD *)&v57._normal.x;
          v114 = v56;
          v113 = v54;
          v58 = G3D::CoordinateFrame::toObjectSpace(v13, (const G3D::Plane *)&v112);
          v54.m128_u64[0] = *(_QWORD *)&v58._normal.z;
          v56.m128_u64[0] = *(_QWORD *)&v58._normal.x;
          v103 = -8388609;
          v104 = 2139095039;
          v59 = *v109;
          v60 = -3.4028235e38;
          v61 = 3.4028235e38;
          v62 = v109[1] - *v109;
          if ( v62 )
          {
            v63 = 0xAAAAAAAAAAAAAAABLL * (v62 >> 4);
            LODWORD(v64) = _mm_shuffle_ps(v113, v113, 229).m128_u32[0];
            v65 = _mm_shuffle_ps(_mm_shuffle_ps(v113, v114, 16), v114, 226);
            v66 = 2139095039;
            v67 = -8388609;
            v68 = 0;
            v60 = -3.4028235e38;
            v61 = 3.4028235e38;
            v69 = 0;
            do
            {
              v70 = 48 * (v68 >> 32);
              v71 = _mm_mul_ps((__m128)*(unsigned __int64 *)(v59 + v70 + 12), v65);
              v72 = (float)(*(float *)(v59 + v70 + 8) * v114.m128_f32[0]) + v71.m128_f32[0];
              v73 = (__m128i)_mm_shuffle_ps(v71, v71, 229);
              *(float *)v73.m128i_i32 = (float)(*(float *)v73.m128i_i32 + v72) - v64;
              *(float *)&v74 = COERCE_FLOAT(_mm_cvtsi128_si32(v73));
              v75 = *(float *)&v74;
              if ( v61 <= *(float *)v73.m128i_i32 )
                v75 = *(float *)&v66;
              v104 = LODWORD(v75);
              if ( *(float *)v73.m128i_i32 <= v60 )
                v74 = v67;
              v103 = v74;
              ++v69;
              v60 = *(float *)&v74;
              v61 = v75;
              v68 += 0x100000000LL;
              v67 = v74;
              v66 = LODWORD(v75);
            }
            while ( v69 < v63 );
          }
          v101 = -8388609;
          v102 = 2139095039;
          v76 = *v111;
          v77 = -3.4028235e38;
          v78 = 3.4028235e38;
          v79 = v111[1] - *v111;
          if ( v79 )
          {
            v80 = 0xAAAAAAAAAAAAAAABLL * (v79 >> 4);
            LODWORD(v81) = _mm_shuffle_ps(v54, v54, 229).m128_u32[0];
            v82 = _mm_shuffle_ps(_mm_shuffle_ps(v54, v56, 16), v56, 226);
            v83 = 2139095039;
            v84 = -8388609;
            v85 = 0;
            v77 = -3.4028235e38;
            v78 = 3.4028235e38;
            v86 = 0;
            do
            {
              v87 = 48 * (v85 >> 32);
              v88 = _mm_mul_ps((__m128)*(unsigned __int64 *)(v76 + v87 + 12), v82);
              v89 = (float)(*(float *)(v76 + v87 + 8) * v58._normal.x) + v88.m128_f32[0];
              v90 = (__m128i)_mm_shuffle_ps(v88, v88, 229);
              *(float *)v90.m128i_i32 = (float)(*(float *)v90.m128i_i32 + v89) - v81;
              *(float *)&v91 = COERCE_FLOAT(_mm_cvtsi128_si32(v90));
              v92 = *(float *)&v91;
              if ( v78 <= *(float *)v90.m128i_i32 )
                v92 = *(float *)&v83;
              v102 = LODWORD(v92);
              if ( *(float *)v90.m128i_i32 <= v77 )
                v91 = v84;
              v101 = v91;
              ++v86;
              v77 = *(float *)&v91;
              v78 = v92;
              v85 += 0x100000000LL;
              v84 = v91;
              v83 = LODWORD(v92);
            }
            while ( v86 < v80 );
          }
          v93 = &v104;
          if ( v78 > v61 )
            v93 = &v102;
          v94 = *(float *)v93;
          v95 = &v103;
          if ( v60 > v77 )
            v95 = &v101;
          result = v94 - *(float *)v95;
          v96 = v100;
          v39 = v107;
          if ( result > v100 )
          {
            v97 = v119;
            v119->bestEdge0 = v120;
            v97->bestEdge1 = (const RBX::POLY::Edge *)(v40 + 8 * v41);
            if ( result > 0.0 )
            {
              v98 = 0;
              v105 = result;
              goto LABEL_35;
            }
            v96 = result;
          }
          v98 = 1;
          result = v96;
LABEL_35:
          v13 = v122;
          if ( !v98 )
            return v105;
LABEL_36:
          if ( ++v38 >= v110 )
            goto LABEL_39;
        }
      }
      result = v99;
LABEL_39:
      v15 = v115;
    }
    v25 = v121 + 1;
    if ( v121 + 1 >= v117 )
      return result;
    v18 = v109[3];
  }
}


// Address: 0x1e04b20 | Name: _ZN3RBX9Collision12EdgeEdgePair13computeMinMaxERKN3G3D5PlaneEPKNS_4POLY4MeshERfSA_
void __fastcall RBX::Collision::EdgeEdgePair::computeMinMax(
        RBX::Collision::EdgeEdgePair *this,
        const RBX::Plane *planeInMesh,
        const RBX::POLY::Mesh *mesh,
        float *min,
        float *max)
{
  __int64 v5; // rax
  __int64 v6; // rdx
  unsigned __int64 v7; // r9
  float v8; // xmm0_4
  unsigned __int64 v9; // rdi
  __int64 i; // rdx
  __int64 v11; // rbx
  __m128 v12; // xmm3
  float v13; // xmm3_4
  float *v14; // rbx
  float *v15; // rbx
  _DWORD v16[3]; // [rsp+0h] [rbp-Ch] BYREF

  *max = -3.4028235e38;
  *min = 3.4028235e38;
  v5 = *(_QWORD *)mesh;
  v6 = *((_QWORD *)mesh + 1) - *(_QWORD *)mesh;
  if ( v6 )
  {
    v7 = 0xAAAAAAAAAAAAAAABLL * (v6 >> 4);
    v8 = 3.4028235e38;
    v9 = 1;
    for ( i = 0; ; i += 0x100000000LL )
    {
      v11 = 48 * (i >> 32);
      v12 = _mm_mul_ps(
              (__m128)*(unsigned __int64 *)(v5 + v11 + 12),
              (__m128)*(unsigned __int64 *)&planeInMesh->_normal.y);
      v13 = (float)(_mm_shuffle_ps(v12, v12, 229).m128_f32[0]
                  + (float)((float)(planeInMesh->_normal.x * *(float *)(v5 + v11 + 8)) + v12.m128_f32[0]))
          - planeInMesh->_distance;
      *(float *)v16 = v13;
      v14 = min;
      if ( v8 > v13 )
        v14 = (float *)v16;
      *min = *v14;
      v15 = max;
      if ( v13 > *max )
        v15 = (float *)v16;
      *max = *v15;
      if ( v9 >= v7 )
        break;
      v8 = *min;
      ++v9;
    }
  }
}


// Address: 0x1e04be0 | Name: _ZN3RBX9Collision12EdgeEdgePair19updatePairInContactERNS_10FixedArrayIPNS0_29FeaturePolyCollisionConnectorELm8EEEf
char __fastcall RBX::Collision::EdgeEdgePair::updatePairInContact(
        RBX::Collision::EdgeEdgePair *this,
        RBX::Collision::PolyCollisionConnectorArray *collisionConnectors,
        __m128 a3,
        float overlapIgnored)
{
  RBX::Primitive *v5; // rdx
  RBX::Primitive *v7; // rsi
  RBX::Collision::FeaturePolyCollisionConnector *CollisionConnector; // r14
  const RBX::POLY::Edge *bestEdge0; // rax
  const RBX::POLY::Vertex *v10; // rdx
  const RBX::POLY::Vertex *v11; // rcx
  float v12; // xmm1_4
  __m128 v13; // xmm3
  float v14; // xmm2_4
  float v15; // xmm4_4
  __m128 v16; // xmm0
  __m128 v17; // xmm2
  float v18; // xmm1_4
  __m128 v19; // xmm2
  float v20; // xmm4_4
  __m128 v21; // xmm4
  const RBX::POLY::Edge *bestEdge1; // rdx
  const RBX::POLY::Vertex *v23; // rsi
  const RBX::POLY::Vertex *v24; // rdi
  float v25; // xmm1_4
  __m128 v26; // xmm3
  __m128 v27; // xmm2
  float v28; // xmm1_4
  __m128 v29; // xmm2
  float v30; // xmm1_4
  __m128 v31; // xmm0
  char result; // al
  RBX::Line edgeLine0; // [rsp+0h] [rbp-68h] BYREF
  G3D::Line edgeId0; // [rsp+20h] [rbp-48h] BYREF
  __m128 v35; // [rsp+40h] [rbp-28h]

  if ( this->bestEdge0 && this->bestEdge1 )
  {
    v5 = this->primitive[1];
    v7 = this->primitive[0];
    v35 = a3;
    CollisionConnector = RBX::Collision::FeaturePolyContact::createCollisionConnector(
                           collisionConnectors,
                           v7,
                           v5,
                           RBX::Collision::FeaturePolyPair::EDGE_EDGE_POLY_PAIR);
    bestEdge0 = this->bestEdge0;
    v10 = bestEdge0->vertex[0];
    v11 = bestEdge0->vertex[1];
    v12 = *((float *)v11 + 4) - *((float *)v10 + 4);
    v13 = _mm_sub_ps((__m128)*((unsigned __int64 *)v11 + 1), (__m128)*((unsigned __int64 *)v10 + 1));
    v14 = _mm_shuffle_ps(v13, v13, 229).m128_f32[0];
    v15 = fsqrt((float)(v12 * v12) + (float)((float)(v14 * v14) + (float)(v13.m128_f32[0] * v13.m128_f32[0])));
    v16 = (__m128)0x3F800000u;
    v17 = (__m128)0x3F800000u;
    v17.m128_f32[0] = 1.0 / v15;
    v18 = v12 * (float)(1.0 / v15);
    v19 = _mm_mul_ps(_mm_shuffle_ps(v17, v17, 224), v13);
    edgeId0._vptr$Line = (int (**)(void))&edgeLine1;
    edgeId0._point = *(G3D::Vector3 *)((char *)v10 + 8);
    v20 = _mm_shuffle_ps(v19, v19, 229).m128_f32[0];
    v13.m128_f32[0] = fsqrt((float)(v18 * v18) + (float)((float)(v20 * v20) + (float)(v19.m128_f32[0] * v19.m128_f32[0])));
    v21 = (__m128)0x3F800000u;
    v21.m128_f32[0] = 1.0 / v13.m128_f32[0];
    _mm_storel_ps((double *)&edgeId0._direction.x, _mm_mul_ps(_mm_shuffle_ps(v21, v21, 224), v19));
    edgeId0._direction.z = v18 * (float)(1.0 / v13.m128_f32[0]);
    bestEdge1 = this->bestEdge1;
    v23 = bestEdge1->vertex[0];
    v24 = bestEdge1->vertex[1];
    v25 = *((float *)v24 + 4) - *((float *)v23 + 4);
    v26 = _mm_sub_ps((__m128)*((unsigned __int64 *)v24 + 1), (__m128)*((unsigned __int64 *)v23 + 1));
    v21.m128_f32[0] = _mm_shuffle_ps(v26, v26, 229).m128_f32[0];
    v27 = (__m128)0x3F800000u;
    v27.m128_f32[0] = 1.0
                    / fsqrt(
                        (float)(v25 * v25)
                      + (float)((float)(v21.m128_f32[0] * v21.m128_f32[0]) + (float)(v26.m128_f32[0] * v26.m128_f32[0])));
    v28 = v25 * v27.m128_f32[0];
    v29 = _mm_mul_ps(_mm_shuffle_ps(v27, v27, 224), v26);
    edgeLine0._vptr$Line = (int (**)(void))&edgeLine1;
    edgeLine0._point = *(G3D::Vector3 *)((char *)v23 + 8);
    v21.m128_f32[0] = _mm_shuffle_ps(v29, v29, 229).m128_f32[0];
    v16.m128_f32[0] = 1.0
                    / fsqrt(
                        (float)(v28 * v28)
                      + (float)((float)(v21.m128_f32[0] * v21.m128_f32[0]) + (float)(v29.m128_f32[0] * v29.m128_f32[0])));
    v30 = v28 * v16.m128_f32[0];
    v31 = _mm_mul_ps(_mm_shuffle_ps(v16, v16, 224), v29);
    _mm_storel_ps((double *)&edgeLine0._direction.x, v31);
    edgeLine0._direction.z = v30;
    RBX::Collision::EdgeEdgePair::updateEdgeEdgeCollision(
      (RBX::Collision::EdgeEdgePair *)v24,
      CollisionConnector,
      &edgeId0,
      &edgeLine0,
      bestEdge0->id,
      bestEdge1->id,
      v31);
    result = 1;
    if ( CollisionConnector->depth < (float)-v35.m128_f32[0] )
      return result;
    *(_QWORD *)&CollisionConnector->normal.x = 0;
    CollisionConnector->normal.z = 0.0;
  }
  return 0;
}


// Address: 0x1e04fb0 | Name: _GLOBAL__sub_I_PolyPolyContact.cpp
void __cdecl GLOBAL__sub_I_PolyPolyContact_cpp()
{
  qword_2AAF728 = (__int64)boost::system::generic_category();
  qword_2AAF730 = (__int64)boost::system::generic_category();
  qword_2AAF738 = (__int64)boost::system::system_category();
}


