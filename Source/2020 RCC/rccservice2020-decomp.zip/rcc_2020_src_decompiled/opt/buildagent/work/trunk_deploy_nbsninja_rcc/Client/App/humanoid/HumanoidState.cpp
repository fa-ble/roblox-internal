// Address: 0x10dbe90 | Name: _ZN3RBX5HUMAN8getStateENS0_9StateTypeENS0_9EventTypeE
RBX::HUMAN::StateType __fastcall RBX::HUMAN::getState(RBX::HUMAN::StateType oldState, RBX::HUMAN::EventType eventType)
{
  return dword_4ADD70[27 * oldState + 28 + eventType];
}


// Address: 0x10dbeb0 | Name: _ZN3RBX5HUMAN13HumanoidStateC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::HumanoidState::HumanoidState(
        RBX::HUMAN::HumanoidState *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  _DWORD *v5; // rax
  _DWORD *v6; // rax
  RBX::PartInstance *VisibleTorsoSlow; // rax
  RBX::OnDemandInstance *v8; // rax
  rbx::signals::slot_base **v9; // rax
  rbx::signals::slot_base *p; // rcx
  rbx::signals::slot_base *v11; // rdi
  RBX::PartInstance *LeftLegSlow; // rax
  RBX::OnDemandInstance *v13; // rax
  rbx::signals::slot_base **v14; // rax
  rbx::signals::slot_base *v15; // rcx
  rbx::signals::slot_base *v16; // rdi
  RBX::PartInstance *RightLegSlow; // rax
  RBX::OnDemandInstance *v18; // rax
  rbx::signals::slot_base **v19; // rax
  rbx::signals::slot_base *v20; // rcx
  rbx::signals::slot_base *v21; // rdi
  rbx::signals::connection __x; // [rsp+8h] [rbp-50h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::HUMAN::HumanoidState,bool>,boost::_bi::list2<boost::_bi::value<RBX::HUMAN::HumanoidState *>,boost::arg<1> > > function; // [rsp+10h] [rbp-48h] BYREF

  *(_QWORD *)this = &off_2895400;
  *((_DWORD *)this + 2) = 0;
  *((_WORD *)this + 6) = 1;
  *((_OWORD *)this + 1) = 0;
  *((_DWORD *)this + 8) = 0;
  v5 = operator new(4u);
  *v5 = (_DWORD)v5;
  *((_QWORD *)this + 5) = v5;
  v6 = operator new(4u);
  *v6 = (_DWORD)v6 + 18;
  *((_QWORD *)this + 6) = v6;
  *((_DWORD *)this + 14) = priorState;
  *((_DWORD *)this + 15) = 0;
  *((_QWORD *)this + 8) = humanoid;
  boost::mutex::mutex((boost::mutex *)((char *)this + 72));
  *((_OWORD *)this + 7) = 0;
  *((_DWORD *)this + 32) = 1792;
  *((_DWORD *)this + 35) = dword_2859528;
  *(_QWORD *)((char *)this + 132) = unk_2859520;
  *((_QWORD *)this + 18) = 0x3F80000000000000LL;
  *((_DWORD *)this + 38) = 0;
  *((_DWORD *)this + 41) = dword_2859528;
  *(_QWORD *)((char *)this + 156) = unk_2859520;
  *(_OWORD *)((char *)this + 184) = 0;
  *(_OWORD *)((char *)this + 168) = 0;
  *((_DWORD *)this + 52) = dword_2859534;
  *((_QWORD *)this + 25) = qword_285952C;
  *((_WORD *)this + 140) = 0;
  *((_BYTE *)this + 282) = 0;
  *((_OWORD *)this + 18) = 0;
  *((_QWORD *)this + 38) = 0;
  *((_OWORD *)this + 16) = 0;
  *(_OWORD *)((char *)this + 244) = 0;
  *(_OWORD *)((char *)this + 228) = 0;
  *(_OWORD *)((char *)this + 212) = 0;
  RBX::Humanoid::setJump(humanoid, 0);
  RBX::Humanoid::setStrafe(humanoid, 0);
  RBX::HUMAN::HumanoidState::setCanThrottleState(this, 0);
  VisibleTorsoSlow = RBX::Humanoid::getVisibleTorsoSlow(*((RBX::Humanoid **)this + 8));
  if ( VisibleTorsoSlow )
  {
    v8 = RBX::Instance::onDemandWrite(VisibleTorsoSlow);
    function.f_ = (boost::_mfi::mf1<void,RBX::HUMAN::HumanoidState,bool>)(unsigned __int64)RBX::HUMAN::HumanoidState::setTorsoHasBuoyancy;
    function.l_.a1_.t_ = this;
    rbx::signal<void ()(bool)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::HUMAN::HumanoidState,bool>,boost::_bi::list2<boost::_bi::value<RBX::HUMAN::HumanoidState*>,boost::arg<1>>>>(
      (rbx::signal<void (bool)> *)v8 + 40,
      &function);
    v9 = (rbx::signals::slot_base **)*((_QWORD *)this + 37);
    if ( (unsigned __int64)v9 >= *((_QWORD *)this + 38) )
    {
      std::vector<rbx::signals::connection>::__push_back_slow_path<rbx::signals::connection>(
        (RBX::HUMAN::HumanoidState *)((char *)this + 288),
        &__x);
    }
    else
    {
      *v9 = 0;
      p = __x.weak_slot.p_;
      if ( __x.weak_slot.p_ && __x.weak_slot.p_->strong.v )
      {
        *v9 = __x.weak_slot.p_;
        _InterlockedAdd(&p->weak.v, 1u);
        v9 = (rbx::signals::slot_base **)*((_QWORD *)this + 37);
      }
      *((_QWORD *)this + 37) = v9 + 1;
    }
    v11 = __x.weak_slot.p_;
    if ( __x.weak_slot.p_ && !_InterlockedSub(&__x.weak_slot.p_->weak.v, 1u) )
      operator delete(v11);
  }
  LeftLegSlow = RBX::Humanoid::getLeftLegSlow(humanoid);
  if ( LeftLegSlow )
  {
    v13 = RBX::Instance::onDemandWrite(LeftLegSlow);
    function.f_ = (boost::_mfi::mf1<void,RBX::HUMAN::HumanoidState,bool>)(unsigned __int64)RBX::HUMAN::HumanoidState::setLeftLegHasBuoyancy;
    function.l_.a1_.t_ = this;
    rbx::signal<void ()(bool)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::HUMAN::HumanoidState,bool>,boost::_bi::list2<boost::_bi::value<RBX::HUMAN::HumanoidState*>,boost::arg<1>>>>(
      (rbx::signal<void (bool)> *)v13 + 40,
      &function);
    v14 = (rbx::signals::slot_base **)*((_QWORD *)this + 37);
    if ( (unsigned __int64)v14 >= *((_QWORD *)this + 38) )
    {
      std::vector<rbx::signals::connection>::__push_back_slow_path<rbx::signals::connection>(
        (RBX::HUMAN::HumanoidState *)((char *)this + 288),
        &__x);
    }
    else
    {
      *v14 = 0;
      v15 = __x.weak_slot.p_;
      if ( __x.weak_slot.p_ && __x.weak_slot.p_->strong.v )
      {
        *v14 = __x.weak_slot.p_;
        _InterlockedAdd(&v15->weak.v, 1u);
        v14 = (rbx::signals::slot_base **)*((_QWORD *)this + 37);
      }
      *((_QWORD *)this + 37) = v14 + 1;
    }
    v16 = __x.weak_slot.p_;
    if ( __x.weak_slot.p_ && !_InterlockedSub(&__x.weak_slot.p_->weak.v, 1u) )
      operator delete(v16);
  }
  RightLegSlow = RBX::Humanoid::getRightLegSlow(humanoid);
  if ( RightLegSlow )
  {
    v18 = RBX::Instance::onDemandWrite(RightLegSlow);
    function.f_ = (boost::_mfi::mf1<void,RBX::HUMAN::HumanoidState,bool>)(unsigned __int64)RBX::HUMAN::HumanoidState::setRightLegHasBuoyancy;
    function.l_.a1_.t_ = this;
    rbx::signal<void ()(bool)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf1<void,RBX::HUMAN::HumanoidState,bool>,boost::_bi::list2<boost::_bi::value<RBX::HUMAN::HumanoidState*>,boost::arg<1>>>>(
      (rbx::signal<void (bool)> *)v18 + 40,
      &function);
    v19 = (rbx::signals::slot_base **)*((_QWORD *)this + 37);
    if ( (unsigned __int64)v19 >= *((_QWORD *)this + 38) )
    {
      std::vector<rbx::signals::connection>::__push_back_slow_path<rbx::signals::connection>(
        (RBX::HUMAN::HumanoidState *)((char *)this + 288),
        &__x);
    }
    else
    {
      *v19 = 0;
      v20 = __x.weak_slot.p_;
      if ( __x.weak_slot.p_ && __x.weak_slot.p_->strong.v )
      {
        *v19 = __x.weak_slot.p_;
        _InterlockedAdd(&v20->weak.v, 1u);
        v19 = (rbx::signals::slot_base **)*((_QWORD *)this + 37);
      }
      *((_QWORD *)this + 37) = v19 + 1;
    }
    v21 = __x.weak_slot.p_;
    if ( __x.weak_slot.p_ )
    {
      if ( !_InterlockedSub(&__x.weak_slot.p_->weak.v, 1u) )
        operator delete(v21);
    }
  }
}


// Address: 0x10dc3a0 | Name: _ZN3RBX5HUMAN13HumanoidState19setCanThrottleStateEb
void __fastcall RBX::HUMAN::HumanoidState::setCanThrottleState(RBX::HUMAN::HumanoidState *this, bool canThrottle)
{
  RBX::Humanoid *v3; // rdi
  RBX::PartInstance *HeadSlow; // rax
  RBX::PartInstance *TorsoSlow; // rax
  RBX::PartInstance *RightArmSlow; // rax
  RBX::PartInstance *LeftArmSlow; // rax
  RBX::PartInstance *RightLegSlow; // rax
  RBX::PartInstance *LeftLegSlow; // rax

  v3 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( v3 )
  {
    if ( RBX::Humanoid::getHeadSlow(v3) )
    {
      HeadSlow = RBX::Humanoid::getHeadSlow(*((RBX::Humanoid **)this + 8));
      RBX::Primitive::setCanThrottle(HeadSlow->primitive.px, canThrottle);
    }
    if ( RBX::Humanoid::getTorsoSlow(*((RBX::Humanoid **)this + 8)) )
    {
      TorsoSlow = RBX::Humanoid::getTorsoSlow(*((RBX::Humanoid **)this + 8));
      RBX::Primitive::setCanThrottle(TorsoSlow->primitive.px, canThrottle);
    }
    if ( RBX::Humanoid::getRightArmSlow(*((RBX::Humanoid **)this + 8)) )
    {
      RightArmSlow = RBX::Humanoid::getRightArmSlow(*((RBX::Humanoid **)this + 8));
      RBX::Primitive::setCanThrottle(RightArmSlow->primitive.px, canThrottle);
    }
    if ( RBX::Humanoid::getLeftArmSlow(*((RBX::Humanoid **)this + 8)) )
    {
      LeftArmSlow = RBX::Humanoid::getLeftArmSlow(*((RBX::Humanoid **)this + 8));
      RBX::Primitive::setCanThrottle(LeftArmSlow->primitive.px, canThrottle);
    }
    if ( RBX::Humanoid::getRightLegSlow(*((RBX::Humanoid **)this + 8)) )
    {
      RightLegSlow = RBX::Humanoid::getRightLegSlow(*((RBX::Humanoid **)this + 8));
      RBX::Primitive::setCanThrottle(RightLegSlow->primitive.px, canThrottle);
    }
    if ( RBX::Humanoid::getLeftLegSlow(*((RBX::Humanoid **)this + 8)) )
    {
      LeftLegSlow = RBX::Humanoid::getLeftLegSlow(*((RBX::Humanoid **)this + 8));
      RBX::Primitive::setCanThrottle(LeftLegSlow->primitive.px, canThrottle);
    }
  }
}


// Address: 0x10dc4b0 | Name: _ZN3RBX5HUMAN13HumanoidStateD2Ev
void __fastcall RBX::HUMAN::HumanoidState::~HumanoidState(RBX::HUMAN::HumanoidState *this)
{
  const rbx::signals::connection *v2; // rbx
  const rbx::signals::connection *v3; // r15
  volatile signed __int32 *v4; // rdi
  volatile signed __int32 *v5; // rdi
  rbx::signals::connection *v6; // rdi
  volatile signed __int32 *v7; // rbx
  volatile signed __int32 *v8; // rbx
  void *v9; // rdi
  void *v10; // rdi

  *(_QWORD *)this = &off_2895400;
  RBX::HUMAN::HumanoidState::setCanThrottleState(this, 0);
  v2 = (const rbx::signals::connection *)*((_QWORD *)this + 36);
  if ( v2 == *((const rbx::signals::connection **)this + 37) )
  {
    v3 = (const rbx::signals::connection *)*((_QWORD *)this + 36);
  }
  else
  {
    do
      rbx::signals::connection::disconnect(v2++);
    while ( v2 != *((const rbx::signals::connection **)this + 37) );
    v3 = (const rbx::signals::connection *)*((_QWORD *)this + 36);
    if ( v3 == v2 )
    {
      v2 = (const rbx::signals::connection *)*((_QWORD *)this + 36);
    }
    else
    {
      do
      {
        v4 = (volatile signed __int32 *)&v2[-1].weak_slot.p_->rbx::intrusive_ptr_target<rbx::signals::slot_base>;
        --v2;
        if ( v4 && !_InterlockedSub(v4 + 1, 1u) )
          operator delete((void *)v4);
      }
      while ( v3 != v2 );
      v2 = (const rbx::signals::connection *)*((_QWORD *)this + 36);
    }
  }
  *((_QWORD *)this + 37) = v3;
  if ( v2 )
  {
    if ( v3 == v2 )
    {
      v6 = (rbx::signals::connection *)v2;
    }
    else
    {
      do
      {
        v5 = (volatile signed __int32 *)&v3[-1].weak_slot.p_->rbx::intrusive_ptr_target<rbx::signals::slot_base>;
        --v3;
        if ( v5 && !_InterlockedSub(v5 + 1, 1u) )
          operator delete((void *)v5);
      }
      while ( v2 != v3 );
      v6 = (rbx::signals::connection *)*((_QWORD *)this + 36);
    }
    *((_QWORD *)this + 37) = v2;
    operator delete(v6);
  }
  v7 = (volatile signed __int32 *)*((_QWORD *)this + 24);
  if ( v7 )
  {
    if ( !_InterlockedSub(v7 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  RBX::Memory::deallocate(*((void **)this + 21));
  *(_OWORD *)((char *)this + 168) = 0;
  v8 = (volatile signed __int32 *)*((_QWORD *)this + 15);
  if ( v8 )
  {
    if ( !_InterlockedSub(v8 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
      if ( !_InterlockedSub(v8 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 24LL))(v8);
    }
  }
  while ( pthread_mutex_destroy((pthread_mutex_t *)((char *)this + 72)) == 4 )
    ;
  v9 = (void *)*((_QWORD *)this + 6);
  if ( v9 )
    operator delete(v9);
  v10 = (void *)*((_QWORD *)this + 5);
  if ( v10 )
    operator delete(v10);
}


// Address: 0x10dc6b0 | Name: _ZN3RBX5HUMAN13HumanoidStateD0Ev
void __fastcall __noreturn RBX::HUMAN::HumanoidState::~HumanoidState(RBX::HUMAN::HumanoidState *this)
{
  BUG();
}


// Address: 0x10dc6c0 | Name: _ZN3RBX5HUMAN13HumanoidState13runningKMovePEv
float __cdecl RBX::HUMAN::HumanoidState::runningKMoveP()
{
  return 1250.0;
}


// Address: 0x10dc6d0 | Name: _ZN3RBX5HUMAN13HumanoidState19runningKMovePForPGSEv
float __cdecl RBX::HUMAN::HumanoidState::runningKMovePForPGS()
{
  return 150.0;
}


// Address: 0x10dc6e0 | Name: _ZNK3RBX5HUMAN13HumanoidState15steepSlopeAngleEv
float __fastcall RBX::HUMAN::HumanoidState::steepSlopeAngle(const RBX::HUMAN::HumanoidState *this)
{
  __int64 v1; // rax

  v1 = *((_QWORD *)this + 8);
  if ( v1 )
    return cosf((float)(COERCE_FLOAT(*(_QWORD *)(v1 + 680) - **(_DWORD **)(v1 + 680)) * 3.1415927) / 180.0);
  else
    return 0.5;
}


// Address: 0x10dc720 | Name: _ZN3RBX5HUMAN13HumanoidState10fireEventsEv
void __fastcall RBX::HUMAN::HumanoidState::fireEvents(RBX::HUMAN::HumanoidState *this)
{
  int v1; // ebp
  RBX::HUMAN::StateType v2; // eax
  rbx::signal<void (RBX::HUMAN::StateType,RBX::HUMAN::StateType)> *v3; // r14
  RBX::HUMAN::StateType v4; // ebp
  RBX::HUMAN::StateType v5; // eax

  v1 = *((_DWORD *)this + 14);
  if ( v1 != (*(unsigned int (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) )
  {
    RBX::HUMAN::HumanoidState::fireEvent(this, *((RBX::HUMAN::StateType *)this + 14), 0);
    v2 = (*(unsigned int (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this);
    RBX::HUMAN::HumanoidState::fireEvent(this, v2, 1);
    v3 = (rbx::signal<void (RBX::HUMAN::StateType,RBX::HUMAN::StateType)> *)(*((_QWORD *)this + 8) + 2712LL);
    v4 = *((_DWORD *)this + 14);
    v5 = (*(unsigned int (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this);
    rbx::signal<void ()(RBX::HUMAN::StateType,RBX::HUMAN::StateType)>::operator()(v3, v4, v5);
  }
  *((_DWORD *)this + 14) = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this);
}


// Address: 0x10dc7a0 | Name: _ZN3RBX5HUMAN13HumanoidState9fireEventENS0_9StateTypeEb
void __fastcall RBX::HUMAN::HumanoidState::fireEvent(
        RBX::HUMAN::HumanoidState *this,
        RBX::HUMAN::StateType stateType,
        bool entering)
{
  __m128 v3; // xmm2
  __int64 v6; // rdi
  rbx::signal<void (float)> *v7; // rdi
  RBX::Primitive *v8; // rax
  RBX::Primitive *v9; // rbp
  __m128 v10; // xmm1
  __m128 v11; // xmm0
  __int64 v12; // rbx
  boost::shared_ptr<RBX::Instance> v13; // rdx
  boost::detail::sp_counted_base *pi; // rbx
  volatile signed __int32 *v15; // rbx
  RBX::Humanoid *v16; // r14
  RBX::Primitive *v17; // rax
  RBX::Primitive *v18; // rbp
  RBX::Humanoid *v19; // r14
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Primitive *v21; // rbp
  __m128 v22; // xmm0
  double v23; // xmm1_8
  rbx::signal<void (float)> *v24; // r14
  __m128 v25; // xmm1
  __m128 v26; // rt1
  float v27; // xmm0_4
  float v28; // xmm3_4
  __int64 v29; // xmm1_8
  bool v30; // al
  double v31; // xmm1_8
  float v32; // xmm1_4
  __m128 v33; // rt1
  float v34; // xmm3_4
  float v35; // xmm2_4
  float v36; // xmm3_4
  float v37; // [rsp+0h] [rbp-68h]
  __m128 v38; // [rsp+0h] [rbp-68h]
  __m128 v39; // [rsp+0h] [rbp-68h]
  float v40; // [rsp+0h] [rbp-68h]
  float v41; // [rsp+0h] [rbp-68h]
  RBX::Velocity v42; // [rsp+10h] [rbp-58h] BYREF
  __m128 v43; // [rsp+30h] [rbp-38h]
  boost::shared_ptr<RBX::Instance> args; // [rsp+40h] [rbp-28h] BYREF

  switch ( stateType )
  {
    case RBX::HUMAN::StateType::FALLING_DWN:
      v6 = 2680;
      goto LABEL_24;
    case RBX::HUMAN::StateType::RAGDOLL:
    case RBX::HUMAN::StateType::PHYSICS:
      v6 = 2688;
      goto LABEL_24;
    case RBX::HUMAN::StateType::GETTING_UP:
      v6 = 2672;
      goto LABEL_24;
    case RBX::HUMAN::StateType::JUMPING:
      v6 = 2648;
      goto LABEL_24;
    case RBX::HUMAN::StateType::SWIMMING:
      v19 = (RBX::Humanoid *)*((_QWORD *)this + 8);
      TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(v19);
      if ( TorsoPrimitiveSlow )
      {
        v21 = TorsoPrimitiveSlow;
        RBX::Body::updatePV((RBX::Body *)((char *)TorsoPrimitiveSlow + 152));
        v43 = (__m128)*((unsigned __int64 *)v21 + 51);
        v40 = *((float *)v21 + 104);
        RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v42, this);
        v43 = _mm_sub_ps(v43, (__m128)*(unsigned __int64 *)&v42.linear.x);
        v41 = v40 - v42.linear.z;
      }
      else
      {
        v41 = 0.0;
        v43 = 0;
      }
      if ( RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8)) )
      {
        v24 = (rbx::signal<void (float)> *)((char *)v19 + 2624);
        if ( v24->head.px )
        {
          v32 = _mm_shuffle_ps(v43, v43, 229).m128_f32[0];
          v3.m128_f32[0] = fsqrt(
                             (float)(v41 * v41)
                           + (float)((float)(v32 * v32) + (float)(v43.m128_f32[0] * v43.m128_f32[0])));
          v31 = NAN;
          v33.m128_i32[0] = 1056964608;
          v27 = _mm_andnot_ps(_mm_cmplt_ss(_mm_and_ps(v3, (__m128)xmmword_3E5B40), v33), v3).m128_f32[0];
          v34 = *((float *)this + 15);
          if ( v34 < 0.0 && v27 > 0.0 )
            goto LABEL_44;
          v35 = fabs(v27);
          v36 = fabs(v34);
          HIDWORD(v31) = 0;
          *(float *)&v31 = 0.94999999 * v36;
          if ( (float)(0.94999999 * v36) > v35 || v35 > (float)(v36 * 1.05) )
            goto LABEL_44;
        }
      }
      return;
    case RBX::HUMAN::StateType::FREE_FALL:
    case RBX::HUMAN::StateType::FLYING:
    case RBX::HUMAN::StateType::LANDED:
      v6 = 2656;
      goto LABEL_24;
    case RBX::HUMAN::StateType::RUNNING:
    case RBX::HUMAN::StateType::RUNNING_NO_PHYS:
      v7 = (rbx::signal<void (float)> *)*((_QWORD *)this + 8);
      v8 = RBX::Humanoid::getTorsoPrimitiveSlow((RBX::Humanoid *)v7);
      if ( v8 )
      {
        v9 = v8;
        RBX::Body::updatePV((RBX::Body *)((char *)v8 + 152));
        v43 = (__m128)*((unsigned __int64 *)v9 + 51);
        v37 = *((float *)v9 + 104);
        RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v42, this);
        v10 = _mm_sub_ps(v43, (__m128)*(unsigned __int64 *)&v42.linear.x);
        v11 = (__m128)LODWORD(v37);
        v11.m128_f32[0] = v37 - v42.linear.z;
      }
      else
      {
        v11 = 0;
        v10 = 0;
      }
      _mm_storel_ps((double *)&v42.linear.x, v10);
      LODWORD(v42.linear.z) = v11.m128_i32[0];
      *(G3D::Vector2 *)v11.m128_f32 = G3D::Vector3::xz(&v42.linear);
      v22 = _mm_mul_ps(v11, v11);
      *(_QWORD *)&v23 = _mm_shuffle_ps(v22, v22, 229).m128_u64[0];
      *(float *)&v23 = *(float *)&v23 + v22.m128_f32[0];
      rbx::signal<void ()(float)>::operator()(v7 + 329, fsqrt(*(float *)&v23), v23);
      return;
    case RBX::HUMAN::StateType::STRAFING_NO_PHYS:
      v6 = 2664;
      goto LABEL_24;
    case RBX::HUMAN::StateType::CLIMBING:
      v16 = (RBX::Humanoid *)*((_QWORD *)this + 8);
      v17 = RBX::Humanoid::getTorsoPrimitiveSlow(v16);
      if ( v17 )
      {
        v18 = v17;
        RBX::Body::updatePV((RBX::Body *)((char *)v17 + 152));
        v38 = (__m128)*((unsigned __int64 *)v18 + 51);
        RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v42, this);
        v39 = _mm_sub_ps(v38, (__m128)*(unsigned __int64 *)&v42.linear.x);
      }
      else
      {
        v39 = 0;
      }
      if ( RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8)) )
      {
        v24 = (rbx::signal<void (float)> *)((char *)v16 + 2640);
        if ( v24->head.px )
        {
          v25 = _mm_shuffle_ps(v39, v39, 229);
          v26.m128_i32[0] = 1056964608;
          v27 = _mm_andnot_ps(_mm_cmplt_ss(_mm_and_ps(v25, (__m128)xmmword_3E5B40), v26), v25).m128_f32[0];
          v28 = fabs(v27);
          v29 = *((unsigned int *)this + 15);
          if ( v27 <= 0.0 || (v30 = 1, *(float *)&v29 >= 0.0) )
            v30 = *(float *)&v29 > 0.0 && v27 < 0.0;
          *(_QWORD *)&v31 = v29 & 0x7FFFFFFF7FFFFFFFLL;
          if ( (float)(0.94999999 * *(float *)&v31) > v28
            || (*(float *)&v31 = *(float *)&v31 * 1.05, v28 > *(float *)&v31)
            || v30 )
          {
LABEL_44:
            rbx::signal<void ()(float)>::operator()(v24, v27, v31);
            *((float *)this + 15) = v27;
          }
        }
      }
      break;
    case RBX::HUMAN::StateType::SEATED:
      v12 = *((_QWORD *)this + 8);
      RBX::shared_from<RBX::PartInstance>(
        (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)&v42,
        *(RBX::PartInstance **)(v12 + 496));
      args = *(boost::shared_ptr<RBX::Instance> *)&v42.linear.x;
      *(_OWORD *)&v42.linear.x = 0;
      v13.px = (boost::shared_ptr<RBX::Instance>::element_type *)&args;
      rbx::signal<void ()(bool,boost::shared_ptr<RBX::Instance>)>::operator()(
        (rbx::signal<void (bool,boost::shared_ptr<RBX::Instance>)> *)(v12 + 2696),
        entering,
        v13);
      pi = args.pn.pi_;
      if ( args.pn.pi_ )
      {
        if ( !_InterlockedSub(&args.pn.pi_->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
      }
      v15 = *(volatile signed __int32 **)&v42.linear.z;
      if ( *(_QWORD *)&v42.linear.z )
      {
        if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&v42.linear.z + 8LL), 1u) )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 16LL))(v15);
          if ( !_InterlockedSub(v15 + 3, 1u) )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v15 + 24LL))(v15);
        }
      }
      break;
    case RBX::HUMAN::StateType::PLATFORM_STANDING:
      v6 = 2704;
LABEL_24:
      rbx::signal<void ()(bool)>::operator()((rbx::signal<void (bool)> *)(*((_QWORD *)this + 8) + v6), entering);
      break;
    case RBX::HUMAN::StateType::DEAD:
      rbx::signal<void ()(void)>::operator()((rbx::signal<void ()> *)(*((_QWORD *)this + 8) + 2616LL));
      break;
    default:
      return;
  }
}


// Address: 0x10dcc50 | Name: _ZNK3RBX5HUMAN13HumanoidState16getAssemblyConstEv
const RBX::Assembly *__fastcall RBX::HUMAN::HumanoidState::getAssemblyConst(const RBX::HUMAN::HumanoidState *this)
{
  RBX::Humanoid *v1; // rdi
  RBX::Primitive *TorsoPrimitiveSlow; // rax

  v1 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( v1 && (TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(v1)) != 0 )
    return RBX::Assembly::getConstPrimitiveAssembly(TorsoPrimitiveSlow);
  else
    return 0;
}


// Address: 0x10dcc80 | Name: _ZN3RBX5HUMAN13HumanoidState11getAssemblyEv
RBX::Assembly *__fastcall RBX::HUMAN::HumanoidState::getAssembly(RBX::HUMAN::HumanoidState *this)
{
  RBX::Humanoid *v1; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax

  v1 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( v1 && (TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v1)) != 0 )
    return RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
  else
    return 0;
}


// Address: 0x10dccb0 | Name: _ZN3RBX5HUMAN13HumanoidState15stateToAssemblyEv
void __fastcall RBX::HUMAN::HumanoidState::stateToAssembly(RBX::HUMAN::HumanoidState *this)
{
  RBX::Humanoid *v2; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax

  v2 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( v2 )
  {
    TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v2);
    if ( TorsoPrimitiveFast )
    {
      PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
      if ( PrimitiveAssembly )
        PrimitiveAssembly->networkHumanoidState = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this);
    }
  }
}


// Address: 0x10dcd00 | Name: _ZN3RBX5HUMAN13HumanoidState17stateFromAssemblyEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::HumanoidState::stateFromAssembly(RBX::HUMAN::HumanoidState *this)
{
  RBX::Humanoid *v1; // rdi
  RBX::HUMAN::StateType v2; // ebx
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax

  v1 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  v2 = RBX::HUMAN::StateType::DEAD;
  if ( v1 )
  {
    TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v1);
    if ( TorsoPrimitiveFast )
    {
      PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
      if ( PrimitiveAssembly )
        return PrimitiveAssembly->networkHumanoidState;
    }
  }
  return v2;
}


// Address: 0x10dcd30 | Name: _ZNK3RBX5HUMAN13HumanoidState16getHumanoidConstEv
const RBX::Humanoid *__fastcall RBX::HUMAN::HumanoidState::getHumanoidConst(const RBX::HUMAN::HumanoidState *this)
{
  return (const RBX::Humanoid *)*((_QWORD *)this + 8);
}


// Address: 0x10dcd40 | Name: _ZNK3RBX5HUMAN13HumanoidState9usesEventENS0_9EventTypeE
bool __fastcall RBX::HUMAN::HumanoidState::usesEvent(const RBX::HUMAN::HumanoidState *this, RBX::HUMAN::EventType e)
{
  return dword_4ADD70[27
                    * (int)((*(__int64 (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this)
                          + 1)
                    + 1
                    + e] != 18;
}


// Address: 0x10dcd70 | Name: _ZN3RBX5HUMAN13HumanoidState14onComputeForceEv
void __fastcall RBX::HUMAN::HumanoidState::onComputeForce(RBX::HUMAN::HumanoidState *this)
{
  RBX::Humanoid *v1; // rbx
  RBX::Body *TorsoBodyFast; // r15
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v4; // rbx
  RBX::Solver::SolverRigidBody *rigidBody; // rax
  float z; // xmm0_4
  __m128 v7; // xmm1
  __m128 v8; // xmm3
  __m128 z_low; // xmm2
  __m128 v10; // xmm4
  __m128 v11; // xmm7
  float v12; // xmm2_4
  RBX::Solver::SolverRigidBody *v13; // rax

  v1 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(v1);
  RootBodyFast = RBX::Humanoid::getRootBodyFast(v1);
  if ( TorsoBodyFast )
  {
    v4 = RootBodyFast;
    if ( RootBodyFast )
    {
      RBX::Body::updatePV(RootBodyFast);
      rigidBody = v4->root->rigidBody;
      z = 0.0;
      v7 = 0;
      v8 = 0;
      z_low = 0;
      if ( rigidBody )
      {
        v8 = (__m128)*(unsigned __int64 *)&rigidBody->torque.x;
        z_low = (__m128)LODWORD(rigidBody->torque.z);
      }
      v10 = _mm_shuffle_ps(v8, v8, 229);
      v11 = _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(z_low, z_low, 224),
                (__m128)*(unsigned __int64 *)&v4->pv.position.rotation.elt[2][0]),
              _mm_add_ps(
                _mm_mul_ps((__m128)*(unsigned __int64 *)&v4->pv.position.rotation.elt[1][0], v10),
                _mm_mul_ps(
                  _mm_shuffle_ps(v8, v8, 224),
                  (__m128)*(unsigned __int64 *)&v4->pv.position.rotation.elt[0][0])));
      v12 = (float)(z_low.m128_f32[0] * v4->pv.position.rotation.elt[2][2])
          + (float)((float)(v4->pv.position.rotation.elt[1][2] * v10.m128_f32[0])
                  + (float)(v4->pv.position.rotation.elt[0][2] * v8.m128_f32[0]));
      _mm_storel_ps((double *)((char *)this + 244), v11);
      *((float *)this + 63) = v12;
      v13 = v4->root->rigidBody;
      if ( v13 )
      {
        v7 = (__m128)*(unsigned __int64 *)&v13->force.x;
        z = v13->force.z;
      }
      _mm_storel_ps((double *)this + 32, v7);
      *((float *)this + 66) = z;
    }
  }
  (*(void (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 32LL))(this);
}


// Address: 0x10dce90 | Name: _ZN3RBX5HUMAN13HumanoidState13render3dAdornEPNS_5AdornE
void __fastcall RBX::HUMAN::HumanoidState::render3dAdorn(RBX::HUMAN::HumanoidState *this, RBX::Adorn *adorn)
{
  char *v3; // r15
  int v4; // r14d
  RBX::PartInstance *v5; // rsi
  const G3D::Color3 *v6; // rax
  const G3D::Color3 *v7; // rax
  RBX::Body *TorsoBodyFast; // rbx
  Vector6<RBX::SurfaceType>::$6DCA4632691BE7DD1CF9833283A8B8A0 x_low; // ebp
  Vector6<RBX::SurfaceType>::$6DCA4632691BE7DD1CF9833283A8B8A0 z_low; // ebx
  float v11; // xmm1_4
  float ComputeCharacterHipHeight; // xmm0_4
  const G3D::Color3 *v13; // rax
  int v14; // eax
  __m128 v15; // xmm0
  __m128 v16; // xmm1
  __m128 v17; // xmm2
  __m128 v18; // xmm0
  __m128 v19; // xmm0
  __m128 v20; // xmm1
  __m128 v21; // xmm2
  __m128 v22; // xmm0
  float v23; // xmm0_4
  const std::string *v24; // rbx
  const G3D::Color3 *v25; // rax
  __m128 v26; // xmm4
  double v27; // xmm1_8
  double v28; // xmm2_8
  __m128 v29; // xmm4
  size_t v30; // rax
  size_t v31; // rbx
  RBX::Adorn *v32; // r15
  char *v33; // r13
  size_t v34; // rbp
  const G3D::Color3 *v35; // rax
  const G3D::Color3 *v36; // rax
  __m128 v37; // xmm4
  double v38; // xmm1_8
  double v39; // xmm2_8
  __m128 v40; // xmm4
  size_t v41; // rax
  size_t v42; // rbx
  char *v43; // r13
  size_t v44; // rbp
  const G3D::Color3 *v45; // rax
  const G3D::Color3 *v46; // rax
  size_t v47; // rax
  size_t v48; // rbx
  char *v49; // r12
  size_t v50; // rbp
  const G3D::Color3 *v51; // rax
  const G3D::Color3 *v52; // rax
  struct _Unwind_Exception *v53; // rbx
  RBX::Color4 color; // [rsp+0h] [rbp-1C8h] BYREF
  void *ptr; // [rsp+10h] [rbp-1B8h]
  RBX::Color4 position; // [rsp+18h] [rbp-1B0h] BYREF
  RBX::Vector2 v57; // [rsp+28h] [rbp-1A0h] BYREF
  RBX::Rect2D clippingRect; // [rsp+30h] [rbp-198h] BYREF
  RBX::Rotation2D outline; // [rsp+40h] [rbp-188h] BYREF
  RBX::Vector2 v60; // [rsp+58h] [rbp-170h] BYREF
  RBX::Vector2 availableSpace[2]; // [rsp+60h] [rbp-168h] BYREF
  float v62; // [rsp+74h] [rbp-154h]
  RBX::Vector3 ladderHitLocation; // [rsp+78h] [rbp-150h] BYREF
  RBX::PartInstance *ladderPartFound; // [rsp+88h] [rbp-140h] BYREF
  RBX::Part part; // [rsp+90h] [rbp-138h] BYREF
  unsigned __int64 v66; // [rsp+190h] [rbp-38h]

  v66 = __readfsqword(0x28u);
  if ( *((_BYTE *)this + 9) | stru_2A34AA8.value )
  {
    v3 = (char *)*((_QWORD *)this + 8);
    v4 = 140;
    if ( v3[702] > 0 )
      v4 = 40;
    ladderPartFound = 0;
    *(_QWORD *)&ladderHitLocation.x = 0;
    ladderHitLocation.z = 0.0;
    RBX::HUMAN::HumanoidState::findLadder(this, adorn, &ladderPartFound, &ladderHitLocation);
    v5 = (RBX::PartInstance *)*((_QWORD *)this + 14);
    if ( v5 )
    {
      RBX::PartInstance::getPart(&part, v5);
      v6 = G3D::Color3::white();
      color.r = v6->r;
      color.g = v6->g;
      color.b = v6->b;
      color.a = 1.0;
      RBX::Draw::selectionBox(&part, adorn, &color, 0.15000001);
      *(_OWORD *)&part.type = 0x3F800000u;
      part.color = (G3D::Color4)0x3F800000u;
      part.surfaceType.data[0] = 1065353216;
      part.surfaceType.data[3] = *((_DWORD *)this + 41);
      *(_QWORD *)&part.surfaceType.data[1] = *(_QWORD *)((char *)this + 156);
      v7 = G3D::Color3::white();
      color.r = v7->r;
      color.g = v7->g;
      color.b = v7->b;
      color.a = 1.0;
      RBX::DrawAdorn::cylinder(adorn, (const RBX::CoordinateFrame *)&part, 1, 0.2, 1.0, &color, 1);
      TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast((RBX::Humanoid *)v3);
      RBX::Body::updatePV(TorsoBodyFast);
      x_low = LODWORD(TorsoBodyFast->pv.position.translation.x);
      z_low = LODWORD(TorsoBodyFast->pv.position.translation.z);
      if ( *((float *)this + 40) == *(float *)&dword_2859524 )
      {
        v11 = INFINITY;
      }
      else
      {
        v62 = *((float *)this + 40);
        ComputeCharacterHipHeight = RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(this);
        v11 = v62 + ComputeCharacterHipHeight;
      }
      *(_OWORD *)&part.type = 0x3F800000u;
      part.color = (G3D::Color4)0x3F800000u;
      part.surfaceType.data[0] = 1065353216;
      part.surfaceType.data[1] = x_low;
      *(float *)&part.surfaceType.data[2] = v11;
      part.surfaceType.data[3] = z_low;
      v13 = G3D::Color3::blue();
      color.r = v13->r;
      color.g = v13->g;
      color.b = v13->b;
      color.a = 1.0;
      RBX::DrawAdorn::cylinder(adorn, (const RBX::CoordinateFrame *)&part, 1, 0.2, 1.0, &color, 1);
    }
    v14 = dword_2A08DA4;
    if ( dword_2A08DA4 == 2047
      || (v15 = _mm_unpacklo_ps((__m128)*((unsigned int *)this + 61), (__m128)*((unsigned int *)this + 54)),
          v16 = _mm_unpacklo_ps((__m128)*((unsigned int *)this + 62), (__m128)*((unsigned int *)this + 55)),
          v17 = _mm_unpacklo_ps((__m128)*((unsigned int *)this + 63), (__m128)*((unsigned int *)this + 56)),
          v18 = _mm_sqrt_ps(_mm_add_ps(_mm_mul_ps(v17, v17), _mm_add_ps(_mm_mul_ps(v16, v16), _mm_mul_ps(v15, v15)))),
          v18.m128_f32[0] > _mm_shuffle_ps(v18, v18, 229).m128_f32[0]) )
    {
      *((_DWORD *)this + 56) = *((_DWORD *)this + 63);
      *((_QWORD *)this + 27) = *(_QWORD *)((char *)this + 244);
    }
    if ( v14 == 2047
      || (v19 = _mm_unpacklo_ps((__m128)*((unsigned int *)this + 64), (__m128)*((unsigned int *)this + 57)),
          v20 = _mm_unpacklo_ps((__m128)*((unsigned int *)this + 65), (__m128)*((unsigned int *)this + 58)),
          v21 = _mm_unpacklo_ps((__m128)*((unsigned int *)this + 66), (__m128)*((unsigned int *)this + 59)),
          v22 = _mm_sqrt_ps(_mm_add_ps(_mm_mul_ps(v21, v21), _mm_add_ps(_mm_mul_ps(v20, v20), _mm_mul_ps(v19, v19)))),
          v22.m128_f32[0] > _mm_shuffle_ps(v22, v22, 229).m128_f32[0]) )
    {
      *((_DWORD *)this + 59) = *((_DWORD *)this + 66);
      *(_QWORD *)((char *)this + 228) = *((_QWORD *)this + 32);
    }
    v23 = *((float *)this + 67);
    if ( v14 == 2047 || fabs(v23) > fabs(*((float *)this + 60)) )
      *((float *)this + 60) = v23;
    dword_2A08DA4 = v14 + 1 - ((v14 + ((unsigned int)((v14 + 1) >> 31) >> 22) + 1) & 0xFFFFFC00);
    if ( RBX::Humanoid::getHeadSlow((RBX::Humanoid *)v3) )
    {
      v24 = (const std::string *)(*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 56LL))(this);
      position.r = 16.0;
      position.g = (float)v4;
      v25 = G3D::Color3::white();
      color.r = v25->r;
      color.g = v25->g;
      color.b = v25->b;
      color.a = 1.0;
      outline.angle = (RBX::RotationAngle)*G3D::Color3::black();
      outline.center.x = 1.0;
      _mm_storel_ps((double *)availableSpace, (__m128)0LL);
      clippingRect = (RBX::Rect2D)xmmword_3E7230;
      *(_OWORD *)&part.type = xmmword_3E4990;
      part.color.r = 0.0;
      RBX::Adorn::drawFont2D(
        adorn,
        v24,
        (const RBX::Vector2 *)&position,
        16.0,
        0,
        &color,
        (const RBX::Color4 *)&outline,
        RBX::Text::Font::FONT_LEGACY,
        RBX::Text::XAlign::XALIGN_LEFT,
        RBX::Text::YAlign::YALIGN_BOTTOM,
        availableSpace,
        &clippingRect,
        (const RBX::Rotation2D *)&part,
        1);
      v26 = (__m128)_mm_loadl_epi64((const __m128i *)((char *)this + 220));
      v27 = v26.m128_f32[0];
      v28 = *(float *)_mm_shuffle_epi32((__m128i)v26, 229).m128i_i32;
      v29 = _mm_mul_ps(v26, v26);
      snprintf(
        (char *)&part,
        0x100u,
        "torque(%8.1f, %8.1f, %8.1f), length:%8.1f",
        *((float *)this + 54),
        v27,
        v28,
        fsqrt(
          _mm_shuffle_ps(v29, v29, 229).m128_f32[0]
        + (float)((float)(*((float *)this + 54) * *((float *)this + 54)) + v29.m128_f32[0])));
      color = 0;
      ptr = 0;
      v30 = strlen((const char *)&part);
      if ( v30 >= 0xFFFFFFFFFFFFFFF0LL )
      {
        std::__basic_string_common<true>::__throw_length_error(&color);
        goto LABEL_45;
      }
      v31 = v30;
      v32 = adorn;
      if ( v30 >= 0x17 )
      {
        v34 = (v30 + 16) & 0xFFFFFFFFFFFFFFF0LL;
        v33 = (char *)operator new(v34);
        ptr = v33;
        *(_QWORD *)&color.r = v34 | 1;
        *(_QWORD *)&color.b = v31;
      }
      else
      {
        LOBYTE(color.r) = 2 * v30;
        v33 = (char *)&color.r + 1;
        if ( !v30 )
        {
LABEL_25:
          v33[v31] = 0;
          v57.x = 16.0;
          v57.y = (float)(v4 + 20);
          v35 = G3D::Color3::white();
          clippingRect.min.x = v35->r;
          clippingRect.min.y = v35->g;
          clippingRect.max.x = v35->b;
          clippingRect.max.y = 1.0;
          v36 = G3D::Color3::black();
          position.r = v36->r;
          position.g = v36->g;
          position.b = v36->b;
          position.a = 1.0;
          _mm_storel_ps((double *)&v60, (__m128)0LL);
          *(_OWORD *)&availableSpace[0].x = xmmword_3E7230;
          *(_OWORD *)&outline.angle.value = xmmword_3E4990;
          outline.center.y = 0.0;
          RBX::Adorn::drawFont2D(
            v32,
            (const std::string *)&color,
            &v57,
            16.0,
            0,
            (const RBX::Color4 *)&clippingRect,
            &position,
            RBX::Text::Font::FONT_LEGACY,
            RBX::Text::XAlign::XALIGN_LEFT,
            RBX::Text::YAlign::YALIGN_BOTTOM,
            &v60,
            (const RBX::Rect2D *)availableSpace,
            &outline,
            1);
          if ( (LOBYTE(color.r) & 1) != 0 )
            operator delete(ptr);
          v37 = (__m128)_mm_loadl_epi64((const __m128i *)((char *)this + 232));
          v38 = v37.m128_f32[0];
          v39 = *(float *)_mm_shuffle_epi32((__m128i)v37, 229).m128i_i32;
          v40 = _mm_mul_ps(v37, v37);
          snprintf(
            (char *)&part,
            0x100u,
            "force(%8.1f, %8.1f, %8.1f), length:%8.1f",
            *((float *)this + 57),
            v38,
            v39,
            fsqrt(
              _mm_shuffle_ps(v40, v40, 229).m128_f32[0]
            + (float)((float)(*((float *)this + 57) * *((float *)this + 57)) + v40.m128_f32[0])));
          color = 0;
          ptr = 0;
          v41 = strlen((const char *)&part);
          if ( v41 < 0xFFFFFFFFFFFFFFF0LL )
          {
            v42 = v41;
            if ( v41 >= 0x17 )
            {
              v44 = (v41 + 16) & 0xFFFFFFFFFFFFFFF0LL;
              v43 = (char *)operator new(v44);
              ptr = v43;
              *(_QWORD *)&color.r = v44 | 1;
              *(_QWORD *)&color.b = v42;
            }
            else
            {
              LOBYTE(color.r) = 2 * v41;
              v43 = (char *)&color.r + 1;
              if ( !v41 )
              {
LABEL_33:
                v43[v42] = 0;
                v57.x = 16.0;
                v57.y = (float)(v4 + 40);
                v45 = G3D::Color3::white();
                clippingRect.min.x = v45->r;
                clippingRect.min.y = v45->g;
                clippingRect.max.x = v45->b;
                clippingRect.max.y = 1.0;
                v46 = G3D::Color3::black();
                position.r = v46->r;
                position.g = v46->g;
                position.b = v46->b;
                position.a = 1.0;
                _mm_storel_ps((double *)&v60, (__m128)0LL);
                *(_OWORD *)&availableSpace[0].x = xmmword_3E7230;
                *(_OWORD *)&outline.angle.value = xmmword_3E4990;
                outline.center.y = 0.0;
                RBX::Adorn::drawFont2D(
                  v32,
                  (const std::string *)&color,
                  &v57,
                  16.0,
                  0,
                  (const RBX::Color4 *)&clippingRect,
                  &position,
                  RBX::Text::Font::FONT_LEGACY,
                  RBX::Text::XAlign::XALIGN_LEFT,
                  RBX::Text::YAlign::YALIGN_BOTTOM,
                  &v60,
                  (const RBX::Rect2D *)availableSpace,
                  &outline,
                  1);
                if ( (LOBYTE(color.r) & 1) != 0 )
                  operator delete(ptr);
                snprintf((char *)&part, 0x100u, "contact velocity : %f", *((float *)this + 60));
                color = 0;
                ptr = 0;
                v47 = strlen((const char *)&part);
                if ( v47 < 0xFFFFFFFFFFFFFFF0LL )
                {
                  v48 = v47;
                  if ( v47 >= 0x17 )
                  {
                    v50 = (v47 + 16) & 0xFFFFFFFFFFFFFFF0LL;
                    v49 = (char *)operator new(v50);
                    ptr = v49;
                    *(_QWORD *)&color.r = v50 | 1;
                    *(_QWORD *)&color.b = v48;
                  }
                  else
                  {
                    LOBYTE(color.r) = 2 * v47;
                    v49 = (char *)&color.r + 1;
                    if ( !v47 )
                    {
LABEL_41:
                      v49[v48] = 0;
                      v57.x = 16.0;
                      v57.y = (float)(v4 + 60);
                      v51 = G3D::Color3::white();
                      clippingRect.min.x = v51->r;
                      clippingRect.min.y = v51->g;
                      clippingRect.max.x = v51->b;
                      clippingRect.max.y = 1.0;
                      v52 = G3D::Color3::black();
                      position.r = v52->r;
                      position.g = v52->g;
                      position.b = v52->b;
                      position.a = 1.0;
                      _mm_storel_ps((double *)&v60, (__m128)0LL);
                      *(_OWORD *)&availableSpace[0].x = xmmword_3E7230;
                      *(_OWORD *)&outline.angle.value = xmmword_3E4990;
                      outline.center.y = 0.0;
                      RBX::Adorn::drawFont2D(
                        v32,
                        (const std::string *)&color,
                        &v57,
                        16.0,
                        0,
                        (const RBX::Color4 *)&clippingRect,
                        &position,
                        RBX::Text::Font::FONT_LEGACY,
                        RBX::Text::XAlign::XALIGN_LEFT,
                        RBX::Text::YAlign::YALIGN_BOTTOM,
                        &v60,
                        (const RBX::Rect2D *)availableSpace,
                        &outline,
                        1);
                      if ( (LOBYTE(color.r) & 1) != 0 )
                        operator delete(ptr);
                      return;
                    }
                  }
                  memcpy(v49, &part, v48);
                  goto LABEL_41;
                }
LABEL_46:
                v53 = (struct _Unwind_Exception *)std::__basic_string_common<true>::__throw_length_error(&color);
                if ( (LOBYTE(color.r) & 1) != 0 )
                  operator delete(ptr);
                _Unwind_Resume(v53);
              }
            }
            memcpy(v43, &part, v42);
            goto LABEL_33;
          }
LABEL_45:
          std::__basic_string_common<true>::__throw_length_error(&color);
          goto LABEL_46;
        }
      }
      memcpy(v33, &part, v31);
      goto LABEL_25;
    }
  }
}


// Address: 0x10dd8b0 | Name: _ZN3RBX5HUMAN13HumanoidState10findLadderEPNS_5AdornEPPNS_12PartInstanceEPN3G3D7Vector3E
bool __fastcall RBX::HUMAN::HumanoidState::findLadder(
        RBX::HUMAN::HumanoidState *this,
        RBX::Adorn *adorn,
        RBX::PartInstance **ladderPartFound,
        RBX::Vector3 *ladderHitLocation)
{
  __m128 v4; // xmm0
  __m128 v5; // xmm1
  RBX::Adorn *v8; // r12
  RBX::PartInstance *TorsoSlow; // rax
  const RBX::PartInstance *v10; // rbp
  const RBX::CoordinateFrame *CoordinateFrame; // r15
  int v12; // eax
  float v13; // xmm0_4
  int v14; // ecx
  RBX::HUMAN::HumanoidState *v15; // rbp
  int v16; // ebx
  float LadderRayPosRelativeTorso; // xmm0_4
  int v18; // r13d
  __m128 v19; // xmm1
  float v20; // xmm0_4
  __m128 v21; // xmm1
  float v22; // xmm0_4
  RBX::Humanoid *v23; // rdx
  __m128 v24; // xmm2
  __m128 v25; // xmm3
  float v26; // xmm2_4
  RBX::RbxRay *p_caster; // rsi
  __int64 v28; // rax
  float v29; // xmm1_4
  RBX::Primitive *v30; // r15
  RBX::Adorn *v31; // rbx
  RBX::PartInstance *v32; // rax
  RBX::PartInstance *v33; // rbp
  int v34; // eax
  __int64 v35; // rax
  RBX::Primitive *px; // r14
  unsigned int v37; // ebp
  RBX::Collision::Contact *ContactNew; // rax
  RBX::Primitive *prim0; // r12
  RBX::PartInstance *v40; // rax
  const G3D::Color3 *v41; // rax
  float *p_b; // rdx
  unsigned int *p_g; // rcx
  float v44; // r14d
  unsigned int v45; // ebx
  float r; // ebp
  __m128 v47; // xmm0
  __m128 v48; // xmm1
  float v49; // xmm0_4
  bool v51; // bl
  float *p_x; // rbp
  RBX::PartInstance **v53; // r14
  __m128 v55; // xmm0
  float v56; // xmm1_4
  float v57; // [rsp+0h] [rbp-128h]
  float v58; // [rsp+4h] [rbp-124h]
  float z; // [rsp+8h] [rbp-120h]
  float y; // [rsp+Ch] [rbp-11Ch]
  float x; // [rsp+10h] [rbp-118h]
  float v62; // [rsp+14h] [rbp-114h]
  float v63; // [rsp+18h] [rbp-110h]
  float v64; // [rsp+1Ch] [rbp-10Ch]
  RBX::Vector3 hitLocationOut; // [rsp+20h] [rbp-108h] BYREF
  float *v66; // [rsp+30h] [rbp-F8h]
  float v67; // [rsp+38h] [rbp-F0h]
  float v68; // [rsp+3Ch] [rbp-ECh]
  int v69; // [rsp+40h] [rbp-E8h]
  float v70; // [rsp+44h] [rbp-E4h]
  RBX::RbxRay caster; // [rsp+48h] [rbp-E0h] BYREF
  RBX::Primitive *v72; // [rsp+60h] [rbp-C8h]
  RBX::RbxRay *v73; // [rsp+68h] [rbp-C0h]
  RBX::HUMAN::HumanoidState *v74; // [rsp+70h] [rbp-B8h]
  float v75; // [rsp+7Ch] [rbp-ACh]
  int v76; // [rsp+80h] [rbp-A8h]
  float v77; // [rsp+84h] [rbp-A4h]
  RBX::PartInstance **v78; // [rsp+88h] [rbp-A0h]
  RBX::Vector3 *v79; // [rsp+90h] [rbp-98h]
  RBX::Primitive *hitPrimOut; // [rsp+98h] [rbp-90h] BYREF
  __m128 v81; // [rsp+A0h] [rbp-88h]
  __m128 v82; // [rsp+B0h] [rbp-78h]
  RBX::CoordinateFrame worldC; // [rsp+C0h] [rbp-68h] BYREF
  RBX::Instance *v84; // [rsp+F0h] [rbp-38h]
  G3D::Vector3 v85; // 0:kr00_12.12

  v8 = adorn;
  if ( !RBX::Humanoid::getStateTransitionEnabled(*((RBX::Humanoid **)this + 8), RBX::HUMAN::StateType::CLIMBING) )
    return 0;
  TorsoSlow = RBX::Humanoid::getTorsoSlow(*((RBX::Humanoid **)this + 8));
  if ( !TorsoSlow )
    return 0;
  v10 = TorsoSlow;
  if ( !RBX::HUMAN::HumanoidState::findPrimitiveInLadderZone(this, adorn) )
    return 0;
  CoordinateFrame = RBX::PartInstance::getCoordinateFrame(v10);
  v85 = G3D::Matrix3::column(&CoordinateFrame->rotation, 2);
  v4.m128_i32[0] = LODWORD(v85.x);
  v4.m128_i32[1] = LODWORD(v85.y);
  v5.m128_i32[0] = LODWORD(v85.z);
  v82 = v4;
  v81 = v5;
  G3D::Color3::orange();
  v75 = RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(this) / 3.0;
  v70 = 0.14285715 * v75;
  v13 = RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(this) + -0.30000001;
  v14 = (int)(float)(v13 / (float)(0.14285715 * v75));
  v15 = this;
  if ( stru_2A08D18.value )
  {
    v16 = (int)(float)(v13 / (float)(0.14285715 * v75));
    LadderRayPosRelativeTorso = RBX::HUMAN::HumanoidState::firstLadderRayPosRelativeTorso(
                                  this,
                                  &CoordinateFrame->translation,
                                  v13,
                                  adorn);
    v14 = v16;
    v77 = LadderRayPosRelativeTorso;
    if ( v16 < -8 )
      return 0;
  }
  else if ( v14 < -8 )
  {
    return 0;
  }
  v78 = ladderPartFound;
  v79 = ladderHitLocation;
  v81 = _mm_xor_ps(v81, *(__m128 *)&stru_3E4970.x);
  v82 = _mm_xor_ps(v82, *(__m128 *)&stru_3E4970.x);
  v18 = 1;
  LOBYTE(v12) = 1;
  v69 = v12;
  v62 = -1.0;
  v73 = 0;
  v58 = 0.0;
  v68 = 0.0;
  v72 = 0;
  z = 0.0;
  y = 0.0;
  x = 0.0;
  v74 = this;
  v66 = (float *)CoordinateFrame;
  v76 = v14 + 9;
  do
  {
    v19 = 0;
    v19.m128_f32[0] = (float)v18 * v70;
    v20 = v77;
    v57 = v19.m128_f32[0];
    if ( !stru_2A08D18.value )
    {
      v19 = (__m128)v19.m128_u32[0];
      v20 = RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(v15) + -0.30000001;
    }
    v19.m128_f32[0] = v19.m128_f32[0] - v20;
    v21 = _mm_add_ps(
            _mm_shuffle_ps(_mm_shuffle_ps(v19, (__m128)0LL, 0), (__m128)0LL, 226),
            (__m128)*(unsigned __int64 *)&CoordinateFrame->translation.x);
    v22 = CoordinateFrame->translation.z + 0.0;
    v23 = (RBX::Humanoid *)*((_QWORD *)v15 + 8);
    if ( !v23 || (v24 = (__m128)0x3FE66667u, !*((_DWORD *)v23 + 177)) )
      v24 = (__m128)0x3F866666u;
    v25 = _mm_mul_ps(_mm_shuffle_ps(v24, v24, 224), v82);
    v26 = v24.m128_f32[0] * v81.m128_f32[0];
    _mm_storel_ps((double *)&caster.m_origin.x, v21);
    caster.m_origin.z = v22;
    _mm_storel_ps((double *)&caster.m_direction.x, v25);
    caster.m_direction.z = v26;
    hitPrimOut = 0;
    *(_QWORD *)&hitLocationOut.x = 0;
    hitLocationOut.z = 0.0;
    p_caster = &caster;
    RBX::HUMAN::HumanoidState::doLadderRaycast(v15, &caster, v23, &hitPrimOut, &hitLocationOut);
    v28 = *((_QWORD *)v15 + 8);
    if ( !v28 || (v29 = 1.2, !*(_DWORD *)(v28 + 708)) )
      v29 = 0.69999999;
    v30 = hitPrimOut;
    v64 = (float)((float)((float)(hitLocationOut.y - caster.m_origin.y) * (float)(hitLocationOut.y - caster.m_origin.y))
                + (float)((float)(hitLocationOut.x - caster.m_origin.x) * (float)(hitLocationOut.x - caster.m_origin.x)))
        + (float)((float)(hitLocationOut.z - caster.m_origin.z) * (float)(hitLocationOut.z - caster.m_origin.z));
    v63 = v29 * v29;
    if ( !hitPrimOut )
      goto LABEL_47;
    v31 = v8;
    v32 = RBX::PartInstance::fromPrimitive(hitPrimOut);
    if ( v32 )
    {
      v33 = v32;
      if ( (*((unsigned int (__fastcall **)(RBX::PartInstance *))v32->_vptr$EventSource + 42))(v32) == 3 )
      {
        if ( stru_2A08D48.value )
        {
          *v78 = v33;
          *v79 = hitLocationOut;
        }
        if ( !stru_2A08CC0.value )
          return 1;
        v34 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)v74 + 128LL))(v74);
        if ( v63 > v64 || v34 == 12 )
          return 1;
        v35 = *((_QWORD *)v74 + 8);
        if ( *(_QWORD *)(v35 + 2464) )
        {
          px = v33->primitive.px;
          if ( px )
          {
            if ( (int)((*((_QWORD *)px + 59) - *((_QWORD *)px + 58)) >> 4) > 0 )
            {
              v84 = *(RBX::Instance **)(v35 + 88);
              v37 = 0;
              do
              {
                p_caster = (RBX::RbxRay *)v37;
                ContactNew = RBX::Primitive::getContactNew(px, v37);
                prim0 = ContactNew->prim0;
                if ( prim0 == px )
                  prim0 = ContactNew->prim1;
                if ( RBX::Collision::Contact::getInContact(ContactNew)
                  && !*((_BYTE *)prim0 + 594)
                  && !*((_BYTE *)prim0 + 596) )
                {
                  v40 = RBX::PartInstance::fromPrimitive(prim0);
                  if ( v40 )
                  {
                    if ( v40->parent == v84 )
                      return 1;
                  }
                }
              }
              while ( (int)++v37 < (int)((*((_QWORD *)px + 59) - *((_QWORD *)px + 58)) >> 4) );
            }
          }
        }
      }
    }
    v8 = v31;
    v15 = v74;
    if ( v63 <= v64 )
    {
LABEL_47:
      v41 = G3D::Color3::yellow();
      if ( ((unsigned __int8)v73 & 1) != 0 )
      {
        v41 = G3D::Color3::red();
        p_g = (unsigned int *)&v41->g;
        p_b = &v41->b;
        v73 = 0;
        v68 = v57 - v58;
      }
      else
      {
        p_g = (unsigned int *)&v41->g;
        p_b = &v41->b;
      }
      goto LABEL_51;
    }
    if ( stru_2A08D48.value
      && (!v72
       || v67 > (float)((float)((float)(hitLocationOut.z - v66[11]) * (float)(hitLocationOut.z - v66[11]))
                      + (float)((float)((float)(hitLocationOut.y - v66[10]) * (float)(hitLocationOut.y - v66[10]))
                              + (float)((float)(hitLocationOut.x - v66[9]) * (float)(hitLocationOut.x - v66[9]))))) )
    {
      x = hitLocationOut.x;
      y = hitLocationOut.y;
      z = hitLocationOut.z;
      v67 = (float)((float)(hitLocationOut.z - v66[11]) * (float)(hitLocationOut.z - v66[11]))
          + (float)((float)((float)(hitLocationOut.y - v66[10]) * (float)(hitLocationOut.y - v66[10]))
                  + (float)((float)(hitLocationOut.x - v66[9]) * (float)(hitLocationOut.x - v66[9])));
      v72 = v30;
    }
    v41 = G3D::Color3::gray();
    if ( (v69 & 1) != 0 )
    {
      v41 = G3D::Color3::green();
      p_g = (unsigned int *)&v41->g;
      p_b = &v41->b;
      LOBYTE(p_caster) = 1;
      v73 = p_caster;
      v69 = 0;
      v58 = v57;
LABEL_51:
      CoordinateFrame = (const RBX::CoordinateFrame *)v66;
      goto LABEL_52;
    }
    p_b = &v41->b;
    p_g = (unsigned int *)&v41->g;
    CoordinateFrame = (const RBX::CoordinateFrame *)v66;
    if ( ((unsigned __int8)v73 & 1) == 0 && v62 < 0.0 )
    {
      v41 = G3D::Color3::blue();
      p_g = (unsigned int *)&v41->g;
      p_b = &v41->b;
      v62 = v57;
      if ( !v31 )
        continue;
      goto LABEL_53;
    }
LABEL_52:
    if ( !v8 )
      continue;
LABEL_53:
    v44 = *p_b;
    v45 = *p_g;
    r = v41->r;
    *(_OWORD *)&worldC.rotation.elt[0][0] = 0x3F800000u;
    *(_OWORD *)&worldC.rotation.elt[1][1] = 0x3F800000u;
    *(_OWORD *)&worldC.rotation.elt[2][2] = 0x3F800000u;
    (*(void (__fastcall **)(RBX::Adorn *, RBX::CoordinateFrame *))(*(_QWORD *)v8 + 176LL))(v8, &worldC);
    v47 = (__m128)LODWORD(v64);
    if ( v63 > v64 )
    {
      v47.m128_f32[0] = fsqrt(v64);
      v48 = _mm_mul_ps(_mm_shuffle_ps(v47, v47, 224), v82);
      v49 = v47.m128_f32[0] * v81.m128_f32[0];
      _mm_storel_ps((double *)&caster.m_direction.x, v48);
      caster.m_direction.z = v49;
    }
    *(_QWORD *)&worldC.rotation.elt[0][0] = __PAIR64__(v45, LODWORD(r));
    worldC.rotation.elt[0][2] = v44;
    worldC.rotation.elt[1][0] = 1.0;
    (*(void (__fastcall **)(RBX::Adorn *, RBX::RbxRay *, RBX::CoordinateFrame *))(*(_QWORD *)v8 + 256LL))(
      v8,
      &caster,
      &worldC);
    v15 = v74;
  }
  while ( v18++ < v76 );
  v51 = 0;
  p_x = &v79->x;
  v53 = v78;
  if ( (float)(v75 * 2.45) > v68 && v68 > 0.0 && v75 > v58 )
  {
    if ( v62 < 0.0 && v58 <= (float)(v75 / 5.0) )
      return 0;
    if ( v8 )
    {
      v55 = _mm_add_ps((__m128)*(unsigned __int64 *)&CoordinateFrame->translation.x, (__m128)xmmword_3E61F0);
      v56 = CoordinateFrame->translation.z + 0.0;
      *(_OWORD *)&worldC.rotation.elt[0][0] = 0x3F800000u;
      *(_OWORD *)&worldC.rotation.elt[1][1] = 0x3F800000u;
      worldC.rotation.elt[2][2] = 1.0;
      _mm_storel_ps((double *)&worldC.translation.x, v55);
      worldC.translation.z = v56;
      caster.m_origin = (G3D::Vector3)*G3D::Color3::purple();
      caster.m_direction.x = 1.0;
      RBX::DrawAdorn::cylinder(v8, &worldC, 1, 0.2, 1.0, (const RBX::Color4 *)&caster, 1);
    }
    v51 = 1;
    if ( stru_2A08D48.value )
    {
      *v53 = RBX::PartInstance::fromPrimitive(v72);
      *p_x = x;
      p_x[1] = y;
      p_x[2] = z;
    }
  }
  return v51;
}


// Address: 0x10de0f0 | Name: _ZN3RBX5HUMAN13HumanoidState18getDesiredAltitudeEv
float __fastcall RBX::HUMAN::HumanoidState::getDesiredAltitude(RBX::HUMAN::HumanoidState *this)
{
  float v2; // [rsp+0h] [rbp-4h]

  if ( *((float *)this + 40) == *(float *)&dword_2859524 )
    return INFINITY;
  v2 = *((float *)this + 40);
  return v2 + RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(this);
}


// Address: 0x10de140 | Name: _ZNK3RBX5HUMAN13HumanoidState24getFloorFrictionPropertyEPNS_9PrimitiveE
float __fastcall RBX::HUMAN::HumanoidState::getFloorFrictionProperty(
        const RBX::HUMAN::HumanoidState *this,
        RBX::Primitive *floorPrim)
{
  __int64 v2; // rax
  RBX::PhysicalProperties v4; // [rsp+0h] [rbp-18h] BYREF

  v2 = *((_QWORD *)floorPrim + 73);
  if ( *(_BYTE *)v2 )
    return *(float *)(v2 + 12);
  RBX::MaterialProperties::generatePhysicalMaterialFromPartMaterial(&v4, *((RBX::PartMaterial *)this + 32));
  return v4.friction;
}


// Address: 0x10de180 | Name: _ZN3RBX5HUMAN13HumanoidState17getFloorPrimitiveEv
RBX::Primitive *__fastcall RBX::HUMAN::HumanoidState::getFloorPrimitive(RBX::HUMAN::HumanoidState *this)
{
  __int64 v1; // rax
  RBX::Primitive *v2; // rbx
  RBX::Humanoid *v3; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax

  v1 = *((_QWORD *)this + 14);
  if ( !v1 )
    return 0;
  v2 = *(RBX::Primitive **)(v1 + 232);
  if ( !*((_QWORD *)v2 + 17) )
    return 0;
  v3 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( !v3 )
    return 0;
  TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v3);
  if ( !TorsoPrimitiveFast )
    return 0;
  PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
  if ( !PrimitiveAssembly || PrimitiveAssembly == RBX::Assembly::getPrimitiveAssembly(v2) )
    return 0;
  return v2;
}


// Address: 0x10de1e0 | Name: _ZN3RBX5HUMAN13HumanoidState18getLadderPrimitiveEv
RBX::Primitive *__fastcall RBX::HUMAN::HumanoidState::getLadderPrimitive(RBX::HUMAN::HumanoidState *this)
{
  __int64 v1; // rax
  RBX::Primitive *v2; // rbx
  RBX::Humanoid *v3; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax

  v1 = *((_QWORD *)this + 23);
  if ( !v1 )
    return 0;
  v2 = *(RBX::Primitive **)(v1 + 232);
  if ( !*((_QWORD *)v2 + 17) )
    return 0;
  v3 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( !v3 )
    return 0;
  TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v3);
  if ( !TorsoPrimitiveFast )
    return 0;
  PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
  if ( !PrimitiveAssembly || PrimitiveAssembly == RBX::Assembly::getPrimitiveAssembly(v2) )
    return 0;
  return v2;
}


// Address: 0x10de240 | Name: _ZNK3RBX5HUMAN13HumanoidState22getFloorPrimitiveConstEv
const RBX::Primitive *__fastcall RBX::HUMAN::HumanoidState::getFloorPrimitiveConst(
        const RBX::HUMAN::HumanoidState *this)
{
  __int64 v1; // rax
  RBX::Primitive *v2; // rbx
  RBX::Humanoid *v3; // rdi
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Assembly *ConstPrimitiveAssembly; // rax

  v1 = *((_QWORD *)this + 14);
  if ( !v1 )
    return 0;
  v2 = *(RBX::Primitive **)(v1 + 232);
  if ( !*((_QWORD *)v2 + 17) )
    return 0;
  v3 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( !v3 )
    return 0;
  TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(v3);
  if ( !TorsoPrimitiveSlow )
    return 0;
  ConstPrimitiveAssembly = (RBX::Assembly *)RBX::Assembly::getConstPrimitiveAssembly(TorsoPrimitiveSlow);
  if ( !ConstPrimitiveAssembly || ConstPrimitiveAssembly == RBX::Assembly::getPrimitiveAssembly(v2) )
    return 0;
  return v2;
}


// Address: 0x10de2a0 | Name: _ZN3RBX5HUMAN13HumanoidState12defaultStateEPNS_8HumanoidE
RBX::HUMAN::HumanoidState *__fastcall RBX::HUMAN::HumanoidState::defaultState(RBX::Humanoid *humanoid)
{
  RBX::HUMAN::Running *v1; // rbx

  v1 = (RBX::HUMAN::Running *)operator new(0x1D0u);
  RBX::HUMAN::Running::Running(v1, humanoid, RBX::HUMAN::StateType::RUNNING_NO_PHYS);
  return v1;
}


// Address: 0x10de2f0 | Name: _ZN3RBX5HUMAN13HumanoidState20preStepSimulatorSideEf
void __fastcall RBX::HUMAN::HumanoidState::preStepSimulatorSide(RBX::HUMAN::HumanoidState *this, float a2, float dt)
{
  int v3; // eax
  __int64 v4; // rcx
  int v5; // eax
  int v6; // eax
  int v7; // eax
  bool Ladder; // al
  __int128 v9; // xmm0
  volatile signed __int32 *v10; // r14
  volatile signed __int32 *v11; // r14
  __int64 v12; // rax
  volatile signed __int32 *v13; // r14
  __m128 v14; // xmm0
  float v15; // xmm1_4
  __m128 v16; // xmm0
  __m128d v17; // xmm0
  double v18; // [rsp+0h] [rbp-58h]
  RBX::Vector3 ladderHitLocation; // [rsp+8h] [rbp-50h] BYREF
  RBX::PartInstance *ladderPartFound; // [rsp+18h] [rbp-40h] BYREF
  _OWORD v21[2]; // [rsp+20h] [rbp-38h] BYREF
  double v22; // [rsp+40h] [rbp-18h]

  RBX::HUMAN::HumanoidState::preStepFloor(this);
  *((float *)this + 4) = *((float *)this + 4) - a2;
  *((float *)this + 5) = *((float *)this + 5) + a2;
  *((float *)this + 7) = a2 + *((float *)this + 7);
  RBX::HUMAN::HumanoidState::preStepCollide(this);
  *((_BYTE *)this + 13) = 0;
  v3 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this);
  v4 = 7873;
  if ( _bittest64(&v4, (unsigned int)(v3 + 1))
    || (v5 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this), v5 == 12)
    || v5 == -1 )
  {
    v6 = *((_DWORD *)this + 53);
    if ( v6 <= 0 )
    {
      ladderPartFound = 0;
      *(_QWORD *)&ladderHitLocation.x = 0;
      ladderHitLocation.z = 0.0;
      Ladder = RBX::HUMAN::HumanoidState::findLadder(this, 0, &ladderPartFound, &ladderHitLocation);
      *((_BYTE *)this + 13) = Ladder;
      if ( stru_2A08D48.value )
      {
        if ( Ladder )
        {
          RBX::shared_from<RBX::PartInstance>(
            (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)v21,
            ladderPartFound);
          v9 = v21[0];
          v21[0] = 0;
          v10 = (volatile signed __int32 *)*((_QWORD *)this + 24);
          *(_OWORD *)((char *)this + 184) = v9;
          if ( v10 )
          {
            if ( !_InterlockedSub(v10 + 2, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
              if ( !_InterlockedSub(v10 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 24LL))(v10);
            }
          }
          v11 = (volatile signed __int32 *)*((_QWORD *)&v21[0] + 1);
          if ( *((_QWORD *)&v21[0] + 1) )
          {
            if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&v21[0] + 1) + 8LL), 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
              if ( !_InterlockedSub(v11 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 24LL))(v11);
            }
          }
          *((_DWORD *)this + 52) = LODWORD(ladderHitLocation.z);
          v12 = *(_QWORD *)&ladderHitLocation.x;
        }
        else
        {
          v13 = (volatile signed __int32 *)*((_QWORD *)this + 24);
          *(_OWORD *)((char *)this + 184) = 0;
          if ( v13 )
          {
            if ( !_InterlockedSub(v13 + 2, 1u) )
            {
              (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
              if ( !_InterlockedSub(v13 + 3, 1u) )
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 24LL))(v13);
            }
          }
          *((_DWORD *)this + 52) = dword_2859534;
          v12 = qword_285952C;
        }
        *((_QWORD *)this + 25) = v12;
      }
      v7 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 24LL))(this);
    }
    else
    {
      v7 = v6 - 1;
    }
    *((_DWORD *)this + 53) = v7;
  }
  if ( !*((_BYTE *)this + 13) && *(char *)(*((_QWORD *)this + 8) + 698LL) > 0 )
  {
    if ( (*(unsigned __int8 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 96LL))(this) )
    {
      (*(void (__fastcall **)(_OWORD *))(**((_QWORD **)this + 8) + 416LL))(v21);
      v14 = _mm_mul_ps((__m128)*(unsigned __int64 *)((char *)v21 + 4), (__m128)*(unsigned __int64 *)((char *)v21 + 4));
      v15 = (float)(*(float *)v21 * *(float *)v21) + v14.m128_f32[0];
      v16 = _mm_shuffle_ps(v14, v14, 229);
      v16.m128_f32[0] = v16.m128_f32[0] + v15;
      if ( v16.m128_f32[0] != 0.0 )
      {
        v17 = (__m128d)_mm_and_ps(v16, (__m128)xmmword_3E5B40);
        v18 = *(float *)v17.m128d_f64;
        v22 = *(float *)v17.m128d_f64 + 1.0;
        v17.m128d_f64[0] = G3D::inf();
        v17.m128d_f64[0] = _mm_cmpeq_sd(v17, (__m128d)*(unsigned __int64 *)&v22).m128d_f64[0];
        if ( COERCE_DOUBLE(
               *(_QWORD *)&v17.m128d_f64[0] & 0x3EE4F8B580000000LL
             | ~*(_QWORD *)&v17.m128d_f64[0] & COERCE_UNSIGNED_INT64(v22 * 0.000009999999747378752)) < v18 )
          RBX::HUMAN::HumanoidState::doAutoJump(this);
      }
    }
  }
}


// Address: 0x10de5a0 | Name: _ZN3RBX5HUMAN13HumanoidState12preStepFloorEv
void __fastcall RBX::HUMAN::HumanoidState::preStepFloor(RBX::HUMAN::HumanoidState *this)
{
  boost::detail::sp_counted_base *v2; // rax
  _QWORD *v3; // rax
  volatile signed __int32 *v4; // r14
  int v5; // eax
  __int64 v6; // rcx
  int v7; // eax
  __int64 v8; // rcx
  int v9; // eax
  __int64 v10; // rcx
  __int64 v11; // rcx
  boost::shared_ptr<RBX::PartInstance>::element_type *v12; // rax
  boost::shared_ptr<RBX::PartInstance>::element_type *px; // r14
  RBX::PartInstance *TorsoSlow; // rax
  RBX::PartInstance *v15; // r15
  boost::detail::sp_counted_base *pi; // r14
  __int64 v17; // rax
  RBX::Primitive *v18; // r14
  RBX::Humanoid *v19; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // r15
  RBX::Assembly *v22; // rax
  boost::detail::sp_counted_base *v23; // rbx
  boost::shared_ptr<RBX::PartInstance> v24; // [rsp+0h] [rbp-48h] BYREF
  boost::shared_ptr<RBX::PartInstance> other; // [rsp+10h] [rbp-38h] BYREF
  RBX::Vector3 oldFloorNormal; // [rsp+20h] [rbp-28h] BYREF

  v24.px = (boost::shared_ptr<RBX::PartInstance>::element_type *)*((_QWORD *)this + 14);
  v2 = (boost::detail::sp_counted_base *)*((_QWORD *)this + 15);
  v24.pn.pi_ = v2;
  if ( v2 )
  {
    _InterlockedAdd(&v2->use_count_, 1u);
    v3 = (_QWORD *)((char *)this + 120);
    v4 = (volatile signed __int32 *)*((_QWORD *)this + 15);
  }
  else
  {
    v3 = (_QWORD *)((char *)this + 120);
    v4 = 0;
  }
  oldFloorNormal = *(RBX::Vector3 *)((_BYTE *)this + 12);
  *((_QWORD *)this + 14) = 0;
  *v3 = 0;
  if ( v4 )
  {
    if ( !_InterlockedSub(v4 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
      if ( !_InterlockedSub(v4 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
    }
  }
  *((_DWORD *)this + 35) = dword_2859528;
  *(_QWORD *)((char *)this + 132) = unk_2859520;
  *((_QWORD *)this + 18) = 0x3F80000000000000LL;
  *((_DWORD *)this + 38) = 0;
  *((_DWORD *)this + 41) = dword_2859528;
  *(_QWORD *)((char *)this + 156) = unk_2859520;
  v5 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this);
  v6 = 8209;
  if ( _bittest64(&v6, (unsigned int)(v5 + 1))
    || (v7 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this),
        v8 = 8385,
        _bittest64(&v8, (unsigned int)(v7 + 1)))
    || (v9 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this),
        v10 = 16145,
        _bittest64(&v10, (unsigned int)(v9 + 1))) )
  {
    RBX::HUMAN::HumanoidState::findFloor(this, &v24, &oldFloorNormal);
  }
  if ( *((_QWORD *)this + 14) )
  {
    v11 = *((_QWORD *)this + 8);
    *(_DWORD *)(v11 + 884) = *((_DWORD *)this + 38);
    *(_QWORD *)(v11 + 876) = *((_QWORD *)this + 18);
    v12 = (boost::shared_ptr<RBX::PartInstance>::element_type *)*((_QWORD *)this + 14);
  }
  else
  {
    v12 = 0;
  }
  px = v24.px;
  if ( v24.px != v12 )
  {
    TorsoSlow = RBX::Humanoid::getTorsoSlow(*((RBX::Humanoid **)this + 8));
    if ( px )
    {
      v15 = TorsoSlow;
      if ( TorsoSlow )
      {
        if ( !RBX::ContactManager::arePrimitivesOverlapping(px->primitive.px, TorsoSlow->primitive.px) )
        {
          RBX::shared_from<RBX::PartInstance>(&other.px, v15);
          RBX::PartInstance::reportUntouch(px, &other);
          pi = other.pn.pi_;
          if ( other.pn.pi_ )
          {
            if ( !_InterlockedSub(&other.pn.pi_->use_count_, 1u) )
            {
              (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
              if ( !_InterlockedSub(&pi->weak_count_, 1u) )
                (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
            }
          }
        }
      }
    }
    v17 = *((_QWORD *)this + 14);
    if ( v17 )
    {
      v18 = *(RBX::Primitive **)(v17 + 232);
      if ( *((_QWORD *)v18 + 17) )
      {
        v19 = (RBX::Humanoid *)*((_QWORD *)this + 8);
        if ( v19 )
        {
          TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v19);
          if ( TorsoPrimitiveFast )
          {
            PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
            if ( PrimitiveAssembly )
            {
              v22 = RBX::Assembly::getPrimitiveAssembly(v18);
              if ( v18 )
              {
                if ( PrimitiveAssembly != v22 )
                  RBX::World::ticklePrimitive(*(RBX::World **)(*((_QWORD *)this + 8) + 2464LL), v18, 0);
              }
            }
          }
        }
      }
    }
  }
  v23 = v24.pn.pi_;
  if ( v24.pn.pi_ && !_InterlockedSub(&v24.pn.pi_->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *))v23->_vptr$sp_counted_base + 2))(v23);
    if ( !_InterlockedSub(&v23->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v23->_vptr$sp_counted_base + 3))(v23);
  }
}


// Address: 0x10de8b0 | Name: _ZN3RBX5HUMAN13HumanoidState14preStepCollideEv
void __fastcall RBX::HUMAN::HumanoidState::preStepCollide(RBX::HUMAN::HumanoidState *this)
{
  char v2; // al
  char v3; // al
  char v4; // bp
  RBX::PartInstance *HeadSlow; // rax
  char v6; // al

  v2 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 72LL))(this);
  RBX::HUMAN::HumanoidState::setLegsCanCollide(this, v2);
  v3 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 64LL))(this);
  RBX::HUMAN::HumanoidState::setArmsCanCollide(this, v3);
  v4 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 80LL))(this);
  HeadSlow = RBX::Humanoid::getHeadSlow(*((RBX::Humanoid **)this + 8));
  if ( HeadSlow )
    RBX::Primitive::setPreventCollide(HeadSlow->primitive.px, v4 != 1);
  v6 = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 88LL))(this);
  RBX::HUMAN::HumanoidState::setTorsoCanCollide(this, v6);
}


// Address: 0x10de930 | Name: _ZN3RBX5HUMAN13HumanoidState10doAutoJumpEv
void __fastcall RBX::HUMAN::HumanoidState::doAutoJump(RBX::HUMAN::HumanoidState *this)
{
  __int128 v1; // xmm0
  char *v3; // rdi
  RBX::PartInstance *v4; // rax
  const RBX::PartInstance *v5; // rbx
  RBX::PartInstance *HeadSlow; // rax
  const RBX::PartInstance *v7; // rbp
  const RBX::Workspace *ConstWorkspaceIfInWorkspaceNotWorldRoot; // rax
  RBX::Vector3 *v9; // r15
  __int64 v10; // rax
  const RBX::CoordinateFrame *v11; // rax
  RBX::Humanoid *v12; // rdi
  float v13; // xmm0_4
  int *v14; // r13
  float y; // xmm1_4
  __m128 v16; // xmm0
  __m128 v17; // xmm0
  __m128 v18; // xmm1
  __m128 v19; // xmm0
  __m128 v20; // xmm2
  __m128 v21; // xmm3
  RBX::WorldRoot **p_parent; // r14
  __m128 v23; // xmm1
  __m128 v24; // xmm1
  __m128 v25; // xmm2
  __m128 v26; // xmm2
  __m128 v27; // xmm0
  _BOOL8 v28; // rax
  __m128 v29; // xmm1
  __m128 v30; // xmm2
  RBX::WorldRoot *v31; // rsi
  __m128 v32; // xmm2
  bool v33; // al
  RBX::PartInstance *TorsoSlow; // rax
  RBX::PartInstance *v35; // rbp
  const RBX::CoordinateFrame *CoordinateFrame; // rbx
  RBX::Vector3 *WorkspaceNotWorldRoot; // rax
  RBX::Vector3 *v38; // r14
  __m128 v39; // xmm0
  __m128 v40; // xmm2
  float v41; // xmm4_4
  __m128 v42; // xmm1
  __m128 v43; // xmm2
  float v44; // xmm3_4
  RBX::WorldRoot *parent; // rsi
  __m128 v46; // xmm1
  RBX::WorldRoot *v47; // rsi
  volatile signed __int32 *v48; // rbx
  volatile signed __int32 *px; // rbx
  __m128 v50; // rt1
  float v51; // xmm1_4
  RBX::WorldRoot *v52; // rsi
  bool CanCollide; // al
  __m128 v54; // xmm4
  __m128 v55; // rt1
  float v56; // xmm1_4
  __m128 v57; // xmm5
  __m128 v58; // xmm1
  __m128 v59; // xmm5
  float v60; // xmm2_4
  __m128 v61; // xmm4
  __m128 v62; // xmm4
  __m128 v63; // xmm0
  __m128 v64; // xmm1
  float v65; // xmm0_4
  __m128 v66; // xmm2
  float v67; // xmm3_4
  RBX::WorldRoot *v68; // rsi
  float v69; // xmm2_4
  bool v70; // al
  unsigned int v71; // xmm0_4
  RBX::WorldRoot *v72; // rsi
  bool v73; // al
  int v74; // xmm0_4
  float v75; // xmm1_4
  RBX::RbxRay ray; // [rsp+0h] [rbp-228h]
  RBX::RbxRay raya; // [rsp+0h] [rbp-228h]
  bool v78; // [rsp+28h] [rbp-200h]
  bool v79; // [rsp+28h] [rbp-200h]
  int v80; // [rsp+34h] [rbp-1F4h]
  int v81; // [rsp+34h] [rbp-1F4h]
  float v82; // [rsp+38h] [rbp-1F0h]
  float z; // [rsp+3Ch] [rbp-1ECh]
  float v84; // [rsp+3Ch] [rbp-1ECh]
  char v85; // [rsp+40h] [rbp-1E8h]
  float v86; // [rsp+44h] [rbp-1E4h]
  float v87; // [rsp+48h] [rbp-1E0h]
  float v88; // [rsp+48h] [rbp-1E0h]
  float v89; // [rsp+4Ch] [rbp-1DCh]
  RBX::Instance ancestor; // [rsp+50h] [rbp-1D8h] BYREF
  _BYTE surfaceNormal[20]; // [rsp+DCh] [rbp-14Ch] BYREF
  __m128 v92; // [rsp+F0h] [rbp-138h]
  RBX::RbxRay v93; // [rsp+108h] [rbp-120h] BYREF
  __m128 v94; // [rsp+120h] [rbp-108h]
  __m128 v95; // [rsp+130h] [rbp-F8h]
  __m128 v96; // [rsp+140h] [rbp-E8h]
  __m128 v97; // [rsp+150h] [rbp-D8h]
  RBX::RbxRay v98; // [rsp+168h] [rbp-C0h] BYREF
  RBX::RbxRay v99; // [rsp+180h] [rbp-A8h] BYREF
  RBX::RbxRay v100; // [rsp+198h] [rbp-90h] BYREF
  RBX::RbxRay v101; // [rsp+1B0h] [rbp-78h] BYREF
  RBX::RbxRay v102; // [rsp+1C8h] [rbp-60h] BYREF
  __m128 v103; // [rsp+1E0h] [rbp-48h]
  G3D::Vector3 v104; // 0:kr14_12.12

  v3 = (char *)*((_QWORD *)this + 8);
  if ( !stru_2A08C78.value )
  {
    if ( v3 )
    {
      if ( v3[732] )
      {
        TorsoSlow = RBX::Humanoid::getTorsoSlow((RBX::Humanoid *)v3);
        if ( TorsoSlow )
        {
          v35 = TorsoSlow;
          CoordinateFrame = RBX::PartInstance::getCoordinateFrame(TorsoSlow);
          v104 = G3D::Matrix3::column(&CoordinateFrame->rotation, 2);
          *(float *)&v1 = v104.x;
          DWORD1(v1) = LODWORD(v104.y);
          *(_OWORD *)&ancestor.weak_this_.pn.pi_ = v1;
          *(float *)&ancestor.xmlId.px = v104.z;
          *(_OWORD *)&ancestor.children.object.pn.pi_ = LODWORD(CoordinateFrame->translation.x);
          *(_OWORD *)&ancestor.propertyChangedSignal.head.px = LODWORD(CoordinateFrame->translation.y);
          *(float *)&ancestor.onDemandPtr.px = CoordinateFrame->translation.z;
          WorkspaceNotWorldRoot = (RBX::Vector3 *)RBX::Workspace::findWorkspaceNotWorldRoot(*((RBX::Instance **)this + 8));
          if ( WorkspaceNotWorldRoot )
          {
            v38 = WorkspaceNotWorldRoot;
            *(_OWORD *)&ancestor._vptr$EventSource = 0;
            memset(&ancestor.guid, 0, 28);
            v39 = (__m128)0xBF000000;
            v92.m128_i32[0] = *(_DWORD *)(*((_QWORD *)v35->primitive.px + 18) + 12LL);
            v40 = *(__m128 *)&ancestor.children.object.pn.pi_;
            v40.m128_f32[0] = *(float *)&ancestor.children.object.pn.pi_ + 0.0;
            v39.m128_f32[0] = (float)(-0.5 * v92.m128_f32[0]) + *(float *)&ancestor.propertyChangedSignal.head.px;
            v41 = *(float *)&ancestor.onDemandPtr.px + 0.0;
            *(__m128 *)&ancestor.children.object.pn.pi_ = v40;
            v42 = v40;
            v43 = _mm_mul_ps(*(__m128 *)&ancestor.weak_this_.pn.pi_, (__m128)xmmword_3EA070);
            v44 = *(float *)&ancestor.xmlId.px * -1.5;
            parent = (RBX::WorldRoot *)v35->parent;
            _mm_storel_ps((double *)&v99.m_origin.x, _mm_unpacklo_ps(v42, v39));
            *(float *)&ancestor.onDemandPtr.px = v41;
            v99.m_origin.z = v41;
            *(__m128 *)&ancestor.weak_this_.pn.pi_ = v43;
            _mm_storel_ps((double *)&v99.m_direction.x, v43);
            *(float *)&ancestor.xmlId.px = v44;
            v99.m_direction.z = v44;
            RBX::WorldRoot::getHitLocationPartFilterDescendents<RBX::Instance>(
              WorkspaceNotWorldRoot,
              parent,
              &ancestor,
              v99,
              (boost::shared_ptr<RBX::PartInstance> *)&ancestor.name,
              (RBX::Vector3 *)surfaceNormal,
              0,
              0,
              0,
              v78);
            v46 = *(__m128 *)&ancestor.propertyChangedSignal.head.px;
            v46.m128_f32[0] = *(float *)&ancestor.propertyChangedSignal.head.px + (float)(7.0 - v92.m128_f32[0]);
            v47 = (RBX::WorldRoot *)v35->parent;
            _mm_storel_ps(
              (double *)&v98.m_origin.x,
              _mm_shuffle_ps(
                _mm_shuffle_ps(v46, *(__m128 *)&ancestor.children.object.pn.pi_, 0),
                *(__m128 *)&ancestor.children.object.pn.pi_,
                226));
            v98.m_origin.z = *(float *)&ancestor.onDemandPtr.px;
            _mm_storel_ps((double *)&v98.m_direction.x, *(__m128 *)&ancestor.weak_this_.pn.pi_);
            v98.m_direction.z = *(float *)&ancestor.xmlId.px;
            RBX::WorldRoot::getHitLocationPartFilterDescendents<RBX::Instance>(
              v38,
              v47,
              (RBX::Instance *)&ancestor.guid,
              v98,
              (boost::shared_ptr<RBX::PartInstance> *)&ancestor.name,
              (RBX::Vector3 *)surfaceNormal,
              0,
              0,
              0,
              v79);
            if ( ancestor._vptr$EventSource
              && !*(_QWORD *)&ancestor.guid
              && RBX::PartInstance::getCanCollide((const RBX::PartInstance *)ancestor._vptr$EventSource) )
            {
              RBX::Humanoid::setJump(*((RBX::Humanoid **)this + 8), 1);
            }
            v48 = *(volatile signed __int32 **)&ancestor.archivable;
            if ( *(_QWORD *)&ancestor.archivable )
            {
              if ( !_InterlockedSub((volatile signed __int32 *)(*(_QWORD *)&ancestor.archivable + 8LL), 1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v48 + 16LL))(v48);
                if ( !_InterlockedSub(v48 + 3, 1u) )
                  (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v48 + 24LL))(v48);
              }
            }
            px = (volatile signed __int32 *)ancestor.weak_this_.px;
            if ( ancestor.weak_this_.px )
            {
              if ( !_InterlockedSub(
                      (volatile signed __int32 *)&ancestor.weak_this_.px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
                      1u) )
              {
                (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)px + 16LL))(px);
                if ( !_InterlockedSub(px + 3, 1u) )
                  goto LABEL_68;
              }
            }
          }
        }
      }
    }
    return;
  }
  if ( !v3 )
    return;
  if ( v3[697] > 0 )
    return;
  if ( !v3[732] )
    return;
  v4 = RBX::Humanoid::getTorsoSlow((RBX::Humanoid *)v3);
  if ( !v4 )
    return;
  v5 = v4;
  HeadSlow = RBX::Humanoid::getHeadSlow(*((RBX::Humanoid **)this + 8));
  if ( !HeadSlow )
    return;
  v7 = HeadSlow;
  ConstWorkspaceIfInWorkspaceNotWorldRoot = RBX::Workspace::getConstWorkspaceIfInWorkspaceNotWorldRoot(*((const RBX::Instance **)this + 8));
  if ( !ConstWorkspaceIfInWorkspaceNotWorldRoot )
    return;
  v9 = (RBX::Vector3 *)ConstWorkspaceIfInWorkspaceNotWorldRoot;
  v10 = *((_QWORD *)this + 8);
  *(_OWORD *)&ancestor.children.object.pn.pi_ = *(unsigned __int64 *)(v10 + 552);
  LODWORD(ancestor.propertyChangedSignal.head.px) = *(_DWORD *)(v10 + 560);
  v11 = RBX::PartInstance::getCoordinateFrame(v5);
  *(_OWORD *)&ancestor.weak_this_.pn.pi_ = *(unsigned __int64 *)&v11->translation.x;
  z = v11->translation.z;
  v12 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  v89 = *(float *)(*((_QWORD *)v12 + 308) + 176LL);
  v13 = RBX::Humanoid::calculateJumpPower(v12);
  if ( v89 <= 0.0 || v13 <= 0.0 )
    return;
  v82 = v13;
  v14 = *(int **)(*((_QWORD *)this + 8) + 608LL);
  v80 = *v14;
  y = RBX::PartInstance::getCoordinateFrame(v7)->translation.y;
  v16 = _mm_shuffle_ps(*(__m128 *)&ancestor.weak_this_.pn.pi_, *(__m128 *)&ancestor.weak_this_.pn.pi_, 229);
  v92 = v16;
  *(float *)&ancestor.xmlId.px = y - v16.m128_f32[0];
  v16.m128_u64[0] = (unsigned __int64)RBX::PartInstance::getPartSizeUi(v7);
  v17 = _mm_shuffle_ps(v16, v16, 229);
  v17.m128_f32[0] = (float)((float)(v17.m128_f32[0] * 0.5) + *(float *)&ancestor.xmlId.px) + 0.2;
  v103 = v17;
  v17.m128_f32[0] = RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(this);
  v87 = v17.m128_f32[0];
  v18 = v17;
  v18.m128_f32[0] = v17.m128_f32[0] + v103.m128_f32[0];
  *(_OWORD *)&ancestor._vptr$EventSource = 0;
  ancestor.guid = 0;
  *(_DWORD *)&ancestor.archivable = 0;
  v19 = (__m128)*((unsigned int *)this + 8);
  v97.m128_f32[0] = v19.m128_f32[0] + 2.0;
  v94 = v18;
  if ( (float)(v19.m128_f32[0] + 2.0) <= v19.m128_f32[0] )
  {
    p_parent = (RBX::WorldRoot **)&v5->parent;
    v32 = *(__m128 *)&ancestor.weak_this_.pn.pi_;
LABEL_33:
    v50.m128_i32[0] = 1082130432;
    *((_DWORD *)this + 8) = _mm_cmplt_ss(v19, v50).m128_u32[0] & v19.m128_i32[0];
    v51 = (float)(1.5 * *(float *)&ancestor.propertyChangedSignal.head.px) + z;
    v52 = *p_parent;
    _mm_storel_ps(
      (double *)&v101.m_origin.x,
      _mm_add_ps(_mm_mul_ps((__m128)xmmword_3E8CB0, *(__m128 *)&ancestor.children.object.pn.pi_), v32));
    v101.m_origin.z = v51;
    *(_QWORD *)&v101.m_direction.x = 0xC0C0000000000000LL;
    v101.m_direction.z = 0.0;
    *(_QWORD *)&ray.m_direction.y = 3233808384LL;
    *(_OWORD *)&ray.m_origin.x = *(_OWORD *)&v101.m_origin.x;
    RBX::WorldRoot::getHitLocationPartFilterDescendents<RBX::Instance>(
      v9,
      v52,
      &ancestor,
      ray,
      (boost::shared_ptr<RBX::PartInstance> *)&ancestor.guid,
      (RBX::Vector3 *)&ancestor.name,
      0,
      1,
      0,
      v78);
    if ( ancestor._vptr$EventSource )
    {
      CanCollide = RBX::PartInstance::getCanCollide((const RBX::PartInstance *)ancestor._vptr$EventSource);
      v54 = (__m128)LODWORD(v82);
      if ( CanCollide )
        goto LABEL_65;
      v85 = 0;
      v32 = *(__m128 *)&ancestor.weak_this_.pn.pi_;
    }
    else
    {
      v85 = 0;
      v32 = *(__m128 *)&ancestor.weak_this_.pn.pi_;
      v54 = (__m128)LODWORD(v82);
    }
  }
  else
  {
    *(_QWORD *)&surfaceNormal[4] = v14;
    v20 = (__m128)0xBFC00000;
    v20.m128_f32[0] = v18.m128_f32[0] + -1.5;
    v21 = *(__m128 *)&ancestor.weak_this_.pn.pi_;
    v21.m128_f32[0] = *(float *)&ancestor.weak_this_.pn.pi_ + 0.0;
    v95 = v21;
    p_parent = (RBX::WorldRoot **)&v5->parent;
    v96 = _mm_shuffle_ps(v20, v20, 224);
    while ( 1 )
    {
      v23 = v19;
      v23.m128_f32[0] = v19.m128_f32[0] + 1.0;
      v24 = _mm_unpacklo_ps(v23, v19);
      v25 = (__m128)_mm_srai_epi32(
                      _mm_slli_epi32(
                        _mm_insert_epi16(
                          _mm_cvtsi32_si128((float)(v19.m128_f32[0] + 1.0) <= 4.0),
                          v19.m128_f32[0] < 4.0,
                          2),
                        0x1Fu),
                      0x1Fu);
      v26 = _mm_add_ps(
              _mm_mul_ps(
                _mm_mul_ps(
                  _mm_or_ps(_mm_andnot_ps(v25, _mm_add_ps(v24, (__m128)xmmword_3E6560)), _mm_and_ps(v24, v25)),
                  (__m128)xmmword_3E8550),
                v96),
              (__m128)xmmword_3E8CB0);
      *(__m128 *)&ancestor.xmlId.px = _mm_shuffle_ps(v26, v26, 229);
      v26.m128_f32[0] = v26.m128_f32[0] - *(float *)&ancestor.xmlId.px;
      *(__m128 *)&ancestor.onDemandPtr.px = v26;
      v27 = 0;
      v27.m128_f32[0] = (float)((float)((float)rand() * v26.m128_f32[0]) * 4.6566129e-10) + *(float *)&ancestor.xmlId.px;
      v28 = v27.m128_f32[0] < 2.5;
      v27.m128_f32[0] = (float)(v27.m128_f32[0] - v87) + v92.m128_f32[0];
      v29 = (__m128)*((unsigned int *)&unk_490128 + v28);
      v30 = _mm_mul_ps(_mm_shuffle_ps(v29, v29, 224), *(__m128 *)&ancestor.children.object.pn.pi_);
      v29.m128_f32[0] = v29.m128_f32[0] * *(float *)&ancestor.propertyChangedSignal.head.px;
      v31 = *p_parent;
      _mm_storel_ps((double *)&v102.m_origin.x, _mm_shuffle_ps(_mm_shuffle_ps(v27, v95, 0), v95, 226));
      v102.m_origin.z = z + 0.0;
      _mm_storel_ps((double *)&v102.m_direction.x, v30);
      LODWORD(v102.m_direction.z) = v29.m128_i32[0];
      RBX::WorldRoot::getHitLocationPartFilterDescendents<RBX::Instance>(
        v9,
        v31,
        &ancestor,
        v102,
        (boost::shared_ptr<RBX::PartInstance> *)&ancestor.guid,
        (RBX::Vector3 *)&ancestor.name,
        0,
        1,
        0,
        v78);
      v32 = *(__m128 *)&ancestor.weak_this_.pn.pi_;
      if ( ancestor._vptr$EventSource )
      {
        v33 = RBX::PartInstance::getCanCollide((const RBX::PartInstance *)ancestor._vptr$EventSource);
        v32 = *(__m128 *)&ancestor.weak_this_.pn.pi_;
        if ( v33 )
          break;
      }
      v19 = (__m128)*((unsigned int *)this + 8);
      v19.m128_f32[0] = v19.m128_f32[0] + 1.0;
      *((_DWORD *)this + 8) = v19.m128_i32[0];
      if ( v97.m128_f32[0] <= v19.m128_f32[0] )
      {
        LODWORD(v14) = *(_DWORD *)&surfaceNormal[4];
        goto LABEL_33;
      }
    }
    v55.m128_i32[0] = 1082130432;
    *((_DWORD *)this + 8) &= _mm_cmplt_ss((__m128)*((unsigned int *)this + 8), v55).m128_u32[0];
    v85 = 1;
    v54 = (__m128)LODWORD(v82);
    LODWORD(v14) = *(_DWORD *)&surfaceNormal[4];
  }
  v56 = _mm_shuffle_ps(*(__m128 *)&ancestor.children.object.pn.pi_, *(__m128 *)&ancestor.children.object.pn.pi_, 229).m128_f32[0];
  v96.m128_f32[0] = (float)(v54.m128_f32[0] + v54.m128_f32[0]) / v89;
  v86 = (float)((float)(COERCE_FLOAT(v80 - (_DWORD)v14)
                      * fsqrt(
                          (float)(*(float *)&ancestor.propertyChangedSignal.head.px
                                * *(float *)&ancestor.propertyChangedSignal.head.px)
                        + (float)((float)(v56 * v56)
                                + (float)(*(float *)&ancestor.children.object.pn.pi_
                                        * *(float *)&ancestor.children.object.pn.pi_))))
              * v96.m128_f32[0])
      * 0.94999999;
  v95.m128_f32[0] = v86 + 1.0;
  if ( (float)(v86 + 1.0) <= 0.0 )
  {
    v59.m128_i32[0] = -1082130432;
    v75 = -1.0;
    if ( !v85 )
      goto LABEL_65;
    goto LABEL_59;
  }
  v57 = v54;
  v57.m128_f32[0] = (float)(v54.m128_f32[0] * v54.m128_f32[0]) / (float)(v89 + v89);
  v32.m128_f32[0] = v32.m128_f32[0] + 0.0;
  *(__m128 *)&ancestor.weak_this_.pn.pi_ = v32;
  v84 = z + 0.0;
  v58 = v94;
  v58.m128_f32[0] = v94.m128_f32[0] + 1.0;
  *(__m128 *)&surfaceNormal[4] = _mm_xor_ps(v57, *(__m128 *)&stru_3E4970.x);
  v94 = _mm_shuffle_ps(_mm_shuffle_ps(v58, (__m128)0LL, 0), (__m128)0LL, 226);
  *(float *)&v81 = -1.0;
  v59 = 0;
  while ( 1 )
  {
    *(__m128 *)&ancestor.xmlId.px = v59;
    v60 = (float)((float)((float)(v89 * (float)((float)(v96.m128_f32[0] * v59.m128_f32[0]) / v86))
                        * (float)((float)(v96.m128_f32[0] * v59.m128_f32[0]) / v86))
                * -0.5)
        + (float)(v54.m128_f32[0] * (float)((float)(v96.m128_f32[0] * v59.m128_f32[0]) / v86));
    v61 = v103;
    v88 = v60;
    v61.m128_f32[0] = (float)(v103.m128_f32[0] + v60) + v92.m128_f32[0];
    v62 = _mm_add_ps(
            _mm_shuffle_ps(
              _mm_shuffle_ps(v61, *(__m128 *)&ancestor.weak_this_.pn.pi_, 0),
              *(__m128 *)&ancestor.weak_this_.pn.pi_,
              226),
            _mm_mul_ps(_mm_shuffle_ps(v59, v59, 224), *(__m128 *)&ancestor.children.object.pn.pi_));
    v63 = (__m128)*((unsigned int *)&unk_490530 + (_mm_cvtsi128_si32((__m128i)_mm_cmpeq_ss(v59, (__m128)0LL)) & 1));
    v64 = _mm_add_ps(_mm_mul_ps(_mm_shuffle_ps(v63, v63, 224), *(__m128 *)&ancestor.children.object.pn.pi_), v94);
    v65 = (float)(v63.m128_f32[0] * *(float *)&ancestor.propertyChangedSignal.head.px) + 0.0;
    *(float *)&ancestor.onDemandPtr.px = (float)(*(float *)&ancestor.propertyChangedSignal.head.px * v59.m128_f32[0])
                                       + v84;
    v97 = v62;
    v66 = v62;
    if ( ((int)v59.m128_f32[0] & 3) != 0 )
    {
      v66 = _mm_add_ps(v62, v64);
      v67 = (float)((float)(*(float *)&ancestor.propertyChangedSignal.head.px * v59.m128_f32[0]) + v84) + v65;
      v64 = _mm_xor_ps(v64, *(__m128 *)&stru_3E4970.x);
      v65 = -v65;
    }
    else
    {
      v67 = (float)(*(float *)&ancestor.propertyChangedSignal.head.px * v59.m128_f32[0]) + v84;
    }
    v68 = (RBX::WorldRoot *)v5->parent;
    _mm_storel_ps((double *)&v100.m_origin.x, v66);
    v100.m_origin.z = v67;
    _mm_storel_ps((double *)&v100.m_direction.x, v64);
    v100.m_direction.z = v65;
    RBX::WorldRoot::getHitLocationPartFilterDescendents<RBX::Instance>(
      v9,
      v68,
      &ancestor,
      v100,
      (boost::shared_ptr<RBX::PartInstance> *)&ancestor.guid,
      (RBX::Vector3 *)&ancestor.name,
      0,
      1,
      0,
      v78);
    v54.m128_f32[0] = v82;
    v59 = *(__m128 *)&ancestor.xmlId.px;
    v69 = *(float *)&ancestor.onDemandPtr.px;
    if ( ancestor._vptr$EventSource )
    {
      v70 = RBX::PartInstance::getCanCollide((const RBX::PartInstance *)ancestor._vptr$EventSource);
      v54.m128_f32[0] = v82;
      v59 = *(__m128 *)&ancestor.xmlId.px;
      v69 = *(float *)&ancestor.onDemandPtr.px;
      if ( v70 )
        break;
    }
    if ( v59.m128_f32[0] > 0.5 )
    {
      *(float *)&v71 = (float)(*(float *)&surfaceNormal[4] - v88) + -6.0;
      v72 = (RBX::WorldRoot *)v5->parent;
      _mm_storel_ps((double *)&v93.m_origin.x, v97);
      v93.m_origin.z = v69;
      v93.m_direction.x = 0.0;
      *(_QWORD *)&v93.m_direction.y = v71;
      *(_QWORD *)&raya.m_direction.y = v71;
      *(_OWORD *)&raya.m_origin.x = *(_OWORD *)&v93.m_origin.x;
      RBX::WorldRoot::getHitLocationPartFilterDescendents<RBX::Instance>(
        v9,
        v72,
        &ancestor,
        raya,
        (boost::shared_ptr<RBX::PartInstance> *)&ancestor.guid,
        (RBX::Vector3 *)&ancestor.name,
        0,
        1,
        0,
        v78);
      if ( ancestor._vptr$EventSource )
      {
        v73 = RBX::PartInstance::getCanCollide((const RBX::PartInstance *)ancestor._vptr$EventSource);
        v59 = *(__m128 *)&ancestor.xmlId.px;
        v74 = (int)ancestor.xmlId.px;
        if ( !v73 )
          v74 = v81;
        v54.m128_f32[0] = v82;
        if ( v85 )
        {
          v81 = v74;
        }
        else
        {
          v81 = v74;
          if ( v73 )
            goto LABEL_64;
        }
      }
      else
      {
        v54.m128_f32[0] = v82;
        v59 = *(__m128 *)&ancestor.xmlId.px;
      }
    }
    v59.m128_f32[0] = v59.m128_f32[0] + 2.0;
    if ( v95.m128_f32[0] <= v59.m128_f32[0] )
    {
      v59.m128_i32[0] = -1082130432;
      break;
    }
  }
  v75 = *(float *)&v81;
  if ( v85 )
  {
LABEL_59:
    if ( v59.m128_f32[0] < 0.0 && v75 > 4.5
      || v59.m128_f32[0] > 0.0 && v75 > 0.0 && (float)(v59.m128_f32[0] - v75) < 2.5 )
    {
LABEL_64:
      RBX::Humanoid::setJump(*((RBX::Humanoid **)this + 8), 1);
    }
  }
LABEL_65:
  px = (volatile signed __int32 *)ancestor.weak_this_.px;
  if ( ancestor.weak_this_.px )
  {
    if ( !_InterlockedSub(
            (volatile signed __int32 *)&ancestor.weak_this_.px->boost::enable_shared_from_this<RBX::Reflection::DescribedBase>,
            1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)px + 16LL))(px);
      if ( !_InterlockedSub(px + 3, 1u) )
LABEL_68:
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)px + 24LL))(px);
    }
  }
}


// Address: 0x10df690 | Name: _ZN3RBX5HUMAN13HumanoidState17setLegsCanCollideEb
void __fastcall RBX::HUMAN::HumanoidState::setLegsCanCollide(RBX::HUMAN::HumanoidState *this, bool canCollide)
{
  __int64 v3; // rdi
  bool v4; // bp
  RBX::PartInstance *R15PartFast; // rax
  RBX::PartInstance *v6; // rax
  RBX::PartInstance *v7; // rax
  RBX::PartInstance *v8; // rax
  RBX::PartInstance *v9; // rax
  RBX::PartInstance *v10; // rax
  RBX::PartInstance *LeftLegSlow; // rax
  RBX::PartInstance *RightLegSlow; // rax

  v3 = *((_QWORD *)this + 8);
  if ( *(_DWORD *)(v3 + 708) )
  {
    if ( *(_QWORD *)(v3 + 88) )
    {
      v4 = !canCollide;
      R15PartFast = RBX::Humanoid::getR15PartFast((RBX::Humanoid *)v3, RBX::Humanoid::R15PartType::R15_RIGHT_UPPER_LEG);
      if ( R15PartFast )
        RBX::Primitive::setPreventCollide(R15PartFast->primitive.px, v4);
      v6 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_RIGHT_LOWER_LEG);
      if ( v6 )
        RBX::Primitive::setPreventCollide(v6->primitive.px, v4);
      v7 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_RIGHT_FOOT);
      if ( v7 )
        RBX::Primitive::setPreventCollide(v7->primitive.px, v4);
      v8 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_LEFT_UPPER_LEG);
      if ( v8 )
        RBX::Primitive::setPreventCollide(v8->primitive.px, v4);
      v9 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_LEFT_LOWER_LEG);
      if ( v9 )
        RBX::Primitive::setPreventCollide(v9->primitive.px, v4);
      v10 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_LEFT_FOOT);
      if ( v10 )
        RBX::Primitive::setPreventCollide(v10->primitive.px, v4);
    }
  }
  else
  {
    LeftLegSlow = RBX::Humanoid::getLeftLegSlow((RBX::Humanoid *)v3);
    if ( LeftLegSlow )
      RBX::Primitive::setPreventCollide(LeftLegSlow->primitive.px, !canCollide);
    RightLegSlow = RBX::Humanoid::getRightLegSlow(*((RBX::Humanoid **)this + 8));
    if ( RightLegSlow )
      RBX::Primitive::setPreventCollide(RightLegSlow->primitive.px, !canCollide);
  }
}


// Address: 0x10df7e0 | Name: _ZN3RBX5HUMAN13HumanoidState17setArmsCanCollideEb
void __fastcall RBX::HUMAN::HumanoidState::setArmsCanCollide(RBX::HUMAN::HumanoidState *this, bool canCollide)
{
  __int64 v3; // rdi
  bool v4; // bp
  RBX::PartInstance *R15PartFast; // rax
  RBX::PartInstance *v6; // rax
  RBX::PartInstance *v7; // rax
  RBX::PartInstance *v8; // rax
  RBX::PartInstance *v9; // rax
  RBX::PartInstance *v10; // rax
  RBX::PartInstance *LeftArmSlow; // rax
  RBX::PartInstance *RightArmSlow; // rax

  v3 = *((_QWORD *)this + 8);
  if ( *(_DWORD *)(v3 + 708) )
  {
    if ( *(_QWORD *)(v3 + 88) )
    {
      v4 = !canCollide;
      R15PartFast = RBX::Humanoid::getR15PartFast((RBX::Humanoid *)v3, RBX::Humanoid::R15PartType::R15_RIGHT_UPPER_ARM);
      if ( R15PartFast )
        RBX::Primitive::setPreventCollide(R15PartFast->primitive.px, v4);
      v6 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_RIGHT_LOWER_ARM);
      if ( v6 )
        RBX::Primitive::setPreventCollide(v6->primitive.px, v4);
      v7 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_RIGHT_HAND);
      if ( v7 )
        RBX::Primitive::setPreventCollide(v7->primitive.px, v4);
      v8 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_LEFT_UPPER_ARM);
      if ( v8 )
        RBX::Primitive::setPreventCollide(v8->primitive.px, v4);
      v9 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_LEFT_LOWER_ARM);
      if ( v9 )
        RBX::Primitive::setPreventCollide(v9->primitive.px, v4);
      v10 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_LEFT_HAND);
      if ( v10 )
        RBX::Primitive::setPreventCollide(v10->primitive.px, v4);
    }
  }
  else
  {
    LeftArmSlow = RBX::Humanoid::getLeftArmSlow((RBX::Humanoid *)v3);
    if ( LeftArmSlow )
      RBX::Primitive::setPreventCollide(LeftArmSlow->primitive.px, !canCollide);
    RightArmSlow = RBX::Humanoid::getRightArmSlow(*((RBX::Humanoid **)this + 8));
    if ( RightArmSlow )
      RBX::Primitive::setPreventCollide(RightArmSlow->primitive.px, !canCollide);
  }
}


// Address: 0x10df930 | Name: _ZN3RBX5HUMAN13HumanoidState17setHeadCanCollideEb
void __fastcall RBX::HUMAN::HumanoidState::setHeadCanCollide(RBX::HUMAN::HumanoidState *this, bool canCollide)
{
  RBX::PartInstance *HeadSlow; // rax

  HeadSlow = RBX::Humanoid::getHeadSlow(*((RBX::Humanoid **)this + 8));
  if ( HeadSlow )
    RBX::Primitive::setPreventCollide(HeadSlow->primitive.px, !canCollide);
}


// Address: 0x10df960 | Name: _ZN3RBX5HUMAN13HumanoidState18setTorsoCanCollideEb
void __fastcall RBX::HUMAN::HumanoidState::setTorsoCanCollide(RBX::HUMAN::HumanoidState *this, bool canCollide)
{
  RBX::Humanoid *v3; // rdi
  RBX::PartInstance *R15PartFast; // rbx
  RBX::PartInstance *v5; // r14
  RBX::Primitive *px; // rdi
  RBX::PartInstance *VisibleTorsoSlow; // rax

  v3 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( !*((_DWORD *)v3 + 177) )
  {
    VisibleTorsoSlow = RBX::Humanoid::getVisibleTorsoSlow(v3);
    if ( !VisibleTorsoSlow )
      return;
    px = VisibleTorsoSlow->primitive.px;
    goto LABEL_8;
  }
  R15PartFast = RBX::Humanoid::getR15PartFast(v3, RBX::Humanoid::R15PartType::R15_LOWER_TORSO);
  v5 = RBX::Humanoid::getR15PartFast(*((RBX::Humanoid **)this + 8), RBX::Humanoid::R15PartType::R15_UPPER_TORSO);
  if ( R15PartFast )
    RBX::Primitive::setPreventCollide(R15PartFast->primitive.px, !canCollide);
  if ( v5 )
  {
    px = v5->primitive.px;
LABEL_8:
    RBX::Primitive::setPreventCollide(px, !canCollide);
  }
}


// Address: 0x10dfa00 | Name: _ZN3RBX5HUMAN13HumanoidState9findFloorERN5boost10shared_ptrINS_12PartInstanceEEERKN3G3D7Vector3E
void __fastcall RBX::HUMAN::HumanoidState::findFloor(
        RBX::HUMAN::HumanoidState *this,
        boost::shared_ptr<RBX::PartInstance> *oldFloor,
        const RBX::Vector3 *oldFloorNormal)
{
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Primitive *v6; // rbp
  RBX::CoordinateFrame *CoordinateFrame; // rax
  __int64 v8; // rcx
  __m128 v9; // xmm0
  __m128 v10; // xmm2
  __m128 v11; // xmm1
  __m128i v12; // xmm0
  __int64 v13; // rcx
  bool v14; // zf
  __m128i v15; // xmm1
  _BOOL8 v16; // rbx
  float v17; // xmm0_4
  RBX::Humanoid *v18; // rdi
  int v19; // eax
  float v20; // xmm1_4
  float v21; // xmm3_4
  float v22; // xmm0_4
  __m128 v23; // xmm0
  RBX::PartInstance *LeftLegSlow; // rax
  __m128i v25; // xmm1
  RBX::Assembly *PrimitiveAssembly; // rax
  float v27; // xmm4_4
  __m128 v28; // xmm3
  boost::shared_ptr<RBX::PartInstance> *v29; // r15
  RBX::Vector3 *v30; // r12
  RBX::PartMaterial *v31; // r14
  RBX::CoordinateFrame *v32; // r13
  RBX::Assembly *v33; // rbp
  RBX::Vector3 *v34; // rdx
  RBX::HUMAN::HumanoidState *v35; // rbx
  const RBX::CoordinateFrame *v36; // r12
  __m128 v37; // xmm3
  float v38; // xmm2_4
  RBX::HUMAN::HumanoidState *v39; // rdi
  boost::shared_ptr<RBX::PartInstance> *v40; // rbx
  RBX::Vector3 *v41; // r13
  RBX::PartMaterial *v42; // r14
  boost::shared_ptr<RBX::PartInstance> *v43; // rsi
  int v44; // eax
  __m128 v45; // xmm1
  __m128 v46; // xmm1
  __m128 v47; // xmm2
  __m128i v48; // xmm3
  __m128 v49; // xmm1
  RBX::Vector3 floorPartHitNormal; // [rsp+0h] [rbp-118h] BYREF
  float v51; // [rsp+Ch] [rbp-10Ch]
  RBX::Vector3 offset; // [rsp+10h] [rbp-108h] BYREF
  int hitLocationCount; // [rsp+1Ch] [rbp-FCh] BYREF
  __m128i v54; // [rsp+20h] [rbp-F8h]
  RBX::HUMAN::HumanoidState *v55; // [rsp+38h] [rbp-E0h]
  RBX::Vector3 hitLocationAccumulator; // [rsp+40h] [rbp-D8h] BYREF
  __m128 v57; // [rsp+50h] [rbp-C8h]
  __m128 v58; // [rsp+60h] [rbp-B8h]
  boost::shared_ptr<RBX::PartInstance> *floorPart[2]; // [rsp+70h] [rbp-A8h]
  __m128 v60; // [rsp+80h] [rbp-98h]
  __m128 v61; // [rsp+90h] [rbp-88h]
  RBX::Vector3 *floorPartHitLocation; // [rsp+A8h] [rbp-70h]
  RBX::PartMaterial *floorPartHitMaterial; // [rsp+B0h] [rbp-68h]
  RBX::CoordinateFrame *v64; // [rsp+B8h] [rbp-60h]
  __m128 v65; // [rsp+C0h] [rbp-58h]
  __m128 v66; // [rsp+D0h] [rbp-48h]

  TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
  if ( TorsoPrimitiveSlow )
  {
    v6 = TorsoPrimitiveSlow;
    CoordinateFrame = (RBX::CoordinateFrame *)RBX::Primitive::getCoordinateFrame(TorsoPrimitiveSlow);
    v8 = *((_QWORD *)v6 + 18);
    v9 = (__m128)*(unsigned __int64 *)(v8 + 8);
    v10 = _mm_mul_ps((__m128)xmmword_3E7CB0, v9);
    v11 = (__m128)*(unsigned int *)(v8 + 16);
    v12 = _mm_shuffle_epi32((__m128i)v9, 229);
    v13 = *((_QWORD *)this + 8);
    v14 = *(_DWORD *)(v13 + 708) == 1;
    v64 = CoordinateFrame;
    v57 = v11;
    if ( v14 && **(_BYTE **)(v13 + 720) == (unsigned __int8)*(_QWORD *)(v13 + 720) )
    {
      v48 = v12;
      v49 = (__m128)0xBE800000;
      v49.m128_f32[0] = -0.25 * *(float *)v12.m128i_i32;
      *(float *)v48.m128i_i32 = (float)(*(float *)v12.m128i_i32 * 0.5) - (float)(-0.25 * *(float *)v12.m128i_i32);
      v54 = v48;
      v61 = _mm_shuffle_ps(_mm_shuffle_ps(v49, v10, 0), v10, 226);
    }
    else
    {
      v61 = v10;
      v15 = (__m128i)0x3DCCCCCDu;
      *(float *)v15.m128i_i32 = 0.1 * *(float *)v12.m128i_i32;
      v54 = v15;
    }
    v16 = oldFloor->px == 0;
    RBX::Body::updatePV((RBX::Body *)((char *)v6 + 152));
    v17 = fabs(*((float *)v6 + 103));
    v18 = (RBX::Humanoid *)*((_QWORD *)this + 8);
    v19 = *((_DWORD *)v18 + 177);
    if ( v19 == 1 )
      v20 = (float)(*(float *)(*((_QWORD *)v6 + 18) + 12LL) * -0.5) + *((float *)this + 6);
    else
      v20 = *(float *)(*((_QWORD *)v6 + 18) + 12LL);
    v21 = flt_490488[v16];
    v22 = v17 / (float)(v20 * 0.5);
    if ( v22 > (float)dword_28594A0 )
      v21 = v21 + (float)(v22 / (float)dword_28594A0);
    v23 = v57;
    if ( !v19 )
    {
      v51 = v21;
      LeftLegSlow = RBX::Humanoid::getLeftLegSlow(v18);
      if ( LeftLegSlow || (LeftLegSlow = RBX::Humanoid::getRightLegSlow(*((RBX::Humanoid **)this + 8))) != 0 )
      {
        v21 = v51;
        v25 = v54;
        *(float *)v25.m128i_i32 = *(float *)v54.m128i_i32
                                + (float)(*(float *)(*((_QWORD *)LeftLegSlow->primitive.px + 18) + 12LL) * v51);
        v54 = v25;
        v23 = v57;
      }
      else
      {
        v23 = v57;
        v21 = v51;
      }
    }
    v23.m128_f32[0] = v23.m128_f32[0] * 0.40000001;
    v57 = v23;
    v51 = (float)(v21
                * COERCE_FLOAT(*(_QWORD *)(*((_QWORD *)this + 8) + 688LL) + **(_DWORD **)(*((_QWORD *)this + 8) + 688LL)))
        + *(float *)v54.m128i_i32;
    PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(v6);
    *(_QWORD *)&hitLocationAccumulator.x = 0;
    hitLocationAccumulator.z = 0.0;
    hitLocationCount = 0;
    v27 = 1.0;
    if ( oldFloor->px )
      v27 = (float)(0.0 * oldFloorNormal->z) + (float)((float)(oldFloorNormal->x * 0.0) + oldFloorNormal->y);
    v28 = _mm_shuffle_ps(v61, v61, 229);
    v51 = v51
        + (float)((float)((float)((float)dword_28594D8 * *((float *)this + 6)) * 0.0099999998)
                + fabs((float)(1.0 - v27) * v28.m128_f32[0]));
    v28.m128_f32[0] = v28.m128_f32[0] * v27;
    v60 = _mm_xor_ps(v28, *(__m128 *)&stru_3E4970.x);
    v29 = (boost::shared_ptr<RBX::PartInstance> *)((char *)this + 112);
    v30 = (RBX::Vector3 *)((char *)this + 132);
    v55 = this;
    v31 = (RBX::PartMaterial *)((char *)this + 128);
    v54.m128i_i32[0] = 0;
    offset.x = 0.0;
    LODWORD(offset.y) = v60.m128_i32[0];
    offset.z = v57.m128_f32[0] * 0.0;
    *(_QWORD *)&floorPartHitNormal.x = 0;
    floorPartHitNormal.z = 0.0;
    v32 = v64;
    v33 = PrimitiveAssembly;
    RBX::HUMAN::HumanoidState::AverageFloorRayCast(
      v55,
      v29,
      v30,
      &floorPartHitNormal,
      v31,
      &hitLocationAccumulator,
      &hitLocationCount,
      1,
      &offset,
      v51,
      PrimitiveAssembly,
      v64);
    *(__m128 *)floorPart = _mm_add_ps((__m128)0LL, (__m128)*(unsigned __int64 *)&floorPartHitNormal.x);
    *(float *)v54.m128i_i32 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
    offset.x = 0.0;
    LODWORD(offset.y) = v60.m128_i32[0];
    LODWORD(offset.z) = v57.m128_i32[0];
    *(_QWORD *)&floorPartHitNormal.x = 0;
    floorPartHitNormal.z = 0.0;
    RBX::HUMAN::HumanoidState::AverageFloorRayCast(
      v55,
      v29,
      v30,
      &floorPartHitNormal,
      v31,
      &hitLocationAccumulator,
      &hitLocationCount,
      1,
      &offset,
      v51,
      v33,
      v32);
    *(__m128 *)floorPart = _mm_add_ps((__m128)*(unsigned __int64 *)&floorPartHitNormal.x, *(__m128 *)floorPart);
    *(float *)v54.m128i_i32 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
    offset.x = 0.0;
    LODWORD(offset.y) = v60.m128_i32[0];
    v65 = _mm_xor_ps(v57, *(__m128 *)&stru_3E4970.x);
    LODWORD(offset.z) = v65.m128_i32[0];
    *(_QWORD *)&floorPartHitNormal.x = 0;
    floorPartHitNormal.z = 0.0;
    RBX::HUMAN::HumanoidState::AverageFloorRayCast(
      v55,
      v29,
      v30,
      &floorPartHitNormal,
      v31,
      &hitLocationAccumulator,
      &hitLocationCount,
      1,
      &offset,
      v51,
      v33,
      v32);
    *(__m128 *)floorPart = _mm_add_ps((__m128)*(unsigned __int64 *)&floorPartHitNormal.x, *(__m128 *)floorPart);
    *(float *)v54.m128i_i32 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
    offset.x = 0.0;
    LODWORD(offset.y) = v60.m128_i32[0];
    offset.z = v57.m128_f32[0] + v57.m128_f32[0];
    *(_QWORD *)&floorPartHitNormal.x = 0;
    floorPartHitNormal.z = 0.0;
    RBX::HUMAN::HumanoidState::AverageFloorRayCast(
      v55,
      v29,
      v30,
      &floorPartHitNormal,
      v31,
      &hitLocationAccumulator,
      &hitLocationCount,
      0,
      &offset,
      v51,
      v33,
      v32);
    *(float *)v54.m128i_i32 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
    v58 = _mm_add_ps((__m128)*(unsigned __int64 *)&floorPartHitNormal.x, *(__m128 *)floorPart);
    offset.x = 0.0;
    LODWORD(offset.y) = v60.m128_i32[0];
    offset.z = -2.0 * v57.m128_f32[0];
    *(_QWORD *)&floorPartHitNormal.x = 0;
    floorPartHitNormal.z = 0.0;
    floorPart[0] = v29;
    floorPartHitLocation = v30;
    v34 = v30;
    floorPartHitMaterial = v31;
    v35 = v55;
    v36 = v32;
    RBX::HUMAN::HumanoidState::AverageFloorRayCast(
      v55,
      v29,
      v34,
      &floorPartHitNormal,
      v31,
      &hitLocationAccumulator,
      &hitLocationCount,
      0,
      &offset,
      v51,
      v33,
      v32);
    v37 = _mm_add_ps((__m128)*(unsigned __int64 *)&floorPartHitNormal.x, v58);
    v38 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
    if ( !*((_QWORD *)v35 + 14) )
    {
      v66 = _mm_xor_ps(*(__m128 *)&stru_3E4970.x, v61);
      LODWORD(offset.x) = v66.m128_i32[0];
      LODWORD(offset.y) = v60.m128_i32[0];
      LODWORD(offset.z) = v65.m128_i32[0];
      *(_QWORD *)&floorPartHitNormal.x = 0;
      floorPartHitNormal.z = 0.0;
      v39 = v35;
      v40 = floorPart[0];
      v41 = floorPartHitLocation;
      v42 = floorPartHitMaterial;
      *(float *)v54.m128i_i32 = v38;
      v58 = v37;
      RBX::HUMAN::HumanoidState::AverageFloorRayCast(
        v39,
        floorPart[0],
        floorPartHitLocation,
        &floorPartHitNormal,
        floorPartHitMaterial,
        &hitLocationAccumulator,
        &hitLocationCount,
        1,
        &offset,
        v51,
        v33,
        v36);
      v58 = _mm_add_ps(v58, (__m128)*(unsigned __int64 *)&floorPartHitNormal.x);
      *(float *)v54.m128i_i32 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
      LODWORD(offset.x) = v66.m128_i32[0];
      LODWORD(offset.y) = v60.m128_i32[0];
      LODWORD(offset.z) = v57.m128_i32[0];
      *(_QWORD *)&floorPartHitNormal.x = 0;
      floorPartHitNormal.z = 0.0;
      RBX::HUMAN::HumanoidState::AverageFloorRayCast(
        v55,
        v40,
        v41,
        &floorPartHitNormal,
        v42,
        &hitLocationAccumulator,
        &hitLocationCount,
        1,
        &offset,
        v51,
        v33,
        v36);
      v58 = _mm_add_ps((__m128)*(unsigned __int64 *)&floorPartHitNormal.x, v58);
      *(float *)v54.m128i_i32 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
      LODWORD(offset.x) = v61.m128_i32[0];
      LODWORD(offset.y) = v60.m128_i32[0];
      LODWORD(offset.z) = v65.m128_i32[0];
      *(_QWORD *)&floorPartHitNormal.x = 0;
      floorPartHitNormal.z = 0.0;
      RBX::HUMAN::HumanoidState::AverageFloorRayCast(
        v55,
        v40,
        v41,
        &floorPartHitNormal,
        v42,
        &hitLocationAccumulator,
        &hitLocationCount,
        1,
        &offset,
        v51,
        v33,
        v36);
      v58 = _mm_add_ps((__m128)*(unsigned __int64 *)&floorPartHitNormal.x, v58);
      *(float *)v54.m128i_i32 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
      LODWORD(offset.x) = v61.m128_i32[0];
      LODWORD(offset.y) = v60.m128_i32[0];
      LODWORD(offset.z) = v57.m128_i32[0];
      *(_QWORD *)&floorPartHitNormal.x = 0;
      floorPartHitNormal.z = 0.0;
      v43 = v40;
      v35 = v55;
      RBX::HUMAN::HumanoidState::AverageFloorRayCast(
        v55,
        v43,
        v41,
        &floorPartHitNormal,
        v42,
        &hitLocationAccumulator,
        &hitLocationCount,
        1,
        &offset,
        v51,
        v33,
        v36);
      v37 = _mm_add_ps((__m128)*(unsigned __int64 *)&floorPartHitNormal.x, v58);
      v38 = *(float *)v54.m128i_i32 + floorPartHitNormal.z;
    }
    v44 = hitLocationCount;
    if ( hitLocationCount )
    {
      v45 = (__m128)0x3F800000u;
      v45.m128_f32[0] = 1.0 / (float)hitLocationCount;
      _mm_storel_ps((double *)v35 + 18, _mm_mul_ps(v37, _mm_shuffle_ps(v45, v45, 224)));
      *((float *)v35 + 38) = v38 * v45.m128_f32[0];
    }
    if ( floorPart[0]->px )
    {
      v46 = (__m128)0x3F800000u;
      v46.m128_f32[0] = 1.0 / (float)v44;
      v47 = _mm_shuffle_ps(v46, v46, 224);
      v46.m128_f32[0] = v46.m128_f32[0] * hitLocationAccumulator.z;
      _mm_storel_ps(
        (double *)((char *)v35 + 156),
        _mm_mul_ps(v47, (__m128)*(unsigned __int64 *)&hitLocationAccumulator.x));
      *((_DWORD *)v35 + 41) = v46.m128_i32[0];
      *((_DWORD *)v35 + 7) = 0;
    }
  }
}


// Address: 0x10e02f0 | Name: _ZN3RBX5HUMAN13HumanoidState8simulateERN5boost10shared_ptrIS1_EEf
void __fastcall RBX::HUMAN::HumanoidState::simulate(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *state,
        double a2,
        float dt)
{
  int v4; // r14d
  RBX::Humanoid *v5; // rdi
  int networkHumanoidState; // ebp
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax
  boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *px; // rbp
  RBX::Humanoid *v10; // rdi
  RBX::Primitive *v11; // rax
  RBX::Assembly *v12; // rax
  RBX::Humanoid *v13; // rdi
  RBX::Primitive *v14; // rax
  RBX::Humanoid *v15; // rdi
  RBX::Primitive *v16; // rax
  RBX::Assembly *v17; // rdi
  __int64 v18; // r14
  RBX::Body *TorsoBodyFast; // rax
  float *v20; // rbp
  float v21; // xmm2_4
  volatile signed __int32 *v22; // rbx
  __int64 v23; // [rsp+10h] [rbp-28h] BYREF
  volatile signed __int32 *v24; // [rsp+18h] [rbp-20h]

  v4 = (*(__int64 (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *, double, float))(*(_QWORD *)state->px + 128LL))(
         state->px,
         a2,
         dt);
  v5 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
  networkHumanoidState = 15;
  if ( v5 )
  {
    TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v5);
    if ( TorsoPrimitiveFast )
    {
      PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
      if ( PrimitiveAssembly )
        networkHumanoidState = PrimitiveAssembly->networkHumanoidState;
    }
  }
  if ( v4 != networkHumanoidState )
  {
    px = state->px;
    v10 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
    if ( v10 )
    {
      v11 = RBX::Humanoid::getTorsoPrimitiveFast(v10);
      if ( v11 )
      {
        v12 = RBX::Assembly::getPrimitiveAssembly(v11);
        if ( v12 )
          v12->networkHumanoidState = (*(__int64 (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)px + 128LL))(px);
      }
    }
  }
  v13 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
  if ( v13 )
  {
    v14 = RBX::Humanoid::getTorsoPrimitiveFast(v13);
    if ( v14 )
    {
      if ( RBX::Assembly::getPrimitiveAssembly(v14) )
      {
        v15 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
        if ( v15 && (v16 = RBX::Humanoid::getTorsoPrimitiveFast(v15)) != 0 )
          v17 = RBX::Assembly::getPrimitiveAssembly(v16);
        else
          v17 = 0;
        RBX::Assembly::wakeUp(v17, -1);
      }
    }
  }
  RBX::shared_from<RBX::Humanoid>(&v23, *((RBX::Humanoid **)state->px + 8));
  RBX::HUMAN::HumanoidState::preStepSimulatorSide((RBX::HUMAN::HumanoidState *)state->px, *(float *)&a2, dt);
  RBX::HUMAN::HumanoidState::doSimulatorStateTable(state, dt);
  (*(void (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *, float))(*(_QWORD *)state->px
                                                                                              + 48LL))(
    state->px,
    *(float *)&a2);
  (*(void (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 40LL))(state->px);
  if ( state->px )
  {
    v18 = v23;
    if ( v23 )
    {
      TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(*((RBX::Humanoid **)state->px + 8));
      v20 = (float *)TorsoBodyFast;
      if ( TorsoBodyFast )
      {
        RBX::Body::updatePV(TorsoBodyFast);
        v21 = (float)(v20[59] * 0.0) + (float)((float)(v20[53] * 0.0) + v20[56]);
        *(_BYTE *)(v18 + 734) = v21 < 0.99900001;
        if ( v21 < 0.99900001 )
        {
          *(float *)(v18 + 736) = *(float *)(v18 + 736) + 0.0;
          *(float *)(v18 + 740) = *(float *)(v18 + 740) + 0.0;
          *(float *)(v18 + 744) = *(float *)(v18 + 744) + 0.0;
LABEL_25:
          RBX::HUMAN::HumanoidState::updateHumanoidPlatformStatus(state);
          goto LABEL_26;
        }
      }
      else
      {
        *(_BYTE *)(v18 + 734) = 0;
      }
      _mm_storel_ps((double *)(v18 + 736), (__m128)0LL);
      *(_DWORD *)(v18 + 744) = 0;
      goto LABEL_25;
    }
  }
LABEL_26:
  v22 = v24;
  if ( v24 && !_InterlockedSub(v24 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 16LL))(v22);
    if ( !_InterlockedSub(v22 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v22 + 24LL))(v22);
  }
}


// Address: 0x10e0570 | Name: _ZN3RBX5HUMAN13HumanoidState21doSimulatorStateTableERN5boost10shared_ptrIS1_EEf
void __fastcall RBX::HUMAN::HumanoidState::doSimulatorStateTable(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *state,
        double a2,
        float dt)
{
  int v3; // r15d
  char *px; // rbx
  int v5; // eax
  int *v6; // r12
  _DWORD *v7; // rbx
  int v8; // r14d
  int v9; // ebp
  int v10; // ebp
  RBX::Humanoid *v11; // r12
  unsigned __int64 v12; // rax
  bool v13; // r13
  unsigned __int64 v14; // rbx
  RBX::HUMAN::StateType v15; // ebp
  bool v16; // al
  int v17; // [rsp+14h] [rbp-44h]
  boost::unique_lock<boost::mutex> v18; // [rsp+18h] [rbp-40h] BYREF

  v3 = (*(__int64 (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *, double, float))(*(_QWORD *)state->px + 128LL))(
         state->px,
         a2,
         dt);
  px = (char *)state->px;
  v5 = **((_DWORD **)state->px + 6) - *((_QWORD *)state->px + 6);
  if ( v3 == v5 || v5 == 18 )
    goto LABEL_7;
  v18.m = (boost::mutex *)(px + 72);
  v18.is_locked = 0;
  boost::unique_lock<boost::mutex>::lock(&v18);
  v6 = (int *)*((_QWORD *)px + 5);
  v7 = (_DWORD *)*((_QWORD *)px + 6);
  v8 = *v6;
  v9 = 129 - *v7;
  if ( v18.is_locked )
    boost::mutex::unlock(v18.m);
  v10 = (_DWORD)v7 + v9;
  px = (char *)state->px;
  if ( v8 - (_DWORD)v6 != v10 )
  {
LABEL_7:
    v11 = (RBX::Humanoid *)*((_QWORD *)px + 8);
    LODWORD(v18.m) = v3;
    v12 = 0;
    v13 = 0;
    while ( 1 )
    {
      v14 = v12;
      v17 = v12;
      v15 = dword_4ADD70[27 * v3 + 28 + v12];
      if ( v15 != RBX::HUMAN::StateType::xx
        && v15 != v3
        && RBX::Humanoid::getStateTransitionEnabled(v11, v15)
        && RBX::HUMAN::HumanoidState::computeEvent((RBX::HUMAN::HumanoidState *)state->px, (RBX::HUMAN::EventType)v14) )
      {
        break;
      }
      v12 = v14 + 1;
      if ( v13 )
      {
        v13 = 1;
        if ( v12 >= 0x1A )
          goto LABEL_16;
      }
      else
      {
        v13 = v14 != v17;
        if ( v12 >= 0x1A )
        {
LABEL_16:
          v16 = 0;
          if ( v3 == LODWORD(v18.m) )
            goto LABEL_18;
          goto LABEL_17;
        }
      }
    }
    RBX::HUMAN::HumanoidState::changeState(state, v15);
    RBX::HUMAN::HumanoidState::preStepSimulatorSide((RBX::HUMAN::HumanoidState *)state->px, *(float *)&a2, dt);
    v16 = (*(unsigned int (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 128LL))(state->px) != v15;
    if ( v3 != LODWORD(v18.m) )
    {
LABEL_17:
      BYTE2(qword_2A10EA8) |= 1u;
      unk_2A10EEA |= 1u;
    }
LABEL_18:
    if ( v16 )
      unk_2A3B8BA |= 1u;
    if ( v13 )
    {
      BYTE2(qword_2A10EA8) |= 1u;
      unk_2A10EEA |= 1u;
      unk_2A8A1F2 |= 1u;
    }
  }
  else
  {
    RBX::HUMAN::HumanoidState::changeState(state, (RBX::HUMAN::StateType)(**((_DWORD **)px + 6) - *((_QWORD *)px + 6)));
    RBX::HUMAN::HumanoidState::preStepSimulatorSide((RBX::HUMAN::HumanoidState *)state->px, *(float *)&a2, dt);
  }
}


// Address: 0x10e0780 | Name: _ZNK3RBX5HUMAN13HumanoidState11computeTiltEv
float __fastcall RBX::HUMAN::HumanoidState::computeTilt(const RBX::HUMAN::HumanoidState *this)
{
  RBX::Body *TorsoBodyFast; // rax
  float *v2; // rbx

  TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(*((RBX::Humanoid **)this + 8));
  if ( !TorsoBodyFast )
    return 1.0;
  v2 = (float *)TorsoBodyFast;
  RBX::Body::updatePV(TorsoBodyFast);
  return (float)(0.0 * v2[59]) + (float)((float)(v2[53] * 0.0) + v2[56]);
}


// Address: 0x10e07d0 | Name: _ZN3RBX5HUMAN13HumanoidState28updateHumanoidPlatformStatusERN5boost10shared_ptrIS1_EE
void __fastcall RBX::HUMAN::HumanoidState::updateHumanoidPlatformStatus(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *state)
{
  __int64 v2; // rax
  __int64 v3; // rcx
  volatile signed __int32 *v4; // rbp
  RBX::Primitive *v5; // r14
  __int64 v6; // rcx
  __int64 v7; // rax
  volatile signed __int32 *v8; // rcx
  RBX::Primitive *v9; // r13
  __int64 v10; // rcx
  RBX::Primitive *v11; // rbx
  RBX::Humanoid *v12; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // r15
  bool hasFloorChanged; // r15
  char v16; // bp
  RBX::Primitive *v17; // r13
  RBX::Primitive *v18; // rbx
  char v19; // r14
  __int64 v20; // rcx
  RBX::Humanoid *v21; // rdi
  RBX::Primitive *v22; // rax
  RBX::Assembly *v23; // r14
  unsigned int v24; // eax
  int v25; // ecx
  char v26; // r15
  RBX::Body *TorsoBodyFast; // rax
  RBX::Cofm *cofm; // rbp
  float *p_mass; // rax
  RBX::Assembly *v30; // rax
  RBX::Primitive *AssemblyPrimitive; // rax
  __int64 v32; // rbp
  float *v33; // rax
  RBX::PartInstance *v34; // rax
  float v35; // xmm4_4
  char v36; // bp
  RBX::Assembly *v37; // rax
  RBX::Primitive *v38; // rbp
  RBX::PartInstance *TorsoFast; // r14
  RBX::Primitive *RootMovingPrimitive; // rbx
  RBX::PartInstance *v41; // rax
  RBX::Humanoid *v42; // r14
  RBX::PartInstance *v43; // rax
  bool v44; // al
  boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *px; // rax
  RBX::Humanoid *v46; // rdi
  RBX::PartInstance *v47; // rax
  __int64 p_other; // rsi
  int v49; // eax
  __int64 v50; // rcx
  __int64 v51; // rdx
  RBX::Assembly *v52; // rax
  RBX::Primitive *v53; // r15
  RBX::Primitive *v54; // rax
  rbx::signals::connection *v55; // rbx
  unsigned int v56; // r14d
  void *v57; // rbp
  rbx::signals::signal_base *v58; // r15
  rbx::signals::connection *v59; // rbx
  rbx::signals::slot_base *p; // rdi
  char arg1; // [rsp+8h] [rbp-60h]
  float arg1a; // [rsp+8h] [rbp-60h]
  volatile signed __int32 *v63; // [rsp+10h] [rbp-58h]
  __int64 v64; // [rsp+18h] [rbp-50h]
  float v65; // [rsp+18h] [rbp-50h]
  volatile signed __int32 *v66; // [rsp+20h] [rbp-48h]
  rbx::signals::connection other; // [rsp+28h] [rbp-40h] BYREF
  RBX::Primitive *v68; // [rsp+30h] [rbp-38h]

  v2 = *((_QWORD *)state->px + 8);
  v3 = *(_QWORD *)(v2 + 888);
  v4 = *(volatile signed __int32 **)(v2 + 896);
  if ( v4 )
    _InterlockedAdd(v4 + 2, 1u);
  v64 = v3;
  if ( v3 )
  {
    v5 = *(RBX::Primitive **)(v3 + 232);
    if ( stru_2A08D48.value )
      goto LABEL_5;
LABEL_10:
    arg1 = 0;
    v8 = 0;
LABEL_12:
    v9 = 0;
    goto LABEL_13;
  }
  v5 = 0;
  if ( !stru_2A08D48.value )
    goto LABEL_10;
LABEL_5:
  v6 = *((_QWORD *)state->px + 8);
  v7 = *(_QWORD *)(v6 + 904);
  v8 = *(volatile signed __int32 **)(v6 + 912);
  if ( v8 )
    _InterlockedAdd(v8 + 2, 1u);
  if ( !v7 )
  {
    arg1 = 0;
    goto LABEL_12;
  }
  v9 = *(RBX::Primitive **)(v7 + 232);
  arg1 = 1;
LABEL_13:
  v63 = v8;
  v10 = *((_QWORD *)state->px + 14);
  v66 = v4;
  if ( !v10
    || (v11 = *(RBX::Primitive **)(v10 + 232), !*((_QWORD *)v11 + 17))
    || (v12 = (RBX::Humanoid *)*((_QWORD *)state->px + 8)) == 0
    || (TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v12)) == 0
    || (PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast)) == 0
    || PrimitiveAssembly == RBX::Assembly::getPrimitiveAssembly(v11) )
  {
    v11 = 0;
  }
  hasFloorChanged = RBX::HUMAN::HumanoidState::hasFloorChanged(state, v5);
  v16 = 0;
  v68 = v11;
  if ( v11 || !stru_2A08D48.value )
  {
    v17 = v11;
    v18 = v5;
  }
  else
  {
    if ( hasFloorChanged )
    {
      v16 = 0;
      v17 = 0;
      v18 = v5;
      v19 = 1;
LABEL_34:
      if ( rbx::signals::connection::connected((const rbx::signals::connection *)(*((_QWORD *)state->px + 8) + 2608LL)) )
      {
        if ( byte_2A08F68 )
          FLog::FastLog(byte_2A08F68, "Disconnecting from last floor", 0);
        rbx::signals::connection::disconnect((const rbx::signals::connection *)(*((_QWORD *)state->px + 8) + 2608LL));
      }
      if ( (*(unsigned int (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 128LL))(state->px) != 13 )
      {
        if ( v64 )
        {
          RBX::Humanoid::setLastFloor(*((RBX::Humanoid **)state->px + 8), 0);
          v18 = 0;
          RBX::Humanoid::setRootPlatformPart(*((RBX::Humanoid **)state->px + 8), 0);
        }
        if ( stru_2A08D48.value && arg1 )
        {
          RBX::Humanoid::setLastFloor(*((RBX::Humanoid **)state->px + 8), 0);
          v18 = 0;
          RBX::Humanoid::setRootPlatformPart(*((RBX::Humanoid **)state->px + 8), 0);
        }
      }
      goto LABEL_47;
    }
    v18 = v9;
    hasFloorChanged = RBX::HUMAN::HumanoidState::hasLadderChanged(state, v9);
    v20 = *((_QWORD *)state->px + 23);
    v16 = 1;
    if ( v20 )
    {
      v17 = *(RBX::Primitive **)(v20 + 232);
      if ( *((_QWORD *)v17 + 17) )
      {
        v21 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
        if ( v21 )
        {
          v22 = RBX::Humanoid::getTorsoPrimitiveFast(v21);
          if ( v22 )
          {
            v23 = RBX::Assembly::getPrimitiveAssembly(v22);
            if ( v23 )
            {
              if ( v23 != RBX::Assembly::getPrimitiveAssembly(v17) )
                goto LABEL_33;
            }
          }
        }
      }
      v16 = 1;
    }
    v17 = 0;
  }
LABEL_33:
  v19 = 1;
  if ( hasFloorChanged )
    goto LABEL_34;
  v24 = (*(__int64 (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px
                                                                                                + 128LL))(state->px);
  if ( v24 <= 0xE )
  {
    v25 = 20356;
    if ( _bittest(&v25, v24) )
    {
      v19 = 0;
      goto LABEL_47;
    }
  }
  v19 = 0;
  if ( v24 != 12 || !stru_2A08D48.value )
    goto LABEL_34;
LABEL_47:
  if ( !v17 )
  {
LABEL_77:
    v36 = 0;
    goto LABEL_78;
  }
  v26 = v16;
  TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(*((RBX::Humanoid **)state->px + 8));
  cofm = TorsoBodyFast->cofm;
  if ( cofm )
  {
    RBX::Cofm::updateIfDirty(TorsoBodyFast->cofm);
    p_mass = &cofm->branch.mass;
LABEL_53:
    v65 = *p_mass;
    goto LABEL_54;
  }
  if ( !TorsoBodyFast->isMassless || (v65 = 0.0, TorsoBodyFast->root == TorsoBodyFast) )
  {
    p_mass = &TorsoBodyFast->bodyMass.mass;
    goto LABEL_53;
  }
LABEL_54:
  v30 = RBX::Assembly::getPrimitiveAssembly(v17);
  AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(v30);
  v32 = *((_QWORD *)AssemblyPrimitive + 26);
  if ( v32 )
  {
    RBX::Cofm::updateIfDirty(*((RBX::Cofm **)AssemblyPrimitive + 26));
    v33 = (float *)(v32 + 24);
LABEL_59:
    arg1a = *v33;
    goto LABEL_60;
  }
  if ( !*((_BYTE *)AssemblyPrimitive + 236)
    || (arg1a = 0.0, *((RBX::Primitive **)AssemblyPrimitive + 25) == (RBX::Primitive *)((char *)AssemblyPrimitive + 152)) )
  {
    v33 = (float *)((char *)AssemblyPrimitive + 312);
    goto LABEL_59;
  }
LABEL_60:
  v34 = RBX::PartInstance::fromPrimitive(v17);
  if ( v34 && RBX::Humanoid::constHumanoidFromDescendant(v34) || RBX::Primitive::computeIsGrounded(v17) )
    goto LABEL_77;
  if ( byte_2A08F68 )
    FLog::FastLogF(
      byte_2A08F68,
      "Check platform subscription Player Mass: %4.4f, Floor Mass: %4.4f",
      arg1a,
      0.0,
      0.0,
      v35);
  if ( arg1a <= (float)(v65 + v65) )
    goto LABEL_77;
  if ( byte_2A08F68 )
    FLog::FastLog(byte_2A08F68, "Platform Subscribed", 0);
  v36 = 1;
  if ( ((v18 != 0) & (unsigned __int8)~v19) == 0 )
  {
    v37 = RBX::Assembly::getPrimitiveAssembly(v17);
    if ( v37 )
    {
      v38 = RBX::Assembly::getAssemblyPrimitive(v37);
      if ( v38 )
      {
        TorsoFast = RBX::Humanoid::getTorsoFast(*((RBX::Humanoid **)state->px + 8));
        if ( TorsoFast )
        {
          RootMovingPrimitive = RBX::Primitive::getRootMovingPrimitive(v38);
          if ( RootMovingPrimitive != RBX::Primitive::getRootMovingPrimitive(TorsoFast->primitive.px) )
          {
            v41 = RBX::PartInstance::fromPrimitive(v38);
            RBX::PartInstance::setReplicationRootPart(TorsoFast, v41);
          }
        }
        v42 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
        v43 = RBX::PartInstance::fromPrimitive(v38);
        if ( v26 )
          RBX::Humanoid::setLastLadderPart(v42, v43);
        else
          RBX::Humanoid::setLastFloor(v42, v43);
        v18 = v38;
      }
    }
    goto LABEL_89;
  }
LABEL_78:
  v44 = stru_2A08D48.value
     && (*(unsigned int (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 128LL))(state->px) == 12;
  if ( (unsigned __int8)v36 | (v17 == 0) )
  {
    if ( v44 )
      goto LABEL_89;
    px = state->px;
    if ( *((float *)state->px + 7) <= (float)((float)dword_28594B8 / 10.0) )
      goto LABEL_89;
  }
  else
  {
    px = state->px;
  }
  v46 = (RBX::Humanoid *)*((_QWORD *)px + 8);
  if ( v46 )
  {
    v47 = RBX::Humanoid::getTorsoFast(v46);
    if ( v47 )
      RBX::PartInstance::setReplicationRootPart(v47, 0);
  }
LABEL_89:
  if ( v68 )
    p_other = *((unsigned int *)state->px + 32);
  else
    p_other = 1792;
  RBX::Humanoid::setFloorMaterial(*((RBX::Humanoid **)state->px + 8), (RBX::PartMaterial)p_other);
  v49 = (*(__int64 (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px
                                                                                                + 128LL))(state->px);
  v51 = (unsigned int)(v49 - 2);
  if ( (unsigned int)v51 >= 0xD || (LOBYTE(v50) = 1, p_other = 5089, !_bittest((const int *)&p_other, v51)) )
  {
    LOBYTE(v51) = stru_2A08D48.value;
    LOBYTE(v50) = stru_2A08D48.value && v49 == 12;
  }
  if ( v18 && (_BYTE)v50 )
  {
    v52 = RBX::Assembly::getPrimitiveAssembly(v18);
    if ( v52 )
    {
      v53 = RBX::Assembly::getAssemblyPrimitive(v52);
      v54 = RBX::Mechanism::getRootMovingPrimitive(v18);
      p_other = (__int64)RBX::PartInstance::fromPrimitive(v54);
      RBX::Humanoid::setRootPlatformPart(*((RBX::Humanoid **)state->px + 8), (RBX::PartInstance *)p_other);
    }
    else
    {
      v53 = 0;
    }
    if ( !rbx::signals::connection::connected((const rbx::signals::connection *)(*((_QWORD *)state->px + 8) + 2608LL)) )
    {
      v55 = (rbx::signals::connection *)*((_QWORD *)state->px + 8);
      v56 = RBX::Memory::setCurrentCategory(dword_2CE45C8);
      v57 = operator new(0x30u);
      v58 = (rbx::signals::signal_base *)((char *)v53 + 120);
      *(_QWORD *)v57 = 0x100000000LL;
      *((_QWORD *)v57 + 1) = rbx::signals::slot_with_functor<RBX::HUMAN::HumanoidState::updateHumanoidPlatformStatus(boost::shared_ptr<RBX::HUMAN::HumanoidState> &)::$_0,RBX::Primitive *,G3D::CoordinateFrame &,RBX::Velocity &>::do_call;
      *((_QWORD *)v57 + 2) = rbx::signals::slot_with_functor<RBX::HUMAN::HumanoidState::updateHumanoidPlatformStatus(boost::shared_ptr<RBX::HUMAN::HumanoidState> &)::$_0,RBX::Primitive *,G3D::CoordinateFrame &,RBX::Velocity &>::do_dtor;
      *((_QWORD *)v57 + 3) = 0;
      *((_QWORD *)v57 + 4) = v58;
      *((_QWORD *)v57 + 5) = v55;
      rbx::signals::signal_base::insert(v58, (rbx::signals::slot_base *)v57);
      other.weak_slot.p_ = (rbx::signals::slot_base *)v57;
      _InterlockedAdd((volatile signed __int32 *)v57 + 1, 1u);
      RBX::Memory::setCurrentCategory(v56);
      v59 = v55 + 326;
      p_other = (__int64)&other;
      if ( rbx::signals::connection::operator!=(v59, &other) )
      {
        rbx::signals::connection::disconnect(v59);
        p_other = (__int64)&other;
        rbx::signals::connection::operator=(v59, &other);
      }
      p = other.weak_slot.p_;
      if ( other.weak_slot.p_ && !_InterlockedSub(&other.weak_slot.p_->weak.v, 1u) )
        operator delete(p);
    }
  }
  if ( v63 )
  {
    if ( !_InterlockedSub(v63 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *, __int64, __int64, __int64))(*(_QWORD *)v63 + 16LL))(
        v63,
        p_other,
        v51,
        v50);
      if ( !_InterlockedSub(v63 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v63 + 24LL))(v63);
    }
  }
  if ( v66 && !_InterlockedSub(v66 + 2, 1u) )
  {
    (*(void (__fastcall **)(volatile signed __int32 *, __int64, __int64, __int64))(*(_QWORD *)v66 + 16LL))(
      v66,
      p_other,
      v51,
      v50);
    if ( !_InterlockedSub(v66 + 3, 1u) )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v66 + 24LL))(v66);
  }
}


// Address: 0x10e0fc0 | Name: _ZN3RBX5HUMAN13HumanoidState40isValidPlatformSubscriptionHumanoidStateENS0_9StateTypeE
bool __fastcall RBX::HUMAN::HumanoidState::isValidPlatformSubscriptionHumanoidState(RBX::HUMAN::StateType state)
{
  int v1; // eax

  if ( (unsigned int)state <= RBX::HUMAN::StateType::PLATFORM_STANDING && (v1 = 20356, _bittest(&v1, state)) )
    return 1;
  else
    return stru_2A08D48.value && state == RBX::HUMAN::StateType::CLIMBING;
}


// Address: 0x10e1010 | Name: _ZN3RBX5HUMAN13HumanoidState20resetReplicationRootEv
void __fastcall RBX::HUMAN::HumanoidState::resetReplicationRoot(RBX::HUMAN::HumanoidState *this)
{
  RBX::Humanoid *v1; // rdi
  RBX::PartInstance *TorsoFast; // rax

  v1 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( v1 )
  {
    TorsoFast = RBX::Humanoid::getTorsoFast(v1);
    if ( TorsoFast )
      RBX::PartInstance::setReplicationRootPart(TorsoFast, 0);
  }
}


// Address: 0x10e1040 | Name: _ZN3RBX5HUMAN13HumanoidState15hasFloorChangedERN5boost10shared_ptrIS1_EEPNS_9PrimitiveE
bool __fastcall RBX::HUMAN::HumanoidState::hasFloorChanged(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *state,
        RBX::Primitive *lastFloorPrim)
{
  __int64 v3; // rcx
  RBX::Primitive *v4; // r14
  RBX::Humanoid *v5; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax
  RBX::Assembly *v8; // rax
  RBX::Primitive *AssemblyPrimitive; // rcx
  bool result; // al
  RBX::Assembly *v11; // rbx

  v3 = *((_QWORD *)state->px + 14);
  if ( !v3
    || (v4 = *(RBX::Primitive **)(v3 + 232), !*((_QWORD *)v4 + 17))
    || (v5 = (RBX::Humanoid *)*((_QWORD *)state->px + 8)) == 0
    || (TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v5)) == 0
    || (PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast)) == 0
    || PrimitiveAssembly == RBX::Assembly::getPrimitiveAssembly(v4) )
  {
    v4 = 0;
  }
  if ( !lastFloorPrim )
    return 0;
  if ( !*((_QWORD *)lastFloorPrim + 17) )
  {
    RBX::Humanoid::setLastFloor(*((RBX::Humanoid **)state->px + 8), 0);
    RBX::Humanoid::setRootPlatformPart(*((RBX::Humanoid **)state->px + 8), 0);
    return 1;
  }
  if ( !v4 || !RBX::Assembly::getPrimitiveAssembly(lastFloorPrim) )
    return 0;
  v8 = RBX::Assembly::getPrimitiveAssembly(v4);
  AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(v8);
  result = 1;
  if ( AssemblyPrimitive == lastFloorPrim )
  {
    v11 = RBX::Assembly::getPrimitiveAssembly(lastFloorPrim);
    return v11 != RBX::Assembly::getPrimitiveAssembly(v4);
  }
  return result;
}


// Address: 0x10e1130 | Name: _ZN3RBX5HUMAN13HumanoidState16hasLadderChangedERN5boost10shared_ptrIS1_EEPNS_9PrimitiveE
bool __fastcall RBX::HUMAN::HumanoidState::hasLadderChanged(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *state,
        RBX::Primitive *lastLadderPrim)
{
  __int64 v3; // rcx
  RBX::Primitive *v4; // r14
  RBX::Humanoid *v5; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax
  RBX::Assembly *v8; // rax
  RBX::Primitive *AssemblyPrimitive; // rcx
  bool result; // al
  RBX::Assembly *v11; // rbx

  v3 = *((_QWORD *)state->px + 23);
  if ( !v3
    || (v4 = *(RBX::Primitive **)(v3 + 232), !*((_QWORD *)v4 + 17))
    || (v5 = (RBX::Humanoid *)*((_QWORD *)state->px + 8)) == 0
    || (TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v5)) == 0
    || (PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast)) == 0
    || PrimitiveAssembly == RBX::Assembly::getPrimitiveAssembly(v4) )
  {
    v4 = 0;
  }
  if ( !lastLadderPrim )
    return 0;
  if ( !*((_QWORD *)lastLadderPrim + 17) )
  {
    RBX::Humanoid::setLastLadderPart(*((RBX::Humanoid **)state->px + 8), 0);
    RBX::Humanoid::setRootPlatformPart(*((RBX::Humanoid **)state->px + 8), 0);
    return 1;
  }
  if ( !v4 || !RBX::Assembly::getPrimitiveAssembly(lastLadderPrim) )
    return 0;
  v8 = RBX::Assembly::getPrimitiveAssembly(v4);
  AssemblyPrimitive = RBX::Assembly::getAssemblyPrimitive(v8);
  result = 1;
  if ( AssemblyPrimitive == lastLadderPrim )
  {
    v11 = RBX::Assembly::getPrimitiveAssembly(lastLadderPrim);
    return v11 != RBX::Assembly::getPrimitiveAssembly(v4);
  }
  return result;
}


// Address: 0x10e1220 | Name: _ZN3RBX5HUMAN13HumanoidState10noSimulateERN5boost10shared_ptrIS1_EE
void __fastcall RBX::HUMAN::HumanoidState::noSimulate(boost::shared_ptr<RBX::HUMAN::HumanoidState> *state)
{
  RBX::Humanoid *v2; // rdi
  RBX::HUMAN::StateType networkHumanoidState; // ebp
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax
  RBX::Humanoid *v6; // rdi
  RBX::Primitive *v7; // rax
  RBX::Humanoid *v8; // rdi
  RBX::Primitive *v9; // rax
  RBX::Assembly *v10; // rdi

  v2 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
  networkHumanoidState = RBX::HUMAN::StateType::DEAD;
  if ( v2 )
  {
    TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v2);
    if ( TorsoPrimitiveFast )
    {
      PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
      if ( PrimitiveAssembly )
        networkHumanoidState = PrimitiveAssembly->networkHumanoidState;
    }
  }
  v6 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
  if ( v6 )
  {
    v7 = RBX::Humanoid::getTorsoPrimitiveFast(v6);
    if ( v7 )
    {
      if ( RBX::Assembly::getPrimitiveAssembly(v7) )
      {
        v8 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
        if ( v8 && (v9 = RBX::Humanoid::getTorsoPrimitiveFast(v8)) != 0 )
          v10 = RBX::Assembly::getPrimitiveAssembly(v9);
        else
          v10 = 0;
        RBX::Assembly::wakeUp(v10, -1);
      }
    }
  }
  RBX::HUMAN::HumanoidState::preStepCollide((RBX::HUMAN::HumanoidState *)state->px);
  RBX::HUMAN::HumanoidState::doSlaveStateTable(state, networkHumanoidState);
  (*(void (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 40LL))(state->px);
}


// Address: 0x10e12d0 | Name: _ZN3RBX5HUMAN13HumanoidState17doSlaveStateTableERN5boost10shared_ptrIS1_EENS0_9StateTypeE
void __fastcall RBX::HUMAN::HumanoidState::doSlaveStateTable(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *state,
        RBX::HUMAN::StateType newType)
{
  RBX::DataModel *v4; // rax
  RBX::HUMAN::StateType v5; // ebp
  boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *px; // rdi
  __int64 v7; // rax
  int v8; // eax

  if ( (*(unsigned int (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 128LL))(state->px) != 15
    || (v4 = RBX::DataModel::get(*((RBX::Instance **)state->px + 8))) == 0
    || *((_DWORD *)v4 + 492) != 2 )
  {
    v5 = RBX::HUMAN::StateType::DEAD;
    if ( !RBX::Humanoid::getLostAllHealth(*((const RBX::Humanoid **)state->px + 8))
      && !RBX::Humanoid::getLostNeck(*((RBX::Humanoid **)state->px + 8)) )
    {
      px = state->px;
      v7 = *((_QWORD *)state->px + 8);
      v5 = RBX::HUMAN::StateType::SEATED;
      if ( *(char *)(v7 + 699) <= 0 )
      {
        v5 = RBX::HUMAN::StateType::PLATFORM_STANDING;
        if ( **(_BYTE **)(v7 + 712) == (unsigned __int8)*(_QWORD *)(v7 + 712) )
        {
          if ( (*(unsigned int (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)px + 128LL))(px) != 10
            || (v5 = RBX::HUMAN::StateType::RUNNING_SLAVE,
                !RBX::HUMAN::HumanoidState::computeTouchedByMySimulation((RBX::HUMAN::HumanoidState *)state->px)) )
          {
            if ( (*(unsigned int (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 128LL))(state->px) == 8
              && *(char *)(*((_QWORD *)state->px + 8) + 700LL) > 0 )
            {
              newType = RBX::HUMAN::StateType::RAGDOLL;
            }
            v5 = newType;
          }
        }
      }
    }
    if ( v5 != (*(unsigned int (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 128LL))(state->px) )
    {
      v8 = (*(__int64 (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 128LL))(state->px);
      if ( v5 != RBX::HUMAN::StateType::RUNNING_NO_PHYS || v8 != 9 )
      {
        if ( !stru_2A08CD8.value || RBX::Humanoid::getStateTransitionEnabled(*((RBX::Humanoid **)state->px + 8), v5) )
          RBX::HUMAN::HumanoidState::changeState(state, v5);
        RBX::HUMAN::HumanoidState::preStepCollide((RBX::HUMAN::HumanoidState *)state->px);
      }
    }
  }
}


// Address: 0x10e1400 | Name: _ZN3RBX5HUMAN13HumanoidState11changeStateERN5boost10shared_ptrIS1_EENS0_9StateTypeE
void __fastcall RBX::HUMAN::HumanoidState::changeState(
        boost::shared_ptr<RBX::HUMAN::HumanoidState> *state,
        RBX::HUMAN::StateType newType)
{
  RBX::HUMAN::StateType v3; // eax
  RBX::HUMAN::StateType v4; // ebp
  char *px; // rcx
  volatile signed __int32 *v6; // rax
  int v7; // r13d
  __int64 v8; // r14
  volatile signed __int32 *v9; // r15
  rbx::signals::connection *v10; // r13
  boost::detail::sp_counted_base *pi; // r14
  RBX::HUMAN::HumanoidState *New; // rbp
  RBX::Humanoid *v13; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // r14
  RBX::Humanoid *v16; // rdi
  RBX::PartInstance *TorsoFast; // rax
  boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *v18; // rax
  volatile signed __int32 *v19; // rbp
  char *v20; // rax
  _DWORD *v21; // rax
  char *v22; // rax
  boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *v23; // rax
  volatile signed __int32 *v24; // rbp
  _DWORD *v25; // rax
  char v26; // [rsp+Ch] [rbp-9Ch]
  char v27; // [rsp+Dh] [rbp-9Bh]
  char v28; // [rsp+Eh] [rbp-9Ah]
  char v29; // [rsp+Fh] [rbp-99h]
  volatile signed __int32 *v30; // [rsp+10h] [rbp-98h]
  int v31; // [rsp+1Ch] [rbp-8Ch]
  int v32; // [rsp+20h] [rbp-88h]
  int v33; // [rsp+24h] [rbp-84h]
  __int64 v34; // [rsp+28h] [rbp-80h]
  int v35; // [rsp+30h] [rbp-78h]
  __int64 v36; // [rsp+38h] [rbp-70h]
  int v37; // [rsp+40h] [rbp-68h]
  __int64 v38; // [rsp+48h] [rbp-60h]
  int v39; // [rsp+50h] [rbp-58h]
  __int64 v40; // [rsp+58h] [rbp-50h]
  int v41; // [rsp+60h] [rbp-48h]
  __int64 v42; // [rsp+68h] [rbp-40h]
  __int64 v43; // [rsp+70h] [rbp-38h]

  v3 = (*(unsigned int (__fastcall **)(boost::shared_ptr<RBX::HUMAN::HumanoidState>::element_type *))(*(_QWORD *)state->px + 128LL))(state->px);
  if ( v3 != newType )
  {
    v4 = v3;
    px = (char *)state->px;
    v43 = *((_QWORD *)state->px + 14);
    v6 = (volatile signed __int32 *)*((_QWORD *)state->px + 15);
    if ( v6 )
    {
      _InterlockedAdd(v6 + 2, 1u);
      px = (char *)state->px;
    }
    v30 = v6;
    v32 = *((_DWORD *)px + 32);
    v41 = *((_DWORD *)px + 35);
    v40 = *(_QWORD *)(px + 132);
    v39 = *((_DWORD *)px + 38);
    v38 = *((_QWORD *)px + 18);
    v37 = *((_DWORD *)px + 41);
    v36 = *(_QWORD *)(px + 156);
    v7 = *((_DWORD *)px + 7);
    v33 = *((_DWORD *)px + 5);
    v29 = px[8];
    v28 = px[11];
    v27 = px[12];
    v26 = px[13];
    v8 = *((_QWORD *)px + 23);
    v9 = (volatile signed __int32 *)*((_QWORD *)px + 24);
    if ( v9 )
    {
      _InterlockedAdd(v9 + 2, 1u);
      px = (char *)state->px;
    }
    v35 = *((_DWORD *)px + 52);
    v34 = *((_QWORD *)px + 25);
    if ( byte_2A349D0 )
    {
      FLog::FastLog(
        byte_2A349D0,
        "Changing humanoid state, old: %u, new: %u",
        (const void *)(unsigned int)v4,
        (const void *)(unsigned int)newType,
        0);
      px = (char *)state->px;
    }
    v31 = v7;
    v42 = v8;
    v10 = (rbx::signals::connection *)*((_QWORD *)px + 8);
    if ( ((newType | 2) == 0xF || !stru_2A08D48.value && newType == RBX::HUMAN::StateType::CLIMBING)
      && rbx::signals::connection::connected(v10 + 326) )
    {
      rbx::signals::connection::disconnect(v10 + 326);
    }
    RBX::Humanoid::setPreviousStateType((RBX::Humanoid *)v10, v4);
    pi = state->pn.pi_;
    *state = 0;
    if ( pi )
    {
      if ( !_InterlockedSub(&pi->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    New = RBX::HUMAN::HumanoidState::createNew(newType, v4, (RBX::Humanoid *)v10);
    v13 = (RBX::Humanoid *)*((_QWORD *)New + 8);
    if ( v13 )
    {
      TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v13);
      if ( TorsoPrimitiveFast )
      {
        PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
        if ( PrimitiveAssembly )
          PrimitiveAssembly->networkHumanoidState = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)New + 128LL))(New);
      }
    }
    boost::shared_ptr<RBX::HUMAN::HumanoidState>::reset<RBX::HUMAN::HumanoidState>(state, New);
    if ( newType == RBX::HUMAN::StateType::SWIMMING )
    {
      v16 = (RBX::Humanoid *)*((_QWORD *)state->px + 8);
      if ( v16 )
      {
        TorsoFast = RBX::Humanoid::getTorsoFast(v16);
        if ( TorsoFast )
          RBX::PartInstance::setReplicationRootPart(TorsoFast, 0);
      }
    }
    v18 = state->px;
    if ( v30 )
      _InterlockedAdd(v30 + 2, 1u);
    *((_QWORD *)v18 + 14) = v43;
    v19 = (volatile signed __int32 *)*((_QWORD *)v18 + 15);
    *((_QWORD *)v18 + 15) = v30;
    if ( v19 )
    {
      if ( !_InterlockedSub(v19 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 16LL))(v19);
        if ( !_InterlockedSub(v19 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 24LL))(v19);
      }
    }
    v20 = (char *)state->px;
    *((_DWORD *)v20 + 32) = v32;
    *((_DWORD *)v20 + 35) = v41;
    *(_QWORD *)(v20 + 132) = v40;
    v21 = state->px;
    v21[38] = v39;
    *((_QWORD *)v21 + 18) = v38;
    v22 = (char *)state->px;
    *((_DWORD *)v22 + 41) = v37;
    *(_QWORD *)(v22 + 156) = v36;
    v23 = state->px;
    *((_DWORD *)v23 + 7) = v31;
    *((_DWORD *)v23 + 5) = v33;
    *((_BYTE *)v23 + 8) = v29;
    *((_BYTE *)v23 + 11) = v28;
    *((_BYTE *)v23 + 12) = v27;
    *((_BYTE *)v23 + 13) = v26;
    if ( v9 )
      _InterlockedAdd(v9 + 2, 1u);
    *((_QWORD *)v23 + 23) = v42;
    v24 = (volatile signed __int32 *)*((_QWORD *)v23 + 24);
    *((_QWORD *)v23 + 24) = v9;
    if ( v24 )
    {
      if ( !_InterlockedSub(v24 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 16LL))(v24);
        if ( !_InterlockedSub(v24 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v24 + 24LL))(v24);
      }
    }
    v25 = state->px;
    v25[52] = v35;
    *((_QWORD *)v25 + 25) = v34;
    if ( v9 )
    {
      if ( !_InterlockedSub(v9 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
        if ( !_InterlockedSub(v9 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 24LL))(v9);
      }
    }
    if ( v30 && !_InterlockedSub(v30 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v30 + 16LL))(v30);
      if ( !_InterlockedSub(v30 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v30 + 24LL))(v30);
    }
  }
}


// Address: 0x10e1850 | Name: _ZN3RBX5HUMAN13HumanoidState6createENS0_9StateTypeES2_PNS_8HumanoidE
RBX::HUMAN::HumanoidState *__fastcall RBX::HUMAN::HumanoidState::create(
        RBX::HUMAN::StateType newType,
        RBX::HUMAN::StateType oldType,
        RBX::Humanoid *humanoid)
{
  RBX::HUMAN::HumanoidState *New; // rbx
  RBX::Humanoid *v4; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax

  New = RBX::HUMAN::HumanoidState::createNew(newType, oldType, humanoid);
  v4 = (RBX::Humanoid *)*((_QWORD *)New + 8);
  if ( v4 )
  {
    TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v4);
    if ( TorsoPrimitiveFast )
    {
      PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
      if ( PrimitiveAssembly )
        PrimitiveAssembly->networkHumanoidState = (*(__int64 (__fastcall **)(RBX::HUMAN::HumanoidState *))(*(_QWORD *)New + 128LL))(New);
    }
  }
  return New;
}


// Address: 0x10e18a0 | Name: _ZN3RBX5HUMAN13HumanoidState12computeEventENS0_9EventTypeE
bool __fastcall RBX::HUMAN::HumanoidState::computeEvent(
        RBX::HUMAN::HumanoidState *this,
        RBX::HUMAN::EventType eventType)
{
  char v2; // bp
  RBX::Body *TorsoBodyFast; // rax
  float *v6; // rbp
  RBX::Body *v7; // rax
  float *v8; // rbx
  RBX::Primitive *v9; // rax
  RBX::Assembly *PrimitiveAssembly; // rax
  bool v11; // cf
  RBX::Primitive *v12; // rax
  RBX::Assembly *v13; // rax
  bool value; // r14
  bool v15; // r15
  const RBX::Instance *ConstCharacterFromHumanoid; // rax
  const RBX::BodyMover *v17; // rax
  RBX::Humanoid *v18; // rdi
  RBX::Primitive *v19; // rax
  RBX::Assembly *v20; // rax
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Primitive *v22; // rbp
  __m128 v23; // xmm1
  __m128 v24; // [rsp+0h] [rbp-48h]
  RBX::Velocity v25; // [rsp+10h] [rbp-38h] BYREF

  v2 = 0;
  switch ( eventType )
  {
    case RBX::HUMAN::EventType::NO_HEALTH:
      return RBX::Humanoid::getLostAllHealth(*((const RBX::Humanoid **)this + 8));
    case RBX::HUMAN::EventType::NO_NECK:
      return RBX::Humanoid::getLostNeck(*((RBX::Humanoid **)this + 8));
    case RBX::HUMAN::EventType::JUMP_CMD:
      return RBX::HUMAN::HumanoidState::computeJumped(this);
    case RBX::HUMAN::EventType::NO_STRAFE_CMD:
      return *(_BYTE *)(*((_QWORD *)this + 8) + 701LL) <= 0;
    case RBX::HUMAN::EventType::SIT_CMD:
      return *(_BYTE *)(*((_QWORD *)this + 8) + 699LL) > 0;
    case RBX::HUMAN::EventType::NO_SIT_CMD:
      return *(_BYTE *)(*((_QWORD *)this + 8) + 699LL) <= 0;
    case RBX::HUMAN::EventType::PLATFORM_STAND_CMD:
      return **(_BYTE **)(*((_QWORD *)this + 8) + 712LL) != (unsigned __int8)*(_QWORD *)(*((_QWORD *)this + 8) + 712LL);
    case RBX::HUMAN::EventType::NO_PLATFORM_STAND_CMD:
      return **(_BYTE **)(*((_QWORD *)this + 8) + 712LL) == (unsigned __int8)*(_QWORD *)(*((_QWORD *)this + 8) + 712LL);
    case RBX::HUMAN::EventType::TIPPED:
      TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(*((RBX::Humanoid **)this + 8));
      if ( TorsoBodyFast )
      {
        v6 = (float *)TorsoBodyFast;
        RBX::Body::updatePV(TorsoBodyFast);
        if ( (float)((float)(0.0 * v6[59]) + (float)((float)(v6[53] * 0.0) + v6[56])) < 0.69999999
          && !*((_BYTE *)this + 11) )
        {
          return 1;
        }
      }
      return 0;
    case RBX::HUMAN::EventType::UPRIGHT:
      v7 = RBX::Humanoid::getTorsoBodyFast(*((RBX::Humanoid **)this + 8));
      if ( !v7 )
        return 1;
      v8 = (float *)v7;
      RBX::Body::updatePV(v7);
      return (float)((float)(0.0 * v8[59]) + (float)((float)(v8[53] * 0.0) + v8[56])) > 0.89999998;
    case RBX::HUMAN::EventType::FACE_LDR:
      return *((_BYTE *)this + 13) != 0;
    case RBX::HUMAN::EventType::AWAY_LDR:
      return *((_BYTE *)this + 13) == 0;
    case RBX::HUMAN::EventType::OFF_FLOOR:
      return *((_QWORD *)this + 14) == 0;
    case RBX::HUMAN::EventType::OFF_FLOOR_GRACE:
      if ( !stru_2A08CA8.value )
        return *((float *)this + 7) > 0.125;
      if ( RBX::Humanoid::getCurrentStateType(*((RBX::Humanoid **)this + 8)) == RBX::HUMAN::StateType::RUNNING )
        return *((float *)this + 7) > (float)((float)dword_2859470 / 100.0);
      if ( stru_2A08CA8.value
        && RBX::Humanoid::getCurrentStateType(*((RBX::Humanoid **)this + 8)) == RBX::HUMAN::StateType::RUNNING_NO_PHYS )
      {
        return 0;
      }
      return *((float *)this + 7) > 0.125;
    case RBX::HUMAN::EventType::ON_FLOOR:
      if ( stru_2A08D60.value )
        return RBX::HUMAN::HumanoidState::canLand(this);
      if ( !*((_QWORD *)this + 14) )
        return 0;
      TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
      if ( TorsoPrimitiveSlow )
      {
        v22 = TorsoPrimitiveSlow;
        RBX::Body::updatePV((RBX::Body *)((char *)TorsoPrimitiveSlow + 152));
        v24 = (__m128)*((unsigned __int64 *)v22 + 51);
        RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v25, this);
        v23 = _mm_sub_ps(v24, (__m128)*(unsigned __int64 *)&v25.linear.x);
      }
      else
      {
        v23 = 0;
      }
      v11 = _mm_shuffle_ps(v23, v23, 229).m128_f32[0] > 0.0;
      return !v11;
    case RBX::HUMAN::EventType::TOUCHED:
      v2 = 1;
      if ( stru_2A08D30.value )
        return v2;
      v9 = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
      if ( v9 )
      {
        PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(v9);
        if ( PrimitiveAssembly )
        {
          if ( PrimitiveAssembly->filterPhase == Sim_OnContactBuffer )
            return v2;
        }
      }
      return RBX::HUMAN::HumanoidState::computeTouched(this);
    case RBX::HUMAN::EventType::NEARLY_TOUCHED:
      if ( !RBX::Humanoid::computeNearlyTouched(*((RBX::Humanoid **)this + 8)) )
        return 0;
      *((_DWORD *)this + 5) = 0;
      return 1;
    case RBX::HUMAN::EventType::TOUCHED_HARD:
      return *(_BYTE *)(*((_QWORD *)this + 8) + 700LL) > 0;
    case RBX::HUMAN::EventType::ACTIVATE_PHYSICS:
      if ( !stru_2A08CA8.value )
        return *(_BYTE *)(*((_QWORD *)this + 8) + 734LL) != 0;
      if ( RBX::Humanoid::getCurrentStateType(*((RBX::Humanoid **)this + 8)) != RBX::HUMAN::StateType::RUNNING_NO_PHYS )
        return *(_BYTE *)(*((_QWORD *)this + 8) + 734LL) != 0;
      v2 = 1;
      if ( *((float *)this + 7) <= (float)((float)dword_2859490 / 100.0) )
        return *(_BYTE *)(*((_QWORD *)this + 8) + 734LL) != 0;
      return v2;
    case RBX::HUMAN::EventType::FINISHED:
      return *((_BYTE *)this + 10) != 0;
    case RBX::HUMAN::EventType::TIMER_UP:
      v11 = *((float *)this + 4) > 0.0;
      return !v11;
    case RBX::HUMAN::EventType::NO_TOUCH_ONE_SECOND:
      RBX::HUMAN::HumanoidState::computeTouched(this);
      if ( RBX::Humanoid::computeNearlyTouched(*((RBX::Humanoid **)this + 8)) )
        *((_DWORD *)this + 5) = 0;
      if ( stru_2A08D30.value )
        return 0;
      v12 = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
      if ( v12 )
      {
        v13 = RBX::Assembly::getPrimitiveAssembly(v12);
        if ( v13 )
        {
          if ( v13->filterPhase == Sim_OnContactBuffer )
            return 0;
        }
      }
      return RBX::HUMAN::HumanoidState::checkNoTouchOneSecond(this);
    case RBX::HUMAN::EventType::HAS_GYRO:
      value = stru_2A08C90.value;
      v15 = stru_2A08C90.value;
      ConstCharacterFromHumanoid = (const RBX::Instance *)RBX::Humanoid::getConstCharacterFromHumanoid(*((const RBX::Humanoid **)this + 8));
      v17 = RBX::Instance::findConstFirstDescendantOfType<RBX::BodyMover>(ConstCharacterFromHumanoid);
      v2 = v15 || v17 != 0;
      if ( !value || v17 )
        return v2;
      v18 = (RBX::Humanoid *)*((_QWORD *)this + 8);
      if ( !v18 )
        return 0;
      v19 = RBX::Humanoid::getTorsoPrimitiveSlow(v18);
      if ( !v19 )
        return 0;
      v20 = RBX::Assembly::getPrimitiveAssembly(v19);
      return RBX::HUMAN::HumanoidState::hasJointThatRequiresPhysicsRecurse(this, v20);
    case RBX::HUMAN::EventType::HAS_BUOYANCY:
      v2 = 1;
      if ( *((_BYTE *)this + 280) )
        return v2;
      return RBX::Humanoid::isFullySubmerged(*((RBX::Humanoid **)this + 8));
    case RBX::HUMAN::EventType::NO_BUOYANCY:
      if ( *((_BYTE *)this + 280) )
        return 0;
      return !RBX::Humanoid::isFullySubmerged(*((RBX::Humanoid **)this + 8));
    default:
      return v2;
  }
}


// Address: 0x10e1d30 | Name: _ZN3RBX5HUMAN13HumanoidState28computeTouchedByMySimulationEv
bool __fastcall RBX::HUMAN::HumanoidState::computeTouchedByMySimulation(RBX::HUMAN::HumanoidState *this)
{
  RBX::Humanoid *v2; // rdi
  __int64 v3; // r12
  RBX::PartInstance *TorsoSlow; // rax
  RBX::PartInstance *v5; // rbx
  RBX::SystemAddress LocalSimulatorAddress; // r14
  RBX::SystemAddress v7; // rdx
  RBX::PartInstance *HeadSlow; // rax
  RBX::SystemAddress v9; // rdx

  v2 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  v3 = *((_QWORD *)v2 + 308);
  if ( !v3 )
    return 0;
  TorsoSlow = RBX::Humanoid::getTorsoSlow(v2);
  if ( !TorsoSlow )
    return 0;
  v5 = TorsoSlow;
  LocalSimulatorAddress = RBX::Players::findLocalSimulatorAddress(*((const RBX::Instance **)this + 8));
  v7 = LocalSimulatorAddress;
  if ( !RBX::ContactManager::intersectingMySimulation(*(RBX::ContactManager **)(v3 + 784), v5->primitive.px, v7, 0.0) )
  {
    HeadSlow = RBX::Humanoid::getHeadSlow(*((RBX::Humanoid **)this + 8));
    if ( !HeadSlow )
      return 0;
    v9 = LocalSimulatorAddress;
    if ( !RBX::ContactManager::intersectingMySimulation(
            *(RBX::ContactManager **)(v3 + 784),
            HeadSlow->primitive.px,
            v9,
            0.0) )
      return 0;
  }
  *((_DWORD *)this + 5) = 0;
  return 1;
}


// Address: 0x10e1dd0 | Name: _ZN3RBX5HUMAN13HumanoidState27isWithinHipHeightAboveFloorEf
bool __fastcall RBX::HUMAN::HumanoidState::isWithinHipHeightAboveFloor(
        RBX::HUMAN::HumanoidState *this,
        float a2,
        float hipHeight)
{
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  __m128 v5; // xmm3

  if ( !*((_QWORD *)this + 14) )
    return 0;
  TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
  if ( !TorsoPrimitiveSlow )
    return 0;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(TorsoPrimitiveSlow);
  v5 = _mm_mul_ps((__m128)0LL, (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[1][1]);
  v5.m128_f32[0] = (float)((float)(_mm_shuffle_ps(v5, v5, 229).m128_f32[0]
                                 + (float)((float)(CoordinateFrame->rotation.elt[1][0] * 0.0) + v5.m128_f32[0]))
                         + CoordinateFrame->translation.y)
                 - *((float *)this + 34);
  return v5.m128_f32[0] >= 0.0 && a2 >= v5.m128_f32[0];
}


// Address: 0x10e1e50 | Name: _ZN3RBX5HUMAN13HumanoidState7canLandEv
bool __fastcall RBX::HUMAN::HumanoidState::canLand(RBX::HUMAN::HumanoidState *this)
{
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Primitive *v2; // rbx
  __m128 v3; // xmm1
  RBX::Primitive *v4; // rax
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  __m128 v6; // xmm3
  __m128 v8; // [rsp+0h] [rbp-38h]
  float v9; // [rsp+0h] [rbp-38h]
  RBX::Velocity v10; // [rsp+10h] [rbp-28h] BYREF

  TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
  if ( TorsoPrimitiveSlow )
  {
    v2 = TorsoPrimitiveSlow;
    RBX::Body::updatePV((RBX::Body *)((char *)TorsoPrimitiveSlow + 152));
    v8 = (__m128)*((unsigned __int64 *)v2 + 51);
    RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v10, this);
    v3 = _mm_sub_ps(v8, (__m128)*(unsigned __int64 *)&v10.linear.x);
  }
  else
  {
    v3 = 0;
  }
  if ( _mm_shuffle_ps(v3, v3, 229).m128_f32[0] > 0.0 )
    return 0;
  if ( !*((_QWORD *)this + 14) )
    return 0;
  v9 = (float)((float)dword_28594F8 * 0.0099999998) + *((float *)this + 6);
  v4 = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
  if ( !v4 )
    return 0;
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(v4);
  v6 = _mm_mul_ps((__m128)0LL, (__m128)*(unsigned __int64 *)&CoordinateFrame->rotation.elt[1][1]);
  v6.m128_f32[0] = (float)((float)(_mm_shuffle_ps(v6, v6, 229).m128_f32[0]
                                 + (float)((float)(CoordinateFrame->rotation.elt[1][0] * 0.0) + v6.m128_f32[0]))
                         + CoordinateFrame->translation.y)
                 - *((float *)this + 34);
  return v6.m128_f32[0] >= 0.0 && v9 >= v6.m128_f32[0];
}


// Address: 0x10e1f40 | Name: _ZN3RBX5HUMAN13HumanoidState27getRelativeMovementVelocityEv
RBX::Vector3 __fastcall RBX::HUMAN::HumanoidState::getRelativeMovementVelocity(RBX::HUMAN::HumanoidState *this)
{
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Primitive *v2; // rbx
  float v5; // [rsp+Ch] [rbp-3Ch]
  __m128 v6; // [rsp+10h] [rbp-38h]
  RBX::Velocity v7; // [rsp+20h] [rbp-28h] BYREF
  RBX::Vector3 result; // 0:xmm0_8.8,8:xmm1_4.4

  TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
  if ( TorsoPrimitiveSlow )
  {
    v2 = TorsoPrimitiveSlow;
    RBX::Body::updatePV((RBX::Body *)((char *)TorsoPrimitiveSlow + 152));
    v6 = (__m128)*((unsigned __int64 *)v2 + 51);
    v5 = *((float *)v2 + 104);
    RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v7, this);
    *(_QWORD *)&result.x = _mm_sub_ps(v6, (__m128)*(unsigned __int64 *)&v7.linear.x).m128_u64[0];
    result.z = v5 - v7.linear.z;
  }
  else
  {
    result.z = 0.0;
    *(_QWORD *)&result.x = 0;
  }
  return result;
}


// Address: 0x10e1fc0 | Name: _ZN3RBX5HUMAN13HumanoidState18computeHasBuoyancyEv
bool __fastcall RBX::HUMAN::HumanoidState::computeHasBuoyancy(RBX::HUMAN::HumanoidState *this)
{
  return *((_BYTE *)this + 280) || RBX::Humanoid::isFullySubmerged(*((RBX::Humanoid **)this + 8));
}


// Address: 0x10e1fe0 | Name: _ZNK3RBX5HUMAN13HumanoidState13computeJumpedEv
bool __fastcall RBX::HUMAN::HumanoidState::computeJumped(const RBX::HUMAN::HumanoidState *this)
{
  RBX::Primitive *TorsoPrimitiveFast; // rax
  __int64 v3; // rcx
  const RBX::SpatialFilter *v4; // r14
  RBX::Assembly *PrimitiveAssembly; // rsi
  __int64 v6; // rdi
  bool v7; // bl
  float v8; // xmm0_4
  __int64 v9; // r14

  TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(*((RBX::Humanoid **)this + 8));
  if ( TorsoPrimitiveFast && *((_BYTE *)TorsoPrimitiveFast + 595) )
    return 0;
  v3 = *(_QWORD *)(*((_QWORD *)this + 8) + 2464LL);
  if ( v3 )
  {
    v4 = *(const RBX::SpatialFilter **)(v3 + 856);
    if ( stru_2A08D00.value || stru_2A69178.value )
    {
      if ( TorsoPrimitiveFast )
      {
        if ( v4 )
        {
          PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast);
          if ( !RBX::SpatialFilter::canDoManualHumanoidSimulation(v4, PrimitiveAssembly) )
            return 0;
        }
      }
    }
    else if ( v4 && RBX::SpatialFilter::isForceNoClientPhysics_deprecated(v4) )
    {
      return 0;
    }
  }
  if ( RBX::Humanoid::isFullySubmerged(*((RBX::Humanoid **)this + 8))
    && (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 4 )
  {
    return 0;
  }
  if ( (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) != 13
    || (v6 = *((_QWORD *)this + 8), *(_QWORD *)(v6 + 496))
    || *((float *)this + 7) <= 0.13 )
  {
    if ( *((float *)this + 7) > 0.13
      && ((*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 8
       || (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 9
       || (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 10
       || (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 11
       || (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 14)
      || (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 12
      && !*((_BYTE *)this + 13) )
    {
      return 0;
    }
    v8 = RBX::HUMAN::HumanoidState::computeFloorTilt(this);
    v9 = *((_QWORD *)this + 8);
    if ( v9 )
    {
      if ( v8 > cosf((float)(COERCE_FLOAT(*(_QWORD *)(v9 + 680) - **(_DWORD **)(v9 + 680)) * 3.1415927) / 180.0) )
        goto LABEL_28;
    }
    else if ( v8 > 0.5 )
    {
LABEL_28:
      if ( *(char *)(v9 + 697) <= 0 )
        return 0;
LABEL_29:
      v7 = 1;
      if ( RBX::Humanoid::calculateJumpPower((RBX::Humanoid *)v9) > 0.0 )
        return v7;
      return 0;
    }
    if ( (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 8 )
      return 0;
    if ( (*(unsigned int (__fastcall **)(const RBX::HUMAN::HumanoidState *))(*(_QWORD *)this + 128LL))(this) == 10 )
      return 0;
    v9 = *((_QWORD *)this + 8);
    if ( *(char *)(v9 + 697) <= 0 )
      return 0;
    goto LABEL_29;
  }
  if ( *(char *)(v6 + 697) <= 0 )
    return 0;
  v7 = 0;
  RBX::Humanoid::setSit((RBX::Humanoid *)v6, 0);
  return v7;
}


// Address: 0x10e2220 | Name: _ZNK3RBX5HUMAN13HumanoidState13computeTippedEv
bool __fastcall RBX::HUMAN::HumanoidState::computeTipped(const RBX::HUMAN::HumanoidState *this)
{
  RBX::Body *TorsoBodyFast; // rax
  float *v2; // rbx
  bool result; // al

  TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(*((RBX::Humanoid **)this + 8));
  result = 0;
  if ( TorsoBodyFast )
  {
    v2 = (float *)TorsoBodyFast;
    RBX::Body::updatePV(TorsoBodyFast);
    if ( (float)((float)(0.0 * v2[59]) + (float)((float)(v2[53] * 0.0) + v2[56])) < 0.69999999 && !*((_BYTE *)this + 11) )
      return 1;
  }
  return result;
}


// Address: 0x10e2290 | Name: _ZNK3RBX5HUMAN13HumanoidState14computeUprightEv
bool __fastcall RBX::HUMAN::HumanoidState::computeUpright(const RBX::HUMAN::HumanoidState *this)
{
  RBX::Body *TorsoBodyFast; // rax
  float *v2; // rbx

  TorsoBodyFast = RBX::Humanoid::getTorsoBodyFast(*((RBX::Humanoid **)this + 8));
  if ( !TorsoBodyFast )
    return 1;
  v2 = (float *)TorsoBodyFast;
  RBX::Body::updatePV(TorsoBodyFast);
  return (float)((float)(0.0 * v2[59]) + (float)((float)(v2[53] * 0.0) + v2[56])) > 0.89999998;
}


// Address: 0x10e22e0 | Name: _ZN3RBX5HUMAN13HumanoidState20computeOffFloorGraceEv
bool __fastcall RBX::HUMAN::HumanoidState::computeOffFloorGrace(RBX::HUMAN::HumanoidState *this)
{
  float v1; // xmm1_4
  float v2; // xmm0_4
  bool v3; // cf
  bool v4; // zf
  float v6; // xmm0_4

  if ( !stru_2A08CA8.value )
  {
LABEL_7:
    v6 = *((float *)this + 7);
    v3 = v6 < 0.125;
    v4 = v6 == 0.125;
    return !v3 && !v4;
  }
  if ( RBX::Humanoid::getCurrentStateType(*((RBX::Humanoid **)this + 8)) != RBX::HUMAN::StateType::RUNNING )
  {
    if ( stru_2A08CA8.value
      && RBX::Humanoid::getCurrentStateType(*((RBX::Humanoid **)this + 8)) == RBX::HUMAN::StateType::RUNNING_NO_PHYS )
    {
      return 0;
    }
    goto LABEL_7;
  }
  v1 = *((float *)this + 7);
  v2 = (float)dword_2859470 / 100.0;
  v3 = v1 < v2;
  v4 = v1 == v2;
  return !v3 && !v4;
}


// Address: 0x10e2350 | Name: _ZN3RBX5HUMAN13HumanoidState31computeIsBufferZoneSimCharacterEv
bool __fastcall RBX::HUMAN::HumanoidState::computeIsBufferZoneSimCharacter(RBX::HUMAN::HumanoidState *this)
{
  bool v1; // bl
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Assembly *PrimitiveAssembly; // rax

  v1 = 1;
  if ( !stru_2A08D30.value )
  {
    TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
    if ( !TorsoPrimitiveSlow )
      return 0;
    PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveSlow);
    if ( !PrimitiveAssembly || PrimitiveAssembly->filterPhase != Sim_OnContactBuffer )
      return 0;
  }
  return v1;
}


// Address: 0x10e2390 | Name: _ZN3RBX5HUMAN13HumanoidState14computeTouchedEv
bool __fastcall RBX::HUMAN::HumanoidState::computeTouched(RBX::HUMAN::HumanoidState *this)
{
  double v1; // xmm1_8
  RBX::Humanoid *v3; // rdi
  RBX::PartInstance *v4; // rbx
  RBX::PartInstance *TorsoSlow; // rax
  RBX::Primitive *px; // rbp
  RBX::Assembly *PrimitiveAssembly; // rax
  RBX::Humanoid *v8; // rdi
  RBX::Humanoid::R15PartType v9; // r15d
  RBX::PartInstance *R15PartFast; // rax
  RBX::PartInstance *v11; // rbp
  RBX::Primitive *v12; // r12
  RBX::Collision::Contact *FirstContactNew; // rax
  RBX::Collision::Contact *NextContactNew; // rbp
  RBX::Primitive *prim0; // rdi
  RBX::PartInstance *parent; // rax
  RBX::Humanoid::AppendageType v17; // r15d
  RBX::PartInstance *AppendageFast; // rax
  RBX::PartInstance *v19; // rbp
  RBX::Primitive *v20; // r12
  RBX::Collision::Contact *v21; // rax
  RBX::Collision::Contact *v22; // rbp
  RBX::Primitive *prim1; // rdi
  RBX::PartInstance *v24; // rax
  RBX::PartInstance *VisibleTorsoSlow; // rax
  RBX::Primitive *v26; // r15
  RBX::Collision::Contact *v27; // rax
  RBX::Collision::Contact *v28; // rbp
  RBX::Primitive *v29; // rdi
  RBX::PartInstance *v30; // rax
  RBX::PartInstance *HeadSlow; // rax
  RBX::Primitive *v32; // r15
  RBX::Collision::Contact *v33; // rax
  RBX::Collision::Contact *v34; // rbp
  RBX::Primitive *v35; // rdi
  RBX::PartInstance *v36; // rax
  bool result; // al

  v3 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  v4 = (RBX::PartInstance *)*((_QWORD *)v3 + 11);
  TorsoSlow = RBX::Humanoid::getTorsoSlow(v3);
  if ( TorsoSlow )
  {
    px = TorsoSlow->primitive.px;
    PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(px);
    if ( px != RBX::Assembly::getAssemblyPrimitive(PrimitiveAssembly) )
    {
LABEL_56:
      *((_DWORD *)this + 5) = 0;
      return 1;
    }
  }
  v8 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( *((_DWORD *)v8 + 177) )
  {
    v9 = RBX::Humanoid::R15PartType::R15_HEAD;
    while ( 1 )
    {
      R15PartFast = RBX::Humanoid::getR15PartFast(v8, v9);
      if ( R15PartFast )
      {
        v11 = R15PartFast;
        if ( RBX::PartInstance::getCanCollide(R15PartFast) )
        {
          v12 = v11->primitive.px;
          FirstContactNew = RBX::Primitive::getFirstContactNew(v12);
          if ( FirstContactNew )
          {
            NextContactNew = FirstContactNew;
            do
            {
              prim0 = NextContactNew->prim0;
              if ( prim0 == v12 )
                prim0 = NextContactNew->prim1;
              parent = RBX::PartInstance::fromPrimitive(prim0);
              while ( 1 )
              {
                parent = (RBX::PartInstance *)parent->parent;
                if ( parent == v4 )
                  break;
                if ( !parent )
                {
                  if ( RBX::Collision::Contact::computeIsCollidingNonStep(NextContactNew, 0.0, v1) )
                    goto LABEL_56;
                  break;
                }
              }
              NextContactNew = RBX::Primitive::getNextContactNew(v12, NextContactNew);
            }
            while ( NextContactNew );
          }
        }
      }
      if ( ++v9 == RBX::Humanoid::R15PartType::R15_PART_COUNT )
        return 0;
      v8 = (RBX::Humanoid *)*((_QWORD *)this + 8);
    }
  }
  if ( stru_2A08D78.value )
  {
    v17 = RBX::Humanoid::AppendageType::TORSO;
    while ( 1 )
    {
      AppendageFast = RBX::Humanoid::getAppendageFast(v8, v17);
      if ( AppendageFast )
      {
        v19 = AppendageFast;
        if ( RBX::PartInstance::getCanCollide(AppendageFast) )
        {
          v20 = v19->primitive.px;
          v21 = RBX::Primitive::getFirstContactNew(v20);
          if ( v21 )
          {
            v22 = v21;
            do
            {
              prim1 = v22->prim0;
              if ( prim1 == v20 )
                prim1 = v22->prim1;
              v24 = RBX::PartInstance::fromPrimitive(prim1);
              while ( 1 )
              {
                v24 = (RBX::PartInstance *)v24->parent;
                if ( v24 == v4 )
                  break;
                if ( !v24 )
                {
                  if ( RBX::Collision::Contact::computeIsCollidingNonStep(v22, 0.0, v1) )
                    goto LABEL_56;
                  break;
                }
              }
              v22 = RBX::Primitive::getNextContactNew(v20, v22);
            }
            while ( v22 );
          }
        }
      }
      if ( ++v17 == RBX::Humanoid::AppendageType::APPENDAGE_COUNT )
        return 0;
      v8 = (RBX::Humanoid *)*((_QWORD *)this + 8);
    }
  }
  VisibleTorsoSlow = RBX::Humanoid::getVisibleTorsoSlow(v8);
  if ( !VisibleTorsoSlow )
    return 0;
  v26 = VisibleTorsoSlow->primitive.px;
  v27 = RBX::Primitive::getFirstContactNew(v26);
  if ( v27 )
  {
    v28 = v27;
    do
    {
      v29 = v28->prim0;
      if ( v29 == v26 )
        v29 = v28->prim1;
      v30 = RBX::PartInstance::fromPrimitive(v29);
      while ( 1 )
      {
        v30 = (RBX::PartInstance *)v30->parent;
        if ( v30 == v4 )
          break;
        if ( !v30 )
        {
          if ( RBX::Collision::Contact::computeIsCollidingNonStep(v28, 0.0, v1) )
            goto LABEL_56;
          break;
        }
      }
      v28 = RBX::Primitive::getNextContactNew(v26, v28);
    }
    while ( v28 );
  }
  HeadSlow = RBX::Humanoid::getHeadSlow(*((RBX::Humanoid **)this + 8));
  if ( !HeadSlow )
    return 0;
  v32 = HeadSlow->primitive.px;
  v33 = RBX::Primitive::getFirstContactNew(v32);
  if ( !v33 )
    return 0;
  v34 = v33;
  do
  {
    v35 = v34->prim0;
    if ( v35 == v32 )
      v35 = v34->prim1;
    v36 = RBX::PartInstance::fromPrimitive(v35);
    while ( 1 )
    {
      v36 = (RBX::PartInstance *)v36->parent;
      if ( v36 == v4 )
        break;
      if ( !v36 )
      {
        if ( RBX::Collision::Contact::computeIsCollidingNonStep(v34, 0.0, v1) )
          goto LABEL_56;
        break;
      }
    }
    v34 = RBX::Primitive::getNextContactNew(v32, v34);
    result = 0;
  }
  while ( v34 );
  return result;
}


// Address: 0x10e2690 | Name: _ZN3RBX5HUMAN13HumanoidState20computeNearlyTouchedEv
bool __fastcall RBX::HUMAN::HumanoidState::computeNearlyTouched(RBX::HUMAN::HumanoidState *this)
{
  if ( !RBX::Humanoid::computeNearlyTouched(*((RBX::Humanoid **)this + 8)) )
    return 0;
  *((_DWORD *)this + 5) = 0;
  return 1;
}


// Address: 0x10e26b0 | Name: _ZN3RBX5HUMAN13HumanoidState18computeTouchedHardEv
bool __fastcall RBX::HUMAN::HumanoidState::computeTouchedHard(RBX::HUMAN::HumanoidState *this)
{
  return *(_BYTE *)(*((_QWORD *)this + 8) + 700LL) > 0;
}


// Address: 0x10e26c0 | Name: _ZN3RBX5HUMAN13HumanoidState22computeActivatePhysicsEv
bool __fastcall RBX::HUMAN::HumanoidState::computeActivatePhysics(RBX::HUMAN::HumanoidState *this)
{
  bool result; // al

  if ( !stru_2A08CA8.value )
    return *(_BYTE *)(*((_QWORD *)this + 8) + 734LL) != 0;
  if ( RBX::Humanoid::getCurrentStateType(*((RBX::Humanoid **)this + 8)) != RBX::HUMAN::StateType::RUNNING_NO_PHYS )
    return *(_BYTE *)(*((_QWORD *)this + 8) + 734LL) != 0;
  result = 1;
  if ( *((float *)this + 7) <= (float)((float)dword_2859490 / 100.0) )
    return *(_BYTE *)(*((_QWORD *)this + 8) + 734LL) != 0;
  return result;
}


// Address: 0x10e2710 | Name: _ZN3RBX5HUMAN13HumanoidState21checkNoTouchOneSecondEv
bool __fastcall RBX::HUMAN::HumanoidState::checkNoTouchOneSecond(RBX::HUMAN::HumanoidState *this)
{
  float v2; // xmm0_4
  bool v3; // bp
  const RBX::Instance *v4; // rax
  const RBX::BodyMover *v5; // rax
  const RBX::BodyMover *v6; // rcx
  RBX::Humanoid *v7; // rdi
  RBX::Primitive *v8; // rax
  RBX::Assembly *v9; // rax
  bool value; // bp
  bool v11; // r14
  const RBX::Instance *ConstCharacterFromHumanoid; // rax
  const RBX::BodyMover *v13; // rcx
  bool hasJointThatRequiresPhysicsRecurse; // al
  RBX::Humanoid *v15; // rdi
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Assembly *PrimitiveAssembly; // rax
  bool result; // al
  RBX::Body *RootBodyFast; // rbx

  v2 = *((float *)this + 5);
  if ( !stru_2A08CA8.value )
  {
    if ( v2 > 1.0 )
    {
      value = stru_2A08C90.value;
      v11 = stru_2A08C90.value;
      ConstCharacterFromHumanoid = (const RBX::Instance *)RBX::Humanoid::getConstCharacterFromHumanoid(*((const RBX::Humanoid **)this + 8));
      v13 = RBX::Instance::findConstFirstDescendantOfType<RBX::BodyMover>(ConstCharacterFromHumanoid);
      hasJointThatRequiresPhysicsRecurse = v11 || v13 != 0;
      if ( value && !v13 )
      {
        v15 = (RBX::Humanoid *)*((_QWORD *)this + 8);
        if ( v15 && (TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(v15)) != 0 )
        {
          PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveSlow);
          hasJointThatRequiresPhysicsRecurse = RBX::HUMAN::HumanoidState::hasJointThatRequiresPhysicsRecurse(
                                                 this,
                                                 PrimitiveAssembly);
        }
        else
        {
          hasJointThatRequiresPhysicsRecurse = 0;
        }
      }
      return !hasJointThatRequiresPhysicsRecurse;
    }
    return 0;
  }
  if ( v2 <= 1.0 )
    return 0;
  v3 = stru_2A08C90.value;
  v4 = (const RBX::Instance *)RBX::Humanoid::getConstCharacterFromHumanoid(*((const RBX::Humanoid **)this + 8));
  v5 = RBX::Instance::findConstFirstDescendantOfType<RBX::BodyMover>(v4);
  v6 = v5;
  if ( v3 && !v5 )
  {
    v7 = (RBX::Humanoid *)*((_QWORD *)this + 8);
    if ( v7 )
    {
      v8 = RBX::Humanoid::getTorsoPrimitiveSlow(v7);
      if ( v8 )
      {
        v9 = RBX::Assembly::getPrimitiveAssembly(v8);
        if ( RBX::HUMAN::HumanoidState::hasJointThatRequiresPhysicsRecurse(this, v9) )
          return 0;
      }
    }
    goto LABEL_18;
  }
  result = 0;
  if ( !v6 && !v3 )
  {
LABEL_18:
    RootBodyFast = RBX::Humanoid::getRootBodyFast(*((RBX::Humanoid **)this + 8));
    RBX::Body::updatePV(RootBodyFast);
    return (float)((float)dword_2859480 / 100.0) > fabs(RootBodyFast->pv.velocity.linear.y);
  }
  return result;
}


// Address: 0x10e2850 | Name: _ZNK3RBX5HUMAN13HumanoidState27hasJointThatRequiresPhysicsEv
bool __fastcall RBX::HUMAN::HumanoidState::hasJointThatRequiresPhysics(const RBX::HUMAN::HumanoidState *this)
{
  bool value; // bl
  bool v3; // bp
  const RBX::Instance *ConstCharacterFromHumanoid; // rax
  const RBX::BodyMover *v5; // rcx
  bool result; // al
  RBX::Humanoid *v7; // rdi
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Assembly *PrimitiveAssembly; // rax

  value = stru_2A08C90.value;
  v3 = stru_2A08C90.value;
  ConstCharacterFromHumanoid = (const RBX::Instance *)RBX::Humanoid::getConstCharacterFromHumanoid(*((const RBX::Humanoid **)this + 8));
  v5 = RBX::Instance::findConstFirstDescendantOfType<RBX::BodyMover>(ConstCharacterFromHumanoid);
  result = v3 || v5 != 0;
  if ( value && !v5 )
  {
    v7 = (RBX::Humanoid *)*((_QWORD *)this + 8);
    if ( v7 && (TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(v7)) != 0 )
    {
      PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveSlow);
      return RBX::HUMAN::HumanoidState::hasJointThatRequiresPhysicsRecurse(this, PrimitiveAssembly);
    }
    else
    {
      return 0;
    }
  }
  return result;
}


// Address: 0x10e28c0 | Name: _ZN3RBX5HUMAN13HumanoidState9createNewENS0_9StateTypeES2_PNS_8HumanoidE
RBX::HUMAN::HumanoidState *__fastcall RBX::HUMAN::HumanoidState::createNew(
        RBX::HUMAN::StateType newType,
        RBX::HUMAN::StateType oldType,
        RBX::Humanoid *humanoid)
{
  RBX::HUMAN::FallingDown *v4; // rbx

  switch ( newType )
  {
    case RBX::HUMAN::StateType::FALLING_DWN:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x138u);
      RBX::HUMAN::FallingDown::FallingDown(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::RAGDOLL:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x138u);
      RBX::HUMAN::Ragdoll::Ragdoll(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::GETTING_UP:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x188u);
      RBX::HUMAN::GettingUp::GettingUp(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::JUMPING:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x190u);
      RBX::HUMAN::Jumping::Jumping(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::SWIMMING:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x160u);
      RBX::HUMAN::Swimming::Swimming(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::FREE_FALL:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x1B8u);
      RBX::HUMAN::Freefall::Freefall(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::FLYING:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x188u);
      RBX::HUMAN::Flying::Flying(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::LANDED:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x1D0u);
      RBX::HUMAN::Landed::Landed(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::RUNNING_SLAVE:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x1D0u);
      RBX::HUMAN::RunningSlave::RunningSlave(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::RUNNING_NO_PHYS:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x160u);
      RBX::HUMAN::RunningNoPhysics::RunningNoPhysics(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::STRAFING_NO_PHYS:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x160u);
      RBX::HUMAN::StrafingNoPhysics::StrafingNoPhysics(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::CLIMBING:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x1D0u);
      RBX::HUMAN::RunningBase::RunningBase(v4, humanoid, oldType);
      *(_QWORD *)v4 = &off_2895DD8;
      break;
    case RBX::HUMAN::StateType::SEATED:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x138u);
      RBX::HUMAN::Seated::Seated(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::PLATFORM_STANDING:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x138u);
      RBX::HUMAN::PlatformStanding::PlatformStanding(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::DEAD:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x138u);
      RBX::HUMAN::Dead::Dead(v4, humanoid, oldType);
      break;
    case RBX::HUMAN::StateType::PHYSICS:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x138u);
      RBX::HUMAN::Physics::Physics(v4, humanoid, oldType);
      break;
    default:
      v4 = (RBX::HUMAN::FallingDown *)operator new(0x1D0u);
      RBX::HUMAN::Running::Running(v4, humanoid, oldType);
      break;
  }
  return v4;
}


// Address: 0x10e2b60 | Name: _ZN3RBX5HUMAN13HumanoidState18fireMovementSignalERN3rbx6signalIFvfEEEf
void __fastcall RBX::HUMAN::HumanoidState::fireMovementSignal(
        RBX::HUMAN::HumanoidState *this,
        rbx::signal<void (float)> *movementSignal,
        __m128 a3,
        float movementVelocity)
{
  __m128 v4; // rt1
  float v5; // xmm0_4
  float v6; // xmm3_4
  __int64 v7; // xmm1_8
  bool v8; // al
  double v9; // xmm1_8

  if ( RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8)) && movementSignal->head.px )
  {
    v4.m128_i32[0] = 1056964608;
    v5 = _mm_andnot_ps(_mm_cmplt_ss(_mm_and_ps(a3, (__m128)xmmword_3E5B40), v4), a3).m128_f32[0];
    v6 = fabs(v5);
    v7 = *((unsigned int *)this + 15);
    if ( v5 <= 0.0 || (v8 = 1, *(float *)&v7 >= 0.0) )
      v8 = *(float *)&v7 > 0.0 && v5 < 0.0;
    *(_QWORD *)&v9 = v7 & 0x7FFFFFFF7FFFFFFFLL;
    if ( (float)(0.94999999 * *(float *)&v9) > v6 || (*(float *)&v9 = *(float *)&v9 * 1.05, v6 > *(float *)&v9) || v8 )
    {
      rbx::signal<void ()(float)>::operator()(movementSignal, v5, v9);
      *((float *)this + 15) = v5;
    }
  }
}


// Address: 0x10e2c20 | Name: _ZN3RBX5HUMAN13HumanoidState18getStateNameByTypeENS0_9StateTypeE
const char *__fastcall RBX::HUMAN::HumanoidState::getStateNameByType(RBX::HUMAN::StateType state)
{
  int v1; // eax
  __int64 v3; // rax

  if ( (unsigned int)state > RBX::HUMAN::StateType::PHYSICS )
    return 0;
  v1 = 130559;
  if ( !_bittest(&v1, state) )
    return 0;
  v3 = funcs_10E2C42[state]();
  if ( (*(_BYTE *)v3 & 1) != 0 )
    return *(const char **)(v3 + 16);
  else
    return (const char *)(v3 + 1);
}


// Address: 0x10e2d60 | Name: _ZNK3RBX5HUMAN13HumanoidState16computeFloorTiltEv
float __fastcall RBX::HUMAN::HumanoidState::computeFloorTilt(const RBX::HUMAN::HumanoidState *this)
{
  __int64 v2; // rax
  RBX::Primitive *v3; // r14
  RBX::Humanoid *v4; // rdi
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  const RBX::Assembly *ConstPrimitiveAssembly; // rax
  RBX::Assembly *v7; // r15
  RBX::Assembly *PrimitiveAssembly; // rax
  float v9; // xmm1_4
  float *v10; // rbx
  float *v11; // rbx

  v2 = *((_QWORD *)this + 14);
  if ( v2
    && (v3 = *(RBX::Primitive **)(v2 + 232), *((_QWORD *)v3 + 17))
    && (v4 = (RBX::Humanoid *)*((_QWORD *)this + 8)) != 0
    && (TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(v4)) != 0
    && (ConstPrimitiveAssembly = RBX::Assembly::getConstPrimitiveAssembly(TorsoPrimitiveSlow)) != 0
    && (v7 = (RBX::Assembly *)ConstPrimitiveAssembly, PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(v3), v3)
    && v7 != PrimitiveAssembly )
  {
    v9 = (float)(0.0 * *((float *)this + 36)) + *((float *)this + 37);
    v10 = (float *)((char *)this + 152);
  }
  else
  {
    v11 = (float *)*((_QWORD *)this + 8);
    v9 = (float)(0.0 * v11[219]) + v11[220];
    v10 = v11 + 221;
  }
  return (float)(0.0 * *v10) + v9;
}


// Address: 0x10e2e10 | Name: _ZN3RBX5HUMAN13HumanoidState19computeFloorIsSolidEv
bool __fastcall RBX::HUMAN::HumanoidState::computeFloorIsSolid(RBX::HUMAN::HumanoidState *this)
{
  RBX::Body *RootBodyFast; // rbp
  __int64 v2; // rax
  __int64 v3; // r14
  RBX::Humanoid *v4; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax
  RBX::Cofm *cofm; // rbx
  float *p_mass; // rbp
  float v9; // xmm0_4
  bool v10; // bp
  const RBX::Assembly *ConstPrimitiveAssembly; // rax
  __int64 v13; // rax
  __int64 v14; // rbx
  float *v15; // rax
  float v16; // xmm2_4
  float v17; // xmm0_4

  RootBodyFast = RBX::Humanoid::getRootBodyFast(*((RBX::Humanoid **)this + 8));
  v2 = *((_QWORD *)this + 14);
  if ( !v2
    || (v3 = *(_QWORD *)(v2 + 232), !*(_QWORD *)(v3 + 136))
    || (v4 = (RBX::Humanoid *)*((_QWORD *)this + 8)) == 0
    || (TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v4)) == 0
    || (PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast)) == 0
    || PrimitiveAssembly == RBX::Assembly::getPrimitiveAssembly((RBX::Primitive *)v3) )
  {
    v3 = 0;
  }
  cofm = RootBodyFast->cofm;
  if ( cofm )
  {
    RBX::Cofm::updateIfDirty(RootBodyFast->cofm);
    p_mass = &cofm->branch.mass;
LABEL_13:
    v9 = *p_mass;
    goto LABEL_14;
  }
  if ( !RootBodyFast->isMassless || (v9 = 0.0, RootBodyFast->root == RootBodyFast) )
  {
    p_mass = &RootBodyFast->bodyMass.mass;
    goto LABEL_13;
  }
LABEL_14:
  v10 = 1;
  if ( !v3 )
    return v10;
  if ( *(_BYTE *)(v3 + 595) )
    return v10;
  ConstPrimitiveAssembly = RBX::Assembly::getConstPrimitiveAssembly((const RBX::Primitive *)v3);
  if ( !ConstPrimitiveAssembly || RBX::Assembly::getAssemblyState(ConstPrimitiveAssembly) == ANCHORED )
    return v10;
  v13 = *(_QWORD *)(v3 + 200);
  v14 = *(_QWORD *)(v13 + 56);
  if ( v14 )
  {
    RBX::Cofm::updateIfDirty(*(RBX::Cofm **)(v13 + 56));
    v15 = (float *)(v14 + 24);
    v16 = v9;
LABEL_24:
    v17 = *v15;
    goto LABEL_25;
  }
  v16 = v9;
  if ( !*(_BYTE *)(v13 + 84) || (v17 = 0.0, *(_QWORD *)(v13 + 48) == v13) )
  {
    v15 = (float *)(v13 + 160);
    goto LABEL_24;
  }
LABEL_25:
  if ( (float)(v16 * (float)((float)dword_2859718 / 10.0)) > v17 )
    return 0;
  return v10;
}


// Address: 0x10e2f60 | Name: _ZNK3RBX5HUMAN13HumanoidState14computeHasGyroEv
bool __fastcall RBX::HUMAN::HumanoidState::computeHasGyro(const RBX::HUMAN::HumanoidState *this)
{
  const RBX::Instance *ConstCharacterFromHumanoid; // rax

  ConstCharacterFromHumanoid = (const RBX::Instance *)RBX::Humanoid::getConstCharacterFromHumanoid(*((const RBX::Humanoid **)this + 8));
  return RBX::Instance::findConstFirstDescendantOfType<RBX::BodyMover>(ConstCharacterFromHumanoid) != 0;
}


// Address: 0x10e2f80 | Name: _ZNK3RBX5HUMAN13HumanoidState34hasJointThatRequiresPhysicsRecurseEPNS_8AssemblyE
bool __fastcall RBX::HUMAN::HumanoidState::hasJointThatRequiresPhysicsRecurse(
        const RBX::HUMAN::HumanoidState *this,
        RBX::Assembly *a)
{
  const G3D::Array<RBX::Edge *,10,32> *AssemblyEdges; // rax
  const G3D::Array<RBX::Edge *,10,32> *v4; // r12
  __int64 v5; // rbx
  RBX::Edge *v6; // r13
  __int64 v7; // rbx
  RBX::IndexedTree *v8; // rax
  RBX::Assembly *p_children; // rsi

  if ( !a || !a->currentStage )
    return 0;
  AssemblyEdges = RBX::Assembly::getAssemblyEdges(a, 0);
  if ( AssemblyEdges->num > 0 )
  {
    v4 = AssemblyEdges;
    v5 = 0;
    do
    {
      v6 = v4->data[v5];
      if ( !(*((unsigned int (__fastcall **)(RBX::Edge *))v6->_vptr$IPipelined + 5))(v6)
        && (*((unsigned int (__fastcall **)(RBX::Edge *))v6->_vptr$IPipelined + 7))(v6) - 12 < 0xE )
      {
        return 1;
      }
    }
    while ( ++v5 < v4->num );
  }
  if ( a->children.array.num <= 0 )
    return 0;
  v7 = 0;
  while ( 1 )
  {
    v8 = a->children.array.data[v7];
    p_children = (RBX::Assembly *)&v8[-1].children;
    if ( !v8 )
      p_children = 0;
    if ( RBX::HUMAN::HumanoidState::hasJointThatRequiresPhysicsRecurse(this, p_children) )
      break;
    if ( ++v7 >= a->children.array.num )
      return 0;
  }
  return 1;
}


// Address: 0x10e3040 | Name: _ZN3RBX5HUMAN13HumanoidState28computeHitByHighImpactObjectEv
bool __fastcall RBX::HUMAN::HumanoidState::computeHitByHighImpactObject(RBX::HUMAN::HumanoidState *this)
{
  RBX::Body *RootBodyFast; // rax
  RBX::PartInstance *TorsoSlow; // rax
  RBX::Primitive *px; // r12
  int v4; // r13d
  RBX::Collision::Contact *ContactNew; // r15
  const RBX::CollisionConnector *DeepestCollision; // rax
  const RBX::CollisionConnector *v7; // rbx
  RBX::Body *bodyB; // rbp
  RBX::Body *bodyA; // rbx
  __m128 v10; // xmm1
  __m128 v11; // xmm1
  __m128 v12; // xmm2
  __m128 v13; // xmm3
  __m128 v14; // xmm4
  float v15; // xmm0_4
  __m128 v16; // xmm1
  __m128 v17; // xmm2
  __m128 v18; // xmm4
  __m128 v19; // xmm3
  __m128 v20; // xmm1
  __m128 v21; // xmm7
  __m128 v22; // xmm3
  __m128 v23; // xmm1
  __m128 v24; // xmm8
  __m128 v25; // xmm0
  float v26; // xmm0_4
  RBX::Primitive *prim0; // rax
  __m128 v28; // xmm6
  __m128 v29; // xmm5
  __m128 v30; // xmm2
  __m128 v31; // xmm3
  float v32; // xmm1_4
  __m128 v33; // xmm6
  __m128 v34; // xmm5
  __m128 v35; // xmm3
  __m128 v36; // xmm7
  __m128 v37; // xmm2
  __m128 v38; // xmm1
  __m128 v40; // [rsp+0h] [rbp-78h]
  __m128 v41; // [rsp+10h] [rbp-68h]
  __m128 v42; // [rsp+20h] [rbp-58h]
  __m128 x_low; // [rsp+30h] [rbp-48h]

  RootBodyFast = RBX::Humanoid::getRootBodyFast(*((RBX::Humanoid **)this + 8));
  RBX::Body::updatePV(RootBodyFast);
  TorsoSlow = RBX::Humanoid::getTorsoSlow(*((RBX::Humanoid **)this + 8));
  if ( TorsoSlow && (px = TorsoSlow->primitive.px) != 0 )
  {
    v4 = 0;
    if ( (int)((*((_QWORD *)px + 59) - *((_QWORD *)px + 58)) >> 4) > 0 )
    {
      while ( 1 )
      {
        ContactNew = RBX::Primitive::getContactNew(px, v4);
        DeepestCollision = RBX::Collision::Contact::getDeepestCollision(ContactNew);
        if ( DeepestCollision )
        {
          v7 = DeepestCollision;
          x_low = (__m128)LODWORD(DeepestCollision->normal.x);
          v42 = (__m128)*(unsigned __int64 *)&DeepestCollision->normal.y;
          v41 = (__m128)LODWORD(DeepestCollision->contactPoint.x);
          v40 = (__m128)*(unsigned __int64 *)&DeepestCollision->contactPoint.y;
          bodyB = DeepestCollision->bodyB;
          RBX::Body::updatePV(bodyB);
          bodyA = v7->bodyA;
          RBX::Body::updatePV(bodyA);
          v10 = _mm_mul_ps(
                  _mm_sub_ps(
                    (__m128)*(unsigned __int64 *)&bodyB->pv.velocity.linear.y,
                    (__m128)*(unsigned __int64 *)&bodyA->pv.velocity.linear.y),
                  v42);
          if ( (float)(*(_DWORD *)(*((_QWORD *)this + 8) + 752LL) ^ *(_DWORD *)(*((_QWORD *)this + 8) + 748LL)) < (float)-(float)(_mm_shuffle_ps(v10, v10, 229).m128_f32[0] + (float)((float)((float)(bodyB->pv.velocity.linear.x - bodyA->pv.velocity.linear.x) * x_low.m128_f32[0]) + v10.m128_f32[0])) )
          {
            v11 = v41;
            v11.m128_f32[0] = v41.m128_f32[0] - *((float *)px + 99);
            v12 = _mm_sub_ps(v40, (__m128)*((unsigned __int64 *)px + 50));
            v13 = (__m128)*((unsigned int *)px + 107);
            v14 = (__m128)*(unsigned __int64 *)((char *)px + 420);
            v15 = (float)(v11.m128_f32[0] * v13.m128_f32[0])
                - (float)(_mm_shuffle_ps(v12, v12, 229).m128_f32[0] * v14.m128_f32[0]);
            v16 = _mm_unpacklo_ps(v11, v12);
            v17 = _mm_mul_ps(v12, v14);
            v18 = (__m128)_mm_shuffle_epi32((__m128i)v14, 229);
            v19 = _mm_add_ps(
                    _mm_unpacklo_ps((__m128)*((unsigned int *)px + 104), (__m128)*((unsigned int *)px + 102)),
                    _mm_sub_ps(v17, _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(v13, v18, 0), v18, 226), v16)));
            v20 = _mm_shuffle_ps(v42, v42, 229);
            v21 = _mm_shuffle_ps(_mm_shuffle_ps(x_low, v20, 0), v20, 226);
            v22 = _mm_mul_ps(v19, v21);
            v23 = _mm_shuffle_ps(v22, v22, 229);
            v23.m128_f32[0] = (float)(v23.m128_f32[0] + (float)((float)(v15 + *((float *)px + 103)) * v42.m128_f32[0]))
                            + v22.m128_f32[0];
            v24.m128_i32[0] = 0;
            v25 = _mm_cmplt_ss(v23, (__m128)0LL);
            LODWORD(v26) = v25.m128_i32[0] & COERCE_UNSIGNED_INT(-v23.m128_f32[0]) | _mm_andnot_ps(v25, v23).m128_u32[0];
            prim0 = ContactNew->prim0;
            v28 = v41;
            if ( prim0 == px )
              prim0 = ContactNew->prim1;
            v28.m128_f32[0] = v41.m128_f32[0] - *((float *)prim0 + 99);
            v29 = _mm_sub_ps(v40, (__m128)*((unsigned __int64 *)prim0 + 50));
            v30 = (__m128)*((unsigned int *)prim0 + 107);
            v31 = (__m128)*(unsigned __int64 *)((char *)prim0 + 420);
            v32 = (float)(v28.m128_f32[0] * v30.m128_f32[0])
                - (float)(_mm_shuffle_ps(v29, v29, 229).m128_f32[0] * v31.m128_f32[0]);
            v33 = _mm_unpacklo_ps(v28, v29);
            v34 = _mm_mul_ps(v29, v31);
            v35 = (__m128)_mm_shuffle_epi32((__m128i)v31, 229);
            v36 = _mm_mul_ps(
                    v21,
                    _mm_add_ps(
                      _mm_unpacklo_ps((__m128)*((unsigned int *)prim0 + 104), (__m128)*((unsigned int *)prim0 + 102)),
                      _mm_sub_ps(v34, _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(v30, v35, 0), v35, 226), v33))));
            v37 = _mm_shuffle_ps(v36, v36, 229);
            v37.m128_f32[0] = (float)(v37.m128_f32[0] + (float)((float)(v32 + *((float *)prim0 + 103)) * v42.m128_f32[0]))
                            + v36.m128_f32[0];
            v38 = _mm_cmplt_ss(v37, v24);
            if ( v26 < COERCE_FLOAT(v38.m128_i32[0] & COERCE_UNSIGNED_INT(-v37.m128_f32[0]) | _mm_andnot_ps(v38, v37).m128_u32[0]) )
              break;
          }
        }
        if ( ++v4 >= (int)((*((_QWORD *)px + 59) - *((_QWORD *)px + 58)) >> 4) )
          goto LABEL_10;
      }
      LOBYTE(v4) = 1;
    }
  }
  else
  {
LABEL_10:
    LOBYTE(v4) = 0;
  }
  return v4;
}


// Address: 0x10e3350 | Name: _ZN3RBX5HUMAN13HumanoidState19AverageFloorRayCastERN5boost10shared_ptrINS_12PartInstanceEEERN3G3D7Vector3ES9_RNS_12PartMaterialES9_RibRKS8_fPNS_8AssemblyERKNS7_15CoordinateFrameE
void __fastcall RBX::HUMAN::HumanoidState::AverageFloorRayCast(
        const RBX::RbxRay *this,
        boost::shared_ptr<RBX::PartInstance> *floorPart,
        RBX::Vector3 *floorPartHitLocation,
        RBX::Vector3 *floorPartHitNormal,
        RBX::PartMaterial *floorPartHitMaterial,
        RBX::Vector3 *hitLocationAccumulator,
        float maxDistance,
        int *hitLocationCount,
        bool UpdateFloorPart,
        const RBX::Vector3 *offset,
        RBX::PartMaterial *humanoidAssembly,
        const RBX::CoordinateFrame *torsoC)
{
  __m128 x_low; // xmm3
  __m128 y_low; // xmm2
  __m128 z_low; // xmm1
  __m128 v19; // xmm4
  boost::shared_ptr<RBX::PartInstance> v20; // rax
  boost::detail::sp_counted_base *v21; // rbp
  boost::detail::sp_counted_base *pi; // rbx
  RBX::Vector3 hitNormal; // [rsp+10h] [rbp-78h] BYREF
  RBX::PartMaterial v24; // [rsp+1Ch] [rbp-6Ch]
  boost::detail::sp_counted_base *v25; // [rsp+20h] [rbp-68h] BYREF
  float v26; // [rsp+28h] [rbp-60h]
  RBX::Vector3 hitLocation; // [rsp+30h] [rbp-58h] BYREF
  unsigned __int64 v28; // [rsp+3Ch] [rbp-4Ch]
  unsigned int v29; // [rsp+44h] [rbp-44h]
  _QWORD v30[8]; // [rsp+48h] [rbp-40h] BYREF

  *(_QWORD *)&hitNormal.x = 0;
  hitNormal.z = 0.0;
  v25 = 0;
  v26 = 0.0;
  x_low = (__m128)LODWORD(offset->x);
  y_low = (__m128)LODWORD(offset->y);
  z_low = (__m128)LODWORD(offset->z);
  v19 = _mm_add_ps(
          (__m128)*(unsigned __int64 *)&torsoC->translation.x,
          _mm_add_ps(
            _mm_mul_ps(
              _mm_shuffle_ps(z_low, z_low, 224),
              _mm_unpacklo_ps((__m128)LODWORD(torsoC->rotation.elt[0][2]), (__m128)LODWORD(torsoC->rotation.elt[1][2]))),
            _mm_add_ps(
              _mm_mul_ps(
                _mm_shuffle_ps(y_low, y_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(torsoC->rotation.elt[0][1]),
                  (__m128)LODWORD(torsoC->rotation.elt[1][1]))),
              _mm_mul_ps(
                _mm_shuffle_ps(x_low, x_low, 224),
                _mm_unpacklo_ps(
                  (__m128)LODWORD(torsoC->rotation.elt[0][0]),
                  (__m128)LODWORD(torsoC->rotation.elt[1][0]))))));
  z_low.m128_f32[0] = (float)((float)(z_low.m128_f32[0] * torsoC->rotation.elt[2][2])
                            + (float)((float)(y_low.m128_f32[0] * torsoC->rotation.elt[2][1])
                                    + (float)(x_low.m128_f32[0] * torsoC->rotation.elt[2][0])))
                    + torsoC->translation.z;
  _mm_storel_ps((double *)&hitLocation.x, v19);
  LODWORD(hitLocation.z) = z_low.m128_i32[0];
  v28 = 0xBF80000080000000LL;
  v29 = 0x80000000;
  v20 = RBX::HUMAN::HumanoidState::tryFloor(
          (RBX::HUMAN::HumanoidState *)v30,
          this,
          &hitLocation,
          &hitNormal,
          maxDistance,
          (RBX::Assembly *)&v25,
          humanoidAssembly);
  v20.px = (boost::shared_ptr<RBX::PartInstance>::element_type *)v30[0];
  v21 = (boost::detail::sp_counted_base *)v30[1];
  if ( v30[0] )
  {
    hitLocationAccumulator->x = hitNormal.x + hitLocationAccumulator->x;
    hitLocationAccumulator->y = hitNormal.y + hitLocationAccumulator->y;
    hitLocationAccumulator->z = hitNormal.z + hitLocationAccumulator->z;
    ++*hitLocationCount;
    floorPartHitNormal->z = v26;
    v20.pn.pi_ = v25;
    *(_QWORD *)&floorPartHitNormal->x = v25;
    if ( UpdateFloorPart && !floorPart->px )
    {
      *floorPartHitMaterial = v24;
      *floorPartHitLocation = hitNormal;
      if ( v21 )
        _InterlockedAdd(&v21->use_count_, 1u);
      floorPart->px = v20.px;
      pi = floorPart->pn.pi_;
      floorPart->pn.pi_ = v21;
      if ( pi )
      {
        if ( !_InterlockedSub(&pi->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
      }
    }
  }
  if ( v21 && !_InterlockedSub(&v21->use_count_, 1u) )
  {
    (*((void (__fastcall **)(boost::detail::sp_counted_base *, const RBX::RbxRay *, boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base
     + 2))(
      v21,
      this,
      v20.pn.pi_);
    if ( !_InterlockedSub(&v21->weak_count_, 1u) )
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v21->_vptr$sp_counted_base + 3))(v21);
  }
}


// Address: 0x10e3580 | Name: _ZNK3RBX5HUMAN13HumanoidState12filterResultEPKNS_9PrimitiveE
RBX::HitTestFilter::Result __fastcall RBX::HUMAN::HumanoidState::filterResult(
        const RBX::HUMAN::HumanoidState *this,
        const RBX::Primitive *testMe)
{
  const RBX::Assembly *v2; // rbx
  __int64 v3; // r15
  RBX::ContactManager *v4; // r15
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::HitTestFilter::Result v6; // ebx
  const RBX::Assembly *v8; // r15

  if ( stru_2A08D90.value )
  {
    v2 = (const RBX::Assembly *)*((_QWORD *)this + 34);
    v3 = *(_QWORD *)(*((_QWORD *)this + 8) + 2464LL);
    if ( (!v2 || v2 != RBX::Assembly::getConstPrimitiveAssembly(testMe)) && !*((_BYTE *)testMe + 596) )
    {
      v4 = *(RBX::ContactManager **)(v3 + 784);
      TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(*((RBX::Humanoid **)this + 8));
      if ( RBX::ContactManager::getNoCollideJointsCount(v4, TorsoPrimitiveFast, testMe) <= 0 )
        return RBX::HitTestFilter::Result::INCLUDE_PRIM;
    }
    return RBX::HitTestFilter::Result::IGNORE_PRIM;
  }
  if ( *((_BYTE *)testMe + 594) )
    return RBX::HitTestFilter::Result::IGNORE_PRIM;
  if ( *((_BYTE *)testMe + 596) )
    return RBX::HitTestFilter::Result::IGNORE_PRIM;
  v8 = (const RBX::Assembly *)*((_QWORD *)this + 34);
  v6 = RBX::HitTestFilter::Result::INCLUDE_PRIM;
  if ( v8 )
  {
    if ( v8 == RBX::Assembly::getConstPrimitiveAssembly(testMe) )
      return RBX::HitTestFilter::Result::IGNORE_PRIM;
  }
  return v6;
}


// Address: 0x10e3640 | Name: _ZN3RBX5HUMAN13HumanoidState8tryFloorERKNS_6RbxRayERN3G3D7Vector3ES7_fPNS_8AssemblyERNS_12PartMaterialE
RBX::HUMAN::HumanoidState *__fastcall RBX::HUMAN::HumanoidState::tryFloor(
        RBX::HUMAN::HumanoidState *this,
        const RBX::HitTestFilter *ray,
        RBX::Vector3 *hitLocation,
        RBX::Vector3 *hitNormal,
        float maxDistance,
        RBX::Vector3 *humanoidAssembly,
        RBX::Assembly *recentFloorMaterial,
        RBX::PartMaterial *surfaceMaterial)
{
  int (**v9)(void); // rdi
  int (*v10)(void); // rbp
  int8_t v14; // al
  RBX::PartInstance *v15; // rax
  RBX::PartMaterial v16; // ecx
  RBX::Primitive *Hit_DEPRICATED; // rax
  RBX::Primitive *v18; // rbx
  RBX::PartInstance *v19; // rax
  RBX::RbxRay worldRay; // [rsp+8h] [rbp-A0h] BYREF
  RBX::RaycastResult raycastResult; // [rsp+20h] [rbp-88h] BYREF
  RBX::RaycastParams raycastParams; // [rsp+48h] [rbp-60h] BYREF
  __int128 v24; // [rsp+60h] [rbp-48h] BYREF

  v9 = ray[8]._vptr$HitTestFilter;
  v10 = v9[308];
  *(_OWORD *)this = 0;
  if ( v10 )
  {
    ray[34]._vptr$HitTestFilter = (int (**)(void))recentFloorMaterial;
    worldRay.m_origin = *hitLocation;
    worldRay.m_direction = hitLocation[1];
    worldRay.m_direction.x = worldRay.m_direction.x * maxDistance;
    worldRay.m_direction.y = worldRay.m_direction.y * maxDistance;
    worldRay.m_direction.z = maxDistance * worldRay.m_direction.z;
    if ( RBX::Humanoid::getTorsoPrimitiveFast((RBX::Humanoid *)v9) )
      v14 = *((_BYTE *)RBX::Humanoid::getTorsoPrimitiveFast((RBX::Humanoid *)ray[8]._vptr$HitTestFilter) + 599);
    else
      v14 = 0;
    if ( stru_2AAF2E8.value )
    {
      raycastParams.favorSet = 0;
      *(_WORD *)&raycastParams.ignoreWater = 1;
      raycastParams.filter = ray;
      raycastParams.sourceCollisionGroup = v14;
      memset(&raycastResult.hitResult, 0, sizeof(raycastResult.hitResult));
      if ( RBX::ContactManager::getHit(
             *((const RBX::ContactManager **)v10 + 98),
             &worldRay,
             &raycastParams,
             &raycastResult)
        && RBX::Assembly::getPrimitiveAssembly(raycastResult.primitive) != recentFloorMaterial )
      {
        v15 = RBX::PartInstance::fromPrimitive(raycastResult.primitive);
        RBX::shared_from<RBX::PartInstance>((boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)&v24, v15);
        *(_OWORD *)this = v24;
        v16 = raycastResult.surfaceMaterial;
        *hitNormal = raycastResult.hitResult.position;
        *humanoidAssembly = raycastResult.hitResult.normal;
        *surfaceMaterial = v16;
      }
    }
    else
    {
      Hit_DEPRICATED = RBX::ContactManager::getHit_DEPRICATED(
                         *((const RBX::ContactManager **)v10 + 98),
                         &worldRay,
                         0,
                         ray,
                         hitNormal,
                         0,
                         1,
                         humanoidAssembly,
                         surfaceMaterial,
                         0,
                         v14,
                         0);
      v18 = Hit_DEPRICATED;
      if ( Hit_DEPRICATED && RBX::Assembly::getPrimitiveAssembly(Hit_DEPRICATED) != recentFloorMaterial )
      {
        v19 = RBX::PartInstance::fromPrimitive(v18);
        RBX::shared_from<RBX::PartInstance>(
          (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)&raycastResult,
          v19);
        *(_OWORD *)this = *(_OWORD *)&raycastResult.primitive;
      }
    }
  }
  return this;
}


// Address: 0x10e3860 | Name: _ZN3RBX5HUMAN13HumanoidState21getFloorPointVelocityEv
RBX::Velocity *__fastcall RBX::HUMAN::HumanoidState::getFloorPointVelocity(
        RBX::Velocity *__return_ptr retstr,
        RBX::HUMAN::HumanoidState *this)
{
  __int64 v3; // rax
  const RBX::Primitive *v4; // r12
  RBX::Humanoid *v5; // rdi
  RBX::Primitive *TorsoPrimitiveFast; // rax
  RBX::Assembly *PrimitiveAssembly; // rax
  RBX::Assembly *v8; // r15
  RBX::Assembly *v9; // rax
  RBX::Humanoid *v10; // rdi
  __int64 v11; // r15
  const RBX::PV *PV; // rax
  __m128 v14; // xmm6
  __m128 v15; // xmm1
  __m128 v16; // xmm0
  __m128 x_low; // xmm3
  __m128 v18; // xmm5
  __m128 v19; // [rsp+0h] [rbp-58h]

  v3 = *((_QWORD *)this + 14);
  if ( v3
    && (v4 = *(const RBX::Primitive **)(v3 + 232), *((_QWORD *)v4 + 17))
    && (v5 = (RBX::Humanoid *)*((_QWORD *)this + 8)) != 0
    && (TorsoPrimitiveFast = RBX::Humanoid::getTorsoPrimitiveFast(v5)) != 0
    && (PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoPrimitiveFast)) != 0
    && (v8 = PrimitiveAssembly, v9 = RBX::Assembly::getPrimitiveAssembly(v4), v4)
    && v8 != v9
    && *((_QWORD *)v4 + 17) )
  {
    v10 = (RBX::Humanoid *)*((_QWORD *)this + 8);
    v11 = *((_QWORD *)v10 + 308);
    *(_OWORD *)&retstr->linear.x = 0;
    *(_QWORD *)&retstr->rotational.y = 0;
    if ( RBX::Humanoid::shouldNotApplyFloorVelocity(v10, v4) )
    {
      *(_OWORD *)&retstr->linear.x = 0;
      *(_QWORD *)&retstr->rotational.y = 0;
    }
    else
    {
      PV = RBX::Primitive::getPV(v4);
      v14 = (__m128)*((unsigned int *)this + 34);
      v14.m128_f32[0] = v14.m128_f32[0] - PV->position.translation.y;
      v15 = _mm_sub_ps(
              _mm_unpacklo_ps((__m128)*((unsigned int *)this + 35), (__m128)*((unsigned int *)this + 33)),
              _mm_unpacklo_ps((__m128)LODWORD(PV->position.translation.z), (__m128)LODWORD(PV->position.translation.x)));
      v16 = (__m128)*(unsigned __int64 *)&PV->velocity.rotational.y;
      x_low = (__m128)LODWORD(PV->velocity.rotational.x);
      v18 = (__m128)_mm_shuffle_epi32((__m128i)v16, 229);
      v19 = _mm_add_ps(
              (__m128)*(unsigned __int64 *)&PV->velocity.linear.x,
              _mm_sub_ps(
                _mm_mul_ps(v16, v15),
                _mm_mul_ps(_mm_shuffle_ps(_mm_shuffle_ps(x_low, v18, 0), v18, 226), _mm_unpacklo_ps(v14, v15))));
      v14.m128_f32[0] = (float)((float)(v14.m128_f32[0] * x_low.m128_f32[0])
                              - (float)(_mm_shuffle_ps(v15, v15, 229).m128_f32[0] * v16.m128_f32[0]))
                      + PV->velocity.linear.z;
      _mm_storel_ps((double *)&retstr->linear.x, v19);
      LODWORD(retstr->linear.z) = v14.m128_i32[0];
      retstr->rotational = PV->velocity.rotational;
      v16.m128_f32[0] = RBX::EThrottle::getEnvironmentSpeed((const RBX::EThrottle *)(v11 + 40));
      retstr->linear.x = v19.m128_f32[0] * v16.m128_f32[0];
      retstr->linear.y = _mm_shuffle_ps(v19, v19, 229).m128_f32[0] * v16.m128_f32[0];
      retstr->linear.z = v14.m128_f32[0] * v16.m128_f32[0];
      retstr->rotational.x = retstr->rotational.x * v16.m128_f32[0];
      retstr->rotational.y = retstr->rotational.y * v16.m128_f32[0];
      retstr->rotational.z = v16.m128_f32[0] * retstr->rotational.z;
    }
  }
  else
  {
    if ( !(_BYTE)byte_2A08DC8 && __cxa_guard_acquire(&byte_2A08DC8) )
    {
      *(_OWORD *)&vel.linear.x = 0;
      *(_QWORD *)&vel.rotational.y = 0;
      __cxa_guard_release(&byte_2A08DC8);
    }
    *retstr = vel;
  }
  return retstr;
}


// Address: 0x10e3a90 | Name: _ZN3RBX5HUMAN13HumanoidState28getComputeCharacterHipHeightEv
float __fastcall RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(RBX::HUMAN::HumanoidState *this)
{
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Humanoid *v3; // rdi
  RBX::PartInstance *LeftLegSlow; // rax
  RBX::Primitive *px; // rax
  RBX::PartInstance *RightLegSlow; // rax
  float result; // xmm0_4

  *((_DWORD *)this + 6) = 0;
  TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
  if ( TorsoPrimitiveSlow )
    *((float *)this + 6) = (float)(*(float *)(*((_QWORD *)TorsoPrimitiveSlow + 18) + 12LL) * 0.5) + *((float *)this + 6);
  v3 = (RBX::Humanoid *)*((_QWORD *)this + 8);
  if ( !*((_DWORD *)v3 + 177)
    && ((LeftLegSlow = RBX::Humanoid::getLeftLegSlow(v3)) != 0 && (px = LeftLegSlow->primitive.px) != 0
     || (RightLegSlow = RBX::Humanoid::getRightLegSlow(*((RBX::Humanoid **)this + 8))) != 0
     && (px = RightLegSlow->primitive.px) != 0) )
  {
    *((float *)this + 6) = *(float *)(*((_QWORD *)px + 18) + 12LL) + *((float *)this + 6);
  }
  result = COERCE_FLOAT(*(_QWORD *)(*((_QWORD *)this + 8) + 688LL) + **(_DWORD **)(*((_QWORD *)this + 8) + 688LL))
         + *((float *)this + 6);
  *((float *)this + 6) = result;
  return result;
}


// Address: 0x10e3b40 | Name: _ZN3RBX5HUMAN13sampleSpacingEv
float __cdecl RBX::HUMAN::sampleSpacing()
{
  return 0.14285715;
}


// Address: 0x10e3b50 | Name: _ZN3RBX5HUMAN15lowLadderSearchEPNS0_13HumanoidStateE
float __fastcall RBX::HUMAN::lowLadderSearch(RBX::HUMAN::HumanoidState *pHumanoidState)
{
  return RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(pHumanoidState) + -0.30000001;
}


// Address: 0x10e3b60 | Name: _ZN3RBX5HUMAN11searchDepthEPNS_8HumanoidE
float __fastcall RBX::HUMAN::searchDepth(RBX::Humanoid *pHumanoid)
{
  if ( pHumanoid && *((_DWORD *)pHumanoid + 177) )
    return 1.2;
  else
    return 0.69999999;
}


// Address: 0x10e3b80 | Name: _ZN3RBX5HUMAN20ladderSearchDistanceEPNS_8HumanoidE
float __fastcall RBX::HUMAN::ladderSearchDistance(RBX::Humanoid *pHumanoid)
{
  if ( pHumanoid && *((_DWORD *)pHumanoid + 177) )
    return 1.8000001;
  else
    return 1.05;
}


// Address: 0x10e3ba0 | Name: _ZN3RBX5HUMAN13HumanoidState25findPrimitiveInLadderZoneEPNS_5AdornE
bool __fastcall RBX::HUMAN::HumanoidState::findPrimitiveInLadderZone(
        RBX::HUMAN::HumanoidState *this,
        RBX::Adorn *adorn)
{
  __m128 v2; // xmm0
  RBX::Primitive *TorsoPrimitiveSlow; // rbp
  __m128 v5; // xmm1
  __int64 v6; // rax
  __m128 v7; // xmm0
  __int64 v8; // rax
  __m128 v9; // xmm2
  float v10; // xmm1_4
  __m128 v11; // xmm2
  float v12; // xmm0_4
  float v13; // xmm3_4
  __m128 v14; // xmm5
  float v15; // xmm0_4
  __int64 *v16; // r13
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // rbp
  unsigned int v20; // ebx
  _QWORD *i; // r12
  RBX::Primitive *v22; // rbp
  const RBX::Extents *FastFuzzyExtents; // rax
  _QWORD *v24; // rbp
  unsigned int v25; // r12d
  __int64 v26; // rbx
  _QWORD *v27; // rdi
  __int64 v28; // rax
  __int64 v29; // rdi
  __int64 v30; // rbp
  bool v31; // bl
  __int64 v33; // [rsp+8h] [rbp-F0h] BYREF
  float v34; // [rsp+10h] [rbp-E8h]
  __int64 v35; // [rsp+14h] [rbp-E4h] BYREF
  float v36; // [rsp+1Ch] [rbp-DCh]
  RBX::PartInstance *value[2]; // [rsp+20h] [rbp-D8h] BYREF
  RBX::Part part; // [rsp+30h] [rbp-C8h] BYREF
  __m128 v39; // [rsp+A0h] [rbp-58h]
  __m128 v40; // [rsp+B0h] [rbp-48h]
  G3D::Vector3 v41; // 0:kr00_12.12

  TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8));
  RBX::Body::updatePV((RBX::Body *)((char *)TorsoPrimitiveSlow + 152));
  v2.m128_f32[0] = RBX::HUMAN::HumanoidState::getComputeCharacterHipHeight(this);
  v5 = v2;
  v6 = *((_QWORD *)this + 8);
  if ( v6 && *(_DWORD *)(v6 + 708) )
    v7 = (__m128)0x3F666667u;
  else
    v7 = (__m128)0x3F066666u;
  v39 = v7;
  v5.m128_f32[0] = v5.m128_f32[0] + -0.30000001;
  v40 = v5;
  v41 = G3D::Matrix3::column((const G3D::Matrix3 *)TorsoPrimitiveSlow + 10, 2);
  v7.m128_i32[0] = LODWORD(v41.x);
  v7.m128_i32[1] = LODWORD(v41.y);
  v8 = *((_QWORD *)this + 8);
  if ( v8 && *(_DWORD *)(v8 + 708) )
    v9 = (__m128)0x3FE66667u;
  else
    v9 = (__m128)0x3F866666u;
  v10 = v41.z * v9.m128_f32[0];
  v11 = _mm_sub_ps(
          (__m128)*(unsigned __int64 *)((char *)TorsoPrimitiveSlow + 396),
          _mm_mul_ps(_mm_mul_ps(v7, _mm_shuffle_ps(v9, v9, 224)), *(__m128 *)&stru_3EB1B0.x));
  v12 = *((float *)TorsoPrimitiveSlow + 101) - (float)(v10 * 0.5);
  v13 = v12 - v39.m128_f32[0];
  v14 = _mm_add_ps(_mm_unpacklo_ps(v39, (__m128)0LL), v11);
  v15 = v12 + v39.m128_f32[0];
  _mm_storel_ps((double *)&v33, _mm_sub_ps(v11, _mm_unpacklo_ps(v39, v40)));
  v34 = v13;
  _mm_storel_ps((double *)&v35, v14);
  v36 = v15;
  v16 = (__int64 *)((char *)this + 168);
  G3D::Array<RBX::PartInstance *,10,32ul>::resize((G3D::Array<RBX::PartInstance *,10,32> *)((char *)this + 168), 0, 0);
  v18 = *((_QWORD *)this + 8);
  v19 = *(_QWORD *)(v18 + 2464);
  if ( v19 )
  {
    v20 = RBX::Memory::setCurrentCategory(dword_2AAF1D4);
    LOBYTE(part.type) = 0;
    *(_OWORD *)&part.gridSize.y = 0x10u;
    part.color.b = 1.0;
    *(_OWORD *)part.surfaceType.data = 0;
    (*(void (__fastcall **)(_QWORD, __int64 *, _QWORD, _QWORD, RBX::Part *))(**(_QWORD **)(*(_QWORD *)(v19 + 784) + 352LL)
                                                                           + 96LL))(
      *(_QWORD *)(*(_QWORD *)(v19 + 784) + 352LL),
      &v33,
      0,
      0,
      &part);
    if ( *(_QWORD *)&part.color.r )
    {
      for ( i = *(_QWORD **)(*(_QWORD *)&part.surfaceType.data[2] + 8LL * *(_QWORD *)&part.gridSize.y); i; i = (_QWORD *)*i )
      {
        v22 = (RBX::Primitive *)i[2];
        FastFuzzyExtents = RBX::Primitive::getFastFuzzyExtents(v22);
        if ( *(float *)&v33 <= FastFuzzyExtents->high.x
          && *((float *)&v33 + 1) <= FastFuzzyExtents->high.y
          && v34 <= FastFuzzyExtents->high.z
          && FastFuzzyExtents->low.y <= *((float *)&v35 + 1)
          && FastFuzzyExtents->low.x <= *(float *)&v35
          && FastFuzzyExtents->low.z <= v36 )
        {
          value[0] = RBX::PartInstance::fromPrimitive(v22);
          G3D::Array<RBX::PartInstance *,10,32ul>::append(
            (G3D::Array<RBX::PartInstance *,10,32> *)((char *)this + 168),
            value);
        }
      }
    }
    v24 = *(_QWORD **)&part.surfaceType.data[2];
    if ( *(_QWORD *)&part.surfaceType.data[2] )
    {
      if ( *(_QWORD *)&part.color.r )
      {
        v25 = v20;
        v26 = *(_QWORD *)&part.gridSize.y;
        v27 = *(_QWORD **)(*(_QWORD *)&part.surfaceType.data[2] + 8LL * *(_QWORD *)&part.gridSize.y);
        do
        {
          v24[v26] = *v27;
          operator delete(v27);
          --*(_QWORD *)&part.color.r;
          v27 = (_QWORD *)v24[v26];
        }
        while ( v27 );
        v24 = *(_QWORD **)&part.surfaceType.data[2];
        v20 = v25;
      }
      operator delete(v24);
      *(_OWORD *)part.surfaceType.data = 0;
    }
    RBX::Memory::setCurrentCategory(v20);
    v18 = *((_QWORD *)this + 8);
  }
  v28 = *((int *)this + 44);
  if ( v28 > 0 )
  {
    v18 = *(_QWORD *)(v18 + 88);
    v17 = *v16;
    v29 = 0;
    while ( 2 )
    {
      v30 = *(_QWORD *)(v17 + 8 * v29);
      while ( 1 )
      {
        v30 = *(_QWORD *)(v30 + 88);
        if ( v30 == v18 )
          break;
        if ( !v30 )
        {
          v31 = 1;
          if ( adorn )
          {
            RBX::PartInstance::getPart(&part, *(RBX::PartInstance **)(v17 + 8 * v29));
            *(G3D::Color3 *)value = *G3D::Color3::red();
            HIDWORD(value[1]) = 1065353216;
            RBX::Draw::selectionBox(&part, adorn, (const G3D::Color4 *)value, 0.15000001);
          }
          return v31;
        }
      }
      if ( ++v29 < v28 )
        continue;
      break;
    }
  }
  if ( adorn )
  {
    *(_OWORD *)&part.type = 0x3F800000u;
    part.color = (G3D::Color4)0x3F800000u;
    part.surfaceType.data[0] = 1065353216;
    _mm_storel_ps((double *)&part.surfaceType.data[1], (__m128)0LL);
    part.surfaceType.data[3] = NO_SURFACE;
    (*(void (__fastcall **)(RBX::Adorn *, RBX::Part *, __int64, __int64))(*(_QWORD *)adorn + 176LL))(
      adorn,
      &part,
      v17,
      v18);
    part.gridSize.y = v34;
    *(_QWORD *)&part.type = v33;
    *(_QWORD *)&part.gridSize.z = v35;
    part.color.g = v36;
    *(_OWORD *)value = xmmword_3E8560;
    (*(void (__fastcall **)(RBX::Adorn *, RBX::Part *, RBX::PartInstance **))(*(_QWORD *)adorn + 184LL))(
      adorn,
      &part,
      value);
  }
  return 0;
}


// Address: 0x10e4020 | Name: _ZN3RBX5HUMAN13HumanoidState15doLadderRaycastERKNS_6RbxRayEPNS_8HumanoidEPPNS_9PrimitiveEPN3G3D7Vector3E
void __fastcall RBX::HUMAN::HumanoidState::doLadderRaycast(
        RBX::HUMAN::HumanoidState *this,
        const RBX::RbxRay *caster,
        RBX::Humanoid *humanoid,
        RBX::Primitive **hitPrimOut,
        RBX::Vector3 *hitLocationOut)
{
  unsigned __int64 v8; // rdx
  boost::detail::sp_counted_base *pi; // rbp
  int8_t v10; // al
  boost::detail::sp_counted_base *v11; // rbx
  void *ptr[2]; // [rsp+0h] [rbp-E8h] BYREF
  __int64 v13; // [rsp+10h] [rbp-D8h]
  RBX::Vector3 surfaceNormal; // [rsp+18h] [rbp-D0h] BYREF
  RBX::HitTestFilter a; // [rsp+28h] [rbp-C0h] BYREF
  RBX::PartMaterial surfaceMaterial; // [rsp+34h] [rbp-B4h] BYREF
  RBX::RaycastParams raycastParams; // [rsp+38h] [rbp-B0h] BYREF
  RBX::FilterDescendents v18; // [rsp+50h] [rbp-98h] BYREF
  boost::shared_ptr<RBX::Instance> i; // [rsp+68h] [rbp-80h] BYREF
  RBX::RaycastResult raycastResult; // [rsp+78h] [rbp-70h] BYREF
  RBX::MergedFilter v21; // [rsp+A0h] [rbp-48h] BYREF

  if ( *((_QWORD *)humanoid + 308) )
  {
    RBX::shared_from<RBX::Instance>(&i.px, *((RBX::Instance **)humanoid + 11));
    RBX::FilterDescendents::FilterDescendents(&v18, (boost::shared_ptr<RBX::Instance>)__PAIR128__(v8, &i));
    pi = i.pn.pi_;
    if ( i.pn.pi_ )
    {
      if ( !_InterlockedSub(&i.pn.pi_->use_count_, 1u) )
      {
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 2))(pi);
        if ( !_InterlockedSub(&pi->weak_count_, 1u) )
          (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
      }
    }
    *(_OWORD *)ptr = 0;
    v13 = 0;
    a._vptr$HitTestFilter = (int (**)(void))&off_28CE9A8;
    RBX::MergedFilter::MergedFilter(&v21, &a, (const RBX::HitTestFilter *)this);
    *(_QWORD *)&surfaceNormal.x = 0;
    surfaceNormal.z = 0.0;
    if ( RBX::Humanoid::getTorsoPrimitiveFast(humanoid) )
      v10 = *((_BYTE *)RBX::Humanoid::getTorsoPrimitiveFast(humanoid) + 599);
    else
      v10 = 0;
    if ( stru_2AAF2E8.value )
    {
      raycastParams.favorSet = 0;
      *(_WORD *)&raycastParams.ignoreWater = 0;
      raycastParams.filter = &v21;
      raycastParams.sourceCollisionGroup = v10;
      memset(&raycastResult.hitResult, 0, sizeof(raycastResult.hitResult));
      if ( RBX::ContactManager::getHit(
             *(const RBX::ContactManager **)(*((_QWORD *)humanoid + 308) + 784LL),
             caster,
             &raycastParams,
             &raycastResult) )
      {
        *hitPrimOut = raycastResult.primitive;
        *hitLocationOut = raycastResult.hitResult.position;
      }
      else
      {
        *hitPrimOut = 0;
      }
    }
    else
    {
      *hitPrimOut = RBX::ContactManager::getHit_DEPRICATED(
                      *(const RBX::ContactManager **)(*((_QWORD *)humanoid + 308) + 784LL),
                      caster,
                      (const std::vector<const RBX::Primitive *> *)ptr,
                      &v21,
                      hitLocationOut,
                      0,
                      0,
                      &surfaceNormal,
                      &surfaceMaterial,
                      0,
                      v10,
                      0);
    }
    if ( ptr[0] )
    {
      ptr[1] = ptr[0];
      operator delete(ptr[0]);
    }
    v18._vptr$HitTestFilter = (int (**)(void))&off_28CE740;
    v11 = v18.inst.pn.pi_;
    if ( v18.inst.pn.pi_ && !_InterlockedSub(&v18.inst.pn.pi_->use_count_, 1u) )
    {
      (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 2))(v11);
      if ( !_InterlockedSub(&v11->weak_count_, 1u) )
        (*((void (__fastcall **)(boost::detail::sp_counted_base *))v11->_vptr$sp_counted_base + 3))(v11);
    }
  }
  else
  {
    _mm_storel_ps((double *)&hitLocationOut->x, (__m128)0LL);
    hitLocationOut->z = 0.0;
  }
}


// Address: 0x10e4300 | Name: _ZN3RBX5HUMAN13HumanoidState30firstLadderRayPosRelativeTorsoERKN3G3D7Vector3EfPNS_5AdornE
float __fastcall RBX::HUMAN::HumanoidState::firstLadderRayPosRelativeTorso(
        RBX::Humanoid **this,
        const RBX::Vector3 *torsoTranslation,
        __m128 rayCastLength,
        RBX::Adorn *adorn)
{
  RBX::Primitive *v6; // [rsp+0h] [rbp-78h] BYREF
  RBX::RbxRay caster; // [rsp+8h] [rbp-70h] BYREF
  RBX::Vector3 hitLocationOut; // [rsp+20h] [rbp-58h] BYREF
  __m128 v9; // [rsp+30h] [rbp-48h]
  _OWORD v10[3]; // [rsp+40h] [rbp-38h] BYREF

  v6 = 0;
  *(_QWORD *)&hitLocationOut.x = 0;
  hitLocationOut.z = 0.0;
  v9 = rayCastLength;
  caster.m_origin = *torsoTranslation;
  caster.m_direction.x = 0.0;
  caster.m_direction.y = -rayCastLength.m128_f32[0];
  caster.m_direction.z = 0.0;
  RBX::HUMAN::HumanoidState::doLadderRaycast(
    (RBX::HUMAN::HumanoidState *)this,
    &caster,
    *(this + 8),
    &v6,
    &hitLocationOut);
  if ( adorn )
  {
    v10[0] = 0x3F800000u;
    v10[1] = 0x3F800000u;
    v10[2] = 0x3F800000u;
    (*(void (__fastcall **)(RBX::Adorn *, _OWORD *))(*(_QWORD *)adorn + 176LL))(adorn, v10);
    *(G3D::Color3 *)v10 = *G3D::Color3::orange();
    HIDWORD(v10[0]) = 1065353216;
    (*(void (__fastcall **)(RBX::Adorn *, RBX::RbxRay *, _OWORD *))(*(_QWORD *)adorn + 256LL))(adorn, &caster, v10);
  }
  if ( v6 )
    return fminf(caster.m_origin.y - hitLocationOut.y, v9.m128_f32[0]);
  else
    return v9.m128_f32[0];
}


// Address: 0x10e4400 | Name: _ZN3RBX5HUMAN13HumanoidState16setNearlyTouchedEv
void __fastcall RBX::HUMAN::HumanoidState::setNearlyTouched(RBX::HUMAN::HumanoidState *this)
{
  *((_BYTE *)this + 8) = 1;
}


// Address: 0x10e4410 | Name: _ZN3RBX5HUMAN13HumanoidState17checkComputeEventEv
unsigned int __fastcall RBX::HUMAN::HumanoidState::checkComputeEvent(RBX::HUMAN::HumanoidState *this)
{
  __int64 v1; // rbp
  char v2; // al
  char v3; // cl
  int v4; // eax
  int v5; // r15d
  __int64 v6; // rax
  __int64 v7; // rbp
  char v8; // al
  char v9; // cl
  int v10; // eax
  int v11; // ebp
  RBX::Primitive *TorsoPrimitiveSlow; // rax
  RBX::Primitive *v13; // r14
  __m128 v14; // xmm1
  __int64 v15; // rax
  RBX::Velocity v17; // [rsp+8h] [rbp-50h] BYREF
  __m128 v18; // [rsp+20h] [rbp-38h]

  *((_BYTE *)this + 280) = 1;
  *((_BYTE *)this + 13) = 1;
  v1 = *((_QWORD *)this + 8);
  v2 = RBX::globalRand();
  v3 = 1;
  v4 = v2 & 0x7F;
  if ( v4 )
    v3 = v4;
  *(_BYTE *)(v1 + 699) = v3;
  **(_DWORD **)(*((_QWORD *)this + 8) + 712LL) = *(_QWORD *)(*((_QWORD *)this + 8) + 712LL) + 1;
  if ( *((_BYTE *)this + 280)
    || (v5 = 0, RBX::Humanoid::isFullySubmerged(*((RBX::Humanoid **)this + 8)))
    && (*((_BYTE *)this + 280) || RBX::Humanoid::isFullySubmerged(*((RBX::Humanoid **)this + 8))) )
  {
    v5 = 0;
    if ( !*((_QWORD *)this + 14) )
    {
      v6 = *((_QWORD *)this + 8);
      if ( *(char *)(v6 + 699) > 0 && **(_BYTE **)(v6 + 712) != (unsigned __int8)*(_QWORD *)(v6 + 712) )
        v5 = *((unsigned __int8 *)this + 13);
    }
  }
  *((_BYTE *)this + 280) = 0;
  *((_BYTE *)this + 13) = 0;
  v7 = *((_QWORD *)this + 8);
  v8 = RBX::globalRand();
  v9 = 1;
  v10 = v8 & 0x7F;
  if ( v10 )
    v9 = v10;
  *(_BYTE *)(v7 + 699) = -v9;
  **(_DWORD **)(*((_QWORD *)this + 8) + 712LL) = *(_QWORD *)(*((_QWORD *)this + 8) + 712LL);
  v11 = 0;
  if ( !*((_BYTE *)this + 280)
    && !RBX::Humanoid::isFullySubmerged(*((RBX::Humanoid **)this + 8))
    && !*((_BYTE *)this + 280)
    && !RBX::Humanoid::isFullySubmerged(*((RBX::Humanoid **)this + 8)) )
  {
    if ( stru_2A08D60.value )
    {
      if ( RBX::HUMAN::HumanoidState::canLand(this) )
        return v5 + v11;
      goto LABEL_25;
    }
    if ( !*((_QWORD *)this + 14)
      || ((TorsoPrimitiveSlow = RBX::Humanoid::getTorsoPrimitiveSlow(*((RBX::Humanoid **)this + 8))) == 0
        ? (v14 = 0)
        : (v13 = TorsoPrimitiveSlow,
           RBX::Body::updatePV((RBX::Body *)((char *)TorsoPrimitiveSlow + 152)),
           v18 = (__m128)*((unsigned __int64 *)v13 + 51),
           RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v17, this),
           v14 = _mm_sub_ps(v18, (__m128)*(unsigned __int64 *)&v17.linear.x)),
          _mm_shuffle_ps(v14, v14, 229).m128_f32[0] > 0.0) )
    {
LABEL_25:
      v15 = *((_QWORD *)this + 8);
      if ( *(char *)(v15 + 699) <= 0 && **(_BYTE **)(v15 + 712) == (unsigned __int8)*(_QWORD *)(v15 + 712) )
        v11 = *((unsigned __int8 *)this + 13) ^ 1;
    }
  }
  return v5 + v11;
}


// Address: 0x10e45d0 | Name: _ZN3RBX10Reflection4Type12getSingletonINS_5HUMAN9StateTypeEEERKS1_v
const RBX::Reflection::Type *__cdecl RBX::Reflection::Type::getSingleton<RBX::HUMAN::StateType>()
{
  if ( !(_BYTE)byte_2A07D70 && __cxa_guard_acquire(&byte_2A07D70) )
  {
    RBX::Reflection::EnumDesc<RBX::HUMAN::StateType>::EnumDesc((RBX::Reflection::EnumDesc<RBX::HUMAN::StateType> *)&unk_2A07CB8);
    __cxa_atexit(
      (void (*)(void *))RBX::Reflection::EnumDesc<RBX::HUMAN::StateType>::~EnumDesc,
      &unk_2A07CB8,
      &dso_handle);
    __cxa_guard_release(&byte_2A07D70);
  }
  return (const RBX::Reflection::Type *)&unk_2A07CB8;
}


// Address: 0x10e4640 | Name: _Z30_EnumRegistrar_HUMAN_StateTypev
void __cdecl _EnumRegistrar_HUMAN_StateType()
{
  if ( !(_BYTE)byte_2A07D70 )
  {
    if ( __cxa_guard_acquire(&byte_2A07D70) )
    {
      RBX::Reflection::EnumDesc<RBX::HUMAN::StateType>::EnumDesc((RBX::Reflection::EnumDesc<RBX::HUMAN::StateType> *)&unk_2A07CB8);
      __cxa_atexit(
        (void (*)(void *))RBX::Reflection::EnumDesc<RBX::HUMAN::StateType>::~EnumDesc,
        &unk_2A07CB8,
        &dso_handle);
      __cxa_guard_release(&byte_2A07D70);
    }
  }
}


// Address: 0x10e46b0 | Name: _ZN3rbx7signals17slot_with_functorIZN3RBX5HUMAN13HumanoidState28updateHumanoidPlatformStatusERN5boost10shared_ptrIS4_EEE3$_0JPNS2_9PrimitiveERN3G3D15CoordinateFrameERNS2_8VelocityEEE7do_callEPNS0_9slot_baseESB_SE_SG_
void __fastcall rbx::signals::slot_with_functor<RBX::HUMAN::HumanoidState::updateHumanoidPlatformStatus(boost::shared_ptr<RBX::HUMAN::HumanoidState> &)::$_0,RBX::Primitive *,G3D::CoordinateFrame &,RBX::Velocity &>::do_call(
        rbx::signals::slot_base *slot,
        RBX::Primitive *args,
        G3D::CoordinateFrame *a3,
        RBX::Velocity *a4)
{
  RBX::Humanoid::moveHumanoidWithFloorNetworkUpdate(
    *(RBX::Humanoid **)&slot[1].rbx::intrusive_ptr_target<rbx::signals::slot_base>,
    args,
    a3,
    a4);
}


// Address: 0x10e5210 | Name: _GLOBAL__sub_I_HumanoidState.cpp
void __cdecl GLOBAL__sub_I_HumanoidState_cpp()
{
  qword_2A08C60 = (__int64)boost::system::generic_category();
  qword_2A08C68 = (__int64)boost::system::generic_category();
  qword_2A08C70 = (__int64)boost::system::system_category();
  stru_2A08C78.value = 0;
  stru_2A08C78.name = "ImprovedAutoJump";
  dword_2A08C88 = FLog::RegisterFlag("ImprovedAutoJump", &stru_2A08C78, FastVarType::FASTVARTYPE_STATIC);
  stru_2A08C90.value = 0;
  stru_2A08C90.name = "HumanoidWithPGSConstraintsUsePhysicsState";
  dword_2A08CA0 = FLog::RegisterFlag(
                    "HumanoidWithPGSConstraintsUsePhysicsState",
                    &stru_2A08C90,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08CA8.value = 0;
  stru_2A08CA8.name = "FixCharacterJitterDownStairs";
  dword_2A08CB8 = FLog::RegisterFlag("FixCharacterJitterDownStairs", &stru_2A08CA8, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08CC0.value = 0;
  stru_2A08CC0.name = "ReduceTrussSearchDistance2";
  dword_2A08CD0 = FLog::RegisterFlag("ReduceTrussSearchDistance2", &stru_2A08CC0, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08CD8.value = 0;
  stru_2A08CD8.name = "EnforceSlaveStateEnabledStatus";
  dword_2A08CE8 = FLog::RegisterFlag("EnforceSlaveStateEnabledStatus", &stru_2A08CD8, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08CEC = FLog::RegisterInt(
                    "DelaySwitchingFromRunningToFreefallInHundredths",
                    &dword_2859470,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08CF0 = FLog::RegisterInt(
                    "NoTouchOneSecondYVelocityThresholdInHundredths",
                    &dword_2859480,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08CF4 = FLog::RegisterInt(
                    "SwitchFromRunningNoPhysToRunningThresholdInHundredths",
                    &dword_2859490,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08CF8 = FLog::RegisterInt(
                    "FreeFallFloorSearchDistanceIncreaseVelocity",
                    &dword_28594A0,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08D00.value = 0;
  stru_2A08D00.name = "BetterStreamingHumanoidSimulationFiltering";
  dword_2A08D10 = FLog::RegisterFlag(
                    "BetterStreamingHumanoidSimulationFiltering",
                    &stru_2A08D00,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08D14 = FLog::RegisterInt(
                    "ResetNetworkFloorAfterNoFloorTenthSeconds",
                    &dword_28594B8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08D18.value = 0;
  stru_2A08D18.name = "FixLadderStairsMixupCheckTorsoHeightAboveGround";
  dword_2A08D28 = FLog::RegisterFlag(
                    "FixLadderStairsMixupCheckTorsoHeightAboveGround",
                    &stru_2A08D18,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08D30.value = 0;
  stru_2A08D30.name = "DebugForceHumanoidSimulateAlways";
  dword_2A08D40 = FLog::RegisterFlag(
                    "DebugForceHumanoidSimulateAlways",
                    &stru_2A08D30,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08D44 = FLog::RegisterInt(
                    "ExtraFloorRaycastDistanceHipHeightPercent",
                    &dword_28594D8,
                    FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08D48.value = 0;
  stru_2A08D48.name = "HumanoidClimbMovingLadders";
  dword_2A08D58 = FLog::RegisterFlag("HumanoidClimbMovingLadders", &stru_2A08D48, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08D60.value = 0;
  stru_2A08D60.name = "StopDoubleJumpFix";
  dword_2A08D70 = FLog::RegisterFlag("StopDoubleJumpFix", &stru_2A08D60, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08D74 = FLog::RegisterInt("LandedTolerance", &dword_28594F8, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08D78.value = 0;
  stru_2A08D78.name = "FixRootPartCollisionForR6";
  dword_2A08D88 = FLog::RegisterFlag("FixRootPartCollisionForR6", &stru_2A08D78, FastVarType::FASTVARTYPE_DYNAMIC);
  stru_2A08D90.value = 0;
  stru_2A08D90.name = "NoCollisionConstraintHumanoidFix";
  dword_2A08DA0 = FLog::RegisterFlag("NoCollisionConstraintHumanoidFix", &stru_2A08D90, FastVarType::FASTVARTYPE_STATIC);
  dword_2A08DA8 = 0;
  if ( !(_BYTE)byte_2A07D70 && __cxa_guard_acquire(&byte_2A07D70) )
  {
    RBX::Reflection::EnumDesc<RBX::HUMAN::StateType>::EnumDesc((RBX::Reflection::EnumDesc<RBX::HUMAN::StateType> *)&unk_2A07CB8);
    __cxa_atexit(
      (void (*)(void *))RBX::Reflection::EnumDesc<RBX::HUMAN::StateType>::~EnumDesc,
      &unk_2A07CB8,
      &dso_handle);
    __cxa_guard_release(&byte_2A07D70);
  }
  dword_2A08DAC = 0;
  if ( !(_BYTE)byte_2A07D70 )
  {
    if ( __cxa_guard_acquire(&byte_2A07D70) )
    {
      RBX::Reflection::EnumDesc<RBX::HUMAN::StateType>::EnumDesc((RBX::Reflection::EnumDesc<RBX::HUMAN::StateType> *)&unk_2A07CB8);
      __cxa_atexit(
        (void (*)(void *))RBX::Reflection::EnumDesc<RBX::HUMAN::StateType>::~EnumDesc,
        &unk_2A07CB8,
        &dso_handle);
      __cxa_guard_release(&byte_2A07D70);
    }
  }
}


