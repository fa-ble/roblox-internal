// Address: 0x1e08df0 | Name: _ZN3RBX9Collision20clipQuadOnRectPlanesERKN3G3D7Vector2EPNS0_4ClipERi
void __fastcall RBX::Collision::clipQuadOnRectPlanes(const RBX::Vector2 *rect, RBX::Collision::Clip *poly, int *polySz)
{
  __int64 v3; // rax
  RBX::Collision::Clip *v5; // rax
  __int64 v6; // rbp
  float *v7; // r9
  RBX::Collision::Clip *v8; // r11
  int v9; // r14d
  __int64 v10; // r15
  RBX::Collision::Clip *v11; // rbx
  __int64 v12; // rdx
  __int64 v13; // rdx
  RBX::Collision::Clip *v14; // rax
  float v15; // xmm6_4
  __int64 v16; // rcx
  float v17; // xmm5_4
  float v18; // xmm3_4
  float v19; // xmm2_4
  float v20; // xmm4_4
  float v21; // xmm5_4
  __int64 v22; // rbp
  float v23; // xmm3_4
  __m128 v24; // xmm2
  __m128 v25; // xmm3
  __m128 v26; // xmm6
  __int64 v27; // rcx
  __int64 v28; // rbp
  __int64 v29; // rbp
  RBX::Collision::Clip *v30; // rcx
  __int64 v31; // rdx
  float v32; // xmm3_4
  __m128 v33; // xmm2
  __m128 v34; // xmm5
  __m128 v35; // xmm6
  __int64 v36; // [rsp+0h] [rbp-A8h] BYREF
  int v37; // [rsp+8h] [rbp-A0h]
  __int16 v38; // [rsp+Ch] [rbp-9Ch]
  __int64 v39; // [rsp+10h] [rbp-98h]
  int v40; // [rsp+18h] [rbp-90h]
  __int16 v41; // [rsp+1Ch] [rbp-8Ch]
  __int64 v42; // [rsp+20h] [rbp-88h]
  int v43; // [rsp+28h] [rbp-80h]
  __int16 v44; // [rsp+2Ch] [rbp-7Ch]
  __int64 v45; // [rsp+30h] [rbp-78h]
  int v46; // [rsp+38h] [rbp-70h]
  __int16 v47; // [rsp+3Ch] [rbp-6Ch]
  __int64 v48; // [rsp+40h] [rbp-68h]
  int v49; // [rsp+48h] [rbp-60h]
  __int16 v50; // [rsp+4Ch] [rbp-5Ch]
  __int64 v51; // [rsp+50h] [rbp-58h]
  int v52; // [rsp+58h] [rbp-50h]
  __int16 v53; // [rsp+5Ch] [rbp-4Ch]
  __int64 v54; // [rsp+60h] [rbp-48h]
  int v55; // [rsp+68h] [rbp-40h]
  __int16 v56; // [rsp+6Ch] [rbp-3Ch]
  __int64 v57; // [rsp+70h] [rbp-38h]
  int v58; // [rsp+78h] [rbp-30h]
  __int16 v59; // [rsp+7Ch] [rbp-2Ch]
  __int64 v60; // [rsp+80h] [rbp-28h]

  v60 = v3;
  v36 = 0;
  v37 = 0;
  v38 = 255;
  v39 = 0;
  v40 = 0;
  v41 = 255;
  v42 = 0;
  v43 = 0;
  v44 = 255;
  v45 = 0;
  v46 = 0;
  v47 = 255;
  v48 = 0;
  v49 = 0;
  v50 = 255;
  v51 = 0;
  v52 = 0;
  v53 = 255;
  v54 = 0;
  v55 = 0;
  v56 = 255;
  v57 = 0;
  v58 = 0;
  v59 = 255;
  v5 = (RBX::Collision::Clip *)&v36;
  LODWORD(v6) = *polySz;
  v7 = (float *)&unk_5702B0;
  do
  {
    v8 = v5;
    v9 = 0;
    if ( (int)v6 > 0 )
    {
      v10 = 0;
      v11 = poly;
      v9 = 0;
      do
      {
        v12 = (unsigned int)((int)++v10 >> 31);
        LODWORD(v12) = (int)v10 % (int)v6;
        v13 = v12;
        v14 = &poly[v13];
        v15 = v7[1];
        v16 = *(int *)v7;
        v17 = *(&rect->x + v16) * v15;
        v18 = *(&v11->vtx.x + v16);
        v19 = v17 - v18;
        v20 = *(&poly[v13].vtx.x + v16);
        v21 = (float)(v17 - v20) * v15;
        if ( (float)(v15 * v19) >= 0.0 )
        {
          v28 = v9++;
          v29 = v28;
          v30 = &v8[v29];
          if ( v21 < 0.0 )
          {
            v32 = fmaxf(0.0, v19 / (float)(v20 - v18));
            v33 = (__m128)0x3F800000u;
            v33.m128_f32[0] = fminf(1.0, v32);
            v34 = (__m128)0x3F800000u;
            v34.m128_f32[0] = 1.0 - v33.m128_f32[0];
            v35 = _mm_add_ps(
                    _mm_mul_ps(_mm_shuffle_ps(v34, v34, 224), (__m128)*(unsigned __int64 *)&v11->vtx.x),
                    _mm_mul_ps(_mm_shuffle_ps(v33, v33, 224), (__m128)*(unsigned __int64 *)&v14->vtx.x));
            v34.m128_f32[0] = (float)((float)(1.0 - v33.m128_f32[0]) * v11->vtx.z)
                            + (float)(v33.m128_f32[0] * poly[v13].vtx.z);
            _mm_storel_ps((double *)&v30->vtx.x, v35);
            LODWORD(v8[v29].vtx.z) = v34.m128_i32[0];
            *(&v30->vtx.x + *(int *)v7) = v7[1] * *(&rect->x + *(int *)v7);
            v8[v29].idx = -1;
          }
          else
          {
            v31 = *(_QWORD *)&v14->vtx.x;
            *(_QWORD *)((char *)&v30->vtx.y + 2) = *(_QWORD *)((char *)&v14->vtx.y + 2);
            *(_QWORD *)&v30->vtx.x = v31;
          }
        }
        else if ( v21 >= 0.0 )
        {
          v22 = v9;
          v23 = fmaxf(0.0, v19 / (float)(v20 - v18));
          v24 = (__m128)0x3F800000u;
          v24.m128_f32[0] = fminf(1.0, v23);
          v25 = (__m128)0x3F800000u;
          v25.m128_f32[0] = 1.0 - v24.m128_f32[0];
          v26 = _mm_add_ps(
                  _mm_mul_ps(_mm_shuffle_ps(v25, v25, 224), (__m128)*(unsigned __int64 *)&v11->vtx.x),
                  _mm_mul_ps(_mm_shuffle_ps(v24, v24, 224), (__m128)*(unsigned __int64 *)&v14->vtx.x));
          v25.m128_f32[0] = (float)((float)(1.0 - v24.m128_f32[0]) * v11->vtx.z)
                          + (float)(v24.m128_f32[0] * poly[v13].vtx.z);
          _mm_storel_ps((double *)&v8[v22].vtx.x, v26);
          LODWORD(v8[v22].vtx.z) = v25.m128_i32[0];
          *(&v8[v22].vtx.x + *(int *)v7) = v7[1] * *(&rect->x + *(int *)v7);
          v8[v22].idx = -1;
          v9 += 2;
          v27 = *(_QWORD *)&v14->vtx.x;
          *(_QWORD *)((char *)&v8[v22 + 1].vtx.y + 2) = *(_QWORD *)((char *)&v14->vtx.y + 2);
          *(_QWORD *)&v8[v22 + 1].vtx.x = v27;
        }
        v6 = *polySz;
        ++v11;
      }
      while ( v10 < v6 );
    }
    *polySz = v9;
    v7 += 2;
    LODWORD(v6) = v9;
    v5 = poly;
    poly = v8;
  }
  while ( v7 != (float *)&unk_5702D0 );
}


// Address: 0x1e090d0 | Name: _ZN3RBX9Collision15getBlockFaceMatENS_8NormalIdE
const RBX::Matrix3 *__fastcall RBX::Collision::getBlockFaceMat(RBX::NormalId faceNormalID)
{
  return (const RBX::Matrix3 *)((char *)&unk_5702D0 + 36 * (unsigned int)faceNormalID);
}


// Address: 0x1e09230 | Name: _ZN3RBX9Collision16filterClipPointsEPNS0_4ClipEiffPiRi
void __fastcall RBX::Collision::filterClipPoints(
        RBX::Collision::Clip *pts,
        int ptsCount,
        float faceZ,
        float negOverlap,
        int *idx,
        int *idxCount)
{
  int v8; // r9d
  __int64 v9; // rax
  float v10; // xmm2_4
  int8_t *p_fbelow; // rbp
  float v12; // xmm3_4
  float v13; // xmm3_4
  float v14; // xmm3_4
  int v15; // edx
  int v16; // r12d
  int v17; // ecx
  RBX::Collision::Clip *v18; // r10
  int v19; // ebx
  float v20; // xmm0_4
  __int64 v21; // rax
  __m128 v22; // xmm1
  __m128 v23; // xmm1
  float v24; // xmm1_4
  __m128 v25; // xmm0
  __m128 v26; // xmm1
  __m128 v27; // xmm2
  __m128 v28; // xmm2
  int v29; // ebp
  float v30; // xmm4_4
  __m128 v31; // xmm5
  float v32; // xmm5_4
  int v33; // edx
  __m128 v34; // xmm2
  int v35; // ecx
  float v36; // xmm4_4
  __m128 v37; // xmm5
  __m128 v38; // xmm5
  float v39; // xmm6_4
  float v40; // xmm2_4
  int v41; // r15d
  __int64 v42; // r11
  int v43; // r13d
  __int64 v44; // rbx
  int v45; // edx
  int v46; // ecx
  float v47; // xmm3_4
  __m128 v48; // xmm4
  __m128 v49; // xmm5
  __m128 v50; // xmm5
  float v51; // xmm6_4
  int *v52; // rbx
  int v53; // eax
  __int64 v54; // rax

  if ( ptsCount <= 0 )
    goto LABEL_34;
  if ( ptsCount == 1 )
  {
    v8 = -1;
    v9 = 0;
    v10 = negOverlap;
LABEL_13:
    v14 = pts[v9].vtx.z - faceZ;
    if ( negOverlap >= v14 )
    {
      pts[v9].fbelow = 1;
      if ( v10 >= v14 )
        v8 = v9;
    }
    goto LABEL_16;
  }
  p_fbelow = &pts[1].fbelow;
  v8 = -1;
  v9 = 0;
  v10 = negOverlap;
  do
  {
    v12 = *(float *)(p_fbelow - 21) - faceZ;
    if ( negOverlap >= v12 )
    {
      *(p_fbelow - 16) = 1;
      if ( v10 >= v12 )
      {
        v8 = v9;
        v10 = v12;
      }
    }
    v13 = *(float *)(p_fbelow - 5) - faceZ;
    if ( negOverlap >= v13 )
    {
      *p_fbelow = 1;
      if ( v10 >= v13 )
      {
        v8 = v9 + 1;
        v10 = v13;
      }
    }
    v9 += 2;
    p_fbelow += 32;
  }
  while ( (unsigned int)ptsCount - (unsigned __int64)(ptsCount & 1) != v9 );
  if ( (ptsCount & 1) != 0 )
    goto LABEL_13;
LABEL_16:
  if ( v8 == -1 )
  {
LABEL_34:
    v16 = 0;
    goto LABEL_35;
  }
  *idx = v8;
  v15 = (v8 + 1) % ptsCount;
  v16 = 1;
  if ( v15 != v8 )
  {
    v17 = (v8 + 1) % ptsCount;
    v18 = &pts[v8];
    v19 = -1;
    v20 = 0.0;
    do
    {
      v21 = v15;
      if ( pts[v21].fbelow )
      {
        v22 = _mm_sub_ps(
                _mm_unpacklo_ps((__m128)LODWORD(v18->vtx.x), (__m128)LODWORD(v18->vtx.z)),
                _mm_unpacklo_ps((__m128)LODWORD(pts[v15].vtx.x), (__m128)LODWORD(pts[v15].vtx.z)));
        v23 = _mm_mul_ps(v22, v22);
        v24 = _mm_shuffle_ps(v23, v23, 229).m128_f32[0]
            + (float)((float)((float)(v18->vtx.y - pts[v21].vtx.y) * (float)(v18->vtx.y - pts[v21].vtx.y))
                    + v23.m128_f32[0]);
        if ( v24 > v20 )
          v19 = v15;
        v20 = fmaxf(v24, v20);
      }
      v15 = (v15 + 1) % ptsCount;
    }
    while ( v15 != v8 );
    if ( v19 != -1 )
    {
      idx[1] = v19;
      v25 = (__m128)*(unsigned __int64 *)&v18->vtx.x;
      v26 = (__m128)*(unsigned __int64 *)&pts[v19].vtx.x;
      if ( v17 != v19 )
      {
        v27 = _mm_sub_ps(v26, v25);
        v28 = _mm_shuffle_ps(v27, v27, 225);
        v29 = -1;
        v30 = 0.0;
        do
        {
          if ( pts[v17].fbelow )
          {
            v31 = _mm_mul_ps(_mm_sub_ps((__m128)*(unsigned __int64 *)&pts[v17].vtx.x, v25), v28);
            v32 = fabs(v31.m128_f32[0] - _mm_shuffle_ps(v31, v31, 229).m128_f32[0]);
            if ( v32 > v30 )
              v29 = v17;
            v30 = fmaxf(v32, v30);
          }
          v17 = (v17 + 1) % ptsCount;
        }
        while ( v17 != v19 );
        if ( v29 != -1 )
        {
          idx[2] = v19;
          idx[1] = v29;
          goto LABEL_45;
        }
      }
      v33 = (v19 + 1) % ptsCount;
      v16 = 2;
      if ( v33 != v8 )
      {
        v34 = _mm_sub_ps(v25, v26);
        v35 = -1;
        v36 = 0.0;
        do
        {
          if ( pts[v33].fbelow )
          {
            v37 = _mm_sub_ps((__m128)*(unsigned __int64 *)&pts[v33].vtx.x, v26);
            v38 = _mm_mul_ps(_mm_shuffle_ps(v37, v37, 225), v34);
            v39 = fabs(_mm_shuffle_ps(v38, v38, 229).m128_f32[0] - v38.m128_f32[0]);
            if ( v39 > v36 )
              v35 = v33;
            v36 = fmaxf(v39, v36);
          }
          v33 = (v33 + 1) % ptsCount;
        }
        while ( v33 != v8 );
        if ( v35 != -1 )
        {
          idx[2] = v35;
LABEL_45:
          v40 = 0.0;
          v41 = -1;
          v42 = 0;
          v43 = -1;
          while ( 1 )
          {
            v44 = idx[(unsigned __int8)(v42 + 1) % 3u];
            v45 = (v8 + 1) % ptsCount;
            v46 = -1;
            v47 = 0.0;
            if ( v45 != (_DWORD)v44 )
            {
              v48 = _mm_sub_ps((__m128)*(unsigned __int64 *)&pts[v44].vtx.x, v25);
              v46 = -1;
              v47 = 0.0;
              do
              {
                if ( pts[v45].fbelow )
                {
                  v49 = _mm_sub_ps((__m128)*(unsigned __int64 *)&pts[v45].vtx.x, v25);
                  v50 = _mm_mul_ps(_mm_shuffle_ps(v49, v49, 225), v48);
                  v51 = fabs(_mm_shuffle_ps(v50, v50, 229).m128_f32[0] - v50.m128_f32[0]);
                  if ( v51 > v47 )
                    v46 = v45;
                  v47 = fmaxf(v51, v47);
                }
                v45 = (v45 + 1) % ptsCount;
              }
              while ( v45 != (_DWORD)v44 );
            }
            if ( v47 > v40 )
            {
              v41 = v42;
              v43 = v46;
            }
            if ( v42 == 2 )
              break;
            v8 = idx[v42 + 1];
            v25 = (__m128)*(unsigned __int64 *)&pts[v8].vtx.x;
            ++v42;
            v40 = fmaxf(v47, v40);
          }
          if ( v43 == -1 )
          {
            v16 = 3;
          }
          else
          {
            idx[3] = v43;
            v16 = 4;
            if ( v41 != 2 )
            {
              v52 = &idx[v41 + 1];
              if ( v41 == 1 )
              {
                v53 = *v52;
                *v52 = v43;
                idx[3] = v53;
              }
              else
              {
                v54 = 4 * (v41 + 1LL);
                if ( v54 != 12 )
                  memmove((char *)idx - (12 - v54) + 16, v52, 12 - v54);
                *v52 = v43;
              }
            }
          }
        }
      }
    }
  }
LABEL_35:
  *idxCount = v16;
}


// Address: 0x1e09630 | Name: _GLOBAL__sub_I_CollisionUtilities.cpp
void __cdecl GLOBAL__sub_I_CollisionUtilities_cpp()
{
  qword_2AAF770 = (__int64)boost::system::generic_category();
  qword_2AAF778 = (__int64)boost::system::generic_category();
  qword_2AAF780 = (__int64)boost::system::system_category();
}


