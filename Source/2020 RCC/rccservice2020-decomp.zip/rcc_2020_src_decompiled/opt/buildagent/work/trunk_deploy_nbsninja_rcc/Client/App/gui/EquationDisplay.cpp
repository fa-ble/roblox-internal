// Address: 0x1788da0 | Name: _ZN3RBX15EquationDisplayC2ERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_
void __fastcall RBX::EquationDisplay::EquationDisplay(
        RBX::EquationDisplay *this,
        const std::string *title,
        const std::string *eqText)
{
  RBX::TextDisplay::TextDisplay(this, title, title);
  *(_QWORD *)this = off_28DFB80;
  std::string::basic_string((char *)this + 184, eqText);
  *((_OWORD *)this + 13) = 0;
  *((_QWORD *)this + 28) = 0;
  *((_BYTE *)this + 208) = 22;
  *(_QWORD *)((char *)this + 209) = 0x2061746164206F4ELL;
  *(_DWORD *)((char *)this + 217) = (_DWORD)&unk_746579;
  *((_DWORD *)this + 58) = 0;
  *((RBX::Time *)this + 30) = RBX::Time::now<(RBX::Time::SampleMethod)2>();
}


// Address: 0x1788e90 | Name: _ZN3RBX15EquationDisplayC2ERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_S9_
void __fastcall RBX::EquationDisplay::EquationDisplay(
        RBX::EquationDisplay *this,
        const std::string *title,
        const std::string *label,
        const std::string *eqText)
{
  RBX::TextDisplay::TextDisplay(this, title, label);
  *(_QWORD *)this = off_28DFB80;
  std::string::basic_string((char *)this + 184, eqText);
  *((_OWORD *)this + 13) = 0;
  *((_QWORD *)this + 28) = 0;
  *((_BYTE *)this + 208) = 22;
  *(_QWORD *)((char *)this + 209) = 0x2061746164206F4ELL;
  *(_DWORD *)((char *)this + 217) = (_DWORD)&unk_746579;
  *((_DWORD *)this + 58) = 0;
  *((RBX::Time *)this + 30) = RBX::Time::now<(RBX::Time::SampleMethod)2>();
}


// Address: 0x1788f80 | Name: _ZN3RBX15EquationDisplayC2ERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_i
void __fastcall RBX::EquationDisplay::EquationDisplay(
        RBX::EquationDisplay *this,
        const std::string *title,
        const std::string *eqText,
        const int userCount)
{
  RBX::TextDisplay::TextDisplay(this, title, title);
  *(_QWORD *)this = off_28DFB80;
  std::string::basic_string((char *)this + 184, eqText);
  *((_OWORD *)this + 13) = 0;
  *((_QWORD *)this + 28) = 0;
  *((_BYTE *)this + 208) = 22;
  *(_QWORD *)((char *)this + 209) = 0x2061746164206F4ELL;
  *(_DWORD *)((char *)this + 217) = (_DWORD)&unk_746579;
  *((_DWORD *)this + 58) = userCount;
  *((RBX::Time *)this + 30) = RBX::Time::now<(RBX::Time::SampleMethod)2>();
}


// Address: 0x1789070 | Name: _ZN3RBX15EquationDisplay8getLabelEv
RBX::EquationDisplay *__fastcall RBX::EquationDisplay::getLabel(RBX::EquationDisplay *this, __int64 a2)
{
  __int64 v2; // r12
  _WORD *v3; // r15
  unsigned __int64 v4; // rdx
  __int64 v5; // r15
  unsigned __int64 v6; // rdx
  __int64 v7; // rax
  __int128 v9; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  v2 = *((_QWORD *)RBX::GuiItem::getRootAncestor((RBX::GuiItem *)a2) + 14);
  if ( v2 )
  {
    v3 = (_WORD *)(a2 + 208);
    if ( RBX::Time::now<(RBX::Time::SampleMethod)2>().sec - *(double *)(a2 + 240) >= (double)*(int *)(a2 + 232)
      || !(unsigned int)std::string::compare(a2 + 208, "No data yet") )
    {
      (*(void (__fastcall **)(__int128 *, __int64, __int64))(*(_QWORD *)v2 + 16LL))(&v9, v2, a2 + 184);
      if ( (*(_BYTE *)(a2 + 208) & 1) != 0 )
      {
        **(_BYTE **)(a2 + 224) = 0;
        *(_QWORD *)(a2 + 216) = 0;
      }
      else
      {
        *v3 = 0;
      }
      std::string::reserve(a2 + 208, 0);
      *(_QWORD *)(a2 + 224) = ptr;
      *(_OWORD *)v3 = v9;
      *(RBX::Time *)(a2 + 240) = RBX::Time::now<(RBX::Time::SampleMethod)2>();
    }
    std::operator+<char>((__int64)&v9, (unsigned __int8 *)(a2 + 112), " ");
    v4 = *(unsigned __int8 *)(a2 + 208);
    if ( (v4 & 1) != 0 )
    {
      v5 = *(_QWORD *)(a2 + 224);
      v6 = *(_QWORD *)(a2 + 216);
    }
    else
    {
      v5 = a2 + 209;
      v6 = v4 >> 1;
    }
    v7 = std::string::append(&v9, v5, v6);
    *((_QWORD *)this + 2) = *(_QWORD *)(v7 + 16);
    *(_OWORD *)this = *(_OWORD *)v7;
    *(_OWORD *)v7 = 0;
    *(_QWORD *)(v7 + 16) = 0;
    if ( (v9 & 1) != 0 )
      operator delete(ptr);
  }
  else
  {
    std::string::basic_string(this, a2 + 112);
  }
  return this;
}


// Address: 0x17891f0 | Name: _ZN3RBX15EquationDisplay8render2dEPNS_11LegacyAdornERKN3G3D7Vector2E
void __fastcall RBX::EquationDisplay::render2d(
        RBX::EquationDisplay *this,
        RBX::LegacyAdorn *adorn,
        const RBX::Vector2 *pos)
{
  _BYTE v4[16]; // [rsp+0h] [rbp-38h] BYREF
  void *ptr; // [rsp+10h] [rbp-28h]

  if ( *((_BYTE *)this + 176) )
  {
    RBX::EquationDisplay::getLabel((RBX::EquationDisplay *)v4, (__int64)this);
    (*((void (__fastcall **)(RBX::LegacyAdorn *, _BYTE *, const RBX::Vector2 *, _QWORD, char *))adorn->_vptr$LegacyAdorn
     + 4))(
      adorn,
      v4,
      pos,
      *((unsigned int *)this + 34),
      (char *)this + 140);
    if ( (v4[0] & 1) != 0 )
      operator delete(ptr);
  }
}


// Address: 0x1789360 | Name: _GLOBAL__sub_I_EquationDisplay.cpp
void __cdecl GLOBAL__sub_I_EquationDisplay_cpp()
{
  qword_2A41458 = (__int64)boost::system::generic_category();
  qword_2A41460 = (__int64)boost::system::generic_category();
  qword_2A41468 = (__int64)boost::system::system_category();
}


