// Address: 0x10e9260 | Name: _ZN3RBX5HUMAN7Ragdoll18onComputeForceImplEv
void __fastcall RBX::HUMAN::Ragdoll::onComputeForceImpl(RBX::HUMAN::Ragdoll *this)
{
  ;
}


// Address: 0x10e9270 | Name: _ZNK3RBX5HUMAN7Ragdoll17armsShouldCollideEv
bool __fastcall RBX::HUMAN::Ragdoll::armsShouldCollide(const RBX::HUMAN::Ragdoll *this)
{
  return 1;
}


// Address: 0x10e9280 | Name: _ZNK3RBX5HUMAN7Ragdoll17legsShouldCollideEv
bool __fastcall RBX::HUMAN::Ragdoll::legsShouldCollide(const RBX::HUMAN::Ragdoll *this)
{
  return 1;
}


// Address: 0x10e9290 | Name: _ZNK3RBX5HUMAN7Ragdoll14enableAutoJumpEv
bool __fastcall RBX::HUMAN::Ragdoll::enableAutoJump(const RBX::HUMAN::Ragdoll *this)
{
  return 0;
}


// Address: 0x10e92a0 | Name: _ZNK3RBX5HUMAN7Ragdoll12getStateTypeEv
RBX::HUMAN::StateType __fastcall RBX::HUMAN::Ragdoll::getStateType(const RBX::HUMAN::Ragdoll *this)
{
  return RBX::HUMAN::StateType::RAGDOLL;
}


