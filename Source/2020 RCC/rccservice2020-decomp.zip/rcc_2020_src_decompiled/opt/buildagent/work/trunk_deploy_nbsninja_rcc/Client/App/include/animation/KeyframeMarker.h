// Address: 0x106d990 | Name: _ZNK3RBX14KeyframeMarker8getValueEv
RBX::KeyframeMarker *__fastcall RBX::KeyframeMarker::getValue(RBX::KeyframeMarker *this, __int64 a2)
{
  std::string::basic_string(this, a2 + 128);
  return this;
}


// Address: 0x106da10 | Name: _ZN3RBX14KeyframeMarkerD2Ev
void __fastcall RBX::KeyframeMarker::~KeyframeMarker(RBX::KeyframeMarker *this)
{
  *(_QWORD *)this = &off_28912A8;
  if ( (*((_BYTE *)this + 128) & 1) != 0 )
    operator delete(*((void **)this + 18));
  RBX::Instance::~Instance((RBX::Instance *)this);
}


// Address: 0x106da40 | Name: _ZN3RBX14KeyframeMarkerD0Ev
void __fastcall RBX::KeyframeMarker::~KeyframeMarker(RBX::KeyframeMarker *this)
{
  *(_QWORD *)this = &off_28912A8;
  if ( (*((_BYTE *)this + 128) & 1) != 0 )
    operator delete(*((void **)this + 18));
  RBX::Instance::~Instance((RBX::Instance *)this);
  operator delete(this);
}


// Address: 0x106dab0 | Name: _ZNK3RBX14KeyframeMarker11askAddChildEPKNS_8InstanceE
bool __fastcall RBX::KeyframeMarker::askAddChild(const RBX::KeyframeMarker *this, const RBX::Instance *instance)
{
  const RBX::Reflection::ClassDescriptor *descriptor; // rbx
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax

  if ( !instance )
    return 0;
  descriptor = instance->descriptor;
  DescriptorPtr = Class_getDescriptorPtr(this);
  return *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364);
}


// Address: 0x106daf0 | Name: _ZN3RBX14KeyframeMarker12onChildAddedEPNS_8InstanceE
void __fastcall RBX::KeyframeMarker::onChildAdded(RBX::KeyframeMarker *this, RBX::Instance *child)
{
  RBX::Keyframe *v3; // r14
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v6; // r14
  RBX::Reflection::ClassDescriptor *v7; // rax

  while ( 1 )
  {
    v3 = (RBX::Keyframe *)*((_QWORD *)this + 11);
    if ( !v3 )
      break;
    descriptor = v3->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      RBX::Keyframe::invalidate(v3);
      return;
    }
    this = (RBX::KeyframeMarker *)*((_QWORD *)this + 11);
    if ( this )
    {
      v6 = *((_QWORD *)this + 3);
      v7 = Class_getDescriptorPtr(0);
      if ( *(unsigned __int16 *)(v6 + 726) - (unsigned int)*((unsigned __int16 *)v7 + 363) <= *((unsigned __int16 *)v7
                                                                                              + 364) )
        continue;
    }
    return;
  }
}


// Address: 0x106db80 | Name: _ZN3RBX14KeyframeMarker14onChildRemovedEPNS_8InstanceE
void __fastcall RBX::KeyframeMarker::onChildRemoved(RBX::KeyframeMarker *this, RBX::Instance *child)
{
  RBX::Keyframe *v3; // r14
  const RBX::Reflection::ClassDescriptor *descriptor; // r15
  RBX::Reflection::ClassDescriptor *DescriptorPtr; // rax
  __int64 v6; // r14
  RBX::Reflection::ClassDescriptor *v7; // rax

  while ( 1 )
  {
    v3 = (RBX::Keyframe *)*((_QWORD *)this + 11);
    if ( !v3 )
      break;
    descriptor = v3->descriptor;
    DescriptorPtr = Class_getDescriptorPtr(0);
    if ( *((unsigned __int16 *)descriptor + 363) - (unsigned int)*((unsigned __int16 *)DescriptorPtr + 363) <= *((unsigned __int16 *)DescriptorPtr + 364) )
    {
      RBX::Keyframe::invalidate(v3);
      return;
    }
    this = (RBX::KeyframeMarker *)*((_QWORD *)this + 11);
    if ( this )
    {
      v6 = *((_QWORD *)this + 3);
      v7 = Class_getDescriptorPtr(0);
      if ( *(unsigned __int16 *)(v6 + 726) - (unsigned int)*((unsigned __int16 *)v7 + 363) <= *((unsigned __int16 *)v7
                                                                                              + 364) )
        continue;
    }
    return;
  }
}


