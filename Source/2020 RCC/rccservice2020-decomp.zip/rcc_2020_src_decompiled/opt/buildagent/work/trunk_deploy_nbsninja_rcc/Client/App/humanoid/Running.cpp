// Address: 0x10e9340 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN7RunningE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Running *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08F30;
  if ( !qword_2A08F30 )
  {
    result = RBX::Name::declare("Running");
    qword_2A08F30 = result;
  }
  return result;
}


// Address: 0x10e9370 | Name: _ZNK3RBX5HUMAN7Running7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Running::getName(const RBX::HUMAN::Running *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08F30;
  if ( !qword_2A08F30 )
  {
    result = RBX::Name::declare("Running");
    qword_2A08F30 = result;
  }
  return result;
}


// Address: 0x10e93a0 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN12RunningSlaveE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::RunningSlave *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08F38;
  if ( !qword_2A08F38 )
  {
    result = RBX::Name::declare("RunningSlave");
    qword_2A08F38 = result;
  }
  return result;
}


// Address: 0x10e93d0 | Name: _ZNK3RBX5HUMAN12RunningSlave7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::RunningSlave::getName(const RBX::HUMAN::RunningSlave *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08F38;
  if ( !qword_2A08F38 )
  {
    result = RBX::Name::declare("RunningSlave");
    qword_2A08F38 = result;
  }
  return result;
}


// Address: 0x10e9400 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN6LandedE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Landed *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08F40;
  if ( !qword_2A08F40 )
  {
    result = RBX::Name::declare("Landed");
    qword_2A08F40 = result;
  }
  return result;
}


// Address: 0x10e9430 | Name: _ZNK3RBX5HUMAN6Landed7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Landed::getName(const RBX::HUMAN::Landed *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08F40;
  if ( !qword_2A08F40 )
  {
    result = RBX::Name::declare("Landed");
    qword_2A08F40 = result;
  }
  return result;
}


// Address: 0x10e9460 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN8ClimbingE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::Climbing *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08F48;
  if ( !qword_2A08F48 )
  {
    result = RBX::Name::declare("Climbing");
    qword_2A08F48 = result;
  }
  return result;
}


// Address: 0x10e9490 | Name: _ZNK3RBX5HUMAN8Climbing7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::Climbing::getName(const RBX::HUMAN::Climbing *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08F48;
  if ( !qword_2A08F48 )
  {
    result = RBX::Name::declare("Climbing");
    qword_2A08F48 = result;
  }
  return result;
}


// Address: 0x10e94c0 | Name: _ZN3RBX5HUMAN7RunningC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Running::Running(
        RBX::HUMAN::Running *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::RunningBase::RunningBase(this, humanoid, priorState);
  *(_QWORD *)this = &off_2895C10;
  *((_DWORD *)this + 115) = 0;
}


// Address: 0x10e94e0 | Name: _ZN3RBX5HUMAN7Running10fireEventsEv
void __fastcall RBX::HUMAN::Running::fireEvents(RBX::HUMAN::Running *this)
{
  __m128 v1; // xmm0
  rbx::signal<void (float)> *v2; // r14
  __m128 v3; // xmm0
  float v4; // xmm1_4
  __m128 v5; // xmm0
  G3D::Vector3 v6; // [rsp+8h] [rbp-20h] BYREF
  RBX::Vector3 RelativeMovementVelocity; // 0:kr00_12.12

  RBX::HUMAN::HumanoidState::fireEvents(this);
  v2 = (rbx::signal<void (float)> *)((char *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 2632);
  RelativeMovementVelocity = RBX::HUMAN::HumanoidState::getRelativeMovementVelocity(this);
  v1.m128_i32[0] = LODWORD(RelativeMovementVelocity.x);
  v1.m128_i32[1] = LODWORD(RelativeMovementVelocity.y);
  _mm_storel_ps((double *)&v6.x, v1);
  v6.z = RelativeMovementVelocity.z;
  *(G3D::Vector2 *)v1.m128_f32 = G3D::Vector3::xz(&v6);
  v3 = _mm_mul_ps(v1, v1);
  v4 = _mm_shuffle_ps(v3, v3, 229).m128_f32[0] + v3.m128_f32[0];
  v5 = 0;
  v5.m128_f32[0] = fsqrt(v4);
  RBX::HUMAN::HumanoidState::fireMovementSignal(this, v2, v5, v4);
}


// Address: 0x10e9550 | Name: _ZN3RBX5HUMAN7Running18onComputeForceImplEv
void __fastcall RBX::HUMAN::Running::onComputeForceImpl(RBX::HUMAN::Running *this)
{
  const RBX::Humanoid *HumanoidConst; // rax
  const RBX::Humanoid *v2; // r14
  int v3; // eax
  float v4; // xmm0_4
  __m128 v5; // xmm2
  __m128 v6; // xmm2
  char v7; // al
  char v8; // cl
  int v9; // eax

  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  if ( *((char *)HumanoidConst + 700) <= 0 )
  {
    v2 = HumanoidConst;
    v3 = *((_DWORD *)HumanoidConst + 188) ^ *((_DWORD *)HumanoidConst + 187);
    v4 = (float)((float)v3 * 6000.0) * (float)((float)v3 * 6000.0);
    v5 = _mm_mul_ps(
           (__m128)*(unsigned __int64 *)((char *)this + 260),
           (__m128)*(unsigned __int64 *)((char *)this + 260));
    if ( ((float)(_mm_shuffle_ps(v5, v5, 229).m128_f32[0]
                + (float)((float)(*((float *)this + 64) * *((float *)this + 64)) + v5.m128_f32[0])) > v4
       || (v6 = _mm_mul_ps((__m128)*((unsigned __int64 *)this + 31), (__m128)*((unsigned __int64 *)this + 31)),
           (float)(_mm_shuffle_ps(v6, v6, 229).m128_f32[0]
                 + (float)((float)(*((float *)this + 61) * *((float *)this + 61)) + v6.m128_f32[0])) > v4))
      && RBX::HUMAN::HumanoidState::computeHitByHighImpactObject(this) )
    {
      v7 = RBX::globalRand();
      v8 = 1;
      v9 = v7 & 0x7F;
      if ( v9 )
        v8 = v9;
      *((_BYTE *)v2 + 700) = v8;
    }
    else
    {
      RBX::HUMAN::RunningBase::onComputeForceImpl(this);
    }
  }
}


// Address: 0x10e9620 | Name: _ZN3RBX5HUMAN7Running19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::Running::onSimulatorStepImpl(RBX::HUMAN::Running *this, float a2, float stepDt)
{
  float v3; // xmm1_4
  RBX::Humanoid *HumanoidConst; // rax
  RBX::PartInstance *TorsoSlow; // rax
  const RBX::Primitive *px; // r14
  RBX::Assembly *PrimitiveAssembly; // rax
  float DesiredAltitude; // xmm0_4
  float v9; // xmm0_4
  float v10; // xmm0_4
  float y; // [rsp+0h] [rbp-18h]

  v3 = *((float *)this + 107) - *((float *)this + 115);
  *((float *)this + 107) = v3;
  *((_DWORD *)this + 115) = 0;
  RBX::HUMAN::RunningBase::onSimulatorStepImpl(this, v3);
  if ( RBX::HUMAN::HumanoidState::getHumanoidConst(this) )
  {
    HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    TorsoSlow = RBX::Humanoid::getTorsoSlow(HumanoidConst);
    if ( TorsoSlow )
    {
      px = TorsoSlow->primitive.px;
      if ( px )
      {
        PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoSlow->primitive.px);
        if ( RBX::Assembly::getAssemblyPrimitive(PrimitiveAssembly) == px )
        {
          y = RBX::Primitive::getCoordinateFrame(px)->translation.y;
          DesiredAltitude = RBX::HUMAN::HumanoidState::getDesiredAltitude(this);
          if ( DesiredAltitude < INFINITY )
          {
            v9 = fminf(0.1, fmaxf(-0.1, (float)(DesiredAltitude - y) * 0.80000001));
            if ( fabs(v9) > 0.050000001 )
            {
              v10 = v9 / a2;
              *((float *)this + 115) = v10;
              *((float *)this + 107) = v10 + *((float *)this + 107);
            }
          }
        }
      }
    }
  }
}


// Address: 0x10e9720 | Name: _ZN3RBX5HUMAN12RunningSlaveC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::RunningSlave::RunningSlave(
        RBX::HUMAN::RunningSlave *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::RunningBase::RunningBase(this, humanoid, priorState);
  *((_DWORD *)this + 115) = 0;
  *(_QWORD *)this = &off_2895CA8;
}


// Address: 0x10e9740 | Name: _ZN3RBX5HUMAN6LandedC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::Landed::Landed(
        RBX::HUMAN::Landed *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::HUMAN::RunningBase::RunningBase(this, humanoid, priorState, 7500.0, 50.0);
  *(_QWORD *)this = &off_2895D40;
  if ( stru_2A10FE8.value )
  {
    *((float *)this + 78) = (float)dword_2859660;
    *((float *)this + 79) = (float)dword_2859670;
  }
  *((_DWORD *)this + 4) = 1028443341;
}


// Address: 0x10e97a0 | Name: _ZN3RBX5HUMAN6Landed19onSimulatorStepImplEf
float __fastcall RBX::HUMAN::Landed::onSimulatorStepImpl(RBX::HUMAN::Landed *this, double a2, float stepDt)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::PartInstance *TorsoSlow; // rax
  const RBX::Primitive *px; // r14
  RBX::Assembly *PrimitiveAssembly; // rax
  float result; // xmm0_4

  RBX::HUMAN::RunningBase::onSimulatorStepImpl(this, stepDt);
  if ( RBX::HUMAN::HumanoidState::getHumanoidConst(this) )
  {
    HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
    TorsoSlow = RBX::Humanoid::getTorsoSlow(HumanoidConst);
    if ( TorsoSlow )
    {
      px = TorsoSlow->primitive.px;
      if ( px )
      {
        PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoSlow->primitive.px);
        if ( RBX::Assembly::getAssemblyPrimitive(PrimitiveAssembly) == px )
        {
          RBX::Primitive::getCoordinateFrame(px);
          return RBX::HUMAN::HumanoidState::getDesiredAltitude(this);
        }
      }
    }
  }
  return result;
}


// Address: 0x10e9810 | Name: _ZN3RBX5HUMAN8Climbing10fireEventsEv
void __fastcall RBX::HUMAN::Climbing::fireEvents(RBX::HUMAN::Climbing *this)
{
  __m128 v1; // xmm0
  rbx::signal<void (float)> *v2; // r14
  RBX::Vector3 RelativeMovementVelocity; // 0:kr00_12.12

  RBX::HUMAN::HumanoidState::fireEvents(this);
  v2 = (rbx::signal<void (float)> *)((char *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 2640);
  RelativeMovementVelocity = RBX::HUMAN::HumanoidState::getRelativeMovementVelocity(this);
  v1.m128_i32[0] = LODWORD(RelativeMovementVelocity.x);
  v1.m128_i32[1] = LODWORD(RelativeMovementVelocity.y);
  RBX::HUMAN::HumanoidState::fireMovementSignal(this, v2, _mm_shuffle_ps(v1, v1, 229), RelativeMovementVelocity.z);
}


// Address: 0x10e9b10 | Name: _GLOBAL__sub_I_Running.cpp
void __cdecl GLOBAL__sub_I_Running_cpp()
{
  qword_2A08F10 = (__int64)boost::system::generic_category();
  qword_2A08F18 = (__int64)boost::system::generic_category();
  qword_2A08F20 = (__int64)boost::system::system_category();
  dword_2A08F28 = FLog::RegisterInt("LandedBalanceP", &dword_2859660, FastVarType::FASTVARTYPE_DYNAMIC);
  dword_2A08F2C = FLog::RegisterInt("LandedBalanceD", &dword_2859670, FastVarType::FASTVARTYPE_DYNAMIC);
}


