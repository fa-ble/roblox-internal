// Address: 0x10ecd10 | Name: _Z16Class_getNamePtrPN3RBX5HUMAN19MovingNoPhysicsBaseE
const RBX::Name *__fastcall Class_getNamePtr(RBX::HUMAN::MovingNoPhysicsBase *a1)
{
  const RBX::Name *result; // rax

  result = qword_2A08FF0;
  if ( !qword_2A08FF0 )
  {
    result = RBX::Name::declare("MovingNoPhysicsBase");
    qword_2A08FF0 = result;
  }
  return result;
}


// Address: 0x10ecd40 | Name: _ZNK3RBX5HUMAN19MovingNoPhysicsBase7getNameEv
const RBX::Name *__fastcall RBX::HUMAN::MovingNoPhysicsBase::getName(const RBX::HUMAN::MovingNoPhysicsBase *this)
{
  const RBX::Name *result; // rax

  result = qword_2A08FF0;
  if ( !qword_2A08FF0 )
  {
    result = RBX::Name::declare("MovingNoPhysicsBase");
    qword_2A08FF0 = result;
  }
  return result;
}


// Address: 0x10ecd70 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBaseC2EPNS_8HumanoidENS0_9StateTypeE
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::MovingNoPhysicsBase(
        RBX::HUMAN::MovingNoPhysicsBase *this,
        RBX::Humanoid *humanoid,
        RBX::HUMAN::StateType priorState)
{
  RBX::PartInstance *TorsoSlow; // rsi
  __m128i si128; // xmm0
  volatile signed __int32 *v5; // rbx
  volatile signed __int32 *v6; // rbx
  __int64 v7; // rax
  rbx::signal<void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>)> *v8; // rsi
  rbx::signals::slot_base *p; // rdi
  rbx::signals::connection other; // [rsp+8h] [rbp-40h] BYREF
  boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HUMAN::MovingNoPhysicsBase>,boost::_bi::list1<boost::_bi::value<RBX::HUMAN::MovingNoPhysicsBase *> > > function; // [rsp+10h] [rbp-38h] BYREF

  RBX::HUMAN::HumanoidState::HumanoidState(this, humanoid, priorState);
  *(_QWORD *)this = &off_2896070;
  *(_OWORD *)((char *)this + 328) = 0;
  *(_OWORD *)((char *)this + 312) = 0;
  *((_QWORD *)this + 43) = 0;
  TorsoSlow = RBX::Humanoid::getTorsoSlow(humanoid);
  RBX::shared_from<RBX::PartInstance>(
    (boost::weak_ptr<RBX::Reflection::DescribedBase>::element_type **)&function,
    TorsoSlow);
  si128 = _mm_load_si128((const __m128i *)&function);
  function.f_ = 0;
  v5 = (volatile signed __int32 *)*((_QWORD *)this + 40);
  *(__m128i *)((char *)this + 312) = si128;
  if ( v5 )
  {
    if ( !_InterlockedSub(v5 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 16LL))(v5);
      if ( !_InterlockedSub(v5 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 24LL))(v5);
    }
  }
  v6 = (volatile signed __int32 *)*((_QWORD *)&function.f_.f_ + 1);
  if ( *((_QWORD *)&function.f_.f_ + 1) )
  {
    if ( !_InterlockedSub((volatile signed __int32 *)(*((_QWORD *)&function.f_.f_ + 1) + 8LL), 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
      if ( !_InterlockedSub(v6 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
    }
  }
  v7 = *((_QWORD *)this + 39);
  if ( v7 )
  {
    RBX::Primitive::setEngineType(*(RBX::Primitive **)(v7 + 232), HUMANOID_ENGINE);
    v8 = (rbx::signal<void (boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>)> *)*((_QWORD *)this + 39);
    function.f_ = (boost::_mfi::mf0<void,RBX::HUMAN::MovingNoPhysicsBase>)(unsigned __int64)RBX::HUMAN::MovingNoPhysicsBase::onEvent_TorsoAncestryChanged;
    function.l_.a1_.t_ = this;
    rbx::signal<void ()(boost::shared_ptr<RBX::Instance>,boost::shared_ptr<RBX::Instance>)>::connect<boost::_bi::bind_t<void,boost::_mfi::mf0<void,RBX::HUMAN::MovingNoPhysicsBase>,boost::_bi::list1<boost::_bi::value<RBX::HUMAN::MovingNoPhysicsBase*>>>>(
      v8 + 13,
      &function);
    if ( rbx::signals::connection::operator!=((const rbx::signals::connection *)this + 43, &other) )
    {
      rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 43);
      rbx::signals::connection::operator=((rbx::signals::connection *)this + 43, &other);
    }
    p = other.weak_slot.p_;
    if ( other.weak_slot.p_ )
    {
      if ( !_InterlockedSub(&other.weak_slot.p_->weak.v, 1u) )
        operator delete(p);
    }
  }
}


// Address: 0x10ecfb0 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBase28onEvent_TorsoAncestryChangedEv
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::onEvent_TorsoAncestryChanged(RBX::HUMAN::MovingNoPhysicsBase *this)
{
  __int64 v1; // rax
  volatile signed __int32 *v2; // r14

  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 43);
  v1 = *((_QWORD *)this + 39);
  if ( v1 )
  {
    RBX::Primitive::setEngineType(*(RBX::Primitive **)(v1 + 232), DYNAMICS_ENGINE);
    v2 = (volatile signed __int32 *)*((_QWORD *)this + 40);
    *(_OWORD *)((char *)this + 312) = 0;
    if ( v2 )
    {
      if ( !_InterlockedSub(v2 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
        if ( !_InterlockedSub(v2 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
      }
    }
  }
}


// Address: 0x10ed030 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBaseD2Ev
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::~MovingNoPhysicsBase(RBX::HUMAN::MovingNoPhysicsBase *this)
{
  const rbx::signals::connection *v2; // r14
  __int64 v3; // rax
  volatile signed __int32 *v4; // r15
  volatile signed __int32 *v5; // rdi
  volatile signed __int32 *v6; // rdi
  volatile signed __int32 *v7; // rbx

  *(_QWORD *)this = &off_2896070;
  v2 = (const rbx::signals::connection *)((char *)this + 344);
  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 43);
  v3 = *((_QWORD *)this + 39);
  if ( v3 )
  {
    RBX::Primitive::setEngineType(*(RBX::Primitive **)(v3 + 232), DYNAMICS_ENGINE);
    v4 = (volatile signed __int32 *)*((_QWORD *)this + 40);
    *(_OWORD *)((char *)this + 312) = 0;
    if ( v4 )
    {
      if ( !_InterlockedSub(v4 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
        if ( !_InterlockedSub(v4 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 24LL))(v4);
      }
    }
  }
  rbx::signals::connection::disconnect(v2);
  v5 = (volatile signed __int32 *)&v2->weak_slot.p_->rbx::intrusive_ptr_target<rbx::signals::slot_base>;
  if ( v2->weak_slot.p_ && !_InterlockedSub(v5 + 1, 1u) )
    operator delete((void *)v5);
  v6 = (volatile signed __int32 *)*((_QWORD *)this + 42);
  if ( v6 && !_InterlockedSub(v6 + 3, 1u) )
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 24LL))(v6);
  v7 = (volatile signed __int32 *)*((_QWORD *)this + 40);
  if ( v7 )
  {
    if ( !_InterlockedSub(v7 + 2, 1u) )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
      if ( !_InterlockedSub(v7 + 3, 1u) )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 24LL))(v7);
    }
  }
  RBX::HUMAN::HumanoidState::~HumanoidState(this);
}


// Address: 0x10ed180 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBase15disconnectTorsoEv
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::disconnectTorso(RBX::HUMAN::MovingNoPhysicsBase *this)
{
  __int64 v1; // rax
  volatile signed __int32 *v2; // r14

  rbx::signals::connection::disconnect((const rbx::signals::connection *)this + 43);
  v1 = *((_QWORD *)this + 39);
  if ( v1 )
  {
    RBX::Primitive::setEngineType(*(RBX::Primitive **)(v1 + 232), DYNAMICS_ENGINE);
    v2 = (volatile signed __int32 *)*((_QWORD *)this + 40);
    *(_OWORD *)((char *)this + 312) = 0;
    if ( v2 )
    {
      if ( !_InterlockedSub(v2 + 2, 1u) )
      {
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
        if ( !_InterlockedSub(v2 + 3, 1u) )
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 24LL))(v2);
      }
    }
  }
}


// Address: 0x10ed200 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBaseD0Ev
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::~MovingNoPhysicsBase(RBX::HUMAN::MovingNoPhysicsBase *this)
{
  RBX::HUMAN::MovingNoPhysicsBase::~MovingNoPhysicsBase(this);
  operator delete(this);
}


// Address: 0x10ed220 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBase18onComputeForceImplEv
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::onComputeForceImpl(RBX::HUMAN::MovingNoPhysicsBase *this)
{
  ;
}


// Address: 0x10ed230 | Name: _ZNK3RBX5HUMAN19MovingNoPhysicsBase16getAssemblyConstEv
const RBX::Assembly *__fastcall RBX::HUMAN::MovingNoPhysicsBase::getAssemblyConst(
        const RBX::HUMAN::MovingNoPhysicsBase *this)
{
  const RBX::Humanoid *HumanoidConst; // rax
  RBX::Primitive *px; // rdi

  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  px = RBX::Humanoid::getTorsoSlow(HumanoidConst)->primitive.px;
  if ( px )
    return RBX::Assembly::getConstPrimitiveAssembly(px);
  else
    return 0;
}


// Address: 0x10ed260 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBase19applyImpulseToFloorEf
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::applyImpulseToFloor(
        RBX::HUMAN::MovingNoPhysicsBase *this,
        float a2,
        double dt)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::Body *RootBodyFast; // rax
  RBX::Body *v5; // rbx
  RBX::Primitive *FloorPrimitive; // rax
  RBX::Primitive *v7; // r14
  RBX::Cofm *cofm; // r12
  unsigned int *p_mass; // rbx
  double v10; // xmm0_8
  __int64 v11; // rbx
  float *v12; // rbx
  float v13; // xmm5_4
  RBX::Solver::SolverRigidBody *v14; // rbx
  float v15; // xmm5_4
  float v16; // xmm3_4
  float v17; // xmm2_4
  RBX::PartInstance *v18; // rbx
  RBX::Humanoid *v19; // rax
  RBX::PartInstance *TorsoSlow; // rax
  boost::detail::sp_counted_base *pi; // rbx
  float v23; // [rsp+0h] [rbp-38h]
  boost::shared_ptr<RBX::PartInstance> other; // [rsp+8h] [rbp-30h] BYREF

  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  RootBodyFast = RBX::Humanoid::getRootBodyFast(HumanoidConst);
  if ( !RootBodyFast )
    return;
  v5 = RootBodyFast;
  FloorPrimitive = RBX::HUMAN::HumanoidState::getFloorPrimitive(this);
  if ( !FloorPrimitive )
    return;
  v7 = FloorPrimitive;
  cofm = v5->cofm;
  if ( cofm )
  {
    RBX::Cofm::updateIfDirty(v5->cofm);
    p_mass = (unsigned int *)&cofm->branch.mass;
LABEL_8:
    *(_QWORD *)&v10 = *p_mass;
    goto LABEL_9;
  }
  if ( !v5->isMassless || (v10 = 0.0, v5->root == v5) )
  {
    p_mass = (unsigned int *)&v5->bodyMass.mass;
    goto LABEL_8;
  }
LABEL_9:
  v11 = *((_QWORD *)v7 + 26);
  if ( v11 )
  {
    RBX::Cofm::updateIfDirty(*((RBX::Cofm **)v7 + 26));
    *(_QWORD *)&v10 = LODWORD(v10);
    v12 = (float *)(v11 + 24);
  }
  else
  {
    if ( *((_BYTE *)v7 + 236) )
    {
      v13 = 0.0;
      if ( *((RBX::Primitive **)v7 + 25) != (RBX::Primitive *)((char *)v7 + 152) )
        goto LABEL_15;
    }
    v12 = (float *)((char *)v7 + 312);
  }
  v13 = *v12;
LABEL_15:
  v14 = *(RBX::Solver::SolverRigidBody **)(*((_QWORD *)v7 + 25) + 64LL);
  if ( v14 )
  {
    v15 = (float)((float)(fminf(v13, *(float *)&v10) * *(float *)(*((_QWORD *)v7 + 17) + 176LL)) * a2) * -0.5;
    if ( v14->dirty )
    {
      v23 = v15;
      RBX::Solver::SolverRigidBody::update(v14);
      v15 = v23;
    }
    HIDWORD(v10) = 0;
    v14->impulse.x = v14->impulse.x + 0.0;
    v14->impulse.y = v14->impulse.y + v15;
    v14->impulse.z = v14->impulse.z + 0.0;
    *(_QWORD *)&dt = *((unsigned int *)this + 33);
    *(float *)&dt = *(float *)&dt - v14->pv.position.translation.x;
    v16 = *((float *)this + 35) - v14->pv.position.translation.z;
    v17 = (float)(*((float *)this + 34) - v14->pv.position.translation.y) * 0.0;
    *(float *)&v10 = 0.0 * *(float *)&dt;
    v14->rotationalImpulse.x = (float)(v17 - (float)(v15 * v16)) + v14->rotationalImpulse.x;
    v14->rotationalImpulse.y = (float)((float)(v16 * 0.0) - (float)(0.0 * *(float *)&dt)) + v14->rotationalImpulse.y;
    *(float *)&dt = (float)((float)(*(float *)&dt * v15) - v17) + v14->rotationalImpulse.z;
    v14->rotationalImpulse.z = *(float *)&dt;
  }
  v18 = RBX::PartInstance::fromPrimitive(v7);
  v19 = RBX::HUMAN::HumanoidState::getHumanoidConst(this);
  TorsoSlow = RBX::Humanoid::getTorsoSlow(v19);
  if ( v18 )
  {
    if ( TorsoSlow )
    {
      RBX::shared_from<RBX::PartInstance>(&other.px, TorsoSlow);
      RBX::PartInstance::reportTouch(v18, &other);
      pi = other.pn.pi_;
      if ( other.pn.pi_ )
      {
        if ( !_InterlockedSub(&other.pn.pi_->use_count_, 1u) )
        {
          (*((void (__fastcall **)(boost::detail::sp_counted_base *, double, double))pi->_vptr$sp_counted_base + 2))(
            pi,
            v10,
            dt);
          if ( !_InterlockedSub(&pi->weak_count_, 1u) )
            (*((void (__fastcall **)(boost::detail::sp_counted_base *))pi->_vptr$sp_counted_base + 3))(pi);
        }
      }
    }
  }
}


// Address: 0x10ed4f0 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBase19onSimulatorStepImplEf
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::onSimulatorStepImpl(RBX::Vector3 *this, float a2, float stepDt)
{
  RBX::Humanoid *HumanoidConst; // rax
  RBX::PartInstance *TorsoSlow; // rax
  RBX::Primitive *px; // rbx
  RBX::Assembly *PrimitiveAssembly; // rax
  const RBX::SpatialFilter *v7; // r15
  RBX::Assembly *v8; // rax
  const RBX::CoordinateFrame *CoordinateFrame; // rax
  __int128 v10; // xmm1
  __int128 v11; // xmm2
  const RBX::Humanoid *v12; // rax
  float v13; // xmm0_4
  __m128 v14; // xmm4
  RBX::Primitive *FloorPrimitive; // r15
  __m128 x_low; // xmm0
  bool v17; // bp
  float DesiredAltitude; // xmm0_4
  float v19; // xmm1_4
  float v20; // xmm1_4
  const RBX::PV *PV; // rax
  __m128 v22; // xmm0
  RBX::Humanoid *v23; // rax
  float v24; // xmm0_4
  float v25; // xmm13_4
  float v26; // xmm14_4
  __m128 v27; // xmm3
  __m128 v28; // xmm4
  __m128 v29; // xmm5
  float v30; // xmm1_4
  float v31; // xmm12_4
  float v32; // xmm6_4
  float v33; // xmm1_4
  float v34; // xmm2_4
  __m128 v35; // xmm1
  float v36; // xmm1_4
  float v37; // xmm2_4
  __int64 v38; // rax
  __int64 v39; // rcx
  __int64 v40; // rdx
  __m128 v41; // xmm15
  float x; // xmm11_4
  float v43; // xmm10_4
  float v44; // xmm0_4
  RBX::Cofm *v45; // r12
  float *p_mass; // rax
  float v47; // xmm8_4
  float v48; // xmm0_4
  float v49; // xmm5_4
  float v50; // xmm7_4
  float v51; // xmm4_4
  float v52; // xmm2_4
  float v53; // xmm3_4
  float v54; // xmm5_4
  float v55; // xmm3_4
  float v56; // xmm13_4
  float v57; // xmm2_4
  float v58; // xmm7_4
  float v59; // xmm13_4
  double v60; // xmm1_8
  const RBX::Humanoid *v61; // rax
  float v62; // [rsp+4h] [rbp-114h]
  float v63; // [rsp+4h] [rbp-114h]
  RBX::Vector3 desiredLinearVelocity; // [rsp+8h] [rbp-110h] BYREF
  RBX::Vector3 v65; // [rsp+14h] [rbp-104h] BYREF
  float v66; // [rsp+20h] [rbp-F8h]
  float z; // [rsp+24h] [rbp-F4h]
  RBX::Velocity v68; // [rsp+28h] [rbp-F0h] BYREF
  float y; // [rsp+44h] [rbp-D4h]
  RBX::Velocity vel; // [rsp+48h] [rbp-D0h] BYREF
  RBX::CoordinateFrame c; // [rsp+60h] [rbp-B8h] BYREF
  __m128 v72; // [rsp+90h] [rbp-88h]
  __m128 v73; // [rsp+A0h] [rbp-78h]
  __m128 v74; // [rsp+B0h] [rbp-68h]
  __m128 z_low; // [rsp+C0h] [rbp-58h]
  __m128 v76; // [rsp+D0h] [rbp-48h]
  __m128 v77; // [rsp+E0h] [rbp-38h]
  RBX::Vector3 DownwardVectorOnSteepSlope; // 0:kr00_12.12

  v66 = a2;
  HumanoidConst = RBX::HUMAN::HumanoidState::getHumanoidConst((const RBX::HUMAN::HumanoidState *)this);
  TorsoSlow = RBX::Humanoid::getTorsoSlow(HumanoidConst);
  if ( !TorsoSlow )
    return;
  px = TorsoSlow->primitive.px;
  if ( !px )
    return;
  PrimitiveAssembly = RBX::Assembly::getPrimitiveAssembly(TorsoSlow->primitive.px);
  if ( RBX::Assembly::getAssemblyPrimitive(PrimitiveAssembly) != px || *((_BYTE *)px + 595) )
    return;
  v7 = *(const RBX::SpatialFilter **)(*((_QWORD *)RBX::HUMAN::HumanoidState::getHumanoidConst((const RBX::HUMAN::HumanoidState *)this)
                                      + 308)
                                    + 856LL);
  if ( stru_2A08D00.value || stru_2A69178.value )
  {
    if ( v7 )
    {
      v8 = RBX::Assembly::getPrimitiveAssembly(px);
      if ( !RBX::SpatialFilter::canDoManualHumanoidSimulation(v7, v8) )
        return;
    }
  }
  else if ( v7 && RBX::SpatialFilter::isForceNoClientPhysics_deprecated(v7) )
  {
    return;
  }
  CoordinateFrame = RBX::Primitive::getCoordinateFrame(px);
  v10 = *(_OWORD *)&CoordinateFrame->rotation.elt[1][1];
  v11 = *(_OWORD *)&CoordinateFrame->rotation.elt[2][2];
  *(_OWORD *)&c.rotation.elt[0][0] = *(_OWORD *)&CoordinateFrame->rotation.elt[0][0];
  *(_OWORD *)&c.rotation.elt[1][1] = v10;
  *(_OWORD *)&c.rotation.elt[2][2] = v11;
  v12 = RBX::HUMAN::HumanoidState::getHumanoidConst((const RBX::HUMAN::HumanoidState *)this);
  (*(void (__fastcall **)(RBX::Velocity *, const RBX::Humanoid *))(*(_QWORD *)v12 + 416LL))(&vel, v12);
  RBX::HUMAN::HumanoidState::getFloorPointVelocity(&v68, (RBX::HUMAN::HumanoidState *)this);
  v13 = vel.linear.z + v68.linear.z;
  v14 = _mm_add_ps((__m128)*(unsigned __int64 *)&v68.rotational.x, (__m128)*(unsigned __int64 *)&vel.rotational.x);
  *(float *)&v11 = vel.rotational.z + v68.rotational.z;
  _mm_storel_ps(
    (double *)&desiredLinearVelocity.x,
    _mm_add_ps((__m128)*(unsigned __int64 *)&v68.linear.x, (__m128)*(unsigned __int64 *)&vel.linear.x));
  desiredLinearVelocity.z = v13;
  _mm_storel_ps((double *)&v65.x, v14);
  LODWORD(v65.z) = v11;
  FloorPrimitive = RBX::HUMAN::HumanoidState::getFloorPrimitive((RBX::HUMAN::HumanoidState *)this);
  *(_QWORD *)&v68.linear.x = 0;
  v68.linear.z = 0.0;
  if ( FloorPrimitive )
  {
    v68.linear = *(this + 12);
    x_low = (__m128)LODWORD(v68.linear.x);
    z = 0.0;
    v62 = (float)(v68.linear.z * 0.0) + (float)((float)(v68.linear.x * 0.0) + v68.linear.y);
    x_low.m128_f32[0] = RBX::HUMAN::HumanoidState::steepSlopeAngle((const RBX::HUMAN::HumanoidState *)this);
    v17 = x_low.m128_f32[0] > v62;
    if ( x_low.m128_f32[0] <= v62 )
    {
      RBX::Humanoid::reprojectDesiredLinearVelocityToFloor(&v68.linear, &desiredLinearVelocity);
      v72 = 0;
    }
    else
    {
      RBX::Humanoid::cancelXZDesiredVelocityUpSteepSlope(&v68.linear, &desiredLinearVelocity);
      DownwardVectorOnSteepSlope = RBX::Humanoid::getDownwardVectorOnSteepSlope(&v68.linear);
      x_low.m128_i32[0] = LODWORD(DownwardVectorOnSteepSlope.x);
      x_low.m128_i32[1] = LODWORD(DownwardVectorOnSteepSlope.y);
      v72 = x_low;
      z = DownwardVectorOnSteepSlope.z;
    }
    DesiredAltitude = RBX::HUMAN::HumanoidState::getDesiredAltitude((RBX::HUMAN::HumanoidState *)this);
    v63 = 0.0;
    if ( DesiredAltitude < INFINITY )
    {
      v19 = fminf(0.1, fmaxf(-0.1, (float)(DesiredAltitude - c.translation.y) * 0.80000001));
      if ( fabs(v19) <= 0.050000001 )
      {
        c.translation.y = DesiredAltitude;
      }
      else
      {
        v20 = v19 / v66;
        desiredLinearVelocity.y = desiredLinearVelocity.y + v20;
        v63 = v20;
      }
    }
  }
  else
  {
    z = 0.0;
    v72 = 0;
    v17 = 0;
    v63 = 0.0;
  }
  PV = RBX::Primitive::getPV(px);
  v74 = (__m128)LODWORD(PV->velocity.linear.x);
  y = PV->velocity.linear.y;
  z_low = (__m128)LODWORD(PV->velocity.linear.z);
  v76 = (__m128)LODWORD(desiredLinearVelocity.x);
  v22 = (__m128)LODWORD(desiredLinearVelocity.z);
  v73 = (__m128)LODWORD(desiredLinearVelocity.z);
  v22.m128_f32[0] = RBX::HUMAN::HumanoidState::runningKMovePForPGS();
  v77 = v22;
  if ( FloorPrimitive )
  {
    v23 = RBX::HUMAN::HumanoidState::getHumanoidConst((const RBX::HUMAN::HumanoidState *)this);
    v24 = RBX::Humanoid::computeMaxHumanoidFloorFrictionForce(v23, FloorPrimitive);
  }
  else
  {
    v24 = 143.0;
  }
  v25 = z_low.m128_f32[0];
  v26 = v74.m128_f32[0];
  v27 = _mm_mul_ps(_mm_shuffle_ps(v77, v77, 224), _mm_sub_ps(_mm_unpacklo_ps(v73, v76), _mm_unpacklo_ps(z_low, v74)));
  v28 = 0;
  v28.m128_f32[0] = 0.0 * v77.m128_f32[0];
  v29 = _mm_mul_ps(v27, v27);
  v30 = (float)(_mm_shuffle_ps(v29, v29, 229).m128_f32[0] + (float)(v28.m128_f32[0] * v28.m128_f32[0]))
      + v29.m128_f32[0];
  v31 = v66;
  if ( v30 > (float)(v24 * v24) )
  {
    v32 = fsqrt(v30);
    v33 = 0.0;
    v34 = 0.0;
    if ( v32 >= 0.0000001 )
    {
      v35 = _mm_shuffle_ps(v27, v27, 229);
      if ( v32 >= 1.00001 || v32 <= 0.99998999 )
      {
        v35.m128_f32[0] = v35.m128_f32[0] * (float)(1.0 / v32);
        v28.m128_f32[0] = v28.m128_f32[0] * (float)(1.0 / v32);
        LODWORD(v33) = _mm_unpacklo_ps(v35, v28).m128_u32[0];
        v27.m128_f32[0] = v27.m128_f32[0] * (float)(1.0 / v32);
      }
      else
      {
        LODWORD(v33) = _mm_shuffle_ps(_mm_shuffle_ps(v28, v35, 0), v35, 226).m128_u32[0];
      }
      v34 = v27.m128_f32[0];
    }
    v36 = (float)(v33 * v24) * v66;
    v37 = (float)(v34 * v24) * v66;
    if ( v36 >= 0.0 && (float)(desiredLinearVelocity.x - v74.m128_f32[0]) >= v36
      || v36 < 0.0 && v36 >= (float)(desiredLinearVelocity.x - v74.m128_f32[0]) )
    {
      desiredLinearVelocity.x = v36 + v74.m128_f32[0];
    }
    if ( v37 >= 0.0 && (float)(desiredLinearVelocity.z - z_low.m128_f32[0]) >= v37
      || v37 < 0.0 && v37 >= (float)(desiredLinearVelocity.z - z_low.m128_f32[0]) )
    {
      desiredLinearVelocity.z = v37 + z_low.m128_f32[0];
    }
  }
  if ( v17 )
  {
    v38 = *((_QWORD *)px + 25);
    v39 = *(_QWORD *)(v38 + 48);
    v40 = *(_QWORD *)(v39 + 64);
    if ( v40 )
      v41 = (__m128)*(unsigned __int64 *)(v40 + 240);
    else
      v41 = 0;
    v45 = *(RBX::Cofm **)(v38 + 56);
    if ( v45 )
    {
      v73 = v41;
      RBX::Cofm::updateIfDirty(v45);
      p_mass = &v45->branch.mass;
      v31 = v66;
      v25 = z_low.m128_f32[0];
      v26 = v74.m128_f32[0];
      v41 = v73;
    }
    else
    {
      if ( v39 != v38 )
      {
        v47 = 0.0;
        if ( *(_BYTE *)(v38 + 84) )
        {
LABEL_51:
          v48 = fsqrt((float)(v68.linear.z * v68.linear.z) + (float)((float)(v68.linear.x * v68.linear.x) + 0.0));
          v49 = v68.linear.x * (float)(1.0 / v48);
          v50 = v68.linear.z * (float)(1.0 / v48);
          v51 = (float)(1.0 / v48) * 0.0;
          v52 = (float)(desiredLinearVelocity.z * v50)
              + (float)((float)(desiredLinearVelocity.y * v51) + (float)(desiredLinearVelocity.x * v49));
          v53 = fsqrt((float)(v50 * v50) + (float)((float)(v51 * v51) + (float)(v49 * v49)));
          x = desiredLinearVelocity.x - (float)((float)(v49 * (float)(1.0 / v53)) * v52);
          desiredLinearVelocity.x = x;
          v43 = desiredLinearVelocity.y - (float)((float)(v51 * (float)(1.0 / v53)) * v52);
          desiredLinearVelocity.y = v43;
          v44 = desiredLinearVelocity.z - (float)((float)((float)(1.0 / v53) * v50) * v52);
          desiredLinearVelocity.z = v44;
          LODWORD(v54) = _mm_shuffle_ps(v72, v72, 229).m128_u32[0];
          if ( z != 0.0 || v72.m128_f32[0] != 0.0 || v54 != 0.0 )
          {
            v55 = (float)(z * 0.0)
                + (float)((float)((float)(_mm_shuffle_ps(v41, v41, 229).m128_f32[0] / v47) * v54)
                        + (float)(v72.m128_f32[0] * 0.0));
            v56 = (float)(v25 * z) + (float)((float)(y * v54) + (float)(v26 * v72.m128_f32[0]));
            v57 = v72.m128_f32[0] * v56;
            v58 = v54 * v56;
            v59 = (float)(v56 * z) + (float)((float)(z * v55) * v31);
            x = x + (float)(v57 + (float)((float)(v72.m128_f32[0] * v55) * v31));
            desiredLinearVelocity.x = x;
            if ( v63 == 0.0 )
              v43 = v43 + (float)(v58 + (float)((float)(v54 * v55) * v31));
            else
              v43 = v43 + (float)((float)(0.0 * v31) + v58);
            desiredLinearVelocity.y = v43;
            v44 = v44 + v59;
            desiredLinearVelocity.z = v44;
          }
          goto LABEL_58;
        }
      }
      p_mass = (float *)(v38 + 160);
    }
    v47 = *p_mass;
    goto LABEL_51;
  }
  x = desiredLinearVelocity.x;
  v43 = desiredLinearVelocity.y;
  v44 = desiredLinearVelocity.z;
LABEL_58:
  c.translation.x = (float)(x * v31) + c.translation.x;
  c.translation.y = (float)(v43 * v31) + c.translation.y;
  c.translation.z = (float)(v44 * v31) + c.translation.z;
  v60 = 0.0;
  if ( v65.y != 0.0 )
    RBX::Math::rotateAboutYGlobal(&c, 0.0);
  RBX::Math::orthonormalizeIfNecessary(&c.rotation);
  RBX::Primitive::setCoordinateFrame(px, &c);
  desiredLinearVelocity.y = desiredLinearVelocity.y - v63;
  vel.linear = desiredLinearVelocity;
  vel.rotational = v65;
  RBX::Primitive::setVelocity(px, &vel);
  if ( FloorPrimitive )
  {
    *(_QWORD *)&v60 = LODWORD(desiredLinearVelocity.y);
    *(float *)&v60 = (float)(*(float *)&v60 * *(float *)&v60)
                   + (float)(desiredLinearVelocity.x * desiredLinearVelocity.x);
    if ( fsqrt((float)(desiredLinearVelocity.z * desiredLinearVelocity.z) + *(float *)&v60) > 2.0 )
    {
      v61 = RBX::HUMAN::HumanoidState::getHumanoidConst((const RBX::HUMAN::HumanoidState *)this);
      RBX::World::ticklePrimitive(*((RBX::World **)v61 + 308), FloorPrimitive, 1);
    }
  }
  RBX::HUMAN::MovingNoPhysicsBase::applyImpulseToFloor((RBX::HUMAN::MovingNoPhysicsBase *)this, v66, v60);
}


// Address: 0x10edd80 | Name: _ZN3RBX5HUMAN19MovingNoPhysicsBase10fireEventsEv
void __fastcall RBX::HUMAN::MovingNoPhysicsBase::fireEvents(RBX::HUMAN::MovingNoPhysicsBase *this)
{
  __m128 v1; // xmm0
  rbx::signal<void (float)> *v2; // r14
  __m128 v3; // xmm0
  float v4; // xmm1_4
  __m128 v5; // xmm0
  G3D::Vector3 v6; // [rsp+8h] [rbp-20h] BYREF
  RBX::Vector3 RelativeMovementVelocity; // 0:kr00_12.12

  RBX::HUMAN::HumanoidState::fireEvents(this);
  v2 = (rbx::signal<void (float)> *)((char *)RBX::HUMAN::HumanoidState::getHumanoidConst(this) + 2632);
  RelativeMovementVelocity = RBX::HUMAN::HumanoidState::getRelativeMovementVelocity(this);
  v1.m128_i32[0] = LODWORD(RelativeMovementVelocity.x);
  v1.m128_i32[1] = LODWORD(RelativeMovementVelocity.y);
  _mm_storel_ps((double *)&v6.x, v1);
  v6.z = RelativeMovementVelocity.z;
  *(G3D::Vector2 *)v1.m128_f32 = G3D::Vector3::xz(&v6);
  v3 = _mm_mul_ps(v1, v1);
  v4 = _mm_shuffle_ps(v3, v3, 229).m128_f32[0] + v3.m128_f32[0];
  v5 = 0;
  v5.m128_f32[0] = fsqrt(v4);
  RBX::HUMAN::HumanoidState::fireMovementSignal(this, v2, v5, v4);
}


// Address: 0x10edf20 | Name: _GLOBAL__sub_I_MovingNoPhysicsBase.cpp
void __cdecl GLOBAL__sub_I_MovingNoPhysicsBase_cpp()
{
  qword_2A08FD8 = (__int64)boost::system::generic_category();
  qword_2A08FE0 = (__int64)boost::system::generic_category();
  qword_2A08FE8 = (__int64)boost::system::system_category();
}


